
//--TRIMMABLE-BOUNDARY-START(120)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $mecga, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mexla, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mexl, $mjw) {
    "use strict";
    let _;
    let $OupbDk;
    let $xMiIFe;
    let $lXhCPj;
    let $DMmNDk;
    let $dSWqJi;
    let $DMQpJi;
    let $cdgKJk;
    let $oVMiAa;
    let $smDjTi;
    let $wFJuvh;
    let $bpMjYi;
    let $CLqyla;
    let $KoaGNi;
    let $JMdqXa;
    let $rbvwof;
    let $plQTag;
    let $TKqZBj;
    let $DATYbe;
    let $tlkPqj;
    let $sDPgif;
    let $yowRNd;
    let $FxhfUi;
    let $oUEAbb;
    let $yqKJkh;
    let $JiViwa;
    let $yRuptc;
    let $qEtZWj;
    let $nAHPoj;
    let $wjwnFh;
    let $HeaYOg;
    let $sFcuBk;
    let $REnbaa;
    let $LFOBYg;
    let $TSvgpi;
    let $cBlUqc;
    let $QnuFJf;
    let $RYRNcj;
    let $TxjQNh;
    let $sGCMoj;
    let $kRThKc;
    let $Nbkque;
    let $mqIZZa;
    let $bpbJof;
    let $enZOmg;
    let $nPqWXf;
    let $FfASHd;
    let $ofiNzk;
    let $bfVTAg;
    let $Qhesxg;
    let $lCrrBb;
    let $GkxiIe;
    let $vFrYed;
    let $Amavtk;
    let $LkpXNd;
    let $xsHgXg;
    let $NGjcfh;
    let $WnQxoh;
    let $lkHeBf;
    let $cnJkHe;
    let $uUgOSj;
    let $mZgcFh;
    let $pFqSpf;
    let $FzPOoh;
    let $tpUYib;
    let $ZMFLkg;
    let $bQzgQd;
    let $hVftSe;
    let $IYUOil;
    let $grALai;
    let $zbNOHe;
    let $ChrJKd;
    let $iHpDBd;
    let $DSZlga;
    let $FxRaud;
    let $BKyEHd;
    let $qcFuSg;
    let $zqlcwe;
    let $yqQujk;
    let $IYnuuj;
    let $EiUJMi;
    let $CjYLii;
    let $JzXEGj;
    let $phwCWb;
    let $KGxtda;
    let $NQIyId;
    let $NKbRSd;
    let $GNhlja;
    let $ZaLeSk;
    let $kfuzIc;
    let $wHdCvg;
    let $wiALKh;
    let $rGEYpj;
    let $DMQhbh;
    let $ZYMznl;
    let $olrEsh;
    let $JBsKhh;
    let $cjOmAf;
    let $sahUSd;
    let $teEgBc;
    let $wZQQXj;
    let $xUqcAb;
    let $XzjMJk;
    let $yUdNsg;
    let $rImwNj;
    let $EZEuPg;
    let $zghUxd;
    let $vJQtPh;
    let $fAnYYb;
    let $vYvNaj;
    let $sXmEyf;
    let $tqFtPe;
    let $bPcwNb;
    let $WIGvki;
    let $AHMgwg;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.WebAssembly", 
    {
  "h": 120,
  "f": "Microsoft.AspNetCore.Components.WebAssembly",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Build client-side single-page applications (SPAs) with Blazor running under WebAssembly.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Authentication.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "BasicTestApp",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "DynamicProxyGenAssembly2",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 589944,
          "t": 188547073
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1441912)
        $asm.$cls(`$macwa.MACWH.IWebAssemblyHostEnvironment`, ($self) => class IWebAssemblyHostEnvironment
        {
            static $h = 1441912;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591376504),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245688,
        "f": 50331905
      },
      "n": "Environment",
      "o": "MACWH$IWebAssemblyHostEnvironment$Environment",
      "d": 1441912,
      "h": 8591376504,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591376504),
//--TRIMMABLE-BOUNDARY-START(4296409208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181311096,
        "f": 50331905
      },
      "n": "BaseAddress",
      "o": "MACWH$IWebAssemblyHostEnvironment$BaseAddress",
      "d": 1441912,
      "h": 4296409208,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296409208)
  ],
  "h": 1441912
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}IWebAssemblyHostEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441912)
        
        

        //--TRIMMABLE-BOUNDARY-START(3342456)
        $asm.$cls(`$macwa.MACWS.IInternalJSImportMethods`, ($self) => class IInternalJSImportMethods
        {
            static $h = 3342456;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183211640),
    {
      "r": 1310721,
      "n": "GetPersistedState",
      "o": "MACWS$IInternalJSImportMethods$GetPersistedState",
      "d": 3342456,
      "h": 17183211640,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17183211640),
//--TRIMMABLE-BOUNDARY-START(12888244344),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironment",
      "o": "MACWS$IInternalJSImportMethods$GetApplicationEnvironment",
      "d": 3342456,
      "h": 12888244344,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888244344),
//--TRIMMABLE-BOUNDARY-START(4298309752),
    {
      "r": 65537,
      "p": [
        {
          "n": "domElementSelector",
          "p": 1310721
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "AttachRootComponentToElement",
      "o": "MACWS$IInternalJSImportMethods$AttachRootComponentToElement",
      "d": 3342456,
      "h": 4298309752,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298309752),
//--TRIMMABLE-BOUNDARY-START(8593277048),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "EndUpdateRootComponents",
      "o": "MACWS$IInternalJSImportMethods$EndUpdateRootComponents",
      "d": 3342456,
      "h": 8593277048,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593277048),
//--TRIMMABLE-BOUNDARY-START(21478178936),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "NavigationManager_EnableNavigationInterception",
      "o": "MACWS$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception",
      "d": 3342456,
      "h": 21478178936,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478178936),
//--TRIMMABLE-BOUNDARY-START(34363080824),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "NavigationManager_ScrollToElement",
      "o": "MACWS$IInternalJSImportMethods$NavigationManager_ScrollToElement",
      "d": 3342456,
      "h": 34363080824,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34363080824),
//--TRIMMABLE-BOUNDARY-START(30068113528),
    {
      "r": 1310721,
      "n": "NavigationManager_GetLocationHref",
      "o": "MACWS$IInternalJSImportMethods$NavigationManager_GetLocationHref",
      "d": 3342456,
      "h": 30068113528,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30068113528),
//--TRIMMABLE-BOUNDARY-START(25773146232),
    {
      "r": 1310721,
      "n": "NavigationManager_GetBaseUri",
      "o": "MACWS$IInternalJSImportMethods$NavigationManager_GetBaseUri",
      "d": 3342456,
      "h": 25773146232,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25773146232),
//--TRIMMABLE-BOUNDARY-START(38658048120),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "NavigationManager_SetHasLocationChangingListeners",
      "o": "MACWS$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners",
      "d": 3342456,
      "h": 38658048120,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38658048120),
//--TRIMMABLE-BOUNDARY-START(55837917304),
    {
      "r": 655361,
      "n": "RegisteredComponents_GetRegisteredComponentsCount",
      "o": "MACWS$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount",
      "d": 3342456,
      "h": 55837917304,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55837917304),
//--TRIMMABLE-BOUNDARY-START(42953015416),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetAssembly",
      "o": "MACWS$IInternalJSImportMethods$RegisteredComponents_GetAssembly",
      "d": 3342456,
      "h": 42953015416,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42953015416),
//--TRIMMABLE-BOUNDARY-START(60132884600),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetTypeName",
      "o": "MACWS$IInternalJSImportMethods$RegisteredComponents_GetTypeName",
      "d": 3342456,
      "h": 60132884600,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60132884600),
//--TRIMMABLE-BOUNDARY-START(47247982712),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterDefinitions",
      "o": "MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions",
      "d": 3342456,
      "h": 47247982712,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47247982712),
//--TRIMMABLE-BOUNDARY-START(51542950008),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterValues",
      "o": "MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterValues",
      "d": 3342456,
      "h": 51542950008,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51542950008)
  ],
  "h": 3342456
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}IInternalJSImportMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342456)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835128)
        $asm.$cls(`$macwa.MACWH.WebAssemblyCultureProvider`, ($self) => class WebAssemblyCultureProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1900664)
            static $_WebAssemblyCultureProviderInterop;
            static get WebAssemblyCultureProviderInterop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWH.WebAssemblyCultureProvider;
                return $cls.$_WebAssemblyCultureProviderInterop ??= $asm.$ncls(`$macwa.MACWH.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop`, ($self) => class WebAssemblyCultureProviderInterop extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835256)
                    static /*Task */ LoadSatelliteAssemblies(/*string[]*/ culturesToLoad)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591835256);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.STT.Task.CompletedTask;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591835256)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867960)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296867960);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867960)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867960)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867960)
                    
                    static $h = 1900664;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591835256),
    {
      "r": 178454529,
      "p": [
        {
          "n": "culturesToLoad",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "LoadSatelliteAssemblies",
      "d": 1900664,
      "h": 8591835256,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.loadSatelliteAssemblies",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591835256)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867960),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900664,
      "h": 4296867960,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867960)
  ],
  "d": 1835128,
  "h": 1900664
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider+WebAssemblyCultureProviderInterop`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyCultureProvider${separator}WebAssemblyCultureProviderInterop`; }
                }, $cls, ($v) => $cls.$_WebAssemblyCultureProviderInterop = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900664)
            
            //--TRIMMABLE-BOUNDARY-START(55836409976)
            /*string*/ static GetSatelliteAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(55836409976)
            
            //--TRIMMABLE-BOUNDARY-START(81606213752)
            /*string*/ static ReadSatelliteAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(81606213752)
            
            //--TRIMMABLE-BOUNDARY-START(17181704312)
            $ctor$1(/*CultureInfo*/ initialCulture, /*CultureInfo*/ initialUICulture)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181704312);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InitialCulture = initialCulture;
                    this.InitialUICulture = initialUICulture;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181704312)
            
            //--TRIMMABLE-BOUNDARY-START(73016279160)
            /*WebAssemblyCultureProvider?*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(73016279160)
            
            //--TRIMMABLE-BOUNDARY-START(60131377272)
            /*CultureInfo*/ InitialCulture = null;
            //--TRIMMABLE-BOUNDARY-END(60131377272)
            
            //--TRIMMABLE-BOUNDARY-START(68721311864)
            /*CultureInfo*/ InitialUICulture = null;
            //--TRIMMABLE-BOUNDARY-END(68721311864)
            
            //--TRIMMABLE-BOUNDARY-START(64426344568)
            static /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426344568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.MACWH.WebAssemblyCultureProvider.Instance = new $.$macwa.MACWH.WebAssemblyCultureProvider().$ctor$1($.$$.SG.CultureInfo.CurrentCulture, $.$$.SG.CultureInfo.CurrentUICulture);
            }
            //--TRIMMABLE-BOUNDARY-END(64426344568)
            
            //--TRIMMABLE-BOUNDARY-START(94491115640)
            /*void */ ThrowIfCultureChangeIsUnsupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491115640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Environment.GetEnvironmentVariable$1("__BLAZOR_SHARDED_ICU") === "1" && ((!$.$$.S.String.Equals$2.call($.$$.SG.CultureInfo.CurrentCulture.Name, this.InitialCulture.Name, 4/*StringComparison.Ordinal*/) || !$.$$.S.String.Equals$2.call($.$$.SG.CultureInfo.CurrentUICulture.Name, this.InitialUICulture.Name, 4/*StringComparison.Ordinal*/))))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Blazor detected a change in the application's culture that is not supported with the current project configuration. " + "To change culture dynamically during startup, set <BlazorWebAssemblyLoadAllGlobalizationData>true</BlazorWebAssemblyLoadAllGlobalizationData> in the application's project file.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491115640)
            
            //--TRIMMABLE-BOUNDARY-START(77311246456)
            /*ValueTask *//*async*/  LoadCurrentCultureResourcesAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311246456);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.S.OperatingSystem.IsBrowser())
                    {
                        throw new $.$$.S.PlatformNotSupportedException().$ctor$16("This method is only supported in the browser.");
                    }
                    /*var*/ let culturesToLoad = $.$macwa.MACWH.WebAssemblyCultureProvider.GetCultures($.$$.SG.CultureInfo.CurrentCulture, $.$$.SG.CultureInfo.CurrentUICulture);
                    if (culturesToLoad.length === 0)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    ($t1 = $.$macwa.MACWH.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop.LoadSatelliteAssemblies(culturesToLoad), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311246456)
            
            //--TRIMMABLE-BOUNDARY-START(51541442680)
            static /*string[] */ GetCultures(/*CultureInfo*/ cultureInfo, /*CultureInfo?*/ uiCultureInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541442680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let culturesToLoad = $.$macwa.MACWH.WebAssemblyCultureProvider.GetCultureHierarchy(cultureInfo);
                if (cultureInfo !== uiCultureInfo)
                {
                    let $en2 = $.$macwa.MACWH.WebAssemblyCultureProvider.GetCultureHierarchy(uiCultureInfo).SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let culture = $en2.SCG$IEnumerator$$$Current;
                        {
                            if (!$.$sl.SL.Enumerable.Contains$1($.$$.S.String, culturesToLoad, culture))
                            {
                                culturesToLoad = $.$sl.SL.Enumerable.Append($.$$.S.String, culturesToLoad, culture);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                return $.$sl.SL.Enumerable.ToArray($.$$.S.String, culturesToLoad);
            }
            //--TRIMMABLE-BOUNDARY-END(51541442680)
            
            //--TRIMMABLE-BOUNDARY-START(47246475384)
            static /*IEnumerable<string> */ GetCultureHierarchy(/*CultureInfo?*/ culture)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.String))().$ctor$1(function*()
                {
                    while(culture !== $.$$.SG.CultureInfo.InvariantCulture && culture !== null)
                    {
                        yield culture.Name;
                        if (culture === culture.Parent)
                        {
                            break;
                        }
                        culture = culture.Parent;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(47246475384)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(55836409976)
                    this.GetSatelliteAssemblies = "window.Blazor._internal.getSatelliteAssemblies";
                    //--TRIMMABLE-BOUNDARY-END(55836409976)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606213752)
                    this.ReadSatelliteAssemblies = "window.Blazor._internal.readSatelliteAssemblies";
                    //--TRIMMABLE-BOUNDARY-END(81606213752)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1835128;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016279160),
    {
      "p": 1835128,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951508088,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196148344,
        "f": 83886114
      },
      "n": "Instance",
      "d": 1835128,
      "h": 73016279160,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73016279160),
//--TRIMMABLE-BOUNDARY-START(60131377272),
    {
      "p": 84738049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771638904,
        "f": 50331649
      },
      "n": "InitialCulture",
      "d": 1835128,
      "h": 60131377272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131377272),
//--TRIMMABLE-BOUNDARY-START(68721311864),
    {
      "p": 84738049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361573496,
        "f": 50331649
      },
      "n": "InitialUICulture",
      "d": 1835128,
      "h": 68721311864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721311864)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426344568),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1835128,
      "h": 64426344568,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64426344568),
//--TRIMMABLE-BOUNDARY-START(94491115640),
    {
      "r": 65537,
      "n": "ThrowIfCultureChangeIsUnsupported",
      "d": 1835128,
      "h": 94491115640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491115640),
//--TRIMMABLE-BOUNDARY-START(77311246456),
    {
      "r": 181338113,
      "n": "LoadCurrentCultureResourcesAsync",
      "d": 1835128,
      "h": 77311246456,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(77311246456),
//--TRIMMABLE-BOUNDARY-START(51541442680),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "p": [
        {
          "n": "cultureInfo",
          "p": 84738049
        },
        {
          "n": "uiCultureInfo",
          "p": 84738049,
          "f": 65
        }
      ],
      "n": "GetCultures",
      "d": 1835128,
      "h": 51541442680,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541442680),
//--TRIMMABLE-BOUNDARY-START(47246475384),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "GetCultureHierarchy",
      "d": 1835128,
      "h": 47246475384,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246475384)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836409976),
    {
      "t": 1310721,
      "n": "GetSatelliteAssemblies",
      "d": 1835128,
      "h": 55836409976,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836409976),
//--TRIMMABLE-BOUNDARY-START(81606213752),
    {
      "t": 1310721,
      "n": "ReadSatelliteAssemblies",
      "d": 1835128,
      "h": 81606213752,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81606213752)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181704312),
    {
      "p": [
        {
          "n": "initialCulture",
          "p": 84738049
        },
        {
          "n": "initialUICulture",
          "p": 84738049
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835128,
      "h": 17181704312,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181704312)
  ],
  "h": 1835128
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MACWH.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyCultureProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835128)
        
        

        //--TRIMMABLE-BOUNDARY-START(655480)
        $asm.$cls(`$macwa.MAC.JsonSerializerOptionsProvider`, ($self) => class JsonSerializerOptionsProvider
        {
            //--TRIMMABLE-BOUNDARY-START(8590590072)
            /*JsonSerializerOptions*/ static Options = null;
            //--TRIMMABLE-BOUNDARY-END(8590590072)
            
            //--TRIMMABLE-BOUNDARY-START(4295622776)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590590072)
                    this.Options = (() =>
                    {
                        //new $.$stj.STJ.JsonSerializerOptions()
                        const $t1 = $.$stj.STJ.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.STJ.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.IncludeFields = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8590590072)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295622776)
            
            static $h = 655480;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590590072),
    {
      "t": 3342420,
      "n": "Options",
      "d": 655480,
      "h": 8590590072,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590072)
  ],
  "h": 655480
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.JsonSerializerOptionsProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}JsonSerializerOptionsProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655480)
        
        

        //--TRIMMABLE-BOUNDARY-START(4194424)
        $asm.$cls(`$macwa.MAC.WebAssemblyComponentSerializationSettings`, ($self) => class WebAssemblyComponentSerializationSettings
        {
            //--TRIMMABLE-BOUNDARY-START(8594129016)
            /*JsonSerializerOptions*/ static JsonSerializationOptions = null;
            //--TRIMMABLE-BOUNDARY-END(8594129016)
            
            //--TRIMMABLE-BOUNDARY-START(4299161720)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299161720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8594129016)
                    this.JsonSerializationOptions = (() =>
                    {
                        //new $.$stj.STJ.JsonSerializerOptions()
                        const $t1 = $.$stj.STJ.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.STJ.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.DefaultIgnoreCondition = 3/*JsonIgnoreCondition.WhenWritingNull*/;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8594129016)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299161720)
            
            static $h = 4194424;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8594129016),
    {
      "t": 3342420,
      "n": "JsonSerializationOptions",
      "d": 4194424,
      "h": 8594129016,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594129016)
  ],
  "h": 4194424
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssemblyComponentSerializationSettings`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssemblyComponentSerializationSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4194424)
        
        

        //--TRIMMABLE-BOUNDARY-START(3211384)
        $asm.$cls(`$macwa.MACWS.ConsoleLoggerInterop`, ($self) => class ConsoleLoggerInterop
        {
            static $h = 3211384;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3211384
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.ConsoleLoggerInterop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}ConsoleLoggerInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211384)
        
        

        //--TRIMMABLE-BOUNDARY-START(4456568)
        $asm.$cls(`$macwa.MAI.LinkerFlags`, ($self) => class LinkerFlags
        {
            //--TRIMMABLE-BOUNDARY-START(12889358456)
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            //--TRIMMABLE-BOUNDARY-END(12889358456)
            
            //--TRIMMABLE-BOUNDARY-START(4299423864)
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            //--TRIMMABLE-BOUNDARY-END(4299423864)
            
            //--TRIMMABLE-BOUNDARY-START(8594391160)
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            //--TRIMMABLE-BOUNDARY-END(8594391160)
            
            static $h = 4456568;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889358456),
    {
      "n": "JsonSerialized",
      "d": 4456568,
      "h": 12889358456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889358456),
//--TRIMMABLE-BOUNDARY-START(4299423864),
    {
      "n": "Component",
      "d": 4456568,
      "h": 4299423864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4299423864),
//--TRIMMABLE-BOUNDARY-START(8594391160),
    {
      "n": "JSInvokable",
      "d": 4456568,
      "h": 8594391160,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594391160)
  ],
  "h": 4456568
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Internal.LinkerFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Internal${separator}LinkerFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4456568)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376376)
        $asm.$cls(`$macwa.MACW.BrowserNavigationManagerInterop`, ($self) => class BrowserNavigationManagerInterop
        {
            //--TRIMMABLE-BOUNDARY-START(21476212856)
            /*string*/ static Prefix = null;
            //--TRIMMABLE-BOUNDARY-END(21476212856)
            
            //--TRIMMABLE-BOUNDARY-START(4296343672)
            /*string*/ static EnableNavigationInterception = null;
            //--TRIMMABLE-BOUNDARY-END(4296343672)
            
            //--TRIMMABLE-BOUNDARY-START(12886278264)
            /*string*/ static GetLocationHref = null;
            //--TRIMMABLE-BOUNDARY-END(12886278264)
            
            //--TRIMMABLE-BOUNDARY-START(8591310968)
            /*string*/ static GetBaseUri = null;
            //--TRIMMABLE-BOUNDARY-END(8591310968)
            
            //--TRIMMABLE-BOUNDARY-START(17181245560)
            /*string*/ static NavigateTo = null;
            //--TRIMMABLE-BOUNDARY-END(17181245560)
            
            //--TRIMMABLE-BOUNDARY-START(25771180152)
            /*string*/ static Refresh = null;
            //--TRIMMABLE-BOUNDARY-END(25771180152)
            
            //--TRIMMABLE-BOUNDARY-START(34361114744)
            /*string*/ static SetHasLocationChangingListeners = null;
            //--TRIMMABLE-BOUNDARY-END(34361114744)
            
            //--TRIMMABLE-BOUNDARY-START(30066147448)
            /*string*/ static ScrollToElement = null;
            //--TRIMMABLE-BOUNDARY-END(30066147448)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21476212856)
                    this.Prefix = "Blazor._internal.navigationManager.";
                    //--TRIMMABLE-BOUNDARY-END(21476212856)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296343672)
                    this.EnableNavigationInterception = "Blazor._internal.navigationManager.enableNavigationInterception";
                    //--TRIMMABLE-BOUNDARY-END(4296343672)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278264)
                    this.GetLocationHref = "Blazor._internal.navigationManager.getLocationHref";
                    //--TRIMMABLE-BOUNDARY-END(12886278264)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310968)
                    this.GetBaseUri = "Blazor._internal.navigationManager.getBaseURI";
                    //--TRIMMABLE-BOUNDARY-END(8591310968)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181245560)
                    this.NavigateTo = "Blazor._internal.navigationManager.navigateTo";
                    //--TRIMMABLE-BOUNDARY-END(17181245560)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771180152)
                    this.Refresh = "Blazor._internal.navigationManager.refresh";
                    //--TRIMMABLE-BOUNDARY-END(25771180152)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361114744)
                    this.SetHasLocationChangingListeners = "Blazor._internal.navigationManager.setHasLocationChangingListeners";
                    //--TRIMMABLE-BOUNDARY-END(34361114744)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066147448)
                    this.ScrollToElement = "Blazor._internal.navigationManager.scrollToElement";
                    //--TRIMMABLE-BOUNDARY-END(30066147448)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1376376;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212856),
    {
      "t": 1310721,
      "n": "Prefix",
      "d": 1376376,
      "h": 21476212856,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476212856),
//--TRIMMABLE-BOUNDARY-START(4296343672),
    {
      "t": 1310721,
      "n": "EnableNavigationInterception",
      "d": 1376376,
      "h": 4296343672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296343672),
//--TRIMMABLE-BOUNDARY-START(12886278264),
    {
      "t": 1310721,
      "n": "GetLocationHref",
      "d": 1376376,
      "h": 12886278264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278264),
//--TRIMMABLE-BOUNDARY-START(8591310968),
    {
      "t": 1310721,
      "n": "GetBaseUri",
      "d": 1376376,
      "h": 8591310968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310968),
//--TRIMMABLE-BOUNDARY-START(17181245560),
    {
      "t": 1310721,
      "n": "NavigateTo",
      "d": 1376376,
      "h": 17181245560,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245560),
//--TRIMMABLE-BOUNDARY-START(25771180152),
    {
      "t": 1310721,
      "n": "Refresh",
      "d": 1376376,
      "h": 25771180152,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771180152),
//--TRIMMABLE-BOUNDARY-START(34361114744),
    {
      "t": 1310721,
      "n": "SetHasLocationChangingListeners",
      "d": 1376376,
      "h": 34361114744,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361114744),
//--TRIMMABLE-BOUNDARY-START(30066147448),
    {
      "t": 1310721,
      "n": "ScrollToElement",
      "d": 1376376,
      "h": 30066147448,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066147448)
  ],
  "h": 1376376
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Web.BrowserNavigationManagerInterop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Web${separator}BrowserNavigationManagerInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376376)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572984)
        $asm.$cls(`$macwa.MACWH.RegisteredComponentsInterop`, ($self) => class RegisteredComponentsInterop extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361311352)
            /*string*/ static Prefix = null;
            //--TRIMMABLE-BOUNDARY-END(34361311352)
            
            //--TRIMMABLE-BOUNDARY-START(25771376760)
            /*string*/ static GetRegisteredComponentsCount = null;
            //--TRIMMABLE-BOUNDARY-END(25771376760)
            
            //--TRIMMABLE-BOUNDARY-START(12886474872)
            /*string*/ static GetId = null;
            //--TRIMMABLE-BOUNDARY-END(12886474872)
            
            //--TRIMMABLE-BOUNDARY-START(8591507576)
            /*string*/ static GetAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(8591507576)
            
            //--TRIMMABLE-BOUNDARY-START(30066344056)
            /*string*/ static GetTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(30066344056)
            
            //--TRIMMABLE-BOUNDARY-START(17181442168)
            /*string*/ static GetParameterDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(17181442168)
            
            //--TRIMMABLE-BOUNDARY-START(21476409464)
            /*string*/ static GetParameterValues = null;
            //--TRIMMABLE-BOUNDARY-END(21476409464)
            
            //--TRIMMABLE-BOUNDARY-START(4296540280)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540280)
            
            //--TRIMMABLE-BOUNDARY-START(4296540280)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540280)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34361311352)
                    this.Prefix = "Blazor._internal.registeredComponents.";
                    //--TRIMMABLE-BOUNDARY-END(34361311352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771376760)
                    this.GetRegisteredComponentsCount = "Blazor._internal.registeredComponents.getRegisteredComponentsCount";
                    //--TRIMMABLE-BOUNDARY-END(25771376760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886474872)
                    this.GetId = "Blazor._internal.registeredComponents.getId";
                    //--TRIMMABLE-BOUNDARY-END(12886474872)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507576)
                    this.GetAssembly = "Blazor._internal.registeredComponents.getAssembly";
                    //--TRIMMABLE-BOUNDARY-END(8591507576)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066344056)
                    this.GetTypeName = "Blazor._internal.registeredComponents.getTypeName";
                    //--TRIMMABLE-BOUNDARY-END(30066344056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181442168)
                    this.GetParameterDefinitions = "Blazor._internal.registeredComponents.getParameterDefinitions";
                    //--TRIMMABLE-BOUNDARY-END(17181442168)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476409464)
                    this.GetParameterValues = "Blazor._internal.registeredComponents.getParameterValues";
                    //--TRIMMABLE-BOUNDARY-END(21476409464)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 1572984;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361311352),
    {
      "t": 1310721,
      "n": "Prefix",
      "d": 1572984,
      "h": 34361311352,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361311352),
//--TRIMMABLE-BOUNDARY-START(25771376760),
    {
      "t": 1310721,
      "n": "GetRegisteredComponentsCount",
      "d": 1572984,
      "h": 25771376760,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771376760),
//--TRIMMABLE-BOUNDARY-START(12886474872),
    {
      "t": 1310721,
      "n": "GetId",
      "d": 1572984,
      "h": 12886474872,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474872),
//--TRIMMABLE-BOUNDARY-START(8591507576),
    {
      "t": 1310721,
      "n": "GetAssembly",
      "d": 1572984,
      "h": 8591507576,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507576),
//--TRIMMABLE-BOUNDARY-START(30066344056),
    {
      "t": 1310721,
      "n": "GetTypeName",
      "d": 1572984,
      "h": 30066344056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066344056),
//--TRIMMABLE-BOUNDARY-START(17181442168),
    {
      "t": 1310721,
      "n": "GetParameterDefinitions",
      "d": 1572984,
      "h": 17181442168,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442168),
//--TRIMMABLE-BOUNDARY-START(21476409464),
    {
      "t": 1310721,
      "n": "GetParameterValues",
      "d": 1572984,
      "h": 21476409464,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476409464)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540280),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572984,
      "h": 4296540280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540280)
  ],
  "h": 1572984
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.RegisteredComponentsInterop`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}RegisteredComponentsInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572984)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048696)
        $asm.$cls(`$macwa.MAC.RootComponentOperationBatch`, ($self) => class RootComponentOperationBatch extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180917880)
            /*long*/ BatchId = 0n;
            //--TRIMMABLE-BOUNDARY-END(17180917880)
            
            //--TRIMMABLE-BOUNDARY-START(42950721656)
            /*RootComponentOperation[]*/ Operations = null;
            //--TRIMMABLE-BOUNDARY-END(42950721656)
            
            //--TRIMMABLE-BOUNDARY-START(38655754360)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655754360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${$.$strNN("RootComponentOperationBatch")}: ${$.$strNN(this.BatchId)}, Operations Count: ${$.$strNN(this.Operations.length)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754360)
            
            //--TRIMMABLE-BOUNDARY-START(12885950584)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950584)
            
            //--TRIMMABLE-BOUNDARY-START(12885950584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885950584)
            
            static $h = 1048696;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180917880),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770852472,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540656248,
        "f": 83886081
      },
      "n": "BatchId",
      "d": 1048696,
      "h": 17180917880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180917880),
//--TRIMMABLE-BOUNDARY-START(42950721656),
    {
      "p": $.$typeArray($.$macwa.MAC.RootComponentOperation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360787064,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130590840,
        "f": 83886081
      },
      "n": "Operations",
      "d": 1048696,
      "h": 42950721656,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950721656)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655754360),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 1048696,
      "h": 38655754360,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655754360)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950584),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048696,
      "h": 12885950584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950584)
  ],
  "h": 1048696,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.RootComponentOperationBatch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}RootComponentOperationBatch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048696)
        
        

        //--TRIMMABLE-BOUNDARY-START(917624)
        $asm.$cls(`$macwa.MAC.ResourceCollectionProvider`, ($self) => class ResourceCollectionProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885819512)
            /*string?*/ _url = null;
            //--TRIMMABLE-BOUNDARY-END(12885819512)
            
            //--TRIMMABLE-BOUNDARY-START(38655623288)
            /*string? */ get ResourceCollectionUrl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._url;
            }
            /*string? */ set ResourceCollectionUrl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._url !== null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("The resource collection URL has already been set.");
                }
                this._url = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623288)
            
            //--TRIMMABLE-BOUNDARY-START(8590852216)
            /*ResourceAssetCollection?*/ _resourceCollection = null;
            //--TRIMMABLE-BOUNDARY-END(8590852216)
            
            //--TRIMMABLE-BOUNDARY-START(4295884920)
            /*IJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295884920)
            
            //--TRIMMABLE-BOUNDARY-START(17180786808)
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786808)
            
            //--TRIMMABLE-BOUNDARY-START(30065688696)
            /*Task<ResourceAssetCollection> *//*async*/  GetResourceCollection()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mac.MAC.ResourceAssetCollection), $.$mac.MAC.ResourceAssetCollection, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resourceCollection = this._resourceCollection ??= ($t1 = this.LoadResourceCollection(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, this._resourceCollection);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065688696)
            
            //--TRIMMABLE-BOUNDARY-START(51540525176)
            /*void */ SetResourceCollection(/*ResourceAssetCollection*/ resourceCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._resourceCollection = resourceCollection;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525176)
            
            //--TRIMMABLE-BOUNDARY-START(34360655992)
            /*Task<ResourceAssetCollection> *//*async*/  LoadResourceCollection()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$mac.MAC.ResourceAssetCollection), $.$mac.MAC.ResourceAssetCollection, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._url === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$mac.MAC.ResourceAssetCollection.Empty);
                    }
                    /*var*/ let module = ($t2 = $.$mj.MJ.JSRuntimeExtensions.InvokeAsync($.$mj.MJ.IJSObjectReference, this._jsRuntime, "import", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this._url ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*var*/ let result = ($t3 = $.$mj.MJ.JSObjectReferenceExtensions.InvokeAsync($.$typeArray($.$mac.MAC.ResourceAsset), module, "get", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, result === null ? $.$mac.MAC.ResourceAssetCollection.Empty : new $.$mac.MAC.ResourceAssetCollection().$ctor$1(result));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360655992)
            
            static $h = 917624;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655623288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721400,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245557880,
        "f": 83886081
      },
      "n": "ResourceCollectionUrl",
      "d": 917624,
      "h": 38655623288,
      "f": 2097153,
      "a": [
        {
          "t": 6357107,
          "c": 12891258995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655623288)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065688696),
    {
      "r": $.$$.STT.Task$$($.$mac.MAC.ResourceAssetCollection).$h,
      "n": "GetResourceCollection",
      "d": 917624,
      "h": 30065688696,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(30065688696),
//--TRIMMABLE-BOUNDARY-START(51540525176),
    {
      "r": 65537,
      "p": [
        {
          "n": "resourceCollection",
          "p": 9437299
        }
      ],
      "n": "SetResourceCollection",
      "d": 917624,
      "h": 51540525176,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540525176),
//--TRIMMABLE-BOUNDARY-START(34360655992),
    {
      "r": $.$$.STT.Task$$($.$mac.MAC.ResourceAssetCollection).$h,
      "n": "LoadResourceCollection",
      "d": 917624,
      "h": 34360655992,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360655992)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819512),
    {
      "t": 1310721,
      "n": "_url",
      "d": 917624,
      "h": 12885819512,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819512),
//--TRIMMABLE-BOUNDARY-START(8590852216),
    {
      "t": 9437299,
      "n": "_resourceCollection",
      "d": 917624,
      "h": 8590852216,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852216),
//--TRIMMABLE-BOUNDARY-START(4295884920),
    {
      "t": 524402,
      "n": "_jsRuntime",
      "d": 917624,
      "h": 4295884920,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786808),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917624,
      "h": 17180786808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786808)
  ],
  "h": 917624
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ResourceCollectionProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ResourceCollectionProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917624)
        
        

        //--TRIMMABLE-BOUNDARY-START(2621560)
        $asm.$cls(`$macwa.MACWI.JSInteropMethods`, ($self) => class JSInteropMethods
        {
            //--TRIMMABLE-BOUNDARY-START(4297588856)
            static /*void */ NotifyLocationChanged(/*string*/ uri, /*bool*/ isInterceptedLink)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297588856);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.MACWS.WebAssemblyNavigationManager.Instance.SetLocation(uri, null, isInterceptedLink);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297588856)
            
            //--TRIMMABLE-BOUNDARY-START(8592556152)
            static /*void */ NotifyLocationChanged$1(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592556152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.MACWS.WebAssemblyNavigationManager.Instance.SetLocation(uri, state, isInterceptedLink);
            }
            //--TRIMMABLE-BOUNDARY-END(8592556152)
            
            //--TRIMMABLE-BOUNDARY-START(12887523448)
            static /*ValueTask<bool> *//*async*/  NotifyLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887523448);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = $.$macwa.MACWS.WebAssemblyNavigationManager.Instance.HandleLocationChangingAsync(uri, state, isInterceptedLink), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887523448)
            
            static $h = 2621560;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588856),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChanged",
      "d": 2621560,
      "h": 4297588856,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API is for framework use only and is no longer used in the current version",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297588856),
//--TRIMMABLE-BOUNDARY-START(8592556152),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChanged",
      "o": "@$1",
      "d": 2621560,
      "h": 8592556152,
      "f": 16777249,
      "a": [
        {
          "t": 2818162,
          "c": 12887720050,
          "a": [
            {
              "v": "NotifyLocationChanged",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592556152),
//--TRIMMABLE-BOUNDARY-START(12887523448),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChangingAsync",
      "d": 2621560,
      "h": 12887523448,
      "f": 16781345,
      "a": [
        {
          "t": 2818162,
          "c": 12887720050,
          "a": [
            {
              "v": "NotifyLocationChangingAsync",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887523448)
  ],
  "h": 2621560,
  "a": [
    {
      "t": 65011713,
      "c": 12949913601,
      "a": [
        {
          "v": 1,
          "t": 65077249
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.JSInteropMethods`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Infrastructure${separator}JSInteropMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621560)
        
        

        //--TRIMMABLE-BOUNDARY-START(2293880)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHostEnvironmentExtensions`, ($self) => class WebAssemblyHostEnvironmentExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297261176)
            static /*bool */ IsDevelopment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297261176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.MACWH.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Development");
            }
            //--TRIMMABLE-BOUNDARY-END(4297261176)
            
            //--TRIMMABLE-BOUNDARY-START(17182163064)
            static /*bool */ IsStaging(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182163064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.MACWH.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Staging");
            }
            //--TRIMMABLE-BOUNDARY-END(17182163064)
            
            //--TRIMMABLE-BOUNDARY-START(12887195768)
            static /*bool */ IsProduction(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887195768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.MACWH.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Production");
            }
            //--TRIMMABLE-BOUNDARY-END(12887195768)
            
            //--TRIMMABLE-BOUNDARY-START(8592228472)
            static /*bool */ IsEnvironment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment, /*string*/ environmentName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592228472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$$.S.String.Equals$3(hostingEnvironment.MACWH$IWebAssemblyHostEnvironment$Environment, environmentName, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8592228472)
            
            static $h = 2293880;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297261176),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441912
        }
      ],
      "n": "IsDevelopment",
      "d": 2293880,
      "h": 4297261176,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297261176),
//--TRIMMABLE-BOUNDARY-START(17182163064),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441912
        }
      ],
      "n": "IsStaging",
      "d": 2293880,
      "h": 17182163064,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182163064),
//--TRIMMABLE-BOUNDARY-START(12887195768),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441912
        }
      ],
      "n": "IsProduction",
      "d": 2293880,
      "h": 12887195768,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887195768),
//--TRIMMABLE-BOUNDARY-START(8592228472),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441912
        },
        {
          "n": "environmentName",
          "p": 1310721
        }
      ],
      "n": "IsEnvironment",
      "d": 2293880,
      "h": 8592228472,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592228472)
  ],
  "h": 2293880
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHostEnvironmentExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293880)
        
        

        //--TRIMMABLE-BOUNDARY-START(4128888)
        $asm.$cls(`$macwa.MAC.WebAssemblyComponentParameterDeserializer`, ($self) => class WebAssemblyComponentParameterDeserializer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4299096184)
            /*ComponentParametersTypeCache*/ _parametersCache = null;
            //--TRIMMABLE-BOUNDARY-END(4299096184)
            
            //--TRIMMABLE-BOUNDARY-START(17183998072)
            $ctor$1(/*ComponentParametersTypeCache*/ parametersCache)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183998072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._parametersCache = parametersCache;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183998072)
            
            //--TRIMMABLE-BOUNDARY-START(42953801848)
            /*WebAssemblyComponentParameterDeserializer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(42953801848)
            
            //--TRIMMABLE-BOUNDARY-START(21478965368)
            /*ParameterView */ DeserializeParameters(/*IList<ComponentParameter>*/ parametersDefinitions, /*IList<object>*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478965368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parametersDictionary = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                if (parameterValues.SCG$ICollection$$$Count !== parametersDefinitions.SCG$ICollection$$$Count)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`The number of parameter definitions '${$.$strNN(parametersDefinitions.SCG$ICollection$$$Count)}' does not match the number parameter values '${$.$strNN(parameterValues.SCG$ICollection$$$Count)}'.`);
                }
                for(/*var*/ let i = 0; i < parametersDefinitions.SCG$ICollection$$$Count; i++)
                {
                    /*var*/ let definition = parametersDefinitions.SCG$IList$$$get_Item(i);
                    if (definition.Name === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("The name is missing in a parameter definition.");
                    }
                    if (definition.TypeName === null && definition.Assembly === null)
                    {
                        parametersDictionary.set_Item(definition.Name, null);
                    }
                    else if (definition.TypeName === null || definition.Assembly === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`The parameter definition for '${$.$strNN(definition.Name)}' is incomplete: Type='${$.$strNN(definition.TypeName)}' Assembly='${$.$strNN(definition.Assembly)}'.`);
                    }
                    else 
                    {
                        /*var*/ let parameterType = this._parametersCache.GetParameterType(definition.Assembly, definition.TypeName);
                        if (parameterType === null)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`The parameter '${$.$strNN(definition.Name)}' with type '${$.$strNN(definition.TypeName)}' in assembly '${$.$strNN(definition.Assembly)}' could not be found.`);
                        }
                        try
                        {
                            /*var*/ let value = $.$cast(parameterValues.SCG$IList$$$get_Item(i), $.$stj.STJ.JsonElement);
                            /*var*/ let parameterValue = $.$stj.STJ.JsonSerializer.Deserialize$13(value.GetRawText(), parameterType, $.$macwa.MAC.WebAssemblyComponentSerializationSettings.JsonSerializationOptions);
                            parametersDictionary.set_Item(definition.Name, parameterValue);
                        }
                        catch(e)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$11(`Could not parse the parameter value for parameter '${$.$strNN(definition.Name)}' of type '${$.$strNN(definition.TypeName)}' and assembly '${$.$strNN(definition.Assembly)}'.`, e);
                        }
                    }
                }
                return $.$mac.MAC.ParameterView.FromDictionary(parametersDictionary);
            }
            //--TRIMMABLE-BOUNDARY-END(21478965368)
            
            //--TRIMMABLE-BOUNDARY-START(34363867256)
            static /*ComponentParameter[] */ GetParameterDefinitions(/*string*/ parametersDefinitions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363867256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stj.STJ.JsonSerializer.Deserialize$33($.$typeArray($.$macwa.MAC.ComponentParameter), parametersDefinitions, $.$macwa.MACWI.WebAssemblyJsonSerializerContext.Default.ComponentParameterArray);
            }
            //--TRIMMABLE-BOUNDARY-END(34363867256)
            
            //--TRIMMABLE-BOUNDARY-START(38658834552)
            static /*IList<object> */ GetParameterValues(/*string*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658834552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stj.STJ.JsonSerializer.Deserialize$33($.$$.SCG.IList$$($.$$.S.Object), parameterValues, $.$macwa.MACWI.WebAssemblyJsonSerializerContext.Default.IListObject);
            }
            //--TRIMMABLE-BOUNDARY-END(38658834552)
            
            //--TRIMMABLE-BOUNDARY-START(12889030776)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889030776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(42953801848)
                    this.Instance = new $.$macwa.MAC.WebAssemblyComponentParameterDeserializer().$ctor$1(new $.$macwa.MAC.ComponentParametersTypeCache().$ctor$1());
                    //--TRIMMABLE-BOUNDARY-END(42953801848)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889030776)
            
            static $h = 4128888;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953801848),
    {
      "p": 4128888,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068899960,
        "f": 50331681
      },
      "n": "Instance",
      "d": 4128888,
      "h": 42953801848,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42953801848)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478965368),
    {
      "r": 5767283,
      "p": [
        {
          "n": "parametersDefinitions",
          "p": $.$$.SCG.IList$$($.$macwa.MAC.ComponentParameter).$h
        },
        {
          "n": "parameterValues",
          "p": $.$$.SCG.IList$$($.$$.S.Object).$h
        }
      ],
      "n": "DeserializeParameters",
      "d": 4128888,
      "h": 21478965368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478965368),
//--TRIMMABLE-BOUNDARY-START(34363867256),
    {
      "r": $.$typeArray($.$macwa.MAC.ComponentParameter).$h,
      "p": [
        {
          "n": "parametersDefinitions",
          "p": 1310721
        }
      ],
      "n": "GetParameterDefinitions",
      "d": 4128888,
      "h": 34363867256,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34363867256),
//--TRIMMABLE-BOUNDARY-START(38658834552),
    {
      "r": $.$$.SCG.IList$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "parameterValues",
          "p": 1310721
        }
      ],
      "n": "GetParameterValues",
      "d": 4128888,
      "h": 38658834552,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38658834552)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299096184),
    {
      "t": 327800,
      "n": "_parametersCache",
      "d": 4128888,
      "h": 4299096184,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4299096184)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183998072),
    {
      "p": [
        {
          "n": "parametersCache",
          "p": 327800
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4128888,
      "h": 17183998072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183998072)
  ],
  "h": 4128888
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssemblyComponentParameterDeserializer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4128888)
        
        

        //--TRIMMABLE-BOUNDARY-START(983160)
        $asm.$cls(`$macwa.MAC.RootComponentOperation`, ($self) => class RootComponentOperation extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107375165560)
            /*RootComponentOperationType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(107375165560)
            
            //--TRIMMABLE-BOUNDARY-START(103080198264)
            /*int*/ SsrComponentId = 0;
            //--TRIMMABLE-BOUNDARY-END(103080198264)
            
            //--TRIMMABLE-BOUNDARY-START(64425492600)
            /*ComponentMarker?*/ Marker = null;
            //--TRIMMABLE-BOUNDARY-END(64425492600)
            
            //--TRIMMABLE-BOUNDARY-START(25770786936)
            /*WebRootComponentDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(25770786936)
            
            //--TRIMMABLE-BOUNDARY-START(21475819640)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819640)
            
            //--TRIMMABLE-BOUNDARY-START(21475819640)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475819640)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(64425492600)
                this.Marker = null;
                //--TRIMMABLE-BOUNDARY-END(64425492600)
                
            }
            static $h = 983160;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375165560),
    {
      "p": 1114232,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130525304,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785230968,
        "f": 83886081
      },
      "n": "Type",
      "d": 983160,
      "h": 107375165560,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375165560),
//--TRIMMABLE-BOUNDARY-START(103080198264),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540590712,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195296376,
        "f": 83886081
      },
      "n": "SsrComponentId",
      "d": 983160,
      "h": 103080198264,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080198264),
//--TRIMMABLE-BOUNDARY-START(64425492600),
    {
      "p": $.$typeNullable($.$macwa.MAC.ComponentMarker).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950656120,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605361784,
        "f": 83886081
      },
      "n": "Marker",
      "d": 983160,
      "h": 64425492600,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425492600),
//--TRIMMABLE-BOUNDARY-START(25770786936),
    {
      "p": 4325496,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360721528,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015427192,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 983160,
      "h": 25770786936,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 8603959380
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770786936)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475819640),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983160,
      "h": 21475819640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819640)
  ],
  "h": 983160
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.RootComponentOperation`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}RootComponentOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983160)
        
        

        //--TRIMMABLE-BOUNDARY-START(4325496)
        $asm.$cls(`$macwa.MAC.WebRootComponentDescriptor`, ($self) => class WebRootComponentDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17184194680)
            /*Type*/ ComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(17184194680)
            
            //--TRIMMABLE-BOUNDARY-START(42953998456)
            /*WebRootComponentParameters*/ Parameters;
            //--TRIMMABLE-BOUNDARY-END(42953998456)
            
            //--TRIMMABLE-BOUNDARY-START(38659031160)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659031160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.S.String.Join$5(", ", $.$sl.SL.Enumerable.Select$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String, this.Parameters.Parameters.ToDictionary(), new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), $.$$.S.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return `${$.$strNN(p.Key)}: ${$.$strNN($.$dspc(p.Value, $.$$.S.Object, ($t) => $t.ToString))}`;
                }, $OupbDk ??= {"r":1310721,"p":[{"n":"p","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h}],"n":"","d":4325496,"h":0,"f":17825794})));
                return `${$.$strNN(this.ComponentType.FullName)}(${$.$strNN(parameters)})`;
            }
            //--TRIMMABLE-BOUNDARY-END(38659031160)
            
            //Begin primary constructor
            /*Type*/ componentType = null;
            /*WebRootComponentParameters*/ parameters = new $.$macwa.MAC.WebRootComponentParameters();
            $ctor$1(/*Type*/componentType, /*WebRootComponentParameters*/parameters)
            {
                this.componentType = componentType;
                this.parameters = parameters;
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(17184194680)
                //depends on primary constructor parameter
                this.ComponentType = this.componentType;
                //--TRIMMABLE-BOUNDARY-END(17184194680)
                
                //--TRIMMABLE-BOUNDARY-START(42953998456)
                //depends on primary constructor parameter
                this.Parameters = this.parameters;
                //--TRIMMABLE-BOUNDARY-END(42953998456)
                
                return this
            }
            //End primary constructor
            static $h = 4325496;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17184194680),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774129272,
        "f": 50331649
      },
      "n": "ComponentType",
      "d": 4325496,
      "h": 17184194680,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17184194680),
//--TRIMMABLE-BOUNDARY-START(42953998456),
    {
      "p": 4391032,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364063864,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 4325496,
      "h": 42953998456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953998456)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38659031160),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 4325496,
      "h": 38659031160,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38659031160)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889227384),
    {
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "parameters",
          "p": 4391032
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4325496,
      "h": 12889227384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889227384)
  ],
  "h": 4325496,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebRootComponentDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebRootComponentDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4325496)
        
        

        //--TRIMMABLE-BOUNDARY-START(3473528)
        $asm.$cls(`$macwa.MACWS.LazyAssemblyLoader`, ($self) => class LazyAssemblyLoader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(3539064)
            static $_LazyAssemblyLoaderInterop;
            static get LazyAssemblyLoaderInterop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3539064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWS.LazyAssemblyLoader;
                return $cls.$_LazyAssemblyLoaderInterop ??= $asm.$ncls(`$macwa.MACWS.LazyAssemblyLoader.LazyAssemblyLoaderInterop`, ($self) => class LazyAssemblyLoaderInterop extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8593473656)
                    static /*Task<bool> */ LoadLazyAssembly(/*string*/ assemblyToLoad)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8593473656);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let promise = $.$lazyLoad(assemblyToLoad);
                        /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$($.$$.S.Boolean))().$ctor$1();
                        promise.then( (/**/ asm) =>
                        {
                            tcs.SetResult(true);
                        }).catch( (/**/ e) =>
                        {
                            tcs.SetResult(false);
                        });
                        return tcs.Task;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593473656)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298506360)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4298506360);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298506360)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298506360)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298506360)
                    
                    static $h = 3539064;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593473656),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "assemblyToLoad",
          "p": 1310721
        }
      ],
      "n": "LoadLazyAssembly",
      "d": 3539064,
      "h": 8593473656,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 17181048843,
          "a": [
            {
              "v": "INTERNAL.loadLazyAssembly",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593473656)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298506360),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3539064,
      "h": 4298506360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298506360)
  ],
  "d": 3473528,
  "h": 3539064
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader+LazyAssemblyLoaderInterop`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}LazyAssemblyLoader${separator}LazyAssemblyLoaderInterop`; }
                }, $cls, ($v) => $cls.$_LazyAssemblyLoaderInterop = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3539064)
            
            //--TRIMMABLE-BOUNDARY-START(4298440824)
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298440824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298440824)
            
            //--TRIMMABLE-BOUNDARY-START(8593408120)
            /*Task<IEnumerable<Assembly>> */ LoadAssembliesAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593408120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.OperatingSystem.IsBrowser())
                {
                    return $.$macwa.MACWS.LazyAssemblyLoader.LoadAssembliesInClientAsync(assembliesToLoad);
                }
                return $.$macwa.MACWS.LazyAssemblyLoader.LoadAssembliesInServerAsync(assembliesToLoad);
            }
            //--TRIMMABLE-BOUNDARY-END(8593408120)
            
            //--TRIMMABLE-BOUNDARY-START(17183342712)
            static /*Task<IEnumerable<Assembly>> */ LoadAssembliesInServerAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183342712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let loadedAssemblies = new ($.$$.SCG.List$$($.$$.SR.Assembly))().$ctor$1();
                try
                {
                    let $en1 = assembliesToLoad.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let assemblyName = $en1.SCG$IEnumerator$$$Current;
                        {
                            loadedAssemblies.Add($.$$.SR.Assembly.Load$4($.$$.SI.Path.GetFileNameWithoutExtension$1(assemblyName)));
                        }
                    }
                }
                catch(ex)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Unable to find the following assembly: ${$.$strNN(ex.FileName)}. Make sure that the appplication is referencing the assemblies and that they are present in the output folder.`);
                }
                return $.$$.STT.Task.FromResult($.$$.SCG.IEnumerable$$($.$$.SR.Assembly), loadedAssemblies);
            }
            //--TRIMMABLE-BOUNDARY-END(17183342712)
            
            //--TRIMMABLE-BOUNDARY-START(12888375416)
            static /*Task<IEnumerable<Assembly>> *//*async*/  LoadAssembliesInClientAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)), $.$$.SCG.IEnumerable$$($.$$.SR.Assembly), async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888375416);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let newAssembliesToLoad = $.$sl.SL.Enumerable.ToList($.$$.S.String, assembliesToLoad);
                    /*var*/ let loadedAssemblies = new ($.$$.SCG.List$$($.$$.SR.Assembly))().$ctor$1();
                    /*var*/ let pendingLoads = $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$$.STT.Task$$($.$$.S.Boolean), newAssembliesToLoad, new ($.$$.S.Func$$$($.$$.S.String, $.$$.STT.Task$$($.$$.S.Boolean)))().$ctor($.$macwa.MACWS.LazyAssemblyLoader.LazyAssemblyLoaderInterop, $.$macwa.MACWS.LazyAssemblyLoader.LazyAssemblyLoaderInterop.LoadLazyAssembly));
                    /*var*/ let loadedStatus = ($t2 = $.$$.STT.Task.WhenAll$3($.$$.S.Boolean, pendingLoads), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    /*int*/ let i = 0;
                    /*List<Assembly>?*/ let allAssemblies = null;
                    let $i3 = 0;
                    let $arr3 = loadedStatus;
                    while ($i3 < $arr3.length)
                    {
                        let loaded = $arr3[$i3++];
                        if (loaded)
                        {
                            if (allAssemblies === null)
                            {
                                allAssemblies = $.$sl.SL.Enumerable.ToList($.$$.SR.Assembly, $.$$.SRL.AssemblyLoadContext.Default.Assemblies);
                            }
                            /*var*/ let assemblyName = $.$$.SI.Path.GetFileNameWithoutExtension$1(newAssembliesToLoad.get_Item(i));
                            /*var*/ let assembly = $.$sl.SL.Enumerable.FirstOrDefault$1($.$$.SR.Assembly, $.$$.SRL.AssemblyLoadContext.Default.Assemblies, new ($.$$.S.Func$$$($.$$.SR.Assembly, $.$$.S.Boolean))().$ctor(this,  (/*a*/ a) =>
                            {
                                return a.GetName().Name === assemblyName;
                            }, $DMQpJi ??= {"r":262145,"p":[{"n":"a","p":107020289}],"n":"","d":3473528,"h":0,"f":17825794}));
                            if ($.$$.SR.Assembly.op_Inequality(assembly, null))
                            {
                                loadedAssemblies.Add(assembly);
                            }
                        }
                        i++;
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, loadedAssemblies);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12888375416)
            
            static $h = 3473528;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593408120),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "LoadAssembliesAsync",
      "d": 3473528,
      "h": 8593408120,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593408120),
//--TRIMMABLE-BOUNDARY-START(17183342712),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "LoadAssembliesInServerAsync",
      "d": 3473528,
      "h": 17183342712,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17183342712),
//--TRIMMABLE-BOUNDARY-START(12888375416),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IEnumerable$$($.$$.SR.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "LoadAssembliesInClientAsync",
      "d": 3473528,
      "h": 12888375416,
      "f": 16781346,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12888375416)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440824),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3473528,
      "h": 4298440824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298440824)
  ],
  "h": 3473528
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MACWS.LazyAssemblyLoader.LazyAssemblyLoaderInterop ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}LazyAssemblyLoader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3473528)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310840)
        $asm.$cls(`$macwa.MAC.TransmitDataStreamToJS`, ($self) => class TransmitDataStreamToJS
        {
            //--TRIMMABLE-BOUNDARY-START(4296278136)
            static /*Task *//*async*/  TransmitStreamAsync(/*IJSRuntime*/ runtime, /*string*/ methodIdentifier, /*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let buffer = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(((32 * 1024) | 0));
                    try
                    {
                        let $t1, $r1;
                        let $t3, $r3;
                        /*int*/ let bytesRead;
                        while((bytesRead = ($t1 = dotNetStreamReference.Stream.ReadAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit$2(buffer), new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)))) > 0)
                        {
                            let $t2, $r2;
                            ($t2 = $.$mj.MJ.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(streamId, $.$$.S.Int64), buffer, $.$box(bytesRead, $.$$.S.Int32), null ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                        ($t3 = $.$mj.MJ.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(streamId, $.$$.S.Int64), $.$$.S.Array.Empty($.$$.S.Byte), $.$box(0, $.$$.S.Int32), null ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    catch(ex)
                    {
                        try
                        {
                            let $t4, $r4;
                            ($t4 = $.$mj.MJ.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(streamId, $.$$.S.Int64), $.$$.S.Array.Empty($.$$.S.Byte), $.$box(0, $.$$.S.Int32), ex.Message ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                        }
                        catch($e)
                        {
                        }
                        throw ex;
                    }
                    finally
                    {
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(buffer, true);
                            if (!dotNetStreamReference.LeaveOpen)
                            {
                                dotNetStreamReference.Stream?.Dispose();
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4296278136)
            
            static $h = 1310840;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296278136),
    {
      "r": 178454529,
      "p": [
        {
          "n": "runtime",
          "p": 524402
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262258
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 1310840,
      "h": 4296278136,
      "f": 16781352
    },
//--TRIMMABLE-BOUNDARY-END(4296278136)
  ],
  "h": 1310840
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.TransmitDataStreamToJS`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}TransmitDataStreamToJS`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310840)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097272)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHostBuilderExtensions`, ($self) => class WebAssemblyHostBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592031864)
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider$1(/*this WebAssemblyHostBuilder*/ builder, /*Action<ServiceProviderOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.MACWH.WebAssemblyHostBuilderExtensions.UseDefaultServiceProvider(builder, new ($.$$.S.Action$$$($.$macwa.MACWH.IWebAssemblyHostEnvironment, $.$med.MED.ServiceProviderOptions))().$ctor(this,  (/**/ env, /**/ options) =>
                {
                    return configure.Invoke(options);
                }, $dSWqJi ??= {"r":65537,"p":[{"n":"env","p":1441912},{"n":"options","p":3276893}],"n":"","d":2097272,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(8592031864)
            
            //--TRIMMABLE-BOUNDARY-START(4297064568)
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider(/*this WebAssemblyHostBuilder*/ builder, /*Action<IWebAssemblyHostEnvironment, ServiceProviderOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configure, "configure");
                /*var*/ let options = new $.$med.MED.ServiceProviderOptions().$ctor$1();
                configure.Invoke(builder.HostEnvironment, options);
                return builder.UseServiceProviderOptions(options);
            }
            //--TRIMMABLE-BOUNDARY-END(4297064568)
            
            static $h = 2097272;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592031864),
    {
      "r": 2031736,
      "p": [
        {
          "n": "builder",
          "p": 2031736
        },
        {
          "n": "configure",
          "p": $.$$.S.Action$$($.$med.MED.ServiceProviderOptions).$h
        }
      ],
      "n": "UseDefaultServiceProvider",
      "o": "@$1",
      "d": 2097272,
      "h": 8592031864,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592031864),
//--TRIMMABLE-BOUNDARY-START(4297064568),
    {
      "r": 2031736,
      "p": [
        {
          "n": "builder",
          "p": 2031736
        },
        {
          "n": "configure",
          "p": $.$$.S.Action$$$($.$macwa.MACWH.IWebAssemblyHostEnvironment, $.$med.MED.ServiceProviderOptions).$h
        }
      ],
      "n": "UseDefaultServiceProvider",
      "d": 2097272,
      "h": 4297064568,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297064568)
  ],
  "h": 2097272
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHostBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097272)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769592)
        $asm.$cls(`$macwa.MACWH.WebAssemblyCallQueue`, ($self) => class WebAssemblyCallQueue
        {
            //--TRIMMABLE-BOUNDARY-START(4296736888)
            /*bool*/ static _isCallInProgress = false;
            //--TRIMMABLE-BOUNDARY-END(4296736888)
            
            //--TRIMMABLE-BOUNDARY-START(8591704184)
            /*Queue<Action>*/ static _pendingWork = null;
            //--TRIMMABLE-BOUNDARY-END(8591704184)
            
            //--TRIMMABLE-BOUNDARY-START(38656475256)
            static /*bool */ get IsInProgress()
            {
                return $.$macwa.MACWH.WebAssemblyCallQueue._isCallInProgress;
            }
            //--TRIMMABLE-BOUNDARY-END(38656475256)
            
            //--TRIMMABLE-BOUNDARY-START(34361507960)
            static /*bool */ get HasUnstartedWork()
            {
                return $.$macwa.MACWH.WebAssemblyCallQueue._pendingWork.Count > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(34361507960)
            
            //--TRIMMABLE-BOUNDARY-START(42951442552)
            static /*void */ Schedule(T, /*T*/ state, /*Action<T>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951442552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.MACWH.WebAssemblyCallQueue._isCallInProgress)
                {
                    $.$macwa.MACWH.WebAssemblyCallQueue._pendingWork.Enqueue(new $.$$.S.Action().$ctor(this,  () =>
                    {
                        return callback.Invoke(state);
                    }, $lXhCPj ??= {"r":65537,"n":"","d":1769592,"h":0,"f":17825794}));
                }
                else 
                {
                    /*var*/ let nextWorkItem;
                    $.$macwa.MACWH.WebAssemblyCallQueue._isCallInProgress = true;
                    callback.Invoke(state);
                    while($.$macwa.MACWH.WebAssemblyCallQueue._pendingWork.TryDequeue($.$ref(() => nextWorkItem, ($v) => nextWorkItem = $v, $.$$.S.Action)))
                    {
                        nextWorkItem.Invoke();
                    }
                    $.$macwa.MACWH.WebAssemblyCallQueue._isCallInProgress = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951442552)
            
            //--TRIMMABLE-BOUNDARY-START(12886671480)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886671480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704184)
                    this._pendingWork = new ($.$$.SCG.Queue$$($.$$.S.Action))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8591704184)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886671480)
            
            static $h = 1769592;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656475256),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540664,
        "f": 50331681
      },
      "n": "IsInProgress",
      "d": 1769592,
      "h": 38656475256,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38656475256),
//--TRIMMABLE-BOUNDARY-START(34361507960),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476606072,
        "f": 50331681
      },
      "n": "HasUnstartedWork",
      "d": 1769592,
      "h": 34361507960,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34361507960)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951442552),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": (T) => T.$h
        },
        {
          "n": "callback",
          "p": (T) => $.$$.S.Action$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Schedule",
      "d": 1769592,
      "h": 42951442552,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42951442552)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736888),
    {
      "t": 262145,
      "n": "_isCallInProgress",
      "d": 1769592,
      "h": 4296736888,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296736888),
//--TRIMMABLE-BOUNDARY-START(8591704184),
    {
      "t": $.$$.SCG.Queue$$($.$$.S.Action).$h,
      "n": "_pendingWork",
      "d": 1769592,
      "h": 8591704184,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591704184)
  ],
  "h": 1769592
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyCallQueue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769592)
        
        

        //--TRIMMABLE-BOUNDARY-START(589944)
        $asm.$cls(`$macwa.MACH.HotReloadManager`, ($self) => class HotReloadManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770393720)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770393720)
            
            //--TRIMMABLE-BOUNDARY-START(51540197496)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540197496)
            
            //--TRIMMABLE-BOUNDARY-START(47245230200)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245230200)
            
            //--TRIMMABLE-BOUNDARY-START(55835164792)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835164792)
            
            //--TRIMMABLE-BOUNDARY-START(55835164792)
            //--TRIMMABLE-BOUNDARY-START(21475426424)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Combine$2(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426424)
            
            //--TRIMMABLE-BOUNDARY-START(64425099384)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeltaApplied = $.$$.S.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425099384)
            
            //--TRIMMABLE-BOUNDARY-END(55835164792)
            
            //--TRIMMABLE-BOUNDARY-START(81604968568)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604968568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$macwa.MACH.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604968568)
            
            //--TRIMMABLE-BOUNDARY-START(77310001272)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310001272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310001272)
            
            //--TRIMMABLE-BOUNDARY-START(12885491832)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491832)
            
            //--TRIMMABLE-BOUNDARY-START(12885491832)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885491832)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540197496)
                this.MetadataUpdateSupported = $.$$.SRM.MetadataUpdater.IsSupported;
                //--TRIMMABLE-BOUNDARY-END(51540197496)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8590524536)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770393720)
                    this.Default = new $.$macwa.MACH.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770393720)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590524536)
            
            static $h = 589944;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540197496),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015033976,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 589944,
      "h": 51540197496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540197496),
//--TRIMMABLE-BOUNDARY-START(47245230200),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328312,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 589944,
      "h": 47245230200,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230200)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604968568),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 589944,
      "h": 81604968568,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604968568),
//--TRIMMABLE-BOUNDARY-START(77310001272),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 589944,
      "h": 77310001272,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310001272)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770393720),
    {
      "t": 589944,
      "n": "Default",
      "d": 589944,
      "h": 25770393720,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393720)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491832),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589944,
      "h": 12885491832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491832)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835164792),
    {
      "e": 43122689,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 589944,
        "h": 21475426424,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 43122689
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 589944,
        "h": 64425099384,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 589944,
      "h": 55835164792,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835164792)
  ],
  "h": 589944
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.HotReload.HotReloadManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}HotReload${separator}HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589944)
        
        

        //--TRIMMABLE-BOUNDARY-START(327800)
        $asm.$cls(`$macwa.MAC.ComponentParametersTypeCache`, ($self) => class ComponentParametersTypeCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295096)
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            //--TRIMMABLE-BOUNDARY-END(4295295096)
            
            //--TRIMMABLE-BOUNDARY-START(12885229688)
            /*Type? */ GetParameterType(/*string*/ assembly, /*string*/ type)
            {
                /*var*/ let resolvedType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let key = new $.$macwa.MAC.ComponentParametersTypeCache.Key().$ctor$3(assembly, type);
                if (this._typeToKeyLookUp.TryGetValue($.$clone(key), $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$$.S.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$2($.$typeArray($.$$.SR.Assembly), $.$clone(key), new ($.$$.S.Func$$$$($.$macwa.MAC.ComponentParametersTypeCache.Key, $.$typeArray($.$$.SR.Assembly), $.$$.S.Type))().$ctor($.$macwa.MAC.ComponentParametersTypeCache, $.$macwa.MAC.ComponentParametersTypeCache.ResolveType), $.$$.S.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229688)
            
            //--TRIMMABLE-BOUNDARY-START(17180196984)
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$$.System.Array.$ReadT1.call(assemblies, i);
                    if (current.GetName().Name === key.Assembly)
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$$.SR.Assembly.op_Equality(assembly, null))
                {
                    if ($.$$.S.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$$.SR.Assembly.Load$4(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$1(key.Type, false, false) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196984)
            
            //--TRIMMABLE-BOUNDARY-START(393336)
            static $_Key;
            static get Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MAC.ComponentParametersTypeCache;
                return $cls.$_Key ??= $asm.$nstr(`$macwa.MAC.ComponentParametersTypeCache.Key`, ($self) => class Key extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262520)
                    $ctor$3(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180262520);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$tupleUnpack(($tp) =>
                            {
                                this.Assembly = $tp.Item1;
                                this.Type = $tp.Item2;
                            }).$v = { Item1: assembly, Item2: type };
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180262520)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475229816)
                    /*string*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(21475229816)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014837368)
                    /*string*/ Type = null;
                    //--TRIMMABLE-BOUNDARY-END(73014837368)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770197112)
                    /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770197112);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(obj, $.$macwa.MAC.ComponentParametersTypeCache.Key, { set $v($v){ key = $v; } }) && this.Equals$2($.$clone(key));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770197112)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065164408)
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065164408);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.S.String.Equals$3(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$$.S.String.Equals$3(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065164408)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540000888)
                    /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540000888);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.S.HashCode.Combine$6($.$$.S.String, $.$$.S.String, this.Assembly, this.Type);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540000888)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386127873)
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key)
                    S$IEquatable$Microsoft$AspNetCore$Components$ComponentParametersTypeCache$Key$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386127873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386127873)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885295224)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885295224);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885295224)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885295224)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885295224)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 393336;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229816),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655099000,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129935480,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 393336,
      "h": 21475229816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229816),
//--TRIMMABLE-BOUNDARY-START(73014837368),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245033592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719870072,
        "f": 83886081
      },
      "n": "Type",
      "d": 393336,
      "h": 73014837368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014837368)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770197112),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 393336,
      "h": 25770197112,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770197112),
//--TRIMMABLE-BOUNDARY-START(30065164408),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 393336
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 393336,
      "h": 30065164408,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164408),
//--TRIMMABLE-BOUNDARY-START(51540000888),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 393336,
      "h": 51540000888,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540000888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180262520),
    {
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393336,
      "h": 17180262520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262520),
//--TRIMMABLE-BOUNDARY-START(12885295224),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393336,
      "h": 12885295224,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295224)
  ],
  "d": 327800,
  "h": 393336
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$macwa.MAC.ComponentParametersTypeCache.Key) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentParametersTypeCache+Key`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentParametersTypeCache${separator}Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393336)
            
            //--TRIMMABLE-BOUNDARY-START(8590262392)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262392)
            
            //--TRIMMABLE-BOUNDARY-START(8590262392)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590262392)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295295096)
                this._typeToKeyLookUp = new ($.$scc.SCC.ConcurrentDictionary$$$($.$macwa.MAC.ComponentParametersTypeCache.Key, $.$$.S.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295295096)
                
            }
            static $h = 327800;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229688),
    {
      "r": 188547073,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "GetParameterType",
      "d": 327800,
      "h": 12885229688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229688),
//--TRIMMABLE-BOUNDARY-START(17180196984),
    {
      "r": 188547073,
      "p": [
        {
          "n": "key",
          "p": 393336
        },
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.SR.Assembly).$h
        }
      ],
      "n": "ResolveType",
      "d": 327800,
      "h": 17180196984,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180196984)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295096),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$macwa.MAC.ComponentParametersTypeCache.Key, $.$$.S.Type).$h,
      "n": "_typeToKeyLookUp",
      "d": 327800,
      "h": 4295295096,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295096)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262392),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327800,
      "h": 8590262392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262392)
  ],
  "h": 327800
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MAC.ComponentParametersTypeCache.Key ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentParametersTypeCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentParametersTypeCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327800)
        
        

        //--TRIMMABLE-BOUNDARY-START(2556024)
        $asm.$cls(`$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions`, ($self) => class WebAssemblyHttpRequestMessageExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592490616)
            /*HttpRequestOptionsKey<IDictionary<string, object>>*/ static FetchRequestOptionsKey;
            //--TRIMMABLE-BOUNDARY-END(8592490616)
            
            //--TRIMMABLE-BOUNDARY-START(42952228984)
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingRequestKey;
            //--TRIMMABLE-BOUNDARY-END(42952228984)
            
            //--TRIMMABLE-BOUNDARY-START(47247196280)
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingResponseKey;
            //--TRIMMABLE-BOUNDARY-END(47247196280)
            
            //--TRIMMABLE-BOUNDARY-START(17182425208)
            static /*HttpRequestMessage */ SetBrowserRequestCredentials(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCredentials*/ requestCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182425208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCredentials === 0/*BrowserRequestCredentials.Omit*/)
                    {
                        return "omit";
                    }
                    if (requestCredentials === 1/*BrowserRequestCredentials.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestCredentials === 2/*BrowserRequestCredentials.Include*/)
                    {
                        return "include";
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Unsupported enum value ${$.$strNN($.$$.S.Enum.ToStringT($.$macwa.MACWH$1.BrowserRequestCredentials, $.$$.S.UInt32, requestCredentials))}.`);
                })();
                return $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "credentials", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(17182425208)
            
            //--TRIMMABLE-BOUNDARY-START(12887457912)
            static /*HttpRequestMessage */ SetBrowserRequestCache(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCache*/ requestCache)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887457912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCache === 0/*BrowserRequestCache.Default*/)
                    {
                        return $.$default();
                    }
                    if (requestCache === 1/*BrowserRequestCache.NoStore*/)
                    {
                        return "no-store";
                    }
                    if (requestCache === 2/*BrowserRequestCache.Reload*/)
                    {
                        return "reload";
                    }
                    if (requestCache === 3/*BrowserRequestCache.NoCache*/)
                    {
                        return "no-cache";
                    }
                    if (requestCache === 4/*BrowserRequestCache.ForceCache*/)
                    {
                        return "force-cache";
                    }
                    if (requestCache === 5/*BrowserRequestCache.OnlyIfCached*/)
                    {
                        return "only-if-cached";
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Unsupported enum value ${$.$strNN($.$$.S.Enum.ToStringT($.$macwa.MACWH$1.BrowserRequestCache, $.$$.S.UInt32, requestCache))}.`);
                })();
                return $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "cache", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(12887457912)
            
            //--TRIMMABLE-BOUNDARY-START(25772359800)
            static /*HttpRequestMessage */ SetBrowserRequestMode(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestMode*/ requestMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772359800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestMode === 0/*BrowserRequestMode.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestMode === 1/*BrowserRequestMode.NoCors*/)
                    {
                        return "no-cors";
                    }
                    if (requestMode === 2/*BrowserRequestMode.Cors*/)
                    {
                        return "cors";
                    }
                    if (requestMode === 3/*BrowserRequestMode.Navigate*/)
                    {
                        return "navigate";
                    }
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`Unsupported enum value ${$.$strNN($.$$.S.Enum.ToStringT($.$macwa.MACWH$1.BrowserRequestMode, $.$$.S.UInt32, requestMode))}.`);
                })();
                return $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "mode", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(25772359800)
            
            //--TRIMMABLE-BOUNDARY-START(21477392504)
            static /*HttpRequestMessage */ SetBrowserRequestIntegrity(/*this HttpRequestMessage*/ requestMessage, /*string*/ integrity)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477392504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "integrity", integrity);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477392504)
            
            //--TRIMMABLE-BOUNDARY-START(30067327096)
            static /*HttpRequestMessage */ SetBrowserRequestOption(/*this HttpRequestMessage*/ requestMessage, /*string*/ name, /*object*/ value)
            {
                /*var*/ let entry;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067327096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*IDictionary<string, object>*/ let fetchOptions;
                if (requestMessage.Options.TryGetValue($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, $.$ref(() => entry, ($v) => entry = $v, $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object))))
                {
                    fetchOptions = entry;
                }
                else 
                {
                    fetchOptions = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$6($.$$.S.StringComparer.Ordinal);
                    requestMessage.Options.Set($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, fetchOptions);
                }
                fetchOptions.SCG$IDictionary$$$$set_Item(name, value);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(30067327096)
            
            //--TRIMMABLE-BOUNDARY-START(34362294392)
            static /*HttpRequestMessage */ SetBrowserRequestStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362294392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$$.S.Boolean, $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingRequestKey, streamingEnabled);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(34362294392)
            
            //--TRIMMABLE-BOUNDARY-START(38657261688)
            static /*HttpRequestMessage */ SetBrowserResponseStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657261688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$$.S.Boolean, $.$macwa.MACWH$1.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingResponseKey, streamingEnabled);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(38657261688)
            
            //--TRIMMABLE-BOUNDARY-START(4297523320)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297523320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8592490616)
                    this.FetchRequestOptionsKey = new ($.$snh.SNH.HttpRequestOptionsKey$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object)))().$ctor$3("WebAssemblyFetchOptions");
                    //--TRIMMABLE-BOUNDARY-END(8592490616)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952228984)
                    this.WebAssemblyEnableStreamingRequestKey = new ($.$snh.SNH.HttpRequestOptionsKey$$($.$$.S.Boolean))().$ctor$3("WebAssemblyEnableStreamingRequest");
                    //--TRIMMABLE-BOUNDARY-END(42952228984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47247196280)
                    this.WebAssemblyEnableStreamingResponseKey = new ($.$snh.SNH.HttpRequestOptionsKey$$($.$$.S.Boolean))().$ctor$3("WebAssemblyEnableStreamingResponse");
                    //--TRIMMABLE-BOUNDARY-END(47247196280)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297523320)
            
            static $h = 2556024;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182425208),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestCredentials",
          "p": 2424952
        }
      ],
      "n": "SetBrowserRequestCredentials",
      "d": 2556024,
      "h": 17182425208,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182425208),
//--TRIMMABLE-BOUNDARY-START(12887457912),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestCache",
          "p": 2359416
        }
      ],
      "n": "SetBrowserRequestCache",
      "d": 2556024,
      "h": 12887457912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887457912),
//--TRIMMABLE-BOUNDARY-START(25772359800),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestMode",
          "p": 2490488
        }
      ],
      "n": "SetBrowserRequestMode",
      "d": 2556024,
      "h": 25772359800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772359800),
//--TRIMMABLE-BOUNDARY-START(21477392504),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "integrity",
          "p": 1310721
        }
      ],
      "n": "SetBrowserRequestIntegrity",
      "d": 2556024,
      "h": 21477392504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477392504),
//--TRIMMABLE-BOUNDARY-START(30067327096),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetBrowserRequestOption",
      "d": 2556024,
      "h": 30067327096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067327096),
//--TRIMMABLE-BOUNDARY-START(34362294392),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "streamingEnabled",
          "p": 262145
        }
      ],
      "n": "SetBrowserRequestStreamingEnabled",
      "d": 2556024,
      "h": 34362294392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362294392),
//--TRIMMABLE-BOUNDARY-START(38657261688),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "streamingEnabled",
          "p": 262145
        }
      ],
      "n": "SetBrowserResponseStreamingEnabled",
      "d": 2556024,
      "h": 38657261688,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657261688)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592490616),
    {
      "t": $.$snh.SNH.HttpRequestOptionsKey$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object)).$h,
      "n": "FetchRequestOptionsKey",
      "d": 2556024,
      "h": 8592490616,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8592490616),
//--TRIMMABLE-BOUNDARY-START(42952228984),
    {
      "t": $.$snh.SNH.HttpRequestOptionsKey$$($.$$.S.Boolean).$h,
      "n": "WebAssemblyEnableStreamingRequestKey",
      "d": 2556024,
      "h": 42952228984,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42952228984),
//--TRIMMABLE-BOUNDARY-START(47247196280),
    {
      "t": $.$snh.SNH.HttpRequestOptionsKey$$($.$$.S.Boolean).$h,
      "n": "WebAssemblyEnableStreamingResponseKey",
      "d": 2556024,
      "h": 47247196280,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47247196280)
  ],
  "h": 2556024
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Http${separator}WebAssemblyHttpRequestMessageExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556024)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031736)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHostBuilder`, ($self) => class WebAssemblyHostBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591966328)
            /*IInternalJSImportMethods*/ _jsMethods = null;
            //--TRIMMABLE-BOUNDARY-END(8591966328)
            
            //--TRIMMABLE-BOUNDARY-START(4296999032)
            /*Func<IServiceProvider>*/ _createServiceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(4296999032)
            
            //--TRIMMABLE-BOUNDARY-START(17181900920)
            /*RootTypeCache?*/ _rootComponentCache = null;
            //--TRIMMABLE-BOUNDARY-END(17181900920)
            
            //--TRIMMABLE-BOUNDARY-START(12886933624)
            /*string?*/ _persistedState = null;
            //--TRIMMABLE-BOUNDARY-END(12886933624)
            
            //--TRIMMABLE-BOUNDARY-START(21476868216)
            /*ServiceProviderOptions?*/ _serviceProviderOptions = null;
            //--TRIMMABLE-BOUNDARY-END(21476868216)
            
            //--TRIMMABLE-BOUNDARY-START(64426541176)
            static /*WebAssemblyHostBuilder */ CreateDefault(/*string[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426541176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macwa.MACWH.WebAssemblyHostBuilder().$ctor$1($.$macwa.MACWS.InternalJSImportMethods.Instance);
                $.$macwa.MACWH.WebAssemblyCultureProvider.Initialize();
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(64426541176)
            
            //--TRIMMABLE-BOUNDARY-START(47246671992)
            $ctor$1(/*IInternalJSImportMethods*/ jsMethods)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246671992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsMethods = jsMethods;
                    this.Configuration = new $.$macwa.MACWH.WebAssemblyHostConfiguration().$ctor$1();
                    this.RootComponents = new $.$macwa.MACWH.RootComponentMappingCollection().$ctor$3();
                    this.Services = new $.$mxdi.MED.ServiceCollection().$ctor$1();
                    this.Logging = new $.$macwa.MACWH.LoggingBuilder().$ctor$1(this.Services);
                    /*var*/ let assembly = $.$$.SR.Assembly.GetEntryAssembly();
                    if ($.$$.SR.Assembly.op_Inequality(assembly, null))
                    {
                        $.$macwa.MACWH.WebAssemblyHostBuilder.InitializeRoutingAppContextSwitch(assembly);
                    }
                    $.$macwa.MACWH.WebAssemblyHostBuilder.InitializeWebAssemblyRenderer();
                    this.InitializeNavigationManager();
                    this.InitializeRegisteredRootComponents();
                    this.InitializePersistedState();
                    this.InitializeDefaultServices();
                    /*var*/ let hostEnvironment = this.InitializeEnvironment();
                    this.HostEnvironment = hostEnvironment;
                    this._createServiceProvider = new ($.$$.S.Func$$($.$scm.S.IServiceProvider))().$ctor(this,  () =>
                    {
                        /*var*/ let isDevelopment = $.$macwa.MACWH.WebAssemblyHostEnvironmentExtensions.IsDevelopment(hostEnvironment);
                        /*var*/ let options = this._serviceProviderOptions ?? (() =>
                        {
                            //new $.$med.MED.ServiceProviderOptions()
                            const $t1 = $.$med.MED.ServiceProviderOptions;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.ValidateScopes = isDevelopment;
                            $i1.ValidateOnBuild = isDevelopment;
                            return $i1;
                        })();
                        return $.$med.MED.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider(this.Services, options);
                    }, $tlkPqj ??= {"r":327718,"n":"","d":2031736,"h":0,"f":17825794});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246671992)
            
            //--TRIMMABLE-BOUNDARY-START(137440985208)
            static /*void */ InitializeRoutingAppContextSwitch(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440985208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assemblyMetadataAttributes = $.$$.SR.CustomAttributeExtensions.GetCustomAttributes$12($.$$.SR.AssemblyMetadataAttribute, assembly);
                let $en2 = assemblyMetadataAttributes.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let ama = $en2.SCG$IEnumerator$$$Current;
                    {
                        if ($.$$.S.String.Equals$3(ama.Key, "Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", 4/*StringComparison.Ordinal*/))
                        {
                            if (ama.Value !== null && $.$$.S.String.Equals$3(ama.Value, "true", 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                $.$$.S.AppContext.SetSwitch("Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", true);
                            }
                            return;
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440985208)
            
            //--TRIMMABLE-BOUNDARY-START(133146017912)
            /*void */ InitializeRegisteredRootComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146017912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let componentsCount = this._jsMethods.MACWS$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount();
                if (componentsCount === 0)
                {
                    return;
                }
                /*var*/ let registeredComponents = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$macwa.MAC.ComponentMarker), null, [componentsCount], null);
                for(/*var*/ let i = 0; i < componentsCount; i++)
                {
                    /*var*/ let assembly = this._jsMethods.MACWS$IInternalJSImportMethods$RegisteredComponents_GetAssembly(i);
                    /*var*/ let typeName = this._jsMethods.MACWS$IInternalJSImportMethods$RegisteredComponents_GetTypeName(i);
                    /*var*/ let serializedParameterDefinitions = this._jsMethods.MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions(i);
                    /*var*/ let serializedParameterValues = this._jsMethods.MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterValues(i);
                    $.$$.System.Array.$WriteT1.call(registeredComponents, $.$macwa.MAC.ComponentMarker.Create("webassembly"/*ComponentMarker.WebAssemblyMarkerType*/, false, null), i);
                    $.$$.System.Array.$ReadT1.call(registeredComponents, i).WriteWebAssemblyData(assembly, typeName, serializedParameterDefinitions, serializedParameterValues);
                    $.$$.System.Array.$ReadT1.call(registeredComponents, i).PrerenderId = $.$$.S.Int32.ToString$1.call(i, $.$$.SG.CultureInfo.InvariantCulture);
                }
                this._rootComponentCache = new $.$macwa.MAC.RootTypeCache().$ctor$1();
                /*var*/ let componentDeserializer = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.Instance;
                let $i3 = 0;
                let $arr3 = registeredComponents;
                while ($i3 < $arr3.length)
                {
                    let registeredComponent = $arr3[$i3++];
                    /*var*/ let componentType = this._rootComponentCache.GetRootType(registeredComponent.Assembly, registeredComponent.TypeName);
                    if (componentType === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$strNN(`Root component type '${$.$strNN(registeredComponent.TypeName)}' could not be found in the assembly '${$.$strNN(registeredComponent.Assembly)}'. `) + $.$strNN(`This is likely a result of trimming (tree shaking).`));
                    }
                    /*var*/ let definitions = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(registeredComponent.ParameterDefinitions);
                    /*var*/ let values = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.GetParameterValues(registeredComponent.ParameterValues);
                    /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                    this.RootComponents.Add$1(componentType, registeredComponent.PrerenderId, parameters);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146017912)
            
            //--TRIMMABLE-BOUNDARY-START(128851050616)
            /*void */ InitializePersistedState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851050616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._persistedState = this._jsMethods.MACWS$IInternalJSImportMethods$GetPersistedState();
            }
            //--TRIMMABLE-BOUNDARY-END(128851050616)
            
            //--TRIMMABLE-BOUNDARY-START(124556083320)
            /*void */ InitializeNavigationManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556083320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let baseUri = this._jsMethods.MACWS$IInternalJSImportMethods$NavigationManager_GetBaseUri();
                /*var*/ let uri = this._jsMethods.MACWS$IInternalJSImportMethods$NavigationManager_GetLocationHref();
                $.$macwa.MACWS.WebAssemblyNavigationManager.Instance = new $.$macwa.MACWS.WebAssemblyNavigationManager().$ctor$2(baseUri, uri);
            }
            //--TRIMMABLE-BOUNDARY-END(124556083320)
            
            //--TRIMMABLE-BOUNDARY-START(120261116024)
            /*WebAssemblyHostEnvironment */ InitializeEnvironment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261116024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let applicationEnvironment = this._jsMethods.MACWS$IInternalJSImportMethods$GetApplicationEnvironment();
                /*var*/ let hostEnvironment = new $.$macwa.MACWH.WebAssemblyHostEnvironment().$ctor$1(applicationEnvironment, $.$macwa.MACWS.WebAssemblyNavigationManager.Instance.BaseUri);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.MACWH.IWebAssemblyHostEnvironment, this.Services, hostEnvironment);
                /*var*/ let configFiles = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), ["appsettings.json", `appsettings.${$.$strNN(applicationEnvironment)}.json`], null, null);
                let $i4 = 0;
                let $arr4 = configFiles;
                while ($i4 < $arr4.length)
                {
                    let configFile = $arr4[$i4++];
                    if ($.$$.SI.File.Exists(configFile))
                    {
                        /*var*/ let appSettingsJson = $.$$.SI.File.ReadAllBytes(configFile);
                        $.$mecga.MEC.ConfigurationExtensions.Add($.$mecj.MECJ.JsonStreamConfigurationSource, this.Configuration, new ($.$$.S.Action$$($.$mecj.MECJ.JsonStreamConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Stream = new $.$$.SI.MemoryStream().$ctor$8(appSettingsJson);
                        }, $sDPgif ??= {"r":65537,"p":[{"n":"s","p":327777}],"n":"","d":2031736,"h":0,"f":17825794}));
                    }
                }
                return hostEnvironment;
            }
            //--TRIMMABLE-BOUNDARY-END(120261116024)
            
            //--TRIMMABLE-BOUNDARY-START(141735952504)
            static /*void */ InitializeWebAssemblyRenderer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735952504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.OperatingSystem.IsBrowser())
                {
                    /*var*/ let currentThread = $.$$.ST$1.Thread.CurrentThread;
                    if (currentThread.IsThreadPoolThread || currentThread.IsBackground)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("WebAssemblyHostBuilder needs to be instantiated in the UI thread.");
                    }
                    if ($.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext === null && $.$$.ST$1.SynchronizationContext.Current !== null)
                    {
                        $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext = $.$$.ST$1.SynchronizationContext.Current;
                        $.$macwa.MACWR.WebAssemblyDispatcher._mainManagedThreadId = currentThread.ManagedThreadId;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735952504)
            
            //--TRIMMABLE-BOUNDARY-START(55836606584)
            /*WebAssemblyHostConfiguration*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(55836606584)
            
            //--TRIMMABLE-BOUNDARY-START(150325887096)
            /*RootComponentMappingCollection*/ RootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(150325887096)
            
            //--TRIMMABLE-BOUNDARY-START(154620854392)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(154620854392)
            
            //--TRIMMABLE-BOUNDARY-START(111671181432)
            /*IWebAssemblyHostEnvironment*/ HostEnvironment = null;
            //--TRIMMABLE-BOUNDARY-END(111671181432)
            
            //--TRIMMABLE-BOUNDARY-START(146030919800)
            /*ILoggingBuilder*/ Logging = null;
            //--TRIMMABLE-BOUNDARY-END(146030919800)
            
            //--TRIMMABLE-BOUNDARY-START(60131573880)
            /*void */ ConfigureContainer(TBuilder, /*IServiceProviderFactory<TBuilder>*/ factory, /*Action<TBuilder>?*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131573880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                this._createServiceProvider = new ($.$$.S.Func$$($.$scm.S.IServiceProvider))().$ctor(this,  () =>
                {
                    /*var*/ let container = factory[`MED$IServiceProviderFactory$${TBuilder.$getFullName('$')}$CreateBuilder`](this.Services);
                    configure?.Invoke(container);
                    return factory[`MED$IServiceProviderFactory$${TBuilder.$getFullName('$')}$CreateServiceProvider`](container);
                }, $yowRNd ??= {"r":327718,"n":"","d":2031736,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(60131573880)
            
            //--TRIMMABLE-BOUNDARY-START(158915821688)
            /*WebAssemblyHostBuilder */ UseServiceProviderOptions(/*ServiceProviderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915821688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceProviderOptions = $.$firstOf(options, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("options") });
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(158915821688)
            
            //--TRIMMABLE-BOUNDARY-START(51541639288)
            /*WebAssemblyHost */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541639288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mecga.MEC.IConfiguration, this.Services, this.Configuration);
                /*var*/ let services = this._createServiceProvider.Invoke();
                /*var*/ let scope = $.$mxdi.MED.ServiceProviderServiceExtensions.CreateAsyncScope($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.MED.IServiceScopeFactory, services));
                return new $.$macwa.MACWH.WebAssemblyHost().$ctor$1(this, services, scope, this._persistedState);
            }
            //--TRIMMABLE-BOUNDARY-END(51541639288)
            
            //--TRIMMABLE-BOUNDARY-START(115966148728)
            /*void */ InitializeDefaultServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966148728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mj.MJ.IJSRuntime, this.Services, $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.MAC.NavigationManager, this.Services, $.$macwa.MACWS.WebAssemblyNavigationManager.Instance);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.MACR$3.INavigationInterception, this.Services, $.$macwa.MACWS.WebAssemblyNavigationInterception.Instance);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.MACR$3.IScrollToLocationHash, this.Services, $.$macwa.MACWS.WebAssemblyScrollToLocationHash.Instance);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.MACWS.IInternalJSImportMethods, this.Services, this._jsMethods);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.MACWS.LazyAssemblyLoader, this.Services, new $.$macwa.MACWS.LazyAssemblyLoader().$ctor$1($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$macwa.MAC.RootTypeCache, this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$macwa.MAC.RootTypeCache))().$ctor(this,  (/*_*/ _0) =>
                {
                    return this._rootComponentCache ?? new $.$macwa.MAC.RootTypeCache().$ctor$1();
                }, $FxhfUi ??= {"r":1179768,"p":[{"n":"_","p":327718}],"n":"","d":2031736,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$mac.MACI.ComponentStatePersistenceManager, this.Services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$6($.$mac.MAC.PersistentComponentState, this.Services, new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$mac.MAC.PersistentComponentState))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MACI.ComponentStatePersistenceManager, sp).State;
                }, $oUEAbb ??= {"r":6160499,"p":[{"n":"sp","p":327718}],"n":"","d":2031736,"h":0,"f":17825794}));
                $.$mac.MACI.PersistentStateProviderServiceCollectionExtensions.AddSupplyValueFromPersistentComponentStateProvider(this.Services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$macw.MACW.IErrorBoundaryLogger, $.$macwa.MACWS.WebAssemblyErrorBoundaryLogger, this.Services);
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$8($.$macwa.MAC.ResourceCollectionProvider, this.Services);
                $.$mac.MACI.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macwa.MAC.ResourceCollectionProvider, this.Services, $.$macw.MACW.RenderMode.InteractiveWebAssembly);
                $.$mexl.MED.LoggingServiceCollectionExtensions.AddLogging(this.Services, new ($.$$.S.Action$$($.$mexla.MEL.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                    $.$mexl.MEL.LoggingBuilderExtensions.AddProvider(builder, new $.$macwa.MACWS.WebAssemblyConsoleLoggerProvider().$ctor$1($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance));
                }, $yqKJkh ??= {"r":65537,"p":[{"n":"builder","p":1179736}],"n":"","d":2031736,"h":0,"f":17825794}));
                $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$5($.$macw.MACF.AntiforgeryStateProvider, $.$macwa.MACF.DefaultAntiforgeryStateProvider, this.Services);
                $.$mac.MACI.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macw.MACF.AntiforgeryStateProvider, this.Services, $.$macw.MACW.RenderMode.InteractiveWebAssembly);
                $.$mac.MAC.SupplyParameterFromQueryProviderServiceCollectionExtensions.AddSupplyValueFromQueryProvider(this.Services);
            }
            //--TRIMMABLE-BOUNDARY-END(115966148728)
            
            static $h = 2031736;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836606584),
    {
      "p": 2162808,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016475768,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 2031736,
      "h": 55836606584,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836606584),
//--TRIMMABLE-BOUNDARY-START(150325887096),
    {
      "p": 1704056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786279544,
        "f": 50331649
      },
      "n": "RootComponents",
      "d": 2031736,
      "h": 150325887096,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325887096),
//--TRIMMABLE-BOUNDARY-START(154620854392),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376214136,
        "f": 50331649
      },
      "n": "Services",
      "d": 2031736,
      "h": 154620854392,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620854392),
//--TRIMMABLE-BOUNDARY-START(111671181432),
    {
      "p": 1441912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606410360,
        "f": 50331649
      },
      "n": "HostEnvironment",
      "d": 2031736,
      "h": 111671181432,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671181432),
//--TRIMMABLE-BOUNDARY-START(146030919800),
    {
      "p": 1179736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196344952,
        "f": 50331649
      },
      "n": "Logging",
      "d": 2031736,
      "h": 146030919800,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030919800)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426541176),
    {
      "r": 2031736,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 65
        }
      ],
      "n": "CreateDefault",
      "d": 2031736,
      "h": 64426541176,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426541176),
//--TRIMMABLE-BOUNDARY-START(137440985208),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "InitializeRoutingAppContextSwitch",
      "d": 2031736,
      "h": 137440985208,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137440985208),
//--TRIMMABLE-BOUNDARY-START(133146017912),
    {
      "r": 65537,
      "n": "InitializeRegisteredRootComponents",
      "d": 2031736,
      "h": 133146017912,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146017912),
//--TRIMMABLE-BOUNDARY-START(128851050616),
    {
      "r": 65537,
      "n": "InitializePersistedState",
      "d": 2031736,
      "h": 128851050616,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851050616),
//--TRIMMABLE-BOUNDARY-START(124556083320),
    {
      "r": 65537,
      "n": "InitializeNavigationManager",
      "d": 2031736,
      "h": 124556083320,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124556083320),
//--TRIMMABLE-BOUNDARY-START(120261116024),
    {
      "r": 2228344,
      "n": "InitializeEnvironment",
      "d": 2031736,
      "h": 120261116024,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120261116024),
//--TRIMMABLE-BOUNDARY-START(141735952504),
    {
      "r": 65537,
      "n": "InitializeWebAssemblyRenderer",
      "d": 2031736,
      "h": 141735952504,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141735952504),
//--TRIMMABLE-BOUNDARY-START(60131573880),
    {
      "r": 65537,
      "p": [
        {
          "n": "factory",
          "p": (TBuilder) => $.$mxdi.MED.IServiceProviderFactory$$(TBuilder).$h
        },
        {
          "n": "configure",
          "p": (TBuilder) => $.$$.S.Action$$(TBuilder).$h,
          "f": 65
        }
      ],
      "g": [
        "TBuilder"
      ],
      "n": "ConfigureContainer",
      "d": 2031736,
      "h": 60131573880,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60131573880),
//--TRIMMABLE-BOUNDARY-START(158915821688),
    {
      "r": 2031736,
      "p": [
        {
          "n": "options",
          "p": 3276893
        }
      ],
      "n": "UseServiceProviderOptions",
      "d": 2031736,
      "h": 158915821688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915821688),
//--TRIMMABLE-BOUNDARY-START(51541639288),
    {
      "r": 1966200,
      "n": "Build",
      "d": 2031736,
      "h": 51541639288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541639288),
//--TRIMMABLE-BOUNDARY-START(115966148728),
    {
      "r": 65537,
      "n": "InitializeDefaultServices",
      "d": 2031736,
      "h": 115966148728,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115966148728)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591966328),
    {
      "t": 3342456,
      "n": "_jsMethods",
      "d": 2031736,
      "h": 8591966328,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966328),
//--TRIMMABLE-BOUNDARY-START(4296999032),
    {
      "t": $.$$.S.Func$$($.$scm.S.IServiceProvider).$h,
      "n": "_createServiceProvider",
      "d": 2031736,
      "h": 4296999032,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296999032),
//--TRIMMABLE-BOUNDARY-START(17181900920),
    {
      "t": 1179768,
      "n": "_rootComponentCache",
      "d": 2031736,
      "h": 17181900920,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181900920),
//--TRIMMABLE-BOUNDARY-START(12886933624),
    {
      "t": 1310721,
      "n": "_persistedState",
      "d": 2031736,
      "h": 12886933624,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933624),
//--TRIMMABLE-BOUNDARY-START(21476868216),
    {
      "t": 3276893,
      "n": "_serviceProviderOptions",
      "d": 2031736,
      "h": 21476868216,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476868216)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47246671992),
    {
      "p": [
        {
          "n": "jsMethods",
          "p": 3342456
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031736,
      "h": 47246671992,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47246671992)
  ],
  "h": 2031736
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHostBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031736)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507448)
        $asm.$cls(`$macwa.MACWH.LoggingBuilder`, ($self) => class LoggingBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591442040)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591442040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442040)
            
            //--TRIMMABLE-BOUNDARY-START(21476343928)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(21476343928)
            
            //--TRIMMABLE-BOUNDARY-START(8591114328)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get MEL$ILoggingBuilder$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114328)
            
            static $h = 1507448;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476343928),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181376632,
        "f": 50331649
      },
      "n": "Services",
      "d": 1507448,
      "h": 21476343928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476343928)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442040),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507448,
      "h": 8591442040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591442040)
  ],
  "h": 1507448
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILoggingBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.LoggingBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}LoggingBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507448)
        
        

        //--TRIMMABLE-BOUNDARY-START(2228344)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHostEnvironment`, ($self) => class WebAssemblyHostEnvironment extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887130232)
            $ctor$1(/*string*/ environment, /*string*/ baseAddress)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887130232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Environment = environment;
                    this.BaseAddress = baseAddress;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887130232)
            
            //--TRIMMABLE-BOUNDARY-START(21477064824)
            /*string*/ Environment = null;
            //--TRIMMABLE-BOUNDARY-END(21477064824)
            
            //--TRIMMABLE-BOUNDARY-START(17182097528)
            /*string*/ BaseAddress = null;
            //--TRIMMABLE-BOUNDARY-END(17182097528)
            
            //--TRIMMABLE-BOUNDARY-START(25771245688)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.Environment.get
            get MACWH$IWebAssemblyHostEnvironment$Environment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591376504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Environment;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245688)
            
            //--TRIMMABLE-BOUNDARY-START(17181311096)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.BaseAddress.get
            get MACWH$IWebAssemblyHostEnvironment$BaseAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BaseAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311096)
            
            static $h = 2228344;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477064824),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656934008,
        "f": 50331649
      },
      "n": "Environment",
      "d": 2228344,
      "h": 21477064824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477064824),
//--TRIMMABLE-BOUNDARY-START(17182097528),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066999416,
        "f": 50331649
      },
      "n": "BaseAddress",
      "d": 2228344,
      "h": 17182097528,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182097528)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887130232),
    {
      "p": [
        {
          "n": "environment",
          "p": 1310721
        },
        {
          "n": "baseAddress",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228344,
      "h": 12887130232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887130232)
  ],
  "h": 2228344
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.MACWH.IWebAssemblyHostEnvironment ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironment`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHostEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228344)
        
        

        //--TRIMMABLE-BOUNDARY-START(3407992)
        $asm.$cls(`$macwa.MACWS.InternalJSImportMethods`, ($self) => class InternalJSImportMethods extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34363146360)
            static /*string */ GetApplicationEnvironmentCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363146360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let env = window.localStorage.getItem("__environment__");
                if (!(env === null))
                {
                    return env;
                }
                if (window.location.hostname === "localhost")
                {
                    return "Development";
                }
                return "Production";
            }
            //--TRIMMABLE-BOUNDARY-END(34363146360)
            
            //--TRIMMABLE-BOUNDARY-START(55837982840)
            /*InternalJSImportMethods*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(55837982840)
            
            //--TRIMMABLE-BOUNDARY-START(8593342584)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593342584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593342584)
            
            //--TRIMMABLE-BOUNDARY-START(47248048248)
            /*string */ GetPersistedState()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47248048248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.getPersistedState();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248048248)
            
            //--TRIMMABLE-BOUNDARY-START(38658113656)
            static /*Task<RootComponentOperationBatch> *//*async*/  GetInitialComponentUpdate()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$macwa.MAC.RootComponentOperationBatch), $.$macwa.MAC.RootComponentOperationBatch, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658113656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let components = ($t1 = Blazor._internal.getInitialComponentsUpdate(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.DeserializeOperations(components));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38658113656)
            
            //--TRIMMABLE-BOUNDARY-START(30068179064)
            /*string */ GetApplicationEnvironment()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068179064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.MACWS.InternalJSImportMethods.GetApplicationEnvironmentCore();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068179064)
            
            //--TRIMMABLE-BOUNDARY-START(12888309880)
            /*void */ AttachRootComponentToElement(/*string*/ domElementSelector, /*int*/ componentId, /*int*/ rendererId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888309880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.attachRootComponentToElement(domElementSelector, componentId, rendererId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888309880)
            
            //--TRIMMABLE-BOUNDARY-START(21478244472)
            /*void */ EndUpdateRootComponents(/*long*/ batchId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478244472);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.endUpdateRootComponents(batchId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478244472)
            
            //--TRIMMABLE-BOUNDARY-START(60132950136)
            /*void */ NavigationManager_EnableNavigationInterception(/*int*/ rendererId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132950136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.enableNavigationInterception(rendererId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132950136)
            
            //--TRIMMABLE-BOUNDARY-START(85902753912)
            /*void */ NavigationManager_ScrollToElement(/*string*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85902753912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.scrollToElement(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902753912)
            
            //--TRIMMABLE-BOUNDARY-START(77312819320)
            /*string */ NavigationManager_GetLocationHref()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77312819320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.getLocationHref();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77312819320)
            
            //--TRIMMABLE-BOUNDARY-START(68722884728)
            /*string */ NavigationManager_GetBaseUri()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722884728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.getBaseURI();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722884728)
            
            //--TRIMMABLE-BOUNDARY-START(94492688504)
            /*void */ NavigationManager_SetHasLocationChangingListeners(/*int*/ rendererId, /*bool*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94492688504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.setHasLocationChangingListeners(rendererId, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94492688504)
            
            //--TRIMMABLE-BOUNDARY-START(128852426872)
            /*int */ RegisteredComponents_GetRegisteredComponentsCount()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128852426872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128852426872)
            
            //--TRIMMABLE-BOUNDARY-START(103082623096)
            /*string */ RegisteredComponents_GetAssembly(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082623096);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getAssembly(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103082623096)
            
            //--TRIMMABLE-BOUNDARY-START(137442361464)
            /*string */ RegisteredComponents_GetTypeName(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137442361464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getTypeName(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137442361464)
            
            //--TRIMMABLE-BOUNDARY-START(111672557688)
            /*string */ RegisteredComponents_GetParameterDefinitions(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672557688);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getParameterDefinitions(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111672557688)
            
            //--TRIMMABLE-BOUNDARY-START(120262492280)
            /*string */ RegisteredComponents_GetParameterValues(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120262492280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getParameterValues(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262492280)
            
            //--TRIMMABLE-BOUNDARY-START(17183211640)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetPersistedState()
            MACWS$IInternalJSImportMethods$GetPersistedState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183211640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPersistedState(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17183211640)
            
            //--TRIMMABLE-BOUNDARY-START(12888244344)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetApplicationEnvironment()
            MACWS$IInternalJSImportMethods$GetApplicationEnvironment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888244344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetApplicationEnvironment(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12888244344)
            
            //--TRIMMABLE-BOUNDARY-START(4298309752)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.AttachRootComponentToElement(string, int, int)
            MACWS$IInternalJSImportMethods$AttachRootComponentToElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298309752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AttachRootComponentToElement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298309752)
            
            //--TRIMMABLE-BOUNDARY-START(8593277048)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.EndUpdateRootComponents(long)
            MACWS$IInternalJSImportMethods$EndUpdateRootComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593277048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EndUpdateRootComponents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593277048)
            
            //--TRIMMABLE-BOUNDARY-START(21478178936)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_EnableNavigationInterception(int)
            MACWS$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478178936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_EnableNavigationInterception(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478178936)
            
            //--TRIMMABLE-BOUNDARY-START(34363080824)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_ScrollToElement(string)
            MACWS$IInternalJSImportMethods$NavigationManager_ScrollToElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363080824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_ScrollToElement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34363080824)
            
            //--TRIMMABLE-BOUNDARY-START(30068113528)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetLocationHref()
            MACWS$IInternalJSImportMethods$NavigationManager_GetLocationHref()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068113528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_GetLocationHref(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30068113528)
            
            //--TRIMMABLE-BOUNDARY-START(25773146232)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetBaseUri()
            MACWS$IInternalJSImportMethods$NavigationManager_GetBaseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773146232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_GetBaseUri(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25773146232)
            
            //--TRIMMABLE-BOUNDARY-START(38658048120)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_SetHasLocationChangingListeners(int, bool)
            MACWS$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658048120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_SetHasLocationChangingListeners(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38658048120)
            
            //--TRIMMABLE-BOUNDARY-START(55837917304)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetRegisteredComponentsCount()
            MACWS$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837917304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetRegisteredComponentsCount(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55837917304)
            
            //--TRIMMABLE-BOUNDARY-START(42953015416)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetAssembly(int)
            MACWS$IInternalJSImportMethods$RegisteredComponents_GetAssembly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953015416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetAssembly(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42953015416)
            
            //--TRIMMABLE-BOUNDARY-START(60132884600)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetTypeName(int)
            MACWS$IInternalJSImportMethods$RegisteredComponents_GetTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132884600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetTypeName(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60132884600)
            
            //--TRIMMABLE-BOUNDARY-START(47247982712)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterDefinitions(int)
            MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247982712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetParameterDefinitions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47247982712)
            
            //--TRIMMABLE-BOUNDARY-START(51542950008)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterValues(int)
            MACWS$IInternalJSImportMethods$RegisteredComponents_GetParameterValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542950008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetParameterValues(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51542950008)
            
            //--TRIMMABLE-BOUNDARY-START(8593342584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593342584)
            
            //--TRIMMABLE-BOUNDARY-START(4298375288)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298375288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55837982840)
                    this.Instance = new $.$macwa.MACWS.InternalJSImportMethods().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(55837982840)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298375288)
            
            static $h = 3407992;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248048248),
    {
      "r": 1310721,
      "n": "GetPersistedState",
      "d": 3407992,
      "h": 47248048248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47248048248),
//--TRIMMABLE-BOUNDARY-START(38658113656),
    {
      "r": $.$$.STT.Task$$($.$macwa.MAC.RootComponentOperationBatch).$h,
      "n": "GetInitialComponentUpdate",
      "d": 3407992,
      "h": 38658113656,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38658113656),
//--TRIMMABLE-BOUNDARY-START(30068179064),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironment",
      "d": 3407992,
      "h": 30068179064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068179064),
//--TRIMMABLE-BOUNDARY-START(12888309880),
    {
      "r": 65537,
      "p": [
        {
          "n": "domElementSelector",
          "p": 1310721
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "AttachRootComponentToElement",
      "d": 3407992,
      "h": 12888309880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888309880),
//--TRIMMABLE-BOUNDARY-START(21478244472),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "EndUpdateRootComponents",
      "d": 3407992,
      "h": 21478244472,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478244472),
//--TRIMMABLE-BOUNDARY-START(60132950136),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "NavigationManager_EnableNavigationInterception",
      "d": 3407992,
      "h": 60132950136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132950136),
//--TRIMMABLE-BOUNDARY-START(85902753912),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "NavigationManager_ScrollToElement",
      "d": 3407992,
      "h": 85902753912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902753912),
//--TRIMMABLE-BOUNDARY-START(77312819320),
    {
      "r": 1310721,
      "n": "NavigationManager_GetLocationHref",
      "d": 3407992,
      "h": 77312819320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77312819320),
//--TRIMMABLE-BOUNDARY-START(68722884728),
    {
      "r": 1310721,
      "n": "NavigationManager_GetBaseUri",
      "d": 3407992,
      "h": 68722884728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722884728),
//--TRIMMABLE-BOUNDARY-START(94492688504),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "NavigationManager_SetHasLocationChangingListeners",
      "d": 3407992,
      "h": 94492688504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492688504),
//--TRIMMABLE-BOUNDARY-START(128852426872),
    {
      "r": 655361,
      "n": "RegisteredComponents_GetRegisteredComponentsCount",
      "d": 3407992,
      "h": 128852426872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128852426872),
//--TRIMMABLE-BOUNDARY-START(103082623096),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetAssembly",
      "d": 3407992,
      "h": 103082623096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103082623096),
//--TRIMMABLE-BOUNDARY-START(137442361464),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetTypeName",
      "d": 3407992,
      "h": 137442361464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137442361464),
//--TRIMMABLE-BOUNDARY-START(111672557688),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterDefinitions",
      "d": 3407992,
      "h": 111672557688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111672557688),
//--TRIMMABLE-BOUNDARY-START(120262492280),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterValues",
      "d": 3407992,
      "h": 120262492280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120262492280),
//--TRIMMABLE-BOUNDARY-START(34363146360),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironmentCore",
      "d": 3407992,
      "h": 34363146360,
      "f": 16777250,
      "a": [
        {
          "t": 1179659,
          "c": 12886081547,
          "a": [
            {
              "v": "Blazor._internal.getApplicationEnvironment",
              "t": 1310721
            },
            {
              "v": "blazor-internal",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363146360)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55837982840),
    {
      "t": 3407992,
      "n": "Instance",
      "d": 3407992,
      "h": 55837982840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55837982840)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593342584),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3407992,
      "h": 8593342584,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8593342584)
  ],
  "h": 3407992
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.MACWS.IInternalJSImportMethods ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}InternalJSImportMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407992)
        
        

        //--TRIMMABLE-BOUNDARY-START(3866744)
        $asm.$cls(`$macwa.MACWS.WebAssemblyNavigationInterception`, ($self) => class WebAssemblyNavigationInterception extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183735928)
            /*WebAssemblyNavigationInterception*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17183735928)
            
            //--TRIMMABLE-BOUNDARY-START(12888768632)
            /*Task */ EnableNavigationInterceptionAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888768632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.MACWS.InternalJSImportMethods.Instance.NavigationManager_EnableNavigationInterception(2/*WebRendererId.WebAssembly*/);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888768632)
            
            //--TRIMMABLE-BOUNDARY-START(4305322099)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.INavigationInterception.EnableNavigationInterceptionAsync()
            MACR$3$INavigationInterception$EnableNavigationInterceptionAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4305322099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EnableNavigationInterceptionAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4305322099)
            
            //--TRIMMABLE-BOUNDARY-START(8593801336)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593801336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593801336)
            
            //--TRIMMABLE-BOUNDARY-START(8593801336)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593801336)
            
            //--TRIMMABLE-BOUNDARY-START(4298834040)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298834040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17183735928)
                    this.Instance = new $.$macwa.MACWS.WebAssemblyNavigationInterception().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17183735928)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298834040)
            
            static $h = 3866744;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888768632),
    {
      "r": 178454529,
      "n": "EnableNavigationInterceptionAsync",
      "d": 3866744,
      "h": 12888768632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888768632)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183735928),
    {
      "t": 3866744,
      "n": "Instance",
      "d": 3866744,
      "h": 17183735928,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183735928)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593801336),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3866744,
      "h": 8593801336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593801336)
  ],
  "h": 3866744
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MACR$3.INavigationInterception ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyNavigationInterception`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3866744)
        
        

        //--TRIMMABLE-BOUNDARY-START(3801208)
        $asm.$cls(`$macwa.MACWS.WebAssemblyErrorBoundaryLogger`, ($self) => class WebAssemblyErrorBoundaryLogger extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298768504)
            /*ILogger<ErrorBoundary>*/ _errorBoundaryLogger = null;
            //--TRIMMABLE-BOUNDARY-END(4298768504)
            
            //--TRIMMABLE-BOUNDARY-START(8593735800)
            $ctor$1(/*ILogger<ErrorBoundary>*/ errorBoundaryLogger)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593735800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._errorBoundaryLogger = $.$firstOf(errorBoundaryLogger, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("errorBoundaryLogger") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593735800)
            
            //--TRIMMABLE-BOUNDARY-START(12888703096)
            /*ValueTask */ LogErrorAsync(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888703096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.MEL.LoggerExtensions.LogError$2(this._errorBoundaryLogger, exception, exception.ToString(), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                return $.$$.STT.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888703096)
            
            //--TRIMMABLE-BOUNDARY-START(4300734581)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger.LogErrorAsync(System.Exception)
            MACW$IErrorBoundaryLogger$LogErrorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300734581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LogErrorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4300734581)
            
            static $h = 3801208;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888703096),
    {
      "r": 181338113,
      "p": [
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "LogErrorAsync",
      "d": 3801208,
      "h": 12888703096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888703096)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298768504),
    {
      "t": $.$mexla.MEL.ILogger$$($.$macw.MACW.ErrorBoundary).$h,
      "n": "_errorBoundaryLogger",
      "d": 3801208,
      "h": 4298768504,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298768504)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593735800),
    {
      "p": [
        {
          "n": "errorBoundaryLogger",
          "p": $.$mexla.MEL.ILogger$$($.$macw.MACW.ErrorBoundary).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3801208,
      "h": 8593735800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593735800)
  ],
  "h": 3801208
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macw.MACW.IErrorBoundaryLogger ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyErrorBoundaryLogger`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyErrorBoundaryLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3801208)
        
        

        //--TRIMMABLE-BOUNDARY-START(721016)
        $asm.$cls(`$macwa.MAC.PrerenderComponentApplicationStore`, ($self) => class PrerenderComponentApplicationStore extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688312)
            /*bool*/ _stateIsPersisted = false;
            //--TRIMMABLE-BOUNDARY-END(4295688312)
            
            //--TRIMMABLE-BOUNDARY-START(17180590200)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180590200);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ExistingState = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590200)
            
            //--TRIMMABLE-BOUNDARY-START(21475557496)
            $ctor$2(/*string*/ existingState)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(existingState, "existingState");
                    this.DeserializeState($.$$.S.Convert.FromBase64String(existingState));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557496)
            
            //--TRIMMABLE-BOUNDARY-START(25770524792)
            /*void */ DeserializeState(/*byte[]*/ existingState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state = $.$firstOf($.$stj.STJ.JsonSerializer.Deserialize$29($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)), $.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(existingState), $.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.Default.DictionaryStringByteArray), () => { throw new $.$$.S.ArgumentException().$ctor$13("Could not deserialize state correctly", "existingState") });
                this.ExistingState = state;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524792)
            
            //--TRIMMABLE-BOUNDARY-START(55835295864)
            /*string?*/ PersistedState = null;
            //--TRIMMABLE-BOUNDARY-END(55835295864)
            
            //--TRIMMABLE-BOUNDARY-START(30065492088)
            /*Dictionary<string, byte[]>*/ ExistingState = null;
            //--TRIMMABLE-BOUNDARY-END(30065492088)
            
            //--TRIMMABLE-BOUNDARY-START(51540328568)
            /*Task<IDictionary<string, byte[]>> */ GetPersistedStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromResult($.$$.SCG.IDictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)), this.ExistingState);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328568)
            
            //--TRIMMABLE-BOUNDARY-START(64425230456)
            /*byte[] */ SerializeState(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230456);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stj.STJ.JsonSerializer.SerializeToUtf8Bytes$3($.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)), state, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230456)
            
            //--TRIMMABLE-BOUNDARY-START(60130263160)
            /*Task */ PersistStateAsync(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._stateIsPersisted)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("State already persisted.");
                }
                this._stateIsPersisted = true;
                if (!(state === null) && state.SCG$IReadOnlyCollection$$$Count > 0)
                {
                    this.PersistedState = $.$$.S.Convert.ToBase64String$3(this.SerializeState(state));
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263160)
            
            //--TRIMMABLE-BOUNDARY-START(85900066936)
            /*bool */ SupportsRenderMode(/*IComponentRenderMode*/ renderMode)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900066936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return renderMode === null || $.$is(renderMode, $.$macw.MACW.InteractiveWebAssemblyRenderMode) || $.$is(renderMode, $.$macw.MACW.InteractiveAutoRenderMode);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900066936)
            
            //--TRIMMABLE-BOUNDARY-START(4299358323)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.GetPersistedStateAsync()
            MAC$IPersistentComponentStateStore$GetPersistedStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299358323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPersistedStateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4299358323)
            
            //--TRIMMABLE-BOUNDARY-START(8594325619)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.PersistStateAsync(System.Collections.Generic.IReadOnlyDictionary<string, byte[]>)
            MAC$IPersistentComponentStateStore$PersistStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594325619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PersistStateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8594325619)
            
            //--TRIMMABLE-BOUNDARY-START(12889292915)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.SupportsRenderMode(Microsoft.AspNetCore.Components.IComponentRenderMode)
            MAC$IPersistentComponentStateStore$SupportsRenderMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889292915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SupportsRenderMode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12889292915)
            
            //--TRIMMABLE-BOUNDARY-START(17180590200)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180590200)
            
            static $h = 721016;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835295864),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605099640,
        "f": 83886082
      },
      "n": "PersistedState",
      "d": 721016,
      "h": 55835295864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835295864),
//--TRIMMABLE-BOUNDARY-START(30065492088),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015165048,
        "f": 83886084
      },
      "n": "ExistingState",
      "d": 721016,
      "h": 30065492088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065492088)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770524792),
    {
      "r": 65537,
      "p": [
        {
          "n": "existingState",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "DeserializeState",
      "d": 721016,
      "h": 25770524792,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770524792),
//--TRIMMABLE-BOUNDARY-START(51540328568),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.IDictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))).$h,
      "n": "GetPersistedStateAsync",
      "d": 721016,
      "h": 51540328568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328568),
//--TRIMMABLE-BOUNDARY-START(64425230456),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "state",
          "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h
        }
      ],
      "n": "SerializeState",
      "d": 721016,
      "h": 64425230456,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64425230456),
//--TRIMMABLE-BOUNDARY-START(60130263160),
    {
      "r": 178454529,
      "p": [
        {
          "n": "state",
          "p": $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h
        }
      ],
      "n": "PersistStateAsync",
      "d": 721016,
      "h": 60130263160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263160),
//--TRIMMABLE-BOUNDARY-START(85900066936),
    {
      "r": 262145,
      "p": [
        {
          "n": "renderMode",
          "p": 2883699
        }
      ],
      "n": "SupportsRenderMode",
      "d": 721016,
      "h": 85900066936,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900066936)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688312),
    {
      "t": 262145,
      "n": "_stateIsPersisted",
      "d": 721016,
      "h": 4295688312,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180590200),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721016,
      "h": 17180590200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590200),
//--TRIMMABLE-BOUNDARY-START(21475557496),
    {
      "p": [
        {
          "n": "existingState",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721016,
      "h": 21475557496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557496)
  ],
  "h": 721016
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MAC.IPersistentComponentStateStore ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}PrerenderComponentApplicationStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721016)
        
        

        //--TRIMMABLE-BOUNDARY-START(4063352)
        $asm.$cls(`$macwa.MACWS.WebAssemblyScrollToLocationHash`, ($self) => class WebAssemblyScrollToLocationHash extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888965240)
            /*WebAssemblyScrollToLocationHash*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12888965240)
            
            //--TRIMMABLE-BOUNDARY-START(17183932536)
            /*Task */ RefreshScrollPositionForHash(/*string*/ locationAbsolute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183932536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hashIndex = $.$$.S.String.IndexOf$8.call(locationAbsolute, "#", 4/*StringComparison.Ordinal*/);
                if (hashIndex > -1 && locationAbsolute.length > ((hashIndex + 1) | 0))
                {
                    let $t1 = locationAbsolute;
                    /*var*/ let elementId = $.$$.S.String.Substring.call($t1, (((hashIndex + 1) | 0)), $t1.length - (((hashIndex + 1) | 0)));
                    $.$macwa.MACWS.InternalJSImportMethods.Instance.NavigationManager_ScrollToElement(elementId);
                }
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17183932536)
            
            //--TRIMMABLE-BOUNDARY-START(4305453171)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash.RefreshScrollPositionForHash(string)
            MACR$3$IScrollToLocationHash$RefreshScrollPositionForHash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4305453171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RefreshScrollPositionForHash(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4305453171)
            
            //--TRIMMABLE-BOUNDARY-START(8593997944)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593997944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593997944)
            
            //--TRIMMABLE-BOUNDARY-START(8593997944)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8593997944)
            
            //--TRIMMABLE-BOUNDARY-START(4299030648)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299030648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888965240)
                    this.Instance = new $.$macwa.MACWS.WebAssemblyScrollToLocationHash().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12888965240)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299030648)
            
            static $h = 4063352;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183932536),
    {
      "r": 178454529,
      "p": [
        {
          "n": "locationAbsolute",
          "p": 1310721
        }
      ],
      "n": "RefreshScrollPositionForHash",
      "d": 4063352,
      "h": 17183932536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183932536)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888965240),
    {
      "t": 4063352,
      "n": "Instance",
      "d": 4063352,
      "h": 12888965240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888965240)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593997944),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4063352,
      "h": 8593997944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593997944)
  ],
  "h": 4063352
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.MACR$3.IScrollToLocationHash ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyScrollToLocationHash`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4063352)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179768)
        $asm.$cls(`$macwa.MAC.RootTypeCache`, ($self) => class RootTypeCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296147064)
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            //--TRIMMABLE-BOUNDARY-END(4296147064)
            
            //--TRIMMABLE-BOUNDARY-START(8591114360)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$macwa.MACH.HotReloadManager.Default.MetadataUpdateSupported)
                    {
                        $.$macwa.MACH.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.S.Action().$ctor(this, this.ClearCache));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114360)
            
            //--TRIMMABLE-BOUNDARY-START(12886081656)
            /*void */ ClearCache()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._typeToKeyLookUp.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886081656)
            
            //--TRIMMABLE-BOUNDARY-START(17181048952)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.MACH.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macwa.MACH.HotReloadManager.Default.remove_OnDeltaApplied(new $.$$.S.Action().$ctor(this, this.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181048952)
            
            //--TRIMMABLE-BOUNDARY-START(21476016248)
            /*Type? */ GetRootType(/*string*/ assembly, /*string*/ type)
            {
                /*var*/ let resolvedType;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let key = new $.$macwa.MAC.RootTypeCache.Key().$ctor$3(assembly, type);
                if (this._typeToKeyLookUp.TryGetValue(key, $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$$.S.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$2($.$typeArray($.$$.SR.Assembly), key, new ($.$$.S.Func$$$$($.$macwa.MAC.RootTypeCache.Key, $.$typeArray($.$$.SR.Assembly), $.$$.S.Type))().$ctor($.$macwa.MAC.RootTypeCache, $.$macwa.MAC.RootTypeCache.ResolveType), $.$$.S.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476016248)
            
            //--TRIMMABLE-BOUNDARY-START(25770983544)
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$$.System.Array.$ReadT1.call(assemblies, i);
                    if (current.GetName().Name === key.Assembly)
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$$.SR.Assembly.op_Equality(assembly, null))
                {
                    if ($.$$.S.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$$.SR.Assembly.Load$4(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$1(key.Type, false, false) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983544)
            
            //--TRIMMABLE-BOUNDARY-START(1245304)
            static $_Key;
            static get Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1245304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MAC.RootTypeCache;
                return $cls.$_Key ??= $asm.$nstr(`$macwa.MAC.RootTypeCache.Key`, ($self) => class Key extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17181114488)
                    $ctor$3(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181114488);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$tupleUnpack(($tp) =>
                            {
                                this.Assembly = $tp.Item1;
                                this.Type = $tp.Item2;
                            }).$v = { Item1: assembly, Item2: type };
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181114488)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081784)
                    /*string*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(21476081784)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835820152)
                    /*string*/ Type = null;
                    //--TRIMMABLE-BOUNDARY-END(55835820152)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771049080)
                    /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771049080);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(obj, $.$macwa.MAC.RootTypeCache.Key, { set $v($v){ key = $v; } }) && this.Equals$2(key);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771049080)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066016376)
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066016376);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.S.String.Equals$3(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$$.S.String.Equals$3(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066016376)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540852856)
                    /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540852856);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.S.HashCode.Combine$6($.$$.S.String, $.$$.S.String, this.Assembly, this.Type);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540852856)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386127873)
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.RootTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.RootTypeCache.Key)
                    S$IEquatable$Microsoft$AspNetCore$Components$RootTypeCache$Key$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386127873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386127873)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886147192)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886147192);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886147192)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886147192)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886147192)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 1245304;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081784),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950968,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 1245304,
      "h": 21476081784,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476081784),
//--TRIMMABLE-BOUNDARY-START(55835820152),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245885560,
        "f": 50331649
      },
      "n": "Type",
      "d": 1245304,
      "h": 55835820152,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835820152)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771049080),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1245304,
      "h": 25771049080,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771049080),
//--TRIMMABLE-BOUNDARY-START(30066016376),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1245304
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1245304,
      "h": 30066016376,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066016376),
//--TRIMMABLE-BOUNDARY-START(51540852856),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1245304,
      "h": 51540852856,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540852856)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181114488),
    {
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245304,
      "h": 17181114488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114488),
//--TRIMMABLE-BOUNDARY-START(12886147192),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245304,
      "h": 12886147192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147192)
  ],
  "d": 1179768,
  "h": 1245304
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$macwa.MAC.RootTypeCache.Key) ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.RootTypeCache+Key`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}RootTypeCache${separator}Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245304)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(8591114360)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591114360)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296147064)
                this._typeToKeyLookUp = new ($.$scc.SCC.ConcurrentDictionary$$$($.$macwa.MAC.RootTypeCache.Key, $.$$.S.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296147064)
                
            }
            static $h = 1179768;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886081656),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 1179768,
      "h": 12886081656,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886081656),
//--TRIMMABLE-BOUNDARY-START(17181048952),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179768,
      "h": 17181048952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048952),
//--TRIMMABLE-BOUNDARY-START(21476016248),
    {
      "r": 188547073,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "GetRootType",
      "d": 1179768,
      "h": 21476016248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016248),
//--TRIMMABLE-BOUNDARY-START(25770983544),
    {
      "r": 188547073,
      "p": [
        {
          "n": "key",
          "p": 1245304
        },
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.SR.Assembly).$h
        }
      ],
      "n": "ResolveType",
      "d": 1179768,
      "h": 25770983544,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770983544)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147064),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$macwa.MAC.RootTypeCache.Key, $.$$.S.Type).$h,
      "n": "_typeToKeyLookUp",
      "d": 1179768,
      "h": 4296147064,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147064)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114360),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179768,
      "h": 8591114360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114360)
  ],
  "h": 1179768
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MAC.RootTypeCache.Key ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.RootTypeCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}RootTypeCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179768)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966200)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHost`, ($self) => class WebAssemblyHost extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771769976)
            /*AsyncServiceScope*/ _scope;
            //--TRIMMABLE-BOUNDARY-END(25771769976)
            
            //--TRIMMABLE-BOUNDARY-START(30066737272)
            /*IServiceProvider*/ _services = null;
            //--TRIMMABLE-BOUNDARY-END(30066737272)
            
            //--TRIMMABLE-BOUNDARY-START(4296933496)
            /*IConfiguration*/ _configuration = null;
            //--TRIMMABLE-BOUNDARY-END(4296933496)
            
            //--TRIMMABLE-BOUNDARY-START(21476802680)
            /*RootComponentMappingCollection*/ _rootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(21476802680)
            
            //--TRIMMABLE-BOUNDARY-START(12886868088)
            /*string?*/ _persistedState = null;
            //--TRIMMABLE-BOUNDARY-END(12886868088)
            
            //--TRIMMABLE-BOUNDARY-START(8591900792)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8591900792)
            
            //--TRIMMABLE-BOUNDARY-START(34361704568)
            /*bool*/ _started = false;
            //--TRIMMABLE-BOUNDARY-END(34361704568)
            
            //--TRIMMABLE-BOUNDARY-START(17181835384)
            /*WebAssemblyRenderer?*/ _renderer = null;
            //--TRIMMABLE-BOUNDARY-END(17181835384)
            
            //--TRIMMABLE-BOUNDARY-START(38656671864)
            $ctor$1(/*WebAssemblyHostBuilder*/ builder, /*IServiceProvider*/ services, /*AsyncServiceScope*/ scope, /*string?*/ persistedState)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656671864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.GC.KeepAlive($.$macwa.MACWI.JSInteropMethods.$type);
                    this._services = services;
                    this._scope = scope;
                    this._configuration = builder.Configuration;
                    this._rootComponents = builder.RootComponents;
                    this._persistedState = persistedState;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656671864)
            
            //--TRIMMABLE-BOUNDARY-START(47246606456)
            /*IConfiguration */ get Configuration()
            {
                return this._configuration;
            }
            //--TRIMMABLE-BOUNDARY-END(47246606456)
            
            //--TRIMMABLE-BOUNDARY-START(81606344824)
            /*IServiceProvider */ get Services()
            {
                return this._scope.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(81606344824)
            
            //--TRIMMABLE-BOUNDARY-START(51541573752)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541573752);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._disposed)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    this._disposed = true;
                    if (this._renderer !== null)
                    {
                        let $t1, $r1;
                        ($t1 = this._renderer.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    ($t2 = this._scope.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    let asyncDisposableServices;
                    let disposableServices;
                    if ($.$is(this._services, $.$$.S.IAsyncDisposable, { set $v($v){ asyncDisposableServices = $v; } }))
                    {
                        let $t3, $r3;
                        ($t3 = asyncDisposableServices.S$IAsyncDisposable$DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                    else if ($.$is(this._services, $.$$.S.IDisposable, { set $v($v){ disposableServices = $v; } }))
                    {
                        disposableServices.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541573752)
            
            //--TRIMMABLE-BOUNDARY-START(73016410232)
            /*Task */ RunAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016410232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunAsyncCore($.$$.ST$1.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(73016410232)
            
            //--TRIMMABLE-BOUNDARY-START(77311377528)
            /*Task *//*async*/  RunAsyncCore(/*CancellationToken*/ cancellationToken, /*WebAssemblyCultureProvider?*/ cultureProvider)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t4, $r4;
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311377528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._started)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("The host has already started.");
                    }
                    this._started = true;
                    cultureProvider ??= $.$macwa.MACWH.WebAssemblyCultureProvider.Instance;
                    cultureProvider.ThrowIfCultureChangeIsUnsupported();
                    ($t4 = cultureProvider.LoadCurrentCultureResourcesAsync(), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    /*var*/ let manager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MACI.ComponentStatePersistenceManager, this.Services);
                    /*var*/ let store = !$.$$.S.String.IsNullOrEmpty(this._persistedState) ? new $.$macwa.MAC.PrerenderComponentApplicationStore().$ctor$2(this._persistedState) : new $.$macwa.MAC.PrerenderComponentApplicationStore().$ctor$1();
                    manager.SetPlatformRenderMode($.$macw.MACW.RenderMode.InteractiveWebAssembly);
                    ($t5 = manager.RestoreStateAsync(store, $.$mac.MAC.RestoreContext.InitialValue), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    /*var*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                    let $disposable6 = null;
                    try
                    {
                        let $t7, $r7;
                        let $t11, $r11;
                        let $t12, $r12;
                        $disposable6 = cancellationToken.Register$1(new $.$$.S.Action().$ctor(this,  () =>
                        {
                            return tcs.TrySetResult();
                        }, $rbvwof ??= {"r":65537,"n":"","d":1966200,"h":0,"f":17825794}));
                        /*var*/ let loggerFactory = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mexla.MEL.ILoggerFactory, this.Services);
                        /*var*/ let jsComponentInterop = new $.$macw.MACWI.JSComponentInterop().$ctor$1(this._rootComponents.JSComponents);
                        /*var*/ let collectionProvider = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.MAC.ResourceCollectionProvider, this.Services);
                        /*var*/ let collection = ($t7 = collectionProvider.GetResourceCollection(), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                        this._renderer = new $.$macwa.MACWR.WebAssemblyRenderer().$ctor$4(this.Services, collection, loggerFactory, jsComponentInterop);
                        $.$macwa.MACWS.WebAssemblyNavigationManager.Instance.CreateLogger(loggerFactory);
                        /*RootComponentOperationBatch?*/ let initialOperationBatch = null;
                        if ($.$$.S.Environment.GetEnvironmentVariable$1("__BLAZOR_WEBASSEMBLY_WAIT_FOR_ROOT_COMPONENTS") === "true")
                        {
                            let $t8, $r8;
                            initialOperationBatch = ($t8 = $.$macwa.MACWS.InternalJSImportMethods.GetInitialComponentUpdate(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        }
                        /*var*/ let initializationTcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                        $.$macwa.MACWH.WebAssemblyCallQueue.Schedule($.$$.S.ValueTuple$$$$($.$macwa.MACWH.RootComponentMappingCollection, $.$macwa.MACWR.WebAssemblyRenderer, $.$$.STT.TaskCompletionSource), new ($.$$.S.ValueTuple$$$$($.$macwa.MACWH.RootComponentMappingCollection, $.$macwa.MACWR.WebAssemblyRenderer, $.$$.STT.TaskCompletionSource))().$ctor$3(this._rootComponents, this._renderer, initializationTcs), new ($.$$.S.Action$$($.$$.S.ValueTuple$$$$($.$macwa.MACWH.RootComponentMappingCollection, $.$macwa.MACWR.WebAssemblyRenderer, $.$$.STT.TaskCompletionSource)))().$ctor(this, /*async*/  (/*state*/ state) =>
                        {
                            return $.$$.N.AsyncResolver.Async($.$$.S.Void, $.$$.S.Void, async ($asnycContext) => 
                            {
                                /*var*/ let  [ rootComponents, renderer, initializationTcs ] = $.$destructure(state, 3);
                                try
                                {
                                    let $t10, $r10;
                                    /*var*/ let count = rootComponents.Count;
                                    const $t9 = initialOperationBatch;
                                    /*var*/ let initialOperationCount = $.$ifnn($t9, ($t) => $t.Operations.length) ?? 0;
                                    /*var*/ let pendingRenders = new ($.$$.SCG.List$$($.$$.STT.Task))().$ctor$3(((count + initialOperationCount) | 0));
                                    for(/*var*/ let i = 0; i < count; i++)
                                    {
                                        /*var*/ let rootComponent = rootComponents.get_Item(i);
                                        pendingRenders.Add(renderer.AddComponentAsync(rootComponent.ComponentType, rootComponent.Parameters, rootComponent.Selector));
                                    }
                                    if (!(initialOperationBatch === null))
                                    {
                                        $.$macwa.MACWH.WebAssemblyHost.AddWebRootComponents(renderer, initialOperationBatch, pendingRenders);
                                    }
                                    ($t10 = $.$$.STT.Task.WhenAll(pendingRenders), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                                    initializationTcs.SetResult();
                                }
                                catch(ex)
                                {
                                    initializationTcs.SetException$1(ex);
                                }
                            });
                        }, $plQTag ??= {"r":65537,"p":[{"n":"state","p":$.$$.S.ValueTuple$$$$($.$macwa.MACWH.RootComponentMappingCollection, $.$macwa.MACWR.WebAssemblyRenderer, $.$$.STT.TaskCompletionSource).$h}],"n":"","d":1966200,"h":0,"f":17829890}));
                        ($t11 = initializationTcs.Task, ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        store.ExistingState.Clear();
                        ($t12 = tcs.Task, ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                    }
                    finally
                    {
                        $disposable6?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311377528)
            
            //--TRIMMABLE-BOUNDARY-START(42951639160)
            static /*void */ AddWebRootComponents(/*WebAssemblyRenderer*/ renderer, /*RootComponentOperationBatch*/ operationBatch, /*List<Task>*/ pendingRenders)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951639160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let webRootComponentManager = renderer.GetOrCreateWebRootComponentManager();
                /*var*/ let operations = operationBatch.Operations;
                for(/*var*/ let i = 0; i < operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(operations, i);
                    if (operation.Type !== 0/*RootComponentOperationType.Add*/)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("All initial operations must be additions.");
                    }
                    pendingRenders.Add(webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters));
                }
                renderer.NotifyEndUpdateRootComponents(operationBatch.BatchId);
            }
            //--TRIMMABLE-BOUNDARY-END(42951639160)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771769976)
                this._scope = $.$default($.$mxdi.MED.AsyncServiceScope);
                //--TRIMMABLE-BOUNDARY-END(25771769976)
                
            }
            static $h = 1966200;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246606456),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131508344,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 1966200,
      "h": 47246606456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246606456),
//--TRIMMABLE-BOUNDARY-START(81606344824),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721442936,
        "f": 50331649
      },
      "n": "Services",
      "d": 1966200,
      "h": 81606344824,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606344824)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541573752),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 1966200,
      "h": 51541573752,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51541573752),
//--TRIMMABLE-BOUNDARY-START(73016410232),
    {
      "r": 178454529,
      "n": "RunAsync",
      "d": 1966200,
      "h": 73016410232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016410232),
//--TRIMMABLE-BOUNDARY-START(77311377528),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "cultureProvider",
          "p": 1835128,
          "f": 65
        }
      ],
      "n": "RunAsyncCore",
      "d": 1966200,
      "h": 77311377528,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(77311377528),
//--TRIMMABLE-BOUNDARY-START(42951639160),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        },
        {
          "n": "operationBatch",
          "p": 1048696
        },
        {
          "n": "pendingRenders",
          "p": $.$$.SCG.List$$($.$$.STT.Task).$h
        }
      ],
      "n": "AddWebRootComponents",
      "d": 1966200,
      "h": 42951639160,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951639160)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771769976),
    {
      "t": 524378,
      "n": "_scope",
      "d": 1966200,
      "h": 25771769976,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771769976),
//--TRIMMABLE-BOUNDARY-START(30066737272),
    {
      "t": 327718,
      "n": "_services",
      "d": 1966200,
      "h": 30066737272,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066737272),
//--TRIMMABLE-BOUNDARY-START(4296933496),
    {
      "t": 393310,
      "n": "_configuration",
      "d": 1966200,
      "h": 4296933496,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933496),
//--TRIMMABLE-BOUNDARY-START(21476802680),
    {
      "t": 1704056,
      "n": "_rootComponents",
      "d": 1966200,
      "h": 21476802680,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802680),
//--TRIMMABLE-BOUNDARY-START(12886868088),
    {
      "t": 1310721,
      "n": "_persistedState",
      "d": 1966200,
      "h": 12886868088,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886868088),
//--TRIMMABLE-BOUNDARY-START(8591900792),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1966200,
      "h": 8591900792,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900792),
//--TRIMMABLE-BOUNDARY-START(34361704568),
    {
      "t": 262145,
      "n": "_started",
      "d": 1966200,
      "h": 34361704568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361704568),
//--TRIMMABLE-BOUNDARY-START(17181835384),
    {
      "t": 2949240,
      "n": "_renderer",
      "d": 1966200,
      "h": 17181835384,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835384)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656671864),
    {
      "p": [
        {
          "n": "builder",
          "p": 2031736
        },
        {
          "n": "services",
          "p": 327718
        },
        {
          "n": "scope",
          "p": 524378
        },
        {
          "n": "persistedState",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966200,
      "h": 38656671864,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38656671864)
  ],
  "h": 1966200
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966200)
        
        

        //--TRIMMABLE-BOUNDARY-START(3604600)
        $asm.$cls(`$macwa.MACWS.WebAssemblyConsoleLogger<>`, (T) => $asm.$gt(`$macwa.MACWS.WebAssemblyConsoleLogger<>`, [T], ($self) => class WebAssemblyConsoleLogger$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888506488)
            /*string*/ static _loglevelPadding = null;
            //--TRIMMABLE-BOUNDARY-END(12888506488)
            
            //--TRIMMABLE-BOUNDARY-START(17183473784)
            /*string*/ static _messagePadding = null;
            //--TRIMMABLE-BOUNDARY-END(17183473784)
            
            //--TRIMMABLE-BOUNDARY-START(25773408376)
            /*string*/ static _newLineWithMessagePadding = null;
            //--TRIMMABLE-BOUNDARY-END(25773408376)
            
            //--TRIMMABLE-BOUNDARY-START(8593539192)
            /*StringBuilder*/ static _logBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(8593539192)
            
            //--TRIMMABLE-BOUNDARY-START(21478441080)
            /*string*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(21478441080)
            
            //--TRIMMABLE-BOUNDARY-START(4298571896)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4298571896)
            
            //--TRIMMABLE-BOUNDARY-START(34363342968)
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                this.$ctor$2($.$$.S.String.Empty, $.$cast(jsRuntime, $.$mjw.MJW.WebAssemblyJSRuntime));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363342968);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34363342968)
            
            //--TRIMMABLE-BOUNDARY-START(38658310264)
            $ctor$2(/*string*/ name, /*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658310264);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._name = $.$firstOf(name, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("name") });
                    this._jsRuntime = $.$firstOf(jsRuntime, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("jsRuntime") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38658310264)
            
            //--TRIMMABLE-BOUNDARY-START(42953277560)
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953277560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).NoOpDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(42953277560)
            
            //--TRIMMABLE-BOUNDARY-START(55838179448)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838179448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return logLevel !== 6/*LogLevel.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55838179448)
            
            //--TRIMMABLE-BOUNDARY-START(60133146744)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133146744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsEnabled(logLevel))
                {
                    return;
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(formatter, "formatter");
                /*var*/ let message = formatter.Invoke(state, exception);
                if (!$.$$.S.String.IsNullOrEmpty(message) || exception !== null)
                {
                    this.WriteMessage(logLevel, this._name, eventId.Id, message, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60133146744)
            
            //--TRIMMABLE-BOUNDARY-START(64428114040)
            /*void */ WriteMessage(/*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428114040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_logBuilder)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._logBuilder)
                    {
                        try
                        {
                            $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).CreateDefaultLogMessage($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._logBuilder, logLevel, logName, eventId, message, exception);
                            /*var*/ let formattedMessage = $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._logBuilder.ToString();
                            switch(logLevel)
                            {
                                case 0/*LogLevel.Trace*/:
                                case 1/*LogLevel.Debug*/:
                                globalThis.console.debug(formattedMessage);
                                break;
                                case 2/*LogLevel.Information*/:
                                globalThis.console.info(formattedMessage);
                                break;
                                case 3/*LogLevel.Warning*/:
                                globalThis.console.warn(formattedMessage);
                                break;
                                case 4/*LogLevel.Error*/:
                                globalThis.console.error(formattedMessage);
                                break;
                                case 5/*LogLevel.Critical*/:
                                Blazor._internal.dotNetCriticalError(formattedMessage);
                                break;
                                default:
                                $.$$.SD.Debug.Assert$4(logLevel !== 6/*LogLevel.None*/, "This method is never called with LogLevel.None.");
                                $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid(this._jsRuntime, "console.log", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ formattedMessage ], null, null));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._logBuilder.Clear();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._logBuilder)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64428114040)
            
            //--TRIMMABLE-BOUNDARY-START(47248244856)
            static /*void */ CreateDefaultLogMessage(/*StringBuilder*/ logBuilder, /*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248244856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                logBuilder.Append$21($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).GetLogLevelString(logLevel));
                logBuilder.Append$21(": "/*_loglevelPadding*/);
                logBuilder.Append$21(logName);
                logBuilder.Append$5(/*[*/ 91);
                logBuilder.Append$13(eventId);
                logBuilder.Append$5(/*]*/ 93);
                if (!$.$$.S.String.IsNullOrEmpty(message))
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$21($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._messagePadding);
                    /*var*/ let len = logBuilder.Length;
                    logBuilder.Append$21(message);
                    logBuilder.Replace$4($.$$.S.Environment.NewLine, $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._newLineWithMessagePadding, len, message.length);
                }
                if (exception !== null)
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$21(exception.ToString());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248244856)
            
            //--TRIMMABLE-BOUNDARY-START(51543212152)
            static /*string */ GetLogLevelString(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543212152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(logLevel)
                {
                    case 0/*LogLevel.Trace*/:
                    return "trce";
                    case 1/*LogLevel.Debug*/:
                    return "dbug";
                    case 2/*LogLevel.Information*/:
                    return "info";
                    case 3/*LogLevel.Warning*/:
                    return "warn";
                    case 4/*LogLevel.Error*/:
                    return "fail";
                    case 5/*LogLevel.Critical*/:
                    return "crit";
                    default:
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("logLevel");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51543212152)
            
            //--TRIMMABLE-BOUNDARY-START(3670136)
            static $_NoOpDisposable;
            static get NoOpDisposable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3670136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T);
                return $cls.$_NoOpDisposable ??= $asm.$ncls(`$macwa.MACWS.WebAssemblyConsoleLogger<${T?.$fullName}>.NoOpDisposable`, ($self) => class NoOpDisposable extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17183539320)
                    /*NoOpDisposable*/ static Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(17183539320)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888572024)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12888572024);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888572024)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593604728)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8593604728);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593604728)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593604728)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593604728)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298637432)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4298637432);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(17183539320)
                            this.Instance = new ($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).NoOpDisposable)().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(17183539320)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298637432)
                    
                    static $H = 3670136;
                    static $h = 3670136;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888572024),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3670136,
      "H": 12888572024,
      "h": Number(BigInt(3670136)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888572024)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183539320),
    {
      "t": 3670136,
      "n": "Instance",
      "d": 3670136,
      "H": 17183539320,
      "h": Number(BigInt(3670136)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183539320)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593604728),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3670136,
      "H": 8593604728,
      "h": Number(BigInt(3670136)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593604728)
  ],
  "d": 3604600,
  "H": 3670136,
  "h": 3670136
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<${T?.$fullName}>+NoOpDisposable`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyConsoleLogger$${T?.$getFullName(separator)}$${separator}NoOpDisposable`; }
                }, $cls, ($v) => $cls.$_NoOpDisposable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3670136)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            MEL$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            MEL$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            MEL$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            //--TRIMMABLE-BOUNDARY-START(30068375672)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068375672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12888506488)
                    this._loglevelPadding = ": ";
                    //--TRIMMABLE-BOUNDARY-END(12888506488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17183473784)
                    this._messagePadding = $.$$.S.String.Create(/* */ 32, (($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).GetLogLevelString(2/*LogLevel.Information*/).length + ": "/*_loglevelPadding*/.length) | 0));
                    //--TRIMMABLE-BOUNDARY-END(17183473784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25773408376)
                    this._newLineWithMessagePadding = $.$strNN($.$$.S.Environment.NewLine) + $.$strNN($.$macwa.MACWS.WebAssemblyConsoleLogger$$(T)._messagePadding);
                    //--TRIMMABLE-BOUNDARY-END(25773408376)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8593539192)
                    this._logBuilder = new $.$$.ST.StringBuilder().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8593539192)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068375672)
            
            static $H = 3604600;
            static $h = 3604600;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42953277560),
    {
      "r": 91095041,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": this.$h,
      "H": 42953277560,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(42953277560),
//--TRIMMABLE-BOUNDARY-START(55838179448),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": this.$h,
      "H": 55838179448,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55838179448),
//--TRIMMABLE-BOUNDARY-START(60133146744),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 80805889
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.S.Func$$$$(TState, $.$$.S.Exception, $.$$.S.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": this.$h,
      "H": 60133146744,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60133146744),
//--TRIMMABLE-BOUNDARY-START(64428114040),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "logName",
          "p": 1310721
        },
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "WriteMessage",
      "d": this.$h,
      "H": 64428114040,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64428114040),
//--TRIMMABLE-BOUNDARY-START(47248244856),
    {
      "r": 65537,
      "p": [
        {
          "n": "logBuilder",
          "p": 167837697
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "logName",
          "p": 1310721
        },
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "CreateDefaultLogMessage",
      "d": this.$h,
      "H": 47248244856,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47248244856),
//--TRIMMABLE-BOUNDARY-START(51543212152),
    {
      "r": 1310721,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "GetLogLevelString",
      "d": this.$h,
      "H": 51543212152,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51543212152)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888506488),
    {
      "t": 1310721,
      "n": "_loglevelPadding",
      "d": this.$h,
      "H": 12888506488,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888506488),
//--TRIMMABLE-BOUNDARY-START(17183473784),
    {
      "t": 1310721,
      "n": "_messagePadding",
      "d": this.$h,
      "H": 17183473784,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17183473784),
//--TRIMMABLE-BOUNDARY-START(25773408376),
    {
      "t": 1310721,
      "n": "_newLineWithMessagePadding",
      "d": this.$h,
      "H": 25773408376,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25773408376),
//--TRIMMABLE-BOUNDARY-START(8593539192),
    {
      "t": 167837697,
      "n": "_logBuilder",
      "d": this.$h,
      "H": 8593539192,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8593539192),
//--TRIMMABLE-BOUNDARY-START(21478441080),
    {
      "t": 1310721,
      "n": "_name",
      "d": this.$h,
      "H": 21478441080,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21478441080),
//--TRIMMABLE-BOUNDARY-START(4298571896),
    {
      "t": 262263,
      "n": "_jsRuntime",
      "d": this.$h,
      "H": 4298571896,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298571896)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34363342968),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524402
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 34363342968,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363342968),
//--TRIMMABLE-BOUNDARY-START(38658310264),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "jsRuntime",
          "p": 262263
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 38658310264,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38658310264)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 3604600,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILogger$$(T), $.$mexla.MEL.ILogger ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MACWS.WebAssemblyConsoleLogger$$(T).NoOpDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyConsoleLogger$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3604600)
        
        

        //--TRIMMABLE-BOUNDARY-START(3735672)
        $asm.$cls(`$macwa.MACWS.WebAssemblyConsoleLoggerProvider`, ($self) => class WebAssemblyConsoleLoggerProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593670264)
            /*ConcurrentDictionary<string, WebAssemblyConsoleLogger<object>>*/ _loggers = null;
            //--TRIMMABLE-BOUNDARY-END(8593670264)
            
            //--TRIMMABLE-BOUNDARY-START(4298702968)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4298702968)
            
            //--TRIMMABLE-BOUNDARY-START(12888637560)
            $ctor$1(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888637560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._loggers = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$macwa.MACWS.WebAssemblyConsoleLogger$$($.$$.S.Object)))().$ctor$1();
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888637560)
            
            //--TRIMMABLE-BOUNDARY-START(17183604856)
            /*ILogger */ CreateLogger(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183604856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._loggers.GetOrAdd(name, new ($.$$.S.Func$$$($.$$.S.String, $.$macwa.MACWS.WebAssemblyConsoleLogger$$($.$$.S.Object)))().$ctor(this,  (/*loggerName*/ loggerName) =>
                {
                    return new ($.$macwa.MACWS.WebAssemblyConsoleLogger$$($.$$.S.Object))().$ctor$2(name, this._jsRuntime);
                }, $DMmNDk ??= {"r":$.$macwa.MACWS.WebAssemblyConsoleLogger$$($.$$.S.Object).$h,"p":[{"n":"loggerName","p":1310721}],"n":"","d":3735672,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(17183604856)
            
            //--TRIMMABLE-BOUNDARY-START(21478572152)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478572152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21478572152)
            
            //--TRIMMABLE-BOUNDARY-START(4296081496)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerProvider.CreateLogger(string)
            MEL$ILoggerProvider$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081496)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 3735672;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183604856),
    {
      "r": 917592,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 3735672,
      "h": 17183604856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183604856),
//--TRIMMABLE-BOUNDARY-START(21478572152),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3735672,
      "h": 21478572152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478572152)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593670264),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$macwa.MACWS.WebAssemblyConsoleLogger$$($.$$.S.Object)).$h,
      "n": "_loggers",
      "d": 3735672,
      "h": 8593670264,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593670264),
//--TRIMMABLE-BOUNDARY-START(4298702968),
    {
      "t": 262263,
      "n": "_jsRuntime",
      "d": 3735672,
      "h": 4298702968,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298702968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888637560),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262263
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3735672,
      "h": 12888637560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888637560)
  ],
  "h": 3735672
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.MEL.ILoggerProvider, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLoggerProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyConsoleLoggerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735672)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162808)
        $asm.$cls(`$macwa.MACWH.WebAssemblyHostConfiguration`, ($self) => class WebAssemblyHostConfiguration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887064696)
            /*List<IConfigurationProvider>*/ _providers = null;
            //--TRIMMABLE-BOUNDARY-END(12887064696)
            
            //--TRIMMABLE-BOUNDARY-START(17182031992)
            /*List<IConfigurationSource>*/ _sources = null;
            //--TRIMMABLE-BOUNDARY-END(17182031992)
            
            //--TRIMMABLE-BOUNDARY-START(8592097400)
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(8592097400)
            
            //--TRIMMABLE-BOUNDARY-START(4297130104)
            /*ConfigurationReloadToken*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4297130104)
            
            //--TRIMMABLE-BOUNDARY-START(85901508728)
            /*IList<IConfigurationSource> */ get MEC$IConfigurationBuilder$Sources()
            {
                return new ($.$$.SCO.ReadOnlyCollection$$($.$mecga.MEC.IConfigurationSource))().$ctor$1(this._sources.ToArray());
            }
            //--TRIMMABLE-BOUNDARY-END(85901508728)
            
            //--TRIMMABLE-BOUNDARY-START(98786410616)
            /*IEnumerable<IConfigurationProvider> */ get MEC$IConfigurationRoot$Providers()
            {
                return new ($.$$.SCO.ReadOnlyCollection$$($.$mecga.MEC.IConfigurationProvider))().$ctor$1(this._providers.ToArray());
            }
            //--TRIMMABLE-BOUNDARY-END(98786410616)
            
            //--TRIMMABLE-BOUNDARY-START(81606541432)
            /*IDictionary<string, object>*/ MEC$IConfigurationBuilder$Properties = null;
            //--TRIMMABLE-BOUNDARY-END(81606541432)
            
            //--TRIMMABLE-BOUNDARY-START(120261247096)
            /*string?*/ get_Item$1(/*string*/ key)
            {
                for(/*var*/ let i = ((this._providers.Count - 1) | 0); i >= 0; i--)
                {
                    /*var*/ let value;
                    /*var*/ let provider = this._providers.get_Item(i);
                    if (provider.MEC$IConfigurationProvider$TryGet(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.String)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*void*/ set_Item$1(/*string*/ key, /*string?*/ value)
            {
                if (this._providers.Count === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("Can only set property if at least one provider has been inserted.");
                }
                let $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let provider = $en2.Current;
                    {
                        provider.MEC$IConfigurationProvider$Set(key, value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261247096)
            
            //--TRIMMABLE-BOUNDARY-START(55836737656)
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836737656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ConfigurationSection().$ctor$1(this, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836737656)
            
            //--TRIMMABLE-BOUNDARY-START(60131704952)
            /*IEnumerable<IConfigurationSection> */ MEC$IConfiguration$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hashSet = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$4($.$$.S.StringComparer.OrdinalIgnoreCase);
                /*var*/ let result = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationSection))().$ctor$1();
                let $en3 = this._providers.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let provider = $en3.Current;
                    {
                        let $en4 = provider.MEC$IConfigurationProvider$GetChildKeys($.$sl.SL.Enumerable.Empty($.$$.S.String), null).SCG$IEnumerable$$$GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let child = $en4.SCG$IEnumerator$$$Current;
                            {
                                if (!hashSet.Add(child))
                                {
                                    continue;
                                }
                                result.Add(this.GetSection(child));
                            }
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(60131704952)
            
            //--TRIMMABLE-BOUNDARY-START(51541770360)
            /*IChangeToken */ GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541770360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._changeToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541770360)
            
            //--TRIMMABLE-BOUNDARY-START(107376345208)
            /*void */ Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en5 = this._providers.GetEnumerator();
                while ($en5.MoveNext())
                {
                    let provider = $en5.Current;
                    {
                        provider.MEC$IConfigurationProvider$Load();
                    }
                }
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(107376345208)
            
            //--TRIMMABLE-BOUNDARY-START(103081377912)
            /*void */ RaiseChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081377912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let previousToken = $.$$.ST$1.Interlocked.Exchange$14($.$mec.MEC.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.MEC.ConfigurationReloadToken), new $.$mec.MEC.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(103081377912)
            
            //--TRIMMABLE-BOUNDARY-START(30066933880)
            /*IConfigurationBuilder */ Add(/*IConfigurationSource*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                /*var*/ let provider = source.MEC$IConfigurationSource$Build(this);
                provider.MEC$IConfigurationProvider$Load();
                this._changeTokenRegistrations.Add($.$mep.MEP.ChangeToken.OnChange(new ($.$$.S.Func$$($.$mep.MEP.IChangeToken))().$ctor(provider, provider.MEC$IConfigurationProvider$GetReloadToken), new $.$$.S.Action().$ctor(this, this.RaiseChanged)));
                this._providers.Add(provider);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066933880)
            
            //--TRIMMABLE-BOUNDARY-START(34361901176)
            /*IConfigurationRoot */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361901176)
            
            //--TRIMMABLE-BOUNDARY-START(38656868472)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en7 = this._changeTokenRegistrations.GetEnumerator();
                while ($en7.MoveNext())
                {
                    let registration = $en7.Current;
                    {
                        registration.S$IDisposable$Dispose();
                    }
                }
                let $en8 = this._providers.GetEnumerator();
                while ($en8.MoveNext())
                {
                    let provider = $en8.Current;
                    {
                        ($.$as(provider, $.$$.S.IDisposable))?.S$IDisposable$Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656868472)
            
            //--TRIMMABLE-BOUNDARY-START(17180524638)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Reload()
            MEC$IConfigurationRoot$Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reload(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524638)
            
            //--TRIMMABLE-BOUNDARY-START(8590327902)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            MEC$IConfiguration$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327902)
            
            //--TRIMMABLE-BOUNDARY-START(30065164382)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            MEC$IConfiguration$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164382)
            
            //--TRIMMABLE-BOUNDARY-START(21475229790)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            MEC$IConfiguration$GetSection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSection(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229790)
            
            //--TRIMMABLE-BOUNDARY-START(17180262494)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            MEC$IConfiguration$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262494)
            
            //--TRIMMABLE-BOUNDARY-START(4295426142)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
            MEC$IConfigurationBuilder$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426142)
            
            //--TRIMMABLE-BOUNDARY-START(8590393438)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Build()
            MEC$IConfigurationBuilder$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393438)
            
            //--TRIMMABLE-BOUNDARY-START(25771966584)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966584)
            
            //--TRIMMABLE-BOUNDARY-START(25771966584)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25771966584)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12887064696)
                this._providers = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12887064696)
                
                //--TRIMMABLE-BOUNDARY-START(17182031992)
                this._sources = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182031992)
                
                //--TRIMMABLE-BOUNDARY-START(8592097400)
                this._changeTokenRegistrations = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8592097400)
                
                //--TRIMMABLE-BOUNDARY-START(4297130104)
                this._changeToken = new $.$mec.MEC.ConfigurationReloadToken().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4297130104)
                
                //--TRIMMABLE-BOUNDARY-START(81606541432)
                this.MEC$IConfigurationBuilder$Properties = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(81606541432)
                
            }
            static $h = 2162808;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85901508728),
    {
      "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311574136,
        "f": 50331650
      },
      "n": "{458846}.Sources",
      "o": "MEC$IConfigurationBuilder$Sources",
      "d": 2162808,
      "h": 85901508728,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(85901508728),
//--TRIMMABLE-BOUNDARY-START(98786410616),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491443320,
        "f": 50331650
      },
      "n": "{655454}.Providers",
      "o": "MEC$IConfigurationRoot$Providers",
      "d": 2162808,
      "h": 98786410616,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98786410616),
//--TRIMMABLE-BOUNDARY-START(81606541432),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721639544,
        "f": 50331650
      },
      "n": "{458846}.Properties",
      "o": "MEC$IConfigurationBuilder$Properties",
      "d": 2162808,
      "h": 81606541432,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(81606541432),
//--TRIMMABLE-BOUNDARY-START(120261247096),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246803064,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115966279800,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 2162808,
      "h": 120261247096,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(120261247096)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836737656),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "d": 2162808,
      "h": 55836737656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836737656),
//--TRIMMABLE-BOUNDARY-START(51541770360),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 2162808,
      "h": 51541770360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541770360),
//--TRIMMABLE-BOUNDARY-START(107376345208),
    {
      "r": 65537,
      "n": "Reload",
      "d": 2162808,
      "h": 107376345208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376345208),
//--TRIMMABLE-BOUNDARY-START(103081377912),
    {
      "r": 65537,
      "n": "RaiseChanged",
      "d": 2162808,
      "h": 103081377912,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103081377912),
//--TRIMMABLE-BOUNDARY-START(30066933880),
    {
      "r": 458846,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "d": 2162808,
      "h": 30066933880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066933880),
//--TRIMMABLE-BOUNDARY-START(34361901176),
    {
      "r": 655454,
      "n": "Build",
      "d": 2162808,
      "h": 34361901176,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361901176),
//--TRIMMABLE-BOUNDARY-START(38656868472),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2162808,
      "h": 38656868472,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656868472)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887064696),
    {
      "t": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "n": "_providers",
      "d": 2162808,
      "h": 12887064696,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064696),
//--TRIMMABLE-BOUNDARY-START(17182031992),
    {
      "t": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource).$h,
      "n": "_sources",
      "d": 2162808,
      "h": 17182031992,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182031992),
//--TRIMMABLE-BOUNDARY-START(8592097400),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_changeTokenRegistrations",
      "d": 2162808,
      "h": 8592097400,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097400),
//--TRIMMABLE-BOUNDARY-START(4297130104),
    {
      "t": 720991,
      "n": "_changeToken",
      "d": 2162808,
      "h": 4297130104,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297130104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771966584),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162808,
      "h": 25771966584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771966584)
  ],
  "h": 2162808
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationRoot, $.$mecga.MEC.IConfiguration, $.$mecga.MEC.IConfigurationBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}WebAssemblyHostConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162808)
        
        

        //--TRIMMABLE-BOUNDARY-START(524408)
        $asm.$cls(`$macwa.MACF.DefaultAntiforgeryStateProvider`, ($self) => class DefaultAntiforgeryStateProvider extends $.$macw.MACF.AntiforgeryStateProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295491704)
            /*AntiforgeryRequestToken?*/ _currentToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295491704)
            
            //--TRIMMABLE-BOUNDARY-START(12885426296)
            /*AntiforgeryRequestToken? */ get CurrentToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._currentToken ??= this.GetAntiforgeryToken();
            }
            /*AntiforgeryRequestToken? */ set CurrentToken(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._currentToken = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426296)
            
            //--TRIMMABLE-BOUNDARY-START(25770328184)
            /*AntiforgeryRequestToken? */ GetAntiforgeryToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._currentToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328184)
            
            //--TRIMMABLE-BOUNDARY-START(8590459000)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590459000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590459000)
            
            //--TRIMMABLE-BOUNDARY-START(8590459000)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590459000)
            
            static $h = 524408;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$macw.MACF.AntiforgeryStateProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426296),
    {
      "p": 262261,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360888,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360262776,
        "f": 83886081
      },
      "n": "CurrentToken",
      "d": 524408,
      "h": 12885426296,
      "f": 2097153,
      "a": [
        {
          "t": 6357107,
          "c": 12891258995
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885426296)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770328184),
    {
      "r": 262261,
      "n": "GetAntiforgeryToken",
      "d": 524408,
      "h": 25770328184,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770328184)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491704),
    {
      "t": 262261,
      "n": "_currentToken",
      "d": 524408,
      "h": 4295491704,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4295491704)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590459000),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524408,
      "h": 8590459000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590459000)
  ],
  "h": 524408
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}Forms${separator}DefaultAntiforgeryStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524408)
        
        

        //--TRIMMABLE-BOUNDARY-START(2752632)
        $asm.$cls(`$macwa.MACWR.NullDispatcher`, ($self) => class NullDispatcher extends $.$mac.MAC.Dispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(17182621816)
            /*Dispatcher*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17182621816)
            
            //--TRIMMABLE-BOUNDARY-START(8592687224)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592687224);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687224)
            
            //--TRIMMABLE-BOUNDARY-START(12887654520)
            /*bool */ CheckAccess()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654520);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887654520)
            
            //--TRIMMABLE-BOUNDARY-START(21477589112)
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477589112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                workItem.Invoke();
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(21477589112)
            
            //--TRIMMABLE-BOUNDARY-START(25772556408)
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772556408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return workItem.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(25772556408)
            
            //--TRIMMABLE-BOUNDARY-START(34362491000)
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<TResult>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362491000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return $.$$.STT.Task.FromResult(TResult, workItem.Invoke());
            }
            //--TRIMMABLE-BOUNDARY-END(34362491000)
            
            //--TRIMMABLE-BOUNDARY-START(30067523704)
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067523704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return workItem.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(30067523704)
            
            //--TRIMMABLE-BOUNDARY-START(8592687224)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8592687224)
            
            //--TRIMMABLE-BOUNDARY-START(4297719928)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297719928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17182621816)
                    this.Instance = new $.$macwa.MACWR.NullDispatcher().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(17182621816)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297719928)
            
            static $h = 2752632;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.Dispatcher; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887654520),
    {
      "r": 262145,
      "n": "CheckAccess",
      "d": 2752632,
      "h": 12887654520,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12887654520),
//--TRIMMABLE-BOUNDARY-START(21477589112),
    {
      "r": 178454529,
      "p": [
        {
          "n": "workItem",
          "p": 43122689
        }
      ],
      "n": "InvokeAsync",
      "d": 2752632,
      "h": 21477589112,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477589112),
//--TRIMMABLE-BOUNDARY-START(25772556408),
    {
      "r": 178454529,
      "p": [
        {
          "n": "workItem",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        }
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2752632,
      "h": 25772556408,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772556408),
//--TRIMMABLE-BOUNDARY-START(34362491000),
    {
      "r": (TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.S.Func$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2752632,
      "h": 34362491000,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(34362491000),
//--TRIMMABLE-BOUNDARY-START(30067523704),
    {
      "r": (TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.S.Func$$($.$$.STT.Task$$(TResult)).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2752632,
      "h": 30067523704,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(30067523704)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182621816),
    {
      "t": 1704051,
      "n": "Instance",
      "d": 2752632,
      "h": 17182621816,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182621816)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687224),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752632,
      "h": 8592687224,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8592687224)
  ],
  "h": 2752632
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}NullDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752632)
        
        

        //--TRIMMABLE-BOUNDARY-START(4391032)
        $asm.$str(`$macwa.MAC.WebRootComponentParameters`, ($self) => class WebRootComponentParameters extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34364129400)
            /*WebRootComponentParameters*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(34364129400)
            
            //--TRIMMABLE-BOUNDARY-START(4299358328)
            /*IReadOnlyList<ComponentParameter>*/ _parameterDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(4299358328)
            
            //--TRIMMABLE-BOUNDARY-START(8594325624)
            /*IReadOnlyList<object>*/ _serializedParameterValues = null;
            //--TRIMMABLE-BOUNDARY-END(8594325624)
            
            //--TRIMMABLE-BOUNDARY-START(47249031288)
            /*ParameterView */ get Parameters()
            {
                return this.parameterView;
            }
            //--TRIMMABLE-BOUNDARY-END(47249031288)
            
            //--TRIMMABLE-BOUNDARY-START(30069162104)
            /*bool */ DefinitelyEquals(/*in WebRootComponentParameters*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069162104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = this._parameterDefinitions.SCG$IReadOnlyCollection$$$Count;
                if (count !== other.$v._parameterDefinitions.SCG$IReadOnlyCollection$$$Count)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < count; i++)
                {
                    /*var*/ let definition = this._parameterDefinitions.SCG$IReadOnlyList$$$get_Item(i);
                    /*var*/ let otherDefinition = other.$v._parameterDefinitions.SCG$IReadOnlyList$$$get_Item(i);
                    if (!$.$$.S.String.Equals$3(definition.Name, otherDefinition.Name, 4/*StringComparison.Ordinal*/) || !$.$$.S.String.Equals$3(definition.TypeName, otherDefinition.TypeName, 4/*StringComparison.Ordinal*/) || !$.$$.S.String.Equals$3(definition.Assembly, otherDefinition.Assembly, 4/*StringComparison.Ordinal*/))
                    {
                        return false;
                    }
                    /*var*/ let value = this._serializedParameterValues.SCG$IReadOnlyList$$$get_Item(i);
                    /*var*/ let otherValue = other.$v._serializedParameterValues.SCG$IReadOnlyList$$$get_Item(i);
                    let jsonValue;
                    let otherJsonValue;
                    if ($.$is(value, $.$stj.STJ.JsonElement, { set $v($v){ jsonValue = $v; } }) && $.$is(otherValue, $.$stj.STJ.JsonElement, { set $v($v){ otherJsonValue = $v; } }))
                    {
                        if (!$.$$.S.String.Equals$3(jsonValue.GetRawText(), otherJsonValue.GetRawText(), 4/*StringComparison.Ordinal*/))
                        {
                            return false;
                        }
                    }
                    else if (!$.$$.S.Object.Equals(value, otherValue))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30069162104)
            
            //--TRIMMABLE-BOUNDARY-START(21479227512)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21479227512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21479227512)
            
            //--TRIMMABLE-BOUNDARY-START(21479227512)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(21479227512)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parameterDefinitions = this._parameterDefinitions;
                copy._serializedParameterValues = this._serializedParameterValues;
                return copy;
            }
            //Begin primary constructor
            /*ParameterView*/ parameterView = new $.$mac.MAC.ParameterView();
            /*IReadOnlyList<ComponentParameter>*/ parameterDefinitions = null;
            /*IReadOnlyList<object>*/ serializedParameterValues = null;
            $ctor$3(/*ParameterView*/parameterView, /*IReadOnlyList<ComponentParameter>*/parameterDefinitions, /*IReadOnlyList<object>*/serializedParameterValues)
            {
                this.parameterView = parameterView;
                this.parameterDefinitions = parameterDefinitions;
                this.serializedParameterValues = serializedParameterValues;
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(4299358328)
                //depends on primary constructor parameter
                this._parameterDefinitions = this.parameterDefinitions;
                //--TRIMMABLE-BOUNDARY-END(4299358328)
                
                //--TRIMMABLE-BOUNDARY-START(8594325624)
                //depends on primary constructor parameter
                this._serializedParameterValues = this.serializedParameterValues;
                //--TRIMMABLE-BOUNDARY-END(8594325624)
                
                return this
            }
            //End primary constructor
            //--TRIMMABLE-BOUNDARY-START(17184260216)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17184260216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(34364129400)
                    this.Empty = new $.$macwa.MAC.WebRootComponentParameters().$ctor$3($.$mac.MAC.ParameterView.Empty, (() =>
                    {
                        let $t1 = new ($.$$.SCG.List$$($.$macwa.MAC.ComponentParameter))().$ctor$1();
                        return $t1;
                    })(), (() =>
                    {
                        let $t2 = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                        return $t2;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(34364129400)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17184260216)
            
            static $h = 4391032;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47249031288),
    {
      "p": 5767283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954063992,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 4391032,
      "h": 47249031288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47249031288)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30069162104),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 4391032,
          "f": 8
        }
      ],
      "n": "DefinitelyEquals",
      "d": 4391032,
      "h": 30069162104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30069162104)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889292920),
    {
      "t": 5767283,
      "n": "\u003CparameterView\u003EP",
      "d": 4391032,
      "h": 12889292920,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12889292920),
//--TRIMMABLE-BOUNDARY-START(34364129400),
    {
      "t": 4391032,
      "n": "Empty",
      "d": 4391032,
      "h": 34364129400,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364129400),
//--TRIMMABLE-BOUNDARY-START(4299358328),
    {
      "t": $.$$.SCG.IReadOnlyList$$($.$macwa.MAC.ComponentParameter).$h,
      "n": "_parameterDefinitions",
      "d": 4391032,
      "h": 4299358328,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4299358328),
//--TRIMMABLE-BOUNDARY-START(8594325624),
    {
      "t": $.$$.SCG.IReadOnlyList$$($.$$.S.Object).$h,
      "n": "_serializedParameterValues",
      "d": 4391032,
      "h": 8594325624,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8594325624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25774194808),
    {
      "p": [
        {
          "n": "parameterView",
          "p": 5767283
        },
        {
          "n": "parameterDefinitions",
          "p": $.$$.SCG.IReadOnlyList$$($.$macwa.MAC.ComponentParameter).$h
        },
        {
          "n": "serializedParameterValues",
          "p": $.$$.SCG.IReadOnlyList$$($.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4391032,
      "h": 25774194808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25774194808),
//--TRIMMABLE-BOUNDARY-START(21479227512),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4391032,
      "h": 21479227512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21479227512)
  ],
  "h": 4391032
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebRootComponentParameters`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebRootComponentParameters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4391032)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638520)
        $asm.$str(`$macwa.MACWH.RootComponentMapping`, ($self) => class RootComponentMapping extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25771442296)
            $ctor$4(/*Type*/ componentType, /*string*/ selector)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771442296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(componentType, "componentType");
                    if (!$.$mac.MAC.IComponent.$type.IsAssignableFrom(componentType))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13(`The type '${$.$strNN(componentType.Name)}' must implement ${$.$strNN("IComponent")} to be used as a root component.`, "componentType");
                    }
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                    this.ComponentType = componentType;
                    this.Selector = selector;
                    this.Parameters = $.$mac.MAC.ParameterView.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442296)
            
            //--TRIMMABLE-BOUNDARY-START(21476475000)
            $ctor$3(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                this.$ctor$4(componentType, selector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476475000);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Parameters = parameters;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476475000)
            
            //--TRIMMABLE-BOUNDARY-START(30066409592)
            /*Type*/ ComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(30066409592)
            
            //--TRIMMABLE-BOUNDARY-START(64426147960)
            /*string*/ Selector = null;
            //--TRIMMABLE-BOUNDARY-END(64426147960)
            
            //--TRIMMABLE-BOUNDARY-START(60131180664)
            /*ParameterView*/ Parameters;
            //--TRIMMABLE-BOUNDARY-END(60131180664)
            
            //--TRIMMABLE-BOUNDARY-START(17181507704)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507704)
            
            //--TRIMMABLE-BOUNDARY-START(17181507704)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17181507704)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ComponentType = this.ComponentType;
                copy.Selector = this.Selector;
                copy.Parameters = this.Parameters.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(60131180664)
                this.Parameters = $.$default($.$mac.MAC.ParameterView);
                //--TRIMMABLE-BOUNDARY-END(60131180664)
                
            }
            static $h = 1638520;
            static $z = 28;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066409592),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656344184,
        "f": 50331649
      },
      "n": "ComponentType",
      "d": 1638520,
      "h": 30066409592,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066409592),
//--TRIMMABLE-BOUNDARY-START(64426147960),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836213368,
        "f": 50331649
      },
      "n": "Selector",
      "d": 1638520,
      "h": 64426147960,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426147960),
//--TRIMMABLE-BOUNDARY-START(60131180664),
    {
      "p": 5767283,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246278776,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1638520,
      "h": 60131180664,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131180664)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771442296),
    {
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1638520,
      "h": 25771442296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771442296),
//--TRIMMABLE-BOUNDARY-START(21476475000),
    {
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "selector",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638520,
      "h": 21476475000,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476475000),
//--TRIMMABLE-BOUNDARY-START(17181507704),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638520,
      "h": 17181507704,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181507704)
  ],
  "h": 1638520
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}RootComponentMapping`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638520)
        
        

        //--TRIMMABLE-BOUNDARY-START(3932280)
        $asm.$cls(`$macwa.MACWS.WebAssemblyNavigationManager`, ($self) => class WebAssemblyNavigationManager extends $.$mac.MAC.NavigationManager
        {
            //--TRIMMABLE-BOUNDARY-START(4298899576)
            /*ILogger<WebAssemblyNavigationManager>*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(4298899576)
            
            //--TRIMMABLE-BOUNDARY-START(42953605240)
            /*WebAssemblyNavigationManager*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(42953605240)
            
            //--TRIMMABLE-BOUNDARY-START(17183801464)
            $ctor$2(/*string*/ baseUri, /*string*/ uri)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183801464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Initialize(baseUri, uri);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183801464)
            
            //--TRIMMABLE-BOUNDARY-START(21478768760)
            /*void */ CreateLogger(/*ILoggerFactory*/ loggerFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478768760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._logger === null))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12(`The ${$.$strNN("WebAssemblyNavigationManager")} has already created a logger.`);
                }
                this._logger = $.$mexla.MEL.LoggerFactoryExtensions.CreateLogger$1($.$macwa.MACWS.WebAssemblyNavigationManager, loggerFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(21478768760)
            
            //--TRIMMABLE-BOUNDARY-START(64428441720)
            /*void */ SetLocation(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428441720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Uri = uri;
                this.HistoryEntryState = state;
                this.NotifyLocationChanged(isInterceptedLink);
            }
            //--TRIMMABLE-BOUNDARY-END(64428441720)
            
            //--TRIMMABLE-BOUNDARY-START(34363670648)
            /*ValueTask<bool> *//*async*/  HandleLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ intercepted)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363670648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.NotifyLocationChangingAsync(uri, state, intercepted), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34363670648)
            
            //--TRIMMABLE-BOUNDARY-START(47248572536)
            /*void */ NavigateToCore(/*string*/ uri, /*NavigationOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248572536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                _ = PerformNavigationAsync.call(this);
                /*Task*/ /*async*/  function PerformNavigationAsync()
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        try
                        {
                            let $t2, $r2;
                            /*var*/ let shouldContinueNavigation = ($t2 = this.NotifyLocationChangingAsync(uri, options.HistoryEntryState, false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            if (!shouldContinueNavigation)
                            {
                                $.$macwa.MACWS.WebAssemblyNavigationManager.Log.NavigationCanceled(this._logger, uri);
                                return $.$$.N.AsyncResolver.Result($asnycContext,);
                            }
                            $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.navigateTo"/*Interop.NavigateTo*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ uri, options ], null, null));
                        }
                        catch(ex)
                        {
                            $.$macwa.MACWS.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, uri, ex);
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248572536)
            
            //--TRIMMABLE-BOUNDARY-START(51543539832)
            /*void */ Refresh(/*bool*/ forceReload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543539832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.MJ.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.refresh"/*Interop.Refresh*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$box(forceReload, $.$$.S.Boolean) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(51543539832)
            
            //--TRIMMABLE-BOUNDARY-START(38658637944)
            /*void */ HandleLocationChangingHandlerException(/*Exception*/ ex, /*LocationChangingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658637944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.MACWS.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, context.TargetLocation, ex);
            }
            //--TRIMMABLE-BOUNDARY-END(38658637944)
            
            //--TRIMMABLE-BOUNDARY-START(68723409016)
            /*void */ SetNavigationLockState(/*bool*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68723409016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.MACWS.InternalJSImportMethods.Instance.NavigationManager_SetHasLocationChangingListeners(2/*WebRendererId.WebAssembly*/, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68723409016)
            
            //--TRIMMABLE-BOUNDARY-START(3997816)
            static $_Log;
            static get Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3997816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWS.WebAssemblyNavigationManager;
                return $cls.$_Log ??= $asm.$ncls(`$macwa.MACWS.WebAssemblyNavigationManager.Log`, ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4298965112)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationCanceledCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4298965112)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183867000)
                    static /*void */ NavigationCanceled(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17183867000);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.MEL$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$macwa.MACWS.WebAssemblyNavigationManager.Log.__NavigationCanceledCallback.Invoke(logger, uri, null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183867000)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593932408)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationFailedCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(8593932408)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478834296)
                    static /*void */ NavigationFailed(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri, /*global::System.Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21478834296);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.MEL$ILogger$IsEnabled(4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/))
                        {
                            $.$macwa.MACWS.WebAssemblyNavigationManager.Log.__NavigationFailedCallback.Invoke(logger, uri, exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21478834296)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888899704)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12888899704);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(4298965112)
                            this.__NavigationCanceledCallback = $.$mexla.MEL.LoggerMessage.Define$12($.$$.S.String, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mexla.MEL.EventId().$ctor$3(1, "NavigationCanceled"), "Navigation canceled when changing the location to {Uri}", (() =>
                            {
                                //new $.$mexla.MEL.LogDefineOptions()
                                const $t3 = $.$mexla.MEL.LogDefineOptions;
                                const $i3 = new $t3();
                                $i3.$ctor$1();
                                $i3.SkipEnabledCheck = true;
                                return $i3;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4298965112)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8593932408)
                            this.__NavigationFailedCallback = $.$mexla.MEL.LoggerMessage.Define$12($.$$.S.String, 4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/, new $.$mexla.MEL.EventId().$ctor$3(2, "NavigationFailed"), "Navigation failed when changing the location to {Uri}", (() =>
                            {
                                //new $.$mexla.MEL.LogDefineOptions()
                                const $t4 = $.$mexla.MEL.LogDefineOptions;
                                const $i4 = new $t4();
                                $i4.$ctor$1();
                                $i4.SkipEnabledCheck = true;
                                return $i4;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(8593932408)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888899704)
                    
                    static $h = 3997816;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183867000),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": "NavigationCanceled",
      "d": 3997816,
      "h": 17183867000,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "Navigation canceled when changing the location to {Uri}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "NavigationCanceled",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183867000),
//--TRIMMABLE-BOUNDARY-START(21478834296),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "NavigationFailed",
      "d": 3997816,
      "h": 21478834296,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 2,
              "t": 655361
            },
            {
              "v": 4,
              "t": 2293848
            },
            {
              "v": "Navigation failed when changing the location to {Uri}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "NavigationFailed",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478834296)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298965112),
    {
      "t": $.$$.S.Action$$$$($.$mexla.MEL.ILogger, $.$$.S.String, $.$$.S.Exception).$h,
      "n": "__NavigationCanceledCallback",
      "d": 3997816,
      "h": 4298965112,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4298965112),
//--TRIMMABLE-BOUNDARY-START(8593932408),
    {
      "t": $.$$.S.Action$$$$($.$mexla.MEL.ILogger, $.$$.S.String, $.$$.S.Exception).$h,
      "n": "__NavigationFailedCallback",
      "d": 3997816,
      "h": 8593932408,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593932408)
  ],
  "d": 3932280,
  "h": 3997816
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager+Log`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyNavigationManager${separator}Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3997816)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4298899576)
                this._logger = null;
                //--TRIMMABLE-BOUNDARY-END(4298899576)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12888834168)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888834168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(42953605240)
                    this.Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(42953605240)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888834168)
            
            static $h = 3932280;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.NavigationManager; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953605240),
    {
      "p": 3932280,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068703352,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60133474424,
        "f": 83886113
      },
      "n": "Instance",
      "d": 3932280,
      "h": 42953605240,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42953605240)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478768760),
    {
      "r": 65537,
      "p": [
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": "CreateLogger",
      "d": 3932280,
      "h": 21478768760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478768760),
//--TRIMMABLE-BOUNDARY-START(64428441720),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "SetLocation",
      "d": 3932280,
      "h": 64428441720,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64428441720),
//--TRIMMABLE-BOUNDARY-START(34363670648),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "intercepted",
          "p": 262145
        }
      ],
      "n": "HandleLocationChangingAsync",
      "d": 3932280,
      "h": 34363670648,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34363670648),
//--TRIMMABLE-BOUNDARY-START(47248572536),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 5439603
        }
      ],
      "n": "NavigateToCore",
      "d": 3932280,
      "h": 47248572536,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47248572536),
//--TRIMMABLE-BOUNDARY-START(51543539832),
    {
      "r": 65537,
      "p": [
        {
          "n": "forceReload",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Refresh",
      "d": 3932280,
      "h": 51543539832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51543539832),
//--TRIMMABLE-BOUNDARY-START(38658637944),
    {
      "r": 65537,
      "p": [
        {
          "n": "ex",
          "p": 80805889
        },
        {
          "n": "context",
          "p": 10616947
        }
      ],
      "n": "HandleLocationChangingHandlerException",
      "d": 3932280,
      "h": 38658637944,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38658637944),
//--TRIMMABLE-BOUNDARY-START(68723409016),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetNavigationLockState",
      "d": 3932280,
      "h": 68723409016,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68723409016)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298899576),
    {
      "t": $.$mexla.MEL.ILogger$$($.$macwa.MACWS.WebAssemblyNavigationManager).$h,
      "n": "_logger",
      "d": 3932280,
      "h": 4298899576,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298899576)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183801464),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1310721
        },
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3932280,
      "h": 17183801464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183801464)
  ],
  "h": 3932280
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MACWS.WebAssemblyNavigationManager.Log ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}WebAssemblyNavigationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3932280)
        
        

        //--TRIMMABLE-BOUNDARY-START(262264)
        $asm.$str(`$macwa.MAC.ComponentParameter`, ($self) => class ComponentParameter extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55834837112)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55834837112)
            
            //--TRIMMABLE-BOUNDARY-START(85899608184)
            /*string?*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(85899608184)
            
            //--TRIMMABLE-BOUNDARY-START(21475098744)
            /*string?*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(21475098744)
            
            //--TRIMMABLE-BOUNDARY-START(25770066040)
            static /*(IList<ComponentParameter> parameterDefinitions, IList<object?> parameterValues) */ FromParameterView(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameterDefinitions = new ($.$$.SCG.List$$($.$macwa.MAC.ComponentParameter))().$ctor$1();
                /*var*/ let parameterValues = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                let $en1 = parameters.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let kvp = $en1.Current;
                    {
                        /*object?*/ let __ca1__;
                        /*var*/ let valueType = ((__ca1__ = kvp.Value) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null);
                        parameterDefinitions.Add((() =>
                        {
                            //new $.$macwa.MAC.ComponentParameter()
                            const $t2 = $.$macwa.MAC.ComponentParameter;
                            const $i2 = new $t2();
                            $i2.$ctor$2();
                            $i2.Name = kvp.Name;
                            $i2.TypeName = (valueType?.FullName ?? null);
                            $i2.Assembly = (valueType?.Assembly?.GetName()?.Name ?? null);
                            return $i2;
                        })());
                        parameterValues.Add(kvp.Value);
                    }
                }
                return new ($.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$macwa.MAC.ComponentParameter), $.$$.SCG.IList$$($.$$.S.Object)))().$ctor$3(parameterDefinitions, parameterValues);
            }
            //--TRIMMABLE-BOUNDARY-END(25770066040)
            
            //--TRIMMABLE-BOUNDARY-START(17180131448)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131448)
            
            //--TRIMMABLE-BOUNDARY-START(17180131448)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180131448)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.TypeName = this.TypeName;
                copy.Assembly = this.Assembly;
                return copy;
            }
            static $h = 262264;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834837112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949935224,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706296,
        "f": 83886081
      },
      "n": "Name",
      "d": 262264,
      "h": 55834837112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837112),
//--TRIMMABLE-BOUNDARY-START(85899608184),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869816,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640888,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 262264,
      "h": 85899608184,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899608184),
//--TRIMMABLE-BOUNDARY-START(21475098744),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000632,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771704,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 262264,
      "h": 21475098744,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098744)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770066040),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.SCG.IList$$($.$macwa.MAC.ComponentParameter), $.$$.SCG.IList$$($.$$.S.Object)).$h,
      "p": [
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "FromParameterView",
      "d": 262264,
      "h": 25770066040,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770066040)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131448),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262264,
      "h": 17180131448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131448)
  ],
  "h": 262264
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentParameter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentParameter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262264)
        
        

        //--TRIMMABLE-BOUNDARY-START(2883704)
        $asm.$cls(`$macwa.MACWR.WebAssemblyDispatcher`, ($self) => class WebAssemblyDispatcher extends $.$mac.MAC.Dispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(8592818296)
            /*SynchronizationContext?*/ static _mainSynchronizationContext = null;
            //--TRIMMABLE-BOUNDARY-END(8592818296)
            
            //--TRIMMABLE-BOUNDARY-START(4297851000)
            /*int*/ static _mainManagedThreadId = 0;
            //--TRIMMABLE-BOUNDARY-END(4297851000)
            
            //--TRIMMABLE-BOUNDARY-START(17182752888)
            /*bool */ CheckAccess()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182752888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.MACWR.WebAssemblyDispatcher._mainManagedThreadId === $.$$.S.Environment.CurrentManagedThreadId;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182752888)
            
            //--TRIMMABLE-BOUNDARY-START(21477720184)
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    workItem.Invoke();
                    return $.$$.STT.Task.CompletedTask;
                }
                /*var*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.ST$1.SendOrPostCallback().$ctor($.$macwa.MACWR.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource, $.$$.S.Action));
                    try
                    {
                        state.Item2.Invoke();
                        state.Item1.SetResult();
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, $cdgKJk ??= {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883704,"h":0,"f":17825826}), new ($.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource, $.$$.S.Action))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(21477720184)
            
            //--TRIMMABLE-BOUNDARY-START(34362622072)
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<TResult>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362622072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return $.$$.STT.Task.FromResult(TResult, workItem.Invoke());
                }
                /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.ST$1.SendOrPostCallback().$ctor($.$macwa.MACWR.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource$$(TResult), $.$$.S.Func$$(TResult)));
                    try
                    {
                        /*var*/ let res = state.Item2.Invoke();
                        state.Item1.SetResult(res);
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, $oVMiAa ??= {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883704,"h":0,"f":17825826}), new ($.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource$$(TResult), $.$$.S.Func$$(TResult)))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(34362622072)
            
            //--TRIMMABLE-BOUNDARY-START(25772687480)
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772687480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.ST$1.SendOrPostCallback().$ctor($.$macwa.MACWR.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource, $.$$.S.Func$$($.$$.STT.Task)));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$10(new ($.$$.S.Action$$($.$$.STT.Task))().$ctor(this,  (/**/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException$1(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult();
                            }
                        }, $smDjTi ??= {"r":65537,"p":[{"n":"t","p":178454529}],"n":"","d":2883704,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, $wFJuvh ??= {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883704,"h":0,"f":17825826}), new ($.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource, $.$$.S.Func$$($.$$.STT.Task)))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(25772687480)
            
            //--TRIMMABLE-BOUNDARY-START(30067654776)
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067654776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new ($.$$.STT.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.ST$1.SendOrPostCallback().$ctor($.$macwa.MACWR.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource$$(TResult), $.$$.S.Func$$($.$$.STT.Task$$(TResult))));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$34(new ($.$$.S.Action$$($.$$.STT.Task$$(TResult)))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException$1(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult(t.Result);
                            }
                        }, $bpMjYi ??= {"r":65537,"p":[{"n":"t","p":(TResult) => $.$$.STT.Task$$(TResult).$h}],"n":"","d":2883704,"h":0,"f":17825794}), $.$$.STT.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, $CLqyla ??= {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883704,"h":0,"f":17825826}), new ($.$$.S.ValueTuple$$$($.$$.STT.TaskCompletionSource$$(TResult), $.$$.S.Func$$($.$$.STT.Task$$(TResult))))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(30067654776)
            
            //--TRIMMABLE-BOUNDARY-START(12887785592)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887785592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887785592)
            
            //--TRIMMABLE-BOUNDARY-START(12887785592)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887785592)
            
            static $h = 2883704;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MAC.Dispatcher; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182752888),
    {
      "r": 262145,
      "n": "CheckAccess",
      "d": 2883704,
      "h": 17182752888,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17182752888),
//--TRIMMABLE-BOUNDARY-START(21477720184),
    {
      "r": 178454529,
      "p": [
        {
          "n": "workItem",
          "p": 43122689
        }
      ],
      "n": "InvokeAsync",
      "d": 2883704,
      "h": 21477720184,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477720184),
//--TRIMMABLE-BOUNDARY-START(34362622072),
    {
      "r": (TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.S.Func$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2883704,
      "h": 34362622072,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(34362622072),
//--TRIMMABLE-BOUNDARY-START(25772687480),
    {
      "r": 178454529,
      "p": [
        {
          "n": "workItem",
          "p": $.$$.S.Func$$($.$$.STT.Task).$h
        }
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2883704,
      "h": 25772687480,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772687480),
//--TRIMMABLE-BOUNDARY-START(30067654776),
    {
      "r": (TResult) => $.$$.STT.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.S.Func$$($.$$.STT.Task$$(TResult)).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2883704,
      "h": 30067654776,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(30067654776)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592818296),
    {
      "t": 176095233,
      "n": "_mainSynchronizationContext",
      "d": 2883704,
      "h": 8592818296,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8592818296),
//--TRIMMABLE-BOUNDARY-START(4297851000),
    {
      "t": 655361,
      "n": "_mainManagedThreadId",
      "d": 2883704,
      "h": 4297851000,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4297851000)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887785592),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883704,
      "h": 12887785592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887785592)
  ],
  "h": 2883704
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883704)
        
        

        //--TRIMMABLE-BOUNDARY-START(131192)
        $asm.$str(`$macwa.MAC.ComponentMarker`, ($self) => class ComponentMarker extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(171798823032)
            /*string*/ static ServerMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(171798823032)
            
            //--TRIMMABLE-BOUNDARY-START(266288103544)
            /*string*/ static WebAssemblyMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(266288103544)
            
            //--TRIMMABLE-BOUNDARY-START(51539738744)
            /*string*/ static AutoMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(51539738744)
            
            //--TRIMMABLE-BOUNDARY-START(257698168952)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(257698168952)
            
            //--TRIMMABLE-BOUNDARY-START(163208888440)
            /*string?*/ PrerenderId = null;
            //--TRIMMABLE-BOUNDARY-END(163208888440)
            
            //--TRIMMABLE-BOUNDARY-START(150323986552)
            /*ComponentMarkerKey?*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(150323986552)
            
            //--TRIMMABLE-BOUNDARY-START(167503855736)
            /*int?*/ Sequence = null;
            //--TRIMMABLE-BOUNDARY-END(167503855736)
            
            //--TRIMMABLE-BOUNDARY-START(60129673336)
            /*string?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(60129673336)
            
            //--TRIMMABLE-BOUNDARY-START(47244771448)
            /*string?*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(47244771448)
            
            //--TRIMMABLE-BOUNDARY-START(261993136248)
            /*string?*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(261993136248)
            
            //--TRIMMABLE-BOUNDARY-START(154618953848)
            /*string?*/ ParameterDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(154618953848)
            
            //--TRIMMABLE-BOUNDARY-START(158913921144)
            /*string?*/ ParameterValues = null;
            //--TRIMMABLE-BOUNDARY-END(158913921144)
            
            //--TRIMMABLE-BOUNDARY-START(55834706040)
            static /*ComponentMarker */ Create(/*string*/ type, /*bool*/ prerendered, /*ComponentMarkerKey?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$macwa.MAC.ComponentMarker()
                    const $t1 = $.$macwa.MAC.ComponentMarker;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.Type = type;
                    $i1.PrerenderId = prerendered ? $.$macwa.MAC.ComponentMarker.GeneratePrerenderId() : null;
                    $i1.Key = $.$clone(key);
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55834706040)
            
            //--TRIMMABLE-BOUNDARY-START(270583070840)
            /*void */ WriteServerData(/*int*/ sequence, /*string*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583070840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Sequence = sequence;
                this.Descriptor = descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(270583070840)
            
            //--TRIMMABLE-BOUNDARY-START(274878038136)
            /*void */ WriteWebAssemblyData(/*string*/ assembly, /*string*/ typeName, /*string*/ parameterDefinitions, /*string*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878038136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assembly = assembly;
                this.TypeName = typeName;
                this.ParameterDefinitions = parameterDefinitions;
                this.ParameterValues = parameterValues;
            }
            //--TRIMMABLE-BOUNDARY-END(274878038136)
            
            //--TRIMMABLE-BOUNDARY-START(253403201656)
            /*ComponentEndMarker? */ ToEndMarker()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253403201656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PrerenderId === null ? null : (() =>
                    {
                        //new $.$macwa.MAC.ComponentEndMarker()
                        const $t2 = $.$macwa.MAC.ComponentEndMarker;
                        const $i2 = new $t2();
                        $i2.$ctor$2();
                        $i2.PrerenderId = this.PrerenderId;
                        return $i2;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403201656)
            
            //--TRIMMABLE-BOUNDARY-START(64424640632)
            static /*string */ GeneratePrerenderId()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640632);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Guid.NewGuid().ToString$2("N");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424640632)
            
            //--TRIMMABLE-BOUNDARY-START(146029019256)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029019256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let __ca1__;
                /*string?*/ let __ca2__;
                switch(this.Type)
                {
                    case "server"/*ServerMarkerType*/:
                    return `Server Component: ${$.$strNN(this.TypeName)}, Sequence: ${$.$strNN(this.Sequence)}, Key: ${$.$strNN((this.Key?.FormattedComponentKey ?? null))} Descriptor: ${$.$strNN(((__ca1__ = this.Descriptor) !== null ? $.$$.S.String.Substring$1.call(__ca1__, 5) : null))}...`;
                    case "webassembly"/*WebAssemblyMarkerType*/:
                    return `WebAssembly Component: ${$.$strNN(this.TypeName)}, Assembly: ${$.$strNN(this.Assembly)}, Key: ${$.$strNN((this.Key?.FormattedComponentKey ?? null))}`;
                    case "auto"/*AutoMarkerType*/:
                    return `Auto Component: ${$.$strNN(this.TypeName)}, Assembly: ${$.$strNN(this.Assembly)}, Key: ${$.$strNN((this.Key?.FormattedComponentKey ?? null))}, Descriptor: ${$.$strNN(((__ca2__ = this.Descriptor) !== null ? $.$$.S.String.Substring$1.call(__ca2__, 5) : null))}...`;
                    default:
                    return `Unknown Component Type: ${$.$strNN(this.Type)}, Key: ${$.$strNN((this.Key?.FormattedComponentKey ?? null))}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029019256)
            
            //--TRIMMABLE-BOUNDARY-START(42949804152)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804152)
            
            //--TRIMMABLE-BOUNDARY-START(42949804152)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804152)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.PrerenderId = this.PrerenderId;
                copy.Key = this.Key?.$clone() ?? null;
                copy.Sequence = this.Sequence;
                copy.Descriptor = this.Descriptor;
                copy.Assembly = this.Assembly;
                copy.TypeName = this.TypeName;
                copy.ParameterDefinitions = this.ParameterDefinitions;
                copy.ParameterValues = this.ParameterValues;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(150323986552)
                this.Key = null;
                //--TRIMMABLE-BOUNDARY-END(150323986552)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(171798823032)
                    this.ServerMarkerType = "server";
                    //--TRIMMABLE-BOUNDARY-END(171798823032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288103544)
                    this.WebAssemblyMarkerType = "webassembly";
                    //--TRIMMABLE-BOUNDARY-END(266288103544)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738744)
                    this.AutoMarkerType = "auto";
                    //--TRIMMABLE-BOUNDARY-END(51539738744)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131192;
            static $z = 42;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(257698168952),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144117368,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518299768,
        "f": 83886081
      },
      "n": "Type",
      "d": 131192,
      "h": 257698168952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698168952),
//--TRIMMABLE-BOUNDARY-START(163208888440),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964248184,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338430584,
        "f": 83886081
      },
      "n": "PrerenderId",
      "d": 131192,
      "h": 163208888440,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163208888440),
//--TRIMMABLE-BOUNDARY-START(150323986552),
    {
      "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194444408,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568626808,
        "f": 83886081
      },
      "n": "Key",
      "d": 131192,
      "h": 150323986552,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150323986552),
//--TRIMMABLE-BOUNDARY-START(167503855736),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554182776,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928365176,
        "f": 83886081
      },
      "n": "Sequence",
      "d": 131192,
      "h": 167503855736,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503855736),
//--TRIMMABLE-BOUNDARY-START(60129673336),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604509816,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978692216,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 131192,
      "h": 60129673336,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129673336),
//--TRIMMABLE-BOUNDARY-START(47244771448),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014575224,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388757624,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 131192,
      "h": 47244771448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244771448),
//--TRIMMABLE-BOUNDARY-START(261993136248),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051960,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108234360,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 131192,
      "h": 261993136248,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993136248),
//--TRIMMABLE-BOUNDARY-START(154618953848),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784379000,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158561400,
        "f": 83886081
      },
      "n": "ParameterDefinitions",
      "d": 131192,
      "h": 154618953848,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154618953848),
//--TRIMMABLE-BOUNDARY-START(158913921144),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374313592,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748495992,
        "f": 83886081
      },
      "n": "ParameterValues",
      "d": 131192,
      "h": 158913921144,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913921144)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834706040),
    {
      "r": 131192,
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "prerendered",
          "p": 262145
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h
        }
      ],
      "n": "Create",
      "d": 131192,
      "h": 55834706040,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834706040),
//--TRIMMABLE-BOUNDARY-START(270583070840),
    {
      "r": 65537,
      "p": [
        {
          "n": "sequence",
          "p": 655361
        },
        {
          "n": "descriptor",
          "p": 1310721
        }
      ],
      "n": "WriteServerData",
      "d": 131192,
      "h": 270583070840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583070840),
//--TRIMMABLE-BOUNDARY-START(274878038136),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "parameterDefinitions",
          "p": 1310721
        },
        {
          "n": "parameterValues",
          "p": 1310721
        }
      ],
      "n": "WriteWebAssemblyData",
      "d": 131192,
      "h": 274878038136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878038136),
//--TRIMMABLE-BOUNDARY-START(253403201656),
    {
      "r": $.$typeNullable($.$macwa.MAC.ComponentEndMarker).$h,
      "n": "ToEndMarker",
      "d": 131192,
      "h": 253403201656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403201656),
//--TRIMMABLE-BOUNDARY-START(64424640632),
    {
      "r": 1310721,
      "n": "GeneratePrerenderId",
      "d": 131192,
      "h": 64424640632,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424640632),
//--TRIMMABLE-BOUNDARY-START(146029019256),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 131192,
      "h": 146029019256,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029019256)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(171798823032),
    {
      "t": 1310721,
      "n": "ServerMarkerType",
      "d": 131192,
      "h": 171798823032,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798823032),
//--TRIMMABLE-BOUNDARY-START(266288103544),
    {
      "t": 1310721,
      "n": "WebAssemblyMarkerType",
      "d": 131192,
      "h": 266288103544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288103544),
//--TRIMMABLE-BOUNDARY-START(51539738744),
    {
      "t": 1310721,
      "n": "AutoMarkerType",
      "d": 131192,
      "h": 51539738744,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539738744)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42949804152),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131192,
      "h": 42949804152,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949804152)
  ],
  "h": 131192,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentMarker`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentMarker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131192)
        
        

        //--TRIMMABLE-BOUNDARY-START(65656)
        $asm.$str(`$macwa.MAC.ComponentEndMarker`, ($self) => class ComponentEndMarker extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21474902136)
            /*string?*/ PrerenderId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902136)
            
            //--TRIMMABLE-BOUNDARY-START(8590000248)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000248)
            
            //--TRIMMABLE-BOUNDARY-START(8590000248)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000248)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PrerenderId = this.PrerenderId;
                return copy;
            }
            static $h = 65656;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474902136),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934840,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064836728,
        "f": 83886081
      },
      "n": "PrerenderId",
      "d": 65656,
      "h": 21474902136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474902136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000248),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65656,
      "h": 8590000248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000248)
  ],
  "h": 65656
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentEndMarker`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentEndMarker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65656)
        
        

        //--TRIMMABLE-BOUNDARY-START(196728)
        $asm.$str(`$macwa.MAC.ComponentMarkerKey`, ($self) => class ComponentMarkerKey extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180065912)
            $ctor$3(/*string*/ locationHash, /*string?*/ formattedComponentKey)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$tupleUnpack(($tp) =>
                    {
                        this.LocationHash = $tp.Item1;
                        this.FormattedComponentKey = $tp.Item2;
                    }).$v = { Item1: locationHash, Item2: formattedComponentKey };
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065912)
            
            //--TRIMMABLE-BOUNDARY-START(60129738872)
            /*string*/ LocationHash = null;
            //--TRIMMABLE-BOUNDARY-END(60129738872)
            
            //--TRIMMABLE-BOUNDARY-START(30064967800)
            /*string?*/ FormattedComponentKey = null;
            //--TRIMMABLE-BOUNDARY-END(30064967800)
            
            //--TRIMMABLE-BOUNDARY-START(64424706168)
            static /*bool */ op_Equality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424706168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return left.Equals$2($.$clone(right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424706168)
            
            //--TRIMMABLE-BOUNDARY-START(68719673464)
            static /*bool */ op_Inequality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719673464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !($.$macwa.MAC.ComponentMarkerKey.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719673464)
            
            //--TRIMMABLE-BOUNDARY-START(25770000504)
            /*bool */ Equals$2(/*ComponentMarkerKey*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.String.Equals$3(this.LocationHash, other.LocationHash, 4/*StringComparison.Ordinal*/) && $.$$.S.String.Equals$3(this.FormattedComponentKey, other.FormattedComponentKey, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000504)
            
            //--TRIMMABLE-BOUNDARY-START(21475033208)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033208);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$macwa.MAC.ComponentMarkerKey, { set $v($v){ other = $v; } }) && this.Equals$2($.$clone(other));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033208)
            
            //--TRIMMABLE-BOUNDARY-START(55834771576)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834771576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.HashCode.Combine$6($.$$.S.String, $.$$.S.String, this.LocationHash, this.FormattedComponentKey);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834771576)
            
            //--TRIMMABLE-BOUNDARY-START(51539804280)
            /*string */ GetDebuggerDisplay()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `LocationHash: ${$.$strNN(this.LocationHash)}, Key: ${$.$strNN(this.FormattedComponentKey ?? "null")}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539804280)
            
            //--TRIMMABLE-BOUNDARY-START(73014640760)
            /*string? */ Serialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.MAC.ComponentMarkerKey.op_Equality(this, new $.$macwa.MAC.ComponentMarkerKey()) ? null : `${$.$strNN(this.LocationHash)}:${$.$strNN(this.FormattedComponentKey)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640760)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentMarkerKey>.Equals(Microsoft.AspNetCore.Components.ComponentMarkerKey)
            S$IEquatable$Microsoft$AspNetCore$Components$ComponentMarkerKey$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12885098616)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098616)
            
            //--TRIMMABLE-BOUNDARY-START(12885098616)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098616)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.LocationHash = this.LocationHash;
                copy.FormattedComponentKey = this.FormattedComponentKey;
                return copy;
            }
            static $h = 196728;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129738872),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194509944,
        "f": 83886081
      },
      "n": "LocationHash",
      "d": 196728,
      "h": 60129738872,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129738872),
//--TRIMMABLE-BOUNDARY-START(30064967800),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902392,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604575352,
        "f": 83886081
      },
      "n": "FormattedComponentKey",
      "d": 196728,
      "h": 30064967800,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064967800)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770000504),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 196728
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 196728,
      "h": 25770000504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000504),
//--TRIMMABLE-BOUNDARY-START(21475033208),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196728,
      "h": 21475033208,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475033208),
//--TRIMMABLE-BOUNDARY-START(55834771576),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196728,
      "h": 55834771576,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834771576),
//--TRIMMABLE-BOUNDARY-START(51539804280),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 196728,
      "h": 51539804280,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539804280),
//--TRIMMABLE-BOUNDARY-START(73014640760),
    {
      "r": 1310721,
      "n": "Serialized",
      "d": 196728,
      "h": 73014640760,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014640760)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065912),
    {
      "p": [
        {
          "n": "locationHash",
          "p": 1310721
        },
        {
          "n": "formattedComponentKey",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196728,
      "h": 17180065912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065912),
//--TRIMMABLE-BOUNDARY-START(12885098616),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196728,
      "h": 12885098616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098616)
  ],
  "h": 196728,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$macwa.MAC.ComponentMarkerKey) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ComponentMarkerKey`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ComponentMarkerKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196728)
        
        

        //--TRIMMABLE-BOUNDARY-START(2687096)
        $asm.$cls(`$macwa.MACWI.WebAssemblyJsonSerializerContext`, ($self) => class WebAssemblyJsonSerializerContext extends $.$stj.STJS$1.JsonSerializerContext
        {
            //--TRIMMABLE-BOUNDARY-START(34362425464)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>?*/ _JsonElement = null;
            //--TRIMMABLE-BOUNDARY-END(34362425464)
            
            //--TRIMMABLE-BOUNDARY-START(493923926136)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ get JsonElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347895038072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._JsonElement ??= $.$cast(this.Options.GetTypeInfo($.$stj.STJ.JsonElement.$type), $.$stj.STJSM.JsonTypeInfo$$($.$stj.STJ.JsonElement));
            }
            //--TRIMMABLE-BOUNDARY-END(493923926136)
            
            //--TRIMMABLE-BOUNDARY-START(193276215416)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ Create_JsonElement(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276215416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$stj.STJ.JsonElement, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$stj.STJ.JsonElement))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$stj.STJ.JsonElement, options, $.$stj.STJSM.JsonMetadataServices.JsonElementConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(193276215416)
            
            //--TRIMMABLE-BOUNDARY-START(25772490872)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>?*/ _Int32 = null;
            //--TRIMMABLE-BOUNDARY-END(25772490872)
            
            //--TRIMMABLE-BOUNDARY-START(485333991544)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ get Int32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330715168888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Int32 ??= $.$cast(this.Options.GetTypeInfo($.$$.S.Int32.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(485333991544)
            
            //--TRIMMABLE-BOUNDARY-START(184686280824)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ Create_Int32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686280824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.Int32, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int32))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.Int32, options, $.$stj.STJSM.JsonMetadataServices.Int32Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(184686280824)
            
            //--TRIMMABLE-BOUNDARY-START(30067458168)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>?*/ _Int64 = null;
            //--TRIMMABLE-BOUNDARY-END(30067458168)
            
            //--TRIMMABLE-BOUNDARY-START(489628958840)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ get Int64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339305103480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Int64 ??= $.$cast(this.Options.GetTypeInfo($.$$.S.Int64.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(489628958840)
            
            //--TRIMMABLE-BOUNDARY-START(188981248120)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ Create_Int64(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981248120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.Int64, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int64))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.Int64, options, $.$stj.STJSM.JsonMetadataServices.Int64Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(188981248120)
            
            //--TRIMMABLE-BOUNDARY-START(42952360056)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>?*/ _NullableComponentMarkerKey = null;
            //--TRIMMABLE-BOUNDARY-END(42952360056)
            
            //--TRIMMABLE-BOUNDARY-START(502513860728)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ get NullableComponentMarkerKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074907256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)));
            }
            //--TRIMMABLE-BOUNDARY-END(502513860728)
            
            //--TRIMMABLE-BOUNDARY-START(201866150008)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ Create_NullableComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866150008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.MAC.ComponentMarkerKey), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.STJSM.JsonMetadataServices.GetNullableConverter($.$macwa.MAC.ComponentMarkerKey, options);
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.MAC.ComponentMarkerKey), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(201866150008)
            
            //--TRIMMABLE-BOUNDARY-START(81607065720)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>?*/ _Type = null;
            //--TRIMMABLE-BOUNDARY-END(81607065720)
            
            //--TRIMMABLE-BOUNDARY-START(661427650680)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442384318584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Type ??= $.$cast(this.Options.GetTypeInfo($.$$.S.Type.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Type));
            }
            //--TRIMMABLE-BOUNDARY-END(661427650680)
            
            //--TRIMMABLE-BOUNDARY-START(240520855672)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ Create_Type(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520855672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.Type, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Type))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.Type, options, $.$stj.STJSM.JsonMetadataServices.GetUnsupportedTypeConverter($.$$.S.Type));
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(240520855672)
            
            //--TRIMMABLE-BOUNDARY-START(21477523576)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>?*/ _IListObject = null;
            //--TRIMMABLE-BOUNDARY-END(21477523576)
            
            //--TRIMMABLE-BOUNDARY-START(476744056952)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ get IListObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322125234296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._IListObject ??= $.$cast(this.Options.GetTypeInfo($.$$.SCG.IList$$($.$$.S.Object).$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.IList$$($.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(476744056952)
            
            //--TRIMMABLE-BOUNDARY-START(180391313528)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ Create_IListObject(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391313528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.SCG.IList$$($.$$.S.Object), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.IList$$($.$$.S.Object)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.STJSM.JsonCollectionInfoValues$$($.$$.SCG.IList$$($.$$.S.Object))()
                        const $t7 = $.$stj.STJSM.JsonCollectionInfoValues$$($.$$.SCG.IList$$($.$$.S.Object));
                        const $i7 = new $t7();
                        $i7.$ctor$1();
                        $i7.ObjectCreator = null;
                        $i7.SerializeHandler = null;
                        return $i7;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateIListInfo($.$$.SCG.IList$$($.$$.S.Object), $.$$.S.Object, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(180391313528)
            
            //--TRIMMABLE-BOUNDARY-START(468154122360)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468154122360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.STJSM.JsonTypeInfo));
                return typeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(468154122360)
            
            //--TRIMMABLE-BOUNDARY-START(472449089656)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ STJSM$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449089656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === $.$macwa.MAC.ComponentMarker.$type)
                {
                    return this.Create_ComponentMarker(options);
                }
                if (type === $.$typeNullable($.$macwa.MAC.ComponentMarker).$type)
                {
                    return this.Create_NullableComponentMarker(options);
                }
                if (type === $.$macwa.MAC.ComponentMarkerKey.$type)
                {
                    return this.Create_ComponentMarkerKey(options);
                }
                if (type === $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$type)
                {
                    return this.Create_NullableComponentMarkerKey(options);
                }
                if (type === $.$macwa.MAC.ComponentParameter.$type)
                {
                    return this.Create_ComponentParameter(options);
                }
                if (type === $.$typeArray($.$macwa.MAC.ComponentParameter).$type)
                {
                    return this.Create_ComponentParameterArray(options);
                }
                if (type === $.$mac.MAC.ParameterView.$type)
                {
                    return this.Create_ParameterView(options);
                }
                if (type === $.$macwa.MAC.RootComponentOperation.$type)
                {
                    return this.Create_RootComponentOperation(options);
                }
                if (type === $.$typeArray($.$macwa.MAC.RootComponentOperation).$type)
                {
                    return this.Create_RootComponentOperationArray(options);
                }
                if (type === $.$macwa.MAC.RootComponentOperationBatch.$type)
                {
                    return this.Create_RootComponentOperationBatch(options);
                }
                if (type === $.$macwa.MAC.RootComponentOperationType.$type)
                {
                    return this.Create_RootComponentOperationType(options);
                }
                if (type === $.$macwa.MAC.WebRootComponentDescriptor.$type)
                {
                    return this.Create_WebRootComponentDescriptor(options);
                }
                if (type === $.$macwa.MAC.WebRootComponentParameters.$type)
                {
                    return this.Create_WebRootComponentParameters(options);
                }
                if (type === $.$$.SCG.IList$$($.$$.S.Object).$type)
                {
                    return this.Create_IListObject(options);
                }
                if (type === $.$stj.STJ.JsonElement.$type)
                {
                    return this.Create_JsonElement(options);
                }
                if (type === $.$$.S.Type.$type)
                {
                    return this.Create_Type(options);
                }
                if (type === $.$$.S.Int32.$type)
                {
                    return this.Create_Int32(options);
                }
                if (type === $.$typeNullable($.$$.S.Int32).$type)
                {
                    return this.Create_NullableInt32(options);
                }
                if (type === $.$$.S.Int64.$type)
                {
                    return this.Create_Int64(options);
                }
                if (type === $.$$.S.Object.$type)
                {
                    return this.Create_Object(options);
                }
                if (type === $.$$.S.String.$type)
                {
                    return this.Create_String(options);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(472449089656)
            
            //--TRIMMABLE-BOUNDARY-START(77312098424)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            //--TRIMMABLE-BOUNDARY-END(77312098424)
            
            //--TRIMMABLE-BOUNDARY-START(652837716088)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433794383992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$$.S.String.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String));
            }
            //--TRIMMABLE-BOUNDARY-END(652837716088)
            
            //--TRIMMABLE-BOUNDARY-START(236225888376)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225888376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.String, options, $.$stj.STJSM.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(236225888376)
            
            //--TRIMMABLE-BOUNDARY-START(64427196536)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>?*/ _RootComponentOperationArray = null;
            //--TRIMMABLE-BOUNDARY-END(64427196536)
            
            //--TRIMMABLE-BOUNDARY-START(609888043128)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ get RootComponentOperationArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408024580216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.MAC.RootComponentOperation).$type), $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.RootComponentOperation)));
            }
            //--TRIMMABLE-BOUNDARY-END(609888043128)
            
            //--TRIMMABLE-BOUNDARY-START(223340986488)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ Create_RootComponentOperationArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340986488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.MAC.RootComponentOperation), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.RootComponentOperation)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.STJSM.JsonCollectionInfoValues$$($.$typeArray($.$macwa.MAC.RootComponentOperation))()
                        const $t11 = $.$stj.STJSM.JsonCollectionInfoValues$$($.$typeArray($.$macwa.MAC.RootComponentOperation));
                        const $i11 = new $t11();
                        $i11.$ctor$1();
                        $i11.ObjectCreator = null;
                        $i11.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$typeArray($.$macwa.MAC.RootComponentOperation)))().$ctor(this, this.RootComponentOperationArraySerializeHandler);
                        return $i11;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateArrayInfo($.$macwa.MAC.RootComponentOperation, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(223340986488)
            
            //--TRIMMABLE-BOUNDARY-START(614183010424)
            /*void */ RootComponentOperationArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614183010424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.RootComponentOperationSerializeHandler(writer, $.$$.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            //--TRIMMABLE-BOUNDARY-END(614183010424)
            
            //--TRIMMABLE-BOUNDARY-START(597003141240)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_type;
            //--TRIMMABLE-BOUNDARY-END(597003141240)
            
            //--TRIMMABLE-BOUNDARY-START(584118239352)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_prerenderId;
            //--TRIMMABLE-BOUNDARY-END(584118239352)
            
            //--TRIMMABLE-BOUNDARY-START(549758500984)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_key;
            //--TRIMMABLE-BOUNDARY-END(549758500984)
            
            //--TRIMMABLE-BOUNDARY-START(588413206648)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_sequence;
            //--TRIMMABLE-BOUNDARY-END(588413206648)
            
            //--TRIMMABLE-BOUNDARY-START(541168566392)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_descriptor;
            //--TRIMMABLE-BOUNDARY-END(541168566392)
            
            //--TRIMMABLE-BOUNDARY-START(528283664504)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_assembly;
            //--TRIMMABLE-BOUNDARY-END(528283664504)
            
            //--TRIMMABLE-BOUNDARY-START(601298108536)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_typeName;
            //--TRIMMABLE-BOUNDARY-END(601298108536)
            
            //--TRIMMABLE-BOUNDARY-START(571233337464)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterDefinitions;
            //--TRIMMABLE-BOUNDARY-END(571233337464)
            
            //--TRIMMABLE-BOUNDARY-START(579823272056)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterValues;
            //--TRIMMABLE-BOUNDARY-END(579823272056)
            
            //--TRIMMABLE-BOUNDARY-START(554053468280)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_locationHash;
            //--TRIMMABLE-BOUNDARY-END(554053468280)
            
            //--TRIMMABLE-BOUNDARY-START(545463533688)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_formattedComponentKey;
            //--TRIMMABLE-BOUNDARY-END(545463533688)
            
            //--TRIMMABLE-BOUNDARY-START(562643402872)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_name;
            //--TRIMMABLE-BOUNDARY-END(562643402872)
            
            //--TRIMMABLE-BOUNDARY-START(592708173944)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_ssrComponentId;
            //--TRIMMABLE-BOUNDARY-END(592708173944)
            
            //--TRIMMABLE-BOUNDARY-START(558348435576)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_marker;
            //--TRIMMABLE-BOUNDARY-END(558348435576)
            
            //--TRIMMABLE-BOUNDARY-START(532578631800)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_batchId;
            //--TRIMMABLE-BOUNDARY-END(532578631800)
            
            //--TRIMMABLE-BOUNDARY-START(566938370168)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_operations;
            //--TRIMMABLE-BOUNDARY-END(566938370168)
            
            //--TRIMMABLE-BOUNDARY-START(536873599096)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_componentType;
            //--TRIMMABLE-BOUNDARY-END(536873599096)
            
            //--TRIMMABLE-BOUNDARY-START(575528304760)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameters;
            //--TRIMMABLE-BOUNDARY-END(575528304760)
            
            //--TRIMMABLE-BOUNDARY-START(47247327352)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>?*/ _NullableInt32 = null;
            //--TRIMMABLE-BOUNDARY-END(47247327352)
            
            //--TRIMMABLE-BOUNDARY-START(506808828024)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ get NullableInt32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664841848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableInt32 ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$$.S.Int32).$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(506808828024)
            
            //--TRIMMABLE-BOUNDARY-START(206161117304)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ Create_NullableInt32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161117304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$$.S.Int32), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$$.S.Int32)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.STJSM.JsonMetadataServices.GetNullableConverter($.$$.S.Int32, options);
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$$.S.Int32), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(206161117304)
            
            //--TRIMMABLE-BOUNDARY-START(17182556280)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>?*/ _ComponentParameterArray = null;
            //--TRIMMABLE-BOUNDARY-END(17182556280)
            
            //--TRIMMABLE-BOUNDARY-START(146031575160)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ get ComponentParameterArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355430520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentParameterArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.MAC.ComponentParameter).$type), $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.ComponentParameter)));
            }
            //--TRIMMABLE-BOUNDARY-END(146031575160)
            
            //--TRIMMABLE-BOUNDARY-START(176096346232)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ Create_ComponentParameterArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096346232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.MAC.ComponentParameter), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.ComponentParameter)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.STJSM.JsonCollectionInfoValues$$($.$typeArray($.$macwa.MAC.ComponentParameter))()
                        const $t14 = $.$stj.STJSM.JsonCollectionInfoValues$$($.$typeArray($.$macwa.MAC.ComponentParameter));
                        const $i14 = new $t14();
                        $i14.$ctor$1();
                        $i14.ObjectCreator = null;
                        $i14.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$typeArray($.$macwa.MAC.ComponentParameter)))().$ctor(this, this.ComponentParameterArraySerializeHandler);
                        return $i14;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateArrayInfo($.$macwa.MAC.ComponentParameter, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(176096346232)
            
            //--TRIMMABLE-BOUNDARY-START(150326542456)
            /*void */ ComponentParameterArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326542456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.ComponentParameterSerializeHandler(writer, $.$$.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            //--TRIMMABLE-BOUNDARY-END(150326542456)
            
            //--TRIMMABLE-BOUNDARY-START(55837261944)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>?*/ _ParameterView = null;
            //--TRIMMABLE-BOUNDARY-END(55837261944)
            
            //--TRIMMABLE-BOUNDARY-START(515398762616)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ get ParameterView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844711032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ParameterView ??= $.$cast(this.Options.GetTypeInfo($.$mac.MAC.ParameterView.$type), $.$stj.STJSM.JsonTypeInfo$$($.$mac.MAC.ParameterView));
            }
            //--TRIMMABLE-BOUNDARY-END(515398762616)
            
            //--TRIMMABLE-BOUNDARY-START(214751051896)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ Create_ParameterView(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751051896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$mac.MAC.ParameterView, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$mac.MAC.ParameterView))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$mac.MAC.ParameterView)()
                        const $t16 = $.$stj.STJSM.JsonObjectInfoValues$$($.$mac.MAC.ParameterView);
                        const $i16 = new $t16();
                        $i16.$ctor$1();
                        $i16.ObjectCreator = new ($.$$.S.Func$$($.$mac.MAC.ParameterView))().$ctor(this,  () =>
                        {
                            return new $.$mac.MAC.ParameterView().$ctor$2();
                        }, $JiViwa ??= {"r":5767283,"n":"","d":2687096,"h":0,"f":17825794});
                        $i16.ObjectWithParameterizedConstructorCreator = null;
                        $i16.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ParameterViewPropInit(options);
                        }, $yRuptc ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i16.ConstructorParameterMetadataInitializer = null;
                        $i16.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$mac.MAC.ParameterView.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $qEtZWj ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i16.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$mac.MAC.ParameterView))().$ctor(this, this.ParameterViewSerializeHandler);
                        return $i16;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$mac.MAC.ParameterView, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(214751051896)
            
            //--TRIMMABLE-BOUNDARY-START(519693729912)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ParameterViewPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519693729912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [0], null);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(519693729912)
            
            //--TRIMMABLE-BOUNDARY-START(523988697208)
            /*void */ ParameterViewSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ParameterView*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523988697208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(523988697208)
            
            //--TRIMMABLE-BOUNDARY-START(51542294648)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>?*/ _Object = null;
            //--TRIMMABLE-BOUNDARY-END(51542294648)
            
            //--TRIMMABLE-BOUNDARY-START(511103795320)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ get Object()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254776440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Object ??= $.$cast(this.Options.GetTypeInfo($.$$.S.Object.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(511103795320)
            
            //--TRIMMABLE-BOUNDARY-START(210456084600)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ Create_Object(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210456084600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.Object, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Object))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.Object, options, $.$stj.STJSM.JsonMetadataServices.ObjectConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(210456084600)
            
            //--TRIMMABLE-BOUNDARY-START(90197000312)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>?*/ _WebRootComponentParameters = null;
            //--TRIMMABLE-BOUNDARY-END(90197000312)
            
            //--TRIMMABLE-BOUNDARY-START(682902487160)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ get WebRootComponentParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459564187768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._WebRootComponentParameters ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.WebRootComponentParameters.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentParameters));
            }
            //--TRIMMABLE-BOUNDARY-END(682902487160)
            
            //--TRIMMABLE-BOUNDARY-START(249110790264)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ Create_WebRootComponentParameters(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110790264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.WebRootComponentParameters, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentParameters))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.WebRootComponentParameters)()
                        const $t19 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.WebRootComponentParameters);
                        const $i19 = new $t19();
                        $i19.$ctor$1();
                        $i19.ObjectCreator = new ($.$$.S.Func$$($.$macwa.MAC.WebRootComponentParameters))().$ctor(this,  () =>
                        {
                            return new $.$macwa.MAC.WebRootComponentParameters().$ctor$2();
                        }, $nAHPoj ??= {"r":4391032,"n":"","d":2687096,"h":0,"f":17825794});
                        $i19.ObjectWithParameterizedConstructorCreator = null;
                        $i19.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.WebRootComponentParametersPropInit(options);
                        }, $wjwnFh ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i19.ConstructorParameterMetadataInitializer = null;
                        $i19.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.WebRootComponentParameters.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $HeaYOg ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i19.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.WebRootComponentParameters))().$ctor(this, this.WebRootComponentParametersSerializeHandler);
                        return $i19;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.WebRootComponentParameters, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(249110790264)
            
            //--TRIMMABLE-BOUNDARY-START(687197454456)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentParametersPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687197454456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [1], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$mac.MAC.ParameterView)()
                    const $t20 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$mac.MAC.ParameterView);
                    const $i20 = new $t20();
                    $i20.$ctor$1();
                    $i20.IsProperty = true;
                    $i20.IsPublic = true;
                    $i20.IsVirtual = false;
                    $i20.DeclaringType = $.$macwa.MAC.WebRootComponentParameters.$type;
                    $i20.Converter = null;
                    $i20.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$mac.MAC.ParameterView))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.WebRootComponentParameters)).Parameters;
                    }, $sFcuBk ??= {"r":5767283,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i20.Setter = null;
                    $i20.IgnoreCondition = null;
                    $i20.HasJsonInclude = false;
                    $i20.IsExtensionData = false;
                    $i20.NumberHandling = null;
                    $i20.PropertyName = "Parameters";
                    $i20.JsonPropertyName = null;
                    $i20.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.WebRootComponentParameters.$type.GetProperty("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$mac.MAC.ParameterView.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $REnbaa ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i20;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$mac.MAC.ParameterView, options, info0), 0);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(687197454456)
            
            //--TRIMMABLE-BOUNDARY-START(691492421752)
            /*void */ WebRootComponentParametersSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentParameters*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691492421752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.ParameterViewSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(691492421752)
            
            //--TRIMMABLE-BOUNDARY-START(8592621688)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>?*/ _ComponentMarkerKey = null;
            //--TRIMMABLE-BOUNDARY-END(8592621688)
            
            //--TRIMMABLE-BOUNDARY-START(120261771384)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ get ComponentMarkerKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175561336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.ComponentMarkerKey.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarkerKey));
            }
            //--TRIMMABLE-BOUNDARY-END(120261771384)
            
            //--TRIMMABLE-BOUNDARY-START(167506411640)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ Create_ComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506411640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.ComponentMarkerKey, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarkerKey))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentMarkerKey)()
                        const $t22 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentMarkerKey);
                        const $i22 = new $t22();
                        $i22.$ctor$1();
                        $i22.ObjectCreator = new ($.$$.S.Func$$($.$macwa.MAC.ComponentMarkerKey))().$ctor(this,  () =>
                        {
                            return new $.$macwa.MAC.ComponentMarkerKey().$ctor$2();
                        }, $LFOBYg ??= {"r":196728,"n":"","d":2687096,"h":0,"f":17825794});
                        $i22.ObjectWithParameterizedConstructorCreator = null;
                        $i22.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ComponentMarkerKeyPropInit(options);
                        }, $TSvgpi ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i22.ConstructorParameterMetadataInitializer = null;
                        $i22.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.ComponentMarkerKey.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $cBlUqc ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i22.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.ComponentMarkerKey))().$ctor(this, this.ComponentMarkerKeySerializeHandler);
                        return $i22;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.ComponentMarkerKey, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(167506411640)
            
            //--TRIMMABLE-BOUNDARY-START(124556738680)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerKeyPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556738680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t23 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i23 = new $t23();
                    $i23.$ctor$1();
                    $i23.IsProperty = true;
                    $i23.IsPublic = true;
                    $i23.IsVirtual = false;
                    $i23.DeclaringType = $.$macwa.MAC.ComponentMarkerKey.$type;
                    $i23.Converter = null;
                    $i23.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarkerKey)).LocationHash;
                    }, $QnuFJf ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i23.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarkerKey, obj).$v.LocationHash = value;
                    }, $RYRNcj ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i23.IgnoreCondition = null;
                    $i23.HasJsonInclude = false;
                    $i23.IsExtensionData = false;
                    $i23.NumberHandling = null;
                    $i23.PropertyName = "LocationHash";
                    $i23.JsonPropertyName = null;
                    $i23.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarkerKey.$type.GetProperty("LocationHash", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $TxjQNh ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i23;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t24 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i24 = new $t24();
                    $i24.$ctor$1();
                    $i24.IsProperty = true;
                    $i24.IsPublic = true;
                    $i24.IsVirtual = false;
                    $i24.DeclaringType = $.$macwa.MAC.ComponentMarkerKey.$type;
                    $i24.Converter = null;
                    $i24.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarkerKey)).FormattedComponentKey;
                    }, $sGCMoj ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i24.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarkerKey, obj).$v.FormattedComponentKey = value;
                    }, $kRThKc ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i24.IgnoreCondition = null;
                    $i24.HasJsonInclude = false;
                    $i24.IsExtensionData = false;
                    $i24.NumberHandling = null;
                    $i24.PropertyName = "FormattedComponentKey";
                    $i24.JsonPropertyName = null;
                    $i24.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarkerKey.$type.GetProperty("FormattedComponentKey", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $Nbkque ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i24;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info1), 1);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(124556738680)
            
            //--TRIMMABLE-BOUNDARY-START(128851705976)
            /*void */ ComponentMarkerKeySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851705976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_LocationHash = (value).LocationHash;
                if (!(__value_LocationHash === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_locationHash, __value_LocationHash);
                }
                /*string*/ let __value_FormattedComponentKey = (value).FormattedComponentKey;
                if (!(__value_FormattedComponentKey === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_formattedComponentKey, __value_FormattedComponentKey);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(128851705976)
            
            //--TRIMMABLE-BOUNDARY-START(73017131128)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>?*/ _RootComponentOperationType = null;
            //--TRIMMABLE-BOUNDARY-END(73017131128)
            
            //--TRIMMABLE-BOUNDARY-START(644247781496)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ get RootComponentOperationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204449400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationType ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.RootComponentOperationType.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationType));
            }
            //--TRIMMABLE-BOUNDARY-END(644247781496)
            
            //--TRIMMABLE-BOUNDARY-START(231930921080)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ Create_RootComponentOperationType(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930921080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.RootComponentOperationType, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationType))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ExpandConverter($.$macwa.MAC.RootComponentOperationType.$type, new ($.$stj.STJS$1.JsonStringEnumConverter$$($.$macwa.MAC.RootComponentOperationType))().$ctor$3(), options, true);
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$macwa.MAC.RootComponentOperationType, options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(231930921080)
            
            //--TRIMMABLE-BOUNDARY-START(38657392760)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>?*/ _NullableComponentMarker = null;
            //--TRIMMABLE-BOUNDARY-END(38657392760)
            
            //--TRIMMABLE-BOUNDARY-START(498218893432)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ get NullableComponentMarker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484972664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.MAC.ComponentMarker).$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)));
            }
            //--TRIMMABLE-BOUNDARY-END(498218893432)
            
            //--TRIMMABLE-BOUNDARY-START(197571182712)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ Create_NullableComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571182712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.MAC.ComponentMarker), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.STJSM.JsonMetadataServices.GetNullableConverter($.$macwa.MAC.ComponentMarker, options);
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.MAC.ComponentMarker), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(197571182712)
            
            //--TRIMMABLE-BOUNDARY-START(648542748792)
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            //--TRIMMABLE-BOUNDARY-END(648542748792)
            
            //--TRIMMABLE-BOUNDARY-START(481039024248)
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            //--TRIMMABLE-BOUNDARY-END(481039024248)
            
            //--TRIMMABLE-BOUNDARY-START(253405757560)
            /*global::Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(253405757560)
            
            //--TRIMMABLE-BOUNDARY-START(261995692152)
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(261995692152)
            
            //--TRIMMABLE-BOUNDARY-START(107376869496)
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107376869496);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(107376869496)
            
            //--TRIMMABLE-BOUNDARY-START(111671836792)
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111671836792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(111671836792)
            
            //--TRIMMABLE-BOUNDARY-START(657132683384)
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657132683384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.MACWI.WebAssemblyJsonSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(657132683384)
            
            //--TRIMMABLE-BOUNDARY-START(463859155064)
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859155064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < options.Converters.SCG$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.SCG$IList$$$get_Item(i);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(463859155064)
            
            //--TRIMMABLE-BOUNDARY-START(257700724856)
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700724856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$$.S.String.Format$8("The converter '{0}' is not compatible with the type '{1}'.", $.$$.S.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.STJS$1.JsonConverterFactory, { set $v($v){ factory = $v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.STJS$1.JsonConverterFactory))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$$.S.String.Format$9("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$$.S.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            //--TRIMMABLE-BOUNDARY-END(257700724856)
            
            //--TRIMMABLE-BOUNDARY-START(68722163832)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>?*/ _RootComponentOperationBatch = null;
            //--TRIMMABLE-BOUNDARY-END(68722163832)
            
            //--TRIMMABLE-BOUNDARY-START(618477977720)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ get RootComponentOperationBatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416614514808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationBatch ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.RootComponentOperationBatch.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationBatch));
            }
            //--TRIMMABLE-BOUNDARY-END(618477977720)
            
            //--TRIMMABLE-BOUNDARY-START(227635953784)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ Create_RootComponentOperationBatch(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635953784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.RootComponentOperationBatch, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationBatch))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.RootComponentOperationBatch)()
                        const $t28 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.RootComponentOperationBatch);
                        const $i28 = new $t28();
                        $i28.$ctor$1();
                        $i28.ObjectCreator = null;
                        $i28.ObjectWithParameterizedConstructorCreator = new ($.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$macwa.MAC.RootComponentOperationBatch))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return (() =>
                            {
                                //new $.$macwa.MAC.RootComponentOperationBatch()
                                const $t29 = $.$macwa.MAC.RootComponentOperationBatch;
                                const $i29 = new $t29();
                                $i29.$ctor$1();
                                $i29.Operations = $.$cast($.$$.System.Array.$ReadT1.call(args, 0), $.$typeArray($.$macwa.MAC.RootComponentOperation));
                                return $i29;
                            })();
                        }, $mqIZZa ??= {"r":1048696,"p":[{"n":"args","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                        $i28.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.RootComponentOperationBatchPropInit(options);
                        }, $bpbJof ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i28.ConstructorParameterMetadataInitializer = new ($.$$.S.Func$$($.$typeArray($.$stj.STJSM.JsonParameterInfoValues)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, $.$macwa.MACWI.WebAssemblyJsonSerializerContext.RootComponentOperationBatchCtorParamInit);
                        $i28.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.RootComponentOperationBatch.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $enZOmg ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i28.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.RootComponentOperationBatch))().$ctor(this, this.RootComponentOperationBatchSerializeHandler);
                        return $i28;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.RootComponentOperationBatch, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(227635953784)
            
            //--TRIMMABLE-BOUNDARY-START(627067912312)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationBatchPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627067912312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Int64)()
                    const $t30 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Int64);
                    const $i30 = new $t30();
                    $i30.$ctor$1();
                    $i30.IsProperty = true;
                    $i30.IsPublic = true;
                    $i30.IsVirtual = false;
                    $i30.DeclaringType = $.$macwa.MAC.RootComponentOperationBatch.$type;
                    $i30.Converter = null;
                    $i30.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Int64))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperationBatch)).BatchId;
                    }, $nPqWXf ??= {"r":917505,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i30.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.Int64))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperationBatch)).BatchId = value;
                    }, $FfASHd ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":917505}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i30.IgnoreCondition = null;
                    $i30.HasJsonInclude = false;
                    $i30.IsExtensionData = false;
                    $i30.NumberHandling = null;
                    $i30.PropertyName = "BatchId";
                    $i30.JsonPropertyName = null;
                    $i30.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperationBatch.$type.GetProperty("BatchId", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.Int64.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $ofiNzk ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i30;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.Int64, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$typeArray($.$macwa.MAC.RootComponentOperation))()
                    const $t31 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$typeArray($.$macwa.MAC.RootComponentOperation));
                    const $i31 = new $t31();
                    $i31.$ctor$1();
                    $i31.IsProperty = true;
                    $i31.IsPublic = true;
                    $i31.IsVirtual = false;
                    $i31.DeclaringType = $.$macwa.MAC.RootComponentOperationBatch.$type;
                    $i31.Converter = null;
                    $i31.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$typeArray($.$macwa.MAC.RootComponentOperation)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperationBatch)).Operations;
                    }, $bfVTAg ??= {"r":$.$typeArray($.$macwa.MAC.RootComponentOperation).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i31.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$typeArray($.$macwa.MAC.RootComponentOperation)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperationBatch)).Operations = value;
                    }, $Qhesxg ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeArray($.$macwa.MAC.RootComponentOperation).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i31.IgnoreCondition = null;
                    $i31.HasJsonInclude = false;
                    $i31.IsExtensionData = false;
                    $i31.NumberHandling = null;
                    $i31.PropertyName = "Operations";
                    $i31.JsonPropertyName = null;
                    $i31.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperationBatch.$type.GetProperty("Operations", 52/*InstanceMemberBindingFlags*/, null, $.$typeArray($.$macwa.MAC.RootComponentOperation).$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $lCrrBb ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i31;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$typeArray($.$macwa.MAC.RootComponentOperation), options, info1), 1);
                $.$$.System.Array.$ReadT1.call(properties, 1).IsRequired = true;
                $.$$.System.Array.$ReadT1.call(properties, 1).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 1).IsSetNullable = false;
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(627067912312)
            
            //--TRIMMABLE-BOUNDARY-START(631362879608)
            /*void */ RootComponentOperationBatchSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperationBatch?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631362879608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WriteNumber$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_batchId, (value).BatchId);
                /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]*/ let __value_Operations = (value).Operations;
                if (!(__value_Operations === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_operations);
                    this.RootComponentOperationArraySerializeHandler(writer, __value_Operations);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(631362879608)
            
            //--TRIMMABLE-BOUNDARY-START(622772945016)
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ RootComponentOperationBatchCtorParamInit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(622772945016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonParameterInfoValues), [(() =>
                    {
                        //new $.$stj.STJSM.JsonParameterInfoValues()
                        const $t32 = $.$stj.STJSM.JsonParameterInfoValues;
                        const $i32 = new $t32();
                        $i32.$ctor$1();
                        $i32.Name = "Operations";
                        $i32.ParameterType = $.$typeArray($.$macwa.MAC.RootComponentOperation).$type;
                        $i32.Position = 0;
                        $i32.IsNullable = false;
                        $i32.IsMemberInitializer = true;
                        return $i32;
                    })()], [-1], null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(622772945016)
            
            //--TRIMMABLE-BOUNDARY-START(12887588984)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>?*/ _ComponentParameter = null;
            //--TRIMMABLE-BOUNDARY-END(12887588984)
            
            //--TRIMMABLE-BOUNDARY-START(141736607864)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ get ComponentParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765495928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentParameter ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.ComponentParameter.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentParameter));
            }
            //--TRIMMABLE-BOUNDARY-END(141736607864)
            
            //--TRIMMABLE-BOUNDARY-START(171801378936)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ Create_ComponentParameter(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801378936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.ComponentParameter, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentParameter))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentParameter)()
                        const $t34 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentParameter);
                        const $i34 = new $t34();
                        $i34.$ctor$1();
                        $i34.ObjectCreator = new ($.$$.S.Func$$($.$macwa.MAC.ComponentParameter))().$ctor(this,  () =>
                        {
                            return new $.$macwa.MAC.ComponentParameter().$ctor$2();
                        }, $GkxiIe ??= {"r":262264,"n":"","d":2687096,"h":0,"f":17825794});
                        $i34.ObjectWithParameterizedConstructorCreator = null;
                        $i34.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ComponentParameterPropInit(options);
                        }, $vFrYed ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i34.ConstructorParameterMetadataInitializer = null;
                        $i34.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.ComponentParameter.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $Amavtk ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i34.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.ComponentParameter))().$ctor(this, this.ComponentParameterSerializeHandler);
                        return $i34;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.ComponentParameter, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(171801378936)
            
            //--TRIMMABLE-BOUNDARY-START(154621509752)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentParameterPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621509752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [3], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t35 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i35 = new $t35();
                    $i35.$ctor$1();
                    $i35.IsProperty = true;
                    $i35.IsPublic = true;
                    $i35.IsVirtual = false;
                    $i35.DeclaringType = $.$macwa.MAC.ComponentParameter.$type;
                    $i35.Converter = null;
                    $i35.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentParameter)).Name;
                    }, $LkpXNd ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i35.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentParameter, obj).$v.Name = value;
                    }, $xsHgXg ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i35.IgnoreCondition = null;
                    $i35.HasJsonInclude = false;
                    $i35.IsExtensionData = false;
                    $i35.NumberHandling = null;
                    $i35.PropertyName = "Name";
                    $i35.JsonPropertyName = null;
                    $i35.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentParameter.$type.GetProperty("Name", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $NGjcfh ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i35;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t36 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i36 = new $t36();
                    $i36.$ctor$1();
                    $i36.IsProperty = true;
                    $i36.IsPublic = true;
                    $i36.IsVirtual = false;
                    $i36.DeclaringType = $.$macwa.MAC.ComponentParameter.$type;
                    $i36.Converter = null;
                    $i36.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentParameter)).TypeName;
                    }, $WnQxoh ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i36.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentParameter, obj).$v.TypeName = value;
                    }, $lkHeBf ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i36.IgnoreCondition = null;
                    $i36.HasJsonInclude = false;
                    $i36.IsExtensionData = false;
                    $i36.NumberHandling = null;
                    $i36.PropertyName = "TypeName";
                    $i36.JsonPropertyName = null;
                    $i36.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentParameter.$type.GetProperty("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $cnJkHe ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i36;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t37 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i37 = new $t37();
                    $i37.$ctor$1();
                    $i37.IsProperty = true;
                    $i37.IsPublic = true;
                    $i37.IsVirtual = false;
                    $i37.DeclaringType = $.$macwa.MAC.ComponentParameter.$type;
                    $i37.Converter = null;
                    $i37.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentParameter)).Assembly;
                    }, $uUgOSj ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i37.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentParameter, obj).$v.Assembly = value;
                    }, $mZgcFh ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i37.IgnoreCondition = null;
                    $i37.HasJsonInclude = false;
                    $i37.IsExtensionData = false;
                    $i37.NumberHandling = null;
                    $i37.PropertyName = "Assembly";
                    $i37.JsonPropertyName = null;
                    $i37.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentParameter.$type.GetProperty("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $pFqSpf ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i37;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info2), 2);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(154621509752)
            
            //--TRIMMABLE-BOUNDARY-START(158916477048)
            /*void */ ComponentParameterSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916477048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_Name = (value).Name;
                if (!(__value_Name === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_name, __value_Name);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(158916477048)
            
            //--TRIMMABLE-BOUNDARY-START(60132229240)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>?*/ _RootComponentOperation = null;
            //--TRIMMABLE-BOUNDARY-END(60132229240)
            
            //--TRIMMABLE-BOUNDARY-START(605593075832)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ get RootComponentOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434645624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperation ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.RootComponentOperation.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperation));
            }
            //--TRIMMABLE-BOUNDARY-END(605593075832)
            
            //--TRIMMABLE-BOUNDARY-START(219046019192)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ Create_RootComponentOperation(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046019192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.RootComponentOperation, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperation))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.RootComponentOperation)()
                        const $t39 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.RootComponentOperation);
                        const $i39 = new $t39();
                        $i39.$ctor$1();
                        $i39.ObjectCreator = new ($.$$.S.Func$$($.$macwa.MAC.RootComponentOperation))().$ctor(this,  () =>
                        {
                            return new $.$macwa.MAC.RootComponentOperation().$ctor$1();
                        }, $FzPOoh ??= {"r":983160,"n":"","d":2687096,"h":0,"f":17825794});
                        $i39.ObjectWithParameterizedConstructorCreator = null;
                        $i39.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.RootComponentOperationPropInit(options);
                        }, $tpUYib ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i39.ConstructorParameterMetadataInitializer = null;
                        $i39.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.RootComponentOperation.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $ZMFLkg ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i39.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.RootComponentOperation))().$ctor(this, this.RootComponentOperationSerializeHandler);
                        return $i39;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.RootComponentOperation, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(219046019192)
            
            //--TRIMMABLE-BOUNDARY-START(635657846904)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635657846904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [4], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.RootComponentOperationType)()
                    const $t40 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.RootComponentOperationType);
                    const $i40 = new $t40();
                    $i40.$ctor$1();
                    $i40.IsProperty = true;
                    $i40.IsPublic = true;
                    $i40.IsVirtual = false;
                    $i40.DeclaringType = $.$macwa.MAC.RootComponentOperation.$type;
                    $i40.Converter = null;
                    $i40.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$macwa.MAC.RootComponentOperationType))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Type;
                    }, $bQzgQd ??= {"r":1114232,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i40.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$macwa.MAC.RootComponentOperationType))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Type = value;
                    }, $hVftSe ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1114232}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i40.IgnoreCondition = null;
                    $i40.HasJsonInclude = false;
                    $i40.IsExtensionData = false;
                    $i40.NumberHandling = null;
                    $i40.PropertyName = "Type";
                    $i40.JsonPropertyName = null;
                    $i40.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperation.$type.GetProperty("Type", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.MAC.RootComponentOperationType.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $IYUOil ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i40;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$macwa.MAC.RootComponentOperationType, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Int32)()
                    const $t41 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Int32);
                    const $i41 = new $t41();
                    $i41.$ctor$1();
                    $i41.IsProperty = true;
                    $i41.IsPublic = true;
                    $i41.IsVirtual = false;
                    $i41.DeclaringType = $.$macwa.MAC.RootComponentOperation.$type;
                    $i41.Converter = null;
                    $i41.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Int32))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).SsrComponentId;
                    }, $grALai ??= {"r":655361,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i41.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.Int32))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).SsrComponentId = value;
                    }, $zbNOHe ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":655361}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i41.IgnoreCondition = null;
                    $i41.HasJsonInclude = false;
                    $i41.IsExtensionData = false;
                    $i41.NumberHandling = null;
                    $i41.PropertyName = "SsrComponentId";
                    $i41.JsonPropertyName = null;
                    $i41.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperation.$type.GetProperty("SsrComponentId", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.Int32.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $ChrJKd ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i41;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.Int32, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker))()
                    const $t42 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker));
                    const $i42 = new $t42();
                    $i42.$ctor$1();
                    $i42.IsProperty = true;
                    $i42.IsPublic = true;
                    $i42.IsVirtual = false;
                    $i42.DeclaringType = $.$macwa.MAC.RootComponentOperation.$type;
                    $i42.Converter = null;
                    $i42.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Marker;
                    }, $iHpDBd ??= {"r":$.$typeNullable($.$macwa.MAC.ComponentMarker).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i42.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Marker = value;
                    }, $DSZlga ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$macwa.MAC.ComponentMarker).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i42.IgnoreCondition = null;
                    $i42.HasJsonInclude = false;
                    $i42.IsExtensionData = false;
                    $i42.NumberHandling = null;
                    $i42.PropertyName = "Marker";
                    $i42.JsonPropertyName = null;
                    $i42.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperation.$type.GetProperty("Marker", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.MAC.ComponentMarker).$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $FxRaud ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i42;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.MAC.ComponentMarker), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.WebRootComponentDescriptor)()
                    const $t43 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.WebRootComponentDescriptor);
                    const $i43 = new $t43();
                    $i43.$ctor$1();
                    $i43.IsProperty = true;
                    $i43.IsPublic = true;
                    $i43.IsVirtual = false;
                    $i43.DeclaringType = $.$macwa.MAC.RootComponentOperation.$type;
                    $i43.Converter = null;
                    $i43.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$macwa.MAC.WebRootComponentDescriptor))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Descriptor;
                    }, $BKyEHd ??= {"r":4325496,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i43.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$macwa.MAC.WebRootComponentDescriptor))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.RootComponentOperation)).Descriptor = value;
                    }, $qcFuSg ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":4325496}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i43.IgnoreCondition = null;
                    $i43.HasJsonInclude = false;
                    $i43.IsExtensionData = false;
                    $i43.NumberHandling = null;
                    $i43.PropertyName = "Descriptor";
                    $i43.JsonPropertyName = null;
                    $i43.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.RootComponentOperation.$type.GetProperty("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.MAC.WebRootComponentDescriptor.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $zqlcwe ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i43;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$macwa.MAC.WebRootComponentDescriptor, options, info3), 3);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(635657846904)
            
            //--TRIMMABLE-BOUNDARY-START(639952814200)
            /*void */ RootComponentOperationSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639952814200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_type);
                $.$stj.STJ.JsonSerializer.Serialize$12($.$macwa.MAC.RootComponentOperationType, writer, (value).Type, this.RootComponentOperationType);
                writer.WriteNumber$25($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_ssrComponentId, (value).SsrComponentId);
                /*global::Microsoft.AspNetCore.Components.ComponentMarker?*/ let __value_Marker = (value).Marker;
                if (!(__value_Marker === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_marker);
                    $.$stj.STJ.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.MAC.ComponentMarker), writer, $.$clone(__value_Marker), this.NullableComponentMarker);
                }
                /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_descriptor);
                    this.WebRootComponentDescriptorSerializeHandler(writer, __value_Descriptor);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(639952814200)
            
            //--TRIMMABLE-BOUNDARY-START(4297654392)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>?*/ _ComponentMarker = null;
            //--TRIMMABLE-BOUNDARY-END(4297654392)
            
            //--TRIMMABLE-BOUNDARY-START(115966804088)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ get ComponentMarker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585626744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.ComponentMarker.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarker));
            }
            //--TRIMMABLE-BOUNDARY-END(115966804088)
            
            //--TRIMMABLE-BOUNDARY-START(163211444344)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ Create_ComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211444344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.ComponentMarker, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarker))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentMarker)()
                        const $t45 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.ComponentMarker);
                        const $i45 = new $t45();
                        $i45.$ctor$1();
                        $i45.ObjectCreator = new ($.$$.S.Func$$($.$macwa.MAC.ComponentMarker))().$ctor(this,  () =>
                        {
                            return new $.$macwa.MAC.ComponentMarker().$ctor$2();
                        }, $yqQujk ??= {"r":131192,"n":"","d":2687096,"h":0,"f":17825794});
                        $i45.ObjectWithParameterizedConstructorCreator = null;
                        $i45.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.ComponentMarkerPropInit(options);
                        }, $IYnuuj ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i45.ConstructorParameterMetadataInitializer = null;
                        $i45.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.ComponentMarker.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.S.Array.Empty($.$$.S.Type), null);
                        }, $EiUJMi ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i45.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.ComponentMarker))().$ctor(this, this.ComponentMarkerSerializeHandler);
                        return $i45;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.ComponentMarker, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(163211444344)
            
            //--TRIMMABLE-BOUNDARY-START(133146673272)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146673272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [9], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t46 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i46 = new $t46();
                    $i46.$ctor$1();
                    $i46.IsProperty = true;
                    $i46.IsPublic = true;
                    $i46.IsVirtual = false;
                    $i46.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i46.Converter = null;
                    $i46.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).Type;
                    }, $CjYLii ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i46.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.Type = value;
                    }, $JzXEGj ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i46.IgnoreCondition = null;
                    $i46.HasJsonInclude = false;
                    $i46.IsExtensionData = false;
                    $i46.NumberHandling = null;
                    $i46.PropertyName = "Type";
                    $i46.JsonPropertyName = null;
                    $i46.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("Type", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $phwCWb ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i46;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t47 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i47 = new $t47();
                    $i47.$ctor$1();
                    $i47.IsProperty = true;
                    $i47.IsPublic = true;
                    $i47.IsVirtual = false;
                    $i47.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i47.Converter = null;
                    $i47.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).PrerenderId;
                    }, $KGxtda ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i47.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.PrerenderId = value;
                    }, $NQIyId ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i47.IgnoreCondition = null;
                    $i47.HasJsonInclude = false;
                    $i47.IsExtensionData = false;
                    $i47.NumberHandling = null;
                    $i47.PropertyName = "PrerenderId";
                    $i47.JsonPropertyName = null;
                    $i47.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("PrerenderId", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $NKbRSd ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i47;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey))()
                    const $t48 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey));
                    const $i48 = new $t48();
                    $i48.$ctor$1();
                    $i48.IsProperty = true;
                    $i48.IsPublic = true;
                    $i48.IsVirtual = false;
                    $i48.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i48.Converter = null;
                    $i48.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).Key;
                    }, $GNhlja ??= {"r":$.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i48.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.Key = value;
                    }, $ZaLeSk ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i48.IgnoreCondition = null;
                    $i48.HasJsonInclude = false;
                    $i48.IsExtensionData = false;
                    $i48.NumberHandling = null;
                    $i48.PropertyName = "Key";
                    $i48.JsonPropertyName = null;
                    $i48.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("Key", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $kfuzIc ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i48;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.MAC.ComponentMarkerKey), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$$.S.Int32))()
                    const $t49 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Nullable$$($.$$.S.Int32));
                    const $i49 = new $t49();
                    $i49.$ctor$1();
                    $i49.IsProperty = true;
                    $i49.IsPublic = true;
                    $i49.IsVirtual = false;
                    $i49.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i49.Converter = null;
                    $i49.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Nullable$$($.$$.S.Int32)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).Sequence;
                    }, $wHdCvg ??= {"r":$.$typeNullable($.$$.S.Int32).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i49.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.Nullable$$($.$$.S.Int32)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.Sequence = value;
                    }, $wiALKh ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$$.S.Int32).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i49.IgnoreCondition = null;
                    $i49.HasJsonInclude = false;
                    $i49.IsExtensionData = false;
                    $i49.NumberHandling = null;
                    $i49.PropertyName = "Sequence";
                    $i49.JsonPropertyName = null;
                    $i49.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("Sequence", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$$.S.Int32).$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $rGEYpj ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i49;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$$.S.Int32), options, info3), 3);
                /*var*/ let info4 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t50 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i50 = new $t50();
                    $i50.$ctor$1();
                    $i50.IsProperty = true;
                    $i50.IsPublic = true;
                    $i50.IsVirtual = false;
                    $i50.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i50.Converter = null;
                    $i50.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).Descriptor;
                    }, $DMQhbh ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i50.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.Descriptor = value;
                    }, $ZYMznl ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i50.IgnoreCondition = null;
                    $i50.HasJsonInclude = false;
                    $i50.IsExtensionData = false;
                    $i50.NumberHandling = null;
                    $i50.PropertyName = "Descriptor";
                    $i50.JsonPropertyName = null;
                    $i50.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $olrEsh ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i50;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info4), 4);
                /*var*/ let info5 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t51 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i51 = new $t51();
                    $i51.$ctor$1();
                    $i51.IsProperty = true;
                    $i51.IsPublic = true;
                    $i51.IsVirtual = false;
                    $i51.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i51.Converter = null;
                    $i51.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).Assembly;
                    }, $JBsKhh ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i51.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.Assembly = value;
                    }, $cjOmAf ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i51.IgnoreCondition = null;
                    $i51.HasJsonInclude = false;
                    $i51.IsExtensionData = false;
                    $i51.NumberHandling = null;
                    $i51.PropertyName = "Assembly";
                    $i51.JsonPropertyName = null;
                    $i51.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $sahUSd ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i51;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info5), 5);
                /*var*/ let info6 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t52 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i52 = new $t52();
                    $i52.$ctor$1();
                    $i52.IsProperty = true;
                    $i52.IsPublic = true;
                    $i52.IsVirtual = false;
                    $i52.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i52.Converter = null;
                    $i52.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).TypeName;
                    }, $teEgBc ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i52.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.TypeName = value;
                    }, $wZQQXj ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i52.IgnoreCondition = null;
                    $i52.HasJsonInclude = false;
                    $i52.IsExtensionData = false;
                    $i52.NumberHandling = null;
                    $i52.PropertyName = "TypeName";
                    $i52.JsonPropertyName = null;
                    $i52.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $xUqcAb ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i52;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info6), 6);
                /*var*/ let info7 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t53 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i53 = new $t53();
                    $i53.$ctor$1();
                    $i53.IsProperty = true;
                    $i53.IsPublic = true;
                    $i53.IsVirtual = false;
                    $i53.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i53.Converter = null;
                    $i53.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).ParameterDefinitions;
                    }, $XzjMJk ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i53.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.ParameterDefinitions = value;
                    }, $yUdNsg ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i53.IgnoreCondition = null;
                    $i53.HasJsonInclude = false;
                    $i53.IsExtensionData = false;
                    $i53.NumberHandling = null;
                    $i53.PropertyName = "ParameterDefinitions";
                    $i53.JsonPropertyName = null;
                    $i53.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("ParameterDefinitions", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $rImwNj ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i53;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info7), 7);
                /*var*/ let info8 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String)()
                    const $t54 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.String);
                    const $i54 = new $t54();
                    $i54.$ctor$1();
                    $i54.IsProperty = true;
                    $i54.IsPublic = true;
                    $i54.IsVirtual = false;
                    $i54.DeclaringType = $.$macwa.MAC.ComponentMarker.$type;
                    $i54.Converter = null;
                    $i54.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.ComponentMarker)).ParameterValues;
                    }, $EZEuPg ??= {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i54.Setter = new ($.$$.S.Action$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.SRC.Unsafe.Unbox($.$macwa.MAC.ComponentMarker, obj).$v.ParameterValues = value;
                    }, $zghUxd ??= {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i54.IgnoreCondition = null;
                    $i54.HasJsonInclude = false;
                    $i54.IsExtensionData = false;
                    $i54.NumberHandling = null;
                    $i54.PropertyName = "ParameterValues";
                    $i54.JsonPropertyName = null;
                    $i54.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.ComponentMarker.$type.GetProperty("ParameterValues", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.String.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $vJQtPh ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i54;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.String, options, info8), 8);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(133146673272)
            
            //--TRIMMABLE-BOUNDARY-START(137441640568)
            /*void */ ComponentMarkerSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarker*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441640568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_Type = (value).Type;
                if (!(__value_Type === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_type, __value_Type);
                }
                /*string*/ let __value_PrerenderId = (value).PrerenderId;
                if (!(__value_PrerenderId === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_prerenderId, __value_PrerenderId);
                }
                /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey?*/ let __value_Key = (value).Key;
                if (!(__value_Key === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_key);
                    $.$stj.STJ.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.MAC.ComponentMarkerKey), writer, $.$clone(__value_Key), this.NullableComponentMarkerKey);
                }
                /*int?*/ let __value_Sequence = (value).Sequence;
                if (!(__value_Sequence === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_sequence);
                    $.$stj.STJ.JsonSerializer.Serialize$12($.$typeNullable($.$$.S.Int32), writer, __value_Sequence, this.NullableInt32);
                }
                /*string*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_descriptor, __value_Descriptor);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_ParameterDefinitions = (value).ParameterDefinitions;
                if (!(__value_ParameterDefinitions === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_parameterDefinitions, __value_ParameterDefinitions);
                }
                /*string*/ let __value_ParameterValues = (value).ParameterValues;
                if (!(__value_ParameterValues === null))
                {
                    writer.WriteString$26($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_parameterValues, __value_ParameterValues);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(137441640568)
            
            //--TRIMMABLE-BOUNDARY-START(85902033016)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>?*/ _WebRootComponentDescriptor = null;
            //--TRIMMABLE-BOUNDARY-END(85902033016)
            
            //--TRIMMABLE-BOUNDARY-START(665722617976)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ get WebRootComponentDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450974253176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._WebRootComponentDescriptor ??= $.$cast(this.Options.GetTypeInfo($.$macwa.MAC.WebRootComponentDescriptor.$type), $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentDescriptor));
            }
            //--TRIMMABLE-BOUNDARY-END(665722617976)
            
            //--TRIMMABLE-BOUNDARY-START(244815822968)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ Create_WebRootComponentDescriptor(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815822968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MACWI.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.MAC.WebRootComponentDescriptor, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentDescriptor))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.WebRootComponentDescriptor)()
                        const $t56 = $.$stj.STJSM.JsonObjectInfoValues$$($.$macwa.MAC.WebRootComponentDescriptor);
                        const $i56 = new $t56();
                        $i56.$ctor$1();
                        $i56.ObjectCreator = null;
                        $i56.ObjectWithParameterizedConstructorCreator = new ($.$$.S.Func$$$($.$typeArray($.$$.S.Object), $.$macwa.MAC.WebRootComponentDescriptor))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return new $.$macwa.MAC.WebRootComponentDescriptor().$ctor$1($.$cast($.$$.System.Array.$ReadT1.call(args, 0), $.$$.S.Type), $.$cast($.$$.System.Array.$ReadT1.call(args, 1), $.$macwa.MAC.WebRootComponentParameters));
                        }, $fAnYYb ??= {"r":4325496,"p":[{"n":"args","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":2687096,"h":0,"f":17825826});
                        $i56.PropertyMetadataInitializer = new ($.$$.S.Func$$$($.$stj.STJS$1.JsonSerializerContext, $.$typeArray($.$stj.STJSM.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.MACWI.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorPropInit(options);
                        }, $vYvNaj ??= {"r":$.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,"p":[{"n":"_","p":15138900}],"n":"","d":2687096,"h":0,"f":17825794});
                        $i56.ConstructorParameterMetadataInitializer = new ($.$$.S.Func$$($.$typeArray($.$stj.STJSM.JsonParameterInfoValues)))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, $.$macwa.MACWI.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorCtorParamInit);
                        $i56.ConstructorAttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.MAC.WebRootComponentDescriptor.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [$.$$.S.Type.$type, $.$macwa.MAC.WebRootComponentParameters.$type], null, null), null);
                        }, $sXmEyf ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                        $i56.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$macwa.MAC.WebRootComponentDescriptor))().$ctor(this, this.WebRootComponentDescriptorSerializeHandler);
                        return $i56;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateObjectInfo($.$macwa.MAC.WebRootComponentDescriptor, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(244815822968)
            
            //--TRIMMABLE-BOUNDARY-START(674312552568)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentDescriptorPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674312552568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Type)()
                    const $t57 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$$.S.Type);
                    const $i57 = new $t57();
                    $i57.$ctor$1();
                    $i57.IsProperty = true;
                    $i57.IsPublic = true;
                    $i57.IsVirtual = false;
                    $i57.DeclaringType = $.$macwa.MAC.WebRootComponentDescriptor.$type;
                    $i57.Converter = null;
                    $i57.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.Type))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.WebRootComponentDescriptor)).ComponentType;
                    }, $tqFtPe ??= {"r":188547073,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i57.Setter = null;
                    $i57.IgnoreCondition = null;
                    $i57.HasJsonInclude = false;
                    $i57.IsExtensionData = false;
                    $i57.NumberHandling = null;
                    $i57.PropertyName = "ComponentType";
                    $i57.JsonPropertyName = null;
                    $i57.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.WebRootComponentDescriptor.$type.GetProperty("ComponentType", 52/*InstanceMemberBindingFlags*/, null, $.$$.S.Type.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $bPcwNb ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i57;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$$.S.Type, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.WebRootComponentParameters)()
                    const $t58 = $.$stj.STJSM.JsonPropertyInfoValues$$($.$macwa.MAC.WebRootComponentParameters);
                    const $i58 = new $t58();
                    $i58.$ctor$1();
                    $i58.IsProperty = true;
                    $i58.IsPublic = true;
                    $i58.IsVirtual = false;
                    $i58.DeclaringType = $.$macwa.MAC.WebRootComponentDescriptor.$type;
                    $i58.Converter = null;
                    $i58.Getter = new ($.$$.S.Func$$$($.$$.S.Object, $.$macwa.MAC.WebRootComponentParameters))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.MAC.WebRootComponentDescriptor)).Parameters;
                    }, $WIGvki ??= {"r":4391032,"p":[{"n":"obj","p":131073}],"n":"","d":2687096,"h":0,"f":17825826});
                    $i58.Setter = null;
                    $i58.IgnoreCondition = null;
                    $i58.HasJsonInclude = false;
                    $i58.IsExtensionData = false;
                    $i58.NumberHandling = null;
                    $i58.PropertyName = "Parameters";
                    $i58.JsonPropertyName = null;
                    $i58.AttributeProviderFactory = new ($.$$.S.Func$$($.$$.SR.ICustomAttributeProvider))().$ctor($.$macwa.MACWI.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.MAC.WebRootComponentDescriptor.$type.GetProperty("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.MAC.WebRootComponentParameters.$type, $.$$.S.Array.Empty($.$$.S.Type), null);
                    }, $AHMgwg ??= {"r":114884609,"n":"","d":2687096,"h":0,"f":17825826});
                    return $i58;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.STJSM.JsonMetadataServices.CreatePropertyInfo($.$macwa.MAC.WebRootComponentParameters, options, info1), 1);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(674312552568)
            
            //--TRIMMABLE-BOUNDARY-START(678607519864)
            /*void */ WebRootComponentDescriptorSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678607519864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                /*global::System.Type*/ let __value_ComponentType = (value).ComponentType;
                if (!(__value_ComponentType === null))
                {
                    writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_componentType);
                    $.$stj.STJ.JsonSerializer.Serialize$12($.$$.S.Type, writer, __value_ComponentType, this.Type);
                }
                writer.WritePropertyName$12($.$macwa.MACWI.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.WebRootComponentParametersSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(678607519864)
            
            //--TRIMMABLE-BOUNDARY-START(670017585272)
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ WebRootComponentDescriptorCtorParamInit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(670017585272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$stj.STJSM.JsonParameterInfoValues), [(() =>
                    {
                        //new $.$stj.STJSM.JsonParameterInfoValues()
                        const $t59 = $.$stj.STJSM.JsonParameterInfoValues;
                        const $i59 = new $t59();
                        $i59.$ctor$1();
                        $i59.Name = "componentType";
                        $i59.ParameterType = $.$$.S.Type.$type;
                        $i59.Position = 0;
                        $i59.HasDefaultValue = false;
                        $i59.DefaultValue = null;
                        $i59.IsNullable = false;
                        return $i59;
                    })(), (() =>
                    {
                        //new $.$stj.STJSM.JsonParameterInfoValues()
                        const $t60 = $.$stj.STJSM.JsonParameterInfoValues;
                        const $i60 = new $t60();
                        $i60.$ctor$1();
                        $i60.Name = "parameters";
                        $i60.ParameterType = $.$macwa.MAC.WebRootComponentParameters.$type;
                        $i60.Position = 1;
                        $i60.HasDefaultValue = false;
                        $i60.DefaultValue = null;
                        $i60.IsNullable = false;
                        return $i60;
                    })()], [-1], null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(670017585272)
            
            //--TRIMMABLE-BOUNDARY-START(107376869496)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(107376869496)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(261995692152)
                this.GeneratedSerializerOptions = $.$macwa.MACWI.WebAssemblyJsonSerializerContext.s_defaultOptions;
                //--TRIMMABLE-BOUNDARY-END(261995692152)
                
            }
            //--TRIMMABLE-BOUNDARY-START(103081902200)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081902200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(597003141240)
                    this.PropName_type = $.$stj.STJ.JsonEncodedText.Encode$2("type", null);
                    //--TRIMMABLE-BOUNDARY-END(597003141240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(584118239352)
                    this.PropName_prerenderId = $.$stj.STJ.JsonEncodedText.Encode$2("prerenderId", null);
                    //--TRIMMABLE-BOUNDARY-END(584118239352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(549758500984)
                    this.PropName_key = $.$stj.STJ.JsonEncodedText.Encode$2("key", null);
                    //--TRIMMABLE-BOUNDARY-END(549758500984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(588413206648)
                    this.PropName_sequence = $.$stj.STJ.JsonEncodedText.Encode$2("sequence", null);
                    //--TRIMMABLE-BOUNDARY-END(588413206648)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(541168566392)
                    this.PropName_descriptor = $.$stj.STJ.JsonEncodedText.Encode$2("descriptor", null);
                    //--TRIMMABLE-BOUNDARY-END(541168566392)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528283664504)
                    this.PropName_assembly = $.$stj.STJ.JsonEncodedText.Encode$2("assembly", null);
                    //--TRIMMABLE-BOUNDARY-END(528283664504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(601298108536)
                    this.PropName_typeName = $.$stj.STJ.JsonEncodedText.Encode$2("typeName", null);
                    //--TRIMMABLE-BOUNDARY-END(601298108536)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(571233337464)
                    this.PropName_parameterDefinitions = $.$stj.STJ.JsonEncodedText.Encode$2("parameterDefinitions", null);
                    //--TRIMMABLE-BOUNDARY-END(571233337464)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(579823272056)
                    this.PropName_parameterValues = $.$stj.STJ.JsonEncodedText.Encode$2("parameterValues", null);
                    //--TRIMMABLE-BOUNDARY-END(579823272056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(554053468280)
                    this.PropName_locationHash = $.$stj.STJ.JsonEncodedText.Encode$2("locationHash", null);
                    //--TRIMMABLE-BOUNDARY-END(554053468280)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(545463533688)
                    this.PropName_formattedComponentKey = $.$stj.STJ.JsonEncodedText.Encode$2("formattedComponentKey", null);
                    //--TRIMMABLE-BOUNDARY-END(545463533688)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(562643402872)
                    this.PropName_name = $.$stj.STJ.JsonEncodedText.Encode$2("name", null);
                    //--TRIMMABLE-BOUNDARY-END(562643402872)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(592708173944)
                    this.PropName_ssrComponentId = $.$stj.STJ.JsonEncodedText.Encode$2("ssrComponentId", null);
                    //--TRIMMABLE-BOUNDARY-END(592708173944)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(558348435576)
                    this.PropName_marker = $.$stj.STJ.JsonEncodedText.Encode$2("marker", null);
                    //--TRIMMABLE-BOUNDARY-END(558348435576)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532578631800)
                    this.PropName_batchId = $.$stj.STJ.JsonEncodedText.Encode$2("batchId", null);
                    //--TRIMMABLE-BOUNDARY-END(532578631800)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(566938370168)
                    this.PropName_operations = $.$stj.STJ.JsonEncodedText.Encode$2("operations", null);
                    //--TRIMMABLE-BOUNDARY-END(566938370168)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(536873599096)
                    this.PropName_componentType = $.$stj.STJ.JsonEncodedText.Encode$2("componentType", null);
                    //--TRIMMABLE-BOUNDARY-END(536873599096)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(575528304760)
                    this.PropName_parameters = $.$stj.STJ.JsonEncodedText.Encode$2("parameters", null);
                    //--TRIMMABLE-BOUNDARY-END(575528304760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(648542748792)
                    this.s_defaultOptions = (() =>
                    {
                        //new $.$stj.STJ.JsonSerializerOptions()
                        const $t61 = $.$stj.STJ.JsonSerializerOptions;
                        const $i61 = new $t61();
                        $i61.$ctor$1();
                        $i61.DefaultIgnoreCondition = 3/*global::System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull*/;
                        $i61.PropertyNameCaseInsensitive = true;
                        $i61.PropertyNamingPolicy = $.$stj.STJ.JsonNamingPolicy.CamelCase;
                        return $i61;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(648542748792)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253405757560)
                    this.Default = new $.$macwa.MACWI.WebAssemblyJsonSerializerContext().$ctor$3(new $.$stj.STJ.JsonSerializerOptions().$ctor$3($.$macwa.MACWI.WebAssemblyJsonSerializerContext.s_defaultOptions));
                    //--TRIMMABLE-BOUNDARY-END(253405757560)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081902200)
            
            static $h = 2687096;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonSerializerContext; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(493923926136),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$stj.STJ.JsonElement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347895038072,
        "f": 50331649
      },
      "n": "JsonElement",
      "d": 2687096,
      "h": 493923926136,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(493923926136),
//--TRIMMABLE-BOUNDARY-START(485333991544),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330715168888,
        "f": 50331649
      },
      "n": "Int32",
      "d": 2687096,
      "h": 485333991544,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485333991544),
//--TRIMMABLE-BOUNDARY-START(489628958840),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339305103480,
        "f": 50331649
      },
      "n": "Int64",
      "d": 2687096,
      "h": 489628958840,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(489628958840),
//--TRIMMABLE-BOUNDARY-START(502513860728),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365074907256,
        "f": 50331649
      },
      "n": "NullableComponentMarkerKey",
      "d": 2687096,
      "h": 502513860728,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(502513860728),
//--TRIMMABLE-BOUNDARY-START(661427650680),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442384318584,
        "f": 50331649
      },
      "n": "Type",
      "d": 2687096,
      "h": 661427650680,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(661427650680),
//--TRIMMABLE-BOUNDARY-START(476744056952),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.IList$$($.$$.S.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322125234296,
        "f": 50331649
      },
      "n": "IListObject",
      "d": 2687096,
      "h": 476744056952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(476744056952),
//--TRIMMABLE-BOUNDARY-START(652837716088),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433794383992,
        "f": 50331649
      },
      "n": "String",
      "d": 2687096,
      "h": 652837716088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(652837716088),
//--TRIMMABLE-BOUNDARY-START(609888043128),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.RootComponentOperation)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408024580216,
        "f": 50331649
      },
      "n": "RootComponentOperationArray",
      "d": 2687096,
      "h": 609888043128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(609888043128),
//--TRIMMABLE-BOUNDARY-START(506808828024),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$$.S.Int32)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373664841848,
        "f": 50331649
      },
      "n": "NullableInt32",
      "d": 2687096,
      "h": 506808828024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(506808828024),
//--TRIMMABLE-BOUNDARY-START(146031575160),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.ComponentParameter)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296355430520,
        "f": 50331649
      },
      "n": "ComponentParameterArray",
      "d": 2687096,
      "h": 146031575160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031575160),
//--TRIMMABLE-BOUNDARY-START(515398762616),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$mac.MAC.ParameterView).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390844711032,
        "f": 50331649
      },
      "n": "ParameterView",
      "d": 2687096,
      "h": 515398762616,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(515398762616),
//--TRIMMABLE-BOUNDARY-START(511103795320),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382254776440,
        "f": 50331649
      },
      "n": "Object",
      "d": 2687096,
      "h": 511103795320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(511103795320),
//--TRIMMABLE-BOUNDARY-START(682902487160),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentParameters).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459564187768,
        "f": 50331649
      },
      "n": "WebRootComponentParameters",
      "d": 2687096,
      "h": 682902487160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(682902487160),
//--TRIMMABLE-BOUNDARY-START(120261771384),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarkerKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279175561336,
        "f": 50331649
      },
      "n": "ComponentMarkerKey",
      "d": 2687096,
      "h": 120261771384,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261771384),
//--TRIMMABLE-BOUNDARY-START(644247781496),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425204449400,
        "f": 50331649
      },
      "n": "RootComponentOperationType",
      "d": 2687096,
      "h": 644247781496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(644247781496),
//--TRIMMABLE-BOUNDARY-START(498218893432),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356484972664,
        "f": 50331649
      },
      "n": "NullableComponentMarker",
      "d": 2687096,
      "h": 498218893432,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(498218893432),
//--TRIMMABLE-BOUNDARY-START(253405757560),
    {
      "p": 2687096,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304945365112,
        "f": 50331681
      },
      "n": "Default",
      "d": 2687096,
      "h": 253405757560,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(253405757560),
//--TRIMMABLE-BOUNDARY-START(261995692152),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313535299704,
        "f": 50364420
      },
      "n": "GeneratedSerializerOptions",
      "d": 2687096,
      "h": 261995692152,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(261995692152),
//--TRIMMABLE-BOUNDARY-START(618477977720),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationBatch).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416614514808,
        "f": 50331649
      },
      "n": "RootComponentOperationBatch",
      "d": 2687096,
      "h": 618477977720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(618477977720),
//--TRIMMABLE-BOUNDARY-START(141736607864),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentParameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287765495928,
        "f": 50331649
      },
      "n": "ComponentParameter",
      "d": 2687096,
      "h": 141736607864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736607864),
//--TRIMMABLE-BOUNDARY-START(605593075832),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399434645624,
        "f": 50331649
      },
      "n": "RootComponentOperation",
      "d": 2687096,
      "h": 605593075832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(605593075832),
//--TRIMMABLE-BOUNDARY-START(115966804088),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarker).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270585626744,
        "f": 50331649
      },
      "n": "ComponentMarker",
      "d": 2687096,
      "h": 115966804088,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966804088),
//--TRIMMABLE-BOUNDARY-START(665722617976),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450974253176,
        "f": 50331649
      },
      "n": "WebRootComponentDescriptor",
      "d": 2687096,
      "h": 665722617976,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(665722617976)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(193276215416),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$stj.STJ.JsonElement).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_JsonElement",
      "d": 2687096,
      "h": 193276215416,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193276215416),
//--TRIMMABLE-BOUNDARY-START(184686280824),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Int32",
      "d": 2687096,
      "h": 184686280824,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184686280824),
//--TRIMMABLE-BOUNDARY-START(188981248120),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int64).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Int64",
      "d": 2687096,
      "h": 188981248120,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188981248120),
//--TRIMMABLE-BOUNDARY-START(201866150008),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableComponentMarkerKey",
      "d": 2687096,
      "h": 201866150008,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(201866150008),
//--TRIMMABLE-BOUNDARY-START(240520855672),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Type).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Type",
      "d": 2687096,
      "h": 240520855672,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240520855672),
//--TRIMMABLE-BOUNDARY-START(180391313528),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.IList$$($.$$.S.Object)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_IListObject",
      "d": 2687096,
      "h": 180391313528,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180391313528),
//--TRIMMABLE-BOUNDARY-START(468154122360),
    {
      "r": 17170516,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetTypeInfo",
      "d": 2687096,
      "h": 468154122360,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(468154122360),
//--TRIMMABLE-BOUNDARY-START(236225888376),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_String",
      "d": 2687096,
      "h": 236225888376,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236225888376),
//--TRIMMABLE-BOUNDARY-START(223340986488),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.RootComponentOperation)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationArray",
      "d": 2687096,
      "h": 223340986488,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223340986488),
//--TRIMMABLE-BOUNDARY-START(614183010424),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$macwa.MAC.RootComponentOperation).$h
        }
      ],
      "n": "RootComponentOperationArraySerializeHandler",
      "d": 2687096,
      "h": 614183010424,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(614183010424),
//--TRIMMABLE-BOUNDARY-START(206161117304),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$$.S.Int32)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableInt32",
      "d": 2687096,
      "h": 206161117304,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206161117304),
//--TRIMMABLE-BOUNDARY-START(176096346232),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.ComponentParameter)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentParameterArray",
      "d": 2687096,
      "h": 176096346232,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176096346232),
//--TRIMMABLE-BOUNDARY-START(150326542456),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$macwa.MAC.ComponentParameter).$h
        }
      ],
      "n": "ComponentParameterArraySerializeHandler",
      "d": 2687096,
      "h": 150326542456,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150326542456),
//--TRIMMABLE-BOUNDARY-START(214751051896),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$mac.MAC.ParameterView).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ParameterView",
      "d": 2687096,
      "h": 214751051896,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214751051896),
//--TRIMMABLE-BOUNDARY-START(519693729912),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ParameterViewPropInit",
      "d": 2687096,
      "h": 519693729912,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(519693729912),
//--TRIMMABLE-BOUNDARY-START(523988697208),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 5767283
        }
      ],
      "n": "ParameterViewSerializeHandler",
      "d": 2687096,
      "h": 523988697208,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(523988697208),
//--TRIMMABLE-BOUNDARY-START(210456084600),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Object",
      "d": 2687096,
      "h": 210456084600,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210456084600),
//--TRIMMABLE-BOUNDARY-START(249110790264),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentParameters).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_WebRootComponentParameters",
      "d": 2687096,
      "h": 249110790264,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249110790264),
//--TRIMMABLE-BOUNDARY-START(687197454456),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "WebRootComponentParametersPropInit",
      "d": 2687096,
      "h": 687197454456,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(687197454456),
//--TRIMMABLE-BOUNDARY-START(691492421752),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 4391032
        }
      ],
      "n": "WebRootComponentParametersSerializeHandler",
      "d": 2687096,
      "h": 691492421752,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(691492421752),
//--TRIMMABLE-BOUNDARY-START(167506411640),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarkerKey).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentMarkerKey",
      "d": 2687096,
      "h": 167506411640,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167506411640),
//--TRIMMABLE-BOUNDARY-START(124556738680),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentMarkerKeyPropInit",
      "d": 2687096,
      "h": 124556738680,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124556738680),
//--TRIMMABLE-BOUNDARY-START(128851705976),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 196728
        }
      ],
      "n": "ComponentMarkerKeySerializeHandler",
      "d": 2687096,
      "h": 128851705976,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851705976),
//--TRIMMABLE-BOUNDARY-START(231930921080),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationType).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationType",
      "d": 2687096,
      "h": 231930921080,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231930921080),
//--TRIMMABLE-BOUNDARY-START(197571182712),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableComponentMarker",
      "d": 2687096,
      "h": 197571182712,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197571182712),
//--TRIMMABLE-BOUNDARY-START(657132683384),
    {
      "r": 262145,
      "p": [
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "jsonTypeInfo",
          "p": (TJsonMetadataType) => $.$stj.STJSM.JsonTypeInfo$$(TJsonMetadataType).$h,
          "f": 2
        }
      ],
      "g": [
        "TJsonMetadataType"
      ],
      "n": "TryGetTypeInfoForRuntimeCustomConverter",
      "d": 2687096,
      "h": 657132683384,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(657132683384),
//--TRIMMABLE-BOUNDARY-START(463859155064),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "GetRuntimeConverterForType",
      "d": 2687096,
      "h": 463859155064,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(463859155064),
//--TRIMMABLE-BOUNDARY-START(257700724856),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "converter",
          "p": 13500500
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "validateCanConvert",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ExpandConverter",
      "d": 2687096,
      "h": 257700724856,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(257700724856),
//--TRIMMABLE-BOUNDARY-START(227635953784),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationBatch).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationBatch",
      "d": 2687096,
      "h": 227635953784,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227635953784),
//--TRIMMABLE-BOUNDARY-START(627067912312),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "RootComponentOperationBatchPropInit",
      "d": 2687096,
      "h": 627067912312,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(627067912312),
//--TRIMMABLE-BOUNDARY-START(631362879608),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 1048696
        }
      ],
      "n": "RootComponentOperationBatchSerializeHandler",
      "d": 2687096,
      "h": 631362879608,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(631362879608),
//--TRIMMABLE-BOUNDARY-START(622772945016),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonParameterInfoValues).$h,
      "n": "RootComponentOperationBatchCtorParamInit",
      "d": 2687096,
      "h": 622772945016,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(622772945016),
//--TRIMMABLE-BOUNDARY-START(171801378936),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentParameter).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentParameter",
      "d": 2687096,
      "h": 171801378936,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171801378936),
//--TRIMMABLE-BOUNDARY-START(154621509752),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentParameterPropInit",
      "d": 2687096,
      "h": 154621509752,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154621509752),
//--TRIMMABLE-BOUNDARY-START(158916477048),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 262264
        }
      ],
      "n": "ComponentParameterSerializeHandler",
      "d": 2687096,
      "h": 158916477048,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158916477048),
//--TRIMMABLE-BOUNDARY-START(219046019192),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperation).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperation",
      "d": 2687096,
      "h": 219046019192,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219046019192),
//--TRIMMABLE-BOUNDARY-START(635657846904),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "RootComponentOperationPropInit",
      "d": 2687096,
      "h": 635657846904,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(635657846904),
//--TRIMMABLE-BOUNDARY-START(639952814200),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 983160
        }
      ],
      "n": "RootComponentOperationSerializeHandler",
      "d": 2687096,
      "h": 639952814200,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(639952814200),
//--TRIMMABLE-BOUNDARY-START(163211444344),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarker).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentMarker",
      "d": 2687096,
      "h": 163211444344,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163211444344),
//--TRIMMABLE-BOUNDARY-START(133146673272),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentMarkerPropInit",
      "d": 2687096,
      "h": 133146673272,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133146673272),
//--TRIMMABLE-BOUNDARY-START(137441640568),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 131192
        }
      ],
      "n": "ComponentMarkerSerializeHandler",
      "d": 2687096,
      "h": 137441640568,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137441640568),
//--TRIMMABLE-BOUNDARY-START(244815822968),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentDescriptor).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_WebRootComponentDescriptor",
      "d": 2687096,
      "h": 244815822968,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244815822968),
//--TRIMMABLE-BOUNDARY-START(674312552568),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "WebRootComponentDescriptorPropInit",
      "d": 2687096,
      "h": 674312552568,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(674312552568),
//--TRIMMABLE-BOUNDARY-START(678607519864),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 4325496
        }
      ],
      "n": "WebRootComponentDescriptorSerializeHandler",
      "d": 2687096,
      "h": 678607519864,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(678607519864),
//--TRIMMABLE-BOUNDARY-START(670017585272),
    {
      "r": $.$typeArray($.$stj.STJSM.JsonParameterInfoValues).$h,
      "n": "WebRootComponentDescriptorCtorParamInit",
      "d": 2687096,
      "h": 670017585272,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(670017585272)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34362425464),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$stj.STJ.JsonElement).$h,
      "n": "_JsonElement",
      "d": 2687096,
      "h": 34362425464,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34362425464),
//--TRIMMABLE-BOUNDARY-START(25772490872),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int32).$h,
      "n": "_Int32",
      "d": 2687096,
      "h": 25772490872,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772490872),
//--TRIMMABLE-BOUNDARY-START(30067458168),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Int64).$h,
      "n": "_Int64",
      "d": 2687096,
      "h": 30067458168,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067458168),
//--TRIMMABLE-BOUNDARY-START(42952360056),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey)).$h,
      "n": "_NullableComponentMarkerKey",
      "d": 2687096,
      "h": 42952360056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42952360056),
//--TRIMMABLE-BOUNDARY-START(81607065720),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Type).$h,
      "n": "_Type",
      "d": 2687096,
      "h": 81607065720,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81607065720),
//--TRIMMABLE-BOUNDARY-START(21477523576),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.IList$$($.$$.S.Object)).$h,
      "n": "_IListObject",
      "d": 2687096,
      "h": 21477523576,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477523576),
//--TRIMMABLE-BOUNDARY-START(77312098424),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "n": "_String",
      "d": 2687096,
      "h": 77312098424,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77312098424),
//--TRIMMABLE-BOUNDARY-START(64427196536),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.RootComponentOperation)).$h,
      "n": "_RootComponentOperationArray",
      "d": 2687096,
      "h": 64427196536,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64427196536),
//--TRIMMABLE-BOUNDARY-START(597003141240),
    {
      "t": 2293844,
      "n": "PropName_type",
      "d": 2687096,
      "h": 597003141240,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(597003141240),
//--TRIMMABLE-BOUNDARY-START(584118239352),
    {
      "t": 2293844,
      "n": "PropName_prerenderId",
      "d": 2687096,
      "h": 584118239352,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(584118239352),
//--TRIMMABLE-BOUNDARY-START(549758500984),
    {
      "t": 2293844,
      "n": "PropName_key",
      "d": 2687096,
      "h": 549758500984,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(549758500984),
//--TRIMMABLE-BOUNDARY-START(588413206648),
    {
      "t": 2293844,
      "n": "PropName_sequence",
      "d": 2687096,
      "h": 588413206648,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(588413206648),
//--TRIMMABLE-BOUNDARY-START(541168566392),
    {
      "t": 2293844,
      "n": "PropName_descriptor",
      "d": 2687096,
      "h": 541168566392,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(541168566392),
//--TRIMMABLE-BOUNDARY-START(528283664504),
    {
      "t": 2293844,
      "n": "PropName_assembly",
      "d": 2687096,
      "h": 528283664504,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(528283664504),
//--TRIMMABLE-BOUNDARY-START(601298108536),
    {
      "t": 2293844,
      "n": "PropName_typeName",
      "d": 2687096,
      "h": 601298108536,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(601298108536),
//--TRIMMABLE-BOUNDARY-START(571233337464),
    {
      "t": 2293844,
      "n": "PropName_parameterDefinitions",
      "d": 2687096,
      "h": 571233337464,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(571233337464),
//--TRIMMABLE-BOUNDARY-START(579823272056),
    {
      "t": 2293844,
      "n": "PropName_parameterValues",
      "d": 2687096,
      "h": 579823272056,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(579823272056),
//--TRIMMABLE-BOUNDARY-START(554053468280),
    {
      "t": 2293844,
      "n": "PropName_locationHash",
      "d": 2687096,
      "h": 554053468280,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(554053468280),
//--TRIMMABLE-BOUNDARY-START(545463533688),
    {
      "t": 2293844,
      "n": "PropName_formattedComponentKey",
      "d": 2687096,
      "h": 545463533688,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(545463533688),
//--TRIMMABLE-BOUNDARY-START(562643402872),
    {
      "t": 2293844,
      "n": "PropName_name",
      "d": 2687096,
      "h": 562643402872,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(562643402872),
//--TRIMMABLE-BOUNDARY-START(592708173944),
    {
      "t": 2293844,
      "n": "PropName_ssrComponentId",
      "d": 2687096,
      "h": 592708173944,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(592708173944),
//--TRIMMABLE-BOUNDARY-START(558348435576),
    {
      "t": 2293844,
      "n": "PropName_marker",
      "d": 2687096,
      "h": 558348435576,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(558348435576),
//--TRIMMABLE-BOUNDARY-START(532578631800),
    {
      "t": 2293844,
      "n": "PropName_batchId",
      "d": 2687096,
      "h": 532578631800,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(532578631800),
//--TRIMMABLE-BOUNDARY-START(566938370168),
    {
      "t": 2293844,
      "n": "PropName_operations",
      "d": 2687096,
      "h": 566938370168,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(566938370168),
//--TRIMMABLE-BOUNDARY-START(536873599096),
    {
      "t": 2293844,
      "n": "PropName_componentType",
      "d": 2687096,
      "h": 536873599096,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(536873599096),
//--TRIMMABLE-BOUNDARY-START(575528304760),
    {
      "t": 2293844,
      "n": "PropName_parameters",
      "d": 2687096,
      "h": 575528304760,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(575528304760),
//--TRIMMABLE-BOUNDARY-START(47247327352),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$$.S.Int32)).$h,
      "n": "_NullableInt32",
      "d": 2687096,
      "h": 47247327352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47247327352),
//--TRIMMABLE-BOUNDARY-START(17182556280),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$macwa.MAC.ComponentParameter)).$h,
      "n": "_ComponentParameterArray",
      "d": 2687096,
      "h": 17182556280,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182556280),
//--TRIMMABLE-BOUNDARY-START(55837261944),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$mac.MAC.ParameterView).$h,
      "n": "_ParameterView",
      "d": 2687096,
      "h": 55837261944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55837261944),
//--TRIMMABLE-BOUNDARY-START(51542294648),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Object).$h,
      "n": "_Object",
      "d": 2687096,
      "h": 51542294648,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51542294648),
//--TRIMMABLE-BOUNDARY-START(90197000312),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentParameters).$h,
      "n": "_WebRootComponentParameters",
      "d": 2687096,
      "h": 90197000312,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90197000312),
//--TRIMMABLE-BOUNDARY-START(8592621688),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarkerKey).$h,
      "n": "_ComponentMarkerKey",
      "d": 2687096,
      "h": 8592621688,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592621688),
//--TRIMMABLE-BOUNDARY-START(73017131128),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationType).$h,
      "n": "_RootComponentOperationType",
      "d": 2687096,
      "h": 73017131128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73017131128),
//--TRIMMABLE-BOUNDARY-START(38657392760),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker)).$h,
      "n": "_NullableComponentMarker",
      "d": 2687096,
      "h": 38657392760,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38657392760),
//--TRIMMABLE-BOUNDARY-START(648542748792),
    {
      "t": 3342420,
      "n": "s_defaultOptions",
      "d": 2687096,
      "h": 648542748792,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(648542748792),
//--TRIMMABLE-BOUNDARY-START(481039024248),
    {
      "t": 109051905,
      "n": "InstanceMemberBindingFlags",
      "d": 2687096,
      "h": 481039024248,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(481039024248),
//--TRIMMABLE-BOUNDARY-START(68722163832),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperationBatch).$h,
      "n": "_RootComponentOperationBatch",
      "d": 2687096,
      "h": 68722163832,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68722163832),
//--TRIMMABLE-BOUNDARY-START(12887588984),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentParameter).$h,
      "n": "_ComponentParameter",
      "d": 2687096,
      "h": 12887588984,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887588984),
//--TRIMMABLE-BOUNDARY-START(60132229240),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.RootComponentOperation).$h,
      "n": "_RootComponentOperation",
      "d": 2687096,
      "h": 60132229240,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60132229240),
//--TRIMMABLE-BOUNDARY-START(4297654392),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.ComponentMarker).$h,
      "n": "_ComponentMarker",
      "d": 2687096,
      "h": 4297654392,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297654392),
//--TRIMMABLE-BOUNDARY-START(85902033016),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$macwa.MAC.WebRootComponentDescriptor).$h,
      "n": "_WebRootComponentDescriptor",
      "d": 2687096,
      "h": 85902033016,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85902033016)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(107376869496),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687096,
      "h": 107376869496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376869496),
//--TRIMMABLE-BOUNDARY-START(111671836792),
    {
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687096,
      "h": 111671836792,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111671836792)
  ],
  "h": 2687096,
  "a": [
    {
      "t": 15269972,
      "c": 120274354260,
      "n": [
        {
          "n": "PropertyNamingPolicy",
          "v": 1,
          "t": 14221396
        },
        {
          "n": "PropertyNameCaseInsensitive",
          "v": true,
          "t": 262145
        },
        {
          "n": "DefaultIgnoreCondition",
          "v": 3,
          "t": 14090324
        }
      ]
    },
    {
      "t": 15073364,
      "c": 12899975252,
      "a": [
        {
          "v": $.$typeArray($.$macwa.MAC.ComponentParameter).$h,
          "t": 188547073
        }
      ]
    },
    {
      "t": 15073364,
      "c": 12899975252,
      "a": [
        {
          "v": 2097236,
          "t": 188547073
        }
      ]
    },
    {
      "t": 15073364,
      "c": 12899975252,
      "a": [
        {
          "v": $.$$.SCG.IList$$($.$$.S.Object).$h,
          "t": 188547073
        }
      ]
    },
    {
      "t": 15073364,
      "c": 12899975252,
      "a": [
        {
          "v": 1048696,
          "t": 188547073
        }
      ]
    },
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Text.Json.SourceGeneration",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.STJSM.IBuiltInJsonTypeInfoResolver, $.$stj.STJSM.IJsonTypeInfoResolver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Infrastructure${separator}WebAssemblyJsonSerializerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687096)
        
        

        //--TRIMMABLE-BOUNDARY-START(786552)
        $asm.$cls(`$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext`, ($self) => class PrerenderComponentApplicationStoreSerializerContext extends $.$stj.STJS$1.JsonSerializerContext
        {
            //--TRIMMABLE-BOUNDARY-START(4295753848)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>?*/ _ByteArray = null;
            //--TRIMMABLE-BOUNDARY-END(4295753848)
            
            //--TRIMMABLE-BOUNDARY-START(38655492216)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ get ByteArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605165176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ByteArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$$.S.Byte).$type), $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$$.S.Byte)));
            }
            //--TRIMMABLE-BOUNDARY-END(38655492216)
            
            //--TRIMMABLE-BOUNDARY-START(42950459512)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ Create_ByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$$.S.Byte), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$$.S.Byte)))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$typeArray($.$$.S.Byte), options, $.$stj.STJSM.JsonMetadataServices.ByteArrayConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459512)
            
            //--TRIMMABLE-BOUNDARY-START(12885688440)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            //--TRIMMABLE-BOUNDARY-END(12885688440)
            
            //--TRIMMABLE-BOUNDARY-START(141734707320)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$$.S.String.$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String));
            }
            //--TRIMMABLE-BOUNDARY-END(141734707320)
            
            //--TRIMMABLE-BOUNDARY-START(51540394104)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.S.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String))))
                {
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo($.$$.S.String, options, $.$stj.STJSM.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394104)
            
            //--TRIMMABLE-BOUNDARY-START(8590721144)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>?*/ _DictionaryStringByteArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590721144)
            
            //--TRIMMABLE-BOUNDARY-START(60130328696)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ get DictionaryStringByteArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._DictionaryStringByteArray ??= $.$cast(this.Options.GetTypeInfo($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$type), $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))));
            }
            //--TRIMMABLE-BOUNDARY-END(60130328696)
            
            //--TRIMMABLE-BOUNDARY-START(47245426808)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ Create_DictionaryStringByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>*/ let jsonTypeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.STJSM.JsonCollectionInfoValues$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)))()
                        const $t4 = $.$stj.STJSM.JsonCollectionInfoValues$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)));
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.ObjectCreator = new ($.$$.S.Func$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))))().$ctor(this,  () =>
                        {
                            return new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)))().$ctor$1();
                        }, $xMiIFe ??= {"r":$.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h,"n":"","d":786552,"h":0,"f":17825794});
                        $i4.SerializeHandler = new ($.$$.S.Action$$$($.$stj.STJ.Utf8JsonWriter, $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))))().$ctor(this, this.DictionaryStringByteArraySerializeHandler);
                        return $i4;
                    })();
                    jsonTypeInfo = $.$stj.STJSM.JsonMetadataServices.CreateDictionaryInfo($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)), $.$$.S.String, $.$typeArray($.$$.S.Byte), options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426808)
            
            //--TRIMMABLE-BOUNDARY-START(64425295992)
            /*void */ DictionaryStringByteArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.Dictionary<string, byte[]>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                let $en5 = value.GetEnumerator();
                while ($en5.MoveNext())
                {
                    let entry = $en5.Current;
                    {
                        writer.WriteBase64String$2(entry.Key, $.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(entry.Value));
                    }
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(64425295992)
            
            //--TRIMMABLE-BOUNDARY-START(124554838136)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554838136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.STJSM.JsonTypeInfo));
                return typeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(124554838136)
            
            //--TRIMMABLE-BOUNDARY-START(128849805432)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ STJSM$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849805432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === $.$typeArray($.$$.S.Byte).$type)
                {
                    return this.Create_ByteArray(options);
                }
                if (type === $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$type)
                {
                    return this.Create_DictionaryStringByteArray(options);
                }
                if (type === $.$$.S.String.$type)
                {
                    return this.Create_String(options);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(128849805432)
            
            //--TRIMMABLE-BOUNDARY-START(137439740024)
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            //--TRIMMABLE-BOUNDARY-END(137439740024)
            
            //--TRIMMABLE-BOUNDARY-START(133144772728)
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            //--TRIMMABLE-BOUNDARY-END(133144772728)
            
            //--TRIMMABLE-BOUNDARY-START(55835361400)
            /*global::Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(55835361400)
            
            //--TRIMMABLE-BOUNDARY-START(73015230584)
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(73015230584)
            
            //--TRIMMABLE-BOUNDARY-START(30065557624)
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557624)
            
            //--TRIMMABLE-BOUNDARY-START(34360524920)
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524920)
            
            //--TRIMMABLE-BOUNDARY-START(146029674616)
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029674616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.STJSM.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(146029674616)
            
            //--TRIMMABLE-BOUNDARY-START(120259870840)
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < options.Converters.SCG$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.SCG$IList$$$get_Item(i);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(120259870840)
            
            //--TRIMMABLE-BOUNDARY-START(68720263288)
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$$.S.String.Format$8("The converter '{0}' is not compatible with the type '{1}'.", $.$$.S.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.STJS$1.JsonConverterFactory, { set $v($v){ factory = $v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.STJS$1.JsonConverterFactory))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$$.S.String.Format$9("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$$.S.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263288)
            
            //--TRIMMABLE-BOUNDARY-START(30065557624)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(30065557624)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(73015230584)
                this.GeneratedSerializerOptions = $.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions;
                //--TRIMMABLE-BOUNDARY-END(73015230584)
                
            }
            //--TRIMMABLE-BOUNDARY-START(25770590328)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(137439740024)
                    this.s_defaultOptions = new $.$stj.STJ.JsonSerializerOptions().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(137439740024)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835361400)
                    this.Default = new $.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext().$ctor$3(new $.$stj.STJ.JsonSerializerOptions().$ctor$3($.$macwa.MAC.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions));
                    //--TRIMMABLE-BOUNDARY-END(55835361400)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590328)
            
            static $h = 786552;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonSerializerContext; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655492216),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$$.S.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165176,
        "f": 50331649
      },
      "n": "ByteArray",
      "d": 786552,
      "h": 38655492216,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492216),
//--TRIMMABLE-BOUNDARY-START(141734707320),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964903544,
        "f": 50331649
      },
      "n": "String",
      "d": 786552,
      "h": 141734707320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734707320),
//--TRIMMABLE-BOUNDARY-START(60130328696),
    {
      "p": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785034360,
        "f": 50331649
      },
      "n": "DictionaryStringByteArray",
      "d": 786552,
      "h": 60130328696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328696),
//--TRIMMABLE-BOUNDARY-START(55835361400),
    {
      "p": 786552,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099768,
        "f": 50331681
      },
      "n": "Default",
      "d": 786552,
      "h": 55835361400,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835361400),
//--TRIMMABLE-BOUNDARY-START(73015230584),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374968952,
        "f": 50364420
      },
      "n": "GeneratedSerializerOptions",
      "d": 786552,
      "h": 73015230584,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(73015230584)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950459512),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ByteArray",
      "d": 786552,
      "h": 42950459512,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950459512),
//--TRIMMABLE-BOUNDARY-START(51540394104),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_String",
      "d": 786552,
      "h": 51540394104,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540394104),
//--TRIMMABLE-BOUNDARY-START(47245426808),
    {
      "r": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_DictionaryStringByteArray",
      "d": 786552,
      "h": 47245426808,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245426808),
//--TRIMMABLE-BOUNDARY-START(64425295992),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h
        }
      ],
      "n": "DictionaryStringByteArraySerializeHandler",
      "d": 786552,
      "h": 64425295992,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425295992),
//--TRIMMABLE-BOUNDARY-START(124554838136),
    {
      "r": 17170516,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetTypeInfo",
      "d": 786552,
      "h": 124554838136,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554838136),
//--TRIMMABLE-BOUNDARY-START(146029674616),
    {
      "r": 262145,
      "p": [
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "jsonTypeInfo",
          "p": (TJsonMetadataType) => $.$stj.STJSM.JsonTypeInfo$$(TJsonMetadataType).$h,
          "f": 2
        }
      ],
      "g": [
        "TJsonMetadataType"
      ],
      "n": "TryGetTypeInfoForRuntimeCustomConverter",
      "d": 786552,
      "h": 146029674616,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(146029674616),
//--TRIMMABLE-BOUNDARY-START(120259870840),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "GetRuntimeConverterForType",
      "d": 786552,
      "h": 120259870840,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259870840),
//--TRIMMABLE-BOUNDARY-START(68720263288),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "converter",
          "p": 13500500
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "validateCanConvert",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ExpandConverter",
      "d": 786552,
      "h": 68720263288,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720263288)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753848),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$typeArray($.$$.S.Byte)).$h,
      "n": "_ByteArray",
      "d": 786552,
      "h": 4295753848,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753848),
//--TRIMMABLE-BOUNDARY-START(12885688440),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.S.String).$h,
      "n": "_String",
      "d": 786552,
      "h": 12885688440,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688440),
//--TRIMMABLE-BOUNDARY-START(8590721144),
    {
      "t": $.$stj.STJSM.JsonTypeInfo$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte))).$h,
      "n": "_DictionaryStringByteArray",
      "d": 786552,
      "h": 8590721144,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721144),
//--TRIMMABLE-BOUNDARY-START(137439740024),
    {
      "t": 3342420,
      "n": "s_defaultOptions",
      "d": 786552,
      "h": 137439740024,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137439740024),
//--TRIMMABLE-BOUNDARY-START(133144772728),
    {
      "t": 109051905,
      "n": "InstanceMemberBindingFlags",
      "d": 786552,
      "h": 133144772728,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144772728)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065557624),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786552,
      "h": 30065557624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557624),
//--TRIMMABLE-BOUNDARY-START(34360524920),
    {
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786552,
      "h": 34360524920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360524920)
  ],
  "h": 786552,
  "a": [
    {
      "t": 15073364,
      "c": 12899975252,
      "a": [
        {
          "v": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$typeArray($.$$.S.Byte)).$h,
          "t": 188547073
        }
      ],
      "n": [
        {
          "n": "GenerationMode",
          "v": 2,
          "t": 15204436
        }
      ]
    },
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Text.Json.SourceGeneration",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.STJSM.IBuiltInJsonTypeInfoResolver, $.$stj.STJSM.IJsonTypeInfoResolver ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}PrerenderComponentApplicationStoreSerializerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786552)
        
        

        //--TRIMMABLE-BOUNDARY-START(2949240)
        $asm.$cls(`$macwa.MACWR.WebAssemblyRenderer`, ($self) => class WebAssemblyRenderer extends $.$macw.MACR$1.WebRenderer
        {
            //--TRIMMABLE-BOUNDARY-START(3014776)
            static $_Log;
            static get Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3014776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWR.WebAssemblyRenderer;
                return $cls.$_Log ??= $asm.$ncls(`$macwa.MACWR.WebAssemblyRenderer.Log`, ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4297982072)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UnhandledExceptionRenderingComponentCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4297982072)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887916664)
                    static /*void */ UnhandledExceptionRenderingComponent(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ message, /*global::System.Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887916664);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.MEL$ILogger$IsEnabled(5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/))
                        {
                            $.$macwa.MACWR.WebAssemblyRenderer.Log.__UnhandledExceptionRenderingComponentCallback.Invoke(logger, message, exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887916664)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592949368)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592949368);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(4297982072)
                            this.__UnhandledExceptionRenderingComponentCallback = $.$mexla.MEL.LoggerMessage.Define$12($.$$.S.String, 5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/, new $.$mexla.MEL.EventId().$ctor$3(100, "ExceptionRenderingComponent"), "Unhandled exception rendering component: {Message}", (() =>
                            {
                                //new $.$mexla.MEL.LogDefineOptions()
                                const $t1 = $.$mexla.MEL.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4297982072)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592949368)
                    
                    static $h = 3014776;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887916664),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "UnhandledExceptionRenderingComponent",
      "d": 3014776,
      "h": 12887916664,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 100,
              "t": 655361
            },
            {
              "v": 5,
              "t": 2293848
            },
            {
              "v": "Unhandled exception rendering component: {Message}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "ExceptionRenderingComponent",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887916664)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297982072),
    {
      "t": $.$$.S.Action$$$$($.$mexla.MEL.ILogger, $.$$.S.String, $.$$.S.Exception).$h,
      "n": "__UnhandledExceptionRenderingComponentCallback",
      "d": 3014776,
      "h": 4297982072,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297982072)
  ],
  "d": 2949240,
  "h": 3014776
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer+Log`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyRenderer${separator}Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3014776)
            
            //--TRIMMABLE-BOUNDARY-START(30067720312)
            /*WebRootComponentManager?*/ _webRootComponentManager = null;
            //--TRIMMABLE-BOUNDARY-END(30067720312)
            
            //--TRIMMABLE-BOUNDARY-START(111672098936)
            /*WebRootComponentManager */ GetOrCreateWebRootComponentManager()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672098936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._webRootComponentManager ??= new $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111672098936)
            
            //--TRIMMABLE-BOUNDARY-START(3080312)
            static $_WebRootComponentManager;
            static get WebRootComponentManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3080312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$macwa.MACWR.WebAssemblyRenderer;
                return $cls.$_WebRootComponentManager ??= $asm.$ncls(`$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager`, ($self) => class WebRootComponentManager extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8593014904)
                    /*Dictionary<int, WebRootComponent>*/ _webRootComponents = null;
                    //--TRIMMABLE-BOUNDARY-END(8593014904)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298047608)
                    /*Task*/ _currentUpdateTask = null;
                    //--TRIMMABLE-BOUNDARY-END(4298047608)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477916792)
                    /*Task *//*async*/  AddRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ componentType, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ parameters)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                        {
                            let $t2, $r2;
                            let $t3, $r3;
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477916792);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (this._webRootComponents.ContainsKey(ssrComponentId))
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12(`A root component with SSR component ID ${$.$strNN(ssrComponentId)} already exists.`);
                            }
                            /*var*/ let component = $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent.Create(this.renderer, componentType, ssrComponentId, $.$clone(key), parameters);
                            this._webRootComponents.Add(ssrComponentId, component);
                            ($t2 = this._currentUpdateTask, ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            ($t3 = component.RenderAsync$1(this.renderer), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477916792)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952753272)
                    /*Task */ UpdateRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952753272);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        return component.UpdateAsync(this.renderer, newComponentType, $.$clone(newKey), newParameters, this._currentUpdateTask);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952753272)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362818680)
                    /*void */ RemoveRootComponent(/*int*/ ssrComponentId)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362818680);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        component.Remove(this.renderer);
                        this._webRootComponents.Remove$1(ssrComponentId);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362818680)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772884088)
                    /*WebRootComponent */ GetRequiredWebRootComponent(/*int*/ ssrComponentId)
                    {
                        /*var*/ let component;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772884088);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._webRootComponents.TryGetValue(ssrComponentId, $.$ref(() => component, ($v) => component = $v, $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent)))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12(`No root component exists with SSR component ID ${$.$strNN(ssrComponentId)}.`);
                        }
                        return component;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772884088)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067851384)
                    /*ComponentMarkerKey */ GetRootComponentKey(/*int*/ componentId)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067851384);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $en5 = this._webRootComponents.GetEnumerator();
                        while ($en5.MoveNext())
                        {
                            let [ _0, candidate ] = $.$destructure($en5.Current, 2);
                            {
                                /*var*/ let  [ id, key, _6, _7 ] = $.$destructure(candidate, 4);
                                if (id === componentId)
                                {
                                    return key;
                                }
                            }
                        }
                        return new $.$macwa.MAC.ComponentMarkerKey();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067851384)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657785976)
                    /*void */ SetCurrentUpdateTask(/*Task*/ postStateTask)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657785976);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._currentUpdateTask = postStateTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657785976)
                    
                    //--TRIMMABLE-BOUNDARY-START(3145848)
                    static $_WebRootComponent;
                    static get WebRootComponent()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(3145848);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager;
                        return $cls.$_WebRootComponent ??= $asm.$ncls(`$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent`, ($self) => class WebRootComponent extends $.$$.S.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(4298113144)
                            /*Type*/ _componentType = null;
                            //--TRIMMABLE-BOUNDARY-END(4298113144)
                            
                            //--TRIMMABLE-BOUNDARY-START(21477982328)
                            /*string*/ _ssrComponentIdString = null;
                            //--TRIMMABLE-BOUNDARY-END(21477982328)
                            
                            //--TRIMMABLE-BOUNDARY-START(12888047736)
                            /*ComponentMarkerKey*/ _key;
                            //--TRIMMABLE-BOUNDARY-END(12888047736)
                            
                            //--TRIMMABLE-BOUNDARY-START(17183015032)
                            /*WebRootComponentParameters*/ _latestParameters;
                            //--TRIMMABLE-BOUNDARY-END(17183015032)
                            
                            //--TRIMMABLE-BOUNDARY-START(8593080440)
                            /*int*/ _interactiveComponentId = 0;
                            //--TRIMMABLE-BOUNDARY-END(8593080440)
                            
                            //--TRIMMABLE-BOUNDARY-START(30067916920)
                            static /*WebRootComponent */ Create(/*Renderer*/ renderer, /*Type*/ componentType, /*int*/ ssrComponentId, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ initialParameters)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30067916920);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (!$.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey).HasValue$get.call(key))
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("An invalid component marker key was provided.");
                                }
                                /*var*/ let ssrComponentIdString = $.$$.S.Int32.ToString$1.call(ssrComponentId, $.$$.SG.CultureInfo.InvariantCulture);
                                /*var*/ let interactiveComponentId = renderer.AddRootComponent(componentType, ssrComponentIdString);
                                return new $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent().$ctor$1(componentType, ssrComponentIdString, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey).Value$get.call(key), interactiveComponentId, $.$ref(() => initialParameters, ));
                            }
                            //--TRIMMABLE-BOUNDARY-END(30067916920)
                            
                            //--TRIMMABLE-BOUNDARY-START(25772949624)
                            $ctor$1(/*Type*/ componentType, /*string*/ ssrComponentIdString, /*ComponentMarkerKey*/ key, /*int*/ interactiveComponentId, /*in WebRootComponentParameters*/ initialParameters)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(25772949624);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._componentType = componentType;
                                    this._ssrComponentIdString = ssrComponentIdString;
                                    this._key = $.$clone(key);
                                    this._interactiveComponentId = interactiveComponentId;
                                    this._latestParameters = initialParameters.$v;
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(25772949624)
                            
                            //--TRIMMABLE-BOUNDARY-START(34362884216)
                            /*void */ Deconstruct(/*out int*/ interactiveComponentId, /*out ComponentMarkerKey*/ key, /*out Type*/ componentType, /*out ParameterView*/ parameters)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(34362884216);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                interactiveComponentId.$v = this._interactiveComponentId;
                                key.$v = $.$clone(this._key);
                                componentType.$v = this._componentType;
                                parameters.$v = this._latestParameters.Parameters;
                            }
                            //--TRIMMABLE-BOUNDARY-END(34362884216)
                            
                            //--TRIMMABLE-BOUNDARY-START(51542753400)
                            /*Task */ UpdateAsync(/*Renderer*/ renderer, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters, /*Task*/ currentUpdateTask)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51542753400);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._componentType !== newComponentType)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("Cannot update components with mismatching types.");
                                }
                                if (!$.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey).HasValue$get.call(newKey))
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("An invalid component marker key was provided.");
                                }
                                if (!$.$$.S.String.Equals$3(this._key.LocationHash, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey).Value$get.call(newKey).LocationHash, 4/*StringComparison.Ordinal*/) || !$.$$.S.String.Equals$3(this._key.FormattedComponentKey, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarkerKey).Value$get.call(newKey).FormattedComponentKey, 4/*StringComparison.Ordinal*/))
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12("Cannot update components with mismatching keys.");
                                }
                                if (!$.$$.S.String.IsNullOrEmpty(this._key.FormattedComponentKey))
                                {
                                    this._latestParameters = newParameters;
                                    return this.RenderAsync(renderer, currentUpdateTask);
                                }
                                else 
                                {
                                    if (this._latestParameters.DefinitelyEquals($.$ref(() => newParameters, )))
                                    {
                                        return $.$$.STT.Task.CompletedTask;
                                    }
                                    else 
                                    {
                                        renderer.RemoveRootComponent(this._interactiveComponentId);
                                        this._interactiveComponentId = renderer.AddRootComponent(this._componentType, this._ssrComponentIdString);
                                        this._latestParameters = newParameters;
                                        return this.RenderAsync(renderer, currentUpdateTask);
                                    }
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(51542753400)
                            
                            //--TRIMMABLE-BOUNDARY-START(47247786104)
                            /*Task */ RenderAsync$1(/*Renderer*/ renderer)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47247786104);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return renderer.RenderRootComponentAsync(this._interactiveComponentId, this._latestParameters.Parameters);
                            }
                            //--TRIMMABLE-BOUNDARY-END(47247786104)
                            
                            //--TRIMMABLE-BOUNDARY-START(42952818808)
                            /*Task *//*async*/  RenderAsync(/*Renderer*/ renderer, /*Task*/ updateTask)
                            {
                                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                                {
                                    let $t8, $r8;
                                    let $t9, $r9;
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(42952818808);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    ($t8 = updateTask, ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                                    ($t9 = renderer.RenderRootComponentAsync(this._interactiveComponentId, this._latestParameters.Parameters), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                                });
                            }
                            //--TRIMMABLE-BOUNDARY-END(42952818808)
                            
                            //--TRIMMABLE-BOUNDARY-START(38657851512)
                            /*void */ Remove(/*Renderer*/ renderer)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(38657851512);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                renderer.RemoveRootComponent(this._interactiveComponentId);
                            }
                            //--TRIMMABLE-BOUNDARY-END(38657851512)
                            
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(12888047736)
                                this._key = $.$default($.$macwa.MAC.ComponentMarkerKey);
                                //--TRIMMABLE-BOUNDARY-END(12888047736)
                                
                                //--TRIMMABLE-BOUNDARY-START(17183015032)
                                this._latestParameters = $.$default($.$macwa.MAC.WebRootComponentParameters);
                                //--TRIMMABLE-BOUNDARY-END(17183015032)
                                
                            }
                            static $h = 3145848;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Object; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067916920),
    {
      "r": 3145848,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        },
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h
        },
        {
          "n": "initialParameters",
          "p": 4391032
        }
      ],
      "n": "Create",
      "d": 3145848,
      "h": 30067916920,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067916920),
//--TRIMMABLE-BOUNDARY-START(34362884216),
    {
      "r": 65537,
      "p": [
        {
          "n": "interactiveComponentId",
          "p": 655361,
          "f": 2
        },
        {
          "n": "key",
          "p": 196728,
          "f": 2
        },
        {
          "n": "componentType",
          "p": 188547073,
          "f": 2
        },
        {
          "n": "parameters",
          "p": 5767283,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 3145848,
      "h": 34362884216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362884216),
//--TRIMMABLE-BOUNDARY-START(51542753400),
    {
      "r": 178454529,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        },
        {
          "n": "newComponentType",
          "p": 188547073
        },
        {
          "n": "newKey",
          "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h
        },
        {
          "n": "newParameters",
          "p": 4391032
        },
        {
          "n": "currentUpdateTask",
          "p": 178454529
        }
      ],
      "n": "UpdateAsync",
      "d": 3145848,
      "h": 51542753400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542753400),
//--TRIMMABLE-BOUNDARY-START(47247786104),
    {
      "r": 178454529,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        }
      ],
      "n": "RenderAsync",
      "o": "@$1",
      "d": 3145848,
      "h": 47247786104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47247786104),
//--TRIMMABLE-BOUNDARY-START(42952818808),
    {
      "r": 178454529,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        },
        {
          "n": "updateTask",
          "p": 178454529
        }
      ],
      "n": "RenderAsync",
      "d": 3145848,
      "h": 42952818808,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(42952818808),
//--TRIMMABLE-BOUNDARY-START(38657851512),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        }
      ],
      "n": "Remove",
      "d": 3145848,
      "h": 38657851512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657851512)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298113144),
    {
      "t": 188547073,
      "n": "_componentType",
      "d": 3145848,
      "h": 4298113144,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298113144),
//--TRIMMABLE-BOUNDARY-START(21477982328),
    {
      "t": 1310721,
      "n": "_ssrComponentIdString",
      "d": 3145848,
      "h": 21477982328,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477982328),
//--TRIMMABLE-BOUNDARY-START(12888047736),
    {
      "t": 196728,
      "n": "_key",
      "d": 3145848,
      "h": 12888047736,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888047736),
//--TRIMMABLE-BOUNDARY-START(17183015032),
    {
      "t": 4391032,
      "n": "_latestParameters",
      "d": 3145848,
      "h": 17183015032,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17183015032),
//--TRIMMABLE-BOUNDARY-START(8593080440),
    {
      "t": 655361,
      "n": "_interactiveComponentId",
      "d": 3145848,
      "h": 8593080440,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593080440)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772949624),
    {
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "ssrComponentIdString",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 196728
        },
        {
          "n": "interactiveComponentId",
          "p": 655361
        },
        {
          "n": "initialParameters",
          "p": 4391032,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3145848,
      "h": 25772949624,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772949624)
  ],
  "d": 3080312,
  "h": 3145848
}; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer+WebRootComponentManager+WebRootComponent`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyRenderer${separator}WebRootComponentManager${separator}WebRootComponent`; }
                        }, $cls, ($v) => $cls.$_WebRootComponent = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(3145848)
                    
                    //Begin primary constructor
                    /*Renderer*/ renderer = null;
                    $ctor$1(/*Renderer*/renderer)
                    {
                        this.renderer = renderer;
                        super.$ctor();
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8593014904)
                        this._webRootComponents = new ($.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(8593014904)
                        
                        //--TRIMMABLE-BOUNDARY-START(4298047608)
                        this._currentUpdateTask = $.$$.STT.Task.CompletedTask;
                        //--TRIMMABLE-BOUNDARY-END(4298047608)
                        
                    }
                    static $h = 3080312;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477916792),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h
        },
        {
          "n": "parameters",
          "p": 4391032
        }
      ],
      "n": "AddRootComponentAsync",
      "d": 3080312,
      "h": 21477916792,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21477916792),
//--TRIMMABLE-BOUNDARY-START(42952753272),
    {
      "r": 178454529,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "newComponentType",
          "p": 188547073
        },
        {
          "n": "newKey",
          "p": $.$typeNullable($.$macwa.MAC.ComponentMarkerKey).$h
        },
        {
          "n": "newParameters",
          "p": 4391032
        }
      ],
      "n": "UpdateRootComponentAsync",
      "d": 3080312,
      "h": 42952753272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952753272),
//--TRIMMABLE-BOUNDARY-START(34362818680),
    {
      "r": 65537,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        }
      ],
      "n": "RemoveRootComponent",
      "d": 3080312,
      "h": 34362818680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362818680),
//--TRIMMABLE-BOUNDARY-START(25772884088),
    {
      "r": 3145848,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        }
      ],
      "n": "GetRequiredWebRootComponent",
      "d": 3080312,
      "h": 25772884088,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772884088),
//--TRIMMABLE-BOUNDARY-START(30067851384),
    {
      "r": 196728,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        }
      ],
      "n": "GetRootComponentKey",
      "d": 3080312,
      "h": 30067851384,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30067851384),
//--TRIMMABLE-BOUNDARY-START(38657785976),
    {
      "r": 65537,
      "p": [
        {
          "n": "postStateTask",
          "p": 178454529
        }
      ],
      "n": "SetCurrentUpdateTask",
      "d": 3080312,
      "h": 38657785976,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38657785976)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887982200),
    {
      "t": 2949240,
      "n": "\u003Crenderer\u003EP",
      "d": 3080312,
      "h": 12887982200,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887982200),
//--TRIMMABLE-BOUNDARY-START(8593014904),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Int32, $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent).$h,
      "n": "_webRootComponents",
      "d": 3080312,
      "h": 8593014904,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593014904),
//--TRIMMABLE-BOUNDARY-START(4298047608),
    {
      "t": 178454529,
      "n": "_currentUpdateTask",
      "d": 3080312,
      "h": 4298047608,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298047608)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182949496),
    {
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080312,
      "h": 17182949496,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182949496)
  ],
  "d": 2949240,
  "h": 3080312
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer+WebRootComponentManager`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyRenderer${separator}WebRootComponentManager`; }
                }, $cls, ($v) => $cls.$_WebRootComponentManager = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3080312)
            
            //--TRIMMABLE-BOUNDARY-START(21477785720)
            /*ILogger*/ _logger$1 = null;
            //--TRIMMABLE-BOUNDARY-END(21477785720)
            
            //--TRIMMABLE-BOUNDARY-START(12887851128)
            /*Dispatcher*/ _dispatcher = null;
            //--TRIMMABLE-BOUNDARY-END(12887851128)
            
            //--TRIMMABLE-BOUNDARY-START(25772753016)
            /*ResourceAssetCollection*/ _resourceCollection = null;
            //--TRIMMABLE-BOUNDARY-END(25772753016)
            
            //--TRIMMABLE-BOUNDARY-START(17182818424)
            /*IInternalJSImportMethods*/ _jsMethods = null;
            //--TRIMMABLE-BOUNDARY-END(17182818424)
            
            //--TRIMMABLE-BOUNDARY-START(8592883832)
            /*ComponentStatePersistenceManager*/ _componentStatePersistenceManager = null;
            //--TRIMMABLE-BOUNDARY-END(8592883832)
            
            //--TRIMMABLE-BOUNDARY-START(4297916536)
            /*RendererInfo*/ static _componentPlatform = null;
            //--TRIMMABLE-BOUNDARY-END(4297916536)
            
            //--TRIMMABLE-BOUNDARY-START(38657654904)
            $ctor$4(/*IServiceProvider*/ serviceProvider, /*ResourceAssetCollection*/ resourceCollection, /*ILoggerFactory*/ loggerFactory, /*JSComponentInterop*/ jsComponentInterop)
            {
                super.$ctor$3(serviceProvider, loggerFactory, $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance.ReadJsonSerializerOptions(), jsComponentInterop);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657654904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._logger$1 = $.$mexla.MEL.LoggerFactoryExtensions.CreateLogger$1($.$macwa.MACWR.WebAssemblyRenderer, loggerFactory);
                    this._jsMethods = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.MACWS.IInternalJSImportMethods, serviceProvider);
                    this._componentStatePersistenceManager = $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.MACI.ComponentStatePersistenceManager, serviceProvider);
                    this._dispatcher = $.$macwa.MACWR.WebAssemblyDispatcher._mainSynchronizationContext === null ? $.$macwa.MACWR.NullDispatcher.Instance : new $.$macwa.MACWR.WebAssemblyDispatcher().$ctor$2();
                    this._resourceCollection = resourceCollection;
                    this.ElementReferenceContext = $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance.ElementReferenceContext;
                    $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance.add_OnUpdateRootComponents(new ($.$$.S.Action$$$($.$macwa.MAC.RootComponentOperationBatch, $.$$.S.String))().$ctor(this, this.OnUpdateRootComponents));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657654904)
            
            //--TRIMMABLE-BOUNDARY-START(128851968120)
            /*void */ OnUpdateRootComponents(/*RootComponentOperationBatch*/ batch, /*string*/ appState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851968120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let webRootComponentManager = this.GetOrCreateWebRootComponentManager();
                /*TaskCompletionSource?*/ let taskCompletionSource = null;
                /*var*/ let stateUpdateTask = $.$$.STT.Task.CompletedTask;
                /*var*/ let store = !$.$$.S.String.IsNullOrEmpty(appState) ? new $.$macwa.MAC.PrerenderComponentApplicationStore().$ctor$2(appState) : null;
                if (store !== null)
                {
                    taskCompletionSource = new $.$$.STT.TaskCompletionSource().$ctor$1();
                    stateUpdateTask = $.$macwa.MACWR.WebAssemblyRenderer.EnqueueRestore(taskCompletionSource.Task, this._componentStatePersistenceManager, store);
                }
                webRootComponentManager.SetCurrentUpdateTask(stateUpdateTask);
                for(/*var*/ let i = 0; i < batch.Operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(batch.Operations, i);
                    let $switch10 = operation.Type;
                    switch($switch10)
                    {
                        case 0/*RootComponentOperationType.Add*/:
                        _ = webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker).Key, operation.Descriptor.Parameters);
                        break;
                        case 1/*RootComponentOperationType.Update*/:
                        _ = webRootComponentManager.UpdateRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters);
                        break;
                        case 2/*RootComponentOperationType.Remove*/:
                        webRootComponentManager.RemoveRootComponent(operation.SsrComponentId);
                        break;
                    }
                }
                taskCompletionSource?.SetResult();
                store?.ExistingState.Clear();
                this.NotifyEndUpdateRootComponents(batch.BatchId);
            }
            //--TRIMMABLE-BOUNDARY-END(128851968120)
            
            //--TRIMMABLE-BOUNDARY-START(73017393272)
            static /*Task *//*async*/  EnqueueRestore(/*Task*/ task, /*ComponentStatePersistenceManager*/ componentStatePersistenceManager, /*PrerenderComponentApplicationStore*/ store)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t11, $r11;
                    let $t12, $r12;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017393272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t11 = task, ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                    ($t12 = componentStatePersistenceManager.RestoreStateAsync(store, $.$mac.MAC.RestoreContext.ValueUpdate), ($.$$.N.AsyncResolver.IsCompleted($t12, { set $v($v) { $r12 = $v; } }) ? $r12 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t12)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73017393272)
            
            //--TRIMMABLE-BOUNDARY-START(103082164344)
            /*IComponentRenderMode? */ GetComponentRenderMode(/*IComponent*/ component)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082164344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macw.MACW.RenderMode.InteractiveWebAssembly;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103082164344)
            
            //--TRIMMABLE-BOUNDARY-START(124557000824)
            /*void */ NotifyEndUpdateRootComponents(/*long*/ batchId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557000824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jsMethods.MACWS$IInternalJSImportMethods$EndUpdateRootComponents(batchId);
            }
            //--TRIMMABLE-BOUNDARY-END(124557000824)
            
            //--TRIMMABLE-BOUNDARY-START(47247589496)
            /*ResourceAssetCollection */ get Assets()
            {
                return this._resourceCollection;
            }
            //--TRIMMABLE-BOUNDARY-END(47247589496)
            
            //--TRIMMABLE-BOUNDARY-START(141736870008)
            /*RendererInfo */ get RendererInfo()
            {
                return $.$macwa.MACWR.WebAssemblyRenderer._componentPlatform;
            }
            //--TRIMMABLE-BOUNDARY-END(141736870008)
            
            //--TRIMMABLE-BOUNDARY-START(64427458680)
            /*Dispatcher */ get Dispatcher()
            {
                return this._dispatcher;
            }
            //--TRIMMABLE-BOUNDARY-END(64427458680)
            
            //--TRIMMABLE-BOUNDARY-START(42952622200)
            /*Task */ AddComponentAsync(/*Type*/ componentType, /*ParameterView*/ parameters, /*string*/ domElementSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952622200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let componentId = this.AddRootComponent(componentType, domElementSelector);
                return this.RenderRootComponentAsync(componentId, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(42952622200)
            
            //--TRIMMABLE-BOUNDARY-START(115967066232)
            /*int */ GetWebRendererId()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115967066232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 2/*WebRendererId.WebAssembly*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115967066232)
            
            //--TRIMMABLE-BOUNDARY-START(51542556792)
            /*void */ AttachRootComponentToBrowser(/*int*/ componentId, /*string*/ domElementSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542556792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jsMethods.MACWS$IInternalJSImportMethods$AttachRootComponentToElement(domElementSelector, componentId, this.RendererId);
            }
            //--TRIMMABLE-BOUNDARY-END(51542556792)
            
            //--TRIMMABLE-BOUNDARY-START(68722425976)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722425976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(68722425976)
            
            //--TRIMMABLE-BOUNDARY-START(133146935416)
            /*void */ ProcessPendingRender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146935416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.MACWH.WebAssemblyCallQueue.IsInProgress)
                {
                    super.ProcessPendingRender();
                }
                else 
                {
                    $.$macwa.MACWH.WebAssemblyCallQueue.Schedule($.$macwa.MACWR.WebAssemblyRenderer, this, new ($.$$.S.Action$$($.$macwa.MACWR.WebAssemblyRenderer))().$ctor($.$macwa.MACWR.WebAssemblyRenderer, /*static*/ (/**/ $this) =>
                    {
                        return $this.CallBaseProcessPendingRender();
                    }, $KoaGNi ??= {"r":65537,"p":[{"n":"this","p":2949240}],"n":"","d":2949240,"h":0,"f":17825826}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146935416)
            
            //--TRIMMABLE-BOUNDARY-START(55837524088)
            /*void */ CallBaseProcessPendingRender()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837524088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return super.ProcessPendingRender();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837524088)
            
            //--TRIMMABLE-BOUNDARY-START(150326804600)
            /*Task */ UpdateDisplayAsync(/*in RenderBatch*/ batch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326804600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let batchCopy = batch.$v;
                Blazor._internal.renderBatch(this.RendererId, $.$$.SRC.Unsafe.AsPointer($.$mac.MACR$2.RenderBatch, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$mac.MACR$2.RenderBatch, () => batchCopy, ($v) => batchCopy = $v, null, true)));
                if ($.$macwa.MACWH.WebAssemblyCallQueue.HasUnstartedWork)
                {
                    /*var*/ let tcs = new $.$$.STT.TaskCompletionSource().$ctor$1();
                    $.$macwa.MACWH.WebAssemblyCallQueue.Schedule($.$$.STT.TaskCompletionSource, tcs, new ($.$$.S.Action$$($.$$.STT.TaskCompletionSource))().$ctor($.$macwa.MACWR.WebAssemblyRenderer, /*static*/ (/*tcs*/ tcs) =>
                    {
                        return tcs.SetResult();
                    }, $JMdqXa ??= {"r":65537,"p":[{"n":"tcs","p":179568641}],"n":"","d":2949240,"h":0,"f":17825826}));
                    return tcs.Task;
                }
                else 
                {
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150326804600)
            
            //--TRIMMABLE-BOUNDARY-START(120262033528)
            /*void */ HandleException(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262033528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let aggregateException;
                if ($.$is(exception, $.$$.S.AggregateException, { set $v($v){ aggregateException = $v; } }))
                {
                    let $en14 = aggregateException.Flatten().InnerExceptions.GetEnumerator();
                    while ($en14.SC$1$IEnumerator$MoveNext())
                    {
                        let innerException = $en14.SCG$IEnumerator$$$Current;
                        {
                            $.$macwa.MACWR.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger$1, innerException.Message, innerException);
                        }
                    }
                }
                else 
                {
                    $.$macwa.MACWR.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger$1, exception.Message, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262033528)
            
            //--TRIMMABLE-BOUNDARY-START(146031837304)
            /*IComponent */ ResolveComponentForRenderMode(/*Type*/ componentType, /*int?*/ parentComponentId, /*IComponentActivator*/ componentActivator, /*IComponentRenderMode*/ renderMode)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146031837304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if ((renderMode === $.$macw.MACW.InteractiveWebAssemblyRenderMode) || (renderMode === $.$macw.MACW.InteractiveAutoRenderMode))
                        {
                            return componentActivator.MAC$IComponentActivator$CreateInstance(componentType);
                        }
                        throw new $.$$.S.NotSupportedException().$ctor$12(`Cannot create a component of type '${$.$strNN(componentType.ToString())}' because its render mode '${$.$strNN($.$dsp(renderMode, $.$$.S.Object, ($t) => $t.ToString))}' is not supported by WebAssembly rendering.`);
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146031837304)
            
            //--TRIMMABLE-BOUNDARY-START(60132491384)
            /*ComponentState */ CreateComponentState(/*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$macwa.MACWR.WebAssemblyComponentState().$ctor$2(this, componentId, component, parentComponentState);
            }
            //--TRIMMABLE-BOUNDARY-END(60132491384)
            
            //--TRIMMABLE-BOUNDARY-START(107377131640)
            /*ComponentMarkerKey */ GetMarkerKey(/*WebAssemblyComponentState*/ webAssemblyComponentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377131640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return webAssemblyComponentState.ParentComponentState !== null ? new $.$macwa.MAC.ComponentMarkerKey() : this._webRootComponentManager.GetRootComponentKey(webAssemblyComponentState.ComponentId);
            }
            //--TRIMMABLE-BOUNDARY-END(107377131640)
            
            //--TRIMMABLE-BOUNDARY-START(34362687608)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362687608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297916536)
                    this._componentPlatform = new $.$mac.MAC.RendererInfo().$ctor$1("WebAssembly", true);
                    //--TRIMMABLE-BOUNDARY-END(4297916536)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362687608)
            
            static $h = 2949240;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$macw.MACR$1.WebRenderer; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247589496),
    {
      "p": 9437299,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607327864,
        "f": 50364420
      },
      "n": "Assets",
      "d": 2949240,
      "h": 47247589496,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(47247589496),
//--TRIMMABLE-BOUNDARY-START(141736870008),
    {
      "p": 6815859,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787197048,
        "f": 50364420
      },
      "n": "RendererInfo",
      "d": 2949240,
      "h": 141736870008,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(141736870008),
//--TRIMMABLE-BOUNDARY-START(64427458680),
    {
      "p": 1704051,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197262456,
        "f": 50364417
      },
      "n": "Dispatcher",
      "d": 2949240,
      "h": 64427458680,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64427458680)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111672098936),
    {
      "r": 3080312,
      "n": "GetOrCreateWebRootComponentManager",
      "d": 2949240,
      "h": 111672098936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111672098936),
//--TRIMMABLE-BOUNDARY-START(128851968120),
    {
      "r": 65537,
      "p": [
        {
          "n": "batch",
          "p": 1048696
        },
        {
          "n": "appState",
          "p": 1310721
        }
      ],
      "n": "OnUpdateRootComponents",
      "d": 2949240,
      "h": 128851968120,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851968120),
//--TRIMMABLE-BOUNDARY-START(73017393272),
    {
      "r": 178454529,
      "p": [
        {
          "n": "task",
          "p": 178454529
        },
        {
          "n": "componentStatePersistenceManager",
          "p": 3342451
        },
        {
          "n": "store",
          "p": 721016
        }
      ],
      "n": "EnqueueRestore",
      "d": 2949240,
      "h": 73017393272,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(73017393272),
//--TRIMMABLE-BOUNDARY-START(103082164344),
    {
      "r": 2883699,
      "p": [
        {
          "n": "component",
          "p": 2752627
        }
      ],
      "n": "GetComponentRenderMode",
      "d": 2949240,
      "h": 103082164344,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103082164344),
//--TRIMMABLE-BOUNDARY-START(124557000824),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "NotifyEndUpdateRootComponents",
      "d": 2949240,
      "h": 124557000824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124557000824),
//--TRIMMABLE-BOUNDARY-START(42952622200),
    {
      "r": 178454529,
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "parameters",
          "p": 5767283
        },
        {
          "n": "domElementSelector",
          "p": 1310721
        }
      ],
      "n": "AddComponentAsync",
      "d": 2949240,
      "h": 42952622200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952622200),
//--TRIMMABLE-BOUNDARY-START(115967066232),
    {
      "r": 655361,
      "n": "GetWebRendererId",
      "d": 2949240,
      "h": 115967066232,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(115967066232),
//--TRIMMABLE-BOUNDARY-START(51542556792),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "domElementSelector",
          "p": 1310721
        }
      ],
      "n": "AttachRootComponentToBrowser",
      "d": 2949240,
      "h": 51542556792,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51542556792),
//--TRIMMABLE-BOUNDARY-START(68722425976),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2949240,
      "h": 68722425976,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68722425976),
//--TRIMMABLE-BOUNDARY-START(133146935416),
    {
      "r": 65537,
      "n": "ProcessPendingRender",
      "d": 2949240,
      "h": 133146935416,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(133146935416),
//--TRIMMABLE-BOUNDARY-START(55837524088),
    {
      "r": 65537,
      "n": "CallBaseProcessPendingRender",
      "d": 2949240,
      "h": 55837524088,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837524088),
//--TRIMMABLE-BOUNDARY-START(150326804600),
    {
      "r": 178454529,
      "p": [
        {
          "n": "batch",
          "p": 8388723,
          "f": 8
        }
      ],
      "n": "UpdateDisplayAsync",
      "d": 2949240,
      "h": 150326804600,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(150326804600),
//--TRIMMABLE-BOUNDARY-START(120262033528),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80805889
        }
      ],
      "n": "HandleException",
      "d": 2949240,
      "h": 120262033528,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(120262033528),
//--TRIMMABLE-BOUNDARY-START(146031837304),
    {
      "r": 2752627,
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "parentComponentId",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "componentActivator",
          "p": 2818163
        },
        {
          "n": "renderMode",
          "p": 2883699
        }
      ],
      "n": "ResolveComponentForRenderMode",
      "d": 2949240,
      "h": 146031837304,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(146031837304),
//--TRIMMABLE-BOUNDARY-START(60132491384),
    {
      "r": 7078003,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2752627
        },
        {
          "n": "parentComponentState",
          "p": 7078003
        }
      ],
      "n": "CreateComponentState",
      "d": 2949240,
      "h": 60132491384,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60132491384),
//--TRIMMABLE-BOUNDARY-START(107377131640),
    {
      "r": 196728,
      "p": [
        {
          "n": "webAssemblyComponentState",
          "p": 2818168
        }
      ],
      "n": "GetMarkerKey",
      "d": 2949240,
      "h": 107377131640,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(107377131640)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067720312),
    {
      "t": 3080312,
      "n": "_webRootComponentManager",
      "d": 2949240,
      "h": 30067720312,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067720312),
//--TRIMMABLE-BOUNDARY-START(21477785720),
    {
      "t": 917592,
      "n": "_logger",
      "o": "@$1",
      "d": 2949240,
      "h": 21477785720,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477785720),
//--TRIMMABLE-BOUNDARY-START(12887851128),
    {
      "t": 1704051,
      "n": "_dispatcher",
      "d": 2949240,
      "h": 12887851128,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887851128),
//--TRIMMABLE-BOUNDARY-START(25772753016),
    {
      "t": 9437299,
      "n": "_resourceCollection",
      "d": 2949240,
      "h": 25772753016,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772753016),
//--TRIMMABLE-BOUNDARY-START(17182818424),
    {
      "t": 3342456,
      "n": "_jsMethods",
      "d": 2949240,
      "h": 17182818424,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182818424),
//--TRIMMABLE-BOUNDARY-START(8592883832),
    {
      "t": 3342451,
      "n": "_componentStatePersistenceManager",
      "d": 2949240,
      "h": 8592883832,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592883832),
//--TRIMMABLE-BOUNDARY-START(4297916536),
    {
      "t": 6815859,
      "n": "_componentPlatform",
      "d": 2949240,
      "h": 4297916536,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297916536)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38657654904),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "resourceCollection",
          "p": 9437299
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        },
        {
          "n": "jsComponentInterop",
          "p": 5898357
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2949240,
      "h": 38657654904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657654904)
  ],
  "h": 2949240
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$macwa.MACWR.WebAssemblyRenderer.Log, $.$macwa.MACWR.WebAssemblyRenderer.WebRootComponentManager ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949240)
        
        

        //--TRIMMABLE-BOUNDARY-START(852088)
        $asm.$cls(`$macwa.MAC.PullFromJSDataStream`, ($self) => class PullFromJSDataStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(12885753976)
            /*IJSRuntime*/ _runtime = null;
            //--TRIMMABLE-BOUNDARY-END(12885753976)
            
            //--TRIMMABLE-BOUNDARY-START(4295819384)
            /*IJSStreamReference*/ _jsStreamReference = null;
            //--TRIMMABLE-BOUNDARY-END(4295819384)
            
            //--TRIMMABLE-BOUNDARY-START(21475688568)
            /*long*/ _totalLength = 0n;
            //--TRIMMABLE-BOUNDARY-END(21475688568)
            
            //--TRIMMABLE-BOUNDARY-START(17180721272)
            /*CancellationToken*/ _streamCancellationToken;
            //--TRIMMABLE-BOUNDARY-END(17180721272)
            
            //--TRIMMABLE-BOUNDARY-START(8590786680)
            /*long*/ _offset = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590786680)
            
            //--TRIMMABLE-BOUNDARY-START(42950525048)
            static /*PullFromJSDataStream */ CreateJSDataStream(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsDataStream = new $.$macwa.MAC.PullFromJSDataStream().$ctor$3(runtime, jsStreamReference, totalLength, cancellationToken);
                return jsDataStream;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525048)
            
            //--TRIMMABLE-BOUNDARY-START(25770655864)
            $ctor$3(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._runtime = runtime;
                    this._jsStreamReference = jsStreamReference;
                    this._totalLength = totalLength;
                    this._streamCancellationToken = cancellationToken;
                    this._offset = 0n;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655864)
            
            //--TRIMMABLE-BOUNDARY-START(30065623160)
            /*bool */ get CanRead()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623160)
            
            //--TRIMMABLE-BOUNDARY-START(34360590456)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34360590456)
            
            //--TRIMMABLE-BOUNDARY-START(38655557752)
            /*bool */ get CanWrite()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655557752)
            
            //--TRIMMABLE-BOUNDARY-START(98785099896)
            /*long */ get Length()
            {
                return this._totalLength;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099896)
            
            //--TRIMMABLE-BOUNDARY-START(103080067192)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._offset;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(103080067192)
            
            //--TRIMMABLE-BOUNDARY-START(47245492344)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245492344)
            
            //--TRIMMABLE-BOUNDARY-START(51540459640)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540459640);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459640)
            
            //--TRIMMABLE-BOUNDARY-START(107375034488)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375034488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$12("Synchronous reads are not supported.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375034488)
            
            //--TRIMMABLE-BOUNDARY-START(124554903672)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554903672);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554903672)
            
            //--TRIMMABLE-BOUNDARY-START(137439805560)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439805560);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439805560)
            
            //--TRIMMABLE-BOUNDARY-START(146029740152)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029740152);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029740152)
            
            //--TRIMMABLE-BOUNDARY-START(111670001784)
            /*Task<int> *//*async*/  ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670001784)
            
            //--TRIMMABLE-BOUNDARY-START(115964969080)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964969080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let bytesRead = ($t2 = this.RequestDataFromJSAsync(buffer.Length), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    this.ThrowIfCancellationRequested(cancellationToken);
                    $.$$.S.MemoryExtensions.CopyTo($.$$.S.Byte, bytesRead, buffer);
                    return $.$$.N.AsyncResolver.Result($asnycContext, bytesRead.length);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964969080)
            
            //--TRIMMABLE-BOUNDARY-START(141734772856)
            /*void */ ThrowIfCancellationRequested(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734772856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested || this._streamCancellationToken.IsCancellationRequested)
                {
                    throw new $.$$.STT.TaskCanceledException().$ctor$16();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734772856)
            
            //--TRIMMABLE-BOUNDARY-START(120259936376)
            /*ValueTask<byte[]> *//*async*/  RequestDataFromJSAsync(/*int*/ numBytesToRead)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$typeArray($.$$.S.Byte)), $.$typeArray($.$$.S.Byte), async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259936376);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    numBytesToRead = $.$cast($.$$.S.Math.Min$5(BigInt(numBytesToRead), BigInt.asIntN(64, this._totalLength - this._offset)), $.$$.S.Int32);
                    /*var*/ let bytesRead = ($t3 = $.$mj.MJ.JSRuntimeExtensions.InvokeAsync($.$typeArray($.$$.S.Byte), this._runtime, "Blazor._internal.getJSDataStreamChunk", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this._jsStreamReference, $.$box(this._offset, $.$$.S.Int64), $.$box(numBytesToRead, $.$$.S.Int32) ], null, null)), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    if (bytesRead.length !== numBytesToRead)
                    {
                        throw new $.$$.SI.EndOfStreamException().$ctor$17("Failed to read the requested number of bytes from the stream.");
                    }
                    this._offset += BigInt(bytesRead.length);
                    if (this._offset === this._totalLength)
                    {
                        this.Dispose$1(true);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, bytesRead);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120259936376)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180721272)
                this._streamCancellationToken = $.$default($.$$.ST$1.CancellationToken);
                //--TRIMMABLE-BOUNDARY-END(17180721272)
                
            }
            static $h = 852088;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065623160),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394232,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 852088,
      "h": 30065623160,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065623160),
//--TRIMMABLE-BOUNDARY-START(34360590456),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328824,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 852088,
      "h": 34360590456,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360590456),
//--TRIMMABLE-BOUNDARY-START(38655557752),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263416,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 852088,
      "h": 38655557752,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655557752),
//--TRIMMABLE-BOUNDARY-START(98785099896),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900198008,
        "f": 50364417
      },
      "n": "Length",
      "d": 852088,
      "h": 98785099896,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785099896),
//--TRIMMABLE-BOUNDARY-START(103080067192),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490132600,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144838264,
        "f": 83918849
      },
      "n": "Position",
      "d": 852088,
      "h": 103080067192,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(103080067192)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950525048),
    {
      "r": 852088,
      "p": [
        {
          "n": "runtime",
          "p": 524402
        },
        {
          "n": "jsStreamReference",
          "p": 589938
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CreateJSDataStream",
      "d": 852088,
      "h": 42950525048,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950525048),
//--TRIMMABLE-BOUNDARY-START(47245492344),
    {
      "r": 65537,
      "n": "Flush",
      "d": 852088,
      "h": 47245492344,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245492344),
//--TRIMMABLE-BOUNDARY-START(51540459640),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 852088,
      "h": 51540459640,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540459640),
//--TRIMMABLE-BOUNDARY-START(107375034488),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 852088,
      "h": 107375034488,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375034488),
//--TRIMMABLE-BOUNDARY-START(124554903672),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 852088,
      "h": 124554903672,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554903672),
//--TRIMMABLE-BOUNDARY-START(137439805560),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 852088,
      "h": 137439805560,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439805560),
//--TRIMMABLE-BOUNDARY-START(146029740152),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 852088,
      "h": 146029740152,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029740152),
//--TRIMMABLE-BOUNDARY-START(111670001784),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 852088,
      "h": 111670001784,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(111670001784),
//--TRIMMABLE-BOUNDARY-START(115964969080),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 852088,
      "h": 115964969080,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(115964969080),
//--TRIMMABLE-BOUNDARY-START(141734772856),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ThrowIfCancellationRequested",
      "d": 852088,
      "h": 141734772856,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734772856),
//--TRIMMABLE-BOUNDARY-START(120259936376),
    {
      "r": $.$$.STT.ValueTask$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "numBytesToRead",
          "p": 655361
        }
      ],
      "n": "RequestDataFromJSAsync",
      "d": 852088,
      "h": 120259936376,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(120259936376)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753976),
    {
      "t": 524402,
      "n": "_runtime",
      "d": 852088,
      "h": 12885753976,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753976),
//--TRIMMABLE-BOUNDARY-START(4295819384),
    {
      "t": 589938,
      "n": "_jsStreamReference",
      "d": 852088,
      "h": 4295819384,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819384),
//--TRIMMABLE-BOUNDARY-START(21475688568),
    {
      "t": 917505,
      "n": "_totalLength",
      "d": 852088,
      "h": 21475688568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688568),
//--TRIMMABLE-BOUNDARY-START(17180721272),
    {
      "t": 170852353,
      "n": "_streamCancellationToken",
      "d": 852088,
      "h": 17180721272,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721272),
//--TRIMMABLE-BOUNDARY-START(8590786680),
    {
      "t": 917505,
      "n": "_offset",
      "d": 852088,
      "h": 8590786680,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770655864),
    {
      "p": [
        {
          "n": "runtime",
          "p": 524402
        },
        {
          "n": "jsStreamReference",
          "p": 589938
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852088,
      "h": 25770655864,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770655864)
  ],
  "h": 852088
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.PullFromJSDataStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}PullFromJSDataStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852088)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114232)
        $asm.$str(`$macwa.MAC.RootComponentOperationType`, ($self) => class RootComponentOperationType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Add = 0;
            static Update = 1;
            static Remove = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Update": 1n,
                    "Remove": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296081528)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081528)
            
            //--TRIMMABLE-BOUNDARY-START(4296081528)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296081528)
            
            static $h = 1114232;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591048824),
    {
      "t": 1114232,
      "n": "Add",
      "d": 1114232,
      "h": 8591048824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591048824),
//--TRIMMABLE-BOUNDARY-START(17180983416),
    {
      "t": 1114232,
      "n": "Update",
      "d": 1114232,
      "h": 17180983416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180983416),
//--TRIMMABLE-BOUNDARY-START(12886016120),
    {
      "t": 1114232,
      "n": "Remove",
      "d": 1114232,
      "h": 12886016120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886016120)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081528),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114232,
      "h": 4296081528,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081528)
  ],
  "h": 1114232,
  "a": [
    {
      "t": 13631572,
      "c": 12898533460,
      "a": [
        {
          "v": $.$stj.STJS$1.JsonStringEnumConverter$$($.$macwa.MAC.RootComponentOperationType).$h,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.RootComponentOperationType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}RootComponentOperationType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114232)
        
        

        //--TRIMMABLE-BOUNDARY-START(4259960)
        $asm.$str(`$macwa.MAC.WebRendererId`, ($self) => class WebRendererId extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static Server = 1;
            static WebAssembly = 2;
            static WebView = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4259960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Server": 1n,
                    "WebAssembly": 2n,
                    "WebView": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4299227256)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299227256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4299227256)
            
            //--TRIMMABLE-BOUNDARY-START(4299227256)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4299227256)
            
            static $h = 4259960;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8594194552),
    {
      "t": 4259960,
      "n": "Default",
      "d": 4259960,
      "h": 8594194552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594194552),
//--TRIMMABLE-BOUNDARY-START(12889161848),
    {
      "t": 4259960,
      "n": "Server",
      "d": 4259960,
      "h": 12889161848,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889161848),
//--TRIMMABLE-BOUNDARY-START(17184129144),
    {
      "t": 4259960,
      "n": "WebAssembly",
      "d": 4259960,
      "h": 17184129144,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184129144),
//--TRIMMABLE-BOUNDARY-START(21479096440),
    {
      "t": 4259960,
      "n": "WebView",
      "d": 4259960,
      "h": 21479096440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479096440)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299227256),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4259960,
      "h": 4299227256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299227256)
  ],
  "h": 4259960
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebRendererId`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebRendererId`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4259960)
        
        

        //--TRIMMABLE-BOUNDARY-START(2424952)
        $asm.$str(`$macwa.MACWH$1.BrowserRequestCredentials`, ($self) => class BrowserRequestCredentials extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Omit = 0;
            static SameOrigin = 1;
            static Include = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2424952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Omit": 0n,
                    "SameOrigin": 1n,
                    "Include": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297392248)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297392248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297392248)
            
            //--TRIMMABLE-BOUNDARY-START(4297392248)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297392248)
            
            static $h = 2424952;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887326840),
    {
      "t": 2424952,
      "n": "Omit",
      "d": 2424952,
      "h": 12887326840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887326840),
//--TRIMMABLE-BOUNDARY-START(17182294136),
    {
      "t": 2424952,
      "n": "SameOrigin",
      "d": 2424952,
      "h": 17182294136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182294136),
//--TRIMMABLE-BOUNDARY-START(8592359544),
    {
      "t": 2424952,
      "n": "Include",
      "d": 2424952,
      "h": 8592359544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592359544)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392248),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2424952,
      "h": 4297392248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297392248)
  ],
  "h": 2424952
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCredentials`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Http${separator}BrowserRequestCredentials`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424952)
        
        

        //--TRIMMABLE-BOUNDARY-START(2490488)
        $asm.$str(`$macwa.MACWH$1.BrowserRequestMode`, ($self) => class BrowserRequestMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static SameOrigin = 0;
            static NoCors = 1;
            static Cors = 2;
            static Navigate = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SameOrigin": 0n,
                    "NoCors": 1n,
                    "Cors": 2n,
                    "Navigate": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297457784)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297457784)
            
            //--TRIMMABLE-BOUNDARY-START(4297457784)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297457784)
            
            static $h = 2490488;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477326968),
    {
      "t": 2490488,
      "n": "SameOrigin",
      "d": 2490488,
      "h": 21477326968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477326968),
//--TRIMMABLE-BOUNDARY-START(17182359672),
    {
      "t": 2490488,
      "n": "NoCors",
      "d": 2490488,
      "h": 17182359672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182359672),
//--TRIMMABLE-BOUNDARY-START(8592425080),
    {
      "t": 2490488,
      "n": "Cors",
      "d": 2490488,
      "h": 8592425080,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592425080),
//--TRIMMABLE-BOUNDARY-START(12887392376),
    {
      "t": 2490488,
      "n": "Navigate",
      "d": 2490488,
      "h": 12887392376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887392376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457784),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2490488,
      "h": 4297457784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297457784)
  ],
  "h": 2490488
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Http${separator}BrowserRequestMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490488)
        
        

        //--TRIMMABLE-BOUNDARY-START(2359416)
        $asm.$str(`$macwa.MACWH$1.BrowserRequestCache`, ($self) => class BrowserRequestCache extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static NoStore = 1;
            static Reload = 2;
            static NoCache = 3;
            static ForceCache = 4;
            static OnlyIfCached = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2359416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "NoStore": 1n,
                    "Reload": 2n,
                    "NoCache": 3n,
                    "ForceCache": 4n,
                    "OnlyIfCached": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4297326712)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297326712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326712)
            
            //--TRIMMABLE-BOUNDARY-START(4297326712)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4297326712)
            
            static $h = 2359416;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592294008),
    {
      "t": 2359416,
      "n": "Default",
      "d": 2359416,
      "h": 8592294008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592294008),
//--TRIMMABLE-BOUNDARY-START(21477195896),
    {
      "t": 2359416,
      "n": "NoStore",
      "d": 2359416,
      "h": 21477195896,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477195896),
//--TRIMMABLE-BOUNDARY-START(30067130488),
    {
      "t": 2359416,
      "n": "Reload",
      "d": 2359416,
      "h": 30067130488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067130488),
//--TRIMMABLE-BOUNDARY-START(17182228600),
    {
      "t": 2359416,
      "n": "NoCache",
      "d": 2359416,
      "h": 17182228600,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182228600),
//--TRIMMABLE-BOUNDARY-START(12887261304),
    {
      "t": 2359416,
      "n": "ForceCache",
      "d": 2359416,
      "h": 12887261304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887261304),
//--TRIMMABLE-BOUNDARY-START(25772163192),
    {
      "t": 2359416,
      "n": "OnlyIfCached",
      "d": 2359416,
      "h": 25772163192,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772163192)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326712),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359416,
      "h": 4297326712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297326712)
  ],
  "h": 2359416
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Http${separator}BrowserRequestCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359416)
        
        

        //--TRIMMABLE-BOUNDARY-START(3276920)
        $asm.$cls(`$macwa.MACWS.DefaultWebAssemblyJSRuntime`, ($self) => class DefaultWebAssemblyJSRuntime extends $.$mjw.MJW.WebAssemblyJSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(60132819064)
            /*DefaultWebAssemblyJSRuntime*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(60132819064)
            
            //--TRIMMABLE-BOUNDARY-START(4298244216)
            /*RootTypeCache*/ _rootComponentCache = null;
            //--TRIMMABLE-BOUNDARY-END(4298244216)
            
            //--TRIMMABLE-BOUNDARY-START(42952949880)
            /*ElementReferenceContext*/ ElementReferenceContext = null;
            //--TRIMMABLE-BOUNDARY-END(42952949880)
            
            //--TRIMMABLE-BOUNDARY-START(77312688248)
            /*Action<RootComponentOperationBatch, string>?*/ OnUpdateRootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(77312688248)
            
            //--TRIMMABLE-BOUNDARY-START(77312688248)
            //--TRIMMABLE-BOUNDARY-START(25773080696)
            add_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773080696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnUpdateRootComponents = $.$$.S.Delegate.Combine$2(this.OnUpdateRootComponents, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25773080696)
            
            //--TRIMMABLE-BOUNDARY-START(98787524728)
            remove_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787524728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnUpdateRootComponents = $.$$.S.Delegate.Remove(this.OnUpdateRootComponents, value);
            }
            //--TRIMMABLE-BOUNDARY-END(98787524728)
            
            //--TRIMMABLE-BOUNDARY-END(77312688248)
            
            //--TRIMMABLE-BOUNDARY-START(17183146104)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183146104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ElementReferenceContext = new $.$macw.MAC.WebElementReferenceContext().$ctor$2(this);
                    this.JsonSerializerOptions.Converters.SCG$ICollection$$$Add(new $.$macwa.MAC.ElementReferenceJsonConverter().$ctor$3(this.ElementReferenceContext));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183146104)
            
            //--TRIMMABLE-BOUNDARY-START(85902622840)
            /*JsonSerializerOptions */ ReadJsonSerializerOptions()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85902622840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.JsonSerializerOptions;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902622840)
            
            //--TRIMMABLE-BOUNDARY-START(64427786360)
            static /*string? */ InvokeDotNet(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427786360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let callInfo = new $.$mj.MJI$1.DotNetInvocationInfo().$ctor$3(assemblyName, methodIdentifier, dotNetObjectId, null);
                return $.$mj.MJI$1.DotNetDispatcher.Invoke($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, $.$ref(() => callInfo, ), argsJson);
            }
            //--TRIMMABLE-BOUNDARY-END(64427786360)
            
            //--TRIMMABLE-BOUNDARY-START(47247917176)
            static /*void */ EndInvokeJS(/*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247917176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.MACWH.WebAssemblyCallQueue.Schedule($.$$.S.String, argsJson, new ($.$$.S.Action$$($.$$.S.String))().$ctor($.$macwa.MACWS.DefaultWebAssemblyJSRuntime, /*static*/ (/*argsJson*/ argsJson) =>
                {
                    $.$mj.MJI$1.DotNetDispatcher.EndInvokeJS($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, argsJson);
                }, $TKqZBj ??= {"r":65537,"p":[{"n":"argsJson","p":1310721}],"n":"","d":3276920,"h":0,"f":17825826}));
            }
            //--TRIMMABLE-BOUNDARY-END(47247917176)
            
            //--TRIMMABLE-BOUNDARY-START(30068047992)
            static /*void */ BeginInvokeDotNet(/*string?*/ callId, /*string*/ assemblyNameOrDotNetObjectId, /*string*/ methodIdentifier, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068047992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let assemblyName;
                /*long*/ let dotNetObjectId;
                if ($.$$.S.Char.IsDigit$1($.$$.S.String.get_Chars.call(assemblyNameOrDotNetObjectId, 0)))
                {
                    dotNetObjectId = $.$$.S.Int64.Parse$6(assemblyNameOrDotNetObjectId, $.$$.SG.CultureInfo.InvariantCulture);
                    assemblyName = null;
                }
                else 
                {
                    dotNetObjectId = 0n;
                    assemblyName = assemblyNameOrDotNetObjectId;
                }
                /*var*/ let callInfo = new $.$mj.MJI$1.DotNetInvocationInfo().$ctor$3(assemblyName, methodIdentifier, dotNetObjectId, callId);
                $.$macwa.MACWH.WebAssemblyCallQueue.Schedule($.$$.S.ValueTuple$$$($.$mj.MJI$1.DotNetInvocationInfo, $.$$.S.String), new ($.$$.S.ValueTuple$$$($.$mj.MJI$1.DotNetInvocationInfo, $.$$.S.String))().$ctor$3(callInfo, argsJson), new ($.$$.S.Action$$($.$$.S.ValueTuple$$$($.$mj.MJI$1.DotNetInvocationInfo, $.$$.S.String)))().$ctor($.$macwa.MACWS.DefaultWebAssemblyJSRuntime, /*static*/ (/*state*/ state) =>
                {
                    $.$mj.MJI$1.DotNetDispatcher.BeginInvokeDotNet($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, state.Item1, state.Item2);
                }, $DATYbe ??= {"r":65537,"p":[{"n":"state","p":$.$$.S.ValueTuple$$$($.$mj.MJI$1.DotNetInvocationInfo, $.$$.S.String).$h}],"n":"","d":3276920,"h":0,"f":17825826}));
            }
            //--TRIMMABLE-BOUNDARY-END(30068047992)
            
            //--TRIMMABLE-BOUNDARY-START(107377459320)
            static /*void */ UpdateRootComponentsCore(/*string*/ operationsJson, /*string*/ appState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377459320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let operations = $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.DeserializeOperations(operationsJson);
                    $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance.OnUpdateRootComponents?.Invoke(operations, appState);
                }
                catch(ex)
                {
                    $.$scsl.S.Console.Error.WriteLine$17(`Error deserializing root component operations: ${$.$strNN(ex.ToString())}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107377459320)
            
            //--TRIMMABLE-BOUNDARY-START(38657982584)
            static /*RootComponentOperationBatch */ DeserializeOperations(/*string*/ operationsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657982584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let deserialized = $.$stj.STJ.JsonSerializer.Deserialize$33($.$macwa.MAC.RootComponentOperationBatch, operationsJson, $.$macwa.MACWI.WebAssemblyJsonSerializerContext.Default.RootComponentOperationBatch);
                for(/*var*/ let i = 0; i < deserialized.Operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(deserialized.Operations, i);
                    if (operation.Type === 2/*RootComponentOperationType.Remove*/)
                    {
                        continue;
                    }
                    if (operation.Marker === null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12(`The component operation of type '${$.$strNN($.$$.S.Enum.ToStringT($.$macwa.MAC.RootComponentOperationType, $.$$.S.UInt32, operation.Type))}' requires a '${$.$strNN("Marker")}' to be specified.`);
                    }
                    /*var*/ let componentType = $.$firstOf($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance._rootComponentCache.GetRootType($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker).Assembly, $.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker).TypeName), () => { throw new $.$$.S.InvalidOperationException().$ctor$12(`Root component type '${$.$strNN($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker).TypeName)}' could not be found in the assembly '${$.$strNN($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker).Assembly)}'.`) });
                    /*var*/ let parameters = $.$macwa.MACWS.DefaultWebAssemblyJSRuntime.DeserializeComponentParameters($.$$.S.Nullable$$($.$macwa.MAC.ComponentMarker).Value$get.call(operation.Marker));
                    operation.Descriptor = new $.$macwa.MAC.WebRootComponentDescriptor().$ctor$1(componentType, parameters);
                }
                return deserialized;
            }
            //--TRIMMABLE-BOUNDARY-END(38657982584)
            
            //--TRIMMABLE-BOUNDARY-START(34363015288)
            static /*WebRootComponentParameters */ DeserializeComponentParameters(/*ComponentMarker*/ marker)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363015288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let definitions = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(marker.ParameterDefinitions);
                /*var*/ let values = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.GetParameterValues(marker.ParameterValues);
                /*var*/ let componentDeserializer = $.$macwa.MAC.WebAssemblyComponentParameterDeserializer.Instance;
                /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                return new $.$macwa.MAC.WebRootComponentParameters().$ctor$3(parameters, definitions, $.$$.SCG.CollectionExtensions.AsReadOnly($.$$.S.Object, values));
            }
            //--TRIMMABLE-BOUNDARY-END(34363015288)
            
            //--TRIMMABLE-BOUNDARY-START(90197590136)
            static /*void */ ReceiveByteArrayFromJS(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197590136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.MJI$1.DotNetDispatcher.ReceiveByteArray($.$macwa.MACWS.DefaultWebAssemblyJSRuntime.Instance, id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(90197590136)
            
            //--TRIMMABLE-BOUNDARY-START(81607655544)
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81607655544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.FromResult($.$$.SI.Stream, $.$macwa.MAC.PullFromJSDataStream.CreateJSDataStream(this, jsStreamReference, totalLength, cancellationToken));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81607655544)
            
            //--TRIMMABLE-BOUNDARY-START(103082492024)
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082492024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.MAC.TransmitDataStreamToJS.TransmitStreamAsync(this, "Blazor._internal.receiveWebAssemblyDotNetDataStream", streamId, dotNetStreamReference);
            }
            //--TRIMMABLE-BOUNDARY-END(103082492024)
            
            //--TRIMMABLE-BOUNDARY-START(73017720952)
            /*string */ MACWI$1$IInternalWebJSInProcessRuntime$InvokeJS$1(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017720952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS$1(identifier, argsJson, resultType, targetInstanceId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73017720952)
            
            //--TRIMMABLE-BOUNDARY-START(68722753656)
            /*string */ MACWI$1$IInternalWebJSInProcessRuntime$InvokeJS(/*in JSInvocationInfo*/ invocationInfo)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722753656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS(invocationInfo);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722753656)
            
            //--TRIMMABLE-BOUNDARY-START(17183146104)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17183146104)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4298244216)
                this._rootComponentCache = new $.$macwa.MAC.RootTypeCache().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4298244216)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12888178808)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888178808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60132819064)
                    this.Instance = new $.$macwa.MACWS.DefaultWebAssemblyJSRuntime().$ctor$4();
                    //--TRIMMABLE-BOUNDARY-END(60132819064)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888178808)
            
            //Method exports
            static $exports()
            {
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_InvokeDotNet = this.InvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_EndInvokeJS = this.EndInvokeJS;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_BeginInvokeDotNet = this.BeginInvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_UpdateRootComponentsCore = this.UpdateRootComponentsCore;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_ReceiveByteArrayFromJS = this.ReceiveByteArrayFromJS;
            }
            static $h = 3276920;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mjw.MJW.WebAssemblyJSRuntime; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952949880),
    {
      "p": 1966195,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837851768,
        "f": 50331649
      },
      "n": "ElementReferenceContext",
      "d": 3276920,
      "h": 42952949880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952949880)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85902622840),
    {
      "r": 3342420,
      "n": "ReadJsonSerializerOptions",
      "d": 3276920,
      "h": 85902622840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902622840),
//--TRIMMABLE-BOUNDARY-START(64427786360),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "dotNetObjectId",
          "p": 917505,
          "a": [
            {
              "t": $.$srij.SRIJ.JSMarshalAsAttribute$$($.$srij.SRIJ.JSType.Number).$h,
              "c": Number(BigInt($.$srij.SRIJ.JSMarshalAsAttribute$$($.$srij.SRIJ.JSType.Number).$h)|0x100000000n)
            }
          ]
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeDotNet",
      "d": 3276920,
      "h": 64427786360,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427786360),
//--TRIMMABLE-BOUNDARY-START(47247917176),
    {
      "r": 65537,
      "p": [
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "EndInvokeJS",
      "d": 3276920,
      "h": 47247917176,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247917176),
//--TRIMMABLE-BOUNDARY-START(30068047992),
    {
      "r": 65537,
      "p": [
        {
          "n": "callId",
          "p": 1310721
        },
        {
          "n": "assemblyNameOrDotNetObjectId",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeDotNet",
      "d": 3276920,
      "h": 30068047992,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30068047992),
//--TRIMMABLE-BOUNDARY-START(107377459320),
    {
      "r": 65537,
      "p": [
        {
          "n": "operationsJson",
          "p": 1310721
        },
        {
          "n": "appState",
          "p": 1310721
        }
      ],
      "n": "UpdateRootComponentsCore",
      "d": 3276920,
      "h": 107377459320,
      "f": 16777249,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 458763,
          "c": 4295426059
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377459320),
//--TRIMMABLE-BOUNDARY-START(38657982584),
    {
      "r": 1048696,
      "p": [
        {
          "n": "operationsJson",
          "p": 1310721
        }
      ],
      "n": "DeserializeOperations",
      "d": 3276920,
      "h": 38657982584,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38657982584),
//--TRIMMABLE-BOUNDARY-START(34363015288),
    {
      "r": 4391032,
      "p": [
        {
          "n": "marker",
          "p": 131192
        }
      ],
      "n": "DeserializeComponentParameters",
      "d": 3276920,
      "h": 34363015288,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34363015288),
//--TRIMMABLE-BOUNDARY-START(90197590136),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "ReceiveByteArrayFromJS",
      "d": 3276920,
      "h": 90197590136,
      "f": 16777250,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90197590136),
//--TRIMMABLE-BOUNDARY-START(81607655544),
    {
      "r": $.$$.STT.Task$$($.$$.SI.Stream).$h,
      "p": [
        {
          "n": "jsStreamReference",
          "p": 589938
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadJSDataAsStreamAsync",
      "d": 3276920,
      "h": 81607655544,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81607655544),
//--TRIMMABLE-BOUNDARY-START(103082492024),
    {
      "r": 178454529,
      "p": [
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262258
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 3276920,
      "h": 103082492024,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103082492024)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60132819064),
    {
      "t": 3276920,
      "n": "Instance",
      "d": 3276920,
      "h": 60132819064,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60132819064),
//--TRIMMABLE-BOUNDARY-START(4298244216),
    {
      "t": 1179768,
      "n": "_rootComponentCache",
      "d": 3276920,
      "h": 4298244216,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244216)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183146104),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3276920,
      "h": 17183146104,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17183146104)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(77312688248),
    {
      "e": $.$$.S.Action$$$($.$macwa.MAC.RootComponentOperationBatch, $.$$.S.String).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$$($.$macwa.MAC.RootComponentOperationBatch, $.$$.S.String).$h
          }
        ],
        "n": "add_OnUpdateRootComponents",
        "d": 3276920,
        "h": 25773080696,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.Action$$$($.$macwa.MAC.RootComponentOperationBatch, $.$$.S.String).$h
          }
        ],
        "n": "remove_OnUpdateRootComponents",
        "d": 3276920,
        "h": 98787524728,
        "f": 285212673
      },
      "n": "OnUpdateRootComponents",
      "d": 3276920,
      "h": 77312688248,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(77312688248)
  ],
  "h": 3276920
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$mj.MJ.IJSInProcessRuntime, $.$mj.MJ.IJSRuntime, $.$macw.MACWI$1.IInternalWebJSInProcessRuntime ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Services${separator}DefaultWebAssemblyJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276920)
        
        

        //--TRIMMABLE-BOUNDARY-START(2818168)
        $asm.$cls(`$macwa.MACWR.WebAssemblyComponentState`, ($self) => class WebAssemblyComponentState extends $.$mac.MACR$1.ComponentState
        {
            //--TRIMMABLE-BOUNDARY-START(4297785464)
            /*WebAssemblyRenderer*/ _renderer$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4297785464)
            
            //--TRIMMABLE-BOUNDARY-START(8592752760)
            $ctor$2(/*WebAssemblyRenderer*/ renderer, /*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                super.$ctor$1(renderer, componentId, component, parentComponentState);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592752760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._renderer$1 = renderer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752760)
            
            //--TRIMMABLE-BOUNDARY-START(12887720056)
            /*object? */ GetComponentKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887720056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let markerKey = this._renderer$1.GetMarkerKey(this);
                if ($.$macwa.MAC.ComponentMarkerKey.op_Inequality(markerKey, new $.$macwa.MAC.ComponentMarkerKey()))
                {
                    return markerKey.Serialized();
                }
                return super.GetComponentKey();
            }
            //--TRIMMABLE-BOUNDARY-END(12887720056)
            
            static $h = 2818168;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mac.MACR$1.ComponentState; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887720056),
    {
      "r": 131073,
      "n": "GetComponentKey",
      "d": 2818168,
      "h": 12887720056,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887720056)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297785464),
    {
      "t": 2949240,
      "n": "_renderer",
      "o": "@$1",
      "d": 2818168,
      "h": 4297785464,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785464)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592752760),
    {
      "p": [
        {
          "n": "renderer",
          "p": 2949240
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2752627
        },
        {
          "n": "parentComponentState",
          "p": 7078003
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818168,
      "h": 8592752760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592752760)
  ],
  "h": 2818168
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyComponentState`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Rendering${separator}WebAssemblyComponentState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818168)
        
        

        //--TRIMMABLE-BOUNDARY-START(458872)
        $asm.$cls(`$macwa.MAC.ElementReferenceJsonConverter`, ($self) => class ElementReferenceJsonConverter extends $.$stj.STJS$1.JsonConverter$$($.$mac.MAC.ElementReference)
        {
            //--TRIMMABLE-BOUNDARY-START(17180328056)
            /*JsonEncodedText*/ static IdProperty;
            //--TRIMMABLE-BOUNDARY-END(17180328056)
            
            //--TRIMMABLE-BOUNDARY-START(4295426168)
            /*ElementReferenceContext*/ _elementReferenceContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295426168)
            
            //--TRIMMABLE-BOUNDARY-START(12885360760)
            $ctor$3(/*ElementReferenceContext*/ elementReferenceContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._elementReferenceContext = elementReferenceContext;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360760)
            
            //--TRIMMABLE-BOUNDARY-START(21475295352)
            /*ElementReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.$v.ValueTextEquals($.$macwa.MAC.ElementReferenceJsonConverter.IdProperty.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON property '${$.$strNN(reader.$v.GetString())}'.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.STJ.JsonException().$ctor$10(`Unexpected JSON Token ${$.$strNN($.$$.S.Enum.ToStringT($.$stj.STJ.JsonTokenType, $.$$.S.Byte, reader.$v.TokenType))}.`);
                    }
                }
                if (id === null)
                {
                    throw new $.$stj.STJ.JsonException().$ctor$10("__internalId is required.");
                }
                return new $.$mac.MAC.ElementReference().$ctor$3(id, this._elementReferenceContext);
            }
            //--TRIMMABLE-BOUNDARY-END(21475295352)
            
            //--TRIMMABLE-BOUNDARY-START(25770262648)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*ElementReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteString$26($.$macwa.MAC.ElementReferenceJsonConverter.IdProperty, value.Id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(25770262648)
            
            //--TRIMMABLE-BOUNDARY-START(8590393464)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328056)
                    this.IdProperty = $.$stj.STJ.JsonEncodedText.Encode$2("__internalId", null);
                    //--TRIMMABLE-BOUNDARY-END(17180328056)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393464)
            
            static $h = 458872;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$stj.STJS$1.JsonConverter$$($.$mac.MAC.ElementReference); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475295352),
    {
      "r": 1900659,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 458872,
      "h": 21475295352,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475295352),
//--TRIMMABLE-BOUNDARY-START(25770262648),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 1900659
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 458872,
      "h": 25770262648,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770262648)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328056),
    {
      "t": 2293844,
      "n": "IdProperty",
      "d": 458872,
      "h": 17180328056,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180328056),
//--TRIMMABLE-BOUNDARY-START(4295426168),
    {
      "t": 1966195,
      "n": "_elementReferenceContext",
      "d": 458872,
      "h": 4295426168,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360760),
    {
      "p": [
        {
          "n": "elementReferenceContext",
          "p": 1966195
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458872,
      "h": 12885360760,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360760)
  ],
  "h": 458872
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.ElementReferenceJsonConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}ElementReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458872)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704056)
        $asm.$cls(`$macwa.MACWH.RootComponentMappingCollection`, ($self) => class RootComponentMappingCollection extends $.$$.SCO.Collection$$($.$macwa.MACWH.RootComponentMapping)
        {
            //--TRIMMABLE-BOUNDARY-START(38656409720)
            /*JSComponentConfigurationStore*/ JSComponents = null;
            //--TRIMMABLE-BOUNDARY-END(38656409720)
            
            //--TRIMMABLE-BOUNDARY-START(21476540536)
            /*void */ Add$3(TComponent, /*string*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476540536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                this.Add(new $.$macwa.MACWH.RootComponentMapping().$ctor$4(TComponent.$type, selector));
            }
            //--TRIMMABLE-BOUNDARY-END(21476540536)
            
            //--TRIMMABLE-BOUNDARY-START(17181573240)
            /*void */ Add$2(/*Type*/ componentType, /*string*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181573240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add$1(componentType, selector, $.$mac.MAC.ParameterView.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(17181573240)
            
            //--TRIMMABLE-BOUNDARY-START(12886605944)
            /*void */ Add$1(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(componentType, "componentType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                this.Add(new $.$macwa.MACWH.RootComponentMapping().$ctor$3(componentType, selector, parameters));
            }
            //--TRIMMABLE-BOUNDARY-END(12886605944)
            
            //--TRIMMABLE-BOUNDARY-START(25771507832)
            /*void */ AddRange(/*IEnumerable<RootComponentMapping>*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(items, "items");
                let $en1 = items.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let item = $en1.SCG$IEnumerator$$$Current;
                    {
                        this.Add(item);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771507832)
            
            //--TRIMMABLE-BOUNDARY-START(8595767413)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration.JSComponents.get
            get MACW$IJSComponentConfiguration$JSComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890734709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.JSComponents;
            }
            //--TRIMMABLE-BOUNDARY-END(8595767413)
            
            //--TRIMMABLE-BOUNDARY-START(8591638648)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638648)
            
            //--TRIMMABLE-BOUNDARY-START(8591638648)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(8591638648)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38656409720)
                this.JSComponents = new $.$macw.MACW.JSComponentConfigurationStore().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(38656409720)
                
            }
            static $h = 1704056;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCO.Collection$$($.$macwa.MACWH.RootComponentMapping); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656409720),
    {
      "p": 6488181,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442424,
        "f": 50331649
      },
      "n": "JSComponents",
      "d": 1704056,
      "h": 38656409720,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409720)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476540536),
    {
      "r": 65537,
      "p": [
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "g": [
        "TComponent"
      ],
      "n": "Add",
      "o": "@$3",
      "d": 1704056,
      "h": 21476540536,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21476540536),
//--TRIMMABLE-BOUNDARY-START(17181573240),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 1704056,
      "h": 17181573240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573240),
//--TRIMMABLE-BOUNDARY-START(12886605944),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentType",
          "p": 188547073
        },
        {
          "n": "selector",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": 5767283
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1704056,
      "h": 12886605944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605944),
//--TRIMMABLE-BOUNDARY-START(25771507832),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$$.SCG.IEnumerable$$($.$macwa.MACWH.RootComponentMapping).$h
        }
      ],
      "n": "AddRange",
      "d": 1704056,
      "h": 25771507832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507832)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591638648),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704056,
      "h": 8591638648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591638648)
  ],
  "h": 1704056
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$($.$macwa.MACWH.RootComponentMapping), $.$$.SCG.ICollection$$($.$macwa.MACWH.RootComponentMapping), $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyList$$($.$macwa.MACWH.RootComponentMapping), $.$$.SCG.IReadOnlyCollection$$($.$macwa.MACWH.RootComponentMapping), $.$$.SCG.IEnumerable$$($.$macwa.MACWH.RootComponentMapping), $.$$.SC$1.IEnumerable, $.$macw.MACW.IJSComponentConfiguration ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Components${separator}WebAssembly${separator}Hosting${separator}RootComponentMappingCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704056)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly"));
})();
//--TRIMMABLE-BOUNDARY-END(120)
