
//--TRIMMABLE-BOUNDARY-START(113)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.WebAssembly", 
    {
  "h": 113,
  "f": "Microsoft.AspNetCore.Components.WebAssembly",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 115605505,
      "c": 4410572801,
      "a": [
        {
          "v": 589937,
          "t": 187629569
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Build client-side single-page applications (SPAs) with Blazor running under WebAssembly.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Components.WebAssembly",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.AspNetCore.Components.WebAssembly.Authentication.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "BasicTestApp",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "DynamicProxyGenAssembly2",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1441905)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment", ($self) => class IWebAssemblyHostEnvironment
        {
            static $h = 1441905;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591376497),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245681,
        "f": 50331905
      },
      "n": "Environment",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment",
      "d": 1441905,
      "h": 8591376497,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591376497),
//--TRIMMABLE-BOUNDARY-START(4296409201),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181311089,
        "f": 50331905
      },
      "n": "BaseAddress",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress",
      "d": 1441905,
      "h": 4296409201,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296409201)
  ],
  "h": 1441905
}; }
            static get $fullName() { return `IWebAssemblyHostEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441905)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342449)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods", ($self) => class IInternalJSImportMethods
        {
            static $h = 3342449;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183211633),
    {
      "r": 1310721,
      "n": "GetPersistedState",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState",
      "d": 3342449,
      "h": 17183211633,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17183211633),
//--TRIMMABLE-BOUNDARY-START(12888244337),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironment",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment",
      "d": 3342449,
      "h": 12888244337,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12888244337),
//--TRIMMABLE-BOUNDARY-START(4298309745),
    {
      "r": 65537,
      "p": [
        {
          "n": "domElementSelector",
          "p": 1310721
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "AttachRootComponentToElement",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement",
      "d": 3342449,
      "h": 4298309745,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4298309745),
//--TRIMMABLE-BOUNDARY-START(8593277041),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "EndUpdateRootComponents",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents",
      "d": 3342449,
      "h": 8593277041,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8593277041),
//--TRIMMABLE-BOUNDARY-START(21478178929),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "NavigationManager_EnableNavigationInterception",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception",
      "d": 3342449,
      "h": 21478178929,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21478178929),
//--TRIMMABLE-BOUNDARY-START(34363080817),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "NavigationManager_ScrollToElement",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_ScrollToElement",
      "d": 3342449,
      "h": 34363080817,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34363080817),
//--TRIMMABLE-BOUNDARY-START(30068113521),
    {
      "r": 1310721,
      "n": "NavigationManager_GetLocationHref",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref",
      "d": 3342449,
      "h": 30068113521,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30068113521),
//--TRIMMABLE-BOUNDARY-START(25773146225),
    {
      "r": 1310721,
      "n": "NavigationManager_GetBaseUri",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri",
      "d": 3342449,
      "h": 25773146225,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25773146225),
//--TRIMMABLE-BOUNDARY-START(38658048113),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "NavigationManager_SetHasLocationChangingListeners",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners",
      "d": 3342449,
      "h": 38658048113,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38658048113),
//--TRIMMABLE-BOUNDARY-START(55837917297),
    {
      "r": 655361,
      "n": "RegisteredComponents_GetRegisteredComponentsCount",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount",
      "d": 3342449,
      "h": 55837917297,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55837917297),
//--TRIMMABLE-BOUNDARY-START(42953015409),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetAssembly",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly",
      "d": 3342449,
      "h": 42953015409,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42953015409),
//--TRIMMABLE-BOUNDARY-START(60132884593),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetTypeName",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName",
      "d": 3342449,
      "h": 60132884593,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60132884593),
//--TRIMMABLE-BOUNDARY-START(47247982705),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterDefinitions",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions",
      "d": 3342449,
      "h": 47247982705,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47247982705),
//--TRIMMABLE-BOUNDARY-START(51542950001),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterValues",
      "o": "Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues",
      "d": 3342449,
      "h": 51542950001,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51542950001)
  ],
  "h": 3342449
}; }
            static get $fullName() { return `IInternalJSImportMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342449)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835121)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider", ($self) => class WebAssemblyCultureProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1900657)
            static $_WebAssemblyCultureProviderInterop;
            static get WebAssemblyCultureProviderInterop()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider;
                return $cls.$_WebAssemblyCultureProviderInterop ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop", ($self) => class WebAssemblyCultureProviderInterop extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835249)
                    static /*Task */ LoadSatelliteAssemblies(/*string[]*/ culturesToLoad)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591835249);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.Threading.Tasks.Task.CompletedTask;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591835249)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1900657;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591835249),
    {
      "r": 177537025,
      "p": [
        {
          "n": "culturesToLoad",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": "LoadSatelliteAssemblies",
      "d": 1900657,
      "h": 8591835249,
      "f": 16777249,
      "a": [
        {
          "t": 1179659,
          "c": 4296146955,
          "a": [
            {
              "v": "INTERNAL.loadSatelliteAssemblies",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591835249)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867953),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900657,
      "h": 4296867953,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867953)
  ],
  "d": 1835121,
  "h": 1900657
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop`; }
                }, $cls, ($v) => $cls.$_WebAssemblyCultureProviderInterop = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900657)
            
            //--TRIMMABLE-BOUNDARY-START(55836409969)
            /*string*/ static GetSatelliteAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(55836409969)
            
            //--TRIMMABLE-BOUNDARY-START(81606213745)
            /*string*/ static ReadSatelliteAssemblies = null;
            //--TRIMMABLE-BOUNDARY-END(81606213745)
            
            //--TRIMMABLE-BOUNDARY-START(4296802417)
            $ctor$1(/*CultureInfo*/ initialCulture, /*CultureInfo*/ initialUICulture)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296802417);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InitialCulture = initialCulture;
                    this.InitialUICulture = initialUICulture;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802417)
            
            //--TRIMMABLE-BOUNDARY-START(73016279153)
            /*WebAssemblyCultureProvider?*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(73016279153)
            
            //--TRIMMABLE-BOUNDARY-START(60131377265)
            /*CultureInfo*/ InitialCulture = null;
            //--TRIMMABLE-BOUNDARY-END(60131377265)
            
            //--TRIMMABLE-BOUNDARY-START(68721311857)
            /*CultureInfo*/ InitialUICulture = null;
            //--TRIMMABLE-BOUNDARY-END(68721311857)
            
            //--TRIMMABLE-BOUNDARY-START(64426344561)
            static /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426344561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider().$ctor$1($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$$.System.Globalization.CultureInfo.CurrentUICulture);
            }
            //--TRIMMABLE-BOUNDARY-END(64426344561)
            
            //--TRIMMABLE-BOUNDARY-START(94491115633)
            /*void */ ThrowIfCultureChangeIsUnsupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491115633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality($.$$.System.Environment.GetEnvironmentVariable$1("__BLAZOR_SHARDED_ICU"), "1") && ((!$.$$.System.String.Equals$4.call($.$$.System.Globalization.CultureInfo.CurrentCulture.Name, this.InitialCulture.Name, 4/*StringComparison.Ordinal*/) || !$.$$.System.String.Equals$4.call($.$$.System.Globalization.CultureInfo.CurrentUICulture.Name, this.InitialUICulture.Name, 4/*StringComparison.Ordinal*/))))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("Blazor detected a change in the application's culture that is not supported with the current project configuration. " + "To change culture dynamically during startup, set <BlazorWebAssemblyLoadAllGlobalizationData>true</BlazorWebAssemblyLoadAllGlobalizationData> in the application's project file.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491115633)
            
            //--TRIMMABLE-BOUNDARY-START(77311246449)
            /*ValueTask *//*async*/  LoadCurrentCultureResourcesAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311246449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.System.OperatingSystem.IsBrowser())
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$16("This method is only supported in the browser.");
                    }
                    /*var*/ let culturesToLoad = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultures($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$$.System.Globalization.CultureInfo.CurrentUICulture);
                    if (culturesToLoad.length === 0)
                    {
                        return;
                    }
                    await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop.LoadSatelliteAssemblies(culturesToLoad);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311246449)
            
            //--TRIMMABLE-BOUNDARY-START(51541442673)
            static /*string[] */ GetCultures(/*CultureInfo*/ cultureInfo, /*CultureInfo?*/ uiCultureInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541442673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let culturesToLoad = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultureHierarchy(cultureInfo);
                if (cultureInfo !== uiCultureInfo)
                {
                    var $en3 = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultureHierarchy(uiCultureInfo).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var culture = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!$.$sl.System.Linq.Enumerable.Contains$1($.$$.System.String, culturesToLoad, culture))
                            {
                                culturesToLoad = $.$sl.System.Linq.Enumerable.Append($.$$.System.String, culturesToLoad, culture);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                return $.$sl.System.Linq.Enumerable.ToArray($.$$.System.String, culturesToLoad);
            }
            //--TRIMMABLE-BOUNDARY-END(51541442673)
            
            //--TRIMMABLE-BOUNDARY-START(47246475377)
            static /*IEnumerable<string> */ GetCultureHierarchy(/*CultureInfo?*/ culture)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    while(culture !== $.$$.System.Globalization.CultureInfo.InvariantCulture && culture !== null)
                    {
                        yield culture.Name;
                        if (culture === culture.Parent)
                        {
                            break;
                        }
                        culture = culture.Parent;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(47246475377)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(55836409969)
                    this.GetSatelliteAssemblies = "window.Blazor._internal.getSatelliteAssemblies";
                    //--TRIMMABLE-BOUNDARY-END(55836409969)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606213745)
                    this.ReadSatelliteAssemblies = "window.Blazor._internal.readSatelliteAssemblies";
                    //--TRIMMABLE-BOUNDARY-END(81606213745)
                    
                }
            }
            static $h = 1835121;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016279153),
    {
      "p": 1835121,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951508081,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90196148337,
        "f": 83886114
      },
      "n": "Instance",
      "d": 1835121,
      "h": 73016279153,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73016279153),
//--TRIMMABLE-BOUNDARY-START(60131377265),
    {
      "p": 83820545,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771638897,
        "f": 50331649
      },
      "n": "InitialCulture",
      "d": 1835121,
      "h": 60131377265,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131377265),
//--TRIMMABLE-BOUNDARY-START(68721311857),
    {
      "p": 83820545,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361573489,
        "f": 50331649
      },
      "n": "InitialUICulture",
      "d": 1835121,
      "h": 68721311857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721311857)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426344561),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1835121,
      "h": 64426344561,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(64426344561),
//--TRIMMABLE-BOUNDARY-START(94491115633),
    {
      "r": 65537,
      "n": "ThrowIfCultureChangeIsUnsupported",
      "d": 1835121,
      "h": 94491115633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94491115633),
//--TRIMMABLE-BOUNDARY-START(77311246449),
    {
      "r": 180420609,
      "n": "LoadCurrentCultureResourcesAsync",
      "d": 1835121,
      "h": 77311246449,
      "f": 16781441
    },
//--TRIMMABLE-BOUNDARY-END(77311246449),
//--TRIMMABLE-BOUNDARY-START(51541442673),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "p": [
        {
          "n": "cultureInfo",
          "p": 83820545
        },
        {
          "n": "uiCultureInfo",
          "p": 83820545,
          "f": 65
        }
      ],
      "n": "GetCultures",
      "d": 1835121,
      "h": 51541442673,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51541442673),
//--TRIMMABLE-BOUNDARY-START(47246475377),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 83820545
        }
      ],
      "n": "GetCultureHierarchy",
      "d": 1835121,
      "h": 47246475377,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246475377)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836409969),
    {
      "t": 1310721,
      "n": "GetSatelliteAssemblies",
      "d": 1835121,
      "h": 55836409969,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836409969),
//--TRIMMABLE-BOUNDARY-START(81606213745),
    {
      "t": 1310721,
      "n": "ReadSatelliteAssemblies",
      "d": 1835121,
      "h": 81606213745,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81606213745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802417),
    {
      "p": [
        {
          "n": "initialCulture",
          "p": 83820545
        },
        {
          "n": "initialUICulture",
          "p": 83820545
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1835121,
      "h": 4296802417,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296802417)
  ],
  "j": [1900657
  ],
  "h": 1835121
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyCultureProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835121)
        
        
        //--TRIMMABLE-BOUNDARY-START(655473)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.JsonSerializerOptionsProvider", ($self) => class JsonSerializerOptionsProvider
        {
            //--TRIMMABLE-BOUNDARY-START(8590590065)
            /*JsonSerializerOptions*/ static Options = null;
            //--TRIMMABLE-BOUNDARY-END(8590590065)
            
            //--TRIMMABLE-BOUNDARY-START(4295622769)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590590065)
                    this.Options = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.IncludeFields = true;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8590590065)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295622769)
            
            static $h = 655473;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590590065),
    {
      "t": 3342420,
      "n": "Options",
      "d": 655473,
      "h": 8590590065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590065)
  ],
  "h": 655473
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JsonSerializerOptionsProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655473)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211377)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.ConsoleLoggerInterop", ($self) => class ConsoleLoggerInterop
        {
            static $h = 3211377;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3211377
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ConsoleLoggerInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211377)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376369)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.Web.BrowserNavigationManagerInterop", ($self) => class BrowserNavigationManagerInterop
        {
            //--TRIMMABLE-BOUNDARY-START(21476212849)
            /*string*/ static Prefix = null;
            //--TRIMMABLE-BOUNDARY-END(21476212849)
            
            //--TRIMMABLE-BOUNDARY-START(4296343665)
            /*string*/ static EnableNavigationInterception = null;
            //--TRIMMABLE-BOUNDARY-END(4296343665)
            
            //--TRIMMABLE-BOUNDARY-START(12886278257)
            /*string*/ static GetLocationHref = null;
            //--TRIMMABLE-BOUNDARY-END(12886278257)
            
            //--TRIMMABLE-BOUNDARY-START(8591310961)
            /*string*/ static GetBaseUri = null;
            //--TRIMMABLE-BOUNDARY-END(8591310961)
            
            //--TRIMMABLE-BOUNDARY-START(17181245553)
            /*string*/ static NavigateTo = null;
            //--TRIMMABLE-BOUNDARY-END(17181245553)
            
            //--TRIMMABLE-BOUNDARY-START(25771180145)
            /*string*/ static Refresh = null;
            //--TRIMMABLE-BOUNDARY-END(25771180145)
            
            //--TRIMMABLE-BOUNDARY-START(34361114737)
            /*string*/ static SetHasLocationChangingListeners = null;
            //--TRIMMABLE-BOUNDARY-END(34361114737)
            
            //--TRIMMABLE-BOUNDARY-START(30066147441)
            /*string*/ static ScrollToElement = null;
            //--TRIMMABLE-BOUNDARY-END(30066147441)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21476212849)
                    this.Prefix = "Blazor._internal.navigationManager.";
                    //--TRIMMABLE-BOUNDARY-END(21476212849)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296343665)
                    this.EnableNavigationInterception = "Blazor._internal.navigationManager.enableNavigationInterception";
                    //--TRIMMABLE-BOUNDARY-END(4296343665)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886278257)
                    this.GetLocationHref = "Blazor._internal.navigationManager.getLocationHref";
                    //--TRIMMABLE-BOUNDARY-END(12886278257)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310961)
                    this.GetBaseUri = "Blazor._internal.navigationManager.getBaseURI";
                    //--TRIMMABLE-BOUNDARY-END(8591310961)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181245553)
                    this.NavigateTo = "Blazor._internal.navigationManager.navigateTo";
                    //--TRIMMABLE-BOUNDARY-END(17181245553)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771180145)
                    this.Refresh = "Blazor._internal.navigationManager.refresh";
                    //--TRIMMABLE-BOUNDARY-END(25771180145)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361114737)
                    this.SetHasLocationChangingListeners = "Blazor._internal.navigationManager.setHasLocationChangingListeners";
                    //--TRIMMABLE-BOUNDARY-END(34361114737)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066147441)
                    this.ScrollToElement = "Blazor._internal.navigationManager.scrollToElement";
                    //--TRIMMABLE-BOUNDARY-END(30066147441)
                    
                }
            }
            static $h = 1376369;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476212849),
    {
      "t": 1310721,
      "n": "Prefix",
      "d": 1376369,
      "h": 21476212849,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476212849),
//--TRIMMABLE-BOUNDARY-START(4296343665),
    {
      "t": 1310721,
      "n": "EnableNavigationInterception",
      "d": 1376369,
      "h": 4296343665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296343665),
//--TRIMMABLE-BOUNDARY-START(12886278257),
    {
      "t": 1310721,
      "n": "GetLocationHref",
      "d": 1376369,
      "h": 12886278257,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278257),
//--TRIMMABLE-BOUNDARY-START(8591310961),
    {
      "t": 1310721,
      "n": "GetBaseUri",
      "d": 1376369,
      "h": 8591310961,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310961),
//--TRIMMABLE-BOUNDARY-START(17181245553),
    {
      "t": 1310721,
      "n": "NavigateTo",
      "d": 1376369,
      "h": 17181245553,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245553),
//--TRIMMABLE-BOUNDARY-START(25771180145),
    {
      "t": 1310721,
      "n": "Refresh",
      "d": 1376369,
      "h": 25771180145,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771180145),
//--TRIMMABLE-BOUNDARY-START(34361114737),
    {
      "t": 1310721,
      "n": "SetHasLocationChangingListeners",
      "d": 1376369,
      "h": 34361114737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361114737),
//--TRIMMABLE-BOUNDARY-START(30066147441),
    {
      "t": 1310721,
      "n": "ScrollToElement",
      "d": 1376369,
      "h": 30066147441,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066147441)
  ],
  "h": 1376369
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `BrowserNavigationManagerInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376369)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048689)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch", ($self) => class RootComponentOperationBatch extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180917873)
            /*long*/ BatchId = 0n;
            //--TRIMMABLE-BOUNDARY-END(17180917873)
            
            //--TRIMMABLE-BOUNDARY-START(42950721649)
            /*RootComponentOperation[]*/ Operations = null;
            //--TRIMMABLE-BOUNDARY-END(42950721649)
            
            //--TRIMMABLE-BOUNDARY-START(38655754353)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655754353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `${"RootComponentOperationBatch"}: ${this.BatchId}, Operations Count: ${this.Operations.length}`;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754353)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1048689;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180917873),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770852465,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540656241,
        "f": 83886081
      },
      "n": "BatchId",
      "d": 1048689,
      "h": 17180917873,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180917873),
//--TRIMMABLE-BOUNDARY-START(42950721649),
    {
      "p": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360787057,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130590833,
        "f": 83886081
      },
      "n": "Operations",
      "d": 1048689,
      "h": 42950721649,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950721649)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655754353),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 1048689,
      "h": 38655754353,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655754353)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015985),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048689,
      "h": 4296015985,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015985)
  ],
  "h": 1048689,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RootComponentOperationBatch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048689)
        
        
        //--TRIMMABLE-BOUNDARY-START(3473521)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader", ($self) => class LazyAssemblyLoader extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(3539057)
            static $_LazyAssemblyLoaderInterop;
            static get LazyAssemblyLoaderInterop()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader;
                return $cls.$_LazyAssemblyLoaderInterop ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop", ($self) => class LazyAssemblyLoaderInterop extends $.$$.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3539057;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298506353),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3539057,
      "h": 4298506353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298506353)
  ],
  "d": 3473521,
  "h": 3539057
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `LazyAssemblyLoader.LazyAssemblyLoaderInterop`; }
                }, $cls, ($v) => $cls.$_LazyAssemblyLoaderInterop = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3539057)
            
            //--TRIMMABLE-BOUNDARY-START(4298440817)
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298440817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298440817)
            
            //--TRIMMABLE-BOUNDARY-START(12888375409)
            /*Task<IEnumerable<Assembly>> */ LoadAssembliesAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888375409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.OperatingSystem.IsBrowser())
                {
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LoadAssembliesInClientAsync(assembliesToLoad);
                }
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LoadAssembliesInServerAsync(assembliesToLoad);
            }
            //--TRIMMABLE-BOUNDARY-END(12888375409)
            
            //--TRIMMABLE-BOUNDARY-START(21478310001)
            static /*Task<IEnumerable<Assembly>> */ LoadAssembliesInServerAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478310001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let loadedAssemblies = new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.Assembly))().$ctor$1();
                try
                {
                    var $en3 = assembliesToLoad.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var assemblyName = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            loadedAssemblies.Add($.$$.System.Reflection.Assembly.Load$4($.$$.System.IO.Path.GetFileNameWithoutExtension$1(assemblyName)));
                        }
                    }
                }
                catch(ex)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unable to find the following assembly: ${ex.FileName}. Make sure that the appplication is referencing the assemblies and that they are present in the output folder.`);
                }
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly), loadedAssemblies);
            }
            //--TRIMMABLE-BOUNDARY-END(21478310001)
            
            //--TRIMMABLE-BOUNDARY-START(17183342705)
            static /*Task<IEnumerable<Assembly>> *//*async*/  LoadAssembliesInClientAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183342705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let newAssembliesToLoad = $.$sl.System.Linq.Enumerable.ToList($.$$.System.String, assembliesToLoad);
                    /*var*/ let loadedAssemblies = new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.Assembly))().$ctor$1();
                    /*var*/ let pendingLoads = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), newAssembliesToLoad, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop.LoadLazyAssembly));
                    /*var*/ let loadedStatus = await $.$$.System.Threading.Tasks.Task.WhenAll$3($.$$.System.Boolean, pendingLoads);
                    /*int*/ let i = 0;
                    /*List<Assembly>?*/ let allAssemblies = null;
                    let $i1 = 0;
                    let $arr1 = loadedStatus;
                    while ($i1 < $arr1.length)
                    {
                        let loaded = $arr1[$i1++];
                        if (loaded)
                        {
                            if (allAssemblies === null)
                            {
                                allAssemblies = $.$sl.System.Linq.Enumerable.ToList($.$$.System.Reflection.Assembly, $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.Assemblies);
                            }
                            /*var*/ let assemblyName = $.$$.System.IO.Path.GetFileNameWithoutExtension$1(newAssembliesToLoad.get_Item(i));
                            /*var*/ let assembly = $.$sl.System.Linq.Enumerable.FirstOrDefault$1($.$$.System.Reflection.Assembly, $.$$.System.Runtime.Loader.AssemblyLoadContext.Default.Assemblies, new ($.$$.System.Func$$$($.$$.System.Reflection.Assembly, $.$$.System.Boolean))().$ctor(this,  (/*a*/ a) =>
                            {
                                return $.$$.System.String.op_Equality(a.GetName().Name, assemblyName);
                            }, {
  "r": 262145,
  "p": [
    {
      "n": "a",
      "p": 106168321
    }
  ],
  "n": "",
  "d": 3473521,
  "h": 0,
  "f": 17825794
}));
                            if ($.$$.System.Reflection.Assembly.op_Inequality(assembly, null))
                            {
                                loadedAssemblies.Add(assembly);
                            }
                        }
                        i++;
                    }
                    return loadedAssemblies;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17183342705)
            
            static $h = 3473521;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888375409),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "LoadAssembliesAsync",
      "d": 3473521,
      "h": 12888375409,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888375409),
//--TRIMMABLE-BOUNDARY-START(21478310001),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "LoadAssembliesInServerAsync",
      "d": 3473521,
      "h": 21478310001,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21478310001),
//--TRIMMABLE-BOUNDARY-START(17183342705),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Reflection.Assembly)).$h,
      "p": [
        {
          "n": "assembliesToLoad",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "LoadAssembliesInClientAsync",
      "d": 3473521,
      "h": 17183342705,
      "f": 16781346,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183342705)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298440817),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3473521,
      "h": 4298440817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298440817)
  ],
  "j": [3539057
  ],
  "h": 3473521
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LazyAssemblyLoader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3473521)
        
        
        //--TRIMMABLE-BOUNDARY-START(4194417)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentSerializationSettings", ($self) => class WebAssemblyComponentSerializationSettings
        {
            //--TRIMMABLE-BOUNDARY-START(8594129009)
            /*JsonSerializerOptions*/ static JsonSerializationOptions = null;
            //--TRIMMABLE-BOUNDARY-END(8594129009)
            
            //--TRIMMABLE-BOUNDARY-START(4299161713)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8594129009)
                    this.JsonSerializationOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.DefaultIgnoreCondition = 3/*JsonIgnoreCondition.WhenWritingNull*/;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(8594129009)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299161713)
            
            static $h = 4194417;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8594129009),
    {
      "t": 3342420,
      "n": "JsonSerializationOptions",
      "d": 4194417,
      "h": 8594129009,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594129009)
  ],
  "h": 4194417
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyComponentSerializationSettings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4194417)
        
        
        //--TRIMMABLE-BOUNDARY-START(4456561)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Internal.LinkerFlags", ($self) => class LinkerFlags
        {
            //--TRIMMABLE-BOUNDARY-START(12889358449)
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            //--TRIMMABLE-BOUNDARY-END(12889358449)
            
            //--TRIMMABLE-BOUNDARY-START(4299423857)
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            //--TRIMMABLE-BOUNDARY-END(4299423857)
            
            //--TRIMMABLE-BOUNDARY-START(8594391153)
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            //--TRIMMABLE-BOUNDARY-END(8594391153)
            
            static $h = 4456561;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12889358449),
    {
      "n": "JsonSerialized",
      "d": 4456561,
      "h": 12889358449,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889358449),
//--TRIMMABLE-BOUNDARY-START(4299423857),
    {
      "n": "Component",
      "d": 4456561,
      "h": 4299423857,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4299423857),
//--TRIMMABLE-BOUNDARY-START(8594391153),
    {
      "n": "JSInvokable",
      "d": 4456561,
      "h": 8594391153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594391153)
  ],
  "h": 4456561
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LinkerFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4456561)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572977)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RegisteredComponentsInterop", ($self) => class RegisteredComponentsInterop extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361311345)
            /*string*/ static Prefix = null;
            //--TRIMMABLE-BOUNDARY-END(34361311345)
            
            //--TRIMMABLE-BOUNDARY-START(25771376753)
            /*string*/ static GetRegisteredComponentsCount = null;
            //--TRIMMABLE-BOUNDARY-END(25771376753)
            
            //--TRIMMABLE-BOUNDARY-START(12886474865)
            /*string*/ static GetId = null;
            //--TRIMMABLE-BOUNDARY-END(12886474865)
            
            //--TRIMMABLE-BOUNDARY-START(8591507569)
            /*string*/ static GetAssembly = null;
            //--TRIMMABLE-BOUNDARY-END(8591507569)
            
            //--TRIMMABLE-BOUNDARY-START(30066344049)
            /*string*/ static GetTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(30066344049)
            
            //--TRIMMABLE-BOUNDARY-START(17181442161)
            /*string*/ static GetParameterDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(17181442161)
            
            //--TRIMMABLE-BOUNDARY-START(21476409457)
            /*string*/ static GetParameterValues = null;
            //--TRIMMABLE-BOUNDARY-END(21476409457)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34361311345)
                    this.Prefix = "Blazor._internal.registeredComponents.";
                    //--TRIMMABLE-BOUNDARY-END(34361311345)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771376753)
                    this.GetRegisteredComponentsCount = "Blazor._internal.registeredComponents.getRegisteredComponentsCount";
                    //--TRIMMABLE-BOUNDARY-END(25771376753)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886474865)
                    this.GetId = "Blazor._internal.registeredComponents.getId";
                    //--TRIMMABLE-BOUNDARY-END(12886474865)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507569)
                    this.GetAssembly = "Blazor._internal.registeredComponents.getAssembly";
                    //--TRIMMABLE-BOUNDARY-END(8591507569)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066344049)
                    this.GetTypeName = "Blazor._internal.registeredComponents.getTypeName";
                    //--TRIMMABLE-BOUNDARY-END(30066344049)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181442161)
                    this.GetParameterDefinitions = "Blazor._internal.registeredComponents.getParameterDefinitions";
                    //--TRIMMABLE-BOUNDARY-END(17181442161)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476409457)
                    this.GetParameterValues = "Blazor._internal.registeredComponents.getParameterValues";
                    //--TRIMMABLE-BOUNDARY-END(21476409457)
                    
                }
            }
            static $h = 1572977;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361311345),
    {
      "t": 1310721,
      "n": "Prefix",
      "d": 1572977,
      "h": 34361311345,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34361311345),
//--TRIMMABLE-BOUNDARY-START(25771376753),
    {
      "t": 1310721,
      "n": "GetRegisteredComponentsCount",
      "d": 1572977,
      "h": 25771376753,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771376753),
//--TRIMMABLE-BOUNDARY-START(12886474865),
    {
      "t": 1310721,
      "n": "GetId",
      "d": 1572977,
      "h": 12886474865,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474865),
//--TRIMMABLE-BOUNDARY-START(8591507569),
    {
      "t": 1310721,
      "n": "GetAssembly",
      "d": 1572977,
      "h": 8591507569,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507569),
//--TRIMMABLE-BOUNDARY-START(30066344049),
    {
      "t": 1310721,
      "n": "GetTypeName",
      "d": 1572977,
      "h": 30066344049,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066344049),
//--TRIMMABLE-BOUNDARY-START(17181442161),
    {
      "t": 1310721,
      "n": "GetParameterDefinitions",
      "d": 1572977,
      "h": 17181442161,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442161),
//--TRIMMABLE-BOUNDARY-START(21476409457),
    {
      "t": 1310721,
      "n": "GetParameterValues",
      "d": 1572977,
      "h": 21476409457,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476409457)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540273),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572977,
      "h": 4296540273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540273)
  ],
  "h": 1572977
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RegisteredComponentsInterop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572977)
        
        
        //--TRIMMABLE-BOUNDARY-START(917617)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider", ($self) => class ResourceCollectionProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885819505)
            /*string?*/ _url = null;
            //--TRIMMABLE-BOUNDARY-END(12885819505)
            
            //--TRIMMABLE-BOUNDARY-START(38655623281)
            /*string? */ get ResourceCollectionUrl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._url;
            }
            /*string? */ set ResourceCollectionUrl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this._url, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The resource collection URL has already been set.");
                }
                this._url = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623281)
            
            //--TRIMMABLE-BOUNDARY-START(8590852209)
            /*ResourceAssetCollection?*/ _resourceCollection = null;
            //--TRIMMABLE-BOUNDARY-END(8590852209)
            
            //--TRIMMABLE-BOUNDARY-START(4295884913)
            /*IJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4295884913)
            
            //--TRIMMABLE-BOUNDARY-START(17180786801)
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786801)
            
            //--TRIMMABLE-BOUNDARY-START(30065688689)
            /*Task<ResourceAssetCollection> *//*async*/  GetResourceCollection()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection), $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065688689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resourceCollection = this._resourceCollection ??= await this.LoadResourceCollection();
                    return this._resourceCollection;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(30065688689)
            
            //--TRIMMABLE-BOUNDARY-START(51540525169)
            /*void */ SetResourceCollection(/*ResourceAssetCollection*/ resourceCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._resourceCollection = resourceCollection;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525169)
            
            //--TRIMMABLE-BOUNDARY-START(34360655985)
            /*Task<ResourceAssetCollection> *//*async*/  LoadResourceCollection()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection), $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655985);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.op_Equality(this._url, null))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection.Empty;
                    }
                    /*var*/ let module = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this._jsRuntime, "import", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._url ], null, null));
                    /*var*/ let result = await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeAsync($.$typeArray($.$mac.Microsoft.AspNetCore.Components.ResourceAsset), module, "get", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                    return result === null ? $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection.Empty : new $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection().$ctor$1(result);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34360655985)
            
            static $h = 917617;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655623281),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721393,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245557873,
        "f": 83886081
      },
      "n": "ResourceCollectionUrl",
      "d": 917617,
      "h": 38655623281,
      "f": 2097153,
      "a": [
        {
          "t": 6357100,
          "c": 4301324396
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655623281)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065688689),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection).$h,
      "n": "GetResourceCollection",
      "d": 917617,
      "h": 30065688689,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(30065688689),
//--TRIMMABLE-BOUNDARY-START(51540525169),
    {
      "r": 65537,
      "p": [
        {
          "n": "resourceCollection",
          "p": 9437292
        }
      ],
      "n": "SetResourceCollection",
      "d": 917617,
      "h": 51540525169,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540525169),
//--TRIMMABLE-BOUNDARY-START(34360655985),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection).$h,
      "n": "LoadResourceCollection",
      "d": 917617,
      "h": 34360655985,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(34360655985)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819505),
    {
      "t": 1310721,
      "n": "_url",
      "d": 917617,
      "h": 12885819505,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819505),
//--TRIMMABLE-BOUNDARY-START(8590852209),
    {
      "t": 9437292,
      "n": "_resourceCollection",
      "d": 917617,
      "h": 8590852209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852209),
//--TRIMMABLE-BOUNDARY-START(4295884913),
    {
      "t": 524395,
      "n": "_jsRuntime",
      "d": 917617,
      "h": 4295884913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884913)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786801),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917617,
      "h": 17180786801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786801)
  ],
  "h": 917617
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ResourceCollectionProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917617)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293873)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions", ($self) => class WebAssemblyHostEnvironmentExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297261169)
            static /*bool */ IsDevelopment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297261169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Development");
            }
            //--TRIMMABLE-BOUNDARY-END(4297261169)
            
            //--TRIMMABLE-BOUNDARY-START(17182163057)
            static /*bool */ IsStaging(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182163057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Staging");
            }
            //--TRIMMABLE-BOUNDARY-END(17182163057)
            
            //--TRIMMABLE-BOUNDARY-START(12887195761)
            static /*bool */ IsProduction(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887195761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Production");
            }
            //--TRIMMABLE-BOUNDARY-END(12887195761)
            
            //--TRIMMABLE-BOUNDARY-START(8592228465)
            static /*bool */ IsEnvironment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment, /*string*/ environmentName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592228465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(hostingEnvironment, "hostingEnvironment");
                return $.$$.System.String.Equals$2(hostingEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment, environmentName, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8592228465)
            
            static $h = 2293873;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297261169),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441905
        }
      ],
      "n": "IsDevelopment",
      "d": 2293873,
      "h": 4297261169,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297261169),
//--TRIMMABLE-BOUNDARY-START(17182163057),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441905
        }
      ],
      "n": "IsStaging",
      "d": 2293873,
      "h": 17182163057,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182163057),
//--TRIMMABLE-BOUNDARY-START(12887195761),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441905
        }
      ],
      "n": "IsProduction",
      "d": 2293873,
      "h": 12887195761,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887195761),
//--TRIMMABLE-BOUNDARY-START(8592228465),
    {
      "r": 262145,
      "p": [
        {
          "n": "hostingEnvironment",
          "p": 1441905
        },
        {
          "n": "environmentName",
          "p": 1310721
        }
      ],
      "n": "IsEnvironment",
      "d": 2293873,
      "h": 8592228465,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592228465)
  ],
  "h": 2293873
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyHostEnvironmentExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293873)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621553)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.JSInteropMethods", ($self) => class JSInteropMethods
        {
            //--TRIMMABLE-BOUNDARY-START(4297588849)
            static /*void */ NotifyLocationChanged(/*string*/ uri, /*bool*/ isInterceptedLink)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297588849);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.SetLocation(uri, null, isInterceptedLink);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297588849)
            
            //--TRIMMABLE-BOUNDARY-START(8592556145)
            static /*void */ NotifyLocationChanged$1(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592556145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.SetLocation(uri, state, isInterceptedLink);
            }
            //--TRIMMABLE-BOUNDARY-END(8592556145)
            
            //--TRIMMABLE-BOUNDARY-START(12887523441)
            static /*ValueTask<bool> *//*async*/  NotifyLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887523441);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.HandleLocationChangingAsync(uri, state, isInterceptedLink);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12887523441)
            
            static $h = 2621553;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588849),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChanged",
      "d": 2621553,
      "h": 4297588849,
      "f": 16777249,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API is for framework use only and is no longer used in the current version",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297588849),
//--TRIMMABLE-BOUNDARY-START(8592556145),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChanged",
      "o": "@$1",
      "d": 2621553,
      "h": 8592556145,
      "f": 16777249,
      "a": [
        {
          "t": 2818155,
          "c": 8592752747,
          "a": [
            {
              "v": "NotifyLocationChanged",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592556145),
//--TRIMMABLE-BOUNDARY-START(12887523441),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "NotifyLocationChangingAsync",
      "d": 2621553,
      "h": 12887523441,
      "f": 16781345,
      "a": [
        {
          "t": 2818155,
          "c": 8592752747,
          "a": [
            {
              "v": "NotifyLocationChangingAsync",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887523441)
  ],
  "h": 2621553,
  "a": [
    {
      "t": 64159745,
      "c": 4359127041,
      "a": [
        {
          "v": 1,
          "t": 64225281
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `JSInteropMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621553)
        
        
        //--TRIMMABLE-BOUNDARY-START(2556017)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions", ($self) => class WebAssemblyHttpRequestMessageExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8592490609)
            /*HttpRequestOptionsKey<IDictionary<string, object>>*/ static FetchRequestOptionsKey;
            //--TRIMMABLE-BOUNDARY-END(8592490609)
            
            //--TRIMMABLE-BOUNDARY-START(42952228977)
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingRequestKey;
            //--TRIMMABLE-BOUNDARY-END(42952228977)
            
            //--TRIMMABLE-BOUNDARY-START(47247196273)
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingResponseKey;
            //--TRIMMABLE-BOUNDARY-END(47247196273)
            
            //--TRIMMABLE-BOUNDARY-START(17182425201)
            static /*HttpRequestMessage */ SetBrowserRequestCredentials(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCredentials*/ requestCredentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182425201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCredentials === 0/*BrowserRequestCredentials.Omit*/)
                    {
                        return "omit";
                    }
                    if (requestCredentials === 1/*BrowserRequestCredentials.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestCredentials === 2/*BrowserRequestCredentials.Include*/)
                    {
                        return "include";
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported enum value ${requestCredentials}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "credentials", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(17182425201)
            
            //--TRIMMABLE-BOUNDARY-START(12887457905)
            static /*HttpRequestMessage */ SetBrowserRequestCache(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCache*/ requestCache)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887457905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCache === 0/*BrowserRequestCache.Default*/)
                    {
                        return $.$default();
                    }
                    if (requestCache === 1/*BrowserRequestCache.NoStore*/)
                    {
                        return "no-store";
                    }
                    if (requestCache === 2/*BrowserRequestCache.Reload*/)
                    {
                        return "reload";
                    }
                    if (requestCache === 3/*BrowserRequestCache.NoCache*/)
                    {
                        return "no-cache";
                    }
                    if (requestCache === 4/*BrowserRequestCache.ForceCache*/)
                    {
                        return "force-cache";
                    }
                    if (requestCache === 5/*BrowserRequestCache.OnlyIfCached*/)
                    {
                        return "only-if-cached";
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported enum value ${requestCache}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "cache", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(12887457905)
            
            //--TRIMMABLE-BOUNDARY-START(25772359793)
            static /*HttpRequestMessage */ SetBrowserRequestMode(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestMode*/ requestMode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772359793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestMode === 0/*BrowserRequestMode.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestMode === 1/*BrowserRequestMode.NoCors*/)
                    {
                        return "no-cors";
                    }
                    if (requestMode === 2/*BrowserRequestMode.Cors*/)
                    {
                        return "cors";
                    }
                    if (requestMode === 3/*BrowserRequestMode.Navigate*/)
                    {
                        return "navigate";
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`Unsupported enum value ${requestMode}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "mode", stringOption);
            }
            //--TRIMMABLE-BOUNDARY-END(25772359793)
            
            //--TRIMMABLE-BOUNDARY-START(21477392497)
            static /*HttpRequestMessage */ SetBrowserRequestIntegrity(/*this HttpRequestMessage*/ requestMessage, /*string*/ integrity)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477392497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "integrity", integrity);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477392497)
            
            //--TRIMMABLE-BOUNDARY-START(30067327089)
            static /*HttpRequestMessage */ SetBrowserRequestOption(/*this HttpRequestMessage*/ requestMessage, /*string*/ name, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067327089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                /*IDictionary<string, object>*/ let fetchOptions;
                /*var*/ let entry;
                if (requestMessage.Options.TryGetValue($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, $.$ref(() => entry, ($v) => entry = $v, $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object))))
                {
                    fetchOptions = entry;
                }
                else 
                {
                    fetchOptions = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.Ordinal);
                    requestMessage.Options.Set($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, fetchOptions);
                }
                fetchOptions.System$Collections$Generic$IDictionary$$$$set_Item(name, value, [$.$$.System.String, $.$$.System.Object]);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(30067327089)
            
            //--TRIMMABLE-BOUNDARY-START(34362294385)
            static /*HttpRequestMessage */ SetBrowserRequestStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362294385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$$.System.Boolean, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingRequestKey, streamingEnabled);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(34362294385)
            
            //--TRIMMABLE-BOUNDARY-START(38657261681)
            static /*HttpRequestMessage */ SetBrowserResponseStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657261681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$$.System.Boolean, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingResponseKey, streamingEnabled);
                return requestMessage;
            }
            //--TRIMMABLE-BOUNDARY-END(38657261681)
            
            //--TRIMMABLE-BOUNDARY-START(4297523313)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8592490609)
                    this.FetchRequestOptionsKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object)))().$ctor$3("WebAssemblyFetchOptions");
                    //--TRIMMABLE-BOUNDARY-END(8592490609)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952228977)
                    this.WebAssemblyEnableStreamingRequestKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Boolean))().$ctor$3("WebAssemblyEnableStreamingRequest");
                    //--TRIMMABLE-BOUNDARY-END(42952228977)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47247196273)
                    this.WebAssemblyEnableStreamingResponseKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Boolean))().$ctor$3("WebAssemblyEnableStreamingResponse");
                    //--TRIMMABLE-BOUNDARY-END(47247196273)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297523313)
            
            static $h = 2556017;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182425201),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestCredentials",
          "p": 2424945
        }
      ],
      "n": "SetBrowserRequestCredentials",
      "d": 2556017,
      "h": 17182425201,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182425201),
//--TRIMMABLE-BOUNDARY-START(12887457905),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestCache",
          "p": 2359409
        }
      ],
      "n": "SetBrowserRequestCache",
      "d": 2556017,
      "h": 12887457905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887457905),
//--TRIMMABLE-BOUNDARY-START(25772359793),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "requestMode",
          "p": 2490481
        }
      ],
      "n": "SetBrowserRequestMode",
      "d": 2556017,
      "h": 25772359793,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772359793),
//--TRIMMABLE-BOUNDARY-START(21477392497),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "integrity",
          "p": 1310721
        }
      ],
      "n": "SetBrowserRequestIntegrity",
      "d": 2556017,
      "h": 21477392497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477392497),
//--TRIMMABLE-BOUNDARY-START(30067327089),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetBrowserRequestOption",
      "d": 2556017,
      "h": 30067327089,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067327089),
//--TRIMMABLE-BOUNDARY-START(34362294385),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "streamingEnabled",
          "p": 262145
        }
      ],
      "n": "SetBrowserRequestStreamingEnabled",
      "d": 2556017,
      "h": 34362294385,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362294385),
//--TRIMMABLE-BOUNDARY-START(38657261681),
    {
      "r": 7602229,
      "p": [
        {
          "n": "requestMessage",
          "p": 7602229
        },
        {
          "n": "streamingEnabled",
          "p": 262145
        }
      ],
      "n": "SetBrowserResponseStreamingEnabled",
      "d": 2556017,
      "h": 38657261681,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657261681)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592490609),
    {
      "t": $.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "FetchRequestOptionsKey",
      "d": 2556017,
      "h": 8592490609,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8592490609),
//--TRIMMABLE-BOUNDARY-START(42952228977),
    {
      "t": $.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Boolean).$h,
      "n": "WebAssemblyEnableStreamingRequestKey",
      "d": 2556017,
      "h": 42952228977,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42952228977),
//--TRIMMABLE-BOUNDARY-START(47247196273),
    {
      "t": $.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$$.System.Boolean).$h,
      "n": "WebAssemblyEnableStreamingResponseKey",
      "d": 2556017,
      "h": 47247196273,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47247196273)
  ],
  "h": 2556017
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyHttpRequestMessageExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556017)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769585)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue", ($self) => class WebAssemblyCallQueue
        {
            //--TRIMMABLE-BOUNDARY-START(4296736881)
            /*bool*/ static _isCallInProgress = false;
            //--TRIMMABLE-BOUNDARY-END(4296736881)
            
            //--TRIMMABLE-BOUNDARY-START(8591704177)
            /*Queue<Action>*/ static _pendingWork = null;
            //--TRIMMABLE-BOUNDARY-END(8591704177)
            
            //--TRIMMABLE-BOUNDARY-START(38656475249)
            static /*bool */ get IsInProgress()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress;
            }
            //--TRIMMABLE-BOUNDARY-END(38656475249)
            
            //--TRIMMABLE-BOUNDARY-START(34361507953)
            static /*bool */ get HasUnstartedWork()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.Count > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(34361507953)
            
            //--TRIMMABLE-BOUNDARY-START(42951442545)
            static /*void */ Schedule(T, /*T*/ state, /*Action<T>*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951442545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress)
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.Enqueue(new $.$$.System.Action().$ctor(this,  () =>
                    {
                        return callback.Invoke(state);
                    }, {
  "r": 65537,
  "n": "",
  "d": 1769585,
  "h": 0,
  "f": 17825794
}));
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress = true;
                    callback.Invoke(state);
                    /*var*/ let nextWorkItem;
                    while($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.TryDequeue($.$ref(() => nextWorkItem, ($v) => nextWorkItem = $v, $.$$.System.Action)))
                    {
                        nextWorkItem.Invoke();
                    }
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951442545)
            
            //--TRIMMABLE-BOUNDARY-START(12886671473)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8591704177)
                    this._pendingWork = new ($.$$.System.Collections.Generic.Queue$$($.$$.System.Action))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8591704177)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886671473)
            
            static $h = 1769585;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656475249),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540657,
        "f": 50331681
      },
      "n": "IsInProgress",
      "d": 1769585,
      "h": 38656475249,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38656475249),
//--TRIMMABLE-BOUNDARY-START(34361507953),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476606065,
        "f": 50331681
      },
      "n": "HasUnstartedWork",
      "d": 1769585,
      "h": 34361507953,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34361507953)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951442545),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": (T) => T.$h
        },
        {
          "n": "callback",
          "p": (T) => $.$$.System.Action$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Schedule",
      "d": 1769585,
      "h": 42951442545,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42951442545)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736881),
    {
      "t": 262145,
      "n": "_isCallInProgress",
      "d": 1769585,
      "h": 4296736881,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296736881),
//--TRIMMABLE-BOUNDARY-START(8591704177),
    {
      "t": $.$$.System.Collections.Generic.Queue$$($.$$.System.Action).$h,
      "n": "_pendingWork",
      "d": 1769585,
      "h": 8591704177,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591704177)
  ],
  "h": 1769585
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyCallQueue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769585)
        
        
        //--TRIMMABLE-BOUNDARY-START(4128881)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer", ($self) => class WebAssemblyComponentParameterDeserializer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4299096177)
            /*ComponentParametersTypeCache*/ _parametersCache = null;
            //--TRIMMABLE-BOUNDARY-END(4299096177)
            
            //--TRIMMABLE-BOUNDARY-START(12889030769)
            $ctor$1(/*ComponentParametersTypeCache*/ parametersCache)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12889030769);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._parametersCache = parametersCache;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12889030769)
            
            //--TRIMMABLE-BOUNDARY-START(42953801841)
            /*WebAssemblyComponentParameterDeserializer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(42953801841)
            
            //--TRIMMABLE-BOUNDARY-START(21478965361)
            /*ParameterView */ DeserializeParameters(/*IList<ComponentParameter>*/ parametersDefinitions, /*IList<object>*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478965361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parametersDictionary = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                if (parameterValues.System$Collections$Generic$ICollection$$$Count !== parametersDefinitions.System$Collections$Generic$ICollection$$$Count)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The number of parameter definitions '${parametersDefinitions.System$Collections$Generic$ICollection$$$Count}' does not match the number parameter values '${parameterValues.System$Collections$Generic$ICollection$$$Count}'.`);
                }
                for(/*var*/ let i = 0; i < parametersDefinitions.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let definition = parametersDefinitions.System$Collections$Generic$IList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    if ($.$$.System.String.op_Equality(definition.Name, null))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("The name is missing in a parameter definition.");
                    }
                    if ($.$$.System.String.op_Equality(definition.TypeName, null) && $.$$.System.String.op_Equality(definition.Assembly, null))
                    {
                        parametersDictionary.set_Item(definition.Name, null);
                    }
                    else if ($.$$.System.String.op_Equality(definition.TypeName, null) || $.$$.System.String.op_Equality(definition.Assembly, null))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`The parameter definition for '${definition.Name}' is incomplete: Type='${definition.TypeName}' Assembly='${definition.Assembly}'.`);
                    }
                    else 
                    {
                        /*var*/ let parameterType = this._parametersCache.GetParameterType(definition.Assembly, definition.TypeName);
                        if ($.$$.System.Type.op_Equality$1(parameterType, null))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`The parameter '${definition.Name}' with type '${definition.TypeName}' in assembly '${definition.Assembly}' could not be found.`);
                        }
                        try
                        {
                            /*var*/ let value = $.$cast(parameterValues.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.Object]), $.$stj.System.Text.Json.JsonElement);
                            /*var*/ let parameterValue = $.$stj.System.Text.Json.JsonSerializer.Deserialize$9(value.GetRawText(), parameterType, $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentSerializationSettings.JsonSerializationOptions);
                            parametersDictionary.set_Item(definition.Name, parameterValue);
                        }
                        catch(e)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$11(`Could not parse the parameter value for parameter '${definition.Name}' of type '${definition.TypeName}' and assembly '${definition.Assembly}'.`, e);
                        }
                    }
                }
                return $.$mac.Microsoft.AspNetCore.Components.ParameterView.FromDictionary(parametersDictionary);
            }
            //--TRIMMABLE-BOUNDARY-END(21478965361)
            
            //--TRIMMABLE-BOUNDARY-START(34363867249)
            static /*ComponentParameter[] */ GetParameterDefinitions(/*string*/ parametersDefinitions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363867249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stj.System.Text.Json.JsonSerializer.Deserialize$31($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), parametersDefinitions, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.ComponentParameterArray);
            }
            //--TRIMMABLE-BOUNDARY-END(34363867249)
            
            //--TRIMMABLE-BOUNDARY-START(38658834545)
            static /*IList<object> */ GetParameterValues(/*string*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658834545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$stj.System.Text.Json.JsonSerializer.Deserialize$31($.$$.System.Collections.Generic.IList$$($.$$.System.Object), parameterValues, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.IListObject);
            }
            //--TRIMMABLE-BOUNDARY-END(38658834545)
            
            //--TRIMMABLE-BOUNDARY-START(8594063473)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer().$ctor$1(new $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache().$ctor$1());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8594063473)
            
            static $h = 4128881;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953801841),
    {
      "p": 4128881,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068899953,
        "f": 50331681
      },
      "n": "Instance",
      "d": 4128881,
      "h": 42953801841,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42953801841)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478965361),
    {
      "r": 5767276,
      "p": [
        {
          "n": "parametersDefinitions",
          "p": $.$$.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h
        },
        {
          "n": "parameterValues",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Object).$h
        }
      ],
      "n": "DeserializeParameters",
      "d": 4128881,
      "h": 21478965361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478965361),
//--TRIMMABLE-BOUNDARY-START(34363867249),
    {
      "r": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
      "p": [
        {
          "n": "parametersDefinitions",
          "p": 1310721
        }
      ],
      "n": "GetParameterDefinitions",
      "d": 4128881,
      "h": 34363867249,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34363867249),
//--TRIMMABLE-BOUNDARY-START(38658834545),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "parameterValues",
          "p": 1310721
        }
      ],
      "n": "GetParameterValues",
      "d": 4128881,
      "h": 38658834545,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38658834545)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4299096177),
    {
      "t": 327793,
      "n": "_parametersCache",
      "d": 4128881,
      "h": 4299096177,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4299096177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12889030769),
    {
      "p": [
        {
          "n": "parametersCache",
          "p": 327793
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4128881,
      "h": 12889030769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12889030769)
  ],
  "h": 4128881
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyComponentParameterDeserializer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4128881)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310833)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.TransmitDataStreamToJS", ($self) => class TransmitDataStreamToJS
        {
            //--TRIMMABLE-BOUNDARY-START(4296278129)
            static /*Task *//*async*/  TransmitStreamAsync(/*IJSRuntime*/ runtime, /*string*/ methodIdentifier, /*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let buffer = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(((32 * 1024) | 0));
                    try
                    {
                        /*int*/ let bytesRead;
                        while((bytesRead = await dotNetStreamReference.Stream.ReadAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$1(buffer), new $.$$.System.Threading.CancellationToken())) > 0)
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(streamId, $.$$.System.Int64), buffer, $.$box(bytesRead, $.$$.System.Int32), null ], null, null));
                        }
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(streamId, $.$$.System.Int64), $.$$.System.Array.Empty($.$$.System.Byte), $.$box(0, $.$$.System.Int32), null ], null, null));
                    }
                    catch(ex)
                    {
                        try
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(streamId, $.$$.System.Int64), $.$$.System.Array.Empty($.$$.System.Byte), $.$box(0, $.$$.System.Int32), ex.Message ], null, null));
                        }
                        catch($e)
                        {
                        }
                        throw ex;
                    }
                    finally
                    {
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(buffer, true);
                            if (!dotNetStreamReference.LeaveOpen)
                            {
                                dotNetStreamReference.Stream?.Dispose();
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4296278129)
            
            static $h = 1310833;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296278129),
    {
      "r": 177537025,
      "p": [
        {
          "n": "runtime",
          "p": 524395
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262251
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 1310833,
      "h": 4296278129,
      "f": 16781352
    },
//--TRIMMABLE-BOUNDARY-END(4296278129)
  ],
  "h": 1310833
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `TransmitDataStreamToJS`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310833)
        
        
        //--TRIMMABLE-BOUNDARY-START(589937)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770393713)
            /*HotReloadManager*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(25770393713)
            
            //--TRIMMABLE-BOUNDARY-START(51540197489)
            /*bool*/ MetadataUpdateSupported = false;
            //--TRIMMABLE-BOUNDARY-END(51540197489)
            
            //--TRIMMABLE-BOUNDARY-START(47245230193)
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            //--TRIMMABLE-BOUNDARY-END(47245230193)
            
            //--TRIMMABLE-BOUNDARY-START(55835164785)
            /*Action?*/ OnDeltaApplied = null;
            //--TRIMMABLE-BOUNDARY-END(55835164785)
            
            //--TRIMMABLE-BOUNDARY-START(55835164785)
            //--TRIMMABLE-BOUNDARY-START(21475426417)
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426417)
            
            //--TRIMMABLE-BOUNDARY-START(64425099377)
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$$.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425099377)
            
            //--TRIMMABLE-BOUNDARY-END(55835164785)
            
            //--TRIMMABLE-BOUNDARY-START(81604968561)
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604968561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604968561)
            
            //--TRIMMABLE-BOUNDARY-START(77310001265)
            /*void */ TriggerOnDeltaApplied()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310001265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.OnDeltaApplied?.Invoke() ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310001265)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$$.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //--TRIMMABLE-BOUNDARY-START(4295557233)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770393713)
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770393713)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295557233)
            
            static $h = 589937;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540197489),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015033969,
        "f": 83886081
      },
      "n": "MetadataUpdateSupported",
      "d": 589937,
      "h": 51540197489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540197489),
//--TRIMMABLE-BOUNDARY-START(47245230193),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328305,
        "f": 50331649
      },
      "n": "IsSubscribedTo",
      "d": 589937,
      "h": 47245230193,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230193)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604968561),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "UpdateApplication",
      "d": 589937,
      "h": 81604968561,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604968561),
//--TRIMMABLE-BOUNDARY-START(77310001265),
    {
      "r": 65537,
      "n": "TriggerOnDeltaApplied",
      "d": 589937,
      "h": 77310001265,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310001265)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770393713),
    {
      "t": 589937,
      "n": "Default",
      "d": 589937,
      "h": 25770393713,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524529),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589937,
      "h": 8590524529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524529)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55835164785),
    {
      "e": 42270721,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "add_OnDeltaApplied",
        "d": 589937,
        "h": 21475426417,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 42270721
          }
        ],
        "n": "remove_OnDeltaApplied",
        "d": 589937,
        "h": 64425099377,
        "f": 285212673
      },
      "n": "OnDeltaApplied",
      "d": 589937,
      "h": 55835164785,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(55835164785)
  ],
  "h": 589937
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589937)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097265)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilderExtensions", ($self) => class WebAssemblyHostBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297064561)
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider$1(/*this WebAssemblyHostBuilder*/ builder, /*Action<ServiceProviderOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilderExtensions.UseDefaultServiceProvider(builder, new ($.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions))().$ctor(this,  (/**/ env, /**/ options) =>
                {
                    return configure.Invoke(options);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "env",
      "p": 1441905
    },
    {
      "n": "options",
      "p": 3276893
    }
  ],
  "n": "",
  "d": 2097265,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(4297064561)
            
            //--TRIMMABLE-BOUNDARY-START(8592031857)
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider(/*this WebAssemblyHostBuilder*/ builder, /*Action<IWebAssemblyHostEnvironment, ServiceProviderOptions>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configure, "configure");
                /*var*/ let options = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions().$ctor$1();
                configure.Invoke(builder.HostEnvironment, options);
                return builder.UseServiceProviderOptions(options);
            }
            //--TRIMMABLE-BOUNDARY-END(8592031857)
            
            static $h = 2097265;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297064561),
    {
      "r": 2031729,
      "p": [
        {
          "n": "builder",
          "p": 2031729
        },
        {
          "n": "configure",
          "p": $.$$.System.Action$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions).$h
        }
      ],
      "n": "UseDefaultServiceProvider",
      "o": "@$1",
      "d": 2097265,
      "h": 4297064561,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297064561),
//--TRIMMABLE-BOUNDARY-START(8592031857),
    {
      "r": 2031729,
      "p": [
        {
          "n": "builder",
          "p": 2031729
        },
        {
          "n": "configure",
          "p": $.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions).$h
        }
      ],
      "n": "UseDefaultServiceProvider",
      "d": 2097265,
      "h": 8592031857,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592031857)
  ],
  "h": 2097265
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyHostBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097265)
        
        
        //--TRIMMABLE-BOUNDARY-START(327793)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache", ($self) => class ComponentParametersTypeCache extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295089)
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            //--TRIMMABLE-BOUNDARY-END(4295295089)
            
            //--TRIMMABLE-BOUNDARY-START(12885229681)
            /*Type? */ GetParameterType(/*string*/ assembly, /*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let key = new $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key().$ctor$3(assembly, type);
                /*var*/ let resolvedType;
                if (this._typeToKeyLookUp.TryGetValue(key.Clone(), $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$$.System.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$2($.$typeArray($.$$.System.Reflection.Assembly), key.Clone(), new ($.$$.System.Func$$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$typeArray($.$$.System.Reflection.Assembly), $.$$.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache, $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.ResolveType), $.$$.System.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229681)
            
            //--TRIMMABLE-BOUNDARY-START(21475164273)
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$$.System.Array.$ReadT1.call(assemblies, i);
                    if ($.$$.System.String.op_Equality(current.GetName().Name, key.Assembly))
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$$.System.Reflection.Assembly.op_Equality(assembly, null))
                {
                    if ($.$$.System.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$$.System.Reflection.Assembly.Load$4(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$1(key.Type, false, false) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164273)
            
            //--TRIMMABLE-BOUNDARY-START(393329)
            static $_Key;
            static get Key()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache;
                return $cls.$_Key ??= $asm.$nstr("$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key", ($self) => class Key extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360625)
                    $ctor$3(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295360625);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$tupleUnpack(($tp) =>
                            {
                                this.Assembly = $tp.Item1;
                                this.Type = $tp.Item2;
                            }).$v = { Item1: assembly, Item2: type };
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295360625)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475229809)
                    /*string*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(21475229809)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014837361)
                    /*string*/ Type = null;
                    //--TRIMMABLE-BOUNDARY-END(73014837361)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25770197105, 34359869441)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770197105);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, { set $v(v){ key = v; } }) && this.Equals$2(key.Clone());
                        }
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25770197105, 34359869441)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065164401)
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065164401);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.String.Equals$2(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$$.System.String.Equals$2(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065164401)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 51540000881, 184683724801)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540000881);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.Assembly, this.Type);
                        }
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 51540000881, 184683724801)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385210369)
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385210369);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385210369)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 393329;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229809),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098993,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129935473,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 393329,
      "h": 21475229809,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229809),
//--TRIMMABLE-BOUNDARY-START(73014837361),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245033585,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719870065,
        "f": 83886081
      },
      "n": "Type",
      "d": 393329,
      "h": 73014837361,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014837361)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25770197105, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 393329,
      "h": 25770197105,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770197105, 34359869441),
//--TRIMMABLE-BOUNDARY-START(30065164401),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 393329
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 393329,
      "h": 30065164401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164401),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540000881, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 393329,
      "h": 51540000881,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540000881, 184683724801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360625),
    {
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393329,
      "h": 4295360625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360625),
//--TRIMMABLE-BOUNDARY-START(8590327921),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393329,
      "h": 8590327921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327921)
  ],
  "i": [$.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key).$h
  ],
  "d": 327793,
  "h": 393329
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key) ]; }
                    static get $fullName() { return `ComponentParametersTypeCache.Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393329)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295295089)
                this._typeToKeyLookUp = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$$.System.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295295089)
                
            }
            static $h = 327793;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229681),
    {
      "r": 187629569,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "GetParameterType",
      "d": 327793,
      "h": 12885229681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229681),
//--TRIMMABLE-BOUNDARY-START(21475164273),
    {
      "r": 187629569,
      "p": [
        {
          "n": "key",
          "p": 393329
        },
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.System.Reflection.Assembly).$h
        }
      ],
      "n": "ResolveType",
      "d": 327793,
      "h": 21475164273,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475164273)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295089),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$$.System.Type).$h,
      "n": "_typeToKeyLookUp",
      "d": 327793,
      "h": 4295295089,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295089)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262385),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327793,
      "h": 8590262385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262385)
  ],
  "j": [393329
  ],
  "h": 327793
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ComponentParametersTypeCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327793)
        
        
        //--TRIMMABLE-BOUNDARY-START(983153)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootComponentOperation", ($self) => class RootComponentOperation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107375165553)
            /*RootComponentOperationType*/ Type = 0;
            //--TRIMMABLE-BOUNDARY-END(107375165553)
            
            //--TRIMMABLE-BOUNDARY-START(103080198257)
            /*int*/ SsrComponentId = 0;
            //--TRIMMABLE-BOUNDARY-END(103080198257)
            
            //--TRIMMABLE-BOUNDARY-START(64425492593)
            /*ComponentMarker?*/ Marker = null;
            //--TRIMMABLE-BOUNDARY-END(64425492593)
            
            //--TRIMMABLE-BOUNDARY-START(25770786929)
            /*WebRootComponentDescriptor?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(25770786929)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Marker = null;
            }
            static $h = 983153;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(107375165553),
    {
      "p": 1114225,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130525297,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785230961,
        "f": 83886081
      },
      "n": "Type",
      "d": 983153,
      "h": 107375165553,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375165553),
//--TRIMMABLE-BOUNDARY-START(103080198257),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540590705,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195296369,
        "f": 83886081
      },
      "n": "SsrComponentId",
      "d": 983153,
      "h": 103080198257,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080198257),
//--TRIMMABLE-BOUNDARY-START(64425492593),
    {
      "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950656113,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605361777,
        "f": 83886081
      },
      "n": "Marker",
      "d": 983153,
      "h": 64425492593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425492593),
//--TRIMMABLE-BOUNDARY-START(25770786929),
    {
      "p": 4325489,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360721521,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015427185,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 983153,
      "h": 25770786929,
      "f": 2097153,
      "a": [
        {
          "t": 14024788,
          "c": 4308992084
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770786929)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950449),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983153,
      "h": 4295950449,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950449)
  ],
  "h": 983153
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `RootComponentOperation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983153)
        
        
        //--TRIMMABLE-BOUNDARY-START(4325489)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor", ($self) => class WebRootComponentDescriptor extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17184194673)
            /*Type*/ ComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(17184194673)
            
            //--TRIMMABLE-BOUNDARY-START(42953998449)
            /*WebRootComponentParameters*/ Parameters;
            //--TRIMMABLE-BOUNDARY-END(42953998449)
            
            //--TRIMMABLE-BOUNDARY-START(38659031153)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38659031153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameters = $.$$.System.String.Join$5(", ", $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String, this.Parameters.Parameters.ToDictionary(), new ($.$$.System.Func$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return `${p.Key}: ${$.$$.System.Object.ToString.call(p.Value)}`;
                }, {
  "r": 1310721,
  "p": [
    {
      "n": "p",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 4325489,
  "h": 0,
  "f": 17825794
})));
                return `${this.ComponentType.FullName}(${parameters})`;
            }
            //--TRIMMABLE-BOUNDARY-END(38659031153)
            
            //Begin primary constructor
            /*Type*/ componentType = null;
            /*WebRootComponentParameters*/ parameters = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters();
            $ctor$1(/*Type*/componentType, /*WebRootComponentParameters*/parameters)
            {
                this.componentType = componentType;
                this.parameters = parameters;
                //depends on primary constructor parameter
                this.ComponentType = this.componentType;
                //depends on primary constructor parameter
                this.Parameters = this.parameters;
                return this
            }
            //End primary constructor
            static $h = 4325489;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17184194673),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25774129265,
        "f": 50331649
      },
      "n": "ComponentType",
      "d": 4325489,
      "h": 17184194673,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17184194673),
//--TRIMMABLE-BOUNDARY-START(42953998449),
    {
      "p": 4391025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34364063857,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 4325489,
      "h": 42953998449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953998449)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38659031153),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 4325489,
      "h": 38659031153,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38659031153)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299292785),
    {
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "parameters",
          "p": 4391025
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4325489,
      "h": 4299292785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299292785)
  ],
  "h": 4325489,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebRootComponentDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4325489)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031729)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder", ($self) => class WebAssemblyHostBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591966321)
            /*IInternalJSImportMethods*/ _jsMethods = null;
            //--TRIMMABLE-BOUNDARY-END(8591966321)
            
            //--TRIMMABLE-BOUNDARY-START(4296999025)
            /*Func<IServiceProvider>*/ _createServiceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(4296999025)
            
            //--TRIMMABLE-BOUNDARY-START(17181900913)
            /*RootTypeCache?*/ _rootComponentCache = null;
            //--TRIMMABLE-BOUNDARY-END(17181900913)
            
            //--TRIMMABLE-BOUNDARY-START(12886933617)
            /*string?*/ _persistedState = null;
            //--TRIMMABLE-BOUNDARY-END(12886933617)
            
            //--TRIMMABLE-BOUNDARY-START(21476868209)
            /*ServiceProviderOptions?*/ _serviceProviderOptions = null;
            //--TRIMMABLE-BOUNDARY-END(21476868209)
            
            //--TRIMMABLE-BOUNDARY-START(64426541169)
            static /*WebAssemblyHostBuilder */ CreateDefault(/*string[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426541169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let builder = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance);
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Initialize();
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(64426541169)
            
            //--TRIMMABLE-BOUNDARY-START(25771835505)
            $ctor$1(/*IInternalJSImportMethods*/ jsMethods)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771835505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._jsMethods = jsMethods;
                    this.Configuration = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostConfiguration().$ctor$1();
                    this.RootComponents = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection().$ctor$3();
                    this.Services = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection().$ctor$1();
                    this.Logging = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.LoggingBuilder().$ctor$1(this.Services);
                    /*var*/ let assembly = $.$$.System.Reflection.Assembly.GetEntryAssembly();
                    if ($.$$.System.Reflection.Assembly.op_Inequality(assembly, null))
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.InitializeRoutingAppContextSwitch(assembly);
                    }
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.InitializeWebAssemblyRenderer();
                    this.InitializeNavigationManager();
                    this.InitializeRegisteredRootComponents();
                    this.InitializePersistedState();
                    this.InitializeDefaultServices();
                    /*var*/ let hostEnvironment = this.InitializeEnvironment();
                    this.HostEnvironment = hostEnvironment;
                    this._createServiceProvider = new ($.$$.System.Func$$($.$scm.System.IServiceProvider))().$ctor(this,  () =>
                    {
                        /*var*/ let isDevelopment = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsDevelopment(hostEnvironment);
                        /*var*/ let options = this._serviceProviderOptions ?? (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.ValidateScopes = isDevelopment;
                            $i1.ValidateOnBuild = isDevelopment;
                            return $i1;
                        })();
                        return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$1(this.Services, options);
                    }, {
  "r": 327718,
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771835505)
            
            //--TRIMMABLE-BOUNDARY-START(137440985201)
            static /*void */ InitializeRoutingAppContextSwitch(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440985201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let assemblyMetadataAttributes = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$12($.$$.System.Reflection.AssemblyMetadataAttribute, assembly);
                var $en2 = assemblyMetadataAttributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var ama = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.Equals$2(ama.Key, "Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", 4/*StringComparison.Ordinal*/))
                        {
                            if ($.$$.System.String.op_Inequality(ama.Value, null) && $.$$.System.String.Equals$2(ama.Value, "true", 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                $.$$.System.AppContext.SetSwitch("Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", true);
                            }
                            return;
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440985201)
            
            //--TRIMMABLE-BOUNDARY-START(133146017905)
            /*void */ InitializeRegisteredRootComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146017905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let componentsCount = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount();
                if (componentsCount === 0)
                {
                    return;
                }
                /*var*/ let registeredComponents = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), null, [componentsCount], null);
                for(/*var*/ let i = 0; i < componentsCount; i++)
                {
                    /*var*/ let assembly = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly(i);
                    /*var*/ let typeName = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName(i);
                    /*var*/ let serializedParameterDefinitions = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions(i);
                    /*var*/ let serializedParameterValues = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues(i);
                    $.$$.System.Array.$WriteT1.call(registeredComponents, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.Create("webassembly"/*ComponentMarker.WebAssemblyMarkerType*/, false, null), i);
                    $.$$.System.Array.$ReadT1.call(registeredComponents, i).WriteWebAssemblyData(assembly, typeName, serializedParameterDefinitions, serializedParameterValues);
                    $.$$.System.Array.$ReadT1.call(registeredComponents, i).PrerenderId = $.$$.System.Int32.ToString$1.call(i, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                }
                this._rootComponentCache = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
                /*var*/ let componentDeserializer = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.Instance;
                let $i1 = 0;
                let $arr1 = registeredComponents;
                while ($i1 < $arr1.length)
                {
                    let registeredComponent = $arr1[$i1++];
                    /*var*/ let componentType = this._rootComponentCache.GetRootType(registeredComponent.Assembly, registeredComponent.TypeName);
                    if (componentType === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`Root component type '${registeredComponent.TypeName}' could not be found in the assembly '${registeredComponent.Assembly}'. ` + `This is likely a result of trimming (tree shaking).`);
                    }
                    /*var*/ let definitions = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(registeredComponent.ParameterDefinitions);
                    /*var*/ let values = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterValues(registeredComponent.ParameterValues);
                    /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                    this.RootComponents.Add$1(componentType, registeredComponent.PrerenderId, parameters);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146017905)
            
            //--TRIMMABLE-BOUNDARY-START(128851050609)
            /*void */ InitializePersistedState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851050609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._persistedState = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState();
            }
            //--TRIMMABLE-BOUNDARY-END(128851050609)
            
            //--TRIMMABLE-BOUNDARY-START(124556083313)
            /*void */ InitializeNavigationManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556083313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let baseUri = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri();
                /*var*/ let uri = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager().$ctor$2(baseUri, uri);
            }
            //--TRIMMABLE-BOUNDARY-END(124556083313)
            
            //--TRIMMABLE-BOUNDARY-START(120261116017)
            /*WebAssemblyHostEnvironment */ InitializeEnvironment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261116017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let applicationEnvironment = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment();
                /*var*/ let hostEnvironment = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironment().$ctor$1(applicationEnvironment, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.BaseUri);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, this.Services, hostEnvironment);
                /*var*/ let configFiles = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["appsettings.json", `appsettings.${applicationEnvironment}.json`], null, null);
                let $i1 = 0;
                let $arr1 = configFiles;
                while ($i1 < $arr1.length)
                {
                    let configFile = $arr1[$i1++];
                    if ($.$$.System.IO.File.Exists(configFile))
                    {
                        /*var*/ let appSettingsJson = $.$$.System.IO.File.ReadAllBytes(configFile);
                        $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource, this.Configuration, new ($.$$.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource))().$ctor(this,  (/**/ s) =>
                        {
                            return s.Stream = new $.$$.System.IO.MemoryStream().$ctor$8(appSettingsJson);
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 327777
    }
  ],
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
}));
                    }
                }
                return hostEnvironment;
            }
            //--TRIMMABLE-BOUNDARY-END(120261116017)
            
            //--TRIMMABLE-BOUNDARY-START(141735952497)
            static /*void */ InitializeWebAssemblyRenderer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735952497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.OperatingSystem.IsBrowser())
                {
                    /*var*/ let currentThread = $.$$.System.Threading.Thread.CurrentThread;
                    if (currentThread.IsThreadPoolThread || currentThread.IsBackground)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("WebAssemblyHostBuilder needs to be instantiated in the UI thread.");
                    }
                    if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext === null && $.$$.System.Threading.SynchronizationContext.Current !== null)
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext = $.$$.System.Threading.SynchronizationContext.Current;
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainManagedThreadId = currentThread.ManagedThreadId;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735952497)
            
            //--TRIMMABLE-BOUNDARY-START(55836606577)
            /*WebAssemblyHostConfiguration*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(55836606577)
            
            //--TRIMMABLE-BOUNDARY-START(150325887089)
            /*RootComponentMappingCollection*/ RootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(150325887089)
            
            //--TRIMMABLE-BOUNDARY-START(154620854385)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(154620854385)
            
            //--TRIMMABLE-BOUNDARY-START(111671181425)
            /*IWebAssemblyHostEnvironment*/ HostEnvironment = null;
            //--TRIMMABLE-BOUNDARY-END(111671181425)
            
            //--TRIMMABLE-BOUNDARY-START(146030919793)
            /*ILoggingBuilder*/ Logging = null;
            //--TRIMMABLE-BOUNDARY-END(146030919793)
            
            //--TRIMMABLE-BOUNDARY-START(60131573873)
            /*void */ ConfigureContainer(TBuilder, /*IServiceProviderFactory<TBuilder>*/ factory, /*Action<TBuilder>?*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131573873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                this._createServiceProvider = new ($.$$.System.Func$$($.$scm.System.IServiceProvider))().$ctor(this,  () =>
                {
                    /*var*/ let container = factory.Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder(this.Services, [TBuilder]);
                    configure?.Invoke(container);
                    return factory.Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider(container, [TBuilder]);
                }, {
  "r": 327718,
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(60131573873)
            
            //--TRIMMABLE-BOUNDARY-START(158915821681)
            /*WebAssemblyHostBuilder */ UseServiceProviderOptions(/*ServiceProviderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915821681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceProviderOptions = $.$firstOf(options, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("options") });
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(158915821681)
            
            //--TRIMMABLE-BOUNDARY-START(51541639281)
            /*WebAssemblyHost */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541639281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meca.Microsoft.Extensions.Configuration.IConfiguration, this.Services, this.Configuration);
                /*var*/ let services = this._createServiceProvider.Invoke();
                /*var*/ let scope = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.CreateAsyncScope($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory, services));
                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost().$ctor$1(this, services, scope, this._persistedState);
            }
            //--TRIMMABLE-BOUNDARY-END(51541639281)
            
            //--TRIMMABLE-BOUNDARY-START(115966148721)
            /*void */ InitializeDefaultServices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966148721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mj.Microsoft.JSInterop.IJSRuntime, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.Microsoft.AspNetCore.Components.NavigationManager, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.Microsoft.AspNetCore.Components.Routing.INavigationInterception, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mac.Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods, this.Services, this._jsMethods);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader, this.Services, new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$6($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache, this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache))().$ctor(this,  (/**/ _0) =>
                {
                    return this._rootComponentCache ?? new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
                }, {
  "r": 1179761,
  "p": [
    {
      "n": "_",
      "p": 327718
    }
  ],
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$6($.$mac.Microsoft.AspNetCore.Components.PersistentComponentState, this.Services, new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$mac.Microsoft.AspNetCore.Components.PersistentComponentState))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, sp).State;
                }, {
  "r": 6160492,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
}));
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.PersistentStateProviderServiceCollectionExtensions.AddSupplyValueFromPersistentComponentStateProvider(this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$5($.$macw.Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyErrorBoundaryLogger, this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services);
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services, $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging(this.Services, new ($.$$.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                    $.$mel.Microsoft.Extensions.Logging.LoggingBuilderExtensions.AddProvider(builder, new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLoggerProvider().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance));
                }, {
  "r": 65537,
  "p": [
    {
      "n": "builder",
      "p": 1179736
    }
  ],
  "n": "",
  "d": 2031729,
  "h": 0,
  "f": 17825794
}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$5($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider, $.$macwa.Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider, this.Services);
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider, this.Services, $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                $.$mac.Microsoft.AspNetCore.Components.SupplyParameterFromQueryProviderServiceCollectionExtensions.AddSupplyValueFromQueryProvider(this.Services);
            }
            //--TRIMMABLE-BOUNDARY-END(115966148721)
            
            static $h = 2031729;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836606577),
    {
      "p": 2162801,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016475761,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 2031729,
      "h": 55836606577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836606577),
//--TRIMMABLE-BOUNDARY-START(150325887089),
    {
      "p": 1704049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786279537,
        "f": 50331649
      },
      "n": "RootComponents",
      "d": 2031729,
      "h": 150325887089,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325887089),
//--TRIMMABLE-BOUNDARY-START(154620854385),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376214129,
        "f": 50331649
      },
      "n": "Services",
      "d": 2031729,
      "h": 154620854385,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620854385),
//--TRIMMABLE-BOUNDARY-START(111671181425),
    {
      "p": 1441905,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606410353,
        "f": 50331649
      },
      "n": "HostEnvironment",
      "d": 2031729,
      "h": 111671181425,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111671181425),
//--TRIMMABLE-BOUNDARY-START(146030919793),
    {
      "p": 1179736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196344945,
        "f": 50331649
      },
      "n": "Logging",
      "d": 2031729,
      "h": 146030919793,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030919793)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426541169),
    {
      "r": 2031729,
      "p": [
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 65
        }
      ],
      "n": "CreateDefault",
      "d": 2031729,
      "h": 64426541169,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426541169),
//--TRIMMABLE-BOUNDARY-START(137440985201),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 106168321
        }
      ],
      "n": "InitializeRoutingAppContextSwitch",
      "d": 2031729,
      "h": 137440985201,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137440985201),
//--TRIMMABLE-BOUNDARY-START(133146017905),
    {
      "r": 65537,
      "n": "InitializeRegisteredRootComponents",
      "d": 2031729,
      "h": 133146017905,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146017905),
//--TRIMMABLE-BOUNDARY-START(128851050609),
    {
      "r": 65537,
      "n": "InitializePersistedState",
      "d": 2031729,
      "h": 128851050609,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851050609),
//--TRIMMABLE-BOUNDARY-START(124556083313),
    {
      "r": 65537,
      "n": "InitializeNavigationManager",
      "d": 2031729,
      "h": 124556083313,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124556083313),
//--TRIMMABLE-BOUNDARY-START(120261116017),
    {
      "r": 2228337,
      "n": "InitializeEnvironment",
      "d": 2031729,
      "h": 120261116017,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120261116017),
//--TRIMMABLE-BOUNDARY-START(141735952497),
    {
      "r": 65537,
      "n": "InitializeWebAssemblyRenderer",
      "d": 2031729,
      "h": 141735952497,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141735952497),
//--TRIMMABLE-BOUNDARY-START(60131573873),
    {
      "r": 65537,
      "p": [
        {
          "n": "factory",
          "p": (TBuilder) => $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$(TBuilder).$h
        },
        {
          "n": "configure",
          "p": (TBuilder) => $.$$.System.Action$$(TBuilder).$h,
          "f": 65
        }
      ],
      "g": [
        "TBuilder"
      ],
      "n": "ConfigureContainer",
      "d": 2031729,
      "h": 60131573873,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60131573873),
//--TRIMMABLE-BOUNDARY-START(158915821681),
    {
      "r": 2031729,
      "p": [
        {
          "n": "options",
          "p": 3276893
        }
      ],
      "n": "UseServiceProviderOptions",
      "d": 2031729,
      "h": 158915821681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158915821681),
//--TRIMMABLE-BOUNDARY-START(51541639281),
    {
      "r": 1966193,
      "n": "Build",
      "d": 2031729,
      "h": 51541639281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541639281),
//--TRIMMABLE-BOUNDARY-START(115966148721),
    {
      "r": 65537,
      "n": "InitializeDefaultServices",
      "d": 2031729,
      "h": 115966148721,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115966148721)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591966321),
    {
      "t": 3342449,
      "n": "_jsMethods",
      "d": 2031729,
      "h": 8591966321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966321),
//--TRIMMABLE-BOUNDARY-START(4296999025),
    {
      "t": $.$$.System.Func$$($.$scm.System.IServiceProvider).$h,
      "n": "_createServiceProvider",
      "d": 2031729,
      "h": 4296999025,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296999025),
//--TRIMMABLE-BOUNDARY-START(17181900913),
    {
      "t": 1179761,
      "n": "_rootComponentCache",
      "d": 2031729,
      "h": 17181900913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181900913),
//--TRIMMABLE-BOUNDARY-START(12886933617),
    {
      "t": 1310721,
      "n": "_persistedState",
      "d": 2031729,
      "h": 12886933617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933617),
//--TRIMMABLE-BOUNDARY-START(21476868209),
    {
      "t": 3276893,
      "n": "_serviceProviderOptions",
      "d": 2031729,
      "h": 21476868209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476868209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771835505),
    {
      "p": [
        {
          "n": "jsMethods",
          "p": 3342449
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031729,
      "h": 25771835505,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25771835505)
  ],
  "h": 2031729
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebAssemblyHostBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031729)
        
        
        //--TRIMMABLE-BOUNDARY-START(3407985)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods", ($self) => class InternalJSImportMethods extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34363146353)
            static /*string */ GetApplicationEnvironmentCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363146353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let env = window.localStorage.getItem("__environment__");
                if (!(env === null))
                {
                    return env;
                }
                if (window.location.hostname === "localhost")
                {
                    return "Development";
                }
                return "Production";
            }
            //--TRIMMABLE-BOUNDARY-END(34363146353)
            
            //--TRIMMABLE-BOUNDARY-START(55837982833)
            /*InternalJSImportMethods*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(55837982833)
            
            //--TRIMMABLE-BOUNDARY-START(8593342577)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593342577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593342577)
            
            //--TRIMMABLE-BOUNDARY-START(47248048241)
            /*string */ GetPersistedState()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47248048241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.getPersistedState();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248048241)
            
            //--TRIMMABLE-BOUNDARY-START(38658113649)
            static /*Task<RootComponentOperationBatch> *//*async*/  GetInitialComponentUpdate()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch), $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658113649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let components = await Blazor._internal.getInitialComponentsUpdate();
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeOperations(components);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(38658113649)
            
            //--TRIMMABLE-BOUNDARY-START(30068179057)
            /*string */ GetApplicationEnvironment()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068179057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.GetApplicationEnvironmentCore();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068179057)
            
            //--TRIMMABLE-BOUNDARY-START(12888309873)
            /*void */ AttachRootComponentToElement(/*string*/ domElementSelector, /*int*/ componentId, /*int*/ rendererId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888309873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.attachRootComponentToElement(domElementSelector, componentId, rendererId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888309873)
            
            //--TRIMMABLE-BOUNDARY-START(21478244465)
            /*void */ EndUpdateRootComponents(/*long*/ batchId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478244465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.endUpdateRootComponents(batchId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478244465)
            
            //--TRIMMABLE-BOUNDARY-START(60132950129)
            /*void */ NavigationManager_EnableNavigationInterception(/*int*/ rendererId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132950129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.enableNavigationInterception(rendererId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132950129)
            
            //--TRIMMABLE-BOUNDARY-START(85902753905)
            /*void */ NavigationManager_ScrollToElement(/*string*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85902753905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.scrollToElement(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902753905)
            
            //--TRIMMABLE-BOUNDARY-START(77312819313)
            /*string */ NavigationManager_GetLocationHref()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77312819313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.getLocationHref();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77312819313)
            
            //--TRIMMABLE-BOUNDARY-START(68722884721)
            /*string */ NavigationManager_GetBaseUri()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722884721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.getBaseURI();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722884721)
            
            //--TRIMMABLE-BOUNDARY-START(94492688497)
            /*void */ NavigationManager_SetHasLocationChangingListeners(/*int*/ rendererId, /*bool*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94492688497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.navigationManager.setHasLocationChangingListeners(rendererId, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94492688497)
            
            //--TRIMMABLE-BOUNDARY-START(128852426865)
            /*int */ RegisteredComponents_GetRegisteredComponentsCount()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128852426865);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128852426865)
            
            //--TRIMMABLE-BOUNDARY-START(103082623089)
            /*string */ RegisteredComponents_GetAssembly(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082623089);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getAssembly(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103082623089)
            
            //--TRIMMABLE-BOUNDARY-START(137442361457)
            /*string */ RegisteredComponents_GetTypeName(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137442361457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getTypeName(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137442361457)
            
            //--TRIMMABLE-BOUNDARY-START(111672557681)
            /*string */ RegisteredComponents_GetParameterDefinitions(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672557681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getParameterDefinitions(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111672557681)
            
            //--TRIMMABLE-BOUNDARY-START(120262492273)
            /*string */ RegisteredComponents_GetParameterValues(/*int*/ id)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120262492273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Blazor._internal.registeredComponents.getParameterValues(id);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120262492273)
            
            //--TRIMMABLE-BOUNDARY-START(17183211633)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetPersistedState()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183211633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPersistedState(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17183211633)
            
            //--TRIMMABLE-BOUNDARY-START(12888244337)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetApplicationEnvironment()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888244337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetApplicationEnvironment(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12888244337)
            
            //--TRIMMABLE-BOUNDARY-START(4298309745)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.AttachRootComponentToElement(string, int, int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298309745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AttachRootComponentToElement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4298309745)
            
            //--TRIMMABLE-BOUNDARY-START(8593277041)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.EndUpdateRootComponents(long)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593277041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EndUpdateRootComponents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8593277041)
            
            //--TRIMMABLE-BOUNDARY-START(21478178929)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_EnableNavigationInterception(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478178929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_EnableNavigationInterception(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21478178929)
            
            //--TRIMMABLE-BOUNDARY-START(34363080817)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_ScrollToElement(string)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_ScrollToElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363080817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_ScrollToElement(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34363080817)
            
            //--TRIMMABLE-BOUNDARY-START(30068113521)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetLocationHref()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068113521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_GetLocationHref(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30068113521)
            
            //--TRIMMABLE-BOUNDARY-START(25773146225)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetBaseUri()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773146225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_GetBaseUri(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25773146225)
            
            //--TRIMMABLE-BOUNDARY-START(38658048113)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_SetHasLocationChangingListeners(int, bool)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658048113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.NavigationManager_SetHasLocationChangingListeners(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38658048113)
            
            //--TRIMMABLE-BOUNDARY-START(55837917297)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetRegisteredComponentsCount()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837917297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetRegisteredComponentsCount(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(55837917297)
            
            //--TRIMMABLE-BOUNDARY-START(42953015409)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetAssembly(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953015409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetAssembly(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(42953015409)
            
            //--TRIMMABLE-BOUNDARY-START(60132884593)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetTypeName(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132884593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetTypeName(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60132884593)
            
            //--TRIMMABLE-BOUNDARY-START(47247982705)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterDefinitions(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247982705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetParameterDefinitions(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47247982705)
            
            //--TRIMMABLE-BOUNDARY-START(51542950001)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterValues(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542950001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisteredComponents_GetParameterValues(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51542950001)
            
            //--TRIMMABLE-BOUNDARY-START(4298375281)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(55837982833)
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(55837982833)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298375281)
            
            static $h = 3407985;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47248048241),
    {
      "r": 1310721,
      "n": "GetPersistedState",
      "d": 3407985,
      "h": 47248048241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47248048241),
//--TRIMMABLE-BOUNDARY-START(38658113649),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,
      "n": "GetInitialComponentUpdate",
      "d": 3407985,
      "h": 38658113649,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(38658113649),
//--TRIMMABLE-BOUNDARY-START(30068179057),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironment",
      "d": 3407985,
      "h": 30068179057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068179057),
//--TRIMMABLE-BOUNDARY-START(12888309873),
    {
      "r": 65537,
      "p": [
        {
          "n": "domElementSelector",
          "p": 1310721
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "AttachRootComponentToElement",
      "d": 3407985,
      "h": 12888309873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888309873),
//--TRIMMABLE-BOUNDARY-START(21478244465),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "EndUpdateRootComponents",
      "d": 3407985,
      "h": 21478244465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478244465),
//--TRIMMABLE-BOUNDARY-START(60132950129),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        }
      ],
      "n": "NavigationManager_EnableNavigationInterception",
      "d": 3407985,
      "h": 60132950129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132950129),
//--TRIMMABLE-BOUNDARY-START(85902753905),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 1310721
        }
      ],
      "n": "NavigationManager_ScrollToElement",
      "d": 3407985,
      "h": 85902753905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902753905),
//--TRIMMABLE-BOUNDARY-START(77312819313),
    {
      "r": 1310721,
      "n": "NavigationManager_GetLocationHref",
      "d": 3407985,
      "h": 77312819313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77312819313),
//--TRIMMABLE-BOUNDARY-START(68722884721),
    {
      "r": 1310721,
      "n": "NavigationManager_GetBaseUri",
      "d": 3407985,
      "h": 68722884721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722884721),
//--TRIMMABLE-BOUNDARY-START(94492688497),
    {
      "r": 65537,
      "p": [
        {
          "n": "rendererId",
          "p": 655361
        },
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "NavigationManager_SetHasLocationChangingListeners",
      "d": 3407985,
      "h": 94492688497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492688497),
//--TRIMMABLE-BOUNDARY-START(128852426865),
    {
      "r": 655361,
      "n": "RegisteredComponents_GetRegisteredComponentsCount",
      "d": 3407985,
      "h": 128852426865,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128852426865),
//--TRIMMABLE-BOUNDARY-START(103082623089),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetAssembly",
      "d": 3407985,
      "h": 103082623089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103082623089),
//--TRIMMABLE-BOUNDARY-START(137442361457),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetTypeName",
      "d": 3407985,
      "h": 137442361457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137442361457),
//--TRIMMABLE-BOUNDARY-START(111672557681),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterDefinitions",
      "d": 3407985,
      "h": 111672557681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111672557681),
//--TRIMMABLE-BOUNDARY-START(120262492273),
    {
      "r": 1310721,
      "p": [
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "RegisteredComponents_GetParameterValues",
      "d": 3407985,
      "h": 120262492273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120262492273),
//--TRIMMABLE-BOUNDARY-START(34363146353),
    {
      "r": 1310721,
      "n": "GetApplicationEnvironmentCore",
      "d": 3407985,
      "h": 34363146353,
      "f": 16777250,
      "a": [
        {
          "t": 1179659,
          "c": 8591114251,
          "a": [
            {
              "v": "Blazor._internal.getApplicationEnvironment",
              "t": 1310721
            },
            {
              "v": "blazor-internal",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34363146353)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55837982833),
    {
      "t": 3407985,
      "n": "Instance",
      "d": 3407985,
      "h": 55837982833,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55837982833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593342577),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3407985,
      "h": 8593342577,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8593342577)
  ],
  "i": [3342449
  ],
  "h": 3407985
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods ]; }
            static get $fullName() { return `InternalJSImportMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407985)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507441)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.LoggingBuilder", ($self) => class LoggingBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474737)
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474737);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Services = services;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474737)
            
            //--TRIMMABLE-BOUNDARY-START(21476343921)
            /*IServiceCollection*/ Services = null;
            //--TRIMMABLE-BOUNDARY-END(21476343921)
            
            //--TRIMMABLE-BOUNDARY-START(8591114328)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get Microsoft$Extensions$Logging$ILoggingBuilder$Services()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Services;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114328)
            
            static $h = 1507441;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476343921),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181376625,
        "f": 50331649
      },
      "n": "Services",
      "d": 1507441,
      "h": 21476343921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476343921)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474737),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507441,
      "h": 4296474737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296474737)
  ],
  "i": [1179736
  ],
  "h": 1507441
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggingBuilder ]; }
            static get $fullName() { return `LoggingBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507441)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179761)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootTypeCache", ($self) => class RootTypeCache extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296147057)
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            //--TRIMMABLE-BOUNDARY-END(4296147057)
            
            //--TRIMMABLE-BOUNDARY-START(8591114353)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$$.System.Action().$ctor(this, this.ClearCache));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114353)
            
            //--TRIMMABLE-BOUNDARY-START(12886081649)
            /*void */ ClearCache()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._typeToKeyLookUp.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886081649)
            
            //--TRIMMABLE-BOUNDARY-START(17181048945)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.remove_OnDeltaApplied(new $.$$.System.Action().$ctor(this, this.ClearCache));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181048945)
            
            //--TRIMMABLE-BOUNDARY-START(21476016241)
            /*Type? */ GetRootType(/*string*/ assembly, /*string*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let key = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key().$ctor$3(assembly, type);
                /*var*/ let resolvedType;
                if (this._typeToKeyLookUp.TryGetValue(key, $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$$.System.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$2($.$typeArray($.$$.System.Reflection.Assembly), key, new ($.$$.System.Func$$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$typeArray($.$$.System.Reflection.Assembly), $.$$.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.ResolveType), $.$$.System.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476016241)
            
            //--TRIMMABLE-BOUNDARY-START(30065950833)
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$$.System.Array.$ReadT1.call(assemblies, i);
                    if ($.$$.System.String.op_Equality(current.GetName().Name, key.Assembly))
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$$.System.Reflection.Assembly.op_Equality(assembly, null))
                {
                    if ($.$$.System.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$$.System.Reflection.Assembly.Load$4(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$1(key.Type, false, false) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950833)
            
            //--TRIMMABLE-BOUNDARY-START(1245297)
            static $_Key;
            static get Key()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache;
                return $cls.$_Key ??= $asm.$nstr("$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key", ($self) => class Key extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4296212593)
                    $ctor$3(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296212593);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$tupleUnpack(($tp) =>
                            {
                                this.Assembly = $tp.Item1;
                                this.Type = $tp.Item2;
                            }).$v = { Item1: assembly, Item2: type };
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296212593)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476081777)
                    /*string*/ Assembly = null;
                    //--TRIMMABLE-BOUNDARY-END(21476081777)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835820145)
                    /*string*/ Type = null;
                    //--TRIMMABLE-BOUNDARY-END(55835820145)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25771049073, 34359869441)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771049073);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, { set $v(v){ key = v; } }) && this.Equals$2(key);
                        }
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25771049073, 34359869441)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066016369)
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066016369);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.String.Equals$2(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$$.System.String.Equals$2(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066016369)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 51540852849, 184683724801)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51540852849);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.Assembly, this.Type);
                        }
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 51540852849, 184683724801)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385210369)
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.RootTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.RootTypeCache.Key)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385210369);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385210369)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 1245297;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081777),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655950961,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 1245297,
      "h": 21476081777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476081777),
//--TRIMMABLE-BOUNDARY-START(55835820145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245885553,
        "f": 50331649
      },
      "n": "Type",
      "d": 1245297,
      "h": 55835820145,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835820145)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25771049073, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1245297,
      "h": 25771049073,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771049073, 34359869441),
//--TRIMMABLE-BOUNDARY-START(30066016369),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1245297
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1245297,
      "h": 30066016369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066016369),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540852849, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1245297,
      "h": 51540852849,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540852849, 184683724801)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212593),
    {
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245297,
      "h": 4296212593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212593),
//--TRIMMABLE-BOUNDARY-START(8591179889),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245297,
      "h": 8591179889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179889)
  ],
  "i": [$.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key).$h
  ],
  "d": 1179761,
  "h": 1245297
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key) ]; }
                    static get $fullName() { return `RootTypeCache.Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1245297)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296147057)
                this._typeToKeyLookUp = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$$.System.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296147057)
                
            }
            static $h = 1179761;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886081649),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 1179761,
      "h": 12886081649,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886081649),
//--TRIMMABLE-BOUNDARY-START(17181048945),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1179761,
      "h": 17181048945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048945),
//--TRIMMABLE-BOUNDARY-START(21476016241),
    {
      "r": 187629569,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 1310721
        }
      ],
      "n": "GetRootType",
      "d": 1179761,
      "h": 21476016241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016241),
//--TRIMMABLE-BOUNDARY-START(30065950833),
    {
      "r": 187629569,
      "p": [
        {
          "n": "key",
          "p": 1245297
        },
        {
          "n": "assemblies",
          "p": $.$typeArray($.$$.System.Reflection.Assembly).$h
        }
      ],
      "n": "ResolveType",
      "d": 1179761,
      "h": 30065950833,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065950833)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147057),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$$.System.Type).$h,
      "n": "_typeToKeyLookUp",
      "d": 1179761,
      "h": 4296147057,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114353),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179761,
      "h": 8591114353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114353)
  ],
  "i": [90177537
  ],
  "j": [1245297
  ],
  "h": 1179761
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `RootTypeCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179761)
        
        
        //--TRIMMABLE-BOUNDARY-START(3801201)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyErrorBoundaryLogger", ($self) => class WebAssemblyErrorBoundaryLogger extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298768497)
            /*ILogger<ErrorBoundary>*/ _errorBoundaryLogger = null;
            //--TRIMMABLE-BOUNDARY-END(4298768497)
            
            //--TRIMMABLE-BOUNDARY-START(8593735793)
            $ctor$1(/*ILogger<ErrorBoundary>*/ errorBoundaryLogger)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593735793);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._errorBoundaryLogger = $.$firstOf(errorBoundaryLogger, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("errorBoundaryLogger") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593735793)
            
            //--TRIMMABLE-BOUNDARY-START(12888703089)
            /*ValueTask */ LogErrorAsync(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888703089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.LogError(this._errorBoundaryLogger, exception, $.$$.System.Exception.ToString.call(exception), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                return $.$$.System.Threading.Tasks.ValueTask.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888703089)
            
            //--TRIMMABLE-BOUNDARY-START(4300734574)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger.LogErrorAsync(System.Exception)
            Microsoft$AspNetCore$Components$Web$IErrorBoundaryLogger$LogErrorAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300734574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LogErrorAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4300734574)
            
            static $h = 3801201;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888703089),
    {
      "r": 180420609,
      "p": [
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "LogErrorAsync",
      "d": 3801201,
      "h": 12888703089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888703089)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298768497),
    {
      "t": $.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorBoundary).$h,
      "n": "_errorBoundaryLogger",
      "d": 3801201,
      "h": 4298768497,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298768497)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593735793),
    {
      "p": [
        {
          "n": "errorBoundaryLogger",
          "p": $.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorBoundary).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3801201,
      "h": 8593735793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593735793)
  ],
  "i": [5767278
  ],
  "h": 3801201
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macw.Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger ]; }
            static get $fullName() { return `WebAssemblyErrorBoundaryLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3801201)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228337)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironment", ($self) => class WebAssemblyHostEnvironment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297195633)
            $ctor$1(/*string*/ environment, /*string*/ baseAddress)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297195633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Environment = environment;
                    this.BaseAddress = baseAddress;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297195633)
            
            //--TRIMMABLE-BOUNDARY-START(21477064817)
            /*string*/ Environment = null;
            //--TRIMMABLE-BOUNDARY-END(21477064817)
            
            //--TRIMMABLE-BOUNDARY-START(17182097521)
            /*string*/ BaseAddress = null;
            //--TRIMMABLE-BOUNDARY-END(17182097521)
            
            //--TRIMMABLE-BOUNDARY-START(25771245681)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.Environment.get
            get Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591376497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Environment;
            }
            //--TRIMMABLE-BOUNDARY-END(25771245681)
            
            //--TRIMMABLE-BOUNDARY-START(17181311089)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.BaseAddress.get
            get Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BaseAddress;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311089)
            
            static $h = 2228337;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477064817),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656934001,
        "f": 50331649
      },
      "n": "Environment",
      "d": 2228337,
      "h": 21477064817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477064817),
//--TRIMMABLE-BOUNDARY-START(17182097521),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066999409,
        "f": 50331649
      },
      "n": "BaseAddress",
      "d": 2228337,
      "h": 17182097521,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182097521)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195633),
    {
      "p": [
        {
          "n": "environment",
          "p": 1310721
        },
        {
          "n": "baseAddress",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228337,
      "h": 4297195633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195633)
  ],
  "i": [1441905
  ],
  "h": 2228337
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment ]; }
            static get $fullName() { return `WebAssemblyHostEnvironment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228337)
        
        
        //--TRIMMABLE-BOUNDARY-START(3866737)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception", ($self) => class WebAssemblyNavigationInterception extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183735921)
            /*WebAssemblyNavigationInterception*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17183735921)
            
            //--TRIMMABLE-BOUNDARY-START(12888768625)
            /*Task */ EnableNavigationInterceptionAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888768625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_EnableNavigationInterception(2/*WebRendererId.WebAssembly*/);
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(12888768625)
            
            //--TRIMMABLE-BOUNDARY-START(4305322092)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.INavigationInterception.EnableNavigationInterceptionAsync()
            Microsoft$AspNetCore$Components$Routing$INavigationInterception$EnableNavigationInterceptionAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4305322092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.EnableNavigationInterceptionAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4305322092)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4298834033)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17183735921)
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17183735921)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298834033)
            
            static $h = 3866737;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888768625),
    {
      "r": 177537025,
      "n": "EnableNavigationInterceptionAsync",
      "d": 3866737,
      "h": 12888768625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888768625)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183735921),
    {
      "t": 3866737,
      "n": "Instance",
      "d": 3866737,
      "h": 17183735921,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183735921)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593801329),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3866737,
      "h": 8593801329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593801329)
  ],
  "i": [10354796
  ],
  "h": 3866737
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.Routing.INavigationInterception ]; }
            static get $fullName() { return `WebAssemblyNavigationInterception`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3866737)
        
        
        //--TRIMMABLE-BOUNDARY-START(721009)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore", ($self) => class PrerenderComponentApplicationStore extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688305)
            /*bool*/ _stateIsPersisted = false;
            //--TRIMMABLE-BOUNDARY-END(4295688305)
            
            //--TRIMMABLE-BOUNDARY-START(8590655601)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ExistingState = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655601)
            
            //--TRIMMABLE-BOUNDARY-START(12885622897)
            $ctor$2(/*string*/ existingState)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(existingState, "existingState");
                    this.DeserializeState($.$$.System.Convert.FromBase64String(existingState));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622897)
            
            //--TRIMMABLE-BOUNDARY-START(25770524785)
            /*void */ DeserializeState(/*byte[]*/ existingState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state = $.$firstOf($.$stj.System.Text.Json.JsonSerializer.Deserialize$27($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)), $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(existingState), $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.Default.DictionaryStringByteArray), () => { throw new $.$$.System.ArgumentException().$ctor$13("Could not deserialize state correctly", "existingState") });
                this.ExistingState = state;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524785)
            
            //--TRIMMABLE-BOUNDARY-START(55835295857)
            /*string?*/ PersistedState = null;
            //--TRIMMABLE-BOUNDARY-END(55835295857)
            
            //--TRIMMABLE-BOUNDARY-START(30065492081)
            /*Dictionary<string, byte[]>*/ ExistingState = null;
            //--TRIMMABLE-BOUNDARY-END(30065492081)
            
            //--TRIMMABLE-BOUNDARY-START(51540328561)
            /*Task<IDictionary<string, byte[]>> */ GetPersistedStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)), this.ExistingState);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328561)
            
            //--TRIMMABLE-BOUNDARY-START(64425230449)
            /*byte[] */ SerializeState(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$stj.System.Text.Json.JsonSerializer.SerializeToUtf8Bytes$3($.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)), state, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230449)
            
            //--TRIMMABLE-BOUNDARY-START(60130263153)
            /*Task */ PersistStateAsync(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._stateIsPersisted)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("State already persisted.");
                }
                this._stateIsPersisted = true;
                if (!(state === null) && state.System$Collections$Generic$IReadOnlyCollection$$$Count > 0)
                {
                    this.PersistedState = $.$$.System.Convert.ToBase64String$3(this.SerializeState(state));
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263153)
            
            //--TRIMMABLE-BOUNDARY-START(85900066929)
            /*bool */ SupportsRenderMode(/*IComponentRenderMode*/ renderMode)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900066929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return renderMode === null || $.$is(renderMode, $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode) || $.$is(renderMode, $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900066929)
            
            //--TRIMMABLE-BOUNDARY-START(4299358316)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.GetPersistedStateAsync()
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$GetPersistedStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4299358316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPersistedStateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4299358316)
            
            //--TRIMMABLE-BOUNDARY-START(8594325612)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.PersistStateAsync(System.Collections.Generic.IReadOnlyDictionary<string, byte[]>)
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$PersistStateAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8594325612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PersistStateAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8594325612)
            
            //--TRIMMABLE-BOUNDARY-START(12889292908)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.SupportsRenderMode(Microsoft.AspNetCore.Components.IComponentRenderMode)
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$SupportsRenderMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12889292908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SupportsRenderMode(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12889292908)
            
            static $h = 721009;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835295857),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605099633,
        "f": 83886082
      },
      "n": "PersistedState",
      "d": 721009,
      "h": 55835295857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835295857),
//--TRIMMABLE-BOUNDARY-START(30065492081),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426673,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015165041,
        "f": 83886084
      },
      "n": "ExistingState",
      "d": 721009,
      "h": 30065492081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065492081)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770524785),
    {
      "r": 65537,
      "p": [
        {
          "n": "existingState",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "DeserializeState",
      "d": 721009,
      "h": 25770524785,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(25770524785),
//--TRIMMABLE-BOUNDARY-START(51540328561),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))).$h,
      "n": "GetPersistedStateAsync",
      "d": 721009,
      "h": 51540328561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328561),
//--TRIMMABLE-BOUNDARY-START(64425230449),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "state",
          "p": $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h
        }
      ],
      "n": "SerializeState",
      "d": 721009,
      "h": 64425230449,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64425230449),
//--TRIMMABLE-BOUNDARY-START(60130263153),
    {
      "r": 177537025,
      "p": [
        {
          "n": "state",
          "p": $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h
        }
      ],
      "n": "PersistStateAsync",
      "d": 721009,
      "h": 60130263153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263153),
//--TRIMMABLE-BOUNDARY-START(85900066929),
    {
      "r": 262145,
      "p": [
        {
          "n": "renderMode",
          "p": 2883692
        }
      ],
      "n": "SupportsRenderMode",
      "d": 721009,
      "h": 85900066929,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900066929)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688305),
    {
      "t": 262145,
      "n": "_stateIsPersisted",
      "d": 721009,
      "h": 4295688305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688305)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590655601),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721009,
      "h": 8590655601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655601),
//--TRIMMABLE-BOUNDARY-START(12885622897),
    {
      "p": [
        {
          "n": "existingState",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721009,
      "h": 12885622897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622897)
  ],
  "i": [4391020
  ],
  "h": 721009
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IPersistentComponentStateStore ]; }
            static get $fullName() { return `PrerenderComponentApplicationStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721009)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966193)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost", ($self) => class WebAssemblyHost extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771769969)
            /*AsyncServiceScope*/ _scope;
            //--TRIMMABLE-BOUNDARY-END(25771769969)
            
            //--TRIMMABLE-BOUNDARY-START(30066737265)
            /*IServiceProvider*/ _services = null;
            //--TRIMMABLE-BOUNDARY-END(30066737265)
            
            //--TRIMMABLE-BOUNDARY-START(4296933489)
            /*IConfiguration*/ _configuration = null;
            //--TRIMMABLE-BOUNDARY-END(4296933489)
            
            //--TRIMMABLE-BOUNDARY-START(21476802673)
            /*RootComponentMappingCollection*/ _rootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(21476802673)
            
            //--TRIMMABLE-BOUNDARY-START(12886868081)
            /*string?*/ _persistedState = null;
            //--TRIMMABLE-BOUNDARY-END(12886868081)
            
            //--TRIMMABLE-BOUNDARY-START(8591900785)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8591900785)
            
            //--TRIMMABLE-BOUNDARY-START(34361704561)
            /*bool*/ _started = false;
            //--TRIMMABLE-BOUNDARY-END(34361704561)
            
            //--TRIMMABLE-BOUNDARY-START(17181835377)
            /*WebAssemblyRenderer?*/ _renderer = null;
            //--TRIMMABLE-BOUNDARY-END(17181835377)
            
            //--TRIMMABLE-BOUNDARY-START(38656671857)
            $ctor$1(/*WebAssemblyHostBuilder*/ builder, /*IServiceProvider*/ services, /*AsyncServiceScope*/ scope, /*string?*/ persistedState)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656671857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.GC.KeepAlive($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.JSInteropMethods.$type);
                    this._services = services;
                    this._scope = scope;
                    this._configuration = builder.Configuration;
                    this._rootComponents = builder.RootComponents;
                    this._persistedState = persistedState;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656671857)
            
            //--TRIMMABLE-BOUNDARY-START(47246606449)
            /*IConfiguration */ get Configuration()
            {
                return this._configuration;
            }
            //--TRIMMABLE-BOUNDARY-END(47246606449)
            
            //--TRIMMABLE-BOUNDARY-START(81606344817)
            /*IServiceProvider */ get Services()
            {
                return this._scope.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(81606344817)
            
            //--TRIMMABLE-BOUNDARY-START(51541573745)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541573745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._disposed)
                    {
                        return;
                    }
                    this._disposed = true;
                    if (this._renderer !== null)
                    {
                        await this._renderer.DisposeAsync();
                    }
                    await this._scope.DisposeAsync();
                    let asyncDisposableServices;
                    let disposableServices;
                    if ($.$is(this._services, $.$$.System.IAsyncDisposable, { set $v(v){ asyncDisposableServices = v; } }))
                    {
                        await asyncDisposableServices.System$IAsyncDisposable$DisposeAsync();
                    }
                    else if ($.$is(this._services, $.$$.System.IDisposable, { set $v(v){ disposableServices = v; } }))
                    {
                        disposableServices.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(51541573745)
            
            //--TRIMMABLE-BOUNDARY-START(73016410225)
            /*Task */ RunAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016410225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunAsyncCore($.$$.System.Threading.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(73016410225)
            
            //--TRIMMABLE-BOUNDARY-START(77311377521)
            /*Task *//*async*/  RunAsyncCore(/*CancellationToken*/ cancellationToken, /*WebAssemblyCultureProvider?*/ cultureProvider)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311377521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._started)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("The host has already started.");
                    }
                    this._started = true;
                    cultureProvider ??= $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Instance;
                    cultureProvider.ThrowIfCultureChangeIsUnsupported();
                    await cultureProvider.LoadCurrentCultureResourcesAsync();
                    /*var*/ let manager = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, this.Services);
                    /*var*/ let store = !$.$$.System.String.IsNullOrEmpty(this._persistedState) ? new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$2(this._persistedState) : new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$1();
                    manager.SetPlatformRenderMode($.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                    await manager.RestoreStateAsync(store, $.$mac.Microsoft.AspNetCore.Components.RestoreContext.InitialValue);
                    /*var*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = cancellationToken.Register$1(new $.$$.System.Action().$ctor(this,  () =>
                        {
                            return tcs.TrySetResult();
                        }, {
  "r": 65537,
  "n": "",
  "d": 1966193,
  "h": 0,
  "f": 17825794
}));
                        /*var*/ let loggerFactory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, this.Services);
                        /*var*/ let jsComponentInterop = new $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop().$ctor$1(this._rootComponents.JSComponents);
                        /*var*/ let collectionProvider = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services);
                        /*var*/ let collection = await collectionProvider.GetResourceCollection();
                        this._renderer = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer().$ctor$4(this.Services, collection, loggerFactory, jsComponentInterop);
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.CreateLogger(loggerFactory);
                        /*RootComponentOperationBatch?*/ let initialOperationBatch = null;
                        if ($.$$.System.String.op_Equality($.$$.System.Environment.GetEnvironmentVariable$1("__BLAZOR_WEBASSEMBLY_WAIT_FOR_ROOT_COMPONENTS"), "true"))
                        {
                            initialOperationBatch = await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.GetInitialComponentUpdate();
                        }
                        /*var*/ let initializationTcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$$.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$$.System.Threading.Tasks.TaskCompletionSource), new ($.$$.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$$.System.Threading.Tasks.TaskCompletionSource))().$ctor$3(this._rootComponents, this._renderer, initializationTcs), new ($.$$.System.Action$$($.$$.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$$.System.Threading.Tasks.TaskCompletionSource)))().$ctor(this, /*async*/  (/*state*/ state) =>
                        {
                            return $.$$.NetJs.AsyncResolver.Async($.$$.System.Void, $.$$.System.Void, async () => 
                            {
                                /*var*/ let  [ rootComponents, renderer, initializationTcs ] = $.$destructure(state);
                                try
                                {
                                    /*var*/ let count = rootComponents.Count;
                                    const $t2 = initialOperationBatch;
                                    /*var*/ let initialOperationCount = $.$ifnn($t2, ($t) => $t.Operations.length) ?? 0;
                                    /*var*/ let pendingRenders = new ($.$$.System.Collections.Generic.List$$($.$$.System.Threading.Tasks.Task))().$ctor$3(((count + initialOperationCount) | 0));
                                    for(/*var*/ let i = 0; i < count; i++)
                                    {
                                        /*var*/ let rootComponent = rootComponents.get_Item(i);
                                        pendingRenders.Add(renderer.AddComponentAsync(rootComponent.ComponentType, rootComponent.Parameters, rootComponent.Selector));
                                    }
                                    if (!(initialOperationBatch === null))
                                    {
                                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost.AddWebRootComponents(renderer, initialOperationBatch, pendingRenders);
                                    }
                                    await $.$$.System.Threading.Tasks.Task.WhenAll(pendingRenders);
                                    initializationTcs.SetResult();
                                }
                                catch(ex)
                                {
                                    initializationTcs.SetException$1(ex);
                                }
                            });
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$$.System.Threading.Tasks.TaskCompletionSource).$h
    }
  ],
  "n": "",
  "d": 1966193,
  "h": 0,
  "f": 17829890
}));
                        await initializationTcs.Task;
                        store.ExistingState.Clear();
                        await tcs.Task;
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77311377521)
            
            //--TRIMMABLE-BOUNDARY-START(42951639153)
            static /*void */ AddWebRootComponents(/*WebAssemblyRenderer*/ renderer, /*RootComponentOperationBatch*/ operationBatch, /*List<Task>*/ pendingRenders)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951639153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let webRootComponentManager = renderer.GetOrCreateWebRootComponentManager();
                /*var*/ let operations = operationBatch.Operations;
                for(/*var*/ let i = 0; i < operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(operations, i);
                    if (operation.Type !== 0/*RootComponentOperationType.Add*/)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12("All initial operations must be additions.");
                    }
                    pendingRenders.Add(webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters));
                }
                renderer.NotifyEndUpdateRootComponents(operationBatch.BatchId);
            }
            //--TRIMMABLE-BOUNDARY-END(42951639153)
            
            //--TRIMMABLE-BOUNDARY-START(4384555009)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384555009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384555009)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771769969)
                this._scope = $.$default($.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope);
                //--TRIMMABLE-BOUNDARY-END(25771769969)
                
            }
            static $h = 1966193;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246606449),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131508337,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 1966193,
      "h": 47246606449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246606449),
//--TRIMMABLE-BOUNDARY-START(81606344817),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721442929,
        "f": 50331649
      },
      "n": "Services",
      "d": 1966193,
      "h": 81606344817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606344817)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541573745),
    {
      "r": 180420609,
      "n": "DisposeAsync",
      "d": 1966193,
      "h": 51541573745,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(51541573745),
//--TRIMMABLE-BOUNDARY-START(73016410225),
    {
      "r": 177537025,
      "n": "RunAsync",
      "d": 1966193,
      "h": 73016410225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016410225),
//--TRIMMABLE-BOUNDARY-START(77311377521),
    {
      "r": 177537025,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        },
        {
          "n": "cultureProvider",
          "p": 1835121,
          "f": 65
        }
      ],
      "n": "RunAsyncCore",
      "d": 1966193,
      "h": 77311377521,
      "f": 16781320
    },
//--TRIMMABLE-BOUNDARY-END(77311377521),
//--TRIMMABLE-BOUNDARY-START(42951639153),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        },
        {
          "n": "operationBatch",
          "p": 1048689
        },
        {
          "n": "pendingRenders",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.Threading.Tasks.Task).$h
        }
      ],
      "n": "AddWebRootComponents",
      "d": 1966193,
      "h": 42951639153,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951639153)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771769969),
    {
      "t": 524378,
      "n": "_scope",
      "d": 1966193,
      "h": 25771769969,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771769969),
//--TRIMMABLE-BOUNDARY-START(30066737265),
    {
      "t": 327718,
      "n": "_services",
      "d": 1966193,
      "h": 30066737265,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066737265),
//--TRIMMABLE-BOUNDARY-START(4296933489),
    {
      "t": 393310,
      "n": "_configuration",
      "d": 1966193,
      "h": 4296933489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933489),
//--TRIMMABLE-BOUNDARY-START(21476802673),
    {
      "t": 1704049,
      "n": "_rootComponents",
      "d": 1966193,
      "h": 21476802673,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802673),
//--TRIMMABLE-BOUNDARY-START(12886868081),
    {
      "t": 1310721,
      "n": "_persistedState",
      "d": 1966193,
      "h": 12886868081,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886868081),
//--TRIMMABLE-BOUNDARY-START(8591900785),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1966193,
      "h": 8591900785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900785),
//--TRIMMABLE-BOUNDARY-START(34361704561),
    {
      "t": 262145,
      "n": "_started",
      "d": 1966193,
      "h": 34361704561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361704561),
//--TRIMMABLE-BOUNDARY-START(17181835377),
    {
      "t": 2949233,
      "n": "_renderer",
      "d": 1966193,
      "h": 17181835377,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835377)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656671857),
    {
      "p": [
        {
          "n": "builder",
          "p": 2031729
        },
        {
          "n": "services",
          "p": 327718
        },
        {
          "n": "scope",
          "p": 524378
        },
        {
          "n": "persistedState",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966193,
      "h": 38656671857,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38656671857)
  ],
  "i": [89587713
  ],
  "h": 1966193
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyHost`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966193)
        
        
        //--TRIMMABLE-BOUNDARY-START(4063345)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash", ($self) => class WebAssemblyScrollToLocationHash extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888965233)
            /*WebAssemblyScrollToLocationHash*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(12888965233)
            
            //--TRIMMABLE-BOUNDARY-START(17183932529)
            /*Task */ RefreshScrollPositionForHash(/*string*/ locationAbsolute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183932529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hashIndex = $.$$.System.String.IndexOf$8.call(locationAbsolute, "#", 4/*StringComparison.Ordinal*/);
                if (hashIndex > -1 && locationAbsolute.length > ((hashIndex + 1) | 0))
                {
                    let $t1 = locationAbsolute;
                    /*var*/ let elementId = $.$$.System.String.Substring.call($t1, (((hashIndex + 1) | 0)), $t1.length - (((hashIndex + 1) | 0)));
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_ScrollToElement(elementId);
                }
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(17183932529)
            
            //--TRIMMABLE-BOUNDARY-START(4305453164)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash.RefreshScrollPositionForHash(string)
            Microsoft$AspNetCore$Components$Routing$IScrollToLocationHash$RefreshScrollPositionForHash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4305453164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RefreshScrollPositionForHash(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4305453164)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4299030641)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12888965233)
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12888965233)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4299030641)
            
            static $h = 4063345;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183932529),
    {
      "r": 177537025,
      "p": [
        {
          "n": "locationAbsolute",
          "p": 1310721
        }
      ],
      "n": "RefreshScrollPositionForHash",
      "d": 4063345,
      "h": 17183932529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183932529)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888965233),
    {
      "t": 4063345,
      "n": "Instance",
      "d": 4063345,
      "h": 12888965233,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12888965233)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593997937),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 4063345,
      "h": 8593997937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593997937)
  ],
  "i": [10485868
  ],
  "h": 4063345
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash ]; }
            static get $fullName() { return `WebAssemblyScrollToLocationHash`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4063345)
        
        
        //--TRIMMABLE-BOUNDARY-START(3604593)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<>", (T) => $asm.$gt("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<>", [T], ($self) => class WebAssemblyConsoleLogger$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12888506481)
            /*string*/ static _loglevelPadding = null;
            //--TRIMMABLE-BOUNDARY-END(12888506481)
            
            //--TRIMMABLE-BOUNDARY-START(17183473777)
            /*string*/ static _messagePadding = null;
            //--TRIMMABLE-BOUNDARY-END(17183473777)
            
            //--TRIMMABLE-BOUNDARY-START(25773408369)
            /*string*/ static _newLineWithMessagePadding = null;
            //--TRIMMABLE-BOUNDARY-END(25773408369)
            
            //--TRIMMABLE-BOUNDARY-START(8593539185)
            /*StringBuilder*/ static _logBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(8593539185)
            
            //--TRIMMABLE-BOUNDARY-START(21478441073)
            /*string*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(21478441073)
            
            //--TRIMMABLE-BOUNDARY-START(4298571889)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4298571889)
            
            //--TRIMMABLE-BOUNDARY-START(34363342961)
            $ctor$2(/*IJSRuntime*/ jsRuntime)
            {
                this.$ctor$1($.$$.System.String.Empty, $.$cast(jsRuntime, $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363342961);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34363342961)
            
            //--TRIMMABLE-BOUNDARY-START(38658310257)
            $ctor$1(/*string*/ name, /*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658310257);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._name = $.$firstOf(name, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("name") });
                    this._jsRuntime = $.$firstOf(jsRuntime, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("jsRuntime") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38658310257)
            
            //--TRIMMABLE-BOUNDARY-START(42953277553)
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953277553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).NoOpDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(42953277553)
            
            //--TRIMMABLE-BOUNDARY-START(55838179441)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838179441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return logLevel !== 6/*LogLevel.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55838179441)
            
            //--TRIMMABLE-BOUNDARY-START(60133146737)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133146737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsEnabled(logLevel))
                {
                    return;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(formatter, "formatter");
                /*var*/ let message = formatter.Invoke(state, exception);
                if (!$.$$.System.String.IsNullOrEmpty(message) || exception !== null)
                {
                    this.WriteMessage(logLevel, this._name, eventId.Id, message, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60133146737)
            
            //--TRIMMABLE-BOUNDARY-START(68723081329)
            /*void */ WriteMessage(/*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723081329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder)
                    {
                        try
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).CreateDefaultLogMessage($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder, logLevel, logName, eventId, message, exception);
                            /*var*/ let formattedMessage = $.$$.System.Text.StringBuilder.ToString.call($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder);
                            switch(logLevel)
                            {
                                case 0/*LogLevel.Trace*/:
                                case 1/*LogLevel.Debug*/:
                                globalThis.console.debug(formattedMessage);
                                break;
                                case 2/*LogLevel.Information*/:
                                globalThis.console.info(formattedMessage);
                                break;
                                case 3/*LogLevel.Warning*/:
                                globalThis.console.warn(formattedMessage);
                                break;
                                case 4/*LogLevel.Error*/:
                                globalThis.console.error(formattedMessage);
                                break;
                                case 5/*LogLevel.Critical*/:
                                Blazor._internal.dotNetCriticalError(formattedMessage);
                                break;
                                default:
                                $.$$.System.Diagnostics.Debug.Assert$2(logLevel !== 6/*LogLevel.None*/, "This method is never called with LogLevel.None.");
                                $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid(this._jsRuntime, "console.log", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ formattedMessage ], null, null));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder.Clear();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68723081329)
            
            //--TRIMMABLE-BOUNDARY-START(47248244849)
            static /*void */ CreateDefaultLogMessage(/*StringBuilder*/ logBuilder, /*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248244849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                logBuilder.Append$19($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).GetLogLevelString(logLevel));
                logBuilder.Append$19(": "/*_loglevelPadding*/);
                logBuilder.Append$19(logName);
                logBuilder.Append$3(/*[*/ 91);
                logBuilder.Append$11(eventId);
                logBuilder.Append$3(/*]*/ 93);
                if (!$.$$.System.String.IsNullOrEmpty(message))
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$19($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._messagePadding);
                    /*var*/ let len = logBuilder.Length;
                    logBuilder.Append$19(message);
                    logBuilder.Replace$4($.$$.System.Environment.NewLine, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._newLineWithMessagePadding, len, message.length);
                }
                if (exception !== null)
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$19($.$$.System.Exception.ToString.call(exception));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47248244849)
            
            //--TRIMMABLE-BOUNDARY-START(51543212145)
            static /*string */ GetLogLevelString(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543212145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(logLevel)
                {
                    case 0/*LogLevel.Trace*/:
                    return "trce";
                    case 1/*LogLevel.Debug*/:
                    return "dbug";
                    case 2/*LogLevel.Information*/:
                    return "info";
                    case 3/*LogLevel.Warning*/:
                    return "warn";
                    case 4/*LogLevel.Error*/:
                    return "fail";
                    case 5/*LogLevel.Critical*/:
                    return "crit";
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("logLevel");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51543212145)
            
            //--TRIMMABLE-BOUNDARY-START(3670129)
            static $_NoOpDisposable;
            static get NoOpDisposable()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T);
                return $cls.$_NoOpDisposable ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$.NoOpDisposable", ($self) => class NoOpDisposable extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17183539313)
                    /*NoOpDisposable*/ static Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(17183539313)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888572017)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12888572017);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888572017)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-START(4298637425)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(17183539313)
                            this.Instance = new ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).NoOpDisposable)().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(17183539313)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4298637425)
                    
                    static $h = 3670129;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12888572017),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3670129,
      "h": Number(BigInt(3670129)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888572017)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183539313),
    {
      "t": 3670129,
      "n": "Instance",
      "d": 3670129,
      "h": Number(BigInt(3670129)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17183539313)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593604721),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3670129,
      "h": Number(BigInt(3670129)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8593604721)
  ],
  "i": [90177537
  ],
  "d": $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).$h,
  "h": 3670129
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `WebAssemblyConsoleLogger<${T?.$fullName}>.NoOpDisposable`; }
                }, $cls, ($v) => $cls.$_NoOpDisposable = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3670129)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            //--TRIMMABLE-BOUNDARY-START(30068375665)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12888506481)
                    this._loglevelPadding = ": ";
                    //--TRIMMABLE-BOUNDARY-END(12888506481)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17183473777)
                    this._messagePadding = $.$$.System.String.Create(/* */ 32, (($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).GetLogLevelString(2/*LogLevel.Information*/).length + ": "/*_loglevelPadding*/.length) | 0));
                    //--TRIMMABLE-BOUNDARY-END(17183473777)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25773408369)
                    this._newLineWithMessagePadding = $.$$.System.Environment.NewLine + $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._messagePadding;
                    //--TRIMMABLE-BOUNDARY-END(25773408369)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8593539185)
                    this._logBuilder = new $.$$.System.Text.StringBuilder().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(8593539185)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068375665)
            
            static $h = 3604593;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42953277553),
    {
      "r": 90177537,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(42953277553),
//--TRIMMABLE-BOUNDARY-START(55838179441),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55838179441),
//--TRIMMABLE-BOUNDARY-START(60133146737),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 79888385
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(60133146737),
//--TRIMMABLE-BOUNDARY-START(68723081329),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "logName",
          "p": 1310721
        },
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "WriteMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68723081329),
//--TRIMMABLE-BOUNDARY-START(47248244849),
    {
      "r": 65537,
      "p": [
        {
          "n": "logBuilder",
          "p": 166920193
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "logName",
          "p": 1310721
        },
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "CreateDefaultLogMessage",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47248244849),
//--TRIMMABLE-BOUNDARY-START(51543212145),
    {
      "r": 1310721,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "GetLogLevelString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51543212145)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12888506481),
    {
      "t": 1310721,
      "n": "_loglevelPadding",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12888506481),
//--TRIMMABLE-BOUNDARY-START(17183473777),
    {
      "t": 1310721,
      "n": "_messagePadding",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17183473777),
//--TRIMMABLE-BOUNDARY-START(25773408369),
    {
      "t": 1310721,
      "n": "_newLineWithMessagePadding",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25773408369),
//--TRIMMABLE-BOUNDARY-START(8593539185),
    {
      "t": 166920193,
      "n": "_logBuilder",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8593539185),
//--TRIMMABLE-BOUNDARY-START(21478441073),
    {
      "t": 1310721,
      "n": "_name",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21478441073),
//--TRIMMABLE-BOUNDARY-START(4298571889),
    {
      "t": 262256,
      "n": "_jsRuntime",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298571889)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34363342961),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 524395
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363342961),
//--TRIMMABLE-BOUNDARY-START(38658310257),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "jsRuntime",
          "p": 262256
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38658310257)
  ],
  "i": [$.$mela.Microsoft.Extensions.Logging.ILogger$$(T).$h,917592
  ],
  "g": [T?.$h??1507328
  ],
  "j": [3670129
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger$$(T), $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `WebAssemblyConsoleLogger<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3604593)
        
        
        //--TRIMMABLE-BOUNDARY-START(3735665)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLoggerProvider", ($self) => class WebAssemblyConsoleLoggerProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8593670257)
            /*ConcurrentDictionary<string, WebAssemblyConsoleLogger<object>>*/ _loggers = null;
            //--TRIMMABLE-BOUNDARY-END(8593670257)
            
            //--TRIMMABLE-BOUNDARY-START(4298702961)
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            //--TRIMMABLE-BOUNDARY-END(4298702961)
            
            //--TRIMMABLE-BOUNDARY-START(12888637553)
            $ctor$1(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888637553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._loggers = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$$.System.Object)))().$ctor$1();
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888637553)
            
            //--TRIMMABLE-BOUNDARY-START(17183604849)
            /*ILogger */ CreateLogger(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183604849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._loggers.GetOrAdd(name, new ($.$$.System.Func$$$($.$$.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$$.System.Object)))().$ctor(this,  (/*loggerName*/ loggerName) =>
                {
                    return new ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$$.System.Object))().$ctor$1(name, this._jsRuntime);
                }, {
  "r": $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$$.System.Object).$h,
  "p": [
    {
      "n": "loggerName",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 3735665,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(17183604849)
            
            //--TRIMMABLE-BOUNDARY-START(21478572145)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478572145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21478572145)
            
            //--TRIMMABLE-BOUNDARY-START(4296081496)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerProvider.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081496)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 3735665;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183604849),
    {
      "r": 917592,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 3735665,
      "h": 17183604849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183604849),
//--TRIMMABLE-BOUNDARY-START(21478572145),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3735665,
      "h": 21478572145,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478572145)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593670257),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$$.System.Object)).$h,
      "n": "_loggers",
      "d": 3735665,
      "h": 8593670257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593670257),
//--TRIMMABLE-BOUNDARY-START(4298702961),
    {
      "t": 262256,
      "n": "_jsRuntime",
      "d": 3735665,
      "h": 4298702961,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298702961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888637553),
    {
      "p": [
        {
          "n": "jsRuntime",
          "p": 262256
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3735665,
      "h": 12888637553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888637553)
  ],
  "i": [1114200,90177537
  ],
  "h": 3735665
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `WebAssemblyConsoleLoggerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735665)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162801)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostConfiguration", ($self) => class WebAssemblyHostConfiguration extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887064689)
            /*List<IConfigurationProvider>*/ _providers = null;
            //--TRIMMABLE-BOUNDARY-END(12887064689)
            
            //--TRIMMABLE-BOUNDARY-START(17182031985)
            /*List<IConfigurationSource>*/ _sources = null;
            //--TRIMMABLE-BOUNDARY-END(17182031985)
            
            //--TRIMMABLE-BOUNDARY-START(8592097393)
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(8592097393)
            
            //--TRIMMABLE-BOUNDARY-START(4297130097)
            /*ConfigurationReloadToken*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4297130097)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85901508721, 34360197214)
            /*IList<IConfigurationSource> */ get Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources()
            {
                return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1(this._sources.ToArray());
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85901508721, 34360197214)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 98786410609, 12885557342)
            /*IEnumerable<IConfigurationProvider> */ get Microsoft$Extensions$Configuration$IConfigurationRoot$Providers()
            {
                return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1(this._providers.ToArray());
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 98786410609, 12885557342)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81606541425, 30065229918)
            /*IDictionary<string, object>*/ Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 81606541425, 30065229918)
            
            //--TRIMMABLE-BOUNDARY-START(120261247089)
            /*string?*/ get_Item(/*string*/ key)
            {
                for(/*var*/ let i = ((this._providers.Count - 1) | 0); i >= 0; i--)
                {
                    /*var*/ let provider = this._providers.get_Item(i);
                    /*var*/ let value;
                    if (provider.Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet(key, $.$ref(() => value, ($v) => value = $v, $.$$.System.String)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                if (this._providers.Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("Can only set property if at least one provider has been inserted.");
                }
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Set(key, value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261247089)
            
            //--TRIMMABLE-BOUNDARY-START(55836737649)
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836737649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection().$ctor$1(this, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836737649)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60131704945, 12885295198)
            /*IEnumerable<IConfigurationSection> */ Microsoft$Extensions$Configuration$IConfiguration$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let hashSet = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                /*var*/ let result = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection))().$ctor$1();
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        var $en4 = provider.Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys($.$sl.System.Linq.Enumerable.Empty($.$$.System.String), null).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var child = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!hashSet.Add(child))
                                {
                                    continue;
                                }
                                result.Add(this.GetSection(child));
                            }
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60131704945, 12885295198)
            
            //--TRIMMABLE-BOUNDARY-START(51541770353)
            /*IChangeToken */ GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541770353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._changeToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541770353)
            
            //--TRIMMABLE-BOUNDARY-START(107376345201)
            /*void */ Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                    }
                }
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(107376345201)
            
            //--TRIMMABLE-BOUNDARY-START(103081377905)
            /*void */ RaiseChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081377905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let previousToken = $.$$.System.Threading.Interlocked.Exchange$14($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken), new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(103081377905)
            
            //--TRIMMABLE-BOUNDARY-START(30066933873)
            /*IConfigurationBuilder */ Add(/*IConfigurationSource*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                /*var*/ let provider = source.Microsoft$Extensions$Configuration$IConfigurationSource$Build(this);
                provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                this._changeTokenRegistrations.Add($.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(provider, provider.Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken), new $.$$.System.Action().$ctor(this, this.RaiseChanged)));
                this._providers.Add(provider);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066933873)
            
            //--TRIMMABLE-BOUNDARY-START(34361901169)
            /*IConfigurationRoot */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361901169)
            
            //--TRIMMABLE-BOUNDARY-START(38656868465)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._changeTokenRegistrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        ($.$as(provider, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656868465)
            
            //--TRIMMABLE-BOUNDARY-START(17180524638)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Reload()
            Microsoft$Extensions$Configuration$IConfigurationRoot$Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reload(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524638)
            
            //--TRIMMABLE-BOUNDARY-START(8590327902)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            Microsoft$Extensions$Configuration$IConfiguration$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327902)
            
            //--TRIMMABLE-BOUNDARY-START(30065164382)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            Microsoft$Extensions$Configuration$IConfiguration$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164382)
            
            //--TRIMMABLE-BOUNDARY-START(21475229790)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            Microsoft$Extensions$Configuration$IConfiguration$GetSection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSection(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229790)
            
            //--TRIMMABLE-BOUNDARY-START(17180262494)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262494)
            
            //--TRIMMABLE-BOUNDARY-START(4295426142)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426142)
            
            //--TRIMMABLE-BOUNDARY-START(8590393438)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Build()
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393438)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12887064689)
                this._providers = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12887064689)
                
                //--TRIMMABLE-BOUNDARY-START(17182031985)
                this._sources = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17182031985)
                
                //--TRIMMABLE-BOUNDARY-START(8592097393)
                this._changeTokenRegistrations = new ($.$$.System.Collections.Generic.List$$($.$$.System.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8592097393)
                
                //--TRIMMABLE-BOUNDARY-START(4297130097)
                this._changeToken = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4297130097)
                
                this.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
            }
            static $h = 2162801;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 85901508721, 34360197214),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311574129,
        "f": 50331650
      },
      "n": "{458846}.Sources",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources",
      "d": 2162801,
      "h": 85901508721,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85901508721, 34360197214),
//--TRIMMABLE-BOUNDARY-START(ALL, 98786410609, 12885557342),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491443313,
        "f": 50331650
      },
      "n": "{655454}.Providers",
      "o": "Microsoft$Extensions$Configuration$IConfigurationRoot$Providers",
      "d": 2162801,
      "h": 98786410609,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 98786410609, 12885557342),
//--TRIMMABLE-BOUNDARY-START(ALL, 81606541425, 30065229918),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721639537,
        "f": 50331650
      },
      "n": "{458846}.Properties",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties",
      "d": 2162801,
      "h": 81606541425,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81606541425, 30065229918),
//--TRIMMABLE-BOUNDARY-START(120261247089),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246803057,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115966279793,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 2162801,
      "h": 120261247089,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261247089)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836737649),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "d": 2162801,
      "h": 55836737649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836737649),
//--TRIMMABLE-BOUNDARY-START(51541770353),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 2162801,
      "h": 51541770353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541770353),
//--TRIMMABLE-BOUNDARY-START(107376345201),
    {
      "r": 65537,
      "n": "Reload",
      "d": 2162801,
      "h": 107376345201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107376345201),
//--TRIMMABLE-BOUNDARY-START(103081377905),
    {
      "r": 65537,
      "n": "RaiseChanged",
      "d": 2162801,
      "h": 103081377905,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103081377905),
//--TRIMMABLE-BOUNDARY-START(30066933873),
    {
      "r": 458846,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "d": 2162801,
      "h": 30066933873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066933873),
//--TRIMMABLE-BOUNDARY-START(34361901169),
    {
      "r": 655454,
      "n": "Build",
      "d": 2162801,
      "h": 34361901169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361901169),
//--TRIMMABLE-BOUNDARY-START(38656868465),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2162801,
      "h": 38656868465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656868465)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887064689),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,
      "n": "_providers",
      "d": 2162801,
      "h": 12887064689,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887064689),
//--TRIMMABLE-BOUNDARY-START(17182031985),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,
      "n": "_sources",
      "d": 2162801,
      "h": 17182031985,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182031985),
//--TRIMMABLE-BOUNDARY-START(8592097393),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.IDisposable).$h,
      "n": "_changeTokenRegistrations",
      "d": 2162801,
      "h": 8592097393,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097393),
//--TRIMMABLE-BOUNDARY-START(4297130097),
    {
      "t": 720991,
      "n": "_changeToken",
      "d": 2162801,
      "h": 4297130097,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297130097)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476999281),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162801,
      "h": 21476999281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476999281)
  ],
  "i": [655454,393310,458846
  ],
  "h": 2162801
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationRoot, $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder ]; }
            static get $fullName() { return `WebAssemblyHostConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162801)
        
        
        //--TRIMMABLE-BOUNDARY-START(4391025)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters", ($self) => class WebRootComponentParameters extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34364129393)
            /*WebRootComponentParameters*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(34364129393)
            
            //--TRIMMABLE-BOUNDARY-START(4299358321)
            /*IReadOnlyList<ComponentParameter>*/  get _parameterDefinitions() { return this.$getField(20, 4); }
            /*IReadOnlyList<ComponentParameter>*/  set _parameterDefinitions(value) { this.$setField(20, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4299358321)
            
            //--TRIMMABLE-BOUNDARY-START(8594325617)
            /*IReadOnlyList<object>*/  get _serializedParameterValues() { return this.$getField(24, 4); }
            /*IReadOnlyList<object>*/  set _serializedParameterValues(value) { this.$setField(24, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8594325617)
            
            //--TRIMMABLE-BOUNDARY-START(47249031281)
            /*ParameterView */ get Parameters()
            {
                return this.parameterView;
            }
            //--TRIMMABLE-BOUNDARY-END(47249031281)
            
            //--TRIMMABLE-BOUNDARY-START(30069162097)
            /*bool */ DefinitelyEquals(/*in WebRootComponentParameters*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30069162097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let count = this._parameterDefinitions.System$Collections$Generic$IReadOnlyCollection$$$Count;
                if (count !== other.$v._parameterDefinitions.System$Collections$Generic$IReadOnlyCollection$$$Count)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < count; i++)
                {
                    /*var*/ let definition = this._parameterDefinitions.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    /*var*/ let otherDefinition = other.$v._parameterDefinitions.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    if (!$.$$.System.String.Equals$2(definition.Name, otherDefinition.Name, 4/*StringComparison.Ordinal*/) || !$.$$.System.String.Equals$2(definition.TypeName, otherDefinition.TypeName, 4/*StringComparison.Ordinal*/) || !$.$$.System.String.Equals$2(definition.Assembly, otherDefinition.Assembly, 4/*StringComparison.Ordinal*/))
                    {
                        return false;
                    }
                    /*var*/ let value = this._serializedParameterValues.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$$.System.Object]);
                    /*var*/ let otherValue = other.$v._serializedParameterValues.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$$.System.Object]);
                    let jsonValue;
                    let otherJsonValue;
                    if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonValue = v; } }) && $.$is(otherValue, $.$stj.System.Text.Json.JsonElement, { set $v(v){ otherJsonValue = v; } }))
                    {
                        if (!$.$$.System.String.Equals$2(jsonValue.GetRawText(), otherJsonValue.GetRawText(), 4/*StringComparison.Ordinal*/))
                        {
                            return false;
                        }
                    }
                    else if (!$.$$.System.Object.Equals(value, otherValue))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30069162097)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parameterDefinitions = this._parameterDefinitions;
                copy._serializedParameterValues = this._serializedParameterValues;
                return copy;
            }
            //Begin primary constructor
            /*ParameterView*/ parameterView = new $.$mac.Microsoft.AspNetCore.Components.ParameterView();
            /*IReadOnlyList<ComponentParameter>*/ parameterDefinitions = null;
            /*IReadOnlyList<object>*/ serializedParameterValues = null;
            $ctor$3(/*ParameterView*/parameterView, /*IReadOnlyList<ComponentParameter>*/parameterDefinitions, /*IReadOnlyList<object>*/serializedParameterValues)
            {
                this.parameterView = parameterView;
                this.parameterDefinitions = parameterDefinitions;
                this.serializedParameterValues = serializedParameterValues;
                //--TRIMMABLE-BOUNDARY-START(4299358321)
                //depends on primary constructor parameter
                this._parameterDefinitions = this.parameterDefinitions;
                //--TRIMMABLE-BOUNDARY-END(4299358321)
                
                //--TRIMMABLE-BOUNDARY-START(8594325617)
                //depends on primary constructor parameter
                this._serializedParameterValues = this.serializedParameterValues;
                //--TRIMMABLE-BOUNDARY-END(8594325617)
                
                return this
            }
            //End primary constructor
            //--TRIMMABLE-BOUNDARY-START(12889292913)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34364129393)
                    this.Empty = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$3($.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty, (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor$1();
                        return $t1;
                    })(), (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                        return $t1;
                    })());
                    //--TRIMMABLE-BOUNDARY-END(34364129393)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12889292913)
            
            static $h = 4391025;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47249031281),
    {
      "p": 5767276,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42954063985,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 4391025,
      "h": 47249031281,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47249031281)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30069162097),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 4391025,
          "f": 8
        }
      ],
      "n": "DefinitelyEquals",
      "d": 4391025,
      "h": 30069162097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30069162097)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25774194801),
    {
      "t": 5767276,
      "n": "\u003CparameterView\u003EP",
      "d": 4391025,
      "h": 25774194801,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25774194801),
//--TRIMMABLE-BOUNDARY-START(34364129393),
    {
      "t": 4391025,
      "n": "Empty",
      "d": 4391025,
      "h": 34364129393,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34364129393),
//--TRIMMABLE-BOUNDARY-START(4299358321),
    {
      "t": $.$$.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
      "n": "_parameterDefinitions",
      "d": 4391025,
      "h": 4299358321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4299358321),
//--TRIMMABLE-BOUNDARY-START(8594325617),
    {
      "t": $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Object).$h,
      "n": "_serializedParameterValues",
      "d": 4391025,
      "h": 8594325617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8594325617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17184260209),
    {
      "p": [
        {
          "n": "parameterView",
          "p": 5767276
        },
        {
          "n": "parameterDefinitions",
          "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h
        },
        {
          "n": "serializedParameterValues",
          "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4391025,
      "h": 17184260209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17184260209),
//--TRIMMABLE-BOUNDARY-START(21479227505),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 4391025,
      "h": 21479227505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21479227505)
  ],
  "h": 4391025
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `WebRootComponentParameters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4391025)
        
        
        //--TRIMMABLE-BOUNDARY-START(524401)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider", ($self) => class DefaultAntiforgeryStateProvider extends $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295491697)
            /*AntiforgeryRequestToken?*/ _currentToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295491697)
            
            //--TRIMMABLE-BOUNDARY-START(12885426289)
            /*AntiforgeryRequestToken? */ get CurrentToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._currentToken ??= this.GetAntiforgeryToken();
            }
            /*AntiforgeryRequestToken? */ set CurrentToken(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._currentToken = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426289)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770328177, 8590262382)
            /*AntiforgeryRequestToken? */ GetAntiforgeryToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._currentToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770328177, 8590262382)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 524401;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 327790,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426289),
    {
      "p": 262254,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360881,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360262769,
        "f": 83886081
      },
      "n": "CurrentToken",
      "d": 524401,
      "h": 12885426289,
      "f": 2097153,
      "a": [
        {
          "t": 6357100,
          "c": 4301324396
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885426289)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25770328177, 8590262382),
    {
      "r": 262254,
      "n": "GetAntiforgeryToken",
      "d": 524401,
      "h": 25770328177,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770328177, 8590262382)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491697),
    {
      "t": 262254,
      "n": "_currentToken",
      "d": 524401,
      "h": 4295491697,
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4295491697)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458993),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524401,
      "h": 8590458993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458993)
  ],
  "h": 524401
}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider; }
            static get $fullName() { return `DefaultAntiforgeryStateProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524401)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638513)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping", ($self) => class RootComponentMapping extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296605809)
            $ctor$4(/*Type*/ componentType, /*string*/ selector)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605809);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(componentType, "componentType");
                    if (!$.$mac.Microsoft.AspNetCore.Components.IComponent.$type.IsAssignableFrom(componentType))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13(`The type '${componentType.Name}' must implement ${"IComponent"} to be used as a root component.`, "componentType");
                    }
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                    this.ComponentType = componentType;
                    this.Selector = selector;
                    this.Parameters = $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605809)
            
            //--TRIMMABLE-BOUNDARY-START(8591573105)
            $ctor$3(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                this.$ctor$4(componentType, selector);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573105);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Parameters = parameters;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573105)
            
            //--TRIMMABLE-BOUNDARY-START(30066409585)
            /*Type*/ ComponentType = null;
            //--TRIMMABLE-BOUNDARY-END(30066409585)
            
            //--TRIMMABLE-BOUNDARY-START(64426147953)
            /*string*/ Selector = null;
            //--TRIMMABLE-BOUNDARY-END(64426147953)
            
            //--TRIMMABLE-BOUNDARY-START(60131180657)
            /*ParameterView*/ Parameters;
            //--TRIMMABLE-BOUNDARY-END(60131180657)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ComponentType = this.ComponentType;
                copy.Selector = this.Selector;
                copy.Parameters = this.Parameters.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Parameters = $.$default($.$mac.Microsoft.AspNetCore.Components.ParameterView);
            }
            static $h = 1638513;
            static $z = 28;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066409585),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656344177,
        "f": 50331649
      },
      "n": "ComponentType",
      "d": 1638513,
      "h": 30066409585,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066409585),
//--TRIMMABLE-BOUNDARY-START(64426147953),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836213361,
        "f": 50331649
      },
      "n": "Selector",
      "d": 1638513,
      "h": 64426147953,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426147953),
//--TRIMMABLE-BOUNDARY-START(60131180657),
    {
      "p": 5767276,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246278769,
        "f": 50331649
      },
      "n": "Parameters",
      "d": 1638513,
      "h": 60131180657,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131180657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605809),
    {
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1638513,
      "h": 4296605809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605809),
//--TRIMMABLE-BOUNDARY-START(8591573105),
    {
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "selector",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": 5767276
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638513,
      "h": 8591573105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591573105),
//--TRIMMABLE-BOUNDARY-START(12886540401),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638513,
      "h": 12886540401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540401)
  ],
  "h": 1638513
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `RootComponentMapping`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638513)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752625)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher", ($self) => class NullDispatcher extends $.$mac.Microsoft.AspNetCore.Components.Dispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(17182621809)
            /*Dispatcher*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17182621809)
            
            //--TRIMMABLE-BOUNDARY-START(8592687217)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592687217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592687217)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12887654513, 25771507820)
            /*bool */ CheckAccess()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12887654513, 25771507820)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21477589105, 42951377004)
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477589105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                workItem.Invoke();
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21477589105, 42951377004)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25772556401, 47246344300)
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772556401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return workItem.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25772556401, 47246344300)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30067523697, 51541311596)
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<TResult>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067523697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return $.$$.System.Threading.Tasks.Task.FromResult(TResult, workItem.Invoke());
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30067523697, 51541311596)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34362490993, 55836278892)
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362490993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                return workItem.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34362490993, 55836278892)
            
            //--TRIMMABLE-BOUNDARY-START(4297719921)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17182621809)
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(17182621809)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297719921)
            
            static $h = 2752625;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1704044,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887654513, 25771507820),
    {
      "r": 262145,
      "n": "CheckAccess",
      "d": 2752625,
      "h": 12887654513,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887654513, 25771507820),
//--TRIMMABLE-BOUNDARY-START(ALL, 21477589105, 42951377004),
    {
      "r": 177537025,
      "p": [
        {
          "n": "workItem",
          "p": 42270721
        }
      ],
      "n": "InvokeAsync",
      "d": 2752625,
      "h": 21477589105,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21477589105, 42951377004),
//--TRIMMABLE-BOUNDARY-START(ALL, 25772556401, 47246344300),
    {
      "r": 177537025,
      "p": [
        {
          "n": "workItem",
          "p": $.$$.System.Func$$($.$$.System.Threading.Tasks.Task).$h
        }
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2752625,
      "h": 25772556401,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25772556401, 47246344300),
//--TRIMMABLE-BOUNDARY-START(ALL, 30067523697, 51541311596),
    {
      "r": (TResult) => $.$$.System.Threading.Tasks.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.System.Func$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2752625,
      "h": 30067523697,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30067523697, 51541311596),
//--TRIMMABLE-BOUNDARY-START(ALL, 34362490993, 55836278892),
    {
      "r": (TResult) => $.$$.System.Threading.Tasks.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$(TResult)).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2752625,
      "h": 34362490993,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34362490993, 55836278892)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182621809),
    {
      "t": 1704044,
      "n": "Instance",
      "d": 2752625,
      "h": 17182621809,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182621809)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687217),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752625,
      "h": 8592687217,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8592687217)
  ],
  "h": 2752625
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Dispatcher; }
            static get $fullName() { return `NullDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752625)
        
        
        //--TRIMMABLE-BOUNDARY-START(3932273)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager", ($self) => class WebAssemblyNavigationManager extends $.$mac.Microsoft.AspNetCore.Components.NavigationManager
        {
            //--TRIMMABLE-BOUNDARY-START(4298899569)
            /*ILogger<WebAssemblyNavigationManager>*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(4298899569)
            
            //--TRIMMABLE-BOUNDARY-START(42953605233)
            /*WebAssemblyNavigationManager*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(42953605233)
            
            //--TRIMMABLE-BOUNDARY-START(12888834161)
            $ctor$2(/*string*/ baseUri, /*string*/ uri)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888834161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Initialize(baseUri, uri);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888834161)
            
            //--TRIMMABLE-BOUNDARY-START(21478768753)
            /*void */ CreateLogger(/*ILoggerFactory*/ loggerFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478768753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._logger === null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(`The ${"WebAssemblyNavigationManager"} has already created a logger.`);
                }
                this._logger = $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager, loggerFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(21478768753)
            
            //--TRIMMABLE-BOUNDARY-START(68723409009)
            /*void */ SetLocation(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723409009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Uri = uri;
                this.HistoryEntryState = state;
                this.NotifyLocationChanged(isInterceptedLink);
            }
            //--TRIMMABLE-BOUNDARY-END(68723409009)
            
            //--TRIMMABLE-BOUNDARY-START(34363670641)
            /*ValueTask<bool> *//*async*/  HandleLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ intercepted)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363670641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return await this.NotifyLocationChangingAsync(uri, state, intercepted);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(34363670641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51543539825, 141738901612)
            /*void */ NavigateToCore$1(/*string*/ uri, /*NavigationOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543539825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                _ = PerformNavigationAsync.call(this);
                /*Task*/ /*async*/  function PerformNavigationAsync()
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                    {
                        try
                        {
                            /*var*/ let shouldContinueNavigation = await this.NotifyLocationChangingAsync(uri, options.HistoryEntryState, false);
                            if (!shouldContinueNavigation)
                            {
                                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationCanceled(this._logger, uri);
                                return;
                            }
                            $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.navigateTo"/*Interop.NavigateTo*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ uri, options ], null, null));
                        }
                        catch(ex)
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, uri, ex);
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51543539825, 141738901612)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55838507121, 171803672684)
            /*void */ Refresh(/*bool*/ forceReload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838507121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.refresh"/*Interop.Refresh*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$box(forceReload, $.$$.System.Boolean) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55838507121, 171803672684)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38658637937, 98789228652)
            /*void */ HandleLocationChangingHandlerException(/*Exception*/ ex, /*LocationChangingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658637937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, context.TargetLocation, ex);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38658637937, 98789228652)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 73018376305, 227638247532)
            /*void */ SetNavigationLockState(/*bool*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73018376305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_SetHasLocationChangingListeners(2/*WebRendererId.WebAssembly*/, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 73018376305, 227638247532)
            
            //--TRIMMABLE-BOUNDARY-START(3997809)
            static $_Log;
            static get Log()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager;
                return $cls.$_Log ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log", ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4298965105)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationCanceledCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4298965105)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183866993)
                    static /*void */ NavigationCanceled(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17183866993);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.__NavigationCanceledCallback.Invoke(logger, uri, null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183866993)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593932401)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationFailedCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(8593932401)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478834289)
                    static /*void */ NavigationFailed(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri, /*global::System.Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21478834289);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.__NavigationFailedCallback.Invoke(logger, uri, exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21478834289)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888899697)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4298965105)
                            this.__NavigationCanceledCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$12($.$$.System.String, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(1, "NavigationCanceled"), "Navigation canceled when changing the location to {Uri}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4298965105)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8593932401)
                            this.__NavigationFailedCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$12($.$$.System.String, 4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(2, "NavigationFailed"), "Navigation failed when changing the location to {Uri}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(8593932401)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888899697)
                    
                    static $h = 3997809;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183866993),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": "NavigationCanceled",
      "d": 3997809,
      "h": 17183866993,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 8592162904,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "Navigation canceled when changing the location to {Uri}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "NavigationCanceled",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17183866993),
//--TRIMMABLE-BOUNDARY-START(21478834289),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "NavigationFailed",
      "d": 3997809,
      "h": 21478834289,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 8592162904,
          "a": [
            {
              "v": 2,
              "t": 655361
            },
            {
              "v": 4,
              "t": 2293848
            },
            {
              "v": "Navigation failed when changing the location to {Uri}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "NavigationFailed",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21478834289)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298965105),
    {
      "t": $.$$.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.Exception).$h,
      "n": "__NavigationCanceledCallback",
      "d": 3997809,
      "h": 4298965105,
      "f": 4194338,
      "a": [
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4298965105),
//--TRIMMABLE-BOUNDARY-START(8593932401),
    {
      "t": $.$$.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.Exception).$h,
      "n": "__NavigationFailedCallback",
      "d": 3997809,
      "h": 8593932401,
      "f": 4194338,
      "a": [
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8593932401)
  ],
  "d": 3932273,
  "h": 3997809
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `WebAssemblyNavigationManager.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3997809)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4298899569)
                this._logger = null;
                //--TRIMMABLE-BOUNDARY-END(4298899569)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8593866865)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593866865)
            
            static $h = 3932273;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 4980844,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42953605233),
    {
      "p": 3932273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068703345,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64428441713,
        "f": 83886113
      },
      "n": "Instance",
      "d": 3932273,
      "h": 42953605233,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42953605233)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478768753),
    {
      "r": 65537,
      "p": [
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": "CreateLogger",
      "d": 3932273,
      "h": 21478768753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478768753),
//--TRIMMABLE-BOUNDARY-START(68723409009),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "isInterceptedLink",
          "p": 262145
        }
      ],
      "n": "SetLocation",
      "d": 3932273,
      "h": 68723409009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68723409009),
//--TRIMMABLE-BOUNDARY-START(34363670641),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "state",
          "p": 1310721
        },
        {
          "n": "intercepted",
          "p": 262145
        }
      ],
      "n": "HandleLocationChangingAsync",
      "d": 3932273,
      "h": 34363670641,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(34363670641),
//--TRIMMABLE-BOUNDARY-START(ALL, 51543539825, 141738901612),
    {
      "r": 65537,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 5439596
        }
      ],
      "n": "NavigateToCore",
      "o": "@$1",
      "d": 3932273,
      "h": 51543539825,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51543539825, 141738901612),
//--TRIMMABLE-BOUNDARY-START(ALL, 55838507121, 171803672684),
    {
      "r": 65537,
      "p": [
        {
          "n": "forceReload",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Refresh",
      "d": 3932273,
      "h": 55838507121,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55838507121, 171803672684),
//--TRIMMABLE-BOUNDARY-START(ALL, 38658637937, 98789228652),
    {
      "r": 65537,
      "p": [
        {
          "n": "ex",
          "p": 79888385
        },
        {
          "n": "context",
          "p": 10616940
        }
      ],
      "n": "HandleLocationChangingHandlerException",
      "d": 3932273,
      "h": 38658637937,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38658637937, 98789228652),
//--TRIMMABLE-BOUNDARY-START(ALL, 73018376305, 227638247532),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "SetNavigationLockState",
      "d": 3932273,
      "h": 73018376305,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 73018376305, 227638247532)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298899569),
    {
      "t": $.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager).$h,
      "n": "_logger",
      "d": 3932273,
      "h": 4298899569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298899569)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888834161),
    {
      "p": [
        {
          "n": "baseUri",
          "p": 1310721
        },
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3932273,
      "h": 12888834161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888834161)
  ],
  "j": [3997809
  ],
  "h": 3932273
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.NavigationManager; }
            static get $fullName() { return `WebAssemblyNavigationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3932273)
        
        
        //--TRIMMABLE-BOUNDARY-START(262257)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentParameter", ($self) => class ComponentParameter extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55834837105)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(55834837105)
            
            //--TRIMMABLE-BOUNDARY-START(85899608177)
            /*string?*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(85899608177)
            
            //--TRIMMABLE-BOUNDARY-START(21475098737)
            /*string?*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(21475098737)
            
            //--TRIMMABLE-BOUNDARY-START(25770066033)
            static /*(IList<ComponentParameter> parameterDefinitions, IList<object?> parameterValues) */ FromParameterView(/*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameterDefinitions = new ($.$$.System.Collections.Generic.List$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor$1();
                /*var*/ let parameterValues = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                var $en2 = parameters.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        const $t1 = () => kvp.Value;
                        /*var*/ let valueType = $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t));
                        /*System.Type?*/ let __ca1__;
                        /*System.Reflection.Assembly*/ let __ca2__;
                        /*System.Reflection.AssemblyName*/ let __ca3__;
                        parameterDefinitions.Add((() =>
                        {
                            //new $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter()
                            const $t2 = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter;
                            const $i2 = new $t2();
                            $i2.Name = kvp.Name;
                            $i2.TypeName = (valueType?.FullName ?? null);
                            $i2.Assembly = ($.$$.System.Type.op_Inequality$1((__ca1__ = valueType), null) ? ($.$$.System.Reflection.Assembly.op_Inequality((__ca2__ = __ca1__.Assembly), null) ? ((__ca3__ = __ca2__.GetName()) !== null ? __ca3__.Name : null) : null) : null);
                            return $i2;
                        })());
                        parameterValues.Add(kvp.Value);
                    }
                }
                return new ($.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), $.$$.System.Collections.Generic.IList$$($.$$.System.Object)))().$ctor$3(parameterDefinitions, parameterValues);
            }
            //--TRIMMABLE-BOUNDARY-END(25770066033)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.TypeName = this.TypeName;
                copy.Assembly = this.Assembly;
                return copy;
            }
            static $h = 262257;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834837105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949935217,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706289,
        "f": 83886081
      },
      "n": "Name",
      "d": 262257,
      "h": 55834837105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837105),
//--TRIMMABLE-BOUNDARY-START(85899608177),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869809,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640881,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 262257,
      "h": 85899608177,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899608177),
//--TRIMMABLE-BOUNDARY-START(21475098737),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000625,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771697,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 262257,
      "h": 21475098737,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098737)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770066033),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), $.$$.System.Collections.Generic.IList$$($.$$.System.Object)).$h,
      "p": [
        {
          "n": "parameters",
          "p": 5767276
        }
      ],
      "n": "FromParameterView",
      "d": 262257,
      "h": 25770066033,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770066033)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229553),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262257,
      "h": 4295229553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229553)
  ],
  "h": 262257
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ComponentParameter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262257)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883697)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher", ($self) => class WebAssemblyDispatcher extends $.$mac.Microsoft.AspNetCore.Components.Dispatcher
        {
            //--TRIMMABLE-BOUNDARY-START(8592818289)
            /*SynchronizationContext?*/ static _mainSynchronizationContext = null;
            //--TRIMMABLE-BOUNDARY-END(8592818289)
            
            //--TRIMMABLE-BOUNDARY-START(4297850993)
            /*int*/ static _mainManagedThreadId = 0;
            //--TRIMMABLE-BOUNDARY-END(4297850993)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17182752881, 25771507820)
            /*bool */ CheckAccess()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182752881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainManagedThreadId === $.$$.System.Environment.CurrentManagedThreadId;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17182752881, 25771507820)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21477720177, 42951377004)
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    workItem.Invoke();
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource, $.$$.System.Action));
                    try
                    {
                        state.Item2.Invoke();
                        state.Item1.SetResult();
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource, $.$$.System.Action))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21477720177, 42951377004)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25772687473, 51541311596)
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<TResult>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772687473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return $.$$.System.Threading.Tasks.Task.FromResult(TResult, workItem.Invoke());
                }
                /*var*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$$.System.Func$$(TResult)));
                    try
                    {
                        /*var*/ let res = state.Item2.Invoke();
                        state.Item1.SetResult(res);
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$$.System.Func$$(TResult)))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25772687473, 51541311596)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30067654769, 47246344300)
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067654769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource, $.$$.System.Func$$($.$$.System.Threading.Tasks.Task)));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$10(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  (/**/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException$1(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult();
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": 177537025
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource, $.$$.System.Func$$($.$$.System.Threading.Tasks.Task)))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30067654769, 47246344300)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34362622065, 55836278892)
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362622065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new ($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$$.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$(TResult))));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$34(new ($.$$.System.Action$$($.$$.System.Threading.Tasks.Task$$(TResult)))().$ctor(this,  (/*t*/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException$1(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult(t.Result);
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "t",
      "p": (TResult) => $.$$.System.Threading.Tasks.Task$$(TResult).$h
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825794
}), $.$$.System.Threading.Tasks.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException$1(ex);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "o",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2883697,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$(TResult))))().$ctor$3(tcs, workItem));
                return tcs.Task;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34362622065, 55836278892)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2883697;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1704044,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 17182752881, 25771507820),
    {
      "r": 262145,
      "n": "CheckAccess",
      "d": 2883697,
      "h": 17182752881,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17182752881, 25771507820),
//--TRIMMABLE-BOUNDARY-START(ALL, 21477720177, 42951377004),
    {
      "r": 177537025,
      "p": [
        {
          "n": "workItem",
          "p": 42270721
        }
      ],
      "n": "InvokeAsync",
      "d": 2883697,
      "h": 21477720177,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21477720177, 42951377004),
//--TRIMMABLE-BOUNDARY-START(ALL, 25772687473, 51541311596),
    {
      "r": (TResult) => $.$$.System.Threading.Tasks.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.System.Func$$(TResult).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$3",
      "d": 2883697,
      "h": 25772687473,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25772687473, 51541311596),
//--TRIMMABLE-BOUNDARY-START(ALL, 30067654769, 47246344300),
    {
      "r": 177537025,
      "p": [
        {
          "n": "workItem",
          "p": $.$$.System.Func$$($.$$.System.Threading.Tasks.Task).$h
        }
      ],
      "n": "InvokeAsync",
      "o": "@$1",
      "d": 2883697,
      "h": 30067654769,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30067654769, 47246344300),
//--TRIMMABLE-BOUNDARY-START(ALL, 34362622065, 55836278892),
    {
      "r": (TResult) => $.$$.System.Threading.Tasks.Task$$(TResult).$h,
      "p": [
        {
          "n": "workItem",
          "p": (TResult) => $.$$.System.Func$$($.$$.System.Threading.Tasks.Task$$(TResult)).$h
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "InvokeAsync",
      "o": "@$2",
      "d": 2883697,
      "h": 34362622065,
      "f": 16941057
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34362622065, 55836278892)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592818289),
    {
      "t": 175177729,
      "n": "_mainSynchronizationContext",
      "d": 2883697,
      "h": 8592818289,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8592818289),
//--TRIMMABLE-BOUNDARY-START(4297850993),
    {
      "t": 655361,
      "n": "_mainManagedThreadId",
      "d": 2883697,
      "h": 4297850993,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4297850993)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887785585),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2883697,
      "h": 12887785585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887785585)
  ],
  "h": 2883697
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Dispatcher; }
            static get $fullName() { return `WebAssemblyDispatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883697)
        
        
        //--TRIMMABLE-BOUNDARY-START(131185)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentMarker", ($self) => class ComponentMarker extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(171798823025)
            /*string*/ static ServerMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(171798823025)
            
            //--TRIMMABLE-BOUNDARY-START(266288103537)
            /*string*/ static WebAssemblyMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(266288103537)
            
            //--TRIMMABLE-BOUNDARY-START(51539738737)
            /*string*/ static AutoMarkerType = null;
            //--TRIMMABLE-BOUNDARY-END(51539738737)
            
            //--TRIMMABLE-BOUNDARY-START(257698168945)
            /*string?*/ Type = null;
            //--TRIMMABLE-BOUNDARY-END(257698168945)
            
            //--TRIMMABLE-BOUNDARY-START(163208888433)
            /*string?*/ PrerenderId = null;
            //--TRIMMABLE-BOUNDARY-END(163208888433)
            
            //--TRIMMABLE-BOUNDARY-START(150323986545)
            /*ComponentMarkerKey?*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(150323986545)
            
            //--TRIMMABLE-BOUNDARY-START(167503855729)
            /*int?*/ Sequence = null;
            //--TRIMMABLE-BOUNDARY-END(167503855729)
            
            //--TRIMMABLE-BOUNDARY-START(60129673329)
            /*string?*/ Descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(60129673329)
            
            //--TRIMMABLE-BOUNDARY-START(47244771441)
            /*string?*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(47244771441)
            
            //--TRIMMABLE-BOUNDARY-START(261993136241)
            /*string?*/ TypeName = null;
            //--TRIMMABLE-BOUNDARY-END(261993136241)
            
            //--TRIMMABLE-BOUNDARY-START(154618953841)
            /*string?*/ ParameterDefinitions = null;
            //--TRIMMABLE-BOUNDARY-END(154618953841)
            
            //--TRIMMABLE-BOUNDARY-START(158913921137)
            /*string?*/ ParameterValues = null;
            //--TRIMMABLE-BOUNDARY-END(158913921137)
            
            //--TRIMMABLE-BOUNDARY-START(55834706033)
            static /*ComponentMarker */ Create(/*string*/ type, /*bool*/ prerendered, /*ComponentMarkerKey?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker()
                    const $t1 = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker;
                    const $i1 = new $t1();
                    $i1.Type = type;
                    $i1.PrerenderId = prerendered ? $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.GeneratePrerenderId() : null;
                    $i1.Key = key?.Clone() ?? null;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55834706033)
            
            //--TRIMMABLE-BOUNDARY-START(270583070833)
            /*void */ WriteServerData(/*int*/ sequence, /*string*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583070833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Sequence = sequence;
                this.Descriptor = descriptor;
            }
            //--TRIMMABLE-BOUNDARY-END(270583070833)
            
            //--TRIMMABLE-BOUNDARY-START(274878038129)
            /*void */ WriteWebAssemblyData(/*string*/ assembly, /*string*/ typeName, /*string*/ parameterDefinitions, /*string*/ parameterValues)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878038129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Assembly = assembly;
                this.TypeName = typeName;
                this.ParameterDefinitions = parameterDefinitions;
                this.ParameterValues = parameterValues;
            }
            //--TRIMMABLE-BOUNDARY-END(274878038129)
            
            //--TRIMMABLE-BOUNDARY-START(253403201649)
            /*ComponentEndMarker? */ ToEndMarker()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253403201649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.PrerenderId === null ? new ($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker))() : (() =>
                    {
                        //new $.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker()
                        const $t1 = $.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker;
                        const $i1 = new $t1();
                        $i1.PrerenderId = this.PrerenderId;
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403201649)
            
            //--TRIMMABLE-BOUNDARY-START(64424640625)
            static /*string */ GeneratePrerenderId()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640625);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Guid.NewGuid().ToString$2("N");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424640625)
            
            //--TRIMMABLE-BOUNDARY-START(146029019249)
            /*string */ GetDebuggerDisplay()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029019249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                switch(this.Type)
                {
                    case "server"/*ServerMarkerType*/:
                    const $t2 = this.Descriptor;
                    return `Server Component: ${this.TypeName}, Sequence: ${this.Sequence}, Key: ${(this.Key?.FormattedComponentKey ?? null)} Descriptor: ${$.$ifnn($t2, ($t) => $.$$.System.String.Substring$1.call($t, 5))}...`;
                    case "webassembly"/*WebAssemblyMarkerType*/:
                    return `WebAssembly Component: ${this.TypeName}, Assembly: ${this.Assembly}, Key: ${(this.Key?.FormattedComponentKey ?? null)}`;
                    case "auto"/*AutoMarkerType*/:
                    const $t3 = this.Descriptor;
                    return `Auto Component: ${this.TypeName}, Assembly: ${this.Assembly}, Key: ${(this.Key?.FormattedComponentKey ?? null)}, Descriptor: ${$.$ifnn($t3, ($t) => $.$$.System.String.Substring$1.call($t, 5))}...`;
                    default:
                    return `Unknown Component Type: ${this.Type}, Key: ${(this.Key?.FormattedComponentKey ?? null)}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029019249)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.PrerenderId = this.PrerenderId;
                copy.Key = this.Key.Clone();
                copy.Sequence = this.Sequence;
                copy.Descriptor = this.Descriptor;
                copy.Assembly = this.Assembly;
                copy.TypeName = this.TypeName;
                copy.ParameterDefinitions = this.ParameterDefinitions;
                copy.ParameterValues = this.ParameterValues;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Key = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(171798823025)
                    this.ServerMarkerType = "server";
                    //--TRIMMABLE-BOUNDARY-END(171798823025)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288103537)
                    this.WebAssemblyMarkerType = "webassembly";
                    //--TRIMMABLE-BOUNDARY-END(266288103537)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539738737)
                    this.AutoMarkerType = "auto";
                    //--TRIMMABLE-BOUNDARY-END(51539738737)
                    
                }
            }
            static $h = 131185;
            static $z = 42;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(257698168945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144117361,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518299761,
        "f": 83886081
      },
      "n": "Type",
      "d": 131185,
      "h": 257698168945,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698168945),
//--TRIMMABLE-BOUNDARY-START(163208888433),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964248177,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338430577,
        "f": 83886081
      },
      "n": "PrerenderId",
      "d": 131185,
      "h": 163208888433,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163208888433),
//--TRIMMABLE-BOUNDARY-START(150323986545),
    {
      "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194444401,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568626801,
        "f": 83886081
      },
      "n": "Key",
      "d": 131185,
      "h": 150323986545,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150323986545),
//--TRIMMABLE-BOUNDARY-START(167503855729),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554182769,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928365169,
        "f": 83886081
      },
      "n": "Sequence",
      "d": 131185,
      "h": 167503855729,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503855729),
//--TRIMMABLE-BOUNDARY-START(60129673329),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604509809,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188978692209,
        "f": 83886081
      },
      "n": "Descriptor",
      "d": 131185,
      "h": 60129673329,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129673329),
//--TRIMMABLE-BOUNDARY-START(47244771441),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014575217,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388757617,
        "f": 83886081
      },
      "n": "Assembly",
      "d": 131185,
      "h": 47244771441,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244771441),
//--TRIMMABLE-BOUNDARY-START(261993136241),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051953,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108234353,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 131185,
      "h": 261993136241,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993136241),
//--TRIMMABLE-BOUNDARY-START(154618953841),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784378993,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158561393,
        "f": 83886081
      },
      "n": "ParameterDefinitions",
      "d": 131185,
      "h": 154618953841,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154618953841),
//--TRIMMABLE-BOUNDARY-START(158913921137),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374313585,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748495985,
        "f": 83886081
      },
      "n": "ParameterValues",
      "d": 131185,
      "h": 158913921137,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158913921137)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834706033),
    {
      "r": 131185,
      "p": [
        {
          "n": "type",
          "p": 1310721
        },
        {
          "n": "prerendered",
          "p": 262145
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
        }
      ],
      "n": "Create",
      "d": 131185,
      "h": 55834706033,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834706033),
//--TRIMMABLE-BOUNDARY-START(270583070833),
    {
      "r": 65537,
      "p": [
        {
          "n": "sequence",
          "p": 655361
        },
        {
          "n": "descriptor",
          "p": 1310721
        }
      ],
      "n": "WriteServerData",
      "d": 131185,
      "h": 270583070833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583070833),
//--TRIMMABLE-BOUNDARY-START(274878038129),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 1310721
        },
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "parameterDefinitions",
          "p": 1310721
        },
        {
          "n": "parameterValues",
          "p": 1310721
        }
      ],
      "n": "WriteWebAssemblyData",
      "d": 131185,
      "h": 274878038129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878038129),
//--TRIMMABLE-BOUNDARY-START(253403201649),
    {
      "r": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker).$h,
      "n": "ToEndMarker",
      "d": 131185,
      "h": 253403201649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403201649),
//--TRIMMABLE-BOUNDARY-START(64424640625),
    {
      "r": 1310721,
      "n": "GeneratePrerenderId",
      "d": 131185,
      "h": 64424640625,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424640625),
//--TRIMMABLE-BOUNDARY-START(146029019249),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 131185,
      "h": 146029019249,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029019249)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(171798823025),
    {
      "t": 1310721,
      "n": "ServerMarkerType",
      "d": 131185,
      "h": 171798823025,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171798823025),
//--TRIMMABLE-BOUNDARY-START(266288103537),
    {
      "t": 1310721,
      "n": "WebAssemblyMarkerType",
      "d": 131185,
      "h": 266288103537,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288103537),
//--TRIMMABLE-BOUNDARY-START(51539738737),
    {
      "t": 1310721,
      "n": "AutoMarkerType",
      "d": 131185,
      "h": 51539738737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539738737)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098481),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131185,
      "h": 4295098481,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098481)
  ],
  "h": 131185,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ComponentMarker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131185)
        
        
        //--TRIMMABLE-BOUNDARY-START(65649)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker", ($self) => class ComponentEndMarker extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21474902129)
            /*string?*/ PrerenderId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902129)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PrerenderId = this.PrerenderId;
                return copy;
            }
            static $h = 65649;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474902129),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934833,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30064836721,
        "f": 83886081
      },
      "n": "PrerenderId",
      "d": 65649,
      "h": 21474902129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474902129)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032945),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65649,
      "h": 4295032945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032945)
  ],
  "h": 65649
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `ComponentEndMarker`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65649)
        
        
        //--TRIMMABLE-BOUNDARY-START(196721)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey", ($self) => class ComponentMarkerKey extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295164017)
            $ctor$3(/*string*/ locationHash, /*string?*/ formattedComponentKey)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295164017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$tupleUnpack(($tp) =>
                    {
                        this.LocationHash = $tp.Item1;
                        this.FormattedComponentKey = $tp.Item2;
                    }).$v = { Item1: locationHash, Item2: formattedComponentKey };
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295164017)
            
            //--TRIMMABLE-BOUNDARY-START(60129738865)
            /*string*/ LocationHash = null;
            //--TRIMMABLE-BOUNDARY-END(60129738865)
            
            //--TRIMMABLE-BOUNDARY-START(30064967793)
            /*string?*/ FormattedComponentKey = null;
            //--TRIMMABLE-BOUNDARY-END(30064967793)
            
            //--TRIMMABLE-BOUNDARY-START(64424706161)
            static /*bool */ op_Equality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                {
                    return left.Equals$2(right.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424706161)
            
            //--TRIMMABLE-BOUNDARY-START(68719673457)
            static /*bool */ op_Inequality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                {
                    return !($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719673457)
            
            //--TRIMMABLE-BOUNDARY-START(21475033201)
            /*bool */ Equals$2(/*ComponentMarkerKey*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033201);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Equals$2(this.LocationHash, other.LocationHash, 4/*StringComparison.Ordinal*/) && $.$$.System.String.Equals$2(this.FormattedComponentKey, other.FormattedComponentKey, 4/*StringComparison.Ordinal*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033201)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770000497, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770000497, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55834771569, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834771569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.LocationHash, this.FormattedComponentKey);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55834771569, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(51539804273)
            /*string */ GetDebuggerDisplay()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `LocationHash: ${this.LocationHash}, Key: ${this.FormattedComponentKey ?? "null"}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539804273)
            
            //--TRIMMABLE-BOUNDARY-START(73014640753)
            /*string? */ Serialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Equality(this, new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey()) ? null : `${this.LocationHash}:${this.FormattedComponentKey}`;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640753)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentMarkerKey>.Equals(Microsoft.AspNetCore.Components.ComponentMarkerKey)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.LocationHash = this.LocationHash;
                copy.FormattedComponentKey = this.FormattedComponentKey;
                return copy;
            }
            static $h = 196721;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129738865),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194509937,
        "f": 83886081
      },
      "n": "LocationHash",
      "d": 196721,
      "h": 60129738865,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129738865),
//--TRIMMABLE-BOUNDARY-START(30064967793),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902385,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604575345,
        "f": 83886081
      },
      "n": "FormattedComponentKey",
      "d": 196721,
      "h": 30064967793,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064967793)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033201),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 196721
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 196721,
      "h": 21475033201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033201),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770000497, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196721,
      "h": 25770000497,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770000497, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 55834771569, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196721,
      "h": 55834771569,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55834771569, 184683724801),
//--TRIMMABLE-BOUNDARY-START(51539804273),
    {
      "r": 1310721,
      "n": "GetDebuggerDisplay",
      "d": 196721,
      "h": 51539804273,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539804273),
//--TRIMMABLE-BOUNDARY-START(73014640753),
    {
      "r": 1310721,
      "n": "Serialized",
      "d": 196721,
      "h": 73014640753,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014640753)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164017),
    {
      "p": [
        {
          "n": "locationHash",
          "p": 1310721
        },
        {
          "n": "formattedComponentKey",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196721,
      "h": 4295164017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164017),
//--TRIMMABLE-BOUNDARY-START(8590131313),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196721,
      "h": 8590131313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131313)
  ],
  "i": [$.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
  ],
  "h": 196721,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{GetDebuggerDisplay(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey) ]; }
            static get $fullName() { return `ComponentMarkerKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196721)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687089)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext", ($self) => class WebAssemblyJsonSerializerContext extends $.$stj.System.Text.Json.Serialization.JsonSerializerContext
        {
            //--TRIMMABLE-BOUNDARY-START(21477523569)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>?*/ _IListObject = null;
            //--TRIMMABLE-BOUNDARY-END(21477523569)
            
            //--TRIMMABLE-BOUNDARY-START(476744056945)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ get IListObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322125234289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._IListObject ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Collections.Generic.IList$$($.$$.System.Object).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(476744056945)
            
            //--TRIMMABLE-BOUNDARY-START(180391313521)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ Create_IListObject(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391313521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Collections.Generic.IList$$($.$$.System.Object), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = null;
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateIListInfo($.$$.System.Collections.Generic.IList$$($.$$.System.Object), $.$$.System.Object, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(180391313521)
            
            //--TRIMMABLE-BOUNDARY-START(25772490865)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>?*/ _Int32 = null;
            //--TRIMMABLE-BOUNDARY-END(25772490865)
            
            //--TRIMMABLE-BOUNDARY-START(485333991537)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ get Int32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330715168881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Int32 ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Int32.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(485333991537)
            
            //--TRIMMABLE-BOUNDARY-START(184686280817)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ Create_Int32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184686280817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Int32, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Int32, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.Int32Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(184686280817)
            
            //--TRIMMABLE-BOUNDARY-START(38657392753)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>?*/ _NullableComponentMarker = null;
            //--TRIMMABLE-BOUNDARY-END(38657392753)
            
            //--TRIMMABLE-BOUNDARY-START(498218893425)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ get NullableComponentMarker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484972657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)));
            }
            //--TRIMMABLE-BOUNDARY-END(498218893425)
            
            //--TRIMMABLE-BOUNDARY-START(197571182705)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ Create_NullableComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571182705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(197571182705)
            
            //--TRIMMABLE-BOUNDARY-START(30067458161)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>?*/ _Int64 = null;
            //--TRIMMABLE-BOUNDARY-END(30067458161)
            
            //--TRIMMABLE-BOUNDARY-START(489628958833)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ get Int64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339305103473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Int64 ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Int64.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int64));
            }
            //--TRIMMABLE-BOUNDARY-END(489628958833)
            
            //--TRIMMABLE-BOUNDARY-START(188981248113)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ Create_Int64(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981248113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Int64, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int64))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Int64, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.Int64Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(188981248113)
            
            //--TRIMMABLE-BOUNDARY-START(47247327345)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>?*/ _NullableInt32 = null;
            //--TRIMMABLE-BOUNDARY-END(47247327345)
            
            //--TRIMMABLE-BOUNDARY-START(506808828017)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ get NullableInt32()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373664841841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableInt32 ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$$.System.Int32).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(506808828017)
            
            //--TRIMMABLE-BOUNDARY-START(206161117297)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ Create_NullableInt32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161117297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$$.System.Int32), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$$.System.Int32)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter($.$$.System.Int32, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$$.System.Int32), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(206161117297)
            
            //--TRIMMABLE-BOUNDARY-START(51542294641)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>?*/ _Object = null;
            //--TRIMMABLE-BOUNDARY-END(51542294641)
            
            //--TRIMMABLE-BOUNDARY-START(511103795313)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ get Object()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254776433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Object ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Object.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(511103795313)
            
            //--TRIMMABLE-BOUNDARY-START(210456084593)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ Create_Object(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210456084593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Object, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Object, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.ObjectConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(210456084593)
            
            //--TRIMMABLE-BOUNDARY-START(34362425457)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>?*/ _JsonElement = null;
            //--TRIMMABLE-BOUNDARY-END(34362425457)
            
            //--TRIMMABLE-BOUNDARY-START(493923926129)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ get JsonElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347895038065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._JsonElement ??= $.$cast(this.Options.GetTypeInfo($.$stj.System.Text.Json.JsonElement.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement));
            }
            //--TRIMMABLE-BOUNDARY-END(493923926129)
            
            //--TRIMMABLE-BOUNDARY-START(193276215409)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ Create_JsonElement(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193276215409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$stj.System.Text.Json.JsonElement, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$stj.System.Text.Json.JsonElement, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.JsonElementConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(193276215409)
            
            //--TRIMMABLE-BOUNDARY-START(42952360049)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>?*/ _NullableComponentMarkerKey = null;
            //--TRIMMABLE-BOUNDARY-END(42952360049)
            
            //--TRIMMABLE-BOUNDARY-START(502513860721)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ get NullableComponentMarkerKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365074907249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._NullableComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)));
            }
            //--TRIMMABLE-BOUNDARY-END(502513860721)
            
            //--TRIMMABLE-BOUNDARY-START(201866150001)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ Create_NullableComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201866150001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(201866150001)
            
            //--TRIMMABLE-BOUNDARY-START(55837261937)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>?*/ _ParameterView = null;
            //--TRIMMABLE-BOUNDARY-END(55837261937)
            
            //--TRIMMABLE-BOUNDARY-START(515398762609)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ get ParameterView()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390844711025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ParameterView ??= $.$cast(this.Options.GetTypeInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView));
            }
            //--TRIMMABLE-BOUNDARY-END(515398762609)
            
            //--TRIMMABLE-BOUNDARY-START(214751051889)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ Create_ParameterView(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751051889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor(this,  () =>
                        {
                            return new $.$mac.Microsoft.AspNetCore.Components.ParameterView().$ctor$2();
                        }, {
  "r": 5767276,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/**/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ParameterViewPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor(this, this.ParameterViewSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(214751051889)
            
            //--TRIMMABLE-BOUNDARY-START(519693729905)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ParameterViewPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519693729905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [0], null);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(519693729905)
            
            //--TRIMMABLE-BOUNDARY-START(523988697201)
            /*void */ ParameterViewSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ParameterView*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523988697201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(523988697201)
            
            //--TRIMMABLE-BOUNDARY-START(597003141233)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_type;
            //--TRIMMABLE-BOUNDARY-END(597003141233)
            
            //--TRIMMABLE-BOUNDARY-START(584118239345)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_prerenderId;
            //--TRIMMABLE-BOUNDARY-END(584118239345)
            
            //--TRIMMABLE-BOUNDARY-START(549758500977)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_key;
            //--TRIMMABLE-BOUNDARY-END(549758500977)
            
            //--TRIMMABLE-BOUNDARY-START(588413206641)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_sequence;
            //--TRIMMABLE-BOUNDARY-END(588413206641)
            
            //--TRIMMABLE-BOUNDARY-START(541168566385)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_descriptor;
            //--TRIMMABLE-BOUNDARY-END(541168566385)
            
            //--TRIMMABLE-BOUNDARY-START(528283664497)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_assembly;
            //--TRIMMABLE-BOUNDARY-END(528283664497)
            
            //--TRIMMABLE-BOUNDARY-START(601298108529)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_typeName;
            //--TRIMMABLE-BOUNDARY-END(601298108529)
            
            //--TRIMMABLE-BOUNDARY-START(571233337457)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterDefinitions;
            //--TRIMMABLE-BOUNDARY-END(571233337457)
            
            //--TRIMMABLE-BOUNDARY-START(579823272049)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterValues;
            //--TRIMMABLE-BOUNDARY-END(579823272049)
            
            //--TRIMMABLE-BOUNDARY-START(554053468273)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_locationHash;
            //--TRIMMABLE-BOUNDARY-END(554053468273)
            
            //--TRIMMABLE-BOUNDARY-START(545463533681)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_formattedComponentKey;
            //--TRIMMABLE-BOUNDARY-END(545463533681)
            
            //--TRIMMABLE-BOUNDARY-START(562643402865)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_name;
            //--TRIMMABLE-BOUNDARY-END(562643402865)
            
            //--TRIMMABLE-BOUNDARY-START(592708173937)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_ssrComponentId;
            //--TRIMMABLE-BOUNDARY-END(592708173937)
            
            //--TRIMMABLE-BOUNDARY-START(558348435569)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_marker;
            //--TRIMMABLE-BOUNDARY-END(558348435569)
            
            //--TRIMMABLE-BOUNDARY-START(532578631793)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_batchId;
            //--TRIMMABLE-BOUNDARY-END(532578631793)
            
            //--TRIMMABLE-BOUNDARY-START(566938370161)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_operations;
            //--TRIMMABLE-BOUNDARY-END(566938370161)
            
            //--TRIMMABLE-BOUNDARY-START(536873599089)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_componentType;
            //--TRIMMABLE-BOUNDARY-END(536873599089)
            
            //--TRIMMABLE-BOUNDARY-START(575528304753)
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameters;
            //--TRIMMABLE-BOUNDARY-END(575528304753)
            
            //--TRIMMABLE-BOUNDARY-START(12887588977)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>?*/ _ComponentParameter = null;
            //--TRIMMABLE-BOUNDARY-END(12887588977)
            
            //--TRIMMABLE-BOUNDARY-START(141736607857)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ get ComponentParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287765495921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentParameter ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter));
            }
            //--TRIMMABLE-BOUNDARY-END(141736607857)
            
            //--TRIMMABLE-BOUNDARY-START(171801378929)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ Create_ComponentParameter(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801378929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter().$ctor$2();
                        }, {
  "r": 262257,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentParameterPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor(this, this.ComponentParameterSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(171801378929)
            
            //--TRIMMABLE-BOUNDARY-START(154621509745)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentParameterPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621509745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [3], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).Name;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/**/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.Name = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Name";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty("Name", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).TypeName;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /**/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.TypeName = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "TypeName";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).Assembly;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.Assembly = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Assembly";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i3;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info2), 2);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(154621509745)
            
            //--TRIMMABLE-BOUNDARY-START(158916477041)
            /*void */ ComponentParameterSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916477041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_Name = (value).Name;
                if (!(__value_Name === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_name, __value_Name);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(158916477041)
            
            //--TRIMMABLE-BOUNDARY-START(68722163825)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>?*/ _RootComponentOperationBatch = null;
            //--TRIMMABLE-BOUNDARY-END(68722163825)
            
            //--TRIMMABLE-BOUNDARY-START(618477977713)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ get RootComponentOperationBatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416614514801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationBatch ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch));
            }
            //--TRIMMABLE-BOUNDARY-END(618477977713)
            
            //--TRIMMABLE-BOUNDARY-START(227635953777)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ Create_RootComponentOperationBatch(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635953777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.ObjectWithParameterizedConstructorCreator = new ($.$$.System.Func$$$($.$typeArray($.$$.System.Object), $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return (() =>
                            {
                                //new $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch()
                                const $t3 = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch;
                                const $i3 = new $t3();
                                $i3.Operations = $.$cast($.$$.System.Array.$ReadT1.call(args, 0), $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                                return $i3;
                            })();
                        }, {
  "r": 1048689,
  "p": [
    {
      "n": "args",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationBatchPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = new ($.$$.System.Func$$($.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationBatchCtorParamInit);
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))().$ctor(this, this.RootComponentOperationBatchSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(227635953777)
            
            //--TRIMMABLE-BOUNDARY-START(627067912305)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationBatchPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627067912305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Int64)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Int64);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Int64))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).BatchId;
                    }, {
  "r": 917505,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Int64))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).BatchId = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 917505
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "BatchId";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetProperty("BatchId", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.Int64.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.Int64, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).Operations;
                    }, {
  "r": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).Operations = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "Operations";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetProperty("Operations", 52/*InstanceMemberBindingFlags*/, null, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation), options, info1), 1);
                $.$$.System.Array.$ReadT1.call(properties, 1).IsRequired = true;
                $.$$.System.Array.$ReadT1.call(properties, 1).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 1).IsSetNullable = false;
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(627067912305)
            
            //--TRIMMABLE-BOUNDARY-START(631362879601)
            /*void */ RootComponentOperationBatchSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperationBatch?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631362879601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WriteNumber$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_batchId, (value).BatchId);
                /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]*/ let __value_Operations = (value).Operations;
                if (!(__value_Operations === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_operations);
                    this.RootComponentOperationArraySerializeHandler(writer, __value_Operations);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(631362879601)
            
            //--TRIMMABLE-BOUNDARY-START(622772945009)
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ RootComponentOperationBatchCtorParamInit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(622772945009);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues), [(() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                        const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Name = "Operations";
                        $i1.ParameterType = $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type;
                        $i1.Position = 0;
                        $i1.IsNullable = false;
                        $i1.IsMemberInitializer = true;
                        return $i1;
                    })()], [-1], null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(622772945009)
            
            //--TRIMMABLE-BOUNDARY-START(85902033009)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>?*/ _WebRootComponentDescriptor = null;
            //--TRIMMABLE-BOUNDARY-END(85902033009)
            
            //--TRIMMABLE-BOUNDARY-START(665722617969)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ get WebRootComponentDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450974253169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._WebRootComponentDescriptor ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor));
            }
            //--TRIMMABLE-BOUNDARY-END(665722617969)
            
            //--TRIMMABLE-BOUNDARY-START(244815822961)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ Create_WebRootComponentDescriptor(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815822961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.ObjectWithParameterizedConstructorCreator = new ($.$$.System.Func$$$($.$typeArray($.$$.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor().$ctor$1($.$cast($.$$.System.Array.$ReadT1.call(args, 0), $.$$.System.Type), $.$cast($.$$.System.Array.$ReadT1.call(args, 1), $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters));
                        }, {
  "r": 4325489,
  "p": [
    {
      "n": "args",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = new ($.$$.System.Func$$($.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorCtorParamInit);
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.Type.$type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type], null, null), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor(this, this.WebRootComponentDescriptorSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(244815822961)
            
            //--TRIMMABLE-BOUNDARY-START(674312552561)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentDescriptorPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674312552561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Type)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Type);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)).ComponentType;
                    }, {
  "r": 187629569,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = null;
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "ComponentType";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetProperty("ComponentType", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.Type.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.Type, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)).Parameters;
                    }, {
  "r": 4391025,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = null;
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "Parameters";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetProperty("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, info1), 1);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(674312552561)
            
            //--TRIMMABLE-BOUNDARY-START(678607519857)
            /*void */ WebRootComponentDescriptorSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678607519857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                /*global::System.Type*/ let __value_ComponentType = (value).ComponentType;
                if (!(__value_ComponentType === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_componentType);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$$.System.Type, writer, __value_ComponentType, this.Type);
                }
                writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.WebRootComponentParametersSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(678607519857)
            
            //--TRIMMABLE-BOUNDARY-START(670017585265)
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ WebRootComponentDescriptorCtorParamInit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(670017585265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues), [(() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                        const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Name = "componentType";
                        $i1.ParameterType = $.$$.System.Type.$type;
                        $i1.Position = 0;
                        $i1.HasDefaultValue = false;
                        $i1.DefaultValue = null;
                        $i1.IsNullable = false;
                        return $i1;
                    })(), (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Name = "parameters";
                        $i2.ParameterType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type;
                        $i2.Position = 1;
                        $i2.HasDefaultValue = false;
                        $i2.DefaultValue = null;
                        $i2.IsNullable = false;
                        return $i2;
                    })()], [-1], null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(670017585265)
            
            //--TRIMMABLE-BOUNDARY-START(73017131121)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>?*/ _RootComponentOperationType = null;
            //--TRIMMABLE-BOUNDARY-END(73017131121)
            
            //--TRIMMABLE-BOUNDARY-START(644247781489)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ get RootComponentOperationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204449393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationType ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType));
            }
            //--TRIMMABLE-BOUNDARY-END(644247781489)
            
            //--TRIMMABLE-BOUNDARY-START(231930921073)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ Create_RootComponentOperationType(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930921073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ExpandConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type, new ($.$stj.System.Text.Json.Serialization.JsonStringEnumConverter$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor$3(), options, true);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(231930921073)
            
            //--TRIMMABLE-BOUNDARY-START(17182556273)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>?*/ _ComponentParameterArray = null;
            //--TRIMMABLE-BOUNDARY-END(17182556273)
            
            //--TRIMMABLE-BOUNDARY-START(146031575153)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ get ComponentParameterArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355430513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentParameterArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)));
            }
            //--TRIMMABLE-BOUNDARY-END(146031575153)
            
            //--TRIMMABLE-BOUNDARY-START(176096346225)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ Create_ComponentParameterArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096346225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)))().$ctor(this, this.ComponentParameterArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(176096346225)
            
            //--TRIMMABLE-BOUNDARY-START(150326542449)
            /*void */ ComponentParameterArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326542449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.ComponentParameterSerializeHandler(writer, $.$$.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            //--TRIMMABLE-BOUNDARY-END(150326542449)
            
            //--TRIMMABLE-BOUNDARY-START(77312098417)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            //--TRIMMABLE-BOUNDARY-END(77312098417)
            
            //--TRIMMABLE-BOUNDARY-START(652837716081)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433794383985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$$.System.String.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(652837716081)
            
            //--TRIMMABLE-BOUNDARY-START(236225888369)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225888369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.String, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(236225888369)
            
            //--TRIMMABLE-BOUNDARY-START(81607065713)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>?*/ _Type = null;
            //--TRIMMABLE-BOUNDARY-END(81607065713)
            
            //--TRIMMABLE-BOUNDARY-START(661427650673)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442384318577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._Type ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Type.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Type));
            }
            //--TRIMMABLE-BOUNDARY-END(661427650673)
            
            //--TRIMMABLE-BOUNDARY-START(240520855665)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ Create_Type(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520855665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Type, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Type))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.Type, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetUnsupportedTypeConverter($.$$.System.Type));
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(240520855665)
            
            //--TRIMMABLE-BOUNDARY-START(90197000305)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>?*/ _WebRootComponentParameters = null;
            //--TRIMMABLE-BOUNDARY-END(90197000305)
            
            //--TRIMMABLE-BOUNDARY-START(682902487153)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ get WebRootComponentParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459564187761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._WebRootComponentParameters ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters));
            }
            //--TRIMMABLE-BOUNDARY-END(682902487153)
            
            //--TRIMMABLE-BOUNDARY-START(249110790257)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ Create_WebRootComponentParameters(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110790257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$2();
                        }, {
  "r": 4391025,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentParametersPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor(this, this.WebRootComponentParametersSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(249110790257)
            
            //--TRIMMABLE-BOUNDARY-START(687197454449)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentParametersPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687197454449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [1], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)).Parameters;
                    }, {
  "r": 5767276,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = null;
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Parameters";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type.GetProperty("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, info0), 0);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(687197454449)
            
            //--TRIMMABLE-BOUNDARY-START(691492421745)
            /*void */ WebRootComponentParametersSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentParameters*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691492421745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.ParameterViewSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(691492421745)
            
            //--TRIMMABLE-BOUNDARY-START(648542748785)
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            //--TRIMMABLE-BOUNDARY-END(648542748785)
            
            //--TRIMMABLE-BOUNDARY-START(481039024241)
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            //--TRIMMABLE-BOUNDARY-END(481039024241)
            
            //--TRIMMABLE-BOUNDARY-START(253405757553)
            /*global::Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(253405757553)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 261995692145, 17195008084)
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 261995692145, 17195008084)
            
            //--TRIMMABLE-BOUNDARY-START(98786934897)
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786934897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(98786934897)
            
            //--TRIMMABLE-BOUNDARY-START(103081902193)
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081902193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(103081902193)
            
            //--TRIMMABLE-BOUNDARY-START(657132683377)
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657132683377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(657132683377)
            
            //--TRIMMABLE-BOUNDARY-START(463859155057)
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859155057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < options.Converters.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.System$Collections$Generic$IList$$$get_Item(i, [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(463859155057)
            
            //--TRIMMABLE-BOUNDARY-START(257700724849)
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700724849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$8("The converter '{0}' is not compatible with the type '{1}'.", $.$$.System.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$9("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$$.System.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            //--TRIMMABLE-BOUNDARY-END(257700724849)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 468154122353, 38669844564)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468154122353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo));
                return typeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 468154122353, 38669844564)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 472449089649, 4311285844)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449089649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type))
                {
                    return this.Create_ComponentMarker(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type))
                {
                    return this.Create_NullableComponentMarker(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type))
                {
                    return this.Create_ComponentMarkerKey(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type))
                {
                    return this.Create_NullableComponentMarkerKey(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type))
                {
                    return this.Create_ComponentParameter(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$type))
                {
                    return this.Create_ComponentParameterArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type))
                {
                    return this.Create_ParameterView(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type))
                {
                    return this.Create_RootComponentOperation(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type))
                {
                    return this.Create_RootComponentOperationArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type))
                {
                    return this.Create_RootComponentOperationBatch(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type))
                {
                    return this.Create_RootComponentOperationType(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type))
                {
                    return this.Create_WebRootComponentDescriptor(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type))
                {
                    return this.Create_WebRootComponentParameters(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Collections.Generic.IList$$($.$$.System.Object).$type))
                {
                    return this.Create_IListObject(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$stj.System.Text.Json.JsonElement.$type))
                {
                    return this.Create_JsonElement(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Type.$type))
                {
                    return this.Create_Type(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int32.$type))
                {
                    return this.Create_Int32(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeNullable($.$$.System.Int32).$type))
                {
                    return this.Create_NullableInt32(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Int64.$type))
                {
                    return this.Create_Int64(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Object.$type))
                {
                    return this.Create_Object(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type))
                {
                    return this.Create_String(options);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 472449089649, 4311285844)
            
            //--TRIMMABLE-BOUNDARY-START(4297654385)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>?*/ _ComponentMarker = null;
            //--TRIMMABLE-BOUNDARY-END(4297654385)
            
            //--TRIMMABLE-BOUNDARY-START(115966804081)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ get ComponentMarker()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270585626737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker));
            }
            //--TRIMMABLE-BOUNDARY-END(115966804081)
            
            //--TRIMMABLE-BOUNDARY-START(163211444337)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ Create_ComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211444337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker().$ctor$2();
                        }, {
  "r": 131185,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentMarkerPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))().$ctor(this, this.ComponentMarkerSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(163211444337)
            
            //--TRIMMABLE-BOUNDARY-START(133146673265)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146673265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [9], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Type;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Type = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Type";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("Type", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).PrerenderId;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.PrerenderId = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "PrerenderId";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("PrerenderId", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey));
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Key;
                    }, {
  "r": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Key = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Key";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("Key", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i3;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$$.System.Int32))()
                    const $t4 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$$.System.Int32));
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.IsProperty = true;
                    $i4.IsPublic = true;
                    $i4.IsVirtual = false;
                    $i4.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i4.Converter = null;
                    $i4.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Sequence;
                    }, {
  "r": $.$typeNullable($.$$.System.Int32).$h,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i4.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Sequence = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": $.$typeNullable($.$$.System.Int32).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i4.IgnoreCondition = null;
                    $i4.HasJsonInclude = false;
                    $i4.IsExtensionData = false;
                    $i4.NumberHandling = null;
                    $i4.PropertyName = "Sequence";
                    $i4.JsonPropertyName = null;
                    $i4.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("Sequence", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$$.System.Int32).$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i4;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$$.System.Int32), options, info3), 3);
                /*var*/ let info4 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t5 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.IsProperty = true;
                    $i5.IsPublic = true;
                    $i5.IsVirtual = false;
                    $i5.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i5.Converter = null;
                    $i5.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Descriptor;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i5.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Descriptor = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i5.IgnoreCondition = null;
                    $i5.HasJsonInclude = false;
                    $i5.IsExtensionData = false;
                    $i5.NumberHandling = null;
                    $i5.PropertyName = "Descriptor";
                    $i5.JsonPropertyName = null;
                    $i5.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i5;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info4), 4);
                /*var*/ let info5 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t6 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.IsProperty = true;
                    $i6.IsPublic = true;
                    $i6.IsVirtual = false;
                    $i6.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i6.Converter = null;
                    $i6.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Assembly;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i6.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Assembly = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i6.IgnoreCondition = null;
                    $i6.HasJsonInclude = false;
                    $i6.IsExtensionData = false;
                    $i6.NumberHandling = null;
                    $i6.PropertyName = "Assembly";
                    $i6.JsonPropertyName = null;
                    $i6.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i6;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info5), 5);
                /*var*/ let info6 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t7 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.IsProperty = true;
                    $i7.IsPublic = true;
                    $i7.IsVirtual = false;
                    $i7.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i7.Converter = null;
                    $i7.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).TypeName;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i7.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.TypeName = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i7.IgnoreCondition = null;
                    $i7.HasJsonInclude = false;
                    $i7.IsExtensionData = false;
                    $i7.NumberHandling = null;
                    $i7.PropertyName = "TypeName";
                    $i7.JsonPropertyName = null;
                    $i7.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i7;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info6), 6);
                /*var*/ let info7 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t8 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.IsProperty = true;
                    $i8.IsPublic = true;
                    $i8.IsVirtual = false;
                    $i8.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i8.Converter = null;
                    $i8.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).ParameterDefinitions;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i8.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.ParameterDefinitions = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i8.IgnoreCondition = null;
                    $i8.HasJsonInclude = false;
                    $i8.IsExtensionData = false;
                    $i8.NumberHandling = null;
                    $i8.PropertyName = "ParameterDefinitions";
                    $i8.JsonPropertyName = null;
                    $i8.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("ParameterDefinitions", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i8;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info7), 7);
                /*var*/ let info8 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t9 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.IsProperty = true;
                    $i9.IsPublic = true;
                    $i9.IsVirtual = false;
                    $i9.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i9.Converter = null;
                    $i9.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).ParameterValues;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i9.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.ParameterValues = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i9.IgnoreCondition = null;
                    $i9.HasJsonInclude = false;
                    $i9.IsExtensionData = false;
                    $i9.NumberHandling = null;
                    $i9.PropertyName = "ParameterValues";
                    $i9.JsonPropertyName = null;
                    $i9.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty("ParameterValues", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i9;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info8), 8);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(133146673265)
            
            //--TRIMMABLE-BOUNDARY-START(137441640561)
            /*void */ ComponentMarkerSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarker*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441640561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_Type = (value).Type;
                if (!(__value_Type === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_type, __value_Type);
                }
                /*string*/ let __value_PrerenderId = (value).PrerenderId;
                if (!(__value_PrerenderId === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_prerenderId, __value_PrerenderId);
                }
                /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey?*/ let __value_Key = (value).Key;
                if (!(__value_Key === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_key);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), writer, __value_Key?.Clone() ?? null, this.NullableComponentMarkerKey);
                }
                /*int?*/ let __value_Sequence = (value).Sequence;
                if (!(__value_Sequence === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_sequence);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$$.System.Int32), writer, __value_Sequence, this.NullableInt32);
                }
                /*string*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_descriptor, __value_Descriptor);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_ParameterDefinitions = (value).ParameterDefinitions;
                if (!(__value_ParameterDefinitions === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameterDefinitions, __value_ParameterDefinitions);
                }
                /*string*/ let __value_ParameterValues = (value).ParameterValues;
                if (!(__value_ParameterValues === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameterValues, __value_ParameterValues);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(137441640561)
            
            //--TRIMMABLE-BOUNDARY-START(60132229233)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>?*/ _RootComponentOperation = null;
            //--TRIMMABLE-BOUNDARY-END(60132229233)
            
            //--TRIMMABLE-BOUNDARY-START(605593075825)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ get RootComponentOperation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399434645617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperation ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
            }
            //--TRIMMABLE-BOUNDARY-END(605593075825)
            
            //--TRIMMABLE-BOUNDARY-START(219046019185)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ Create_RootComponentOperation(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046019185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation().$ctor$1();
                        }, {
  "r": 983153,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))().$ctor(this, this.RootComponentOperationSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(219046019185)
            
            //--TRIMMABLE-BOUNDARY-START(635657846897)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635657846897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [4], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Type;
                    }, {
  "r": 1114225,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Type = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1114225
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Type";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty("Type", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Int32)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Int32);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Int32))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).SsrComponentId;
                    }, {
  "r": 655361,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Int32))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).SsrComponentId = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 655361
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "SsrComponentId";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty("SsrComponentId", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.Int32.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.Int32, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker));
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Marker;
                    }, {
  "r": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Marker = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Marker";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty("Marker", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i3;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)()
                    const $t4 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.IsProperty = true;
                    $i4.IsPublic = true;
                    $i4.IsVirtual = false;
                    $i4.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i4.Converter = null;
                    $i4.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Descriptor;
                    }, {
  "r": 4325489,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i4.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Descriptor = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 4325489
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i4.IgnoreCondition = null;
                    $i4.HasJsonInclude = false;
                    $i4.IsExtensionData = false;
                    $i4.NumberHandling = null;
                    $i4.PropertyName = "Descriptor";
                    $i4.JsonPropertyName = null;
                    $i4.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i4;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, info3), 3);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(635657846897)
            
            //--TRIMMABLE-BOUNDARY-START(639952814193)
            /*void */ RootComponentOperationSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639952814193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_type);
                $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, writer, (value).Type, this.RootComponentOperationType);
                writer.WriteNumber$25($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_ssrComponentId, (value).SsrComponentId);
                /*global::Microsoft.AspNetCore.Components.ComponentMarker?*/ let __value_Marker = (value).Marker;
                if (!(__value_Marker === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_marker);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), writer, __value_Marker?.Clone() ?? null, this.NullableComponentMarker);
                }
                /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WritePropertyName$14($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_descriptor);
                    this.WebRootComponentDescriptorSerializeHandler(writer, __value_Descriptor);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(639952814193)
            
            //--TRIMMABLE-BOUNDARY-START(64427196529)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>?*/ _RootComponentOperationArray = null;
            //--TRIMMABLE-BOUNDARY-END(64427196529)
            
            //--TRIMMABLE-BOUNDARY-START(609888043121)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ get RootComponentOperationArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408024580209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._RootComponentOperationArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)));
            }
            //--TRIMMABLE-BOUNDARY-END(609888043121)
            
            //--TRIMMABLE-BOUNDARY-START(223340986481)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ Create_RootComponentOperationArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340986481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor(this, this.RootComponentOperationArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(223340986481)
            
            //--TRIMMABLE-BOUNDARY-START(614183010417)
            /*void */ RootComponentOperationArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614183010417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.RootComponentOperationSerializeHandler(writer, $.$$.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            //--TRIMMABLE-BOUNDARY-END(614183010417)
            
            //--TRIMMABLE-BOUNDARY-START(8592621681)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>?*/ _ComponentMarkerKey = null;
            //--TRIMMABLE-BOUNDARY-END(8592621681)
            
            //--TRIMMABLE-BOUNDARY-START(120261771377)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ get ComponentMarkerKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279175561329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey));
            }
            //--TRIMMABLE-BOUNDARY-END(120261771377)
            
            //--TRIMMABLE-BOUNDARY-START(167506411633)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ Create_ComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506411633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey().$ctor$2();
                        }, {
  "r": 196721,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$$.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentMarkerKeyPropInit(options);
                        }, {
  "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
  "p": [
    {
      "n": "_",
      "p": 15138900
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825794
});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetConstructor$1(52/*InstanceMemberBindingFlags*/, null, $.$$.System.Array.Empty($.$$.System.Type), null);
                        }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))().$ctor(this, this.ComponentMarkerKeySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(167506411633)
            
            //--TRIMMABLE-BOUNDARY-START(124556738673)
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerKeyPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556738673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).LocationHash;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, obj).$v.LocationHash = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "LocationHash";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetProperty("LocationHash", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i1;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info0), 0);
                $.$$.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$$.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$$.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).FormattedComponentKey;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "obj",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.Setter = new ($.$$.System.Action$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$$.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, obj).$v.FormattedComponentKey = value;
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "obj",
      "p": 131073
    },
    {
      "n": "value",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "FormattedComponentKey";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$$.System.Func$$($.$$.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetProperty("FormattedComponentKey", 52/*InstanceMemberBindingFlags*/, null, $.$$.System.String.$type, $.$$.System.Array.Empty($.$$.System.Type), null);
                    }, {
  "r": 114032641,
  "n": "",
  "d": 2687089,
  "h": 0,
  "f": 17825826
});
                    return $i2;
                })();
                $.$$.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$$.System.String, options, info1), 1);
                return properties;
            }
            //--TRIMMABLE-BOUNDARY-END(124556738673)
            
            //--TRIMMABLE-BOUNDARY-START(128851705969)
            /*void */ ComponentMarkerKeySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851705969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                /*string*/ let __value_LocationHash = (value).LocationHash;
                if (!(__value_LocationHash === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_locationHash, __value_LocationHash);
                }
                /*string*/ let __value_FormattedComponentKey = (value).FormattedComponentKey;
                if (!(__value_FormattedComponentKey === null))
                {
                    writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_formattedComponentKey, __value_FormattedComponentKey);
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(128851705969)
            
            //default member initializer
            constructor()
            {
                super();
                this.GeneratedSerializerOptions = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.s_defaultOptions;
            }
            //--TRIMMABLE-BOUNDARY-START(94491967601)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(597003141233)
                    this.PropName_type = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("type", null);
                    //--TRIMMABLE-BOUNDARY-END(597003141233)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(584118239345)
                    this.PropName_prerenderId = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("prerenderId", null);
                    //--TRIMMABLE-BOUNDARY-END(584118239345)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(549758500977)
                    this.PropName_key = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("key", null);
                    //--TRIMMABLE-BOUNDARY-END(549758500977)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(588413206641)
                    this.PropName_sequence = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("sequence", null);
                    //--TRIMMABLE-BOUNDARY-END(588413206641)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(541168566385)
                    this.PropName_descriptor = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("descriptor", null);
                    //--TRIMMABLE-BOUNDARY-END(541168566385)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528283664497)
                    this.PropName_assembly = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("assembly", null);
                    //--TRIMMABLE-BOUNDARY-END(528283664497)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(601298108529)
                    this.PropName_typeName = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("typeName", null);
                    //--TRIMMABLE-BOUNDARY-END(601298108529)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(571233337457)
                    this.PropName_parameterDefinitions = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("parameterDefinitions", null);
                    //--TRIMMABLE-BOUNDARY-END(571233337457)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(579823272049)
                    this.PropName_parameterValues = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("parameterValues", null);
                    //--TRIMMABLE-BOUNDARY-END(579823272049)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(554053468273)
                    this.PropName_locationHash = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("locationHash", null);
                    //--TRIMMABLE-BOUNDARY-END(554053468273)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(545463533681)
                    this.PropName_formattedComponentKey = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("formattedComponentKey", null);
                    //--TRIMMABLE-BOUNDARY-END(545463533681)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(562643402865)
                    this.PropName_name = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("name", null);
                    //--TRIMMABLE-BOUNDARY-END(562643402865)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(592708173937)
                    this.PropName_ssrComponentId = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("ssrComponentId", null);
                    //--TRIMMABLE-BOUNDARY-END(592708173937)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(558348435569)
                    this.PropName_marker = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("marker", null);
                    //--TRIMMABLE-BOUNDARY-END(558348435569)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532578631793)
                    this.PropName_batchId = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("batchId", null);
                    //--TRIMMABLE-BOUNDARY-END(532578631793)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(566938370161)
                    this.PropName_operations = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("operations", null);
                    //--TRIMMABLE-BOUNDARY-END(566938370161)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(536873599089)
                    this.PropName_componentType = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("componentType", null);
                    //--TRIMMABLE-BOUNDARY-END(536873599089)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(575528304753)
                    this.PropName_parameters = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("parameters", null);
                    //--TRIMMABLE-BOUNDARY-END(575528304753)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(648542748785)
                    this.s_defaultOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.DefaultIgnoreCondition = 3/*global::System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull*/;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(648542748785)
                    
                }
                {
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext().$ctor$3(new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$3($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.s_defaultOptions));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94491967601)
            
            static $h = 2687089;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 15138900,
  "p": [
//--TRIMMABLE-BOUNDARY-START(476744056945),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322125234289,
        "f": 50331649
      },
      "n": "IListObject",
      "d": 2687089,
      "h": 476744056945,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(476744056945),
//--TRIMMABLE-BOUNDARY-START(485333991537),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330715168881,
        "f": 50331649
      },
      "n": "Int32",
      "d": 2687089,
      "h": 485333991537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485333991537),
//--TRIMMABLE-BOUNDARY-START(498218893425),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356484972657,
        "f": 50331649
      },
      "n": "NullableComponentMarker",
      "d": 2687089,
      "h": 498218893425,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(498218893425),
//--TRIMMABLE-BOUNDARY-START(489628958833),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339305103473,
        "f": 50331649
      },
      "n": "Int64",
      "d": 2687089,
      "h": 489628958833,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(489628958833),
//--TRIMMABLE-BOUNDARY-START(506808828017),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$$.System.Int32)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373664841841,
        "f": 50331649
      },
      "n": "NullableInt32",
      "d": 2687089,
      "h": 506808828017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(506808828017),
//--TRIMMABLE-BOUNDARY-START(511103795313),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382254776433,
        "f": 50331649
      },
      "n": "Object",
      "d": 2687089,
      "h": 511103795313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(511103795313),
//--TRIMMABLE-BOUNDARY-START(493923926129),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347895038065,
        "f": 50331649
      },
      "n": "JsonElement",
      "d": 2687089,
      "h": 493923926129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(493923926129),
//--TRIMMABLE-BOUNDARY-START(502513860721),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365074907249,
        "f": 50331649
      },
      "n": "NullableComponentMarkerKey",
      "d": 2687089,
      "h": 502513860721,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(502513860721),
//--TRIMMABLE-BOUNDARY-START(515398762609),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390844711025,
        "f": 50331649
      },
      "n": "ParameterView",
      "d": 2687089,
      "h": 515398762609,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(515398762609),
//--TRIMMABLE-BOUNDARY-START(141736607857),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287765495921,
        "f": 50331649
      },
      "n": "ComponentParameter",
      "d": 2687089,
      "h": 141736607857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736607857),
//--TRIMMABLE-BOUNDARY-START(618477977713),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416614514801,
        "f": 50331649
      },
      "n": "RootComponentOperationBatch",
      "d": 2687089,
      "h": 618477977713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(618477977713),
//--TRIMMABLE-BOUNDARY-START(665722617969),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450974253169,
        "f": 50331649
      },
      "n": "WebRootComponentDescriptor",
      "d": 2687089,
      "h": 665722617969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(665722617969),
//--TRIMMABLE-BOUNDARY-START(644247781489),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425204449393,
        "f": 50331649
      },
      "n": "RootComponentOperationType",
      "d": 2687089,
      "h": 644247781489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(644247781489),
//--TRIMMABLE-BOUNDARY-START(146031575153),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296355430513,
        "f": 50331649
      },
      "n": "ComponentParameterArray",
      "d": 2687089,
      "h": 146031575153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031575153),
//--TRIMMABLE-BOUNDARY-START(652837716081),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433794383985,
        "f": 50331649
      },
      "n": "String",
      "d": 2687089,
      "h": 652837716081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(652837716081),
//--TRIMMABLE-BOUNDARY-START(661427650673),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Type).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442384318577,
        "f": 50331649
      },
      "n": "Type",
      "d": 2687089,
      "h": 661427650673,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(661427650673),
//--TRIMMABLE-BOUNDARY-START(682902487153),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459564187761,
        "f": 50331649
      },
      "n": "WebRootComponentParameters",
      "d": 2687089,
      "h": 682902487153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(682902487153),
//--TRIMMABLE-BOUNDARY-START(253405757553),
    {
      "p": 2687089,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304945365105,
        "f": 50331681
      },
      "n": "Default",
      "d": 2687089,
      "h": 253405757553,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(253405757553),
//--TRIMMABLE-BOUNDARY-START(ALL, 261995692145, 17195008084),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313535299697,
        "f": 50364420
      },
      "n": "GeneratedSerializerOptions",
      "d": 2687089,
      "h": 261995692145,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 261995692145, 17195008084),
//--TRIMMABLE-BOUNDARY-START(115966804081),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270585626737,
        "f": 50331649
      },
      "n": "ComponentMarker",
      "d": 2687089,
      "h": 115966804081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966804081),
//--TRIMMABLE-BOUNDARY-START(605593075825),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399434645617,
        "f": 50331649
      },
      "n": "RootComponentOperation",
      "d": 2687089,
      "h": 605593075825,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(605593075825),
//--TRIMMABLE-BOUNDARY-START(609888043121),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408024580209,
        "f": 50331649
      },
      "n": "RootComponentOperationArray",
      "d": 2687089,
      "h": 609888043121,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(609888043121),
//--TRIMMABLE-BOUNDARY-START(120261771377),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279175561329,
        "f": 50331649
      },
      "n": "ComponentMarkerKey",
      "d": 2687089,
      "h": 120261771377,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120261771377)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(180391313521),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_IListObject",
      "d": 2687089,
      "h": 180391313521,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180391313521),
//--TRIMMABLE-BOUNDARY-START(184686280817),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Int32",
      "d": 2687089,
      "h": 184686280817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(184686280817),
//--TRIMMABLE-BOUNDARY-START(197571182705),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableComponentMarker",
      "d": 2687089,
      "h": 197571182705,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197571182705),
//--TRIMMABLE-BOUNDARY-START(188981248113),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int64).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Int64",
      "d": 2687089,
      "h": 188981248113,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188981248113),
//--TRIMMABLE-BOUNDARY-START(206161117297),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$$.System.Int32)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableInt32",
      "d": 2687089,
      "h": 206161117297,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206161117297),
//--TRIMMABLE-BOUNDARY-START(210456084593),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Object",
      "d": 2687089,
      "h": 210456084593,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210456084593),
//--TRIMMABLE-BOUNDARY-START(193276215409),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_JsonElement",
      "d": 2687089,
      "h": 193276215409,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193276215409),
//--TRIMMABLE-BOUNDARY-START(201866150001),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_NullableComponentMarkerKey",
      "d": 2687089,
      "h": 201866150001,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(201866150001),
//--TRIMMABLE-BOUNDARY-START(214751051889),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ParameterView",
      "d": 2687089,
      "h": 214751051889,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214751051889),
//--TRIMMABLE-BOUNDARY-START(519693729905),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ParameterViewPropInit",
      "d": 2687089,
      "h": 519693729905,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(519693729905),
//--TRIMMABLE-BOUNDARY-START(523988697201),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 5767276
        }
      ],
      "n": "ParameterViewSerializeHandler",
      "d": 2687089,
      "h": 523988697201,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(523988697201),
//--TRIMMABLE-BOUNDARY-START(171801378929),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentParameter",
      "d": 2687089,
      "h": 171801378929,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171801378929),
//--TRIMMABLE-BOUNDARY-START(154621509745),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentParameterPropInit",
      "d": 2687089,
      "h": 154621509745,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154621509745),
//--TRIMMABLE-BOUNDARY-START(158916477041),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 262257
        }
      ],
      "n": "ComponentParameterSerializeHandler",
      "d": 2687089,
      "h": 158916477041,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158916477041),
//--TRIMMABLE-BOUNDARY-START(227635953777),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationBatch",
      "d": 2687089,
      "h": 227635953777,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227635953777),
//--TRIMMABLE-BOUNDARY-START(627067912305),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "RootComponentOperationBatchPropInit",
      "d": 2687089,
      "h": 627067912305,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(627067912305),
//--TRIMMABLE-BOUNDARY-START(631362879601),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 1048689
        }
      ],
      "n": "RootComponentOperationBatchSerializeHandler",
      "d": 2687089,
      "h": 631362879601,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(631362879601),
//--TRIMMABLE-BOUNDARY-START(622772945009),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues).$h,
      "n": "RootComponentOperationBatchCtorParamInit",
      "d": 2687089,
      "h": 622772945009,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(622772945009),
//--TRIMMABLE-BOUNDARY-START(244815822961),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_WebRootComponentDescriptor",
      "d": 2687089,
      "h": 244815822961,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244815822961),
//--TRIMMABLE-BOUNDARY-START(674312552561),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "WebRootComponentDescriptorPropInit",
      "d": 2687089,
      "h": 674312552561,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(674312552561),
//--TRIMMABLE-BOUNDARY-START(678607519857),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 4325489
        }
      ],
      "n": "WebRootComponentDescriptorSerializeHandler",
      "d": 2687089,
      "h": 678607519857,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(678607519857),
//--TRIMMABLE-BOUNDARY-START(670017585265),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues).$h,
      "n": "WebRootComponentDescriptorCtorParamInit",
      "d": 2687089,
      "h": 670017585265,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(670017585265),
//--TRIMMABLE-BOUNDARY-START(231930921073),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationType",
      "d": 2687089,
      "h": 231930921073,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231930921073),
//--TRIMMABLE-BOUNDARY-START(176096346225),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentParameterArray",
      "d": 2687089,
      "h": 176096346225,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176096346225),
//--TRIMMABLE-BOUNDARY-START(150326542449),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h
        }
      ],
      "n": "ComponentParameterArraySerializeHandler",
      "d": 2687089,
      "h": 150326542449,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150326542449),
//--TRIMMABLE-BOUNDARY-START(236225888369),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_String",
      "d": 2687089,
      "h": 236225888369,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236225888369),
//--TRIMMABLE-BOUNDARY-START(240520855665),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Type).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_Type",
      "d": 2687089,
      "h": 240520855665,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240520855665),
//--TRIMMABLE-BOUNDARY-START(249110790257),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_WebRootComponentParameters",
      "d": 2687089,
      "h": 249110790257,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249110790257),
//--TRIMMABLE-BOUNDARY-START(687197454449),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "WebRootComponentParametersPropInit",
      "d": 2687089,
      "h": 687197454449,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(687197454449),
//--TRIMMABLE-BOUNDARY-START(691492421745),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 4391025
        }
      ],
      "n": "WebRootComponentParametersSerializeHandler",
      "d": 2687089,
      "h": 691492421745,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(691492421745),
//--TRIMMABLE-BOUNDARY-START(657132683377),
    {
      "r": 262145,
      "p": [
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "jsonTypeInfo",
          "p": (TJsonMetadataType) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TJsonMetadataType).$h,
          "f": 2
        }
      ],
      "g": [
        "TJsonMetadataType"
      ],
      "n": "TryGetTypeInfoForRuntimeCustomConverter",
      "d": 2687089,
      "h": 657132683377,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(657132683377),
//--TRIMMABLE-BOUNDARY-START(463859155057),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "GetRuntimeConverterForType",
      "d": 2687089,
      "h": 463859155057,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(463859155057),
//--TRIMMABLE-BOUNDARY-START(257700724849),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "converter",
          "p": 13500500
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "validateCanConvert",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ExpandConverter",
      "d": 2687089,
      "h": 257700724849,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(257700724849),
//--TRIMMABLE-BOUNDARY-START(ALL, 468154122353, 38669844564),
    {
      "r": 17170516,
      "p": [
        {
          "n": "type",
          "p": 187629569
        }
      ],
      "n": "GetTypeInfo",
      "d": 2687089,
      "h": 468154122353,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 468154122353, 38669844564),
//--TRIMMABLE-BOUNDARY-START(163211444337),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentMarker",
      "d": 2687089,
      "h": 163211444337,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163211444337),
//--TRIMMABLE-BOUNDARY-START(133146673265),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentMarkerPropInit",
      "d": 2687089,
      "h": 133146673265,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133146673265),
//--TRIMMABLE-BOUNDARY-START(137441640561),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 131185
        }
      ],
      "n": "ComponentMarkerSerializeHandler",
      "d": 2687089,
      "h": 137441640561,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137441640561),
//--TRIMMABLE-BOUNDARY-START(219046019185),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperation",
      "d": 2687089,
      "h": 219046019185,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219046019185),
//--TRIMMABLE-BOUNDARY-START(635657846897),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "RootComponentOperationPropInit",
      "d": 2687089,
      "h": 635657846897,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(635657846897),
//--TRIMMABLE-BOUNDARY-START(639952814193),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 983153
        }
      ],
      "n": "RootComponentOperationSerializeHandler",
      "d": 2687089,
      "h": 639952814193,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(639952814193),
//--TRIMMABLE-BOUNDARY-START(223340986481),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_RootComponentOperationArray",
      "d": 2687089,
      "h": 223340986481,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223340986481),
//--TRIMMABLE-BOUNDARY-START(614183010417),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h
        }
      ],
      "n": "RootComponentOperationArraySerializeHandler",
      "d": 2687089,
      "h": 614183010417,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(614183010417),
//--TRIMMABLE-BOUNDARY-START(167506411633),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ComponentMarkerKey",
      "d": 2687089,
      "h": 167506411633,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167506411633),
//--TRIMMABLE-BOUNDARY-START(124556738673),
    {
      "r": $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "ComponentMarkerKeyPropInit",
      "d": 2687089,
      "h": 124556738673,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124556738673),
//--TRIMMABLE-BOUNDARY-START(128851705969),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 196721
        }
      ],
      "n": "ComponentMarkerKeySerializeHandler",
      "d": 2687089,
      "h": 128851705969,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851705969)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477523569),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.IList$$($.$$.System.Object)).$h,
      "n": "_IListObject",
      "d": 2687089,
      "h": 21477523569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477523569),
//--TRIMMABLE-BOUNDARY-START(25772490865),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int32).$h,
      "n": "_Int32",
      "d": 2687089,
      "h": 25772490865,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772490865),
//--TRIMMABLE-BOUNDARY-START(38657392753),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,
      "n": "_NullableComponentMarker",
      "d": 2687089,
      "h": 38657392753,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38657392753),
//--TRIMMABLE-BOUNDARY-START(30067458161),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Int64).$h,
      "n": "_Int64",
      "d": 2687089,
      "h": 30067458161,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067458161),
//--TRIMMABLE-BOUNDARY-START(47247327345),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$$.System.Int32)).$h,
      "n": "_NullableInt32",
      "d": 2687089,
      "h": 47247327345,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47247327345),
//--TRIMMABLE-BOUNDARY-START(51542294641),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Object).$h,
      "n": "_Object",
      "d": 2687089,
      "h": 51542294641,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51542294641),
//--TRIMMABLE-BOUNDARY-START(34362425457),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,
      "n": "_JsonElement",
      "d": 2687089,
      "h": 34362425457,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34362425457),
//--TRIMMABLE-BOUNDARY-START(42952360049),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,
      "n": "_NullableComponentMarkerKey",
      "d": 2687089,
      "h": 42952360049,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42952360049),
//--TRIMMABLE-BOUNDARY-START(55837261937),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,
      "n": "_ParameterView",
      "d": 2687089,
      "h": 55837261937,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55837261937),
//--TRIMMABLE-BOUNDARY-START(597003141233),
    {
      "t": 2293844,
      "n": "PropName_type",
      "d": 2687089,
      "h": 597003141233,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(597003141233),
//--TRIMMABLE-BOUNDARY-START(584118239345),
    {
      "t": 2293844,
      "n": "PropName_prerenderId",
      "d": 2687089,
      "h": 584118239345,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(584118239345),
//--TRIMMABLE-BOUNDARY-START(549758500977),
    {
      "t": 2293844,
      "n": "PropName_key",
      "d": 2687089,
      "h": 549758500977,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(549758500977),
//--TRIMMABLE-BOUNDARY-START(588413206641),
    {
      "t": 2293844,
      "n": "PropName_sequence",
      "d": 2687089,
      "h": 588413206641,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(588413206641),
//--TRIMMABLE-BOUNDARY-START(541168566385),
    {
      "t": 2293844,
      "n": "PropName_descriptor",
      "d": 2687089,
      "h": 541168566385,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(541168566385),
//--TRIMMABLE-BOUNDARY-START(528283664497),
    {
      "t": 2293844,
      "n": "PropName_assembly",
      "d": 2687089,
      "h": 528283664497,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(528283664497),
//--TRIMMABLE-BOUNDARY-START(601298108529),
    {
      "t": 2293844,
      "n": "PropName_typeName",
      "d": 2687089,
      "h": 601298108529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(601298108529),
//--TRIMMABLE-BOUNDARY-START(571233337457),
    {
      "t": 2293844,
      "n": "PropName_parameterDefinitions",
      "d": 2687089,
      "h": 571233337457,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(571233337457),
//--TRIMMABLE-BOUNDARY-START(579823272049),
    {
      "t": 2293844,
      "n": "PropName_parameterValues",
      "d": 2687089,
      "h": 579823272049,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(579823272049),
//--TRIMMABLE-BOUNDARY-START(554053468273),
    {
      "t": 2293844,
      "n": "PropName_locationHash",
      "d": 2687089,
      "h": 554053468273,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(554053468273),
//--TRIMMABLE-BOUNDARY-START(545463533681),
    {
      "t": 2293844,
      "n": "PropName_formattedComponentKey",
      "d": 2687089,
      "h": 545463533681,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(545463533681),
//--TRIMMABLE-BOUNDARY-START(562643402865),
    {
      "t": 2293844,
      "n": "PropName_name",
      "d": 2687089,
      "h": 562643402865,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(562643402865),
//--TRIMMABLE-BOUNDARY-START(592708173937),
    {
      "t": 2293844,
      "n": "PropName_ssrComponentId",
      "d": 2687089,
      "h": 592708173937,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(592708173937),
//--TRIMMABLE-BOUNDARY-START(558348435569),
    {
      "t": 2293844,
      "n": "PropName_marker",
      "d": 2687089,
      "h": 558348435569,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(558348435569),
//--TRIMMABLE-BOUNDARY-START(532578631793),
    {
      "t": 2293844,
      "n": "PropName_batchId",
      "d": 2687089,
      "h": 532578631793,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(532578631793),
//--TRIMMABLE-BOUNDARY-START(566938370161),
    {
      "t": 2293844,
      "n": "PropName_operations",
      "d": 2687089,
      "h": 566938370161,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(566938370161),
//--TRIMMABLE-BOUNDARY-START(536873599089),
    {
      "t": 2293844,
      "n": "PropName_componentType",
      "d": 2687089,
      "h": 536873599089,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(536873599089),
//--TRIMMABLE-BOUNDARY-START(575528304753),
    {
      "t": 2293844,
      "n": "PropName_parameters",
      "d": 2687089,
      "h": 575528304753,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(575528304753),
//--TRIMMABLE-BOUNDARY-START(12887588977),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
      "n": "_ComponentParameter",
      "d": 2687089,
      "h": 12887588977,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887588977),
//--TRIMMABLE-BOUNDARY-START(68722163825),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,
      "n": "_RootComponentOperationBatch",
      "d": 2687089,
      "h": 68722163825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(68722163825),
//--TRIMMABLE-BOUNDARY-START(85902033009),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,
      "n": "_WebRootComponentDescriptor",
      "d": 2687089,
      "h": 85902033009,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85902033009),
//--TRIMMABLE-BOUNDARY-START(73017131121),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,
      "n": "_RootComponentOperationType",
      "d": 2687089,
      "h": 73017131121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73017131121),
//--TRIMMABLE-BOUNDARY-START(17182556273),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,
      "n": "_ComponentParameterArray",
      "d": 2687089,
      "h": 17182556273,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182556273),
//--TRIMMABLE-BOUNDARY-START(77312098417),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "n": "_String",
      "d": 2687089,
      "h": 77312098417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77312098417),
//--TRIMMABLE-BOUNDARY-START(81607065713),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Type).$h,
      "n": "_Type",
      "d": 2687089,
      "h": 81607065713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(81607065713),
//--TRIMMABLE-BOUNDARY-START(90197000305),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,
      "n": "_WebRootComponentParameters",
      "d": 2687089,
      "h": 90197000305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(90197000305),
//--TRIMMABLE-BOUNDARY-START(648542748785),
    {
      "t": 3342420,
      "n": "s_defaultOptions",
      "d": 2687089,
      "h": 648542748785,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(648542748785),
//--TRIMMABLE-BOUNDARY-START(481039024241),
    {
      "t": 108199937,
      "n": "InstanceMemberBindingFlags",
      "d": 2687089,
      "h": 481039024241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(481039024241),
//--TRIMMABLE-BOUNDARY-START(4297654385),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,
      "n": "_ComponentMarker",
      "d": 2687089,
      "h": 4297654385,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297654385),
//--TRIMMABLE-BOUNDARY-START(60132229233),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,
      "n": "_RootComponentOperation",
      "d": 2687089,
      "h": 60132229233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60132229233),
//--TRIMMABLE-BOUNDARY-START(64427196529),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,
      "n": "_RootComponentOperationArray",
      "d": 2687089,
      "h": 64427196529,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64427196529),
//--TRIMMABLE-BOUNDARY-START(8592621681),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,
      "n": "_ComponentMarkerKey",
      "d": 2687089,
      "h": 8592621681,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592621681)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(98786934897),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687089,
      "h": 98786934897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98786934897),
//--TRIMMABLE-BOUNDARY-START(103081902193),
    {
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687089,
      "h": 103081902193,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103081902193)
  ],
  "i": [16253012,16318548
  ],
  "h": 2687089,
  "a": [
    {
      "t": 15269972,
      "c": 4310237268,
      "n": [
        {
          "n": "PropertyNamingPolicy",
          "v": 1,
          "t": 14221396
        },
        {
          "n": "PropertyNameCaseInsensitive",
          "v": true,
          "t": 262145
        },
        {
          "n": "DefaultIgnoreCondition",
          "v": 3,
          "t": 14090324
        }
      ]
    },
    {
      "t": 15073364,
      "c": 4310040660,
      "a": [
        {
          "v": $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 15073364,
      "c": 4310040660,
      "a": [
        {
          "v": 2097236,
          "t": 187629569
        }
      ]
    },
    {
      "t": 15073364,
      "c": 4310040660,
      "a": [
        {
          "v": $.$$.System.Collections.Generic.IList$$($.$$.System.Object).$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 15073364,
      "c": 4310040660,
      "a": [
        {
          "v": 1048689,
          "t": 187629569
        }
      ]
    },
    {
      "t": 54198273,
      "c": 12939100161,
      "a": [
        {
          "v": "System.Text.Json.SourceGeneration",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonSerializerContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IBuiltInJsonTypeInfoResolver, $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `WebAssemblyJsonSerializerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687089)
        
        
        //--TRIMMABLE-BOUNDARY-START(786545)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext", ($self) => class PrerenderComponentApplicationStoreSerializerContext extends $.$stj.System.Text.Json.Serialization.JsonSerializerContext
        {
            //--TRIMMABLE-BOUNDARY-START(12885688433)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            //--TRIMMABLE-BOUNDARY-END(12885688433)
            
            //--TRIMMABLE-BOUNDARY-START(141734707313)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$$.System.String.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(141734707313)
            
            //--TRIMMABLE-BOUNDARY-START(51540394097)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$$.System.String, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394097)
            
            //--TRIMMABLE-BOUNDARY-START(4295753841)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>?*/ _ByteArray = null;
            //--TRIMMABLE-BOUNDARY-END(4295753841)
            
            //--TRIMMABLE-BOUNDARY-START(38655492209)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ get ByteArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605165169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._ByteArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$$.System.Byte).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Byte)));
            }
            //--TRIMMABLE-BOUNDARY-END(38655492209)
            
            //--TRIMMABLE-BOUNDARY-START(42950459505)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ Create_ByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$$.System.Byte), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Byte)))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeArray($.$$.System.Byte), options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.ByteArrayConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459505)
            
            //--TRIMMABLE-BOUNDARY-START(8590721137)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>?*/ _DictionaryStringByteArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590721137)
            
            //--TRIMMABLE-BOUNDARY-START(60130328689)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ get DictionaryStringByteArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._DictionaryStringByteArray ??= $.$cast(this.Options.GetTypeInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))));
            }
            //--TRIMMABLE-BOUNDARY-END(60130328689)
            
            //--TRIMMABLE-BOUNDARY-START(47245426801)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ Create_DictionaryStringByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$$.System.Func$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))))().$ctor(this,  () =>
                        {
                            return new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)))().$ctor$1();
                        }, {
  "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h,
  "n": "",
  "d": 786545,
  "h": 0,
  "f": 17825794
});
                        $i2.SerializeHandler = new ($.$$.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))))().$ctor(this, this.DictionaryStringByteArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateDictionaryInfo($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)), $.$$.System.String, $.$typeArray($.$$.System.Byte), options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(47245426801)
            
            //--TRIMMABLE-BOUNDARY-START(64425295985)
            /*void */ DictionaryStringByteArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.Dictionary<string, byte[]>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425295985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                var $en2 = value.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        writer.WriteBase64String$2(entry.Key, $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(entry.Value));
                    }
                }
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(64425295985)
            
            //--TRIMMABLE-BOUNDARY-START(137439740017)
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            //--TRIMMABLE-BOUNDARY-END(137439740017)
            
            //--TRIMMABLE-BOUNDARY-START(133144772721)
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            //--TRIMMABLE-BOUNDARY-END(133144772721)
            
            //--TRIMMABLE-BOUNDARY-START(55835361393)
            /*global::Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(55835361393)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 73015230577, 17195008084)
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 73015230577, 17195008084)
            
            //--TRIMMABLE-BOUNDARY-START(21475623025)
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623025)
            
            //--TRIMMABLE-BOUNDARY-START(25770590321)
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590321)
            
            //--TRIMMABLE-BOUNDARY-START(146029674609)
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029674609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(146029674609)
            
            //--TRIMMABLE-BOUNDARY-START(120259870833)
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259870833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < options.Converters.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.System$Collections$Generic$IList$$$get_Item(i, [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(120259870833)
            
            //--TRIMMABLE-BOUNDARY-START(68720263281)
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$8("The converter '{0}' is not compatible with the type '{1}'.", $.$$.System.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Format$9("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$$.System.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263281)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124554838129, 38669844564)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554838129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo));
                return typeInfo;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124554838129, 38669844564)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 128849805425, 4311285844)
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849805425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type))
                {
                    return this.Create_ByteArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$type))
                {
                    return this.Create_DictionaryStringByteArray(options);
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.String.$type))
                {
                    return this.Create_String(options);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 128849805425, 4311285844)
            
            //default member initializer
            constructor()
            {
                super();
                this.GeneratedSerializerOptions = $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions;
            }
            //--TRIMMABLE-BOUNDARY-START(17180655729)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(137439740017)
                    this.s_defaultOptions = new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(137439740017)
                    
                }
                {
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext().$ctor$3(new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$3($.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180655729)
            
            static $h = 786545;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 15138900,
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734707313),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964903537,
        "f": 50331649
      },
      "n": "String",
      "d": 786545,
      "h": 141734707313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734707313),
//--TRIMMABLE-BOUNDARY-START(38655492209),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605165169,
        "f": 50331649
      },
      "n": "ByteArray",
      "d": 786545,
      "h": 38655492209,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655492209),
//--TRIMMABLE-BOUNDARY-START(60130328689),
    {
      "p": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785034353,
        "f": 50331649
      },
      "n": "DictionaryStringByteArray",
      "d": 786545,
      "h": 60130328689,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328689),
//--TRIMMABLE-BOUNDARY-START(55835361393),
    {
      "p": 786545,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195099761,
        "f": 50331681
      },
      "n": "Default",
      "d": 786545,
      "h": 55835361393,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835361393),
//--TRIMMABLE-BOUNDARY-START(ALL, 73015230577, 17195008084),
    {
      "p": 3342420,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374968945,
        "f": 50364420
      },
      "n": "GeneratedSerializerOptions",
      "d": 786545,
      "h": 73015230577,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 73015230577, 17195008084)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540394097),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_String",
      "d": 786545,
      "h": 51540394097,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540394097),
//--TRIMMABLE-BOUNDARY-START(42950459505),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Byte)).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_ByteArray",
      "d": 786545,
      "h": 42950459505,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950459505),
//--TRIMMABLE-BOUNDARY-START(47245426801),
    {
      "r": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))).$h,
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Create_DictionaryStringByteArray",
      "d": 786545,
      "h": 47245426801,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245426801),
//--TRIMMABLE-BOUNDARY-START(64425295985),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h
        }
      ],
      "n": "DictionaryStringByteArraySerializeHandler",
      "d": 786545,
      "h": 64425295985,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425295985),
//--TRIMMABLE-BOUNDARY-START(146029674609),
    {
      "r": 262145,
      "p": [
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "jsonTypeInfo",
          "p": (TJsonMetadataType) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TJsonMetadataType).$h,
          "f": 2
        }
      ],
      "g": [
        "TJsonMetadataType"
      ],
      "n": "TryGetTypeInfoForRuntimeCustomConverter",
      "d": 786545,
      "h": 146029674609,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(146029674609),
//--TRIMMABLE-BOUNDARY-START(120259870833),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "GetRuntimeConverterForType",
      "d": 786545,
      "h": 120259870833,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259870833),
//--TRIMMABLE-BOUNDARY-START(68720263281),
    {
      "r": 13500500,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "converter",
          "p": 13500500
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "validateCanConvert",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "ExpandConverter",
      "d": 786545,
      "h": 68720263281,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68720263281),
//--TRIMMABLE-BOUNDARY-START(ALL, 124554838129, 38669844564),
    {
      "r": 17170516,
      "p": [
        {
          "n": "type",
          "p": 187629569
        }
      ],
      "n": "GetTypeInfo",
      "d": 786545,
      "h": 124554838129,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 124554838129, 38669844564)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885688433),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.String).$h,
      "n": "_String",
      "d": 786545,
      "h": 12885688433,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688433),
//--TRIMMABLE-BOUNDARY-START(4295753841),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$$.System.Byte)).$h,
      "n": "_ByteArray",
      "d": 786545,
      "h": 4295753841,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753841),
//--TRIMMABLE-BOUNDARY-START(8590721137),
    {
      "t": $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte))).$h,
      "n": "_DictionaryStringByteArray",
      "d": 786545,
      "h": 8590721137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721137),
//--TRIMMABLE-BOUNDARY-START(137439740017),
    {
      "t": 3342420,
      "n": "s_defaultOptions",
      "d": 786545,
      "h": 137439740017,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137439740017),
//--TRIMMABLE-BOUNDARY-START(133144772721),
    {
      "t": 108199937,
      "n": "InstanceMemberBindingFlags",
      "d": 786545,
      "h": 133144772721,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144772721)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475623025),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786545,
      "h": 21475623025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623025),
//--TRIMMABLE-BOUNDARY-START(25770590321),
    {
      "p": [
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786545,
      "h": 25770590321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590321)
  ],
  "i": [16253012,16318548
  ],
  "h": 786545,
  "a": [
    {
      "t": 15073364,
      "c": 4310040660,
      "a": [
        {
          "v": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$typeArray($.$$.System.Byte)).$h,
          "t": 187629569
        }
      ],
      "n": [
        {
          "n": "GenerationMode",
          "v": 2,
          "t": 15204436
        }
      ]
    },
    {
      "t": 54198273,
      "c": 12939100161,
      "a": [
        {
          "v": "System.Text.Json.SourceGeneration",
          "t": 1310721
        },
        {
          "v": "42.42.42.42",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonSerializerContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IBuiltInJsonTypeInfoResolver, $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786545)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949233)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer", ($self) => class WebAssemblyRenderer extends $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer
        {
            //--TRIMMABLE-BOUNDARY-START(30067720305)
            /*WebRootComponentManager?*/ _webRootComponentManager = null;
            //--TRIMMABLE-BOUNDARY-END(30067720305)
            
            //--TRIMMABLE-BOUNDARY-START(111672098929)
            /*WebRootComponentManager */ GetOrCreateWebRootComponentManager()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111672098929);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._webRootComponentManager ??= new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111672098929)
            
            //--TRIMMABLE-BOUNDARY-START(3080305)
            static $_WebRootComponentManager;
            static get WebRootComponentManager()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer;
                return $cls.$_WebRootComponentManager ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager", ($self) => class WebRootComponentManager extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8593014897)
                    /*Dictionary<int, WebRootComponent>*/ _webRootComponents = null;
                    //--TRIMMABLE-BOUNDARY-END(8593014897)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298047601)
                    /*Task*/ _currentUpdateTask = null;
                    //--TRIMMABLE-BOUNDARY-END(4298047601)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477916785)
                    /*Task *//*async*/  AddRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ componentType, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ parameters)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477916785);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            if (this._webRootComponents.ContainsKey(ssrComponentId))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12(`A root component with SSR component ID ${ssrComponentId} already exists.`);
                            }
                            /*var*/ let component = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent.Create(this.renderer, componentType, ssrComponentId, key?.Clone() ?? null, parameters);
                            this._webRootComponents.Add(ssrComponentId, component);
                            await this._currentUpdateTask;
                            await component.RenderAsync$1(this.renderer);
                        });
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477916785)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952753265)
                    /*Task */ UpdateRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952753265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        return component.UpdateAsync(this.renderer, newComponentType, newKey?.Clone() ?? null, newParameters, this._currentUpdateTask);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952753265)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362818673)
                    /*void */ RemoveRootComponent(/*int*/ ssrComponentId)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362818673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        component.Remove(this.renderer);
                        this._webRootComponents.Remove$1(ssrComponentId);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362818673)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772884081)
                    /*WebRootComponent */ GetRequiredWebRootComponent(/*int*/ ssrComponentId)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772884081);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let component;
                        if (!this._webRootComponents.TryGetValue(ssrComponentId, $.$ref(() => component, ($v) => component = $v, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12(`No root component exists with SSR component ID ${ssrComponentId}.`);
                        }
                        return component;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772884081)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067851377)
                    /*ComponentMarkerKey */ GetRootComponentKey(/*int*/ componentId)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067851377);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        var $en4 = this._webRootComponents.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            let [ _0, candidate ] = $.$destructure($en4.Current);
                            {
                                /*var*/ let  [ id, key, _1, _2 ] = $.$destructure(candidate);
                                if (id === componentId)
                                {
                                    return key;
                                }
                            }
                        }
                        return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067851377)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657785969)
                    /*void */ SetCurrentUpdateTask(/*Task*/ postStateTask)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657785969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._currentUpdateTask = postStateTask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657785969)
                    
                    //--TRIMMABLE-BOUNDARY-START(3145841)
                    static $_WebRootComponent;
                    static get WebRootComponent()
                    {
                        let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager;
                        return $cls.$_WebRootComponent ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent", ($self) => class WebRootComponent extends $.$$.System.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(4298113137)
                            /*Type*/ _componentType = null;
                            //--TRIMMABLE-BOUNDARY-END(4298113137)
                            
                            //--TRIMMABLE-BOUNDARY-START(21477982321)
                            /*string*/ _ssrComponentIdString = null;
                            //--TRIMMABLE-BOUNDARY-END(21477982321)
                            
                            //--TRIMMABLE-BOUNDARY-START(12888047729)
                            /*ComponentMarkerKey*/ _key;
                            //--TRIMMABLE-BOUNDARY-END(12888047729)
                            
                            //--TRIMMABLE-BOUNDARY-START(17183015025)
                            /*WebRootComponentParameters*/ _latestParameters;
                            //--TRIMMABLE-BOUNDARY-END(17183015025)
                            
                            //--TRIMMABLE-BOUNDARY-START(8593080433)
                            /*int*/ _interactiveComponentId = 0;
                            //--TRIMMABLE-BOUNDARY-END(8593080433)
                            
                            //--TRIMMABLE-BOUNDARY-START(30067916913)
                            static /*WebRootComponent */ Create(/*Renderer*/ renderer, /*Type*/ componentType, /*int*/ ssrComponentId, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ initialParameters)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30067916913);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (!$.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).HasValue$get.call(key))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12("An invalid component marker key was provided.");
                                }
                                /*var*/ let ssrComponentIdString = $.$$.System.Int32.ToString$1.call(ssrComponentId, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                                /*var*/ let interactiveComponentId = renderer.AddRootComponent(componentType, ssrComponentIdString);
                                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent().$ctor$1(componentType, ssrComponentIdString, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(key), interactiveComponentId, $.$ref(() => initialParameters, ));
                            }
                            //--TRIMMABLE-BOUNDARY-END(30067916913)
                            
                            //--TRIMMABLE-BOUNDARY-START(25772949617)
                            $ctor$1(/*Type*/ componentType, /*string*/ ssrComponentIdString, /*ComponentMarkerKey*/ key, /*int*/ interactiveComponentId, /*in WebRootComponentParameters*/ initialParameters)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(25772949617);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._componentType = componentType;
                                    this._ssrComponentIdString = ssrComponentIdString;
                                    this._key = key.Clone();
                                    this._interactiveComponentId = interactiveComponentId;
                                    this._latestParameters = initialParameters.$v;
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(25772949617)
                            
                            //--TRIMMABLE-BOUNDARY-START(34362884209)
                            /*void */ Deconstruct(/*out int*/ interactiveComponentId, /*out ComponentMarkerKey*/ key, /*out Type*/ componentType, /*out ParameterView*/ parameters)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(34362884209);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                interactiveComponentId.$v = this._interactiveComponentId;
                                key.$v = this._key.Clone();
                                componentType.$v = this._componentType;
                                parameters.$v = this._latestParameters.Parameters;
                            }
                            //--TRIMMABLE-BOUNDARY-END(34362884209)
                            
                            //--TRIMMABLE-BOUNDARY-START(51542753393)
                            /*Task */ UpdateAsync(/*Renderer*/ renderer, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters, /*Task*/ currentUpdateTask)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51542753393);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if ($.$$.System.Type.op_Inequality$1(this._componentType, newComponentType))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12("Cannot update components with mismatching types.");
                                }
                                if (!$.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).HasValue$get.call(newKey))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12("An invalid component marker key was provided.");
                                }
                                if (!$.$$.System.String.Equals$2(this._key.LocationHash, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(newKey).LocationHash, 4/*StringComparison.Ordinal*/) || !$.$$.System.String.Equals$2(this._key.FormattedComponentKey, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(newKey).FormattedComponentKey, 4/*StringComparison.Ordinal*/))
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12("Cannot update components with mismatching keys.");
                                }
                                if (!$.$$.System.String.IsNullOrEmpty(this._key.FormattedComponentKey))
                                {
                                    this._latestParameters = newParameters;
                                    return this.RenderAsync(renderer, currentUpdateTask);
                                }
                                else 
                                {
                                    if (this._latestParameters.DefinitelyEquals($.$ref(() => newParameters, )))
                                    {
                                        return $.$$.System.Threading.Tasks.Task.CompletedTask;
                                    }
                                    else 
                                    {
                                        renderer.RemoveRootComponent(this._interactiveComponentId);
                                        this._interactiveComponentId = renderer.AddRootComponent(this._componentType, this._ssrComponentIdString);
                                        this._latestParameters = newParameters;
                                        return this.RenderAsync(renderer, currentUpdateTask);
                                    }
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(51542753393)
                            
                            //--TRIMMABLE-BOUNDARY-START(42952818801)
                            /*Task */ RenderAsync$1(/*Renderer*/ renderer)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(42952818801);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return renderer.RenderRootComponentAsync(this._interactiveComponentId, this._latestParameters.Parameters);
                            }
                            //--TRIMMABLE-BOUNDARY-END(42952818801)
                            
                            //--TRIMMABLE-BOUNDARY-START(47247786097)
                            /*Task *//*async*/  RenderAsync(/*Renderer*/ renderer, /*Task*/ updateTask)
                            {
                                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(47247786097);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    await updateTask;
                                    await renderer.RenderRootComponentAsync(this._interactiveComponentId, this._latestParameters.Parameters);
                                });
                            }
                            //--TRIMMABLE-BOUNDARY-END(47247786097)
                            
                            //--TRIMMABLE-BOUNDARY-START(38657851505)
                            /*void */ Remove(/*Renderer*/ renderer)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(38657851505);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                renderer.RemoveRootComponent(this._interactiveComponentId);
                            }
                            //--TRIMMABLE-BOUNDARY-END(38657851505)
                            
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(12888047729)
                                this._key = $.$default($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey);
                                //--TRIMMABLE-BOUNDARY-END(12888047729)
                                
                                //--TRIMMABLE-BOUNDARY-START(17183015025)
                                this._latestParameters = $.$default($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                                //--TRIMMABLE-BOUNDARY-END(17183015025)
                                
                            }
                            static $h = 3145841;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067916913),
    {
      "r": 3145841,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        },
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
        },
        {
          "n": "initialParameters",
          "p": 4391025
        }
      ],
      "n": "Create",
      "d": 3145841,
      "h": 30067916913,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067916913),
//--TRIMMABLE-BOUNDARY-START(34362884209),
    {
      "r": 65537,
      "p": [
        {
          "n": "interactiveComponentId",
          "p": 655361,
          "f": 2
        },
        {
          "n": "key",
          "p": 196721,
          "f": 2
        },
        {
          "n": "componentType",
          "p": 187629569,
          "f": 2
        },
        {
          "n": "parameters",
          "p": 5767276,
          "f": 2
        }
      ],
      "n": "Deconstruct",
      "d": 3145841,
      "h": 34362884209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362884209),
//--TRIMMABLE-BOUNDARY-START(51542753393),
    {
      "r": 177537025,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        },
        {
          "n": "newComponentType",
          "p": 187629569
        },
        {
          "n": "newKey",
          "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
        },
        {
          "n": "newParameters",
          "p": 4391025
        },
        {
          "n": "currentUpdateTask",
          "p": 177537025
        }
      ],
      "n": "UpdateAsync",
      "d": 3145841,
      "h": 51542753393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542753393),
//--TRIMMABLE-BOUNDARY-START(42952818801),
    {
      "r": 177537025,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        }
      ],
      "n": "RenderAsync",
      "o": "@$1",
      "d": 3145841,
      "h": 42952818801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952818801),
//--TRIMMABLE-BOUNDARY-START(47247786097),
    {
      "r": 177537025,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        },
        {
          "n": "updateTask",
          "p": 177537025
        }
      ],
      "n": "RenderAsync",
      "d": 3145841,
      "h": 47247786097,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(47247786097),
//--TRIMMABLE-BOUNDARY-START(38657851505),
    {
      "r": 65537,
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        }
      ],
      "n": "Remove",
      "d": 3145841,
      "h": 38657851505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657851505)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298113137),
    {
      "t": 187629569,
      "n": "_componentType",
      "d": 3145841,
      "h": 4298113137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298113137),
//--TRIMMABLE-BOUNDARY-START(21477982321),
    {
      "t": 1310721,
      "n": "_ssrComponentIdString",
      "d": 3145841,
      "h": 21477982321,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477982321),
//--TRIMMABLE-BOUNDARY-START(12888047729),
    {
      "t": 196721,
      "n": "_key",
      "d": 3145841,
      "h": 12888047729,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888047729),
//--TRIMMABLE-BOUNDARY-START(17183015025),
    {
      "t": 4391025,
      "n": "_latestParameters",
      "d": 3145841,
      "h": 17183015025,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17183015025),
//--TRIMMABLE-BOUNDARY-START(8593080433),
    {
      "t": 655361,
      "n": "_interactiveComponentId",
      "d": 3145841,
      "h": 8593080433,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593080433)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772949617),
    {
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "ssrComponentIdString",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 196721
        },
        {
          "n": "interactiveComponentId",
          "p": 655361
        },
        {
          "n": "initialParameters",
          "p": 4391025,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3145841,
      "h": 25772949617,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772949617)
  ],
  "d": 3080305,
  "h": 3145841
}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `WebAssemblyRenderer.WebRootComponentManager.WebRootComponent`; }
                        }, $cls, ($v) => $cls.$_WebRootComponent = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(3145841)
                    
                    //Begin primary constructor
                    /*Renderer*/ renderer = null;
                    $ctor$1(/*Renderer*/renderer)
                    {
                        this.renderer = renderer;
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8593014897)
                        this._webRootComponents = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Int32, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(8593014897)
                        
                        //--TRIMMABLE-BOUNDARY-START(4298047601)
                        this._currentUpdateTask = $.$$.System.Threading.Tasks.Task.CompletedTask;
                        //--TRIMMABLE-BOUNDARY-END(4298047601)
                        
                    }
                    static $h = 3080305;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477916785),
    {
      "r": 177537025,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "key",
          "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
        },
        {
          "n": "parameters",
          "p": 4391025
        }
      ],
      "n": "AddRootComponentAsync",
      "d": 3080305,
      "h": 21477916785,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(21477916785),
//--TRIMMABLE-BOUNDARY-START(42952753265),
    {
      "r": 177537025,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        },
        {
          "n": "newComponentType",
          "p": 187629569
        },
        {
          "n": "newKey",
          "p": $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h
        },
        {
          "n": "newParameters",
          "p": 4391025
        }
      ],
      "n": "UpdateRootComponentAsync",
      "d": 3080305,
      "h": 42952753265,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952753265),
//--TRIMMABLE-BOUNDARY-START(34362818673),
    {
      "r": 65537,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        }
      ],
      "n": "RemoveRootComponent",
      "d": 3080305,
      "h": 34362818673,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362818673),
//--TRIMMABLE-BOUNDARY-START(25772884081),
    {
      "r": 3145841,
      "p": [
        {
          "n": "ssrComponentId",
          "p": 655361
        }
      ],
      "n": "GetRequiredWebRootComponent",
      "d": 3080305,
      "h": 25772884081,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772884081),
//--TRIMMABLE-BOUNDARY-START(30067851377),
    {
      "r": 196721,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        }
      ],
      "n": "GetRootComponentKey",
      "d": 3080305,
      "h": 30067851377,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30067851377),
//--TRIMMABLE-BOUNDARY-START(38657785969),
    {
      "r": 65537,
      "p": [
        {
          "n": "postStateTask",
          "p": 177537025
        }
      ],
      "n": "SetCurrentUpdateTask",
      "d": 3080305,
      "h": 38657785969,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38657785969)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182949489),
    {
      "t": 2949233,
      "n": "\u003Crenderer\u003EP",
      "d": 3080305,
      "h": 17182949489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182949489),
//--TRIMMABLE-BOUNDARY-START(8593014897),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Int32, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent).$h,
      "n": "_webRootComponents",
      "d": 3080305,
      "h": 8593014897,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593014897),
//--TRIMMABLE-BOUNDARY-START(4298047601),
    {
      "t": 177537025,
      "n": "_currentUpdateTask",
      "d": 3080305,
      "h": 4298047601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298047601)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887982193),
    {
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080305,
      "h": 12887982193,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887982193)
  ],
  "j": [3145841
  ],
  "d": 2949233,
  "h": 3080305
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `WebAssemblyRenderer.WebRootComponentManager`; }
                }, $cls, ($v) => $cls.$_WebRootComponentManager = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3080305)
            
            //--TRIMMABLE-BOUNDARY-START(3014769)
            static $_Log;
            static get Log()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer;
                return $cls.$_Log ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log", ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4297982065)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UnhandledExceptionRenderingComponentCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4297982065)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887916657)
                    static /*void */ UnhandledExceptionRenderingComponent(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ message, /*global::System.Exception*/ exception)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887916657);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.__UnhandledExceptionRenderingComponentCallback.Invoke(logger, message, exception);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887916657)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592949361)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4297982065)
                            this.__UnhandledExceptionRenderingComponentCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$12($.$$.System.String, 5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(100, "ExceptionRenderingComponent"), "Unhandled exception rendering component: {Message}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4297982065)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592949361)
                    
                    static $h = 3014769;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887916657),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "UnhandledExceptionRenderingComponent",
      "d": 3014769,
      "h": 12887916657,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 8592162904,
          "a": [
            {
              "v": 100,
              "t": 655361
            },
            {
              "v": 5,
              "t": 2293848
            },
            {
              "v": "Unhandled exception rendering component: {Message}",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "ExceptionRenderingComponent",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887916657)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297982065),
    {
      "t": $.$$.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.Exception).$h,
      "n": "__UnhandledExceptionRenderingComponentCallback",
      "d": 3014769,
      "h": 4297982065,
      "f": 4194338,
      "a": [
        {
          "t": 54198273,
          "c": 12939100161,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297982065)
  ],
  "d": 2949233,
  "h": 3014769
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3014769)
            
            //--TRIMMABLE-BOUNDARY-START(21477785713)
            /*ILogger*/ _logger$1 = null;
            //--TRIMMABLE-BOUNDARY-END(21477785713)
            
            //--TRIMMABLE-BOUNDARY-START(12887851121)
            /*Dispatcher*/ _dispatcher = null;
            //--TRIMMABLE-BOUNDARY-END(12887851121)
            
            //--TRIMMABLE-BOUNDARY-START(25772753009)
            /*ResourceAssetCollection*/ _resourceCollection = null;
            //--TRIMMABLE-BOUNDARY-END(25772753009)
            
            //--TRIMMABLE-BOUNDARY-START(17182818417)
            /*IInternalJSImportMethods*/ _jsMethods = null;
            //--TRIMMABLE-BOUNDARY-END(17182818417)
            
            //--TRIMMABLE-BOUNDARY-START(8592883825)
            /*ComponentStatePersistenceManager*/ _componentStatePersistenceManager = null;
            //--TRIMMABLE-BOUNDARY-END(8592883825)
            
            //--TRIMMABLE-BOUNDARY-START(4297916529)
            /*RendererInfo*/ static _componentPlatform = null;
            //--TRIMMABLE-BOUNDARY-END(4297916529)
            
            //--TRIMMABLE-BOUNDARY-START(38657654897)
            $ctor$4(/*IServiceProvider*/ serviceProvider, /*ResourceAssetCollection*/ resourceCollection, /*ILoggerFactory*/ loggerFactory, /*JSComponentInterop*/ jsComponentInterop)
            {
                super.$ctor$3(serviceProvider, loggerFactory, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.ReadJsonSerializerOptions(), jsComponentInterop);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657654897);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._logger$1 = $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, loggerFactory);
                    this._jsMethods = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods, serviceProvider);
                    this._componentStatePersistenceManager = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, serviceProvider);
                    this._dispatcher = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext === null ? $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher.Instance : new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher().$ctor$2();
                    this._resourceCollection = resourceCollection;
                    this.ElementReferenceContext = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.ElementReferenceContext;
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.add_OnUpdateRootComponents(new ($.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$$.System.String))().$ctor(this, this.OnUpdateRootComponents));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657654897)
            
            //--TRIMMABLE-BOUNDARY-START(133146935409)
            /*void */ OnUpdateRootComponents(/*RootComponentOperationBatch*/ batch, /*string*/ appState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146935409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let webRootComponentManager = this.GetOrCreateWebRootComponentManager();
                /*TaskCompletionSource?*/ let taskCompletionSource = null;
                /*var*/ let stateUpdateTask = $.$$.System.Threading.Tasks.Task.CompletedTask;
                /*var*/ let store = !$.$$.System.String.IsNullOrEmpty(appState) ? new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$2(appState) : null;
                if (store !== null)
                {
                    taskCompletionSource = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    stateUpdateTask = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.EnqueueRestore(taskCompletionSource.Task, this._componentStatePersistenceManager, store);
                }
                webRootComponentManager.SetCurrentUpdateTask(stateUpdateTask);
                for(/*var*/ let i = 0; i < batch.Operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(batch.Operations, i);
                    let $switch1 = operation.Type;
                    switch($switch1)
                    {
                        case 0/*RootComponentOperationType.Add*/:
                        _ = webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Key, operation.Descriptor.Parameters);
                        break;
                        case 1/*RootComponentOperationType.Update*/:
                        _ = webRootComponentManager.UpdateRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters);
                        break;
                        case 2/*RootComponentOperationType.Remove*/:
                        webRootComponentManager.RemoveRootComponent(operation.SsrComponentId);
                        break;
                    }
                }
                taskCompletionSource?.SetResult();
                store?.ExistingState.Clear();
                this.NotifyEndUpdateRootComponents(batch.BatchId);
            }
            //--TRIMMABLE-BOUNDARY-END(133146935409)
            
            //--TRIMMABLE-BOUNDARY-START(73017393265)
            static /*Task *//*async*/  EnqueueRestore(/*Task*/ task, /*ComponentStatePersistenceManager*/ componentStatePersistenceManager, /*PrerenderComponentApplicationStore*/ store)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017393265);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await task;
                    await componentStatePersistenceManager.RestoreStateAsync(store, $.$mac.Microsoft.AspNetCore.Components.RestoreContext.ValueUpdate);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73017393265)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103082164337, 339310870636)
            /*IComponentRenderMode? */ GetComponentRenderMode$1(/*IComponent*/ component)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103082164337);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103082164337, 339310870636)
            
            //--TRIMMABLE-BOUNDARY-START(128851968113)
            /*void */ NotifyEndUpdateRootComponents(/*long*/ batchId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851968113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents(batchId);
            }
            //--TRIMMABLE-BOUNDARY-END(128851968113)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47247589489, 163217211500)
            /*ResourceAssetCollection */ get Assets()
            {
                return this._resourceCollection;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47247589489, 163217211500)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 146031837297, 476749824108)
            /*RendererInfo */ get RendererInfo()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer._componentPlatform;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 146031837297, 476749824108)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 64427458673, 197576949868)
            /*Dispatcher */ get Dispatcher()
            {
                return this._dispatcher;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 64427458673, 197576949868)
            
            //--TRIMMABLE-BOUNDARY-START(42952622193)
            /*Task */ AddComponentAsync(/*Type*/ componentType, /*ParameterView*/ parameters, /*string*/ domElementSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952622193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let componentId = this.AddRootComponent(componentType, domElementSelector);
                return this.RenderRootComponentAsync(componentId, parameters);
            }
            //--TRIMMABLE-BOUNDARY-END(42952622193)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 115967066225, 42953539694)
            /*int */ GetWebRendererId()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115967066225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 2/*WebRendererId.WebAssembly*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 115967066225, 42953539694)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51542556785, 21478703214)
            /*void */ AttachRootComponentToBrowser(/*int*/ componentId, /*string*/ domElementSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542556785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement(domElementSelector, componentId, this.RendererId);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51542556785, 21478703214)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68722425969, 210461851756)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722425969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68722425969, 210461851756)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 137441902705, 446685053036)
            /*void */ ProcessPendingRender()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441902705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.IsInProgress)
                {
                    super.ProcessPendingRender();
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, this, new ($.$$.System.Action$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, /*static*/ (/**/ $this) =>
                    {
                        return $this.CallBaseProcessPendingRender();
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "this",
      "p": 2949233
    }
  ],
  "n": "",
  "d": 2949233,
  "h": 0,
  "f": 17825826
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 137441902705, 446685053036)
            
            //--TRIMMABLE-BOUNDARY-START(55837524081)
            /*void */ CallBaseProcessPendingRender()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837524081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return super.ProcessPendingRender();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837524081)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 154621771889, 541174333548)
            /*Task */ UpdateDisplayAsync(/*in RenderBatch*/ batch)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621771889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let batchCopy = batch.$v;
                Blazor._internal.renderBatch(this.RendererId, $.$$.System.Runtime.CompilerServices.Unsafe.AsPointer($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderBatch, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderBatch, () => batchCopy, ($v) => batchCopy = $v, null)));
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.HasUnstartedWork)
                {
                    /*var*/ let tcs = new $.$$.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$$.System.Threading.Tasks.TaskCompletionSource, tcs, new ($.$$.System.Action$$($.$$.System.Threading.Tasks.TaskCompletionSource))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, /*static*/ (/*tcs*/ tcs) =>
                    {
                        return tcs.SetResult();
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "tcs",
      "p": 178651137
    }
  ],
  "n": "",
  "d": 2949233,
  "h": 0,
  "f": 17825826
}));
                    return tcs.Task;
                }
                else 
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 154621771889, 541174333548)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 120262033521, 395145445484)
            /*void */ HandleException(/*Exception*/ exception)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262033521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let aggregateException;
                if ($.$is(exception, $.$$.System.AggregateException, { set $v(v){ aggregateException = v; } }))
                {
                    var $en3 = aggregateException.Flatten().InnerExceptions.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var innerException = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger$1, innerException.Message, innerException);
                        }
                    }
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger$1, exception.Message, exception);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 120262033521, 395145445484)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 150326804593, 498224660588)
            /*IComponent */ ResolveComponentForRenderMode(/*Type*/ componentType, /*int?*/ parentComponentId, /*IComponentActivator*/ componentActivator, /*IComponentRenderMode*/ renderMode)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150326804593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if ((renderMode === $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode) || (renderMode === $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode))
                        {
                            return componentActivator.Microsoft$AspNetCore$Components$IComponentActivator$CreateInstance(componentType);
                        }
                        throw new $.$$.System.NotSupportedException().$ctor$12(`Cannot create a component of type '${$.$$.System.Type.ToString.call(componentType)}' because its render mode '${$.$$.System.Object.ToString.call(renderMode)}' is not supported by WebAssembly rendering.`);
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 150326804593, 498224660588)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60132491377, 193281982572)
            /*ComponentState */ CreateComponentState(/*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132491377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyComponentState().$ctor$2(this, componentId, component, parentComponentState);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60132491377, 193281982572)
            
            //--TRIMMABLE-BOUNDARY-START(107377131633)
            /*ComponentMarkerKey */ GetMarkerKey(/*WebAssemblyComponentState*/ webAssemblyComponentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377131633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return webAssemblyComponentState.ParentComponentState !== null ? new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey() : this._webRootComponentManager.GetRootComponentKey(webAssemblyComponentState.ComponentId);
            }
            //--TRIMMABLE-BOUNDARY-END(107377131633)
            
            //--TRIMMABLE-BOUNDARY-START(34362687601)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4297916529)
                    this._componentPlatform = new $.$mac.Microsoft.AspNetCore.Components.RendererInfo().$ctor$1("WebAssembly", true);
                    //--TRIMMABLE-BOUNDARY-END(4297916529)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362687601)
            
            static $h = 2949233;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3866734,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 47247589489, 163217211500),
    {
      "p": 9437292,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607327857,
        "f": 50364420
      },
      "n": "Assets",
      "d": 2949233,
      "h": 47247589489,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47247589489, 163217211500),
//--TRIMMABLE-BOUNDARY-START(ALL, 146031837297, 476749824108),
    {
      "p": 6815852,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787197041,
        "f": 50364420
      },
      "n": "RendererInfo",
      "d": 2949233,
      "h": 146031837297,
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 146031837297, 476749824108),
//--TRIMMABLE-BOUNDARY-START(ALL, 64427458673, 197576949868),
    {
      "p": 1704044,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197262449,
        "f": 50364417
      },
      "n": "Dispatcher",
      "d": 2949233,
      "h": 64427458673,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64427458673, 197576949868)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(111672098929),
    {
      "r": 3080305,
      "n": "GetOrCreateWebRootComponentManager",
      "d": 2949233,
      "h": 111672098929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111672098929),
//--TRIMMABLE-BOUNDARY-START(133146935409),
    {
      "r": 65537,
      "p": [
        {
          "n": "batch",
          "p": 1048689
        },
        {
          "n": "appState",
          "p": 1310721
        }
      ],
      "n": "OnUpdateRootComponents",
      "d": 2949233,
      "h": 133146935409,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146935409),
//--TRIMMABLE-BOUNDARY-START(73017393265),
    {
      "r": 177537025,
      "p": [
        {
          "n": "task",
          "p": 177537025
        },
        {
          "n": "componentStatePersistenceManager",
          "p": 3342444
        },
        {
          "n": "store",
          "p": 721009
        }
      ],
      "n": "EnqueueRestore",
      "d": 2949233,
      "h": 73017393265,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(73017393265),
//--TRIMMABLE-BOUNDARY-START(ALL, 103082164337, 339310870636),
    {
      "r": 2883692,
      "p": [
        {
          "n": "component",
          "p": 2752620
        }
      ],
      "n": "GetComponentRenderMode",
      "o": "@$1",
      "d": 2949233,
      "h": 103082164337,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103082164337, 339310870636),
//--TRIMMABLE-BOUNDARY-START(128851968113),
    {
      "r": 65537,
      "p": [
        {
          "n": "batchId",
          "p": 917505
        }
      ],
      "n": "NotifyEndUpdateRootComponents",
      "d": 2949233,
      "h": 128851968113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851968113),
//--TRIMMABLE-BOUNDARY-START(42952622193),
    {
      "r": 177537025,
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "parameters",
          "p": 5767276
        },
        {
          "n": "domElementSelector",
          "p": 1310721
        }
      ],
      "n": "AddComponentAsync",
      "d": 2949233,
      "h": 42952622193,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952622193),
//--TRIMMABLE-BOUNDARY-START(ALL, 115967066225, 42953539694),
    {
      "r": 655361,
      "n": "GetWebRendererId",
      "d": 2949233,
      "h": 115967066225,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 115967066225, 42953539694),
//--TRIMMABLE-BOUNDARY-START(ALL, 51542556785, 21478703214),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "domElementSelector",
          "p": 1310721
        }
      ],
      "n": "AttachRootComponentToBrowser",
      "d": 2949233,
      "h": 51542556785,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51542556785, 21478703214),
//--TRIMMABLE-BOUNDARY-START(ALL, 68722425969, 210461851756),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 2949233,
      "h": 68722425969,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68722425969, 210461851756),
//--TRIMMABLE-BOUNDARY-START(ALL, 137441902705, 446685053036),
    {
      "r": 65537,
      "n": "ProcessPendingRender",
      "d": 2949233,
      "h": 137441902705,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 137441902705, 446685053036),
//--TRIMMABLE-BOUNDARY-START(55837524081),
    {
      "r": 65537,
      "n": "CallBaseProcessPendingRender",
      "d": 2949233,
      "h": 55837524081,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55837524081),
//--TRIMMABLE-BOUNDARY-START(ALL, 154621771889, 541174333548),
    {
      "r": 177537025,
      "p": [
        {
          "n": "batch",
          "p": 8388716,
          "f": 8
        }
      ],
      "n": "UpdateDisplayAsync",
      "d": 2949233,
      "h": 154621771889,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 154621771889, 541174333548),
//--TRIMMABLE-BOUNDARY-START(ALL, 120262033521, 395145445484),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 79888385
        }
      ],
      "n": "HandleException",
      "d": 2949233,
      "h": 120262033521,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 120262033521, 395145445484),
//--TRIMMABLE-BOUNDARY-START(ALL, 150326804593, 498224660588),
    {
      "r": 2752620,
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "parentComponentId",
          "p": $.$typeNullable($.$$.System.Int32).$h
        },
        {
          "n": "componentActivator",
          "p": 2818156
        },
        {
          "n": "renderMode",
          "p": 2883692
        }
      ],
      "n": "ResolveComponentForRenderMode",
      "d": 2949233,
      "h": 150326804593,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 150326804593, 498224660588),
//--TRIMMABLE-BOUNDARY-START(ALL, 60132491377, 193281982572),
    {
      "r": 7077996,
      "p": [
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2752620
        },
        {
          "n": "parentComponentState",
          "p": 7077996
        }
      ],
      "n": "CreateComponentState",
      "d": 2949233,
      "h": 60132491377,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60132491377, 193281982572),
//--TRIMMABLE-BOUNDARY-START(107377131633),
    {
      "r": 196721,
      "p": [
        {
          "n": "webAssemblyComponentState",
          "p": 2818161
        }
      ],
      "n": "GetMarkerKey",
      "d": 2949233,
      "h": 107377131633,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(107377131633)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067720305),
    {
      "t": 3080305,
      "n": "_webRootComponentManager",
      "d": 2949233,
      "h": 30067720305,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30067720305),
//--TRIMMABLE-BOUNDARY-START(21477785713),
    {
      "t": 917592,
      "n": "_logger",
      "o": "@$1",
      "d": 2949233,
      "h": 21477785713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477785713),
//--TRIMMABLE-BOUNDARY-START(12887851121),
    {
      "t": 1704044,
      "n": "_dispatcher",
      "d": 2949233,
      "h": 12887851121,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887851121),
//--TRIMMABLE-BOUNDARY-START(25772753009),
    {
      "t": 9437292,
      "n": "_resourceCollection",
      "d": 2949233,
      "h": 25772753009,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772753009),
//--TRIMMABLE-BOUNDARY-START(17182818417),
    {
      "t": 3342449,
      "n": "_jsMethods",
      "d": 2949233,
      "h": 17182818417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182818417),
//--TRIMMABLE-BOUNDARY-START(8592883825),
    {
      "t": 3342444,
      "n": "_componentStatePersistenceManager",
      "d": 2949233,
      "h": 8592883825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592883825),
//--TRIMMABLE-BOUNDARY-START(4297916529),
    {
      "t": 6815852,
      "n": "_componentPlatform",
      "d": 2949233,
      "h": 4297916529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297916529)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38657654897),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "resourceCollection",
          "p": 9437292
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        },
        {
          "n": "jsComponentInterop",
          "p": 5898350
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2949233,
      "h": 38657654897,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657654897)
  ],
  "i": [90177537,89587713
  ],
  "j": [3080305,3014769
  ],
  "h": 2949233
}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyRenderer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949233)
        
        
        //--TRIMMABLE-BOUNDARY-START(852081)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream", ($self) => class PullFromJSDataStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(12885753969)
            /*IJSRuntime*/ _runtime = null;
            //--TRIMMABLE-BOUNDARY-END(12885753969)
            
            //--TRIMMABLE-BOUNDARY-START(4295819377)
            /*IJSStreamReference*/ _jsStreamReference = null;
            //--TRIMMABLE-BOUNDARY-END(4295819377)
            
            //--TRIMMABLE-BOUNDARY-START(21475688561)
            /*long*/ _totalLength = 0n;
            //--TRIMMABLE-BOUNDARY-END(21475688561)
            
            //--TRIMMABLE-BOUNDARY-START(17180721265)
            /*CancellationToken*/ _streamCancellationToken;
            //--TRIMMABLE-BOUNDARY-END(17180721265)
            
            //--TRIMMABLE-BOUNDARY-START(8590786673)
            /*long*/ _offset = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590786673)
            
            //--TRIMMABLE-BOUNDARY-START(42950525041)
            static /*PullFromJSDataStream */ CreateJSDataStream(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsDataStream = new $.$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream().$ctor$3(runtime, jsStreamReference, totalLength, cancellationToken);
                return jsDataStream;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525041)
            
            //--TRIMMABLE-BOUNDARY-START(25770655857)
            $ctor$3(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655857);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._runtime = runtime;
                    this._jsStreamReference = jsStreamReference;
                    this._totalLength = totalLength;
                    this._streamCancellationToken = cancellationToken;
                    this._offset = 0n;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655857)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30065623153, 43044503553)
            /*bool */ get CanRead()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30065623153, 43044503553)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34360590449, 47339470849)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34360590449, 47339470849)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655557745, 55929405441)
            /*bool */ get CanWrite()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655557745, 55929405441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 98785099889, 223433129985)
            /*long */ get Length()
            {
                return this._totalLength;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 98785099889, 223433129985)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103080067185, 240612999169)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._offset;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103080067185, 240612999169)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47245492337, 128943849473)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47245492337, 128943849473)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51540459633, 137533784065)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540459633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51540459633, 137533784065)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 107375034481, 244907966465)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375034481);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$12("Synchronous reads are not supported.");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 107375034481, 244907966465)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124554903665, 326512345089)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554903665);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124554903665, 326512345089)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 137439805553, 356577116161)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439805553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 137439805553, 356577116161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 146029740145, 382346919937)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029740145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 146029740145, 382346919937)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 111670001777, 257792868353)
            /*Task<int> *//*async*/  ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111670001777);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return await this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 111670001777, 257792868353)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 115964969073, 262087835649)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964969073);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let bytesRead = await this.RequestDataFromJSAsync(buffer.Length);
                    this.ThrowIfCancellationRequested(cancellationToken);
                    $.$$.System.MemoryExtensions.CopyTo($.$$.System.Byte, bytesRead, buffer);
                    return bytesRead.length;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 115964969073, 262087835649)
            
            //--TRIMMABLE-BOUNDARY-START(141734772849)
            /*void */ ThrowIfCancellationRequested(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734772849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cancellationToken.IsCancellationRequested || this._streamCancellationToken.IsCancellationRequested)
                {
                    throw new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$16();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734772849)
            
            //--TRIMMABLE-BOUNDARY-START(120259936369)
            /*ValueTask<byte[]> *//*async*/  RequestDataFromJSAsync(/*int*/ numBytesToRead)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$typeArray($.$$.System.Byte)), $.$typeArray($.$$.System.Byte), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259936369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    numBytesToRead = $.$cast($.$$.System.Math.Min$5(BigInt(numBytesToRead), this._totalLength - this._offset), $.$$.System.Int32);
                    /*var*/ let bytesRead = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$typeArray($.$$.System.Byte), this._runtime, "Blazor._internal.getJSDataStreamChunk", $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this._jsStreamReference, $.$box(this._offset, $.$$.System.Int64), $.$box(numBytesToRead, $.$$.System.Int32) ], null, null));
                    if (bytesRead.length !== numBytesToRead)
                    {
                        throw new $.$$.System.IO.EndOfStreamException().$ctor$17("Failed to read the requested number of bytes from the stream.");
                    }
                    this._offset += BigInt(bytesRead.length);
                    if (this._offset === this._totalLength)
                    {
                        this.Dispose$1(true);
                    }
                    return bytesRead;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120259936369)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180721265)
                this._streamCancellationToken = $.$default($.$$.System.Threading.CancellationToken);
                //--TRIMMABLE-BOUNDARY-END(17180721265)
                
            }
            static $h = 852081;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94830593,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 30065623153, 43044503553),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394225,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 852081,
      "h": 30065623153,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30065623153, 43044503553),
//--TRIMMABLE-BOUNDARY-START(ALL, 34360590449, 47339470849),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328817,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 852081,
      "h": 34360590449,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34360590449, 47339470849),
//--TRIMMABLE-BOUNDARY-START(ALL, 38655557745, 55929405441),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263409,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 852081,
      "h": 38655557745,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655557745, 55929405441),
//--TRIMMABLE-BOUNDARY-START(ALL, 98785099889, 223433129985),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900198001,
        "f": 50364417
      },
      "n": "Length",
      "d": 852081,
      "h": 98785099889,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 98785099889, 223433129985),
//--TRIMMABLE-BOUNDARY-START(ALL, 103080067185, 240612999169),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490132593,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144838257,
        "f": 83918849
      },
      "n": "Position",
      "d": 852081,
      "h": 103080067185,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103080067185, 240612999169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950525041),
    {
      "r": 852081,
      "p": [
        {
          "n": "runtime",
          "p": 524395
        },
        {
          "n": "jsStreamReference",
          "p": 589931
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "CreateJSDataStream",
      "d": 852081,
      "h": 42950525041,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950525041),
//--TRIMMABLE-BOUNDARY-START(ALL, 47245492337, 128943849473),
    {
      "r": 65537,
      "n": "Flush",
      "d": 852081,
      "h": 47245492337,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47245492337, 128943849473),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540459633, 137533784065),
    {
      "r": 177537025,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 852081,
      "h": 51540459633,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540459633, 137533784065),
//--TRIMMABLE-BOUNDARY-START(ALL, 107375034481, 244907966465),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 852081,
      "h": 107375034481,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 107375034481, 244907966465),
//--TRIMMABLE-BOUNDARY-START(ALL, 124554903665, 326512345089),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94371841
        }
      ],
      "n": "Seek",
      "d": 852081,
      "h": 124554903665,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 124554903665, 326512345089),
//--TRIMMABLE-BOUNDARY-START(ALL, 137439805553, 356577116161),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 852081,
      "h": 137439805553,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 137439805553, 356577116161),
//--TRIMMABLE-BOUNDARY-START(ALL, 146029740145, 382346919937),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 852081,
      "h": 146029740145,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 146029740145, 382346919937),
//--TRIMMABLE-BOUNDARY-START(ALL, 111670001777, 257792868353),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ReadAsync",
      "d": 852081,
      "h": 111670001777,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 111670001777, 257792868353),
//--TRIMMABLE-BOUNDARY-START(ALL, 115964969073, 262087835649),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 852081,
      "h": 115964969073,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 115964969073, 262087835649),
//--TRIMMABLE-BOUNDARY-START(141734772849),
    {
      "r": 65537,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ThrowIfCancellationRequested",
      "d": 852081,
      "h": 141734772849,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734772849),
//--TRIMMABLE-BOUNDARY-START(120259936369),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$typeArray($.$$.System.Byte)).$h,
      "p": [
        {
          "n": "numBytesToRead",
          "p": 655361
        }
      ],
      "n": "RequestDataFromJSAsync",
      "d": 852081,
      "h": 120259936369,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(120259936369)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753969),
    {
      "t": 524395,
      "n": "_runtime",
      "d": 852081,
      "h": 12885753969,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753969),
//--TRIMMABLE-BOUNDARY-START(4295819377),
    {
      "t": 589931,
      "n": "_jsStreamReference",
      "d": 852081,
      "h": 4295819377,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819377),
//--TRIMMABLE-BOUNDARY-START(21475688561),
    {
      "t": 917505,
      "n": "_totalLength",
      "d": 852081,
      "h": 21475688561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688561),
//--TRIMMABLE-BOUNDARY-START(17180721265),
    {
      "t": 169934849,
      "n": "_streamCancellationToken",
      "d": 852081,
      "h": 17180721265,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721265),
//--TRIMMABLE-BOUNDARY-START(8590786673),
    {
      "t": 917505,
      "n": "_offset",
      "d": 852081,
      "h": 8590786673,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786673)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770655857),
    {
      "p": [
        {
          "n": "runtime",
          "p": 524395
        },
        {
          "n": "jsStreamReference",
          "p": 589931
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852081,
      "h": 25770655857,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770655857)
  ],
  "i": [90177537,89587713
  ],
  "h": 852081
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `PullFromJSDataStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852081)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114225)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType", ($self) => class RootComponentOperationType extends $.$$.System.Enum
        {
            static Add = 0;
            static Update = 1;
            static Remove = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Update": 1n,
                    "Remove": 2n
                };
            }
            static $h = 1114225;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591048817),
    {
      "t": 1114225,
      "n": "Add",
      "d": 1114225,
      "h": 8591048817,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591048817),
//--TRIMMABLE-BOUNDARY-START(17180983409),
    {
      "t": 1114225,
      "n": "Update",
      "d": 1114225,
      "h": 17180983409,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180983409),
//--TRIMMABLE-BOUNDARY-START(12886016113),
    {
      "t": 1114225,
      "n": "Remove",
      "d": 1114225,
      "h": 12886016113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886016113)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081521),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114225,
      "h": 4296081521,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081521)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1114225,
  "a": [
    {
      "t": 13631572,
      "c": 4308598868,
      "a": [
        {
          "v": $.$stj.System.Text.Json.Serialization.JsonStringEnumConverter$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,
          "t": 187629569
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `RootComponentOperationType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114225)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359409)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCache", ($self) => class BrowserRequestCache extends $.$$.System.Enum
        {
            static Default = 0;
            static NoStore = 1;
            static Reload = 2;
            static NoCache = 3;
            static ForceCache = 4;
            static OnlyIfCached = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2359409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "NoStore": 1n,
                    "Reload": 2n,
                    "NoCache": 3n,
                    "ForceCache": 4n,
                    "OnlyIfCached": 5n
                };
            }
            static $h = 2359409;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592294001),
    {
      "t": 2359409,
      "n": "Default",
      "d": 2359409,
      "h": 8592294001,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592294001),
//--TRIMMABLE-BOUNDARY-START(21477195889),
    {
      "t": 2359409,
      "n": "NoStore",
      "d": 2359409,
      "h": 21477195889,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477195889),
//--TRIMMABLE-BOUNDARY-START(30067130481),
    {
      "t": 2359409,
      "n": "Reload",
      "d": 2359409,
      "h": 30067130481,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067130481),
//--TRIMMABLE-BOUNDARY-START(17182228593),
    {
      "t": 2359409,
      "n": "NoCache",
      "d": 2359409,
      "h": 17182228593,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182228593),
//--TRIMMABLE-BOUNDARY-START(12887261297),
    {
      "t": 2359409,
      "n": "ForceCache",
      "d": 2359409,
      "h": 12887261297,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887261297),
//--TRIMMABLE-BOUNDARY-START(25772163185),
    {
      "t": 2359409,
      "n": "OnlyIfCached",
      "d": 2359409,
      "h": 25772163185,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772163185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326705),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359409,
      "h": 4297326705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297326705)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 2359409
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359409)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424945)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCredentials", ($self) => class BrowserRequestCredentials extends $.$$.System.Enum
        {
            static Omit = 0;
            static SameOrigin = 1;
            static Include = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2424945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Omit": 0n,
                    "SameOrigin": 1n,
                    "Include": 2n
                };
            }
            static $h = 2424945;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887326833),
    {
      "t": 2424945,
      "n": "Omit",
      "d": 2424945,
      "h": 12887326833,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887326833),
//--TRIMMABLE-BOUNDARY-START(17182294129),
    {
      "t": 2424945,
      "n": "SameOrigin",
      "d": 2424945,
      "h": 17182294129,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182294129),
//--TRIMMABLE-BOUNDARY-START(8592359537),
    {
      "t": 2424945,
      "n": "Include",
      "d": 2424945,
      "h": 8592359537,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592359537)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392241),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2424945,
      "h": 4297392241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297392241)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 2424945
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestCredentials`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424945)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490481)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestMode", ($self) => class BrowserRequestMode extends $.$$.System.Enum
        {
            static SameOrigin = 0;
            static NoCors = 1;
            static Cors = 2;
            static Navigate = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SameOrigin": 0n,
                    "NoCors": 1n,
                    "Cors": 2n,
                    "Navigate": 3n
                };
            }
            static $h = 2490481;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477326961),
    {
      "t": 2490481,
      "n": "SameOrigin",
      "d": 2490481,
      "h": 21477326961,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477326961),
//--TRIMMABLE-BOUNDARY-START(17182359665),
    {
      "t": 2490481,
      "n": "NoCors",
      "d": 2490481,
      "h": 17182359665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182359665),
//--TRIMMABLE-BOUNDARY-START(8592425073),
    {
      "t": 2490481,
      "n": "Cors",
      "d": 2490481,
      "h": 8592425073,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592425073),
//--TRIMMABLE-BOUNDARY-START(12887392369),
    {
      "t": 2490481,
      "n": "Navigate",
      "d": 2490481,
      "h": 12887392369,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887392369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457777),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2490481,
      "h": 4297457777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297457777)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 2490481
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490481)
        
        
        //--TRIMMABLE-BOUNDARY-START(4259953)
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebRendererId", ($self) => class WebRendererId extends $.$$.System.Enum
        {
            static Default = 0;
            static Server = 1;
            static WebAssembly = 2;
            static WebView = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4259953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Server": 1n,
                    "WebAssembly": 2n,
                    "WebView": 3n
                };
            }
            static $h = 4259953;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8594194545),
    {
      "t": 4259953,
      "n": "Default",
      "d": 4259953,
      "h": 8594194545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8594194545),
//--TRIMMABLE-BOUNDARY-START(12889161841),
    {
      "t": 4259953,
      "n": "Server",
      "d": 4259953,
      "h": 12889161841,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12889161841),
//--TRIMMABLE-BOUNDARY-START(17184129137),
    {
      "t": 4259953,
      "n": "WebAssembly",
      "d": 4259953,
      "h": 17184129137,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17184129137),
//--TRIMMABLE-BOUNDARY-START(21479096433),
    {
      "t": 4259953,
      "n": "WebView",
      "d": 4259953,
      "h": 21479096433,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21479096433)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4299227249),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 4259953,
      "h": 4299227249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4299227249)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 4259953
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `WebRendererId`; }
        });
        //--TRIMMABLE-BOUNDARY-END(4259953)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276913)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime", ($self) => class DefaultWebAssemblyJSRuntime extends $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime
        {
            //--TRIMMABLE-BOUNDARY-START(60132819057)
            /*DefaultWebAssemblyJSRuntime*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(60132819057)
            
            //--TRIMMABLE-BOUNDARY-START(4298244209)
            /*RootTypeCache*/ _rootComponentCache = null;
            //--TRIMMABLE-BOUNDARY-END(4298244209)
            
            //--TRIMMABLE-BOUNDARY-START(42952949873)
            /*ElementReferenceContext*/ ElementReferenceContext = null;
            //--TRIMMABLE-BOUNDARY-END(42952949873)
            
            //--TRIMMABLE-BOUNDARY-START(77312688241)
            /*Action<RootComponentOperationBatch, string>?*/ OnUpdateRootComponents = null;
            //--TRIMMABLE-BOUNDARY-END(77312688241)
            
            //--TRIMMABLE-BOUNDARY-START(77312688241)
            //--TRIMMABLE-BOUNDARY-START(25773080689)
            add_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                this.OnUpdateRootComponents = $.$$.System.Delegate.Combine(this.OnUpdateRootComponents, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25773080689)
            
            //--TRIMMABLE-BOUNDARY-START(98787524721)
            remove_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                this.OnUpdateRootComponents = $.$$.System.Delegate.Remove(this.OnUpdateRootComponents, value);
            }
            //--TRIMMABLE-BOUNDARY-END(98787524721)
            
            //--TRIMMABLE-BOUNDARY-END(77312688241)
            
            //--TRIMMABLE-BOUNDARY-START(12888178801)
            $ctor$4()
            {
                super.$ctor$3();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888178801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ElementReferenceContext = new $.$macw.Microsoft.AspNetCore.Components.WebElementReferenceContext().$ctor$2(this);
                    this.JsonSerializerOptions.Converters.System$Collections$Generic$ICollection$$$Add(new $.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter().$ctor$3(this.ElementReferenceContext), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888178801)
            
            //--TRIMMABLE-BOUNDARY-START(85902622833)
            /*JsonSerializerOptions */ ReadJsonSerializerOptions()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85902622833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.JsonSerializerOptions;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902622833)
            
            //--TRIMMABLE-BOUNDARY-START(64427786353)
            static /*string? */ InvokeDotNet(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427786353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let callInfo = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo().$ctor$3(assemblyName, methodIdentifier, dotNetObjectId, null);
                return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.Invoke($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, $.$ref(() => callInfo, ), argsJson);
            }
            //--TRIMMABLE-BOUNDARY-END(64427786353)
            
            //--TRIMMABLE-BOUNDARY-START(47247917169)
            static /*void */ EndInvokeJS(/*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247917169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$$.System.String, argsJson, new ($.$$.System.Action$$($.$$.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime, /*static*/ (/**/ argsJson) =>
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeJS($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, argsJson);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "argsJson",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 3276913,
  "h": 0,
  "f": 17825826
}));
            }
            //--TRIMMABLE-BOUNDARY-END(47247917169)
            
            //--TRIMMABLE-BOUNDARY-START(30068047985)
            static /*void */ BeginInvokeDotNet(/*string?*/ callId, /*string*/ assemblyNameOrDotNetObjectId, /*string*/ methodIdentifier, /*string*/ argsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068047985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let assemblyName;
                /*long*/ let dotNetObjectId;
                if ($.$$.System.Char.IsDigit($.$$.System.String.get_Chars.call(assemblyNameOrDotNetObjectId, 0)))
                {
                    dotNetObjectId = $.$$.System.Int64.Parse$6(assemblyNameOrDotNetObjectId, $.$$.System.Globalization.CultureInfo.InvariantCulture);
                    assemblyName = null;
                }
                else 
                {
                    dotNetObjectId = 0n;
                    assemblyName = assemblyNameOrDotNetObjectId;
                }
                /*var*/ let callInfo = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo().$ctor$3(assemblyName, methodIdentifier, dotNetObjectId, callId);
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$$.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$$.System.String), new ($.$$.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$$.System.String))().$ctor$3(callInfo, argsJson), new ($.$$.System.Action$$($.$$.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$$.System.String)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime, /*static*/ (/*state*/ state) =>
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.BeginInvokeDotNet($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, state.Item1, state.Item2);
                }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": $.$$.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$$.System.String).$h
    }
  ],
  "n": "",
  "d": 3276913,
  "h": 0,
  "f": 17825826
}));
            }
            //--TRIMMABLE-BOUNDARY-END(30068047985)
            
            //--TRIMMABLE-BOUNDARY-START(107377459313)
            static /*void */ UpdateRootComponentsCore(/*string*/ operationsJson, /*string*/ appState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377459313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let operations = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeOperations(operationsJson);
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.OnUpdateRootComponents?.Invoke(operations, appState);
                }
                catch(ex)
                {
                    $.$scsl.System.Console.Error.WriteLine$17(`Error deserializing root component operations: ${$.$$.System.Exception.ToString.call(ex)}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107377459313)
            
            //--TRIMMABLE-BOUNDARY-START(38657982577)
            static /*RootComponentOperationBatch */ DeserializeOperations(/*string*/ operationsJson)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657982577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let deserialized = $.$stj.System.Text.Json.JsonSerializer.Deserialize$31($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, operationsJson, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.RootComponentOperationBatch);
                for(/*var*/ let i = 0; i < deserialized.Operations.length; i++)
                {
                    /*var*/ let operation = $.$$.System.Array.$ReadT1.call(deserialized.Operations, i);
                    if (operation.Type === 2/*RootComponentOperationType.Remove*/)
                    {
                        continue;
                    }
                    if (operation.Marker === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`The component operation of type '${operation.Type}' requires a '${"Marker"}' to be specified.`);
                    }
                    /*var*/ let componentType = $.$firstOf($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance._rootComponentCache.GetRootType($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Assembly, $.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).TypeName), () => { throw new $.$$.System.InvalidOperationException().$ctor$12(`Root component type '${$.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).TypeName}' could not be found in the assembly '${$.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Assembly}'.`) });
                    /*var*/ let parameters = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeComponentParameters($.$$.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker));
                    operation.Descriptor = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor().$ctor$1(componentType, parameters);
                }
                return deserialized;
            }
            //--TRIMMABLE-BOUNDARY-END(38657982577)
            
            //--TRIMMABLE-BOUNDARY-START(34363015281)
            static /*WebRootComponentParameters */ DeserializeComponentParameters(/*ComponentMarker*/ marker)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363015281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let definitions = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(marker.ParameterDefinitions);
                /*var*/ let values = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterValues(marker.ParameterValues);
                /*var*/ let componentDeserializer = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.Instance;
                /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$3(parameters, definitions, $.$$.System.Collections.Generic.CollectionExtensions.AsReadOnly($.$$.System.Object, values));
            }
            //--TRIMMABLE-BOUNDARY-END(34363015281)
            
            //--TRIMMABLE-BOUNDARY-START(90197590129)
            static /*void */ ReceiveByteArrayFromJS(/*int*/ id, /*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197590129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ReceiveByteArray($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, id, data);
            }
            //--TRIMMABLE-BOUNDARY-END(90197590129)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81607655537, 141736869995)
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81607655537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.IO.Stream, $.$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream.CreateJSDataStream(this, jsStreamReference, totalLength, cancellationToken));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81607655537, 141736869995)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103082492017, 180391575659)
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082492017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$macwa.Microsoft.AspNetCore.Components.TransmitDataStreamToJS.TransmitStreamAsync(this, "Blazor._internal.receiveWebAssemblyDotNetDataStream", streamId, dotNetStreamReference);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103082492017, 180391575659)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68722753649, 4301324398)
            /*string */ Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722753649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS(identifier, argsJson, resultType, targetInstanceId);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68722753649, 4301324398)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 73017720945, 8596291694)
            /*string */ Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS$1(/*in JSInvocationInfo*/ invocationInfo)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017720945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InvokeJS$2(invocationInfo);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 73017720945, 8596291694)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4298244209)
                this._rootComponentCache = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4298244209)
                
            }
            //--TRIMMABLE-BOUNDARY-START(8593211505)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60132819057)
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime().$ctor$4();
                    //--TRIMMABLE-BOUNDARY-END(60132819057)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593211505)
            
            //Method exports
            static $exports()
            {
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_InvokeDotNet = this.InvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_EndInvokeJS = this.EndInvokeJS;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_BeginInvokeDotNet = this.BeginInvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_UpdateRootComponentsCore = this.UpdateRootComponentsCore;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_ReceiveByteArrayFromJS = this.ReceiveByteArrayFromJS;
            }
            static $h = 3276913;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 262256,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952949873),
    {
      "p": 1966188,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837851761,
        "f": 50331649
      },
      "n": "ElementReferenceContext",
      "d": 3276913,
      "h": 42952949873,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952949873)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85902622833),
    {
      "r": 3342420,
      "n": "ReadJsonSerializerOptions",
      "d": 3276913,
      "h": 85902622833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902622833),
//--TRIMMABLE-BOUNDARY-START(64427786353),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assemblyName",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "dotNetObjectId",
          "p": 917505,
          "a": [
            {
              "t": $.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.Number).$h,
              "c": Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.Number).$h)|0x100000000n)
            }
          ]
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "InvokeDotNet",
      "d": 3276913,
      "h": 64427786353,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64427786353),
//--TRIMMABLE-BOUNDARY-START(47247917169),
    {
      "r": 65537,
      "p": [
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "EndInvokeJS",
      "d": 3276913,
      "h": 47247917169,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247917169),
//--TRIMMABLE-BOUNDARY-START(30068047985),
    {
      "r": 65537,
      "p": [
        {
          "n": "callId",
          "p": 1310721
        },
        {
          "n": "assemblyNameOrDotNetObjectId",
          "p": 1310721
        },
        {
          "n": "methodIdentifier",
          "p": 1310721
        },
        {
          "n": "argsJson",
          "p": 1310721
        }
      ],
      "n": "BeginInvokeDotNet",
      "d": 3276913,
      "h": 30068047985,
      "f": 16777249,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30068047985),
//--TRIMMABLE-BOUNDARY-START(107377459313),
    {
      "r": 65537,
      "p": [
        {
          "n": "operationsJson",
          "p": 1310721
        },
        {
          "n": "appState",
          "p": 1310721
        }
      ],
      "n": "UpdateRootComponentsCore",
      "d": 3276913,
      "h": 107377459313,
      "f": 16777249,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 458763,
          "c": 4295426059
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107377459313),
//--TRIMMABLE-BOUNDARY-START(38657982577),
    {
      "r": 1048689,
      "p": [
        {
          "n": "operationsJson",
          "p": 1310721
        }
      ],
      "n": "DeserializeOperations",
      "d": 3276913,
      "h": 38657982577,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38657982577),
//--TRIMMABLE-BOUNDARY-START(34363015281),
    {
      "r": 4391025,
      "p": [
        {
          "n": "marker",
          "p": 131185
        }
      ],
      "n": "DeserializeComponentParameters",
      "d": 3276913,
      "h": 34363015281,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34363015281),
//--TRIMMABLE-BOUNDARY-START(90197590129),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "ReceiveByteArrayFromJS",
      "d": 3276913,
      "h": 90197590129,
      "f": 16777250,
      "a": [
        {
          "t": 458763,
          "c": 4295426059
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90197590129),
//--TRIMMABLE-BOUNDARY-START(ALL, 81607655537, 141736869995),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "jsStreamReference",
          "p": 589931
        },
        {
          "n": "totalLength",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadJSDataAsStreamAsync",
      "d": 3276913,
      "h": 81607655537,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81607655537, 141736869995),
//--TRIMMABLE-BOUNDARY-START(ALL, 103082492017, 180391575659),
    {
      "r": 177537025,
      "p": [
        {
          "n": "streamId",
          "p": 917505
        },
        {
          "n": "dotNetStreamReference",
          "p": 262251
        }
      ],
      "n": "TransmitStreamAsync",
      "d": 3276913,
      "h": 103082492017,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103082492017, 180391575659)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60132819057),
    {
      "t": 3276913,
      "n": "Instance",
      "d": 3276913,
      "h": 60132819057,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60132819057),
//--TRIMMABLE-BOUNDARY-START(4298244209),
    {
      "t": 1179761,
      "n": "_rootComponentCache",
      "d": 3276913,
      "h": 4298244209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888178801),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3276913,
      "h": 12888178801,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12888178801)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(77312688241),
    {
      "e": $.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$$.System.String).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$$.System.String).$h
          }
        ],
        "n": "add_OnUpdateRootComponents",
        "d": 3276913,
        "h": 25773080689,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$$.System.String).$h
          }
        ],
        "n": "remove_OnUpdateRootComponents",
        "d": 3276913,
        "h": 98787524721,
        "f": 285212673
      },
      "n": "OnUpdateRootComponents",
      "d": 3276913,
      "h": 77312688241,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(77312688241)
  ],
  "i": [90177537,393323,524395,6357102
  ],
  "h": 3276913
}; }
            static get $b() { return $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime, $.$macw.Microsoft.AspNetCore.Components.Web.Internal.IInternalWebJSInProcessRuntime ]; }
            static get $fullName() { return `DefaultWebAssemblyJSRuntime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276913)
        
        
        //--TRIMMABLE-BOUNDARY-START(458865)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter", ($self) => class ElementReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mac.Microsoft.AspNetCore.Components.ElementReference)
        {
            //--TRIMMABLE-BOUNDARY-START(17180328049)
            /*JsonEncodedText*/ static IdProperty;
            //--TRIMMABLE-BOUNDARY-END(17180328049)
            
            //--TRIMMABLE-BOUNDARY-START(4295426161)
            /*ElementReferenceContext*/ _elementReferenceContext = null;
            //--TRIMMABLE-BOUNDARY-END(4295426161)
            
            //--TRIMMABLE-BOUNDARY-START(12885360753)
            $ctor$3(/*ElementReferenceContext*/ elementReferenceContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._elementReferenceContext = elementReferenceContext;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360753)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475295345, 77322977364)
            /*ElementReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.$v.ValueTextEquals($.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter.IdProperty.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON property '${reader.$v.GetString()}'.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$10(`Unexpected JSON Token ${reader.$v.TokenType}.`);
                    }
                }
                if (id === null)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$10("__internalId is required.");
                }
                return new $.$mac.Microsoft.AspNetCore.Components.ElementReference().$ctor$3(id, this._elementReferenceContext);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475295345, 77322977364)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770262641, 150337421396)
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*ElementReference*/ value, /*JsonSerializerOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                writer.WriteStartObject();
                writer.WriteString$26($.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter.IdProperty, value.Id);
                writer.WriteEndObject();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770262641, 150337421396)
            
            //--TRIMMABLE-BOUNDARY-START(8590393457)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328049)
                    this.IdProperty = $.$stj.System.Text.Json.JsonEncodedText.Encode$2("__internalId", null);
                    //--TRIMMABLE-BOUNDARY-END(17180328049)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393457)
            
            static $h = 458865;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21475295345, 77322977364),
    {
      "r": 1900652,
      "p": [
        {
          "n": "reader",
          "p": 19333204,
          "f": 4
        },
        {
          "n": "typeToConvert",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Read",
      "d": 458865,
      "h": 21475295345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475295345, 77322977364),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770262641, 150337421396),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 19464276
        },
        {
          "n": "value",
          "p": 1900652
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "Write",
      "d": 458865,
      "h": 25770262641,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770262641, 150337421396)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328049),
    {
      "t": 2293844,
      "n": "IdProperty",
      "d": 458865,
      "h": 17180328049,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180328049),
//--TRIMMABLE-BOUNDARY-START(4295426161),
    {
      "t": 1966188,
      "n": "_elementReferenceContext",
      "d": 458865,
      "h": 4295426161,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426161)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360753),
    {
      "p": [
        {
          "n": "elementReferenceContext",
          "p": 1966188
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458865,
      "h": 12885360753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360753)
  ],
  "h": 458865
}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mac.Microsoft.AspNetCore.Components.ElementReference); }
            static get $fullName() { return `ElementReferenceJsonConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458865)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818161)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyComponentState", ($self) => class WebAssemblyComponentState extends $.$mac.Microsoft.AspNetCore.Components.Rendering.ComponentState
        {
            //--TRIMMABLE-BOUNDARY-START(4297785457)
            /*WebAssemblyRenderer*/ _renderer$1 = null;
            //--TRIMMABLE-BOUNDARY-END(4297785457)
            
            //--TRIMMABLE-BOUNDARY-START(8592752753)
            $ctor$2(/*WebAssemblyRenderer*/ renderer, /*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                super.$ctor$1(renderer, componentId, component, parentComponentState);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592752753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._renderer$1 = renderer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592752753)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12887720049, 150330933356)
            /*object? */ GetComponentKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887720049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let markerKey = this._renderer$1.GetMarkerKey(this);
                if ($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Inequality(markerKey, new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey()))
                {
                    return markerKey.Serialized();
                }
                return super.GetComponentKey();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12887720049, 150330933356)
            
            static $h = 2818161;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 7077996,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12887720049, 150330933356),
    {
      "r": 131073,
      "n": "GetComponentKey",
      "d": 2818161,
      "h": 12887720049,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12887720049, 150330933356)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297785457),
    {
      "t": 2949233,
      "n": "_renderer",
      "o": "@$1",
      "d": 2818161,
      "h": 4297785457,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785457)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592752753),
    {
      "p": [
        {
          "n": "renderer",
          "p": 2949233
        },
        {
          "n": "componentId",
          "p": 655361
        },
        {
          "n": "component",
          "p": 2752620
        },
        {
          "n": "parentComponentState",
          "p": 7077996
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818161,
      "h": 8592752753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592752753)
  ],
  "i": [89587713
  ],
  "h": 2818161
}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Rendering.ComponentState; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyComponentState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818161)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704049)
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection", ($self) => class RootComponentMappingCollection extends $.$$.System.Collections.ObjectModel.Collection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping)
        {
            //--TRIMMABLE-BOUNDARY-START(38656409713)
            /*JSComponentConfigurationStore*/ JSComponents = null;
            //--TRIMMABLE-BOUNDARY-END(38656409713)
            
            //--TRIMMABLE-BOUNDARY-START(12886605937)
            /*void */ Add$3(TComponent, /*string*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                this.Add(new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping().$ctor$4(TComponent.$type, selector));
            }
            //--TRIMMABLE-BOUNDARY-END(12886605937)
            
            //--TRIMMABLE-BOUNDARY-START(17181573233)
            /*void */ Add$2(/*Type*/ componentType, /*string*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181573233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add$1(componentType, selector, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(17181573233)
            
            //--TRIMMABLE-BOUNDARY-START(21476540529)
            /*void */ Add$1(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476540529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(componentType, "componentType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                this.Add(new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping().$ctor$3(componentType, selector, parameters));
            }
            //--TRIMMABLE-BOUNDARY-END(21476540529)
            
            //--TRIMMABLE-BOUNDARY-START(25771507825)
            /*void */ AddRange(/*IEnumerable<RootComponentMapping>*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                var $en2 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Add(item);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771507825)
            
            //--TRIMMABLE-BOUNDARY-START(8595767406)
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration.JSComponents.get
            get Microsoft$AspNetCore$Components$Web$IJSComponentConfiguration$JSComponents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12890734702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.JSComponents;
            }
            //--TRIMMABLE-BOUNDARY-END(8595767406)
            
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.JSComponents = new $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore().$ctor$1();
            }
            static $h = 1704049;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656409713),
    {
      "p": 6488174,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442417,
        "f": 50331649
      },
      "n": "JSComponents",
      "d": 1704049,
      "h": 38656409713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409713)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886605937),
    {
      "r": 65537,
      "p": [
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "g": [
        "TComponent"
      ],
      "n": "Add",
      "o": "@$3",
      "d": 1704049,
      "h": 12886605937,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12886605937),
//--TRIMMABLE-BOUNDARY-START(17181573233),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "selector",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "@$2",
      "d": 1704049,
      "h": 17181573233,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573233),
//--TRIMMABLE-BOUNDARY-START(21476540529),
    {
      "r": 65537,
      "p": [
        {
          "n": "componentType",
          "p": 187629569
        },
        {
          "n": "selector",
          "p": 1310721
        },
        {
          "n": "parameters",
          "p": 5767276
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1704049,
      "h": 21476540529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476540529),
//--TRIMMABLE-BOUNDARY-START(25771507825),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h
        }
      ],
      "n": "AddRange",
      "d": 1704049,
      "h": 25771507825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507825)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671345),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704049,
      "h": 4296671345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671345)
  ],
  "i": [$.$$.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$$.System.Collections.Generic.ICollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,62849025,62259201,$.$$.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,62521345,5832814
  ],
  "h": 1704049
}; }
            static get $b() { return $.$$.System.Collections.ObjectModel.Collection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$$.System.Collections.Generic.ICollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$$.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$$.System.Collections.IEnumerable, $.$macw.Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration ]; }
            static get $fullName() { return `RootComponentMappingCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704049)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly"))
//--TRIMMABLE-BOUNDARY-END(113)
