
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $meca, $mec, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo, $meda, $mecb, $meoc, $mxdg, $mela, $ssa, $mwr, $sdf, $sifd, $sip, $sdpc, $sxr, $stl, $sxxs, $sdc, $stew, $sipl, $stj, $mac, $mev, $srsp, $macf, $med, $mj, $macw, $mefa, $mef, $sifw, $mefp, $mecf, $mecj, $mel, $mjw) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Components.WebAssembly", 
    {"h":12,"f":"Microsoft.AspNetCore.Components.WebAssembly","v":"1.0.35.0","a":[{"t":78512129,"c":4373479425,"a":[{"v":589836,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Build client-side single-page applications (SPAs) with Blazor running under WebAssembly.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.WebAssembly","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Components.WebAssembly","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Components.WebAssembly.Tests","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.AspNetCore.Components.WebAssembly.Authentication.Tests","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"BasicTestApp","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"DynamicProxyGenAssembly2","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment", ($self) => class IWebAssemblyHostEnvironment
        {
            static $h = 1441804;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8591376396,"f":257},"n":"Environment","o":"Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment","d":1441804,"h":4296409100,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":17181310988,"f":257},"n":"BaseAddress","o":"Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress","d":1441804,"h":12886343692,"f":257}],"h":1441804}; }
            static get $fullName() { return `IWebAssemblyHostEnvironment`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods", ($self) => class IInternalJSImportMethods
        {
            static $h = 3342348;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"n":"GetPersistedState","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState","d":3342348,"h":4298309644,"f":257},{"r":1310721,"n":"GetApplicationEnvironment","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment","d":3342348,"h":8593276940,"f":257},{"r":65537,"p":[{"n":"domElementSelector","p":1310721},{"n":"componentId","p":655361},{"n":"rendererId","p":655361}],"n":"AttachRootComponentToElement","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement","d":3342348,"h":12888244236,"f":257},{"r":65537,"p":[{"n":"batchId","p":917505}],"n":"EndUpdateRootComponents","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents","d":3342348,"h":17183211532,"f":257},{"r":65537,"p":[{"n":"rendererId","p":655361}],"n":"NavigationManager_EnableNavigationInterception","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception","d":3342348,"h":21478178828,"f":257},{"r":65537,"p":[{"n":"id","p":1310721}],"n":"NavigationManager_ScrollToElement","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_ScrollToElement","d":3342348,"h":25773146124,"f":257},{"r":1310721,"n":"NavigationManager_GetLocationHref","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref","d":3342348,"h":30068113420,"f":257},{"r":1310721,"n":"NavigationManager_GetBaseUri","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri","d":3342348,"h":34363080716,"f":257},{"r":65537,"p":[{"n":"rendererId","p":655361},{"n":"value","p":262145}],"n":"NavigationManager_SetHasLocationChangingListeners","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners","d":3342348,"h":38658048012,"f":257},{"r":655361,"n":"RegisteredComponents_GetRegisteredComponentsCount","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount","d":3342348,"h":42953015308,"f":257},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"RegisteredComponents_GetAssembly","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly","d":3342348,"h":47247982604,"f":257},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"RegisteredComponents_GetTypeName","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName","d":3342348,"h":51542949900,"f":257},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"RegisteredComponents_GetParameterDefinitions","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions","d":3342348,"h":55837917196,"f":257},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"RegisteredComponents_GetParameterValues","o":"Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues","d":3342348,"h":60132884492,"f":257}],"h":3342348}; }
            static get $fullName() { return `IInternalJSImportMethods`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.Web.BrowserNavigationManagerInterop", ($self) => class BrowserNavigationManagerInterop
        {
            /*string*/ static Prefix = null;
            /*string*/ static EnableNavigationInterception = null;
            /*string*/ static GetLocationHref = null;
            /*string*/ static GetBaseUri = null;
            /*string*/ static NavigateTo = null;
            /*string*/ static Refresh = null;
            /*string*/ static SetHasLocationChangingListeners = null;
            /*string*/ static ScrollToElement = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Prefix = "Blazor._internal.navigationManager.";
                }
                {
                    this.EnableNavigationInterception = "Blazor._internal.navigationManager.enableNavigationInterception";
                }
                {
                    this.GetLocationHref = "Blazor._internal.navigationManager.getLocationHref";
                }
                {
                    this.GetBaseUri = "Blazor._internal.navigationManager.getBaseURI";
                }
                {
                    this.NavigateTo = "Blazor._internal.navigationManager.navigateTo";
                }
                {
                    this.Refresh = "Blazor._internal.navigationManager.refresh";
                }
                {
                    this.SetHasLocationChangingListeners = "Blazor._internal.navigationManager.setHasLocationChangingListeners";
                }
                {
                    this.ScrollToElement = "Blazor._internal.navigationManager.scrollToElement";
                }
            }
            static $h = 1376268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Prefix","d":1376268,"h":4296343564,"f":34},{"t":1310721,"n":"EnableNavigationInterception","d":1376268,"h":8591310860,"f":33},{"t":1310721,"n":"GetLocationHref","d":1376268,"h":12886278156,"f":33},{"t":1310721,"n":"GetBaseUri","d":1376268,"h":17181245452,"f":33},{"t":1310721,"n":"NavigateTo","d":1376268,"h":21476212748,"f":33},{"t":1310721,"n":"Refresh","d":1376268,"h":25771180044,"f":33},{"t":1310721,"n":"SetHasLocationChangingListeners","d":1376268,"h":30066147340,"f":33},{"t":1310721,"n":"ScrollToElement","d":1376268,"h":34361114636,"f":33}],"h":1376268}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `BrowserNavigationManagerInterop`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch", ($self) => class RootComponentOperationBatch extends $.$spc.System.Object
        {
            /*long*/ BatchId = 0n;
            /*RootComponentOperation[]*/ Operations = null;
            /*string */ GetDebuggerDisplay()
            {
                return `${"RootComponentOperationBatch"}: ${this.BatchId}, Operations Count: ${this.Operations.length}`;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1048588;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885950476,"f":1},"s":{"r":0,"d":0,"h":17180917772,"f":1},"n":"BatchId","d":1048588,"h":8590983180,"f":1},{"p":0,"g":{"r":0,"d":0,"h":30065819660,"f":1},"s":{"r":0,"d":0,"h":34360786956,"f":1},"n":"Operations","d":1048588,"h":25770852364,"f":1}],"m":[{"r":1310721,"n":"GetDebuggerDisplay","d":1048588,"h":38655754252,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1048588,"h":42950721548,"f":1}],"h":1048588,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{GetDebuggerDisplay(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `RootComponentOperationBatch`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.ConsoleLoggerInterop", ($self) => class ConsoleLoggerInterop
        {
            static $h = 3211276;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3211276}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ConsoleLoggerInterop`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader", ($self) => class LazyAssemblyLoader extends $.$spc.System.Object
        {
            static $_LazyAssemblyLoaderInterop;
            static get LazyAssemblyLoaderInterop()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader;
                return $cls.$_LazyAssemblyLoaderInterop ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop", ($self) => class LazyAssemblyLoaderInterop extends $.$spc.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3538956;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":3538956,"h":8593473548,"f":1}],"d":3473420,"h":3538956}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `LazyAssemblyLoader.LazyAssemblyLoaderInterop`; }
                }, $cls, ($v) => $cls.$_LazyAssemblyLoaderInterop = $v);
            }
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Task<IEnumerable<Assembly>> */ LoadAssembliesAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                if ($.$spc.System.OperatingSystem.IsBrowser())
                {
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LoadAssembliesInClientAsync(assembliesToLoad);
                }
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LoadAssembliesInServerAsync(assembliesToLoad);
            }
            static /*Task<IEnumerable<Assembly>> */ LoadAssembliesInServerAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                /*var*/ let loadedAssemblies = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.Assembly))().$ctor$1();
                try
                {
                    var $en3 = assembliesToLoad.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var assemblyName = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            loadedAssemblies.Add($.$spc.System.Reflection.Assembly.Load($.$spc.System.IO.Path.GetFileNameWithoutExtension(assemblyName)));
                        }
                    }
                }
                catch(ex)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unable to find the following assembly: ${ex.FileName}. Make sure that the appplication is referencing the assemblies and that they are present in the output folder.`);
                }
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly), loadedAssemblies);
            }
            static /*Task<IEnumerable<Assembly>> *//*async*/  LoadAssembliesInClientAsync(/*IEnumerable<string>*/ assembliesToLoad)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly), async () => 
                {
                    /*var*/ let newAssembliesToLoad = $.$sl.System.Linq.Enumerable.ToList($.$spc.System.String, assembliesToLoad);
                    /*var*/ let loadedAssemblies = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Reflection.Assembly))().$ctor$1();
                    /*var*/ let pendingLoads = $.$sl.System.Linq.Enumerable.Select($.$spc.System.String, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean), newAssembliesToLoad, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.Threading.Tasks.Task$$($.$spc.System.Boolean)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader.LazyAssemblyLoaderInterop.LoadLazyAssembly));
                    /*var*/ let loadedStatus = await $.$spc.System.Threading.Tasks.Task.WhenAll$3($.$spc.System.Boolean, pendingLoads);
                    /*int*/ let i = 0;
                    /*List<Assembly>?*/ let allAssemblies = null;
                    let $i1 = 0;
                    let $arr1 = loadedStatus;
                    while ($i1 < $arr1.length)
                    {
                        let loaded = $arr1[$i1++];
                        if (loaded)
                        {
                            if (allAssemblies === null)
                            {
                                allAssemblies = $.$sl.System.Linq.Enumerable.ToList($.$spc.System.Reflection.Assembly, $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.Assemblies);
                            }
                            /*var*/ let assemblyName = $.$spc.System.IO.Path.GetFileNameWithoutExtension(newAssembliesToLoad.get_Item(i));
                            /*var*/ let assembly = $.$sl.System.Linq.Enumerable.FirstOrDefault$2($.$spc.System.Reflection.Assembly, $.$spc.System.Runtime.Loader.AssemblyLoadContext.Default.Assemblies, new ($.$spc.System.Func$$$($.$spc.System.Reflection.Assembly, $.$spc.System.Boolean))().$ctor(this,  (/**/ a) =>
                            {
                                return $.$spc.System.String.op_Equality(a.GetName().Name, assemblyName);
                            }, {"r":262145,"p":[{"n":"a","p":73465857}],"n":"","d":3473420,"h":0,"f":1048578}));
                            if ($.$spc.System.Reflection.Assembly.op_Inequality(assembly, null))
                            {
                                loadedAssemblies.Add(assembly);
                            }
                        }
                        i++;
                    }
                    return loadedAssemblies;
                });
            }
            static $h = 3473420;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly)).$h,"p":[{"n":"assembliesToLoad","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"LoadAssembliesAsync","d":3473420,"h":12888375308,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly)).$h,"p":[{"n":"assembliesToLoad","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"LoadAssembliesInServerAsync","d":3473420,"h":17183342604,"f":34},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Reflection.Assembly)).$h,"p":[{"n":"assembliesToLoad","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"LoadAssembliesInClientAsync","d":3473420,"h":21478309900,"f":4130,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]}],"c":[{"p":[{"n":"jsRuntime","p":524318}],"n":".ctor","o":"$ctor$1","d":3473420,"h":8593408012,"f":1}],"j":[3538956],"h":3473420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LazyAssemblyLoader`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider", ($self) => class WebAssemblyCultureProvider extends $.$spc.System.Object
        {
            static $_WebAssemblyCultureProviderInterop;
            static get WebAssemblyCultureProviderInterop()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider;
                return $cls.$_WebAssemblyCultureProviderInterop ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop", ($self) => class WebAssemblyCultureProviderInterop extends $.$spc.System.Object
                {
                    static /*Task */ LoadSatelliteAssemblies(/*string[]*/ culturesToLoad)
                    {
                        return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1900556;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"culturesToLoad","p":0}],"n":"LoadSatelliteAssemblies","d":1900556,"h":4296867852,"f":33,"a":[{"t":1240457,"c":30066011529,"a":[{"v":"INTERNAL.loadSatelliteAssemblies","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1900556,"h":8591835148,"f":1}],"d":1835020,"h":1900556}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop`; }
                }, $cls, ($v) => $cls.$_WebAssemblyCultureProviderInterop = $v);
            }
            /*string*/ static GetSatelliteAssemblies = null;
            /*string*/ static ReadSatelliteAssemblies = null;
            $ctor$1(/*CultureInfo*/ initialCulture, /*CultureInfo*/ initialUICulture)
            {
                super.$ctor();
                {
                    this.InitialCulture = initialCulture;
                    this.InitialUICulture = initialUICulture;
                }
                return this;
            }
            /*WebAssemblyCultureProvider?*/ static Instance = null;
            /*CultureInfo*/ InitialCulture = null;
            /*CultureInfo*/ InitialUICulture = null;
            static /*void */ Initialize()
            {
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider().$ctor$1($.$spc.System.Globalization.CultureInfo.CurrentCulture, $.$spc.System.Globalization.CultureInfo.CurrentUICulture);
            }
            /*void */ ThrowIfCultureChangeIsUnsupported()
            {
                if ($.$spc.System.String.op_Equality($.$spc.System.Environment.GetEnvironmentVariable("__BLAZOR_SHARDED_ICU"), "1") && ((!$.$spc.System.String.Equals$3.call($.$spc.System.Globalization.CultureInfo.CurrentCulture.Name, this.InitialCulture.Name, 4/*StringComparison.Ordinal*/) || !$.$spc.System.String.Equals$3.call($.$spc.System.Globalization.CultureInfo.CurrentUICulture.Name, this.InitialUICulture.Name, 4/*StringComparison.Ordinal*/))))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Blazor detected a change in the application's culture that is not supported with the current project configuration. " + "To change culture dynamically during startup, set <BlazorWebAssemblyLoadAllGlobalizationData>true</BlazorWebAssemblyLoadAllGlobalizationData> in the application's project file.");
                }
            }
            /*ValueTask *//*async*/  LoadCurrentCultureResourcesAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (!$.$spc.System.OperatingSystem.IsBrowser())
                    {
                        throw new $.$spc.System.PlatformNotSupportedException().$ctor$14("This method is only supported in the browser.");
                    }
                    /*var*/ let culturesToLoad = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultures($.$spc.System.Globalization.CultureInfo.CurrentCulture, $.$spc.System.Globalization.CultureInfo.CurrentUICulture);
                    if (culturesToLoad.length === 0)
                    {
                        return;
                    }
                    await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.WebAssemblyCultureProviderInterop.LoadSatelliteAssemblies(culturesToLoad);
                });
            }
            static /*string[] */ GetCultures(/*CultureInfo*/ cultureInfo, /*CultureInfo?*/ uiCultureInfo)
            {
                /*var*/ let culturesToLoad = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultureHierarchy(cultureInfo);
                if (cultureInfo !== uiCultureInfo)
                {
                    var $en3 = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.GetCultureHierarchy(uiCultureInfo).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var culture = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!$.$sl.System.Linq.Enumerable.Contains($.$spc.System.String, culturesToLoad, culture))
                            {
                                culturesToLoad = $.$sl.System.Linq.Enumerable.Append($.$spc.System.String, culturesToLoad, culture);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                }
                return $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.String, culturesToLoad);
            }
            static /*IEnumerable<string> */ GetCultureHierarchy(/*CultureInfo?*/ culture)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    while(culture !== $.$spc.System.Globalization.CultureInfo.InvariantCulture && culture !== null)
                    {
                        yield culture.Name;
                        if (culture === culture.Parent)
                        {
                            break;
                        }
                        culture = culture.Parent;
                    }
                }.bind(this));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.GetSatelliteAssemblies = "window.Blazor._internal.getSatelliteAssemblies";
                }
                {
                    this.ReadSatelliteAssemblies = "window.Blazor._internal.readSatelliteAssemblies";
                }
            }
            static $h = 1835020;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1835020,"g":{"r":0,"d":0,"h":30066606092,"f":33},"s":{"r":0,"d":0,"h":34361573388,"f":34},"n":"Instance","d":1835020,"h":25771638796,"f":33},{"p":51183617,"g":{"r":0,"d":0,"h":47246475276,"f":1},"n":"InitialCulture","d":1835020,"h":42951507980,"f":1},{"p":51183617,"g":{"r":0,"d":0,"h":60131377164,"f":1},"n":"InitialUICulture","d":1835020,"h":55836409868,"f":1}],"m":[{"r":65537,"n":"Initialize","d":1835020,"h":64426344460,"f":40},{"r":65537,"n":"ThrowIfCultureChangeIsUnsupported","d":1835020,"h":68721311756,"f":1},{"r":136118273,"n":"LoadCurrentCultureResourcesAsync","d":1835020,"h":73016279052,"f":4225},{"r":0,"p":[{"n":"cultureInfo","p":51183617},{"n":"uiCultureInfo","p":51183617,"f":65}],"n":"GetCultures","d":1835020,"h":77311246348,"f":40},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"culture","p":51183617}],"n":"GetCultureHierarchy","d":1835020,"h":81606213644,"f":34}],"l":[{"t":1310721,"n":"GetSatelliteAssemblies","d":1835020,"h":8591769612,"f":40},{"t":1310721,"n":"ReadSatelliteAssemblies","d":1835020,"h":12886736908,"f":40}],"c":[{"p":[{"n":"initialCulture","p":51183617},{"n":"initialUICulture","p":51183617}],"n":".ctor","o":"$ctor$1","d":1835020,"h":17181704204,"f":8}],"j":[1900556],"h":1835020}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyCultureProvider`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.JsonSerializerOptionsProvider", ($self) => class JsonSerializerOptionsProvider
        {
            /*JsonSerializerOptions*/ static Options = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Options = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.IncludeFields = true;
                        return $i1;
                    })();
                }
            }
            static $h = 655372;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3380909,"n":"Options","d":655372,"h":4295622668,"f":33}],"h":655372}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JsonSerializerOptionsProvider`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Internal.LinkerFlags", ($self) => class LinkerFlags
        {
            /*DynamicallyAccessedMemberTypes*/ static JsonSerialized = 547;
            /*DynamicallyAccessedMemberTypes*/ static Component = -1;
            /*DynamicallyAccessedMemberTypes*/ static JSInvokable = 8;
            static $h = 4456460;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":35913729,"n":"JsonSerialized","d":4456460,"h":4299423756,"f":33},{"t":35913729,"n":"Component","d":4456460,"h":8594391052,"f":33},{"t":35913729,"n":"JSInvokable","d":4456460,"h":12889358348,"f":33}],"h":4456460}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LinkerFlags`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RegisteredComponentsInterop", ($self) => class RegisteredComponentsInterop extends $.$spc.System.Object
        {
            /*string*/ static Prefix = null;
            /*string*/ static GetRegisteredComponentsCount = null;
            /*string*/ static GetId = null;
            /*string*/ static GetAssembly = null;
            /*string*/ static GetTypeName = null;
            /*string*/ static GetParameterDefinitions = null;
            /*string*/ static GetParameterValues = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Prefix = "Blazor._internal.registeredComponents.";
                }
                {
                    this.GetRegisteredComponentsCount = "Blazor._internal.registeredComponents.getRegisteredComponentsCount";
                }
                {
                    this.GetId = "Blazor._internal.registeredComponents.getId";
                }
                {
                    this.GetAssembly = "Blazor._internal.registeredComponents.getAssembly";
                }
                {
                    this.GetTypeName = "Blazor._internal.registeredComponents.getTypeName";
                }
                {
                    this.GetParameterDefinitions = "Blazor._internal.registeredComponents.getParameterDefinitions";
                }
                {
                    this.GetParameterValues = "Blazor._internal.registeredComponents.getParameterValues";
                }
            }
            static $h = 1572876;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Prefix","d":1572876,"h":4296540172,"f":34},{"t":1310721,"n":"GetRegisteredComponentsCount","d":1572876,"h":8591507468,"f":33},{"t":1310721,"n":"GetId","d":1572876,"h":12886474764,"f":33},{"t":1310721,"n":"GetAssembly","d":1572876,"h":17181442060,"f":33},{"t":1310721,"n":"GetTypeName","d":1572876,"h":21476409356,"f":33},{"t":1310721,"n":"GetParameterDefinitions","d":1572876,"h":25771376652,"f":33},{"t":1310721,"n":"GetParameterValues","d":1572876,"h":30066343948,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1572876,"h":34361311244,"f":1}],"h":1572876}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `RegisteredComponentsInterop`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider", ($self) => class ResourceCollectionProvider extends $.$spc.System.Object
        {
            /*string?*/ _url = null;
            /*string? */ get ResourceCollectionUrl()
            {
                return this._url;
            }
            /*string? */ set ResourceCollectionUrl(value)
            {
                if ($.$spc.System.String.op_Inequality(this._url, null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("The resource collection URL has already been set.");
                }
                this._url = value;
            }
            /*ResourceAssetCollection?*/ _resourceCollection = null;
            /*IJSRuntime*/ _jsRuntime = null;
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*Task<ResourceAssetCollection> *//*async*/  GetResourceCollection()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection), $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection, async () => 
                {
                    this._resourceCollection = this._resourceCollection ??= await this.LoadResourceCollection();
                    return this._resourceCollection;
                });
            }
            /*void */ SetResourceCollection(/*ResourceAssetCollection*/ resourceCollection)
            {
                this._resourceCollection = resourceCollection;
            }
            /*Task<ResourceAssetCollection> *//*async*/  LoadResourceCollection()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection), $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection, async () => 
                {
                    if ($.$spc.System.String.op_Equality(this._url, null))
                    {
                        return $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection.Empty;
                    }
                    /*var*/ let module = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$mj.Microsoft.JSInterop.IJSObjectReference, this._jsRuntime, "import", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ this._url ], null, null));
                    /*var*/ let result = await $.$mj.Microsoft.JSInterop.JSObjectReferenceExtensions.InvokeAsync($.$typeArray($.$mac.Microsoft.AspNetCore.Components.ResourceAsset), module, "get", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [  ], null, null));
                    return result === null ? $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection.Empty : new $.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection().$ctor$1(result);
                });
            }
            static $h = 917516;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885819404,"f":1},"s":{"r":0,"d":0,"h":17180786700,"f":1},"n":"ResourceCollectionUrl","d":917516,"h":8590852108,"f":1,"a":[{"t":6357000,"c":38661062664}]}],"m":[{"r":$.$spc.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection).$h,"n":"GetResourceCollection","d":917516,"h":34360655884,"f":4104},{"r":65537,"p":[{"n":"resourceCollection","p":9437192}],"n":"SetResourceCollection","d":917516,"h":38655623180,"f":8},{"r":$.$spc.System.Threading.Tasks.Task$$($.$mac.Microsoft.AspNetCore.Components.ResourceAssetCollection).$h,"n":"LoadResourceCollection","d":917516,"h":42950590476,"f":4098}],"l":[{"t":1310721,"n":"_url","d":917516,"h":4295884812,"f":2},{"t":9437192,"n":"_resourceCollection","d":917516,"h":21475753996,"f":2},{"t":524318,"n":"_jsRuntime","d":917516,"h":25770721292,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":524318}],"n":".ctor","o":"$ctor$1","d":917516,"h":30065688588,"f":1}],"h":917516}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ResourceCollectionProvider`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions", ($self) => class WebAssemblyHostEnvironmentExtensions
        {
            static /*bool */ IsDevelopment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Development");
            }
            static /*bool */ IsStaging(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Staging");
            }
            static /*bool */ IsProduction(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(hostingEnvironment, "hostingEnvironment");
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsEnvironment(hostingEnvironment, "Production");
            }
            static /*bool */ IsEnvironment(/*this IWebAssemblyHostEnvironment*/ hostingEnvironment, /*string*/ environmentName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(hostingEnvironment, "hostingEnvironment");
                return $.$spc.System.String.Equals$5(hostingEnvironment.Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment, environmentName, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            static $h = 2293772;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"hostingEnvironment","p":1441804}],"n":"IsDevelopment","d":2293772,"h":4297261068,"f":33},{"r":262145,"p":[{"n":"hostingEnvironment","p":1441804}],"n":"IsStaging","d":2293772,"h":8592228364,"f":33},{"r":262145,"p":[{"n":"hostingEnvironment","p":1441804}],"n":"IsProduction","d":2293772,"h":12887195660,"f":33},{"r":262145,"p":[{"n":"hostingEnvironment","p":1441804},{"n":"environmentName","p":1310721}],"n":"IsEnvironment","d":2293772,"h":17182162956,"f":33}],"h":2293772}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyHostEnvironmentExtensions`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions", ($self) => class WebAssemblyHttpRequestMessageExtensions
        {
            /*HttpRequestOptionsKey<IDictionary<string, object>>*/ static FetchRequestOptionsKey;
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingRequestKey;
            /*HttpRequestOptionsKey<bool>*/ static WebAssemblyEnableStreamingResponseKey;
            static /*HttpRequestMessage */ SetBrowserRequestCredentials(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCredentials*/ requestCredentials)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCredentials === 0/*BrowserRequestCredentials.Omit*/)
                    {
                        return "omit";
                    }
                    if (requestCredentials === 1/*BrowserRequestCredentials.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestCredentials === 2/*BrowserRequestCredentials.Include*/)
                    {
                        return "include";
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unsupported enum value ${requestCredentials}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "credentials", stringOption);
            }
            static /*HttpRequestMessage */ SetBrowserRequestCache(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestCache*/ requestCache)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestCache === 0/*BrowserRequestCache.Default*/)
                    {
                        return $.$default();
                    }
                    if (requestCache === 1/*BrowserRequestCache.NoStore*/)
                    {
                        return "no-store";
                    }
                    if (requestCache === 2/*BrowserRequestCache.Reload*/)
                    {
                        return "reload";
                    }
                    if (requestCache === 3/*BrowserRequestCache.NoCache*/)
                    {
                        return "no-cache";
                    }
                    if (requestCache === 4/*BrowserRequestCache.ForceCache*/)
                    {
                        return "force-cache";
                    }
                    if (requestCache === 5/*BrowserRequestCache.OnlyIfCached*/)
                    {
                        return "only-if-cached";
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unsupported enum value ${requestCache}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "cache", stringOption);
            }
            static /*HttpRequestMessage */ SetBrowserRequestMode(/*this HttpRequestMessage*/ requestMessage, /*BrowserRequestMode*/ requestMode)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                /*var*/ let stringOption = (() =>
                {
                    if (requestMode === 0/*BrowserRequestMode.SameOrigin*/)
                    {
                        return "same-origin";
                    }
                    if (requestMode === 1/*BrowserRequestMode.NoCors*/)
                    {
                        return "no-cors";
                    }
                    if (requestMode === 2/*BrowserRequestMode.Cors*/)
                    {
                        return "cors";
                    }
                    if (requestMode === 3/*BrowserRequestMode.Navigate*/)
                    {
                        return "navigate";
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`Unsupported enum value ${requestMode}.`);
                })();
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "mode", stringOption);
            }
            static /*HttpRequestMessage */ SetBrowserRequestIntegrity(/*this HttpRequestMessage*/ requestMessage, /*string*/ integrity)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.SetBrowserRequestOption(requestMessage, "integrity", integrity);
            }
            static /*HttpRequestMessage */ SetBrowserRequestOption(/*this HttpRequestMessage*/ requestMessage, /*string*/ name, /*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                /*IDictionary<string, object>*/ let fetchOptions;
                /*var*/ let entry;
                if (requestMessage.Options.TryGetValue($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, $.$ref(() => entry, ($v) => entry = $v, $.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object))))
                {
                    fetchOptions = entry;
                }
                else 
                {
                    fetchOptions = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$3($.$spc.System.StringComparer.Ordinal);
                    requestMessage.Options.Set($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.FetchRequestOptionsKey, fetchOptions);
                }
                fetchOptions.System$Collections$Generic$IDictionary$$$$set_Item(name, value, [$.$spc.System.String, $.$spc.System.Object]);
                return requestMessage;
            }
            static /*HttpRequestMessage */ SetBrowserRequestStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$spc.System.Boolean, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingRequestKey, streamingEnabled);
                return requestMessage;
            }
            static /*HttpRequestMessage */ SetBrowserResponseStreamingEnabled(/*this HttpRequestMessage*/ requestMessage, /*bool*/ streamingEnabled)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(requestMessage, "requestMessage");
                requestMessage.Options.Set($.$spc.System.Boolean, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.WebAssemblyHttpRequestMessageExtensions.WebAssemblyEnableStreamingResponseKey, streamingEnabled);
                return requestMessage;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.FetchRequestOptionsKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$2("WebAssemblyFetchOptions");
                }
                {
                    this.WebAssemblyEnableStreamingRequestKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Boolean))().$ctor$2("WebAssemblyEnableStreamingRequest");
                }
                {
                    this.WebAssemblyEnableStreamingResponseKey = new ($.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Boolean))().$ctor$2("WebAssemblyEnableStreamingResponse");
                }
            }
            static $h = 2555916;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"requestCredentials","p":2424844}],"n":"SetBrowserRequestCredentials","d":2555916,"h":17182425100,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"requestCache","p":2359308}],"n":"SetBrowserRequestCache","d":2555916,"h":21477392396,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"requestMode","p":2490380}],"n":"SetBrowserRequestMode","d":2555916,"h":25772359692,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"integrity","p":1310721}],"n":"SetBrowserRequestIntegrity","d":2555916,"h":30067326988,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"SetBrowserRequestOption","d":2555916,"h":34362294284,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"streamingEnabled","p":262145}],"n":"SetBrowserRequestStreamingEnabled","d":2555916,"h":38657261580,"f":33},{"r":7536685,"p":[{"n":"requestMessage","p":7536685},{"n":"streamingEnabled","p":262145}],"n":"SetBrowserResponseStreamingEnabled","d":2555916,"h":42952228876,"f":33}],"l":[{"t":$.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"FetchRequestOptionsKey","d":2555916,"h":4297523212,"f":34},{"t":$.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Boolean).$h,"n":"WebAssemblyEnableStreamingRequestKey","d":2555916,"h":8592490508,"f":34},{"t":$.$snh.System.Net.Http.HttpRequestOptionsKey$$($.$spc.System.Boolean).$h,"n":"WebAssemblyEnableStreamingResponseKey","d":2555916,"h":12887457804,"f":34}],"h":2555916}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyHttpRequestMessageExtensions`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.JSInteropMethods", ($self) => class JSInteropMethods
        {
            static /*void */ NotifyLocationChanged(/*string*/ uri, /*bool*/ isInterceptedLink)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.SetLocation(uri, null, isInterceptedLink);
            }
            static /*void */ NotifyLocationChanged$1(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.SetLocation(uri, state, isInterceptedLink);
            }
            static /*ValueTask<bool> *//*async*/  NotifyLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    return await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.HandleLocationChangingAsync(uri, state, isInterceptedLink);
                });
            }
            static $h = 2621452;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"isInterceptedLink","p":262145}],"n":"NotifyLocationChanged","d":2621452,"h":4297588748,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API is for framework use only and is no longer used in the current version","t":1310721}]}]},{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"state","p":1310721},{"n":"isInterceptedLink","p":262145}],"n":"NotifyLocationChanged","o":"@$1","d":2621452,"h":8592556044,"f":33,"a":[{"t":2818078,"c":21477654558,"a":[{"v":"NotifyLocationChanged","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"uri","p":1310721},{"n":"state","p":1310721},{"n":"isInterceptedLink","p":262145}],"n":"NotifyLocationChangingAsync","d":2621452,"h":12887523340,"f":4129,"a":[{"t":2818078,"c":21477654558,"a":[{"v":"NotifyLocationChangingAsync","t":1310721}]}]}],"h":2621452,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `JSInteropMethods`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager", ($self) => class HotReloadManager extends $.$spc.System.Object
        {
            /*HotReloadManager*/ static Default = null;
            /*bool*/ MetadataUpdateSupported = false;
            /*bool */ get IsSubscribedTo()
            {
                return !(this.OnDeltaApplied === null);
            }
            /*Action?*/ OnDeltaApplied = null;
            add_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Combine(this.OnDeltaApplied, value);
            }
            remove_OnDeltaApplied(/*Action?*/ value)
            {
                this.OnDeltaApplied = $.$spc.System.Delegate.Remove(this.OnDeltaApplied, value);
            }
            static /*void */ UpdateApplication(/*Type[]?*/ _)
            {
                return ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.OnDeltaApplied?.Invoke() ?? null);
            }
            /*void */ TriggerOnDeltaApplied()
            {
                return (this.OnDeltaApplied?.Invoke() ?? null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.MetadataUpdateSupported = $.$spc.System.Reflection.Metadata.MetadataUpdater.IsSupported;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager().$ctor$1();
                }
            }
            static $h = 589836;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180459020,"f":1},"s":{"r":0,"d":0,"h":21475426316,"f":1},"n":"MetadataUpdateSupported","d":589836,"h":12885491724,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065360908,"f":1},"n":"IsSubscribedTo","d":589836,"h":25770393612,"f":1}],"m":[{"r":65537,"p":[{"n":"_","p":0}],"n":"UpdateApplication","d":589836,"h":47245230092,"f":33},{"r":65537,"n":"TriggerOnDeltaApplied","d":589836,"h":51540197388,"f":8}],"l":[{"t":589836,"n":"Default","d":589836,"h":4295557132,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":589836,"h":55835164684,"f":1}],"e":[{"e":11665409,"m":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"add_OnDeltaApplied","d":589836,"h":34360328204,"f":1},"r":{"r":65537,"p":[{"n":"value","p":11665409}],"n":"remove_OnDeltaApplied","d":589836,"h":38655295500,"f":1},"n":"OnDeltaApplied","d":589836,"h":42950262796,"f":1}],"h":589836}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `HotReloadManager`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue", ($self) => class WebAssemblyCallQueue
        {
            /*bool*/ static _isCallInProgress = false;
            /*Queue<Action>*/ static _pendingWork = null;
            static /*bool */ get IsInProgress()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress;
            }
            static /*bool */ get HasUnstartedWork()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.Count > 0;
            }
            static /*void */ Schedule(T, /*T*/ state, /*Action<T>*/ callback)
            {
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress)
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.Enqueue(new $.$spc.System.Action().$ctor(this,  () =>
                    {
                        return callback.Invoke(state);
                    }, {"r":65537,"n":"","d":1769484,"h":0,"f":1048578}));
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress = true;
                    callback.Invoke(state);
                    /*var*/ let nextWorkItem;
                    while($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._pendingWork.TryDequeue($.$ref(() => nextWorkItem, ($v) => nextWorkItem = $v, $.$spc.System.Action)))
                    {
                        nextWorkItem.Invoke();
                    }
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue._isCallInProgress = false;
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._pendingWork = new ($.$spc.System.Collections.Generic.Queue$$($.$spc.System.Action))().$ctor$1();
                }
            }
            static $h = 1769484;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181638668,"f":33},"n":"IsInProgress","d":1769484,"h":12886671372,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25771573260,"f":33},"n":"HasUnstartedWork","d":1769484,"h":21476605964,"f":33}],"m":[{"r":65537,"p":[{"n":"state","p":(T) => T.$h},{"n":"callback","p":(T) => $.$spc.System.Action$$(T).$h}],"g":["T"],"n":"Schedule","d":1769484,"h":30066540556,"f":131105}],"l":[{"t":262145,"n":"_isCallInProgress","d":1769484,"h":4296736780,"f":34},{"t":$.$spc.System.Collections.Generic.Queue$$($.$spc.System.Action).$h,"n":"_pendingWork","d":1769484,"h":8591704076,"f":34}],"h":1769484}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyCallQueue`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.TransmitDataStreamToJS", ($self) => class TransmitDataStreamToJS
        {
            static /*Task *//*async*/  TransmitStreamAsync(/*IJSRuntime*/ runtime, /*string*/ methodIdentifier, /*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*var*/ let buffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Rent(((32 * 1024) | 0));
                    try
                    {
                        /*int*/ let bytesRead;
                        while((bytesRead = await dotNetStreamReference.Stream.ReadAsync$2($.$spc.System.Memory$$($.$spc.System.Byte).op_Implicit(buffer), new $.$spc.System.Threading.CancellationToken())) > 0)
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(streamId, $.$spc.System.Int64), buffer, $.$box(bytesRead, $.$spc.System.Int32), null ], null, null));
                        }
                        await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(streamId, $.$spc.System.Int64), $.$spc.System.Array.Empty($.$spc.System.Byte), $.$box(0, $.$spc.System.Int32), null ], null, null));
                    }
                    catch(ex)
                    {
                        try
                        {
                            await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeVoidAsync(runtime, methodIdentifier, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(streamId, $.$spc.System.Int64), $.$spc.System.Array.Empty($.$spc.System.Byte), $.$box(0, $.$spc.System.Int32), ex.Message ], null, null));
                        }
                        catch($e)
                        {
                        }
                        throw ex;
                    }
                    finally
                    {
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Byte).Shared.Return(buffer, true);
                            if (!dotNetStreamReference.LeaveOpen)
                            {
                                dotNetStreamReference.Stream?.Dispose();
                            }
                        }
                    }
                });
            }
            static $h = 1310732;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"runtime","p":524318},{"n":"methodIdentifier","p":1310721},{"n":"streamId","p":917505},{"n":"dotNetStreamReference","p":262174}],"n":"TransmitStreamAsync","d":1310732,"h":4296278028,"f":4136}],"h":1310732}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `TransmitDataStreamToJS`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache", ($self) => class ComponentParametersTypeCache extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            /*Type? */ GetParameterType(/*string*/ assembly, /*string*/ type)
            {
                /*var*/ let key = new $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key().$ctor$2(assembly, type);
                /*var*/ let resolvedType;
                if (this._typeToKeyLookUp.TryGetValue(key.Clone(), $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$spc.System.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$1($.$typeArray($.$spc.System.Reflection.Assembly), key.Clone(), new ($.$spc.System.Func$$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$typeArray($.$spc.System.Reflection.Assembly), $.$spc.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache, $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.ResolveType), $.$spc.System.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$spc.System.Array.$ReadT1.call(assemblies, i);
                    if ($.$spc.System.String.op_Equality(current.GetName().Name, key.Assembly))
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$spc.System.Reflection.Assembly.op_Equality(assembly, null))
                {
                    if ($.$spc.System.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$spc.System.Reflection.Assembly.Load(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$3(key.Type, false, false);
            }
            static $_Key;
            static get Key()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache;
                return $cls.$_Key ??= $asm.$nstr("$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key", ($self) => class Key extends $.$spc.System.ValueType
                {
                    $ctor$2(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        $.$tupleUnpack(($tp) =>
                        {
                            this.Assembly = $tp.Item1;
                            this.Type = $tp.Item2;
                        }).$v = { Item1: assembly, Item2: type };
                        return this;
                    }
                    /*string*/ Assembly = null;
                    /*string*/ Type = null;
                    static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
                    {
                        let key;
                        return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, { set $v(v){ key = v; } }) && this.Equals$2(key.Clone());
                    }
                    //Static convention instance redirect
                    /*bool */ Equals() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key.Equals.apply(this, arguments); }
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        return $.$spc.System.String.Equals$5(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$spc.System.String.Equals$5(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                    }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$spc.System.HashCode.Combine$1($.$spc.System.String, $.$spc.System.String, this.Assembly, this.Type);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key.GetHashCode.apply(this, arguments); }
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 393228;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180262412,"f":1},"s":{"r":0,"d":0,"h":21475229708,"f":1},"n":"Assembly","d":393228,"h":12885295116,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360131596,"f":1},"s":{"r":0,"d":0,"h":38655098892,"f":1},"n":"Type","d":393228,"h":30065164300,"f":1}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":393228,"h":42950066188,"f":32769},{"r":262145,"p":[{"n":"other","p":393228}],"n":"Equals","o":"@$2","d":393228,"h":47245033484,"f":1},{"r":655361,"n":"GetHashCode","d":393228,"h":51540000780,"f":32769}],"c":[{"p":[{"n":"assembly","p":1310721},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$2","d":393228,"h":4295360524,"f":1},{"n":".ctor","o":"$ctor$3","d":393228,"h":55834968076,"f":1}],"i":[$.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key).$h],"d":327692,"h":393228}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key) ]; }
                    static get $fullName() { return `ComponentParametersTypeCache.Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._typeToKeyLookUp = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$spc.System.Type))().$ctor$1();
            }
            static $h = 327692;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":142606337,"p":[{"n":"assembly","p":1310721},{"n":"type","p":1310721}],"n":"GetParameterType","d":327692,"h":8590262284,"f":1},{"r":142606337,"p":[{"n":"key","p":393228},{"n":"assemblies","p":0}],"n":"ResolveType","d":327692,"h":12885229580,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache.Key, $.$spc.System.Type).$h,"n":"_typeToKeyLookUp","d":327692,"h":4295294988,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":327692,"h":21475164172,"f":1}],"j":[393228],"h":327692}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ComponentParametersTypeCache`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootComponentOperation", ($self) => class RootComponentOperation extends $.$spc.System.Object
        {
            /*RootComponentOperationType*/ Type = 0;
            /*int*/ SsrComponentId = 0;
            /*ComponentMarker?*/ Marker = null;
            /*WebRootComponentDescriptor?*/ Descriptor = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Type = 0;
                this.Marker = null;
            }
            static $h = 983052;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1114124,"g":{"r":0,"d":0,"h":12885884940,"f":1},"s":{"r":0,"d":0,"h":17180852236,"f":1},"n":"Type","d":983052,"h":8590917644,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065754124,"f":1},"s":{"r":0,"d":0,"h":34360721420,"f":1},"n":"SsrComponentId","d":983052,"h":25770786828,"f":1},{"p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,"g":{"r":0,"d":0,"h":47245623308,"f":1},"s":{"r":0,"d":0,"h":51540590604,"f":1},"n":"Marker","d":983052,"h":42950656012,"f":1},{"p":4325388,"g":{"r":0,"d":0,"h":64425492492,"f":1},"s":{"r":0,"d":0,"h":68720459788,"f":1},"n":"Descriptor","d":983052,"h":60130525196,"f":1,"a":[{"t":13670061,"c":21488506541}]}],"c":[{"n":".ctor","o":"$ctor$1","d":983052,"h":73015427084,"f":1}],"h":983052}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `RootComponentOperation`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor", ($self) => class WebRootComponentDescriptor extends $.$spc.System.Object
        {
            /*Type*/ ComponentType = null;
            /*WebRootComponentParameters*/ Parameters;
            /*string */ GetDebuggerDisplay()
            {
                /*var*/ let parameters = $.$spc.System.String.Join$6(", ", $.$sl.System.Linq.Enumerable.Select($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String, this.Parameters.Parameters.ToDictionary(), new ($.$spc.System.Func$$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String))().$ctor(this,  (/*p*/ p) =>
                {
                    return `${p.Key}: ${$.$spc.System.Object.ToString.call(p.Value)}`;
                }, {"r":1310721,"p":[{"n":"p","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h}],"n":"","d":4325388,"h":0,"f":1048578})));
                return `${this.ComponentType.FullName}(${parameters})`;
            }
            //Begin primary constructor
            /*Type*/ componentType = null;
            /*WebRootComponentParameters*/ parameters = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters();
            $ctor$1(/*Type*/$componentType, /*WebRootComponentParameters*/$parameters)
            {
                this.componentType = $componentType;
                this.parameters = $parameters;
                //depends on primary constructor parameter
                this.ComponentType = this.componentType;
                //depends on primary constructor parameter
                this.Parameters = this.parameters;
                return this
            }
            //End primary constructor
            static $h = 4325388;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17184194572,"f":1},"n":"ComponentType","d":4325388,"h":12889227276,"f":1},{"p":4390924,"g":{"r":0,"d":0,"h":30069096460,"f":1},"n":"Parameters","d":4325388,"h":25774129164,"f":1}],"m":[{"r":1310721,"n":"GetDebuggerDisplay","d":4325388,"h":34364063756,"f":2}],"c":[{"p":[{"n":"componentType","p":142606337},{"n":"parameters","p":4390924}],"n":".ctor","o":"$ctor$1","d":4325388,"h":4299292684,"f":1}],"h":4325388,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{GetDebuggerDisplay(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebRootComponentDescriptor`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentSerializationSettings", ($self) => class WebAssemblyComponentSerializationSettings
        {
            /*JsonSerializerOptions*/ static JsonSerializationOptions = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.JsonSerializationOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.DefaultIgnoreCondition = 3/*JsonIgnoreCondition.WhenWritingNull*/;
                        return $i1;
                    })();
                }
            }
            static $h = 4194316;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":3380909,"n":"JsonSerializationOptions","d":4194316,"h":4299161612,"f":33}],"h":4194316}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyComponentSerializationSettings`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilderExtensions", ($self) => class WebAssemblyHostBuilderExtensions
        {
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider(/*this WebAssemblyHostBuilder*/ builder, /*Action<ServiceProviderOptions>*/ configure)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilderExtensions.UseDefaultServiceProvider$1(builder, new ($.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions))().$ctor(this,  (/*env*/ env, /*options*/ options) =>
                {
                    return configure.Invoke(options);
                }, {"r":65537,"p":[{"n":"env","p":1441804},{"n":"options","p":3145732}],"n":"","d":2097164,"h":0,"f":1048578}));
            }
            static /*WebAssemblyHostBuilder */ UseDefaultServiceProvider$1(/*this WebAssemblyHostBuilder*/ builder, /*Action<IWebAssemblyHostEnvironment, ServiceProviderOptions>*/ configure)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$spc.System.ArgumentNullException.ThrowIfNull(configure, "configure");
                /*var*/ let options = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions().$ctor$1();
                configure.Invoke(builder.HostEnvironment, options);
                return builder.UseServiceProviderOptions(options);
            }
            static $h = 2097164;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":2031628,"p":[{"n":"builder","p":2031628},{"n":"configure","p":$.$spc.System.Action$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions).$h}],"n":"UseDefaultServiceProvider","d":2097164,"h":4297064460,"f":33},{"r":2031628,"p":[{"n":"builder","p":2031628},{"n":"configure","p":$.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions).$h}],"n":"UseDefaultServiceProvider","o":"@$1","d":2097164,"h":8592031756,"f":33}],"h":2097164}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyHostBuilderExtensions`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder", ($self) => class WebAssemblyHostBuilder extends $.$spc.System.Object
        {
            /*IInternalJSImportMethods*/ _jsMethods = null;
            /*Func<IServiceProvider>*/ _createServiceProvider = null;
            /*RootTypeCache?*/ _rootComponentCache = null;
            /*string?*/ _persistedState = null;
            /*ServiceProviderOptions?*/ _serviceProviderOptions = null;
            static /*WebAssemblyHostBuilder */ CreateDefault(/*string[]?*/ args)
            {
                /*var*/ let builder = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance);
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Initialize();
                return builder;
            }
            $ctor$1(/*IInternalJSImportMethods*/ jsMethods)
            {
                super.$ctor();
                {
                    this._jsMethods = jsMethods;
                    this.Configuration = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostConfiguration().$ctor$1();
                    this.RootComponents = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection().$ctor$3();
                    this.Services = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection().$ctor$1();
                    this.Logging = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.LoggingBuilder().$ctor$1(this.Services);
                    /*var*/ let assembly = $.$spc.System.Reflection.Assembly.GetEntryAssembly();
                    if ($.$spc.System.Reflection.Assembly.op_Inequality(assembly, null))
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.InitializeRoutingAppContextSwitch(assembly);
                    }
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostBuilder.InitializeWebAssemblyRenderer();
                    this.InitializeNavigationManager();
                    this.InitializeRegisteredRootComponents();
                    this.InitializePersistedState();
                    this.InitializeDefaultServices();
                    /*var*/ let hostEnvironment = this.InitializeEnvironment();
                    this.HostEnvironment = hostEnvironment;
                    this._createServiceProvider = new ($.$spc.System.Func$$($.$scm.System.IServiceProvider))().$ctor(this,  () =>
                    {
                        /*var*/ let isDevelopment = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironmentExtensions.IsDevelopment(hostEnvironment);
                        /*var*/ let options = this._serviceProviderOptions ?? (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions;
                            const $i1 = new $t1();
                            $i1.$ctor$1();
                            $i1.ValidateScopes = isDevelopment;
                            $i1.ValidateOnBuild = isDevelopment;
                            return $i1;
                        })();
                        return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(this.Services, options);
                    }, {"r":327717,"n":"","d":2031628,"h":0,"f":1048578});
                }
                return this;
            }
            static /*void */ InitializeRoutingAppContextSwitch(/*Assembly*/ assembly)
            {
                /*var*/ let assemblyMetadataAttributes = $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$10($.$spc.System.Reflection.AssemblyMetadataAttribute, assembly);
                var $en2 = assemblyMetadataAttributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var ama = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$spc.System.String.Equals$5(ama.Key, "Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", 4/*StringComparison.Ordinal*/))
                        {
                            if ($.$spc.System.String.op_Inequality(ama.Value, null) && $.$spc.System.String.Equals$5(ama.Value, "true", 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                $.$spc.System.AppContext.SetSwitch("Microsoft.AspNetCore.Components.Routing.RegexConstraintSupport", true);
                            }
                            return;
                        }
                    }
                }
            }
            /*void */ InitializeRegisteredRootComponents()
            {
                /*var*/ let componentsCount = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount();
                if (componentsCount === 0)
                {
                    return;
                }
                /*var*/ let registeredComponents = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), null, [componentsCount], null);
                for(/*var*/ let i = 0; i < componentsCount; i++)
                {
                    /*var*/ let assembly = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly(i);
                    /*var*/ let typeName = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName(i);
                    /*var*/ let serializedParameterDefinitions = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions(i);
                    /*var*/ let serializedParameterValues = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues(i);
                    $.$spc.System.Array.$WriteT1.call(registeredComponents, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.Create("webassembly"/*ComponentMarker.WebAssemblyMarkerType*/, false, null), i);
                    $.$spc.System.Array.$ReadT1.call(registeredComponents, i).WriteWebAssemblyData(assembly, typeName, serializedParameterDefinitions, serializedParameterValues);
                    $.$spc.System.Array.$ReadT1.call(registeredComponents, i).PrerenderId = $.$spc.System.Int32.ToString$2.call(i, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
                }
                this._rootComponentCache = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
                /*var*/ let componentDeserializer = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.Instance;
                let $i1 = 0;
                let $arr1 = registeredComponents;
                while ($i1 < $arr1.length)
                {
                    let registeredComponent = $arr1[$i1++];
                    /*var*/ let componentType = this._rootComponentCache.GetRootType(registeredComponent.Assembly, registeredComponent.TypeName);
                    if (componentType === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`Root component type '${registeredComponent.TypeName}' could not be found in the assembly '${registeredComponent.Assembly}'. ` + `This is likely a result of trimming (tree shaking).`);
                    }
                    /*var*/ let definitions = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(registeredComponent.ParameterDefinitions);
                    /*var*/ let values = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterValues(registeredComponent.ParameterValues);
                    /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                    this.RootComponents.Add$3(componentType, registeredComponent.PrerenderId, parameters);
                }
            }
            /*void */ InitializePersistedState()
            {
                this._persistedState = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState();
            }
            /*void */ InitializeNavigationManager()
            {
                /*var*/ let baseUri = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri();
                /*var*/ let uri = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager().$ctor$2(baseUri, uri);
            }
            /*WebAssemblyHostEnvironment */ InitializeEnvironment()
            {
                /*var*/ let applicationEnvironment = this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment();
                /*var*/ let hostEnvironment = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironment().$ctor$1(applicationEnvironment, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.BaseUri);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment, this.Services, hostEnvironment);
                /*var*/ let configFiles = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["appsettings.json", `appsettings.${applicationEnvironment}.json`], null, null);
                let $i1 = 0;
                let $arr1 = configFiles;
                while ($i1 < $arr1.length)
                {
                    let configFile = $arr1[$i1++];
                    if ($.$spc.System.IO.File.Exists(configFile))
                    {
                        /*var*/ let appSettingsJson = $.$spc.System.IO.File.ReadAllBytes(configFile);
                        $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource, this.Configuration, new ($.$spc.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                        {
                            return s.Stream = new $.$spc.System.IO.MemoryStream().$ctor$5(appSettingsJson);
                        }, {"r":65537,"p":[{"n":"s","p":327697}],"n":"","d":2031628,"h":0,"f":1048578}));
                    }
                }
                return hostEnvironment;
            }
            static /*void */ InitializeWebAssemblyRenderer()
            {
                if ($.$spc.System.OperatingSystem.IsBrowser())
                {
                    /*var*/ let currentThread = $.$spc.System.Threading.Thread.CurrentThread;
                    if (currentThread.IsThreadPoolThread || currentThread.IsBackground)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10("WebAssemblyHostBuilder needs to be instantiated in the UI thread.");
                    }
                    if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext === null && $.$spc.System.Threading.SynchronizationContext.Current !== null)
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext = $.$spc.System.Threading.SynchronizationContext.Current;
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainManagedThreadId = currentThread.ManagedThreadId;
                    }
                }
            }
            /*WebAssemblyHostConfiguration*/ Configuration = null;
            /*RootComponentMappingCollection*/ RootComponents = null;
            /*IServiceCollection*/ Services = null;
            /*IWebAssemblyHostEnvironment*/ HostEnvironment = null;
            /*ILoggingBuilder*/ Logging = null;
            /*void */ ConfigureContainer(TBuilder, /*IServiceProviderFactory<TBuilder>*/ factory, /*Action<TBuilder>?*/ configure)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                this._createServiceProvider = new ($.$spc.System.Func$$($.$scm.System.IServiceProvider))().$ctor(this,  () =>
                {
                    /*var*/ let container = factory.Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder(this.Services, [TBuilder]);
                    configure?.Invoke(container);
                    return factory.Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider(container, [TBuilder]);
                }, {"r":327717,"n":"","d":2031628,"h":0,"f":1048578});
            }
            /*WebAssemblyHostBuilder */ UseServiceProviderOptions(/*ServiceProviderOptions*/ options)
            {
                this._serviceProviderOptions = $.$firstOf(options, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("options") });
                return this;
            }
            /*WebAssemblyHost */ Build()
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$meca.Microsoft.Extensions.Configuration.IConfiguration, this.Services, this.Configuration);
                /*var*/ let services = this._createServiceProvider.Invoke();
                /*var*/ let scope = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.CreateAsyncScope$1($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory, services));
                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost().$ctor$1(this, services, scope, this._persistedState);
            }
            /*void */ InitializeDefaultServices()
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mj.Microsoft.JSInterop.IJSRuntime, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mac.Microsoft.AspNetCore.Components.NavigationManager, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mac.Microsoft.AspNetCore.Components.Routing.INavigationInterception, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mac.Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash, this.Services, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash.Instance);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods, this.Services, this._jsMethods);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader, this.Services, new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.LazyAssemblyLoader().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$5($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache, this.Services, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache))().$ctor(this,  (/*_*/ _0) =>
                {
                    return this._rootComponentCache ?? new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
                }, {"r":1179660,"p":[{"n":"_","p":327717}],"n":"","d":2031628,"h":0,"f":1048578}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$4($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$5($.$mac.Microsoft.AspNetCore.Components.PersistentComponentState, this.Services, new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$mac.Microsoft.AspNetCore.Components.PersistentComponentState))().$ctor(this,  (/*sp*/ sp) =>
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, sp).State;
                }, {"r":6160392,"p":[{"n":"sp","p":327717}],"n":"","d":2031628,"h":0,"f":1048578}));
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.PersistentStateProviderServiceCollectionExtensions.AddSupplyValueFromPersistentComponentStateProvider(this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$2($.$macw.Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyErrorBoundaryLogger, this.Services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$4($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services);
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services, $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                $.$mel.Microsoft.Extensions.DependencyInjection.LoggingServiceCollectionExtensions.AddLogging$1(this.Services, new ($.$spc.System.Action$$($.$mela.Microsoft.Extensions.Logging.ILoggingBuilder))().$ctor(this,  (/*builder*/ builder) =>
                {
                    $.$mel.Microsoft.Extensions.Logging.LoggingBuilderExtensions.AddProvider(builder, new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLoggerProvider().$ctor$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance));
                }, {"r":65537,"p":[{"n":"builder","p":1179669}],"n":"","d":2031628,"h":0,"f":1048578}));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$2($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider, $.$macwa.Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider, this.Services);
                $.$mac.Microsoft.AspNetCore.Components.Infrastructure.RegisterPersistentComponentStateServiceCollectionExtensions.AddPersistentServiceRegistration($.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider, this.Services, $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                $.$mac.Microsoft.AspNetCore.Components.SupplyParameterFromQueryProviderServiceCollectionExtensions.AddSupplyValueFromQueryProvider(this.Services);
            }
            static $h = 2031628;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2162700,"g":{"r":0,"d":0,"h":68721508364,"f":1},"n":"Configuration","d":2031628,"h":64426541068,"f":1},{"p":1703948,"g":{"r":0,"d":0,"h":81606410252,"f":1},"n":"RootComponents","d":2031628,"h":77311442956,"f":1},{"p":786435,"g":{"r":0,"d":0,"h":94491312140,"f":1},"n":"Services","d":2031628,"h":90196344844,"f":1},{"p":1441804,"g":{"r":0,"d":0,"h":107376214028,"f":1},"n":"HostEnvironment","d":2031628,"h":103081246732,"f":1},{"p":1179669,"g":{"r":0,"d":0,"h":120261115916,"f":1},"n":"Logging","d":2031628,"h":115966148620,"f":1}],"m":[{"r":2031628,"p":[{"n":"args","p":0,"f":65}],"n":"CreateDefault","d":2031628,"h":25771835404,"f":33},{"r":65537,"p":[{"n":"assembly","p":73465857}],"n":"InitializeRoutingAppContextSwitch","d":2031628,"h":34361769996,"f":34},{"r":65537,"n":"InitializeRegisteredRootComponents","d":2031628,"h":38656737292,"f":2},{"r":65537,"n":"InitializePersistedState","d":2031628,"h":42951704588,"f":2},{"r":65537,"n":"InitializeNavigationManager","d":2031628,"h":47246671884,"f":2},{"r":2228236,"n":"InitializeEnvironment","d":2031628,"h":51541639180,"f":2},{"r":65537,"n":"InitializeWebAssemblyRenderer","d":2031628,"h":55836606476,"f":34},{"r":65537,"p":[{"n":"factory","p":(TBuilder) => $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$(TBuilder).$h},{"n":"configure","p":(TBuilder) => $.$spc.System.Action$$(TBuilder).$h,"f":65}],"g":["TBuilder"],"n":"ConfigureContainer","d":2031628,"h":124556083212,"f":131073},{"r":2031628,"p":[{"n":"options","p":3145732}],"n":"UseServiceProviderOptions","d":2031628,"h":128851050508,"f":1},{"r":1966092,"n":"Build","d":2031628,"h":133146017804,"f":1},{"r":65537,"n":"InitializeDefaultServices","d":2031628,"h":137440985100,"f":8}],"l":[{"t":3342348,"n":"_jsMethods","d":2031628,"h":4296998924,"f":2},{"t":$.$spc.System.Func$$($.$scm.System.IServiceProvider).$h,"n":"_createServiceProvider","d":2031628,"h":8591966220,"f":2},{"t":1179660,"n":"_rootComponentCache","d":2031628,"h":12886933516,"f":2},{"t":1310721,"n":"_persistedState","d":2031628,"h":17181900812,"f":2},{"t":3145732,"n":"_serviceProviderOptions","d":2031628,"h":21476868108,"f":2}],"c":[{"p":[{"n":"jsMethods","p":3342348}],"n":".ctor","o":"$ctor$1","d":2031628,"h":30066802700,"f":8}],"h":2031628}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyHostBuilder`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer", ($self) => class WebAssemblyComponentParameterDeserializer extends $.$spc.System.Object
        {
            /*ComponentParametersTypeCache*/ _parametersCache = null;
            $ctor$1(/*ComponentParametersTypeCache*/ parametersCache)
            {
                super.$ctor();
                {
                    this._parametersCache = parametersCache;
                }
                return this;
            }
            /*WebAssemblyComponentParameterDeserializer*/ static Instance = null;
            /*ParameterView */ DeserializeParameters(/*IList<ComponentParameter>*/ parametersDefinitions, /*IList<object>*/ parameterValues)
            {
                /*var*/ let parametersDictionary = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                if (parameterValues.System$Collections$Generic$ICollection$$$Count !== parametersDefinitions.System$Collections$Generic$ICollection$$$Count)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`The number of parameter definitions '${parametersDefinitions.System$Collections$Generic$ICollection$$$Count}' does not match the number parameter values '${parameterValues.System$Collections$Generic$ICollection$$$Count}'.`);
                }
                for(/*var*/ let i = 0; i < parametersDefinitions.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*var*/ let definition = parametersDefinitions.System$Collections$Generic$IList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    if ($.$spc.System.String.op_Equality(definition.Name, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10("The name is missing in a parameter definition.");
                    }
                    if ($.$spc.System.String.op_Equality(definition.TypeName, null) && $.$spc.System.String.op_Equality(definition.Assembly, null))
                    {
                        parametersDictionary.set_Item(definition.Name, null);
                    }
                    else if ($.$spc.System.String.op_Equality(definition.TypeName, null) || $.$spc.System.String.op_Equality(definition.Assembly, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`The parameter definition for '${definition.Name}' is incomplete: Type='${definition.TypeName}' Assembly='${definition.Assembly}'.`);
                    }
                    else 
                    {
                        /*var*/ let parameterType = this._parametersCache.GetParameterType(definition.Assembly, definition.TypeName);
                        if ($.$spc.System.Type.op_Equality$1(parameterType, null))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10(`The parameter '${definition.Name}' with type '${definition.TypeName}' in assembly '${definition.Assembly}' could not be found.`);
                        }
                        try
                        {
                            /*var*/ let value = $.$cast(parameterValues.System$Collections$Generic$IList$$$get_Item(i, [$.$spc.System.Object]), $.$stj.System.Text.Json.JsonElement);
                            /*var*/ let parameterValue = $.$stj.System.Text.Json.JsonSerializer.Deserialize$32(value.GetRawText(), parameterType, $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentSerializationSettings.JsonSerializationOptions);
                            parametersDictionary.set_Item(definition.Name, parameterValue);
                        }
                        catch(e)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$11(`Could not parse the parameter value for parameter '${definition.Name}' of type '${definition.TypeName}' and assembly '${definition.Assembly}'.`, e);
                        }
                    }
                }
                return $.$mac.Microsoft.AspNetCore.Components.ParameterView.FromDictionary(parametersDictionary);
            }
            static /*ComponentParameter[] */ GetParameterDefinitions(/*string*/ parametersDefinitions)
            {
                return $.$stj.System.Text.Json.JsonSerializer.Deserialize$34($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), parametersDefinitions, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.ComponentParameterArray);
            }
            static /*IList<object> */ GetParameterValues(/*string*/ parameterValues)
            {
                return $.$stj.System.Text.Json.JsonSerializer.Deserialize$34($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object), parameterValues, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.IListObject);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer().$ctor$1(new $.$macwa.Microsoft.AspNetCore.Components.ComponentParametersTypeCache().$ctor$1());
                }
            }
            static $h = 4128780;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4128780,"g":{"r":0,"d":0,"h":21478965260,"f":33},"n":"Instance","d":4128780,"h":17183997964,"f":33}],"m":[{"r":5767176,"p":[{"n":"parametersDefinitions","p":$.$spc.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h},{"n":"parameterValues","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$h}],"n":"DeserializeParameters","d":4128780,"h":25773932556,"f":1},{"r":0,"p":[{"n":"parametersDefinitions","p":1310721}],"n":"GetParameterDefinitions","d":4128780,"h":30068899852,"f":33},{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$h,"p":[{"n":"parameterValues","p":1310721}],"n":"GetParameterValues","d":4128780,"h":34363867148,"f":33}],"l":[{"t":327692,"n":"_parametersCache","d":4128780,"h":4299096076,"f":2}],"c":[{"p":[{"n":"parametersCache","p":327692}],"n":".ctor","o":"$ctor$1","d":4128780,"h":8594063372,"f":1}],"h":4128780}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `WebAssemblyComponentParameterDeserializer`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods", ($self) => class InternalJSImportMethods extends $.$spc.System.Object
        {
            /*InternalJSImportMethods*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ GetPersistedState()
            {
                return Blazor._internal.getPersistedState();
            }
            static /*Task<RootComponentOperationBatch> *//*async*/  GetInitialComponentUpdate()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch), $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, async () => 
                {
                    /*var*/ let components = await Blazor._internal.getInitialComponentsUpdate();
                    return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeOperations(components);
                });
            }
            /*string */ GetApplicationEnvironment()
            {
                return "Development";
            }
            /*void */ AttachRootComponentToElement(/*string*/ domElementSelector, /*int*/ componentId, /*int*/ rendererId)
            {
                return Blazor._internal.attachRootComponentToElement(domElementSelector, componentId, rendererId);
            }
            /*void */ EndUpdateRootComponents(/*long*/ batchId)
            {
                return Blazor._internal.endUpdateRootComponents(batchId);
            }
            /*void */ NavigationManager_EnableNavigationInterception(/*int*/ rendererId)
            {
                return Blazor._internal.navigationManager.enableNavigationInterception(rendererId);
            }
            /*void */ NavigationManager_ScrollToElement(/*string*/ id)
            {
                return Blazor._internal.navigationManager.scrollToElement(id);
            }
            /*string */ NavigationManager_GetLocationHref()
            {
                return Blazor._internal.navigationManager.getLocationHref();
            }
            /*string */ NavigationManager_GetBaseUri()
            {
                return Blazor._internal.navigationManager.getBaseURI();
            }
            /*void */ NavigationManager_SetHasLocationChangingListeners(/*int*/ rendererId, /*bool*/ value)
            {
                return Blazor._internal.navigationManager.setHasLocationChangingListeners(rendererId, value);
            }
            /*int */ RegisteredComponents_GetRegisteredComponentsCount()
            {
                return 0;
            }
            /*string */ RegisteredComponents_GetAssembly(/*int*/ id)
            {
                return Blazor._internal.registeredComponents.getAssembly(id);
            }
            /*string */ RegisteredComponents_GetTypeName(/*int*/ id)
            {
                return Blazor._internal.registeredComponents.getTypeName(id);
            }
            /*string */ RegisteredComponents_GetParameterDefinitions(/*int*/ id)
            {
                return Blazor._internal.registeredComponents.getParameterDefinitions(id);
            }
            /*string */ RegisteredComponents_GetParameterValues(/*int*/ id)
            {
                return Blazor._internal.registeredComponents.getParameterValues(id);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetPersistedState()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetPersistedState()
            {
                return this.GetPersistedState(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.GetApplicationEnvironment()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$GetApplicationEnvironment()
            {
                return this.GetApplicationEnvironment(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.AttachRootComponentToElement(string, int, int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement()
            {
                return this.AttachRootComponentToElement(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.EndUpdateRootComponents(long)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents()
            {
                return this.EndUpdateRootComponents(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_EnableNavigationInterception(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_EnableNavigationInterception()
            {
                return this.NavigationManager_EnableNavigationInterception(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_ScrollToElement(string)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_ScrollToElement()
            {
                return this.NavigationManager_ScrollToElement(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetLocationHref()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetLocationHref()
            {
                return this.NavigationManager_GetLocationHref(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_GetBaseUri()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_GetBaseUri()
            {
                return this.NavigationManager_GetBaseUri(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.NavigationManager_SetHasLocationChangingListeners(int, bool)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$NavigationManager_SetHasLocationChangingListeners()
            {
                return this.NavigationManager_SetHasLocationChangingListeners(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetRegisteredComponentsCount()
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetRegisteredComponentsCount()
            {
                return this.RegisteredComponents_GetRegisteredComponentsCount(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetAssembly(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetAssembly()
            {
                return this.RegisteredComponents_GetAssembly(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetTypeName(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetTypeName()
            {
                return this.RegisteredComponents_GetTypeName(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterDefinitions(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterDefinitions()
            {
                return this.RegisteredComponents_GetParameterDefinitions(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods.RegisteredComponents_GetParameterValues(int)
            Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$RegisteredComponents_GetParameterValues()
            {
                return this.RegisteredComponents_GetParameterValues(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods().$ctor$1();
                }
            }
            static $h = 3407884;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"n":"GetPersistedState","d":3407884,"h":12888309772,"f":1},{"r":$.$spc.System.Threading.Tasks.Task$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,"n":"GetInitialComponentUpdate","d":3407884,"h":17183277068,"f":4129},{"r":1310721,"n":"GetApplicationEnvironment","d":3407884,"h":21478244364,"f":1},{"r":65537,"p":[{"n":"domElementSelector","p":1310721},{"n":"componentId","p":655361},{"n":"rendererId","p":655361}],"n":"AttachRootComponentToElement","d":3407884,"h":25773211660,"f":1},{"r":65537,"p":[{"n":"batchId","p":917505}],"n":"EndUpdateRootComponents","d":3407884,"h":30068178956,"f":1},{"r":65537,"p":[{"n":"rendererId","p":655361}],"n":"NavigationManager_EnableNavigationInterception","d":3407884,"h":34363146252,"f":1},{"r":65537,"p":[{"n":"id","p":1310721}],"n":"NavigationManager_ScrollToElement","d":3407884,"h":38658113548,"f":1},{"r":1310721,"n":"NavigationManager_GetLocationHref","d":3407884,"h":42953080844,"f":1},{"r":1310721,"n":"NavigationManager_GetBaseUri","d":3407884,"h":47248048140,"f":1},{"r":65537,"p":[{"n":"rendererId","p":655361},{"n":"value","p":262145}],"n":"NavigationManager_SetHasLocationChangingListeners","d":3407884,"h":51543015436,"f":1},{"r":655361,"n":"RegisteredComponents_GetRegisteredComponentsCount","d":3407884,"h":55837982732,"f":1},{"r":1310721,"p":[{"n":"id","p":655361}],"n":"RegisteredComponents_GetAssembly","d":3407884,"h":60132950028,"f":1},{"r":1310721,"p":[{"n":"id","p":655361}],"n":"RegisteredComponents_GetTypeName","d":3407884,"h":64427917324,"f":1},{"r":1310721,"p":[{"n":"id","p":655361}],"n":"RegisteredComponents_GetParameterDefinitions","d":3407884,"h":68722884620,"f":1},{"r":1310721,"p":[{"n":"id","p":655361}],"n":"RegisteredComponents_GetParameterValues","d":3407884,"h":73017851916,"f":1}],"l":[{"t":3407884,"n":"Instance","d":3407884,"h":4298375180,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":3407884,"h":8593342476,"f":2}],"i":[3342348],"h":3407884}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods ]; }
            static get $fullName() { return `InternalJSImportMethods`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore", ($self) => class PrerenderComponentApplicationStore extends $.$spc.System.Object
        {
            /*bool*/ _stateIsPersisted = false;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.ExistingState = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)))().$ctor$1();
                }
                return this;
            }
            $ctor$2(/*string*/ existingState)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(existingState, "existingState");
                    this.DeserializeState($.$spc.System.Convert.FromBase64String(existingState));
                }
                return this;
            }
            /*void */ DeserializeState(/*byte[]*/ existingState)
            {
                /*var*/ let state = $.$firstOf($.$stj.System.Text.Json.JsonSerializer.Deserialize$17($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)), $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(existingState), $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.Default.DictionaryStringByteArray), () => { throw new $.$spc.System.ArgumentException().$ctor$13("Could not deserialize state correctly", "existingState") });
                this.ExistingState = state;
            }
            /*string?*/ PersistedState = null;
            /*Dictionary<string, byte[]>*/ ExistingState = null;
            /*Task<IDictionary<string, byte[]>> */ GetPersistedStateAsync()
            {
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)), this.ExistingState);
            }
            /*byte[] */ SerializeState(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                return $.$stj.System.Text.Json.JsonSerializer.SerializeToUtf8Bytes($.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)), state, null);
            }
            /*Task */ PersistStateAsync(/*IReadOnlyDictionary<string, byte[]>*/ state)
            {
                if (this._stateIsPersisted)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("State already persisted.");
                }
                this._stateIsPersisted = true;
                if (!(state === null) && state.System$Collections$Generic$IReadOnlyCollection$$$Count > 0)
                {
                    this.PersistedState = $.$spc.System.Convert.ToBase64String(this.SerializeState(state));
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*bool */ SupportsRenderMode(/*IComponentRenderMode*/ renderMode)
            {
                return renderMode === null || $.$is(renderMode, $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode) || $.$is(renderMode, $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.GetPersistedStateAsync()
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$GetPersistedStateAsync()
            {
                return this.GetPersistedStateAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.PersistStateAsync(System.Collections.Generic.IReadOnlyDictionary<string, byte[]>)
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$PersistStateAsync()
            {
                return this.PersistStateAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.IPersistentComponentStateStore.SupportsRenderMode(Microsoft.AspNetCore.Components.IComponentRenderMode)
            Microsoft$AspNetCore$Components$IPersistentComponentStateStore$SupportsRenderMode()
            {
                return this.SupportsRenderMode(...arguments);
            }
            static $h = 720908;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065491980,"f":1},"s":{"r":0,"d":0,"h":34360459276,"f":2},"n":"PersistedState","d":720908,"h":25770524684,"f":1},{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":47245361164,"f":1},"s":{"r":0,"d":0,"h":51540328460,"f":4},"n":"ExistingState","d":720908,"h":42950393868,"f":1}],"m":[{"r":65537,"p":[{"n":"existingState","p":0}],"n":"DeserializeState","d":720908,"h":17180590092,"f":4},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))).$h,"n":"GetPersistedStateAsync","d":720908,"h":55835295756,"f":1},{"r":0,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h}],"n":"SerializeState","d":720908,"h":60130263052,"f":132},{"r":133300225,"p":[{"n":"state","p":$.$spc.System.Collections.Generic.IReadOnlyDictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h}],"n":"PersistStateAsync","d":720908,"h":64425230348,"f":1},{"r":262145,"p":[{"n":"renderMode","p":2883592}],"n":"SupportsRenderMode","d":720908,"h":68720197644,"f":129}],"l":[{"t":262145,"n":"_stateIsPersisted","d":720908,"h":4295688204,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":720908,"h":8590655500,"f":1},{"p":[{"n":"existingState","p":1310721}],"n":".ctor","o":"$ctor$2","d":720908,"h":12885622796,"f":1}],"i":[4390920],"h":720908}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.IPersistentComponentStateStore ]; }
            static get $fullName() { return `PrerenderComponentApplicationStore`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostEnvironment", ($self) => class WebAssemblyHostEnvironment extends $.$spc.System.Object
        {
            $ctor$1(/*string*/ environment, /*string*/ baseAddress)
            {
                super.$ctor();
                {
                    this.Environment = environment;
                    this.BaseAddress = baseAddress;
                }
                return this;
            }
            /*string*/ Environment = null;
            /*string*/ BaseAddress = null;
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.Environment.get
            get Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$Environment()
            {
                return this.Environment;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment.BaseAddress.get
            get Microsoft$AspNetCore$Components$WebAssembly$Hosting$IWebAssemblyHostEnvironment$BaseAddress()
            {
                return this.BaseAddress;
            }
            static $h = 2228236;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182097420,"f":1},"n":"Environment","d":2228236,"h":12887130124,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066999308,"f":1},"n":"BaseAddress","d":2228236,"h":25772032012,"f":1}],"c":[{"p":[{"n":"environment","p":1310721},{"n":"baseAddress","p":1310721}],"n":".ctor","o":"$ctor$1","d":2228236,"h":4297195532,"f":1}],"i":[1441804],"h":2228236}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.IWebAssemblyHostEnvironment ]; }
            static get $fullName() { return `WebAssemblyHostEnvironment`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.LoggingBuilder", ($self) => class LoggingBuilder extends $.$spc.System.Object
        {
            $ctor$1(/*IServiceCollection*/ services)
            {
                super.$ctor();
                {
                    this.Services = services;
                }
                return this;
            }
            /*IServiceCollection*/ Services = null;
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggingBuilder.Services.get
            get Microsoft$Extensions$Logging$ILoggingBuilder$Services()
            {
                return this.Services;
            }
            static $h = 1507340;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":786435,"g":{"r":0,"d":0,"h":17181376524,"f":1},"n":"Services","d":1507340,"h":12886409228,"f":1}],"c":[{"p":[{"n":"services","p":786435}],"n":".ctor","o":"$ctor$1","d":1507340,"h":4296474636,"f":1}],"i":[1179669],"h":1507340}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggingBuilder ]; }
            static get $fullName() { return `LoggingBuilder`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.RootTypeCache", ($self) => class RootTypeCache extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<Key, Type?>*/ _typeToKeyLookUp = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    if ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                    {
                        $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.add_OnDeltaApplied(new $.$spc.System.Action().$ctor(this, this.ClearCache));
                    }
                }
                return this;
            }
            /*void */ ClearCache()
            {
                return this._typeToKeyLookUp.Clear();
            }
            /*void */ Dispose()
            {
                if ($.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.MetadataUpdateSupported)
                {
                    $.$macwa.Microsoft.AspNetCore.Components.HotReload.HotReloadManager.Default.remove_OnDeltaApplied(new $.$spc.System.Action().$ctor(this, this.ClearCache));
                }
            }
            /*Type? */ GetRootType(/*string*/ assembly, /*string*/ type)
            {
                /*var*/ let key = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key().$ctor$2(assembly, type);
                /*var*/ let resolvedType;
                if (this._typeToKeyLookUp.TryGetValue(key, $.$ref(() => resolvedType, ($v) => resolvedType = $v, $.$spc.System.Type)))
                {
                    return resolvedType;
                }
                else 
                {
                    return this._typeToKeyLookUp.GetOrAdd$1($.$typeArray($.$spc.System.Reflection.Assembly), key, new ($.$spc.System.Func$$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$typeArray($.$spc.System.Reflection.Assembly), $.$spc.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.ResolveType), $.$spc.System.AppDomain.CurrentDomain.GetAssemblies());
                }
            }
            static /*Type? */ ResolveType(/*Key*/ key, /*Assembly[]*/ assemblies)
            {
                /*Assembly?*/ let assembly = null;
                for(/*var*/ let i = 0; i < assemblies.length; i++)
                {
                    /*var*/ let current = $.$spc.System.Array.$ReadT1.call(assemblies, i);
                    if ($.$spc.System.String.op_Equality(current.GetName().Name, key.Assembly))
                    {
                        assembly = current;
                        break;
                    }
                }
                if ($.$spc.System.Reflection.Assembly.op_Equality(assembly, null))
                {
                    if ($.$spc.System.OperatingSystem.IsBrowser())
                    {
                        try
                        {
                            assembly = $.$spc.System.Reflection.Assembly.Load(key.Assembly);
                        }
                        catch($e)
                        {
                        }
                    }
                }
                return assembly?.GetType$3(key.Type, false, false);
            }
            static $_Key;
            static get Key()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache;
                return $cls.$_Key ??= $asm.$nstr("$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key", ($self) => class Key extends $.$spc.System.ValueType
                {
                    $ctor$2(/*string*/ assembly, /*string*/ type)
                    {
                        super.$ctor$1();
                        $.$tupleUnpack(($tp) =>
                        {
                            this.Assembly = $tp.Item1;
                            this.Type = $tp.Item2;
                        }).$v = { Item1: assembly, Item2: type };
                        return this;
                    }
                    /*string*/ Assembly = null;
                    /*string*/ Type = null;
                    static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
                    {
                        let key;
                        return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, { set $v(v){ key = v; } }) && this.Equals$2(key);
                    }
                    //Static convention instance redirect
                    /*bool */ Equals() { return $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key.Equals.apply(this, arguments); }
                    /*bool */ Equals$2(/*Key*/ other)
                    {
                        return $.$spc.System.String.Equals$5(this.Assembly, other.Assembly, 4/*StringComparison.Ordinal*/) && $.$spc.System.String.Equals$5(this.Type, other.Type, 4/*StringComparison.Ordinal*/);
                    }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$spc.System.HashCode.Combine$1($.$spc.System.String, $.$spc.System.String, this.Assembly, this.Type);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key.GetHashCode.apply(this, arguments); }
                    //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.RootTypeCache.Key>.Equals(Microsoft.AspNetCore.Components.RootTypeCache.Key)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Assembly = this.Assembly;
                        copy.Type = this.Type;
                        return copy;
                    }
                    static $h = 1245196;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181114380,"f":1},"n":"Assembly","d":1245196,"h":12886147084,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066016268,"f":1},"n":"Type","d":1245196,"h":25771048972,"f":1}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1245196,"h":34360983564,"f":32769},{"r":262145,"p":[{"n":"other","p":1245196}],"n":"Equals","o":"@$2","d":1245196,"h":38655950860,"f":1},{"r":655361,"n":"GetHashCode","d":1245196,"h":42950918156,"f":32769}],"c":[{"p":[{"n":"assembly","p":1310721},{"n":"type","p":1310721}],"n":".ctor","o":"$ctor$2","d":1245196,"h":4296212492,"f":1},{"n":".ctor","o":"$ctor$3","d":1245196,"h":47245885452,"f":1}],"i":[$.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key).$h],"d":1179660,"h":1245196}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key) ]; }
                    static get $fullName() { return `RootTypeCache.Key`; }
                }, $cls, ($v) => $cls.$_Key = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._typeToKeyLookUp = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$spc.System.Type))().$ctor$1();
            }
            static $h = 1179660;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ClearCache","d":1179660,"h":12886081548,"f":8},{"r":65537,"n":"Dispose","d":1179660,"h":17181048844,"f":1},{"r":142606337,"p":[{"n":"assembly","p":1310721},{"n":"type","p":1310721}],"n":"GetRootType","d":1179660,"h":21476016140,"f":1},{"r":142606337,"p":[{"n":"key","p":1245196},{"n":"assemblies","p":0}],"n":"ResolveType","d":1179660,"h":25770983436,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$macwa.Microsoft.AspNetCore.Components.RootTypeCache.Key, $.$spc.System.Type).$h,"n":"_typeToKeyLookUp","d":1179660,"h":4296146956,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1179660,"h":8591114252,"f":1}],"i":[57540609],"j":[1245196],"h":1179660}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `RootTypeCache`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyErrorBoundaryLogger", ($self) => class WebAssemblyErrorBoundaryLogger extends $.$spc.System.Object
        {
            /*ILogger<ErrorBoundary>*/ _errorBoundaryLogger = null;
            $ctor$1(/*ILogger<ErrorBoundary>*/ errorBoundaryLogger)
            {
                super.$ctor();
                {
                    this._errorBoundaryLogger = $.$firstOf(errorBoundaryLogger, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("errorBoundaryLogger") });
                }
                return this;
            }
            /*ValueTask */ LogErrorAsync(/*Exception*/ exception)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.LogError$2(this._errorBoundaryLogger, exception, $.$spc.System.Exception.ToString.call(exception), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [  ], null, null));
                return $.$spc.System.Threading.Tasks.ValueTask.CompletedTask;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger.LogErrorAsync(System.Exception)
            Microsoft$AspNetCore$Components$Web$IErrorBoundaryLogger$LogErrorAsync()
            {
                return this.LogErrorAsync(...arguments);
            }
            static $h = 3801100;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":136118273,"p":[{"n":"exception","p":47251457}],"n":"LogErrorAsync","d":3801100,"h":12888702988,"f":1}],"l":[{"t":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorBoundary).$h,"n":"_errorBoundaryLogger","d":3801100,"h":4298768396,"f":2}],"c":[{"p":[{"n":"errorBoundaryLogger","p":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macw.Microsoft.AspNetCore.Components.Web.ErrorBoundary).$h}],"n":".ctor","o":"$ctor$1","d":3801100,"h":8593735692,"f":1}],"i":[5767177],"h":3801100}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$macw.Microsoft.AspNetCore.Components.Web.IErrorBoundaryLogger ]; }
            static get $fullName() { return `WebAssemblyErrorBoundaryLogger`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception", ($self) => class WebAssemblyNavigationInterception extends $.$spc.System.Object
        {
            /*WebAssemblyNavigationInterception*/ static Instance = null;
            /*Task */ EnableNavigationInterceptionAsync()
            {
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_EnableNavigationInterception(2/*WebRendererId.WebAssembly*/);
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.INavigationInterception.EnableNavigationInterceptionAsync()
            Microsoft$AspNetCore$Components$Routing$INavigationInterception$EnableNavigationInterceptionAsync()
            {
                return this.EnableNavigationInterceptionAsync(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationInterception().$ctor$1();
                }
            }
            static $h = 3866636;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"n":"EnableNavigationInterceptionAsync","d":3866636,"h":8593801228,"f":1}],"l":[{"t":3866636,"n":"Instance","d":3866636,"h":4298833932,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":3866636,"h":12888768524,"f":1}],"i":[10354696],"h":3866636}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.Routing.INavigationInterception ]; }
            static get $fullName() { return `WebAssemblyNavigationInterception`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost", ($self) => class WebAssemblyHost extends $.$spc.System.Object
        {
            /*AsyncServiceScope*/ _scope;
            /*IServiceProvider*/ _services = null;
            /*IConfiguration*/ _configuration = null;
            /*RootComponentMappingCollection*/ _rootComponents = null;
            /*string?*/ _persistedState = null;
            /*bool*/ _disposed = false;
            /*bool*/ _started = false;
            /*WebAssemblyRenderer?*/ _renderer = null;
            $ctor$1(/*WebAssemblyHostBuilder*/ builder, /*IServiceProvider*/ services, /*AsyncServiceScope*/ scope, /*string?*/ persistedState)
            {
                super.$ctor();
                {
                    $.$spc.System.GC.KeepAlive($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.JSInteropMethods.$type);
                    this._services = services;
                    this._scope = scope;
                    this._configuration = builder.Configuration;
                    this._rootComponents = builder.RootComponents;
                    this._persistedState = persistedState;
                }
                return this;
            }
            /*IConfiguration */ get Configuration()
            {
                return this._configuration;
            }
            /*IServiceProvider */ get Services()
            {
                return this._scope.ServiceProvider;
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                {
                    if (this._disposed)
                    {
                        return;
                    }
                    this._disposed = true;
                    if (this._renderer !== null)
                    {
                        await this._renderer.DisposeAsync();
                    }
                    await this._scope.DisposeAsync();
                    let asyncDisposableServices;
                    let disposableServices;
                    if ($.$is(this._services, $.$spc.System.IAsyncDisposable, { set $v(v){ asyncDisposableServices = v; } }))
                    {
                        await asyncDisposableServices.System$IAsyncDisposable$DisposeAsync();
                    }
                    else if ($.$is(this._services, $.$spc.System.IDisposable, { set $v(v){ disposableServices = v; } }))
                    {
                        disposableServices.System$IDisposable$Dispose();
                    }
                });
            }
            /*Task */ RunAsync()
            {
                return this.RunAsyncCore($.$spc.System.Threading.CancellationToken.None, null);
            }
            /*Task *//*async*/  RunAsyncCore(/*CancellationToken*/ cancellationToken, /*WebAssemblyCultureProvider?*/ cultureProvider)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    if (this._started)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10("The host has already started.");
                    }
                    this._started = true;
                    cultureProvider ??= $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCultureProvider.Instance;
                    cultureProvider.ThrowIfCultureChangeIsUnsupported();
                    await cultureProvider.LoadCurrentCultureResourcesAsync();
                    /*var*/ let manager = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, this.Services);
                    /*var*/ let store = !$.$spc.System.String.IsNullOrEmpty(this._persistedState) ? new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$2(this._persistedState) : new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$1();
                    manager.SetPlatformRenderMode($.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly);
                    await manager.RestoreStateAsync$1(store, $.$mac.Microsoft.AspNetCore.Components.RestoreContext.InitialValue);
                    /*var*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    let $disposable1 = null;
                    try
                    {
                        $disposable1 = cancellationToken.Register(new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            return tcs.TrySetResult();
                        }, {"r":65537,"n":"","d":1966092,"h":0,"f":1048578}));
                        /*var*/ let loggerFactory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mela.Microsoft.Extensions.Logging.ILoggerFactory, this.Services);
                        /*var*/ let jsComponentInterop = new $.$macw.Microsoft.AspNetCore.Components.Web.Infrastructure.JSComponentInterop().$ctor$1(this._rootComponents.JSComponents);
                        /*var*/ let collectionProvider = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.Microsoft.AspNetCore.Components.ResourceCollectionProvider, this.Services);
                        /*var*/ let collection = await collectionProvider.GetResourceCollection();
                        this._renderer = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer().$ctor$4(this.Services, collection, loggerFactory, jsComponentInterop);
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Instance.CreateLogger(loggerFactory);
                        /*RootComponentOperationBatch?*/ let initialOperationBatch = null;
                        if ($.$spc.System.String.op_Equality($.$spc.System.Environment.GetEnvironmentVariable("__BLAZOR_WEBASSEMBLY_WAIT_FOR_ROOT_COMPONENTS"), "true"))
                        {
                            initialOperationBatch = await $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.GetInitialComponentUpdate();
                        }
                        /*var*/ let initializationTcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$spc.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$spc.System.Threading.Tasks.TaskCompletionSource), new ($.$spc.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$spc.System.Threading.Tasks.TaskCompletionSource))().$ctor$2(this._rootComponents, this._renderer, initializationTcs), new ($.$spc.System.Action$$($.$spc.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$spc.System.Threading.Tasks.TaskCompletionSource)))().$ctor(this, /*async*/  (/*state*/ state) =>
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Void, $.$spc.System.Void, async () => 
                            {
                                /*var*/ let  [ rootComponents, renderer, initializationTcs ] = $.$destructure(state);
                                try
                                {
                                    /*var*/ let count = rootComponents.Count;
                                    const $t2 = initialOperationBatch;
                                    /*var*/ let initialOperationCount = $.$ifnn($t2, ($t) => $t.Operations.length) ?? 0;
                                    /*var*/ let pendingRenders = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Threading.Tasks.Task))().$ctor$2(((count + initialOperationCount) | 0));
                                    for(/*var*/ let i = 0; i < count; i++)
                                    {
                                        /*var*/ let rootComponent = rootComponents.get_Item(i);
                                        pendingRenders.Add(renderer.AddComponentAsync(rootComponent.ComponentType, rootComponent.Parameters, rootComponent.Selector));
                                    }
                                    if (!(initialOperationBatch === null))
                                    {
                                        $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHost.AddWebRootComponents(renderer, initialOperationBatch, pendingRenders);
                                    }
                                    await $.$spc.System.Threading.Tasks.Task.WhenAll(pendingRenders);
                                    initializationTcs.SetResult();
                                }
                                catch(ex)
                                {
                                    initializationTcs.SetException(ex);
                                }
                            });
                        }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.ValueTuple$$$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, $.$spc.System.Threading.Tasks.TaskCompletionSource).$h}],"n":"","d":1966092,"h":0,"f":1052674}));
                        await initializationTcs.Task;
                        store.ExistingState.Clear();
                        await tcs.Task;
                    }
                    finally
                    {
                        $disposable1?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*void */ AddWebRootComponents(/*WebAssemblyRenderer*/ renderer, /*RootComponentOperationBatch*/ operationBatch, /*List<Task>*/ pendingRenders)
            {
                /*var*/ let webRootComponentManager = renderer.GetOrCreateWebRootComponentManager();
                /*var*/ let operations = operationBatch.Operations;
                for(/*var*/ let i = 0; i < operations.length; i++)
                {
                    /*var*/ let operation = $.$spc.System.Array.$ReadT1.call(operations, i);
                    if (operation.Type !== 0/*RootComponentOperationType.Add*/)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10("All initial operations must be additions.");
                    }
                    pendingRenders.Add(webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters));
                }
                renderer.NotifyEndUpdateRootComponents(operationBatch.BatchId);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._scope = $.$default($.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope);
            }
            static $h = 1966092;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262158,"g":{"r":0,"d":0,"h":47246606348,"f":1},"n":"Configuration","d":1966092,"h":42951639052,"f":1},{"p":327717,"g":{"r":0,"d":0,"h":55836540940,"f":1},"n":"Services","d":1966092,"h":51541573644,"f":1}],"m":[{"r":136118273,"n":"DisposeAsync","d":1966092,"h":60131508236,"f":4097},{"r":133300225,"n":"RunAsync","d":1966092,"h":64426475532,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193},{"n":"cultureProvider","p":1835020,"f":65}],"n":"RunAsyncCore","d":1966092,"h":68721442828,"f":4104},{"r":65537,"p":[{"n":"renderer","p":2949132},{"n":"operationBatch","p":1048588},{"n":"pendingRenders","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"AddWebRootComponents","d":1966092,"h":73016410124,"f":34}],"l":[{"t":524291,"n":"_scope","d":1966092,"h":4296933388,"f":2},{"t":327717,"n":"_services","d":1966092,"h":8591900684,"f":2},{"t":262158,"n":"_configuration","d":1966092,"h":12886867980,"f":2},{"t":1703948,"n":"_rootComponents","d":1966092,"h":17181835276,"f":2},{"t":1310721,"n":"_persistedState","d":1966092,"h":21476802572,"f":2},{"t":262145,"n":"_disposed","d":1966092,"h":25771769868,"f":2},{"t":262145,"n":"_started","d":1966092,"h":30066737164,"f":2},{"t":2949132,"n":"_renderer","d":1966092,"h":34361704460,"f":2}],"c":[{"p":[{"n":"builder","p":2031628},{"n":"services","p":327717},{"n":"scope","p":524291},{"n":"persistedState","p":1310721}],"n":".ctor","o":"$ctor$1","d":1966092,"h":38656671756,"f":8}],"i":[56950785],"h":1966092}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyHost`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash", ($self) => class WebAssemblyScrollToLocationHash extends $.$spc.System.Object
        {
            /*WebAssemblyScrollToLocationHash*/ static Instance = null;
            /*Task */ RefreshScrollPositionForHash(/*string*/ locationAbsolute)
            {
                /*var*/ let hashIndex = $.$spc.System.String.IndexOf$7.call(locationAbsolute, "#", 4/*StringComparison.Ordinal*/);
                if (hashIndex > -1 && locationAbsolute.length > ((hashIndex + 1) | 0))
                {
                    let $t1 = locationAbsolute;
                    /*var*/ let elementId = $.$spc.System.String.Substring$1.call($t1, (((hashIndex + 1) | 0)), $t1.length - (((hashIndex + 1) | 0)));
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_ScrollToElement(elementId);
                }
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash.RefreshScrollPositionForHash(string)
            Microsoft$AspNetCore$Components$Routing$IScrollToLocationHash$RefreshScrollPositionForHash()
            {
                return this.RefreshScrollPositionForHash(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyScrollToLocationHash().$ctor$1();
                }
            }
            static $h = 4063244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"locationAbsolute","p":1310721}],"n":"RefreshScrollPositionForHash","d":4063244,"h":8593997836,"f":1}],"l":[{"t":4063244,"n":"Instance","d":4063244,"h":4299030540,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":4063244,"h":12888965132,"f":1}],"i":[10485768],"h":4063244}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mac.Microsoft.AspNetCore.Components.Routing.IScrollToLocationHash ]; }
            static get $fullName() { return `WebAssemblyScrollToLocationHash`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<>", (T) => $asm.$gt("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger<>", [T], ($self) => class WebAssemblyConsoleLogger$$ extends $.$spc.System.Object
        {
            /*string*/ static _loglevelPadding = null;
            /*string*/ static _messagePadding = null;
            /*string*/ static _newLineWithMessagePadding = null;
            /*StringBuilder*/ static _logBuilder = null;
            /*string*/ _name = null;
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            $ctor$1(/*IJSRuntime*/ jsRuntime)
            {
                this.$ctor$2($.$spc.System.String.Empty, $.$cast(jsRuntime, $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime));
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    this._name = $.$firstOf(name, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("name") });
                    this._jsRuntime = $.$firstOf(jsRuntime, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("jsRuntime") });
                }
                return this;
            }
            /*IDisposable? */ BeginScope(TState, /*TState*/ state)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).NoOpDisposable.Instance;
            }
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                return logLevel !== 6/*LogLevel.None*/;
            }
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                if (!this.IsEnabled(logLevel))
                {
                    return;
                }
                $.$spc.System.ArgumentNullException.ThrowIfNull(formatter, "formatter");
                /*var*/ let message = formatter.Invoke(state, exception);
                if (!$.$spc.System.String.IsNullOrEmpty(message) || exception !== null)
                {
                    this.WriteMessage(logLevel, this._name, eventId.Id, message, exception);
                }
            }
            /*void */ WriteMessage(/*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder)
                    {
                        try
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).CreateDefaultLogMessage($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder, logLevel, logName, eventId, message, exception);
                            /*var*/ let formattedMessage = $.$spc.System.Text.StringBuilder.ToString.call($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder);
                            switch(logLevel)
                            {
                                case 0/*LogLevel.Trace*/:
                                case 1/*LogLevel.Debug*/:
                                globalThis.console.debug(formattedMessage);
                                break;
                                case 2/*LogLevel.Information*/:
                                globalThis.console.info(formattedMessage);
                                break;
                                case 3/*LogLevel.Warning*/:
                                globalThis.console.warn(formattedMessage);
                                break;
                                case 4/*LogLevel.Error*/:
                                globalThis.console.error(formattedMessage);
                                break;
                                case 5/*LogLevel.Critical*/:
                                Blazor._internal.dotNetCriticalError(formattedMessage);
                                break;
                                default:
                                $.$spc.System.Diagnostics.Debug.Assert$1(logLevel !== 6/*LogLevel.None*/, "This method is never called with LogLevel.None.");
                                $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid(this._jsRuntime, "console.log", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ formattedMessage ], null, null));
                                break;
                            }
                        }
                        finally
                        {
                            {
                                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder.Clear();
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._logBuilder)
                }
            }
            static /*void */ CreateDefaultLogMessage(/*StringBuilder*/ logBuilder, /*LogLevel*/ logLevel, /*string*/ logName, /*int*/ eventId, /*string*/ message, /*Exception?*/ exception)
            {
                logBuilder.Append$2($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).GetLogLevelString(logLevel));
                logBuilder.Append$2(": "/*_loglevelPadding*/);
                logBuilder.Append$2(logName);
                logBuilder.Append$7(/*[*/ 91);
                logBuilder.Append$11(eventId);
                logBuilder.Append$7(/*]*/ 93);
                if (!$.$spc.System.String.IsNullOrEmpty(message))
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$2($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._messagePadding);
                    /*var*/ let len = logBuilder.Length;
                    logBuilder.Append$2(message);
                    logBuilder.Replace$2($.$spc.System.Environment.NewLine, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._newLineWithMessagePadding, len, message.length);
                }
                if (exception !== null)
                {
                    logBuilder.AppendLine();
                    logBuilder.Append$2($.$spc.System.Exception.ToString.call(exception));
                }
            }
            static /*string */ GetLogLevelString(/*LogLevel*/ logLevel)
            {
                switch(logLevel)
                {
                    case 0/*LogLevel.Trace*/:
                    return "trce";
                    case 1/*LogLevel.Debug*/:
                    return "dbug";
                    case 2/*LogLevel.Information*/:
                    return "info";
                    case 3/*LogLevel.Warning*/:
                    return "warn";
                    case 4/*LogLevel.Error*/:
                    return "fail";
                    case 5/*LogLevel.Critical*/:
                    return "crit";
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("logLevel");
                }
            }
            static $_NoOpDisposable;
            static get NoOpDisposable()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T);
                return $cls.$_NoOpDisposable ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$.NoOpDisposable", ($self) => class NoOpDisposable extends $.$spc.System.Object
                {
                    /*NoOpDisposable*/ static Instance = null;
                    /*void */ Dispose()
                    {
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Instance = new ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).NoOpDisposable)().$ctor$1();
                        }
                    }
                    static $h = 3670028;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"l":[{"t":this.$h,"n":"Instance","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"i":[57540609],"d":$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `WebAssemblyConsoleLogger<${T?.$fullName}>.NoOpDisposable`; }
                }, $cls, ($v) => $cls.$_NoOpDisposable = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                return this.Log(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                return this.BeginScope(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._loglevelPadding = ": ";
                }
                {
                    this._messagePadding = $.$spc.System.String.Create$6(/* */ 32, (($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).GetLogLevelString(2/*LogLevel.Information*/).length + ": "/*_loglevelPadding*/.length) | 0));
                }
                {
                    this._newLineWithMessagePadding = $.$spc.System.Environment.NewLine + $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T)._messagePadding;
                }
                {
                    this._logBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                }
            }
            static $h = 3604492;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57540609,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"BeginScope","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":131073},{"r":262145,"p":[{"n":"logLevel","p":2293781}],"n":"IsEnabled","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"state","p":(TState) => TState.$h},{"n":"exception","p":47251457},{"n":"formatter","p":(TState) => $.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"g":["TState"],"n":"Log","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":131073},{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"logName","p":1310721},{"n":"eventId","p":655361},{"n":"message","p":1310721},{"n":"exception","p":47251457}],"n":"WriteMessage","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},{"r":65537,"p":[{"n":"logBuilder","p":122945537},{"n":"logLevel","p":2293781},{"n":"logName","p":1310721},{"n":"eventId","p":655361},{"n":"message","p":1310721},{"n":"exception","p":47251457}],"n":"CreateDefaultLogMessage","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":34},{"r":1310721,"p":[{"n":"logLevel","p":2293781}],"n":"GetLogLevelString","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":34}],"l":[{"t":1310721,"n":"_loglevelPadding","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":34},{"t":1310721,"n":"_messagePadding","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":34},{"t":1310721,"n":"_newLineWithMessagePadding","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":34},{"t":122945537,"n":"_logBuilder","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":34},{"t":1310721,"n":"_name","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":262175,"n":"_jsRuntime","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"jsRuntime","p":524318}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":[{"n":"name","p":1310721},{"n":"jsRuntime","p":262175}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"i":[$.$mela.Microsoft.Extensions.Logging.ILogger$$(T).$h,917525],"g":[T?.$h??1507328],"j":[$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$(T).NoOpDisposable.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger$$(T), $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `WebAssemblyConsoleLogger<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLoggerProvider", ($self) => class WebAssemblyConsoleLoggerProvider extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<string, WebAssemblyConsoleLogger<object>>*/ _loggers = null;
            /*WebAssemblyJSRuntime*/ _jsRuntime = null;
            $ctor$1(/*WebAssemblyJSRuntime*/ jsRuntime)
            {
                super.$ctor();
                {
                    this._loggers = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$spc.System.Object)))().$ctor$1();
                    this._jsRuntime = jsRuntime;
                }
                return this;
            }
            /*ILogger */ CreateLogger(/*string*/ name)
            {
                return this._loggers.GetOrAdd(name, new ($.$spc.System.Func$$$($.$spc.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$spc.System.Object)))().$ctor(this,  (/*loggerName*/ loggerName) =>
                {
                    return new ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$spc.System.Object))().$ctor$2(name, this._jsRuntime);
                }, {"r":$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$spc.System.Object).$h,"p":[{"n":"loggerName","p":1310721}],"n":"","d":3735564,"h":0,"f":1048578}));
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerProvider.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger()
            {
                return this.CreateLogger(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 3735564;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":917525,"p":[{"n":"name","p":1310721}],"n":"CreateLogger","d":3735564,"h":17183604748,"f":1},{"r":65537,"n":"Dispose","d":3735564,"h":21478572044,"f":1}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyConsoleLogger$$($.$spc.System.Object)).$h,"n":"_loggers","d":3735564,"h":4298702860,"f":2},{"t":262175,"n":"_jsRuntime","d":3735564,"h":8593670156,"f":2}],"c":[{"p":[{"n":"jsRuntime","p":262175}],"n":".ctor","o":"$ctor$1","d":3735564,"h":12888637452,"f":1}],"i":[1114133,57540609],"h":3735564}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerProvider, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `WebAssemblyConsoleLoggerProvider`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyHostConfiguration", ($self) => class WebAssemblyHostConfiguration extends $.$spc.System.Object
        {
            /*List<IConfigurationProvider>*/ _providers = null;
            /*List<IConfigurationSource>*/ _sources = null;
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            /*ConfigurationReloadToken*/ _changeToken = null;
            /*IList<IConfigurationSource> */ get Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources()
            {
                return new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1(this._sources.ToArray());
            }
            /*IEnumerable<IConfigurationProvider> */ get Microsoft$Extensions$Configuration$IConfigurationRoot$Providers()
            {
                return new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1(this._providers.ToArray());
            }
            /*IDictionary<string, object>*/ Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties = null;
            /*string?*/ get_Item(/*string*/ key)
            {
                for(/*var*/ let i = ((this._providers.Count - 1) | 0); i >= 0; i--)
                {
                    /*var*/ let provider = this._providers.get_Item(i);
                    /*var*/ let value;
                    if (provider.Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet(key, $.$ref(() => value, ($v) => value = $v, $.$spc.System.String)))
                    {
                        return value;
                    }
                }
                return null;
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                if (this._providers.Count === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Can only set property if at least one provider has been inserted.");
                }
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Set(key, value);
                    }
                }
            }
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection().$ctor$1(this, key);
            }
            /*IEnumerable<IConfigurationSection> */ Microsoft$Extensions$Configuration$IConfiguration$GetChildren()
            {
                /*var*/ let hashSet = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$2($.$spc.System.StringComparer.OrdinalIgnoreCase);
                /*var*/ let result = new ($.$spc.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection))().$ctor$1();
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        var $en4 = provider.Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys($.$sl.System.Linq.Enumerable.Empty($.$spc.System.String), null).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var child = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (!hashSet.Add(child))
                                {
                                    continue;
                                }
                                result.Add(this.GetSection(child));
                            }
                        }
                    }
                }
                return result;
            }
            /*IChangeToken */ GetReloadToken()
            {
                return this._changeToken;
            }
            /*void */ Reload()
            {
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                    }
                }
                this.RaiseChanged();
            }
            /*void */ RaiseChanged()
            {
                /*var*/ let previousToken = $.$spc.System.Threading.Interlocked.Exchange$14($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken), new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            /*IConfigurationBuilder */ Add(/*IConfigurationSource*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                this._sources.Add(source);
                /*var*/ let provider = source.Microsoft$Extensions$Configuration$IConfigurationSource$Build(this);
                provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                this._changeTokenRegistrations.Add($.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(provider, provider.Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken), new $.$spc.System.Action().$ctor(this, this.RaiseChanged)));
                this._providers.Add(provider);
                return this;
            }
            /*IConfigurationRoot */ Build()
            {
                return this;
            }
            /*void */ Dispose()
            {
                var $en2 = this._changeTokenRegistrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
                var $en2 = this._providers.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var provider = $en2.Current;
                    {
                        ($.$as(provider, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                    }
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Reload()
            Microsoft$Extensions$Configuration$IConfigurationRoot$Reload()
            {
                return this.Reload(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            Microsoft$Extensions$Configuration$IConfiguration$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            Microsoft$Extensions$Configuration$IConfiguration$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            Microsoft$Extensions$Configuration$IConfiguration$GetSection()
            {
                return this.GetSection(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken()
            {
                return this.GetReloadToken(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Build()
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._providers = new ($.$spc.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1();
                this._sources = new ($.$spc.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1();
                this._changeTokenRegistrations = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.IDisposable))().$ctor$1();
                this._changeToken = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1();
                this.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$1();
            }
            static $h = 2162700;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"g":{"r":0,"d":0,"h":25771966476,"f":2},"n":"{327694}.Sources","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources","d":2162700,"h":21476999180,"f":2},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":34361901068,"f":2},"n":"{524302}.Providers","o":"Microsoft$Extensions$Configuration$IConfigurationRoot$Providers","d":2162700,"h":30066933772,"f":2},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":47246802956,"f":2},"n":"{327694}.Properties","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties","d":2162700,"h":42951835660,"f":2},{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":55836737548,"f":1},"s":{"r":0,"d":0,"h":60131704844,"f":1},"n":"Item","o":"@$2","d":2162700,"h":51541770252,"f":1}],"m":[{"r":589838,"p":[{"n":"key","p":1310721}],"n":"GetSection","d":2162700,"h":64426672140,"f":1},{"r":720898,"n":"GetReloadToken","d":2162700,"h":73016606732,"f":1},{"r":65537,"n":"Reload","d":2162700,"h":77311574028,"f":1},{"r":65537,"n":"RaiseChanged","d":2162700,"h":81606541324,"f":2},{"r":327694,"p":[{"n":"source","p":655374}],"n":"Add","d":2162700,"h":85901508620,"f":1},{"r":524302,"n":"Build","d":2162700,"h":90196475916,"f":1},{"r":65537,"n":"Dispose","d":2162700,"h":94491443212,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"n":"_providers","d":2162700,"h":4297129996,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"n":"_sources","d":2162700,"h":8592097292,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.IDisposable).$h,"n":"_changeTokenRegistrations","d":2162700,"h":12887064588,"f":2},{"t":655373,"n":"_changeToken","d":2162700,"h":17182031884,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2162700,"h":98786410508,"f":1}],"i":[524302,262158,327694],"h":2162700}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationRoot, $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder ]; }
            static get $fullName() { return `WebAssemblyHostConfiguration`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters", ($self) => class WebRootComponentParameters extends $.$spc.System.ValueType
        {
            /*WebRootComponentParameters*/ static Empty;
            /*IReadOnlyList<ComponentParameter>*/  get _parameterDefinitions() { return this.$getField(20, 4); }
            /*IReadOnlyList<ComponentParameter>*/  set _parameterDefinitions(value) { this.$setField(20, 4, value); }
            /*IReadOnlyList<object>*/  get _serializedParameterValues() { return this.$getField(24, 4); }
            /*IReadOnlyList<object>*/  set _serializedParameterValues(value) { this.$setField(24, 4, value); }
            /*ParameterView */ get Parameters()
            {
                return this.parameterView;
            }
            /*bool */ DefinitelyEquals(/*in WebRootComponentParameters*/ other)
            {
                /*var*/ let count = this._parameterDefinitions.System$Collections$Generic$IReadOnlyCollection$$$Count;
                if (count !== other.$v._parameterDefinitions.System$Collections$Generic$IReadOnlyCollection$$$Count)
                {
                    return false;
                }
                for(/*var*/ let i = 0; i < count; i++)
                {
                    /*var*/ let definition = this._parameterDefinitions.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    /*var*/ let otherDefinition = other.$v._parameterDefinitions.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$macwa.Microsoft.AspNetCore.Components.ComponentParameter]);
                    if (!$.$spc.System.String.Equals$5(definition.Name, otherDefinition.Name, 4/*StringComparison.Ordinal*/) || !$.$spc.System.String.Equals$5(definition.TypeName, otherDefinition.TypeName, 4/*StringComparison.Ordinal*/) || !$.$spc.System.String.Equals$5(definition.Assembly, otherDefinition.Assembly, 4/*StringComparison.Ordinal*/))
                    {
                        return false;
                    }
                    /*var*/ let value = this._serializedParameterValues.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$spc.System.Object]);
                    /*var*/ let otherValue = other.$v._serializedParameterValues.System$Collections$Generic$IReadOnlyList$$$get_Item(i, [$.$spc.System.Object]);
                    let jsonValue;
                    let otherJsonValue;
                    if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonValue = v; } }) && $.$is(otherValue, $.$stj.System.Text.Json.JsonElement, { set $v(v){ otherJsonValue = v; } }))
                    {
                        if (!$.$spc.System.String.Equals$5(jsonValue.GetRawText(), otherJsonValue.GetRawText(), 4/*StringComparison.Ordinal*/))
                        {
                            return false;
                        }
                    }
                    else if (!$.$spc.System.Object.Equals$1(value, otherValue))
                    {
                        return false;
                    }
                }
                return true;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._parameterDefinitions = this._parameterDefinitions;
                copy._serializedParameterValues = this._serializedParameterValues;
                return copy;
            }
            //Begin primary constructor
            /*ParameterView*/ parameterView = new $.$mac.Microsoft.AspNetCore.Components.ParameterView();
            /*IReadOnlyList<ComponentParameter>*/ parameterDefinitions = null;
            /*IReadOnlyList<object>*/ serializedParameterValues = null;
            $ctor$2(/*ParameterView*/$parameterView, /*IReadOnlyList<ComponentParameter>*/$parameterDefinitions, /*IReadOnlyList<object>*/$serializedParameterValues)
            {
                this.parameterView = $parameterView;
                this.parameterDefinitions = $parameterDefinitions;
                this.serializedParameterValues = $serializedParameterValues;
                //depends on primary constructor parameter
                this._parameterDefinitions = this.parameterDefinitions;
                //depends on primary constructor parameter
                this._serializedParameterValues = this.serializedParameterValues;
                return this
            }
            //End primary constructor
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$2($.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty, (() =>
                    {
                        let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor$1();
                        return $t1;
                    })(), (() =>
                    {
                        let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                        return $t1;
                    })());
                }
            }
            static $h = 4390924;
            static $z = 28;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":5767176,"g":{"r":0,"d":0,"h":30069161996,"f":1},"n":"Parameters","d":4390924,"h":25774194700,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":4390924,"f":8}],"n":"DefinitelyEquals","d":4390924,"h":34364129292,"f":1}],"l":[{"t":5767176,"n":"\u003CparameterView\u003EP","d":4390924,"h":8594325516,"f":2},{"t":4390924,"n":"Empty","d":4390924,"h":12889292812,"f":33},{"t":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,"n":"_parameterDefinitions","d":4390924,"h":17184260108,"f":2},{"t":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Object).$h,"n":"_serializedParameterValues","d":4390924,"h":21479227404,"f":2}],"c":[{"p":[{"n":"parameterView","p":5767176},{"n":"parameterDefinitions","p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h},{"n":"serializedParameterValues","p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":4390924,"h":4299358220,"f":1},{"n":".ctor","o":"$ctor$3","d":4390924,"h":38659096588,"f":1}],"h":4390924}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `WebRootComponentParameters`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.Forms.DefaultAntiforgeryStateProvider", ($self) => class DefaultAntiforgeryStateProvider extends $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider
        {
            /*AntiforgeryRequestToken?*/ _currentToken = null;
            /*AntiforgeryRequestToken? */ get CurrentToken()
            {
                return this._currentToken ??= this.GetAntiforgeryToken();
            }
            /*AntiforgeryRequestToken? */ set CurrentToken(value)
            {
                this._currentToken = value;
            }
            /*AntiforgeryRequestToken? */ GetAntiforgeryToken()
            {
                return this._currentToken;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 524300;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327689,"p":[{"p":262153,"g":{"r":0,"d":0,"h":12885426188,"f":1},"s":{"r":0,"d":0,"h":17180393484,"f":1},"n":"CurrentToken","d":524300,"h":8590458892,"f":1,"a":[{"t":6357000,"c":38661062664}]}],"m":[{"r":262153,"n":"GetAntiforgeryToken","d":524300,"h":21475360780,"f":32769}],"l":[{"t":262153,"n":"_currentToken","d":524300,"h":4295491596,"f":4}],"c":[{"n":".ctor","o":"$ctor$2","d":524300,"h":25770328076,"f":1}],"h":524300}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.Forms.AntiforgeryStateProvider; }
            static get $fullName() { return `DefaultAntiforgeryStateProvider`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping", ($self) => class RootComponentMapping extends $.$spc.System.ValueType
        {
            $ctor$2(/*Type*/ componentType, /*string*/ selector)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(componentType, "componentType");
                    if (!$.$mac.Microsoft.AspNetCore.Components.IComponent.$type.IsAssignableFrom(componentType))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13(`The type '${componentType.Name}' must implement ${"IComponent"} to be used as a root component.`, "componentType");
                    }
                    $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                    this.ComponentType = componentType;
                    this.Selector = selector;
                    this.Parameters = $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty;
                }
                return this;
            }
            $ctor$3(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                this.$ctor$2(componentType, selector);
                {
                    this.Parameters = parameters;
                }
                return this;
            }
            /*Type*/ ComponentType = null;
            /*string*/ Selector = null;
            /*ParameterView*/ Parameters;
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ComponentType = this.ComponentType;
                copy.Selector = this.Selector;
                copy.Parameters = this.Parameters.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Parameters = $.$default($.$mac.Microsoft.AspNetCore.Components.ParameterView);
            }
            static $h = 1638412;
            static $z = 28;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":21476474892,"f":1},"n":"ComponentType","d":1638412,"h":17181507596,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361376780,"f":1},"n":"Selector","d":1638412,"h":30066409484,"f":1},{"p":5767176,"g":{"r":0,"d":0,"h":47246278668,"f":1},"n":"Parameters","d":1638412,"h":42951311372,"f":1}],"c":[{"p":[{"n":"componentType","p":142606337},{"n":"selector","p":1310721}],"n":".ctor","o":"$ctor$2","d":1638412,"h":4296605708,"f":1},{"p":[{"n":"componentType","p":142606337},{"n":"selector","p":1310721},{"n":"parameters","p":5767176}],"n":".ctor","o":"$ctor$3","d":1638412,"h":8591573004,"f":1},{"n":".ctor","o":"$ctor$4","d":1638412,"h":51541245964,"f":1}],"h":1638412}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `RootComponentMapping`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher", ($self) => class NullDispatcher extends $.$mac.Microsoft.AspNetCore.Components.Dispatcher
        {
            /*Dispatcher*/ static Instance = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ CheckAccess()
            {
                return true;
            }
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                workItem.Invoke();
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                return workItem.Invoke();
            }
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<TResult>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                return $.$spc.System.Threading.Tasks.Task.FromResult(TResult, workItem.Invoke());
            }
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                return workItem.Invoke();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher().$ctor$2();
                }
            }
            static $h = 2752524;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1703944,"m":[{"r":262145,"n":"CheckAccess","d":2752524,"h":12887654412,"f":32769},{"r":133300225,"p":[{"n":"workItem","p":11665409}],"n":"InvokeAsync","d":2752524,"h":17182621708,"f":32769},{"r":133300225,"p":[{"n":"workItem","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"InvokeAsync","o":"@$1","d":2752524,"h":21477589004,"f":32769},{"r":(TResult) => $.$spc.System.Threading.Tasks.Task$$(TResult).$h,"p":[{"n":"workItem","p":(TResult) => $.$spc.System.Func$$(TResult).$h}],"g":["TResult"],"n":"InvokeAsync","o":"@$2","d":2752524,"h":25772556300,"f":163841},{"r":(TResult) => $.$spc.System.Threading.Tasks.Task$$(TResult).$h,"p":[{"n":"workItem","p":(TResult) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(TResult)).$h}],"g":["TResult"],"n":"InvokeAsync","o":"@$3","d":2752524,"h":30067523596,"f":163841}],"l":[{"t":1703944,"n":"Instance","d":2752524,"h":4297719820,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":2752524,"h":8592687116,"f":2}],"h":2752524}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Dispatcher; }
            static get $fullName() { return `NullDispatcher`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager", ($self) => class WebAssemblyNavigationManager extends $.$mac.Microsoft.AspNetCore.Components.NavigationManager
        {
            /*ILogger<WebAssemblyNavigationManager>*/ _logger = null;
            /*WebAssemblyNavigationManager*/ static Instance = null;
            $ctor$2(/*string*/ baseUri, /*string*/ uri)
            {
                super.$ctor$1();
                {
                    this.Initialize(baseUri, uri);
                }
                return this;
            }
            /*void */ CreateLogger(/*ILoggerFactory*/ loggerFactory)
            {
                if (!(this._logger === null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(`The ${"WebAssemblyNavigationManager"} has already created a logger.`);
                }
                this._logger = $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager, loggerFactory);
            }
            /*void */ SetLocation(/*string*/ uri, /*string?*/ state, /*bool*/ isInterceptedLink)
            {
                this.Uri = uri;
                this.HistoryEntryState = state;
                this.NotifyLocationChanged(isInterceptedLink);
            }
            /*ValueTask<bool> *//*async*/  HandleLocationChangingAsync(/*string*/ uri, /*string?*/ state, /*bool*/ intercepted)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean), $.$spc.System.Boolean, async () => 
                {
                    return await this.NotifyLocationChangingAsync(uri, state, intercepted);
                });
            }
            /*void */ NavigateToCore$1(/*string*/ uri, /*NavigationOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                _ = PerformNavigationAsync.call(this);
                /*Task*/ /*async*/  function PerformNavigationAsync()
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                    {
                        try
                        {
                            /*var*/ let shouldContinueNavigation = await this.NotifyLocationChangingAsync(uri, options.HistoryEntryState, false);
                            if (!shouldContinueNavigation)
                            {
                                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationCanceled(this._logger, uri);
                                return;
                            }
                            $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.navigateTo"/*Interop.NavigateTo*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ uri, options ], null, null));
                        }
                        catch(ex)
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, uri, ex);
                        }
                    });
                }
            }
            /*void */ Refresh(/*bool*/ forceReload)
            {
                $.$mj.Microsoft.JSInterop.JSInProcessRuntimeExtensions.InvokeVoid($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, "Blazor._internal.navigationManager.refresh"/*Interop.Refresh*/, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ $.$box(forceReload, $.$spc.System.Boolean) ], null, null));
            }
            /*void */ HandleLocationChangingHandlerException(/*Exception*/ ex, /*LocationChangingContext*/ context)
            {
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.NavigationFailed(this._logger, context.TargetLocation, ex);
            }
            /*void */ SetNavigationLockState(/*bool*/ value)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.InternalJSImportMethods.Instance.NavigationManager_SetHasLocationChangingListeners(2/*WebRendererId.WebAssembly*/, value);
            }
            static $_Log;
            static get Log()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager;
                return $cls.$_Log ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log", ($self) => class Log
                {
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationCanceledCallback = null;
                    static /*void */ NavigationCanceled(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri)
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.__NavigationCanceledCallback.Invoke(logger, uri, null);
                        }
                    }
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __NavigationFailedCallback = null;
                    static /*void */ NavigationFailed(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ uri, /*global::System.Exception*/ exception)
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager.Log.__NavigationFailedCallback.Invoke(logger, uri, exception);
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.__NavigationCanceledCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$3($.$spc.System.String, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(1, "NavigationCanceled"), "Navigation canceled when changing the location to {Uri}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                        }
                        {
                            this.__NavigationFailedCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$3($.$spc.System.String, 4/*global::Microsoft.Extensions.Logging.LogLevel.Error*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(2, "NavigationFailed"), "Navigation failed when changing the location to {Uri}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                        }
                    }
                    static $h = 3997708;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525},{"n":"uri","p":1310721}],"n":"NavigationCanceled","d":3997708,"h":4298965004,"f":33,"a":[{"t":2228245,"c":8592162837,"a":[{"v":1,"t":655361},{"v":1,"t":2293781},{"v":"Navigation canceled when changing the location to {Uri}","t":1310721}],"n":[{"n":"EventName","v":"NavigationCanceled","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"uri","p":1310721},{"n":"exception","p":47251457}],"n":"NavigationFailed","d":3997708,"h":8593932300,"f":33,"a":[{"t":2228245,"c":8592162837,"a":[{"v":2,"t":655361},{"v":4,"t":2293781},{"v":"Navigation failed when changing the location to {Uri}","t":1310721}],"n":[{"n":"EventName","v":"NavigationFailed","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"l":[{"t":$.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.String, $.$spc.System.Exception).$h,"n":"__NavigationCanceledCallback","d":3997708,"h":12888899596,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]},{"t":$.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.String, $.$spc.System.Exception).$h,"n":"__NavigationFailedCallback","d":3997708,"h":17183866892,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"d":3932172,"h":3997708}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `WebAssemblyNavigationManager.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._logger = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = null;
                }
            }
            static $h = 3932172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4980744,"p":[{"p":3932172,"g":{"r":0,"d":0,"h":17183801356,"f":33},"s":{"r":0,"d":0,"h":21478768652,"f":33},"n":"Instance","d":3932172,"h":12888834060,"f":33}],"m":[{"r":65537,"p":[{"n":"loggerFactory","p":1048597}],"n":"CreateLogger","d":3932172,"h":30068703244,"f":1},{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"state","p":1310721},{"n":"isInterceptedLink","p":262145}],"n":"SetLocation","d":3932172,"h":34363670540,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Boolean).$h,"p":[{"n":"uri","p":1310721},{"n":"state","p":1310721},{"n":"intercepted","p":262145}],"n":"HandleLocationChangingAsync","d":3932172,"h":38658637836,"f":4097},{"r":65537,"p":[{"n":"uri","p":1310721},{"n":"options","p":5439496}],"n":"NavigateToCore","o":"@$1","d":3932172,"h":42953605132,"f":32772},{"r":65537,"p":[{"n":"forceReload","p":262145,"f":65,"v":false}],"n":"Refresh","d":3932172,"h":47248572428,"f":32769},{"r":65537,"p":[{"n":"ex","p":47251457},{"n":"context","p":10616840}],"n":"HandleLocationChangingHandlerException","d":3932172,"h":51543539724,"f":32772},{"r":65537,"p":[{"n":"value","p":262145}],"n":"SetNavigationLockState","d":3932172,"h":55838507020,"f":32772}],"l":[{"t":$.$mela.Microsoft.Extensions.Logging.ILogger$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager).$h,"n":"_logger","d":3932172,"h":4298899468,"f":2}],"c":[{"p":[{"n":"baseUri","p":1310721},{"n":"uri","p":1310721}],"n":".ctor","o":"$ctor$2","d":3932172,"h":25773735948,"f":1}],"j":[3997708],"h":3932172}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.NavigationManager; }
            static get $fullName() { return `Microsoft.AspNetCore.Components.WebAssembly.Services.WebAssemblyNavigationManager`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentParameter", ($self) => class ComponentParameter extends $.$spc.System.ValueType
        {
            /*string*/ Name = null;
            /*string?*/ TypeName = null;
            /*string?*/ Assembly = null;
            static /*(IList<ComponentParameter> parameterDefinitions, IList<object?> parameterValues) */ FromParameterView(/*ParameterView*/ parameters)
            {
                /*var*/ let parameterDefinitions = new ($.$spc.System.Collections.Generic.List$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor$1();
                /*var*/ let parameterValues = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                var $en2 = parameters.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        const $t1 = () => kvp.Value;
                        /*var*/ let valueType = $.$ifnn($t1, ($t) => $.$spc.System.Object.GetType.call($t));
                        /*System.Type?*/ let __ca1__;
                        /*System.Reflection.Assembly*/ let __ca2__;
                        /*System.Reflection.AssemblyName*/ let __ca3__;
                        parameterDefinitions.Add((() =>
                        {
                            //new $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter()
                            const $t2 = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter;
                            const $i2 = new $t2();
                            $i2.Name = kvp.Name;
                            $i2.TypeName = (valueType?.FullName ?? null);
                            $i2.Assembly = ($.$spc.System.Type.op_Inequality$1((__ca1__ = valueType), null) ? ($.$spc.System.Reflection.Assembly.op_Inequality((__ca2__ = __ca1__.Assembly), null) ? ((__ca3__ = __ca2__.GetName()) !== null ? __ca3__.Name : null) : null) : null);
                            return $i2;
                        })());
                        parameterValues.Add(kvp.Value);
                    }
                }
                return new ($.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), $.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)))().$ctor$2(parameterDefinitions, parameterValues);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Name = this.Name;
                copy.TypeName = this.TypeName;
                copy.Assembly = this.Assembly;
                return copy;
            }
            static $h = 262156;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885164044,"f":1},"s":{"r":0,"d":0,"h":17180131340,"f":1},"n":"Name","d":262156,"h":8590196748,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065033228,"f":1},"s":{"r":0,"d":0,"h":34360000524,"f":1},"n":"TypeName","d":262156,"h":25770065932,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47244902412,"f":1},"s":{"r":0,"d":0,"h":51539869708,"f":1},"n":"Assembly","d":262156,"h":42949935116,"f":1}],"m":[{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), $.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)).$h,"p":[{"n":"parameters","p":5767176}],"n":"FromParameterView","d":262156,"h":55834837004,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":262156,"h":60129804300,"f":1}],"h":262156}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ComponentParameter`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher", ($self) => class WebAssemblyDispatcher extends $.$mac.Microsoft.AspNetCore.Components.Dispatcher
        {
            /*SynchronizationContext?*/ static _mainSynchronizationContext = null;
            /*int*/ static _mainManagedThreadId = 0;
            /*bool */ CheckAccess()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainManagedThreadId === $.$spc.System.Environment.CurrentManagedThreadId;
            }
            /*Task */ InvokeAsync(/*Action*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                if (this.CheckAccess())
                {
                    workItem.Invoke();
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource, $.$spc.System.Action));
                    try
                    {
                        state.Item2.Invoke();
                        state.Item1.SetResult();
                    }
                    catch(ex)
                    {
                        state.Item1.SetException(ex);
                    }
                }, {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883596,"h":0,"f":1048610}), new ($.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource, $.$spc.System.Action))().$ctor$2(tcs, workItem));
                return tcs.Task;
            }
            /*Task<TResult> */ InvokeAsync$2(TResult, /*Func<TResult>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return $.$spc.System.Threading.Tasks.Task.FromResult(TResult, workItem.Invoke());
                }
                /*var*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$spc.System.Func$$(TResult)));
                    try
                    {
                        /*var*/ let res = state.Item2.Invoke();
                        state.Item1.SetResult(res);
                    }
                    catch(ex)
                    {
                        state.Item1.SetException(ex);
                    }
                }, {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883596,"h":0,"f":1048610}), new ($.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$spc.System.Func$$(TResult)))().$ctor$2(tcs, workItem));
                return tcs.Task;
            }
            /*Task */ InvokeAsync$1(/*Func<Task>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource, $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task)));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$2(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  (/**/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult();
                            }
                        }, {"r":65537,"p":[{"n":"t","p":133300225}],"n":"","d":2883596,"h":0,"f":1048578}), $.$spc.System.Threading.Tasks.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException(ex);
                    }
                }, {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883596,"h":0,"f":1048610}), new ($.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource, $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task)))().$ctor$2(tcs, workItem));
                return tcs.Task;
            }
            /*Task<TResult> */ InvokeAsync$3(TResult, /*Func<Task<TResult>>*/ workItem)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(workItem, "workItem");
                if (this.CheckAccess())
                {
                    return workItem.Invoke();
                }
                /*var*/ let tcs = new ($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult))().$ctor$1();
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext.Post(new $.$spc.System.Threading.SendOrPostCallback().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher, /*static*/ (/*object?*/ o) =>
                {
                    /*var*/ let state = $.$cast(o, $.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(TResult))));
                    try
                    {
                        state.Item2.Invoke().ContinueWith$26(new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.Task$$(TResult)))().$ctor(this,  (/**/ t) =>
                        {
                            if (t.IsFaulted)
                            {
                                state.Item1.SetException(t.Exception);
                            }
                            else if (t.IsCanceled)
                            {
                                state.Item1.SetCanceled();
                            }
                            else 
                            {
                                state.Item1.SetResult(t.Result);
                            }
                        }, {"r":65537,"p":[{"n":"t","p":(TResult) => $.$spc.System.Threading.Tasks.Task$$(TResult).$h}],"n":"","d":2883596,"h":0,"f":1048578}), $.$spc.System.Threading.Tasks.TaskScheduler.FromCurrentSynchronizationContext());
                    }
                    catch(ex)
                    {
                        state.Item1.SetException(ex);
                    }
                }, {"r":65537,"p":[{"n":"o","p":131073}],"n":"","d":2883596,"h":0,"f":1048610}), new ($.$spc.System.ValueTuple$$$($.$spc.System.Threading.Tasks.TaskCompletionSource$$(TResult), $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(TResult))))().$ctor$2(tcs, workItem));
                return tcs.Task;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2883596;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1703944,"m":[{"r":262145,"n":"CheckAccess","d":2883596,"h":12887785484,"f":32769},{"r":133300225,"p":[{"n":"workItem","p":11665409}],"n":"InvokeAsync","d":2883596,"h":17182752780,"f":32769},{"r":(TResult) => $.$spc.System.Threading.Tasks.Task$$(TResult).$h,"p":[{"n":"workItem","p":(TResult) => $.$spc.System.Func$$(TResult).$h}],"g":["TResult"],"n":"InvokeAsync","o":"@$2","d":2883596,"h":21477720076,"f":163841},{"r":133300225,"p":[{"n":"workItem","p":$.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task).$h}],"n":"InvokeAsync","o":"@$1","d":2883596,"h":25772687372,"f":32769},{"r":(TResult) => $.$spc.System.Threading.Tasks.Task$$(TResult).$h,"p":[{"n":"workItem","p":(TResult) => $.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task$$(TResult)).$h}],"g":["TResult"],"n":"InvokeAsync","o":"@$3","d":2883596,"h":30067654668,"f":163841}],"l":[{"t":131137537,"n":"_mainSynchronizationContext","d":2883596,"h":4297850892,"f":40},{"t":655361,"n":"_mainManagedThreadId","d":2883596,"h":8592818188,"f":40}],"c":[{"n":".ctor","o":"$ctor$2","d":2883596,"h":34362621964,"f":1}],"h":2883596}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Dispatcher; }
            static get $fullName() { return `WebAssemblyDispatcher`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentMarker", ($self) => class ComponentMarker extends $.$spc.System.ValueType
        {
            /*string*/ static ServerMarkerType = null;
            /*string*/ static WebAssemblyMarkerType = null;
            /*string*/ static AutoMarkerType = null;
            /*string?*/ Type = null;
            /*string?*/ PrerenderId = null;
            /*ComponentMarkerKey?*/ Key = null;
            /*int?*/ Sequence = null;
            /*string?*/ Descriptor = null;
            /*string?*/ Assembly = null;
            /*string?*/ TypeName = null;
            /*string?*/ ParameterDefinitions = null;
            /*string?*/ ParameterValues = null;
            static /*ComponentMarker */ Create(/*string*/ type, /*bool*/ prerendered, /*ComponentMarkerKey?*/ key)
            {
                return (() =>
                {
                    //new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker()
                    const $t1 = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker;
                    const $i1 = new $t1();
                    $i1.Type = type;
                    $i1.PrerenderId = prerendered ? $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.GeneratePrerenderId() : null;
                    $i1.Key = key?.Clone() ?? null;
                    return $i1;
                })();
            }
            /*void */ WriteServerData(/*int*/ sequence, /*string*/ descriptor)
            {
                this.Sequence = sequence;
                this.Descriptor = descriptor;
            }
            /*void */ WriteWebAssemblyData(/*string*/ assembly, /*string*/ typeName, /*string*/ parameterDefinitions, /*string*/ parameterValues)
            {
                this.Assembly = assembly;
                this.TypeName = typeName;
                this.ParameterDefinitions = parameterDefinitions;
                this.ParameterValues = parameterValues;
            }
            /*ComponentEndMarker? */ ToEndMarker()
            {
                return this.PrerenderId === null ? new ($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker))() : (() =>
                {
                    //new $.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker()
                    const $t1 = $.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker;
                    const $i1 = new $t1();
                    $i1.PrerenderId = this.PrerenderId;
                    return $i1;
                })();
            }
            static /*string */ GeneratePrerenderId()
            {
                return $.$spc.System.Guid.NewGuid().ToString$1("N");
            }
            /*string */ GetDebuggerDisplay()
            {
                switch(this.Type)
                {
                    case "server"/*ServerMarkerType*/:
                    const $t2 = this.Descriptor;
                    return `Server Component: ${this.TypeName}, Sequence: ${this.Sequence}, Key: ${(this.Key?.FormattedComponentKey ?? null)} Descriptor: ${$.$ifnn($t2, ($t) => $.$spc.System.String.Substring.call($t, 5))}...`;
                    case "webassembly"/*WebAssemblyMarkerType*/:
                    return `WebAssembly Component: ${this.TypeName}, Assembly: ${this.Assembly}, Key: ${(this.Key?.FormattedComponentKey ?? null)}`;
                    case "auto"/*AutoMarkerType*/:
                    const $t3 = this.Descriptor;
                    return `Auto Component: ${this.TypeName}, Assembly: ${this.Assembly}, Key: ${(this.Key?.FormattedComponentKey ?? null)}, Descriptor: ${$.$ifnn($t3, ($t) => $.$spc.System.String.Substring.call($t, 5))}...`;
                    default:
                    return `Unknown Component Type: ${this.Type}, Key: ${(this.Key?.FormattedComponentKey ?? null)}`;
                }
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Type = this.Type;
                copy.PrerenderId = this.PrerenderId;
                copy.Key = this.Key.Clone();
                copy.Sequence = this.Sequence;
                copy.Descriptor = this.Descriptor;
                copy.Assembly = this.Assembly;
                copy.TypeName = this.TypeName;
                copy.ParameterDefinitions = this.ParameterDefinitions;
                copy.ParameterValues = this.ParameterValues;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Key = null;
                this.Sequence = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ServerMarkerType = "server";
                }
                {
                    this.WebAssemblyMarkerType = "webassembly";
                }
                {
                    this.AutoMarkerType = "auto";
                }
            }
            static $h = 131084;
            static $z = 42;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25769934860,"f":1},"s":{"r":0,"d":0,"h":30064902156,"f":1},"n":"Type","d":131084,"h":21474967564,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42949804044,"f":1},"s":{"r":0,"d":0,"h":47244771340,"f":1},"n":"PrerenderId","d":131084,"h":38654836748,"f":1},{"p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,"g":{"r":0,"d":0,"h":60129673228,"f":1},"s":{"r":0,"d":0,"h":64424640524,"f":1},"n":"Key","d":131084,"h":55834705932,"f":1},{"p":$.$typeNullable($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":77309542412,"f":1},"s":{"r":0,"d":0,"h":81604509708,"f":1},"n":"Sequence","d":131084,"h":73014575116,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489411596,"f":1},"s":{"r":0,"d":0,"h":98784378892,"f":1},"n":"Descriptor","d":131084,"h":90194444300,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669280780,"f":1},"s":{"r":0,"d":0,"h":115964248076,"f":1},"n":"Assembly","d":131084,"h":107374313484,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849149964,"f":1},"s":{"r":0,"d":0,"h":133144117260,"f":1},"n":"TypeName","d":131084,"h":124554182668,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":146029019148,"f":1},"s":{"r":0,"d":0,"h":150323986444,"f":1},"n":"ParameterDefinitions","d":131084,"h":141734051852,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":163208888332,"f":1},"s":{"r":0,"d":0,"h":167503855628,"f":1},"n":"ParameterValues","d":131084,"h":158913921036,"f":1}],"m":[{"r":131084,"p":[{"n":"type","p":1310721},{"n":"prerendered","p":262145},{"n":"key","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h}],"n":"Create","d":131084,"h":171798822924,"f":33},{"r":65537,"p":[{"n":"sequence","p":655361},{"n":"descriptor","p":1310721}],"n":"WriteServerData","d":131084,"h":176093790220,"f":1},{"r":65537,"p":[{"n":"assembly","p":1310721},{"n":"typeName","p":1310721},{"n":"parameterDefinitions","p":1310721},{"n":"parameterValues","p":1310721}],"n":"WriteWebAssemblyData","d":131084,"h":180388757516,"f":1},{"r":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker).$h,"n":"ToEndMarker","d":131084,"h":184683724812,"f":1},{"r":1310721,"n":"GeneratePrerenderId","d":131084,"h":188978692108,"f":34},{"r":1310721,"n":"GetDebuggerDisplay","d":131084,"h":193273659404,"f":2}],"l":[{"t":1310721,"n":"ServerMarkerType","d":131084,"h":4295098380,"f":33},{"t":1310721,"n":"WebAssemblyMarkerType","d":131084,"h":8590065676,"f":33},{"t":1310721,"n":"AutoMarkerType","d":131084,"h":12885032972,"f":33}],"c":[{"n":".ctor","o":"$ctor$2","d":131084,"h":197568626700,"f":1}],"h":131084,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{GetDebuggerDisplay(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ComponentMarker`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentEndMarker", ($self) => class ComponentEndMarker extends $.$spc.System.ValueType
        {
            /*string?*/ PrerenderId = null;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PrerenderId = this.PrerenderId;
                return copy;
            }
            static $h = 65548;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12884967436,"f":1},"s":{"r":0,"d":0,"h":17179934732,"f":1},"n":"PrerenderId","d":65548,"h":8590000140,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":65548,"h":21474902028,"f":1}],"h":65548}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `ComponentEndMarker`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey", ($self) => class ComponentMarkerKey extends $.$spc.System.ValueType
        {
            $ctor$2(/*string*/ locationHash, /*string?*/ formattedComponentKey)
            {
                super.$ctor$1();
                $.$tupleUnpack(($tp) =>
                {
                    this.LocationHash = $tp.Item1;
                    this.FormattedComponentKey = $tp.Item2;
                }).$v = { Item1: locationHash, Item2: formattedComponentKey };
                return this;
            }
            /*string*/ LocationHash = null;
            /*string?*/ FormattedComponentKey = null;
            static /*bool */ op_Equality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                return left.Equals$2(right.Clone());
            }
            static /*bool */ op_Inequality(/*ComponentMarkerKey*/ left, /*ComponentMarkerKey*/ right)
            {
                return !($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Equality(left, right));
            }
            /*bool */ Equals$2(/*ComponentMarkerKey*/ other)
            {
                return $.$spc.System.String.Equals$5(this.LocationHash, other.LocationHash, 4/*StringComparison.Ordinal*/) && $.$spc.System.String.Equals$5(this.FormattedComponentKey, other.FormattedComponentKey, 4/*StringComparison.Ordinal*/);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.String, $.$spc.System.String, this.LocationHash, this.FormattedComponentKey);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.GetHashCode.apply(this, arguments); }
            /*string */ GetDebuggerDisplay()
            {
                return `LocationHash: ${this.LocationHash}, Key: ${this.FormattedComponentKey ?? "null"}`;
            }
            /*string? */ Serialized()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Equality(this, new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey()) ? null : `${this.LocationHash}:${this.FormattedComponentKey}`;
            }
            //Generated interface implemetation for System.IEquatable<Microsoft.AspNetCore.Components.ComponentMarkerKey>.Equals(Microsoft.AspNetCore.Components.ComponentMarkerKey)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.LocationHash = this.LocationHash;
                copy.FormattedComponentKey = this.FormattedComponentKey;
                return copy;
            }
            static $h = 196620;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180065804,"f":1},"s":{"r":0,"d":0,"h":21475033100,"f":1},"n":"LocationHash","d":196620,"h":12885098508,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34359934988,"f":1},"s":{"r":0,"d":0,"h":38654902284,"f":1},"n":"FormattedComponentKey","d":196620,"h":30064967692,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":196620}],"n":"Equals","o":"@$2","d":196620,"h":51539804172,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":196620,"h":55834771468,"f":32769},{"r":655361,"n":"GetHashCode","d":196620,"h":60129738764,"f":32769},{"r":1310721,"n":"GetDebuggerDisplay","d":196620,"h":64424706060,"f":2},{"r":1310721,"n":"Serialized","d":196620,"h":68719673356,"f":8}],"c":[{"p":[{"n":"locationHash","p":1310721},{"n":"formattedComponentKey","p":1310721}],"n":".ctor","o":"$ctor$2","d":196620,"h":4295163916,"f":1},{"n":".ctor","o":"$ctor$3","d":196620,"h":73014640652,"f":1}],"i":[$.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h],"h":196620,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{GetDebuggerDisplay(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey) ]; }
            static get $fullName() { return `ComponentMarkerKey`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext", ($self) => class WebAssemblyJsonSerializerContext extends $.$stj.System.Text.Json.Serialization.JsonSerializerContext
        {
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo));
                return typeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type))
                {
                    return this.Create_ComponentMarker(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type))
                {
                    return this.Create_NullableComponentMarker(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type))
                {
                    return this.Create_ComponentMarkerKey(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type))
                {
                    return this.Create_NullableComponentMarkerKey(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type))
                {
                    return this.Create_ComponentParameter(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$type))
                {
                    return this.Create_ComponentParameterArray(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type))
                {
                    return this.Create_ParameterView(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type))
                {
                    return this.Create_RootComponentOperation(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type))
                {
                    return this.Create_RootComponentOperationArray(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type))
                {
                    return this.Create_RootComponentOperationBatch(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type))
                {
                    return this.Create_RootComponentOperationType(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type))
                {
                    return this.Create_WebRootComponentDescriptor(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type))
                {
                    return this.Create_WebRootComponentParameters(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$type))
                {
                    return this.Create_IListObject(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$stj.System.Text.Json.JsonElement.$type))
                {
                    return this.Create_JsonElement(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Type.$type))
                {
                    return this.Create_Type(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Int32.$type))
                {
                    return this.Create_Int32(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeNullable($.$spc.System.Int32).$type))
                {
                    return this.Create_NullableInt32(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Int64.$type))
                {
                    return this.Create_Int64(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Object.$type))
                {
                    return this.Create_Object(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.String.$type))
                {
                    return this.Create_String(options);
                }
                return null;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>?*/ _IListObject = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ get IListObject()
            {
                return this._IListObject ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>> */ Create_IListObject(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.IList<object>>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = null;
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateIListInfo$1($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object), $.$spc.System.Object, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>?*/ _Int32 = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ get Int32()
            {
                return this._Int32 ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Int32.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int32));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int> */ Create_Int32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Int32, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int32))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.Int32, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.Int32Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>?*/ _Int64 = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ get Int64()
            {
                return this._Int64 ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Int64.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int64));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long> */ Create_Int64(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<long>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Int64, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int64))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.Int64, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.Int64Converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>?*/ _ComponentParameter = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ get ComponentParameter()
            {
                return this._ComponentParameter ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter> */ Create_ComponentParameter(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter().$ctor$2();
                        }, {"r":262156,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentParameterPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))().$ctor(this, this.ComponentParameterSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentParameterPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [3], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).Name;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.Name = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Name";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty$6("Name", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info0), 0);
                $.$spc.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$spc.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/**/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).TypeName;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/**/ obj, /**/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.TypeName = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "TypeName";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty$6("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/**/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).Assembly;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/**/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, obj).$v.Assembly = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Assembly";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentParameter.$type.GetProperty$6("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i3;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info2), 2);
                return properties;
            }
            /*void */ ComponentParameterSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter*/ value)
            {
                writer.WriteStartObject();
                /*string*/ let __value_Name = (value).Name;
                if (!(__value_Name === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_name, __value_Name);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>?*/ _ComponentParameterArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ get ComponentParameterArray()
            {
                return this._ComponentParameterArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]> */ Create_ComponentParameterArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentParameter[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)))().$ctor(this, this.ComponentParameterArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ ComponentParameterArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentParameter[]?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.ComponentParameterSerializeHandler(writer, $.$spc.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>?*/ _Object = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ get Object()
            {
                return this._Object ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Object.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Object));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object> */ Create_Object(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<object>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Object, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Object))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.Object, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.ObjectConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>?*/ _JsonElement = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ get JsonElement()
            {
                return this._JsonElement ??= $.$cast(this.Options.GetTypeInfo($.$stj.System.Text.Json.JsonElement.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement> */ Create_JsonElement(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Text.Json.JsonElement>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$stj.System.Text.Json.JsonElement, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$stj.System.Text.Json.JsonElement, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.JsonElementConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>?*/ _NullableComponentMarker = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ get NullableComponentMarker()
            {
                return this._NullableComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?> */ Create_NullableComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter$1($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            /*global::Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext*/ static Default = null;
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                }
                return this;
            }
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                }
                return this;
            }
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                for(/*int*/ let i = 0; i < options.Converters.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.System$Collections$Generic$IList$$$get_Item(i, [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spc.System.String.Format$1("The converter '{0}' is not compatible with the type '{1}'.", $.$spc.System.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spc.System.String.Format("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$spc.System.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_type;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_prerenderId;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_key;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_sequence;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_descriptor;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_assembly;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_typeName;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterDefinitions;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameterValues;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_locationHash;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_formattedComponentKey;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_name;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_ssrComponentId;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_marker;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_batchId;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_operations;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_componentType;
            /*global::System.Text.Json.JsonEncodedText*/ static PropName_parameters;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>?*/ _NullableComponentMarkerKey = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ get NullableComponentMarkerKey()
            {
                return this._NullableComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?> */ Create_NullableComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter$1($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>?*/ _RootComponentOperationArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ get RootComponentOperationArray()
            {
                return this._RootComponentOperationArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]> */ Create_RootComponentOperationArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor(this, this.RootComponentOperationArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateArrayInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ RootComponentOperationArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartArray();
                for(/*int*/ let i = 0; i < value.length; i++)
                {
                    this.RootComponentOperationSerializeHandler(writer, $.$spc.System.Array.$ReadT1.call(value, i));
                }
                writer.WriteEndArray();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>?*/ _Type = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ get Type()
            {
                return this._Type ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Type.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Type));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type> */ Create_Type(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Type>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Type, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Type))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.Type, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetUnsupportedTypeConverter($.$spc.System.Type));
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>?*/ _NullableInt32 = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ get NullableInt32()
            {
                return this._NullableInt32 ??= $.$cast(this.Options.GetTypeInfo($.$typeNullable($.$spc.System.Int32).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$spc.System.Int32)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?> */ Create_NullableInt32(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<int?>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeNullable($.$spc.System.Int32), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$spc.System.Int32)))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.GetNullableConverter$1($.$spc.System.Int32, options);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeNullable($.$spc.System.Int32), options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>?*/ _ParameterView = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ get ParameterView()
            {
                return this._ParameterView ??= $.$cast(this.Options.GetTypeInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView> */ Create_ParameterView(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ParameterView>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor(this,  () =>
                        {
                            return new $.$mac.Microsoft.AspNetCore.Components.ParameterView().$ctor$4();
                        }, {"r":5767176,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ParameterViewPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor(this, this.ParameterViewSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ParameterViewPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [0], null);
                return properties;
            }
            /*void */ ParameterViewSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ParameterView*/ value)
            {
                writer.WriteStartObject();
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>?*/ _WebRootComponentParameters = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ get WebRootComponentParameters()
            {
                return this._WebRootComponentParameters ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters> */ Create_WebRootComponentParameters(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentParameters>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$3();
                        }, {"r":4390924,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentParametersPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor(this, this.WebRootComponentParametersSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentParametersPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [1], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$mac.Microsoft.AspNetCore.Components.ParameterView);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$mac.Microsoft.AspNetCore.Components.ParameterView))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)).Parameters;
                    }, {"r":5767176,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = null;
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Parameters";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type.GetProperty$6("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$mac.Microsoft.AspNetCore.Components.ParameterView.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$mac.Microsoft.AspNetCore.Components.ParameterView, options, info0), 0);
                return properties;
            }
            /*void */ WebRootComponentParametersSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentParameters*/ value)
            {
                writer.WriteStartObject();
                writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.ParameterViewSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>?*/ _WebRootComponentDescriptor = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ get WebRootComponentDescriptor()
            {
                return this._WebRootComponentDescriptor ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor> */ Create_WebRootComponentDescriptor(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.ObjectWithParameterizedConstructorCreator = new ($.$spc.System.Func$$$($.$typeArray($.$spc.System.Object), $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor().$ctor$1($.$cast($.$spc.System.Array.$ReadT1.call(args, 0), $.$spc.System.Type), $.$cast($.$spc.System.Array.$ReadT1.call(args, 1), $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters));
                        }, {"r":4325388,"p":[{"n":"args","p":0}],"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = new ($.$spc.System.Func$$($.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.WebRootComponentDescriptorCtorParamInit);
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.Type.$type, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type], null, null), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor(this, this.WebRootComponentDescriptorSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ WebRootComponentDescriptorPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Type)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Type);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Type))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)).ComponentType;
                    }, {"r":142606337,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = null;
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "ComponentType";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetProperty$6("ComponentType", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Type.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.Type, options, info0), 0);
                $.$spc.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)).Parameters;
                    }, {"r":4390924,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = null;
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "Parameters";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type.GetProperty$6("Parameters", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters, options, info1), 1);
                return properties;
            }
            /*void */ WebRootComponentDescriptorSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                /*global::System.Type*/ let __value_ComponentType = (value).ComponentType;
                if (!(__value_ComponentType === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_componentType);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$spc.System.Type, writer, __value_ComponentType, this.Type);
                }
                writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameters);
                this.WebRootComponentParametersSerializeHandler(writer, (value).Parameters);
                writer.WriteEndObject();
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ WebRootComponentDescriptorCtorParamInit()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues), [(() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Name = "componentType";
                    $i1.ParameterType = $.$spc.System.Type.$type;
                    $i1.Position = 0;
                    $i1.HasDefaultValue = false;
                    $i1.DefaultValue = null;
                    $i1.IsNullable = false;
                    return $i1;
                })(), (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.Name = "parameters";
                    $i2.ParameterType = $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters.$type;
                    $i2.Position = 1;
                    $i2.HasDefaultValue = false;
                    $i2.DefaultValue = null;
                    $i2.IsNullable = false;
                    return $i2;
                })()], [-1], null);
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>?*/ _RootComponentOperationBatch = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ get RootComponentOperationBatch()
            {
                return this._RootComponentOperationBatch ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch> */ Create_RootComponentOperationBatch(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationBatch>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = null;
                        $i2.ObjectWithParameterizedConstructorCreator = new ($.$spc.System.Func$$$($.$typeArray($.$spc.System.Object), $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*args*/ args) =>
                        {
                            return (() =>
                            {
                                //new $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch()
                                const $t3 = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch;
                                const $i3 = new $t3();
                                $i3.Operations = $.$cast($.$spc.System.Array.$ReadT1.call(args, 0), $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                                return $i3;
                            })();
                        }, {"r":1048588,"p":[{"n":"args","p":0}],"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationBatchPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = new ($.$spc.System.Func$$($.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationBatchCtorParamInit);
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch))().$ctor(this, this.RootComponentOperationBatchSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationBatchPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Int64)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Int64);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Int64))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).BatchId;
                    }, {"r":917505,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Int64))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).BatchId = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":917505}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "BatchId";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetProperty$6("BatchId", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Int64.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.Int64, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).Operations;
                    }, {"r":0,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch)).Operations = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":0}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "Operations";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch.$type.GetProperty$6("Operations", 52/*InstanceMemberBindingFlags*/, null, $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation), options, info1), 1);
                $.$spc.System.Array.$ReadT1.call(properties, 1).IsRequired = true;
                $.$spc.System.Array.$ReadT1.call(properties, 1).IsGetNullable = false;
                $.$spc.System.Array.$ReadT1.call(properties, 1).IsSetNullable = false;
                return properties;
            }
            /*void */ RootComponentOperationBatchSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperationBatch?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WriteNumber$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_batchId, (value).BatchId);
                /*global::Microsoft.AspNetCore.Components.RootComponentOperation[]*/ let __value_Operations = (value).Operations;
                if (!(__value_Operations === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_operations);
                    this.RootComponentOperationArraySerializeHandler(writer, __value_Operations);
                }
                writer.WriteEndObject();
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonParameterInfoValues[] */ RootComponentOperationBatchCtorParamInit()
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues), [(() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonParameterInfoValues;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Name = "Operations";
                    $i1.ParameterType = $.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$type;
                    $i1.Position = 0;
                    $i1.IsNullable = false;
                    $i1.IsMemberInitializer = true;
                    return $i1;
                })()], [-1], null);
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>?*/ _RootComponentOperationType = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ get RootComponentOperationType()
            {
                return this._RootComponentOperationType ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType> */ Create_RootComponentOperationType(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperationType>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))))
                {
                    /*global::System.Text.Json.Serialization.JsonConverter*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ExpandConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type, new ($.$stj.System.Text.Json.Serialization.JsonStringEnumConverter$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor$3(), options, true);
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, converter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.String.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.String, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>?*/ _ComponentMarker = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ get ComponentMarker()
            {
                return this._ComponentMarker ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker> */ Create_ComponentMarker(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarker>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker().$ctor$2();
                        }, {"r":131084,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentMarkerPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))().$ctor(this, this.ComponentMarkerSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [9], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Type;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Type = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Type";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("Type", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).PrerenderId;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.PrerenderId = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "PrerenderId";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("PrerenderId", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey));
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Key;
                    }, {"r":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Key = value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Key";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("Key", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i3;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$spc.System.Int32))()
                    const $t4 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$spc.System.Int32));
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.IsProperty = true;
                    $i4.IsPublic = true;
                    $i4.IsVirtual = false;
                    $i4.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i4.Converter = null;
                    $i4.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$spc.System.Int32)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Sequence;
                    }, {"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i4.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$spc.System.Int32)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Sequence = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$spc.System.Int32).$h}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i4.IgnoreCondition = null;
                    $i4.HasJsonInclude = false;
                    $i4.IsExtensionData = false;
                    $i4.NumberHandling = null;
                    $i4.PropertyName = "Sequence";
                    $i4.JsonPropertyName = null;
                    $i4.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("Sequence", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$spc.System.Int32).$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i4;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$spc.System.Int32), options, info3), 3);
                /*var*/ let info4 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t5 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i5 = new $t5();
                    $i5.$ctor$1();
                    $i5.IsProperty = true;
                    $i5.IsPublic = true;
                    $i5.IsVirtual = false;
                    $i5.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i5.Converter = null;
                    $i5.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Descriptor;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i5.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Descriptor = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i5.IgnoreCondition = null;
                    $i5.HasJsonInclude = false;
                    $i5.IsExtensionData = false;
                    $i5.NumberHandling = null;
                    $i5.PropertyName = "Descriptor";
                    $i5.JsonPropertyName = null;
                    $i5.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i5;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info4), 4);
                /*var*/ let info5 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t6 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i6 = new $t6();
                    $i6.$ctor$1();
                    $i6.IsProperty = true;
                    $i6.IsPublic = true;
                    $i6.IsVirtual = false;
                    $i6.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i6.Converter = null;
                    $i6.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).Assembly;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i6.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.Assembly = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i6.IgnoreCondition = null;
                    $i6.HasJsonInclude = false;
                    $i6.IsExtensionData = false;
                    $i6.NumberHandling = null;
                    $i6.PropertyName = "Assembly";
                    $i6.JsonPropertyName = null;
                    $i6.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("Assembly", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i6;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info5), 5);
                /*var*/ let info6 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t7 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i7 = new $t7();
                    $i7.$ctor$1();
                    $i7.IsProperty = true;
                    $i7.IsPublic = true;
                    $i7.IsVirtual = false;
                    $i7.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i7.Converter = null;
                    $i7.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).TypeName;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i7.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.TypeName = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i7.IgnoreCondition = null;
                    $i7.HasJsonInclude = false;
                    $i7.IsExtensionData = false;
                    $i7.NumberHandling = null;
                    $i7.PropertyName = "TypeName";
                    $i7.JsonPropertyName = null;
                    $i7.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("TypeName", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i7;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info6), 6);
                /*var*/ let info7 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t8 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i8 = new $t8();
                    $i8.$ctor$1();
                    $i8.IsProperty = true;
                    $i8.IsPublic = true;
                    $i8.IsVirtual = false;
                    $i8.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i8.Converter = null;
                    $i8.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).ParameterDefinitions;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i8.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.ParameterDefinitions = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i8.IgnoreCondition = null;
                    $i8.HasJsonInclude = false;
                    $i8.IsExtensionData = false;
                    $i8.NumberHandling = null;
                    $i8.PropertyName = "ParameterDefinitions";
                    $i8.JsonPropertyName = null;
                    $i8.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("ParameterDefinitions", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i8;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info7), 7);
                /*var*/ let info8 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t9 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i9 = new $t9();
                    $i9.$ctor$1();
                    $i9.IsProperty = true;
                    $i9.IsPublic = true;
                    $i9.IsVirtual = false;
                    $i9.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type;
                    $i9.Converter = null;
                    $i9.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).ParameterValues;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i9.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker, obj).$v.ParameterValues = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i9.IgnoreCondition = null;
                    $i9.HasJsonInclude = false;
                    $i9.IsExtensionData = false;
                    $i9.NumberHandling = null;
                    $i9.PropertyName = "ParameterValues";
                    $i9.JsonPropertyName = null;
                    $i9.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarker.$type.GetProperty$6("ParameterValues", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i9;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info8), 8);
                return properties;
            }
            /*void */ ComponentMarkerSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarker*/ value)
            {
                writer.WriteStartObject();
                /*string*/ let __value_Type = (value).Type;
                if (!(__value_Type === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_type, __value_Type);
                }
                /*string*/ let __value_PrerenderId = (value).PrerenderId;
                if (!(__value_PrerenderId === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_prerenderId, __value_PrerenderId);
                }
                /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey?*/ let __value_Key = (value).Key;
                if (!(__value_Key === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_key);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey), writer, __value_Key?.Clone() ?? null, this.NullableComponentMarkerKey);
                }
                /*int?*/ let __value_Sequence = (value).Sequence;
                if (!(__value_Sequence === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_sequence);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$spc.System.Int32), writer, __value_Sequence, this.NullableInt32);
                }
                /*string*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_descriptor, __value_Descriptor);
                }
                /*string*/ let __value_Assembly = (value).Assembly;
                if (!(__value_Assembly === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_assembly, __value_Assembly);
                }
                /*string*/ let __value_TypeName = (value).TypeName;
                if (!(__value_TypeName === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_typeName, __value_TypeName);
                }
                /*string*/ let __value_ParameterDefinitions = (value).ParameterDefinitions;
                if (!(__value_ParameterDefinitions === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameterDefinitions, __value_ParameterDefinitions);
                }
                /*string*/ let __value_ParameterValues = (value).ParameterValues;
                if (!(__value_ParameterValues === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_parameterValues, __value_ParameterValues);
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>?*/ _RootComponentOperation = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ get RootComponentOperation()
            {
                return this._RootComponentOperation ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation> */ Create_RootComponentOperation(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.RootComponentOperation>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation().$ctor$1();
                        }, {"r":983052,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.RootComponentOperationPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation))().$ctor(this, this.RootComponentOperationSerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ RootComponentOperationPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [4], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Type;
                    }, {"r":1114124,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Type = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1114124}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "Type";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty$6("Type", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, options, info0), 0);
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Int32)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Int32);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Int32))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).SsrComponentId;
                    }, {"r":655361,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Int32))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).SsrComponentId = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":655361}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "SsrComponentId";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty$6("SsrComponentId", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Int32.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.Int32, options, info1), 1);
                /*var*/ let info2 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker))()
                    const $t3 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker));
                    const $i3 = new $t3();
                    $i3.$ctor$1();
                    $i3.IsProperty = true;
                    $i3.IsPublic = true;
                    $i3.IsVirtual = false;
                    $i3.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i3.Converter = null;
                    $i3.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Marker;
                    }, {"r":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Marker = value?.Clone() ?? null;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i3.IgnoreCondition = null;
                    $i3.HasJsonInclude = false;
                    $i3.IsExtensionData = false;
                    $i3.NumberHandling = null;
                    $i3.PropertyName = "Marker";
                    $i3.JsonPropertyName = null;
                    $i3.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty$6("Marker", 52/*InstanceMemberBindingFlags*/, null, $.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i3;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), options, info2), 2);
                /*var*/ let info3 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor)()
                    const $t4 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor);
                    const $i4 = new $t4();
                    $i4.$ctor$1();
                    $i4.IsProperty = true;
                    $i4.IsPublic = true;
                    $i4.IsVirtual = false;
                    $i4.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type;
                    $i4.Converter = null;
                    $i4.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Descriptor;
                    }, {"r":4325388,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i4.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).Descriptor = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":4325388}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i4.IgnoreCondition = null;
                    $i4.HasJsonInclude = false;
                    $i4.IsExtensionData = false;
                    $i4.NumberHandling = null;
                    $i4.PropertyName = "Descriptor";
                    $i4.JsonPropertyName = null;
                    $i4.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation.$type.GetProperty$6("Descriptor", 52/*InstanceMemberBindingFlags*/, null, $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i4;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor, options, info3), 3);
                return properties;
            }
            /*void */ RootComponentOperationSerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.RootComponentOperation?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_type);
                $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType, writer, (value).Type, this.RootComponentOperationType);
                writer.WriteNumber$12($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_ssrComponentId, (value).SsrComponentId);
                /*global::Microsoft.AspNetCore.Components.ComponentMarker?*/ let __value_Marker = (value).Marker;
                if (!(__value_Marker === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_marker);
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$12($.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker), writer, __value_Marker?.Clone() ?? null, this.NullableComponentMarker);
                }
                /*global::Microsoft.AspNetCore.Components.WebRootComponentDescriptor*/ let __value_Descriptor = (value).Descriptor;
                if (!(__value_Descriptor === null))
                {
                    writer.WritePropertyName$8($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_descriptor);
                    this.WebRootComponentDescriptorSerializeHandler(writer, __value_Descriptor);
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>?*/ _ComponentMarkerKey = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ get ComponentMarkerKey()
            {
                return this._ComponentMarkerKey ??= $.$cast(this.Options.GetTypeInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey> */ Create_ComponentMarkerKey(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::Microsoft.AspNetCore.Components.ComponentMarkerKey>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))))
                {
                    /*var*/ let objectInfo = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonObjectInfoValues$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey);
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))().$ctor(this,  () =>
                        {
                            return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey().$ctor$3();
                        }, {"r":196620,"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ObjectWithParameterizedConstructorCreator = null;
                        $i2.PropertyMetadataInitializer = new ($.$spc.System.Func$$$($.$stj.System.Text.Json.Serialization.JsonSerializerContext, $.$typeArray($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo)))().$ctor(this,  (/*_*/ _0) =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.ComponentMarkerKeyPropInit(options);
                        }, {"r":0,"p":[{"n":"_","p":14784173}],"n":"","d":2686988,"h":0,"f":1048578});
                        $i2.ConstructorParameterMetadataInitializer = null;
                        $i2.ConstructorAttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                        {
                            return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetConstructor$3(52/*InstanceMemberBindingFlags*/, null, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                        }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey))().$ctor(this, this.ComponentMarkerKeySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateObjectInfo($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, options, objectInfo);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            static /*global::System.Text.Json.Serialization.Metadata.JsonPropertyInfo[] */ ComponentMarkerKeyPropInit(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*var*/ let properties = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfo), null, [2], null);
                /*var*/ let info0 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t1 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.IsProperty = true;
                    $i1.IsPublic = true;
                    $i1.IsVirtual = false;
                    $i1.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type;
                    $i1.Converter = null;
                    $i1.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).LocationHash;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, obj).$v.LocationHash = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i1.IgnoreCondition = null;
                    $i1.HasJsonInclude = false;
                    $i1.IsExtensionData = false;
                    $i1.NumberHandling = null;
                    $i1.PropertyName = "LocationHash";
                    $i1.JsonPropertyName = null;
                    $i1.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetProperty$6("LocationHash", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i1;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info0), 0);
                $.$spc.System.Array.$ReadT1.call(properties, 0).IsGetNullable = false;
                $.$spc.System.Array.$ReadT1.call(properties, 0).IsSetNullable = false;
                /*var*/ let info1 = (() =>
                {
                    //new $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String)()
                    const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonPropertyInfoValues$$($.$spc.System.String);
                    const $i2 = new $t2();
                    $i2.$ctor$1();
                    $i2.IsProperty = true;
                    $i2.IsPublic = true;
                    $i2.IsVirtual = false;
                    $i2.DeclaringType = $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type;
                    $i2.Converter = null;
                    $i2.Getter = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj) =>
                    {
                        return ($.$cast(obj, $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).FormattedComponentKey;
                    }, {"r":1310721,"p":[{"n":"obj","p":131073}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.Setter = new ($.$spc.System.Action$$$($.$spc.System.Object, $.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ (/*obj*/ obj, /*value*/ value) =>
                    {
                        return $.$spc.System.Runtime.CompilerServices.Unsafe.Unbox($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey, obj).$v.FormattedComponentKey = value;
                    }, {"r":65537,"p":[{"n":"obj","p":131073},{"n":"value","p":1310721}],"n":"","d":2686988,"h":0,"f":1048610});
                    $i2.IgnoreCondition = null;
                    $i2.HasJsonInclude = false;
                    $i2.IsExtensionData = false;
                    $i2.NumberHandling = null;
                    $i2.PropertyName = "FormattedComponentKey";
                    $i2.JsonPropertyName = null;
                    $i2.AttributeProviderFactory = new ($.$spc.System.Func$$($.$spc.System.Reflection.ICustomAttributeProvider))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext, /*static*/ () =>
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.$type.GetProperty$6("FormattedComponentKey", 52/*InstanceMemberBindingFlags*/, null, $.$spc.System.String.$type, $.$spc.System.Array.Empty($.$spc.System.Type), null);
                    }, {"r":76939265,"n":"","d":2686988,"h":0,"f":1048610});
                    return $i2;
                })();
                $.$spc.System.Array.$WriteT1.call(properties, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreatePropertyInfo($.$spc.System.String, options, info1), 1);
                return properties;
            }
            /*void */ ComponentMarkerKeySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::Microsoft.AspNetCore.Components.ComponentMarkerKey*/ value)
            {
                writer.WriteStartObject();
                /*string*/ let __value_LocationHash = (value).LocationHash;
                if (!(__value_LocationHash === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_locationHash, __value_LocationHash);
                }
                /*string*/ let __value_FormattedComponentKey = (value).FormattedComponentKey;
                if (!(__value_FormattedComponentKey === null))
                {
                    writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.PropName_formattedComponentKey, __value_FormattedComponentKey);
                }
                writer.WriteEndObject();
            }
            //default member initializer
            constructor()
            {
                super();
                this.GeneratedSerializerOptions = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.s_defaultOptions;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultOptions = (() =>
                    {
                        //new $.$stj.System.Text.Json.JsonSerializerOptions()
                        const $t1 = $.$stj.System.Text.Json.JsonSerializerOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.DefaultIgnoreCondition = 3/*global::System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull*/;
                        $i1.PropertyNameCaseInsensitive = true;
                        $i1.PropertyNamingPolicy = $.$stj.System.Text.Json.JsonNamingPolicy.CamelCase;
                        return $i1;
                    })();
                }
                {
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext().$ctor$3(new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$2($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.s_defaultOptions));
                }
                {
                    this.PropName_type = $.$stj.System.Text.Json.JsonEncodedText.Encode("type", null);
                }
                {
                    this.PropName_prerenderId = $.$stj.System.Text.Json.JsonEncodedText.Encode("prerenderId", null);
                }
                {
                    this.PropName_key = $.$stj.System.Text.Json.JsonEncodedText.Encode("key", null);
                }
                {
                    this.PropName_sequence = $.$stj.System.Text.Json.JsonEncodedText.Encode("sequence", null);
                }
                {
                    this.PropName_descriptor = $.$stj.System.Text.Json.JsonEncodedText.Encode("descriptor", null);
                }
                {
                    this.PropName_assembly = $.$stj.System.Text.Json.JsonEncodedText.Encode("assembly", null);
                }
                {
                    this.PropName_typeName = $.$stj.System.Text.Json.JsonEncodedText.Encode("typeName", null);
                }
                {
                    this.PropName_parameterDefinitions = $.$stj.System.Text.Json.JsonEncodedText.Encode("parameterDefinitions", null);
                }
                {
                    this.PropName_parameterValues = $.$stj.System.Text.Json.JsonEncodedText.Encode("parameterValues", null);
                }
                {
                    this.PropName_locationHash = $.$stj.System.Text.Json.JsonEncodedText.Encode("locationHash", null);
                }
                {
                    this.PropName_formattedComponentKey = $.$stj.System.Text.Json.JsonEncodedText.Encode("formattedComponentKey", null);
                }
                {
                    this.PropName_name = $.$stj.System.Text.Json.JsonEncodedText.Encode("name", null);
                }
                {
                    this.PropName_ssrComponentId = $.$stj.System.Text.Json.JsonEncodedText.Encode("ssrComponentId", null);
                }
                {
                    this.PropName_marker = $.$stj.System.Text.Json.JsonEncodedText.Encode("marker", null);
                }
                {
                    this.PropName_batchId = $.$stj.System.Text.Json.JsonEncodedText.Encode("batchId", null);
                }
                {
                    this.PropName_operations = $.$stj.System.Text.Json.JsonEncodedText.Encode("operations", null);
                }
                {
                    this.PropName_componentType = $.$stj.System.Text.Json.JsonEncodedText.Encode("componentType", null);
                }
                {
                    this.PropName_parameters = $.$stj.System.Text.Json.JsonEncodedText.Encode("parameters", null);
                }
            }
            static $h = 2686988;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14784173,"p":[{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)).$h,"g":{"r":0,"d":0,"h":21477523468,"f":1},"n":"IListObject","d":2686988,"h":17182556172,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":38657392652,"f":1},"n":"Int32","d":2686988,"h":34362425356,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":55837261836,"f":1},"n":"Int64","d":2686988,"h":51542294540,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,"g":{"r":0,"d":0,"h":73017131020,"f":1},"n":"ComponentParameter","d":2686988,"h":68722163724,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,"g":{"r":0,"d":0,"h":98786934796,"f":1},"n":"ComponentParameterArray","d":2686988,"h":94491967500,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":120261771276,"f":1},"n":"Object","d":2686988,"h":115966803980,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,"g":{"r":0,"d":0,"h":137441640460,"f":1},"n":"JsonElement","d":2686988,"h":133146673164,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,"g":{"r":0,"d":0,"h":154621509644,"f":1},"n":"NullableComponentMarker","d":2686988,"h":150326542348,"f":1},{"p":2686988,"g":{"r":0,"d":0,"h":180391313420,"f":33},"n":"Default","d":2686988,"h":176096346124,"f":33},{"p":3380909,"g":{"r":0,"d":0,"h":193276215308,"f":32772},"n":"GeneratedSerializerOptions","d":2686988,"h":188981248012,"f":32772},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,"g":{"r":0,"d":0,"h":304945365004,"f":1},"n":"NullableComponentMarkerKey","d":2686988,"h":300650397708,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,"g":{"r":0,"d":0,"h":322125234188,"f":1},"n":"RootComponentOperationArray","d":2686988,"h":317830266892,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Type).$h,"g":{"r":0,"d":0,"h":343600070668,"f":1},"n":"Type","d":2686988,"h":339305103372,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$spc.System.Int32)).$h,"g":{"r":0,"d":0,"h":360779939852,"f":1},"n":"NullableInt32","d":2686988,"h":356484972556,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,"g":{"r":0,"d":0,"h":377959809036,"f":1},"n":"ParameterView","d":2686988,"h":373664841740,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,"g":{"r":0,"d":0,"h":403729612812,"f":1},"n":"WebRootComponentParameters","d":2686988,"h":399434645516,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,"g":{"r":0,"d":0,"h":429499416588,"f":1},"n":"WebRootComponentDescriptor","d":2686988,"h":425204449292,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,"g":{"r":0,"d":0,"h":459564187660,"f":1},"n":"RootComponentOperationBatch","d":2686988,"h":455269220364,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,"g":{"r":0,"d":0,"h":489628958732,"f":1},"n":"RootComponentOperationType","d":2686988,"h":485333991436,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":506808827916,"f":1},"n":"String","d":2686988,"h":502513860620,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,"g":{"r":0,"d":0,"h":523988697100,"f":1},"n":"ComponentMarker","d":2686988,"h":519693729804,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,"g":{"r":0,"d":0,"h":549758500876,"f":1},"n":"RootComponentOperation","d":2686988,"h":545463533580,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,"g":{"r":0,"d":0,"h":575528304652,"f":1},"n":"ComponentMarkerKey","d":2686988,"h":571233337356,"f":1}],"m":[{"r":16815789,"p":[{"n":"type","p":142606337}],"n":"GetTypeInfo","d":2686988,"h":4297654284,"f":32769},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_IListObject","d":2686988,"h":25772490764,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int32).$h,"p":[{"n":"options","p":3380909}],"n":"Create_Int32","d":2686988,"h":42952359948,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int64).$h,"p":[{"n":"options","p":3380909}],"n":"Create_Int64","d":2686988,"h":60132229132,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ComponentParameter","d":2686988,"h":77312098316,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"ComponentParameterPropInit","d":2686988,"h":81607065612,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":262156}],"n":"ComponentParameterSerializeHandler","d":2686988,"h":85902032908,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ComponentParameterArray","d":2686988,"h":103081902092,"f":2},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":0}],"n":"ComponentParameterArraySerializeHandler","d":2686988,"h":107376869388,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Object).$h,"p":[{"n":"options","p":3380909}],"n":"Create_Object","d":2686988,"h":124556738572,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,"p":[{"n":"options","p":3380909}],"n":"Create_JsonElement","d":2686988,"h":141736607756,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_NullableComponentMarker","d":2686988,"h":158916476940,"f":2},{"r":262145,"p":[{"n":"options","p":3380909},{"n":"jsonTypeInfo","p":(TJsonMetadataType) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TJsonMetadataType).$h,"f":2}],"g":["TJsonMetadataType"],"n":"TryGetTypeInfoForRuntimeCustomConverter","d":2686988,"h":206161117196,"f":131106},{"r":13145773,"p":[{"n":"type","p":142606337},{"n":"options","p":3380909}],"n":"GetRuntimeConverterForType","d":2686988,"h":210456084492,"f":34},{"r":13145773,"p":[{"n":"type","p":142606337},{"n":"converter","p":13145773},{"n":"options","p":3380909},{"n":"validateCanConvert","p":262145,"f":65,"v":true}],"n":"ExpandConverter","d":2686988,"h":214751051788,"f":34},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_NullableComponentMarkerKey","d":2686988,"h":309240332300,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_RootComponentOperationArray","d":2686988,"h":326420201484,"f":2},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":0}],"n":"RootComponentOperationArraySerializeHandler","d":2686988,"h":330715168780,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Type).$h,"p":[{"n":"options","p":3380909}],"n":"Create_Type","d":2686988,"h":347895037964,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$spc.System.Int32)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_NullableInt32","d":2686988,"h":365074907148,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ParameterView","d":2686988,"h":382254776332,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"ParameterViewPropInit","d":2686988,"h":386549743628,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":5767176}],"n":"ParameterViewSerializeHandler","d":2686988,"h":390844710924,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,"p":[{"n":"options","p":3380909}],"n":"Create_WebRootComponentParameters","d":2686988,"h":408024580108,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"WebRootComponentParametersPropInit","d":2686988,"h":412319547404,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":4390924}],"n":"WebRootComponentParametersSerializeHandler","d":2686988,"h":416614514700,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,"p":[{"n":"options","p":3380909}],"n":"Create_WebRootComponentDescriptor","d":2686988,"h":433794383884,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"WebRootComponentDescriptorPropInit","d":2686988,"h":438089351180,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":4325388}],"n":"WebRootComponentDescriptorSerializeHandler","d":2686988,"h":442384318476,"f":2},{"r":0,"n":"WebRootComponentDescriptorCtorParamInit","d":2686988,"h":446679285772,"f":34},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,"p":[{"n":"options","p":3380909}],"n":"Create_RootComponentOperationBatch","d":2686988,"h":463859154956,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"RootComponentOperationBatchPropInit","d":2686988,"h":468154122252,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":1048588}],"n":"RootComponentOperationBatchSerializeHandler","d":2686988,"h":472449089548,"f":2},{"r":0,"n":"RootComponentOperationBatchCtorParamInit","d":2686988,"h":476744056844,"f":34},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,"p":[{"n":"options","p":3380909}],"n":"Create_RootComponentOperationType","d":2686988,"h":493923926028,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"p":[{"n":"options","p":3380909}],"n":"Create_String","d":2686988,"h":511103795212,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ComponentMarker","d":2686988,"h":528283664396,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"ComponentMarkerPropInit","d":2686988,"h":532578631692,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":131084}],"n":"ComponentMarkerSerializeHandler","d":2686988,"h":536873598988,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,"p":[{"n":"options","p":3380909}],"n":"Create_RootComponentOperation","d":2686988,"h":554053468172,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"RootComponentOperationPropInit","d":2686988,"h":558348435468,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":983052}],"n":"RootComponentOperationSerializeHandler","d":2686988,"h":562643402764,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ComponentMarkerKey","d":2686988,"h":579823271948,"f":2},{"r":0,"p":[{"n":"options","p":3380909}],"n":"ComponentMarkerKeyPropInit","d":2686988,"h":584118239244,"f":34},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":196620}],"n":"ComponentMarkerKeySerializeHandler","d":2686988,"h":588413206540,"f":2}],"l":[{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.IList$$($.$spc.System.Object)).$h,"n":"_IListObject","d":2686988,"h":12887588876,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int32).$h,"n":"_Int32","d":2686988,"h":30067458060,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Int64).$h,"n":"_Int64","d":2686988,"h":47247327244,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter).$h,"n":"_ComponentParameter","d":2686988,"h":64427196428,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.ComponentParameter)).$h,"n":"_ComponentParameterArray","d":2686988,"h":90197000204,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Object).$h,"n":"_Object","d":2686988,"h":111671836684,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$stj.System.Text.Json.JsonElement).$h,"n":"_JsonElement","d":2686988,"h":128851705868,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker)).$h,"n":"_NullableComponentMarker","d":2686988,"h":146031575052,"f":2},{"t":3380909,"n":"s_defaultOptions","d":2686988,"h":163211444236,"f":34},{"t":75497473,"n":"InstanceMemberBindingFlags","d":2686988,"h":167506411532,"f":34},{"t":2332333,"n":"PropName_type","d":2686988,"h":219046019084,"f":34},{"t":2332333,"n":"PropName_prerenderId","d":2686988,"h":223340986380,"f":34},{"t":2332333,"n":"PropName_key","d":2686988,"h":227635953676,"f":34},{"t":2332333,"n":"PropName_sequence","d":2686988,"h":231930920972,"f":34},{"t":2332333,"n":"PropName_descriptor","d":2686988,"h":236225888268,"f":34},{"t":2332333,"n":"PropName_assembly","d":2686988,"h":240520855564,"f":34},{"t":2332333,"n":"PropName_typeName","d":2686988,"h":244815822860,"f":34},{"t":2332333,"n":"PropName_parameterDefinitions","d":2686988,"h":249110790156,"f":34},{"t":2332333,"n":"PropName_parameterValues","d":2686988,"h":253405757452,"f":34},{"t":2332333,"n":"PropName_locationHash","d":2686988,"h":257700724748,"f":34},{"t":2332333,"n":"PropName_formattedComponentKey","d":2686988,"h":261995692044,"f":34},{"t":2332333,"n":"PropName_name","d":2686988,"h":266290659340,"f":34},{"t":2332333,"n":"PropName_ssrComponentId","d":2686988,"h":270585626636,"f":34},{"t":2332333,"n":"PropName_marker","d":2686988,"h":274880593932,"f":34},{"t":2332333,"n":"PropName_batchId","d":2686988,"h":279175561228,"f":34},{"t":2332333,"n":"PropName_operations","d":2686988,"h":283470528524,"f":34},{"t":2332333,"n":"PropName_componentType","d":2686988,"h":287765495820,"f":34},{"t":2332333,"n":"PropName_parameters","d":2686988,"h":292060463116,"f":34},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey)).$h,"n":"_NullableComponentMarkerKey","d":2686988,"h":296355430412,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation)).$h,"n":"_RootComponentOperationArray","d":2686988,"h":313535299596,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Type).$h,"n":"_Type","d":2686988,"h":335010136076,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Nullable$$($.$spc.System.Int32)).$h,"n":"_NullableInt32","d":2686988,"h":352190005260,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$mac.Microsoft.AspNetCore.Components.ParameterView).$h,"n":"_ParameterView","d":2686988,"h":369369874444,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters).$h,"n":"_WebRootComponentParameters","d":2686988,"h":395139678220,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor).$h,"n":"_WebRootComponentDescriptor","d":2686988,"h":420909481996,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch).$h,"n":"_RootComponentOperationBatch","d":2686988,"h":450974253068,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,"n":"_RootComponentOperationType","d":2686988,"h":481039024140,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"n":"_String","d":2686988,"h":498218893324,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).$h,"n":"_ComponentMarker","d":2686988,"h":515398762508,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperation).$h,"n":"_RootComponentOperation","d":2686988,"h":541168566284,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h,"n":"_ComponentMarkerKey","d":2686988,"h":566938370060,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2686988,"h":197571182604,"f":1},{"p":[{"n":"options","p":3380909}],"n":".ctor","o":"$ctor$3","d":2686988,"h":201866149900,"f":1}],"i":[15898285,15963821],"h":2686988,"a":[{"t":14915245,"c":4309882541,"n":[{"n":"PropertyNamingPolicy","v":1,"t":13866669},{"n":"PropertyNameCaseInsensitive","v":true,"t":262145},{"n":"DefaultIgnoreCondition","v":3,"t":13735597}]},{"t":14718637,"c":4309685933,"a":[{"v":0,"t":142606337}]},{"t":14718637,"c":4309685933,"a":[{"v":2135725,"t":142606337}]},{"t":14718637,"c":4309685933,"a":[{"v":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$h,"t":142606337}]},{"t":14718637,"c":4309685933,"a":[{"v":1048588,"t":142606337}]},{"t":23527425,"c":12908429313,"a":[{"v":"System.Text.Json.SourceGeneration","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonSerializerContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IBuiltInJsonTypeInfoResolver, $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `WebAssemblyJsonSerializerContext`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext", ($self) => class PrerenderComponentApplicationStoreSerializerContext extends $.$stj.System.Text.Json.Serialization.JsonSerializerContext
        {
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>?*/ _ByteArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ get ByteArray()
            {
                return this._ByteArray ??= $.$cast(this.Options.GetTypeInfo($.$typeArray($.$spc.System.Byte).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$spc.System.Byte)));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]> */ Create_ByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<byte[]>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$typeArray($.$spc.System.Byte), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$spc.System.Byte)))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$typeArray($.$spc.System.Byte), options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.ByteArrayConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>?*/ _String = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ get String()
            {
                return this._String ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.String.$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string> */ Create_String(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<string>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.String, options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String))))
                {
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo($.$spc.System.String, options, $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.StringConverter);
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>?*/ _DictionaryStringByteArray = null;
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ get DictionaryStringByteArray()
            {
                return this._DictionaryStringByteArray ??= $.$cast(this.Options.GetTypeInfo($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$type), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))));
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>> */ Create_DictionaryStringByteArray(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<global::System.Collections.Generic.Dictionary<string, byte[]>>*/ let jsonTypeInfo;
                if (!$.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.TryGetTypeInfoForRuntimeCustomConverter($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)), options, $.$ref(() => jsonTypeInfo, ($v) => jsonTypeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))))))
                {
                    /*var*/ let info = (() =>
                    {
                        //new $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)))()
                        const $t2 = $.$stj.System.Text.Json.Serialization.Metadata.JsonCollectionInfoValues$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)));
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.ObjectCreator = new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))))().$ctor(this,  () =>
                        {
                            return new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)))().$ctor$1();
                        }, {"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h,"n":"","d":786444,"h":0,"f":1048578});
                        $i2.SerializeHandler = new ($.$spc.System.Action$$$($.$stj.System.Text.Json.Utf8JsonWriter, $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))))().$ctor(this, this.DictionaryStringByteArraySerializeHandler);
                        return $i2;
                    })();
                    jsonTypeInfo = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateDictionaryInfo($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)), $.$spc.System.String, $.$typeArray($.$spc.System.Byte), options, info);
                    jsonTypeInfo.NumberHandling = null;
                }
                jsonTypeInfo.OriginatingResolver = this;
                return jsonTypeInfo;
            }
            /*void */ DictionaryStringByteArraySerializeHandler(/*global::System.Text.Json.Utf8JsonWriter*/ writer, /*global::System.Collections.Generic.Dictionary<string, byte[]>?*/ value)
            {
                if (value === null)
                {
                    writer.WriteNullValue();
                    return;
                }
                writer.WriteStartObject();
                var $en2 = value.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entry = $en2.Current;
                    {
                        writer.WriteBase64String$1(entry.Key, $.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(entry.Value));
                    }
                }
                writer.WriteEndObject();
            }
            /*global::System.Text.Json.JsonSerializerOptions*/ static s_defaultOptions = null;
            /*global::System.Reflection.BindingFlags*/ static InstanceMemberBindingFlags = 52;
            /*global::Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext*/ static Default = null;
            /*global::System.Text.Json.JsonSerializerOptions?*/ GeneratedSerializerOptions = null;
            $ctor$2()
            {
                super.$ctor$1(null);
                {
                }
                return this;
            }
            $ctor$3(/*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                super.$ctor$1(options);
                {
                }
                return this;
            }
            static /*bool */ TryGetTypeInfoForRuntimeCustomConverter(TJsonMetadataType, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*out global::System.Text.Json.Serialization.Metadata.JsonTypeInfo<TJsonMetadataType>*/ jsonTypeInfo)
            {
                /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.GetRuntimeConverterForType(TJsonMetadataType.$type, options);
                if (converter !== null)
                {
                    jsonTypeInfo.$v = $.$stj.System.Text.Json.Serialization.Metadata.JsonMetadataServices.CreateValueInfo(TJsonMetadataType, options, converter);
                    return true;
                }
                jsonTypeInfo.$v = null;
                return false;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter? */ GetRuntimeConverterForType(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                for(/*int*/ let i = 0; i < options.Converters.System$Collections$Generic$ICollection$$$Count; i++)
                {
                    /*global::System.Text.Json.Serialization.JsonConverter?*/ let converter = options.Converters.System$Collections$Generic$IList$$$get_Item(i, [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                    if ((converter?.CanConvert(type) ?? null) === true)
                    {
                        return $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.ExpandConverter(type, converter, options, false);
                    }
                }
                return null;
            }
            static /*global::System.Text.Json.Serialization.JsonConverter */ ExpandConverter(/*global::System.Type*/ type, /*global::System.Text.Json.Serialization.JsonConverter*/ converter, /*global::System.Text.Json.JsonSerializerOptions*/ options, /*bool*/ validateCanConvert)
            {
                if (validateCanConvert && !converter.CanConvert(type))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spc.System.String.Format$1("The converter '{0}' is not compatible with the type '{1}'.", $.$spc.System.Object.GetType.call(converter), type));
                }
                let factory;
                if ($.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory, { set $v(v){ factory = v; } }))
                {
                    converter = factory.CreateConverter(type, options);
                    if (converter === null || $.$is(converter, $.$stj.System.Text.Json.Serialization.JsonConverterFactory))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spc.System.String.Format("The converter '{0}' cannot return null or a JsonConverterFactory instance.", $.$spc.System.Object.GetType.call(factory)));
                    }
                }
                return converter;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ GetTypeInfo(/*global::System.Type*/ type)
            {
                /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo?*/ let typeInfo;
                this.Options.TryGetTypeInfo(type, $.$ref(() => typeInfo, ($v) => typeInfo = $v, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo));
                return typeInfo;
            }
            /*global::System.Text.Json.Serialization.Metadata.JsonTypeInfo? */ System$Text$Json$Serialization$Metadata$IJsonTypeInfoResolver$GetTypeInfo(/*global::System.Type*/ type, /*global::System.Text.Json.JsonSerializerOptions*/ options)
            {
                if ($.$spc.System.Type.op_Equality$1(type, $.$typeArray($.$spc.System.Byte).$type))
                {
                    return this.Create_ByteArray(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$type))
                {
                    return this.Create_DictionaryStringByteArray(options);
                }
                if ($.$spc.System.Type.op_Equality$1(type, $.$spc.System.String.$type))
                {
                    return this.Create_String(options);
                }
                return null;
            }
            //default member initializer
            constructor()
            {
                super();
                this.GeneratedSerializerOptions = $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultOptions = new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$1();
                }
                {
                    this.Default = new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext().$ctor$3(new $.$stj.System.Text.Json.JsonSerializerOptions().$ctor$2($.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStoreSerializerContext.s_defaultOptions));
                }
            }
            static $h = 786444;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14784173,"p":[{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$spc.System.Byte)).$h,"g":{"r":0,"d":0,"h":12885688332,"f":1},"n":"ByteArray","d":786444,"h":8590721036,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":30065557516,"f":1},"n":"String","d":786444,"h":25770590220,"f":1},{"p":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))).$h,"g":{"r":0,"d":0,"h":47245426700,"f":1},"n":"DictionaryStringByteArray","d":786444,"h":42950459404,"f":1},{"p":786444,"g":{"r":0,"d":0,"h":77310197772,"f":33},"n":"Default","d":786444,"h":73015230476,"f":33},{"p":3380909,"g":{"r":0,"d":0,"h":90195099660,"f":32772},"n":"GeneratedSerializerOptions","d":786444,"h":85900132364,"f":32772}],"m":[{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$spc.System.Byte)).$h,"p":[{"n":"options","p":3380909}],"n":"Create_ByteArray","d":786444,"h":17180655628,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"p":[{"n":"options","p":3380909}],"n":"Create_String","d":786444,"h":34360524812,"f":2},{"r":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))).$h,"p":[{"n":"options","p":3380909}],"n":"Create_DictionaryStringByteArray","d":786444,"h":51540393996,"f":2},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h}],"n":"DictionaryStringByteArraySerializeHandler","d":786444,"h":55835361292,"f":2},{"r":262145,"p":[{"n":"options","p":3380909},{"n":"jsonTypeInfo","p":(TJsonMetadataType) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TJsonMetadataType).$h,"f":2}],"g":["TJsonMetadataType"],"n":"TryGetTypeInfoForRuntimeCustomConverter","d":786444,"h":103080001548,"f":131106},{"r":13145773,"p":[{"n":"type","p":142606337},{"n":"options","p":3380909}],"n":"GetRuntimeConverterForType","d":786444,"h":107374968844,"f":34},{"r":13145773,"p":[{"n":"type","p":142606337},{"n":"converter","p":13145773},{"n":"options","p":3380909},{"n":"validateCanConvert","p":262145,"f":65,"v":true}],"n":"ExpandConverter","d":786444,"h":111669936140,"f":34},{"r":16815789,"p":[{"n":"type","p":142606337}],"n":"GetTypeInfo","d":786444,"h":115964903436,"f":32769}],"l":[{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$typeArray($.$spc.System.Byte)).$h,"n":"_ByteArray","d":786444,"h":4295753740,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.String).$h,"n":"_String","d":786444,"h":21475622924,"f":2},{"t":$.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte))).$h,"n":"_DictionaryStringByteArray","d":786444,"h":38655492108,"f":2},{"t":3380909,"n":"s_defaultOptions","d":786444,"h":60130328588,"f":34},{"t":75497473,"n":"InstanceMemberBindingFlags","d":786444,"h":64425295884,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":786444,"h":94490066956,"f":1},{"p":[{"n":"options","p":3380909}],"n":".ctor","o":"$ctor$3","d":786444,"h":98785034252,"f":1}],"i":[15898285,15963821],"h":786444,"a":[{"t":14718637,"c":4309685933,"a":[{"v":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$typeArray($.$spc.System.Byte)).$h,"t":142606337}],"n":[{"n":"GenerationMode","v":2,"t":14849709}]},{"t":23527425,"c":12908429313,"a":[{"v":"System.Text.Json.SourceGeneration","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonSerializerContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$stj.System.Text.Json.Serialization.Metadata.IBuiltInJsonTypeInfoResolver, $.$stj.System.Text.Json.Serialization.Metadata.IJsonTypeInfoResolver ]; }
            static get $fullName() { return `PrerenderComponentApplicationStoreSerializerContext`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer", ($self) => class WebAssemblyRenderer extends $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer
        {
            /*WebRootComponentManager?*/ _webRootComponentManager = null;
            /*WebRootComponentManager */ GetOrCreateWebRootComponentManager()
            {
                return this._webRootComponentManager ??= new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager().$ctor$1(this);
            }
            static $_WebRootComponentManager;
            static get WebRootComponentManager()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer;
                return $cls.$_WebRootComponentManager ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager", ($self) => class WebRootComponentManager extends $.$spc.System.Object
                {
                    /*Dictionary<int, WebRootComponent>*/ _webRootComponents = null;
                    /*Task*/ _currentUpdateTask = null;
                    /*Task *//*async*/  AddRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ componentType, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ parameters)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                        {
                            if (this._webRootComponents.ContainsKey(ssrComponentId))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10(`A root component with SSR component ID ${ssrComponentId} already exists.`);
                            }
                            /*var*/ let component = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent.Create(this.renderer, componentType, ssrComponentId, key?.Clone() ?? null, parameters);
                            this._webRootComponents.Add(ssrComponentId, component);
                            await this._currentUpdateTask;
                            await component.RenderAsync(this.renderer);
                        });
                    }
                    /*Task */ UpdateRootComponentAsync(/*int*/ ssrComponentId, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters)
                    {
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        return component.UpdateAsync(this.renderer, newComponentType, newKey?.Clone() ?? null, newParameters, this._currentUpdateTask);
                    }
                    /*void */ RemoveRootComponent(/*int*/ ssrComponentId)
                    {
                        /*var*/ let component = this.GetRequiredWebRootComponent(ssrComponentId);
                        component.Remove(this.renderer);
                        this._webRootComponents.Remove(ssrComponentId);
                    }
                    /*WebRootComponent */ GetRequiredWebRootComponent(/*int*/ ssrComponentId)
                    {
                        /*var*/ let component;
                        if (!this._webRootComponents.TryGetValue(ssrComponentId, $.$ref(() => component, ($v) => component = $v, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent)))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10(`No root component exists with SSR component ID ${ssrComponentId}.`);
                        }
                        return component;
                    }
                    /*ComponentMarkerKey */ GetRootComponentKey(/*int*/ componentId)
                    {
                        var $en4 = this._webRootComponents.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            let [ _0, candidate ] = $.$destructure($en4.Current);
                            {
                                /*var*/ let  [ id, key, _1, _2 ] = $.$destructure(candidate);
                                if (id === componentId)
                                {
                                    return key;
                                }
                            }
                        }
                        return new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey();
                    }
                    /*void */ SetCurrentUpdateTask(/*Task*/ postStateTask)
                    {
                        this._currentUpdateTask = postStateTask;
                    }
                    static $_WebRootComponent;
                    static get WebRootComponent()
                    {
                        let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager;
                        return $cls.$_WebRootComponent ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent", ($self) => class WebRootComponent extends $.$spc.System.Object
                        {
                            /*Type*/ _componentType = null;
                            /*string*/ _ssrComponentIdString = null;
                            /*ComponentMarkerKey*/ _key;
                            /*WebRootComponentParameters*/ _latestParameters;
                            /*int*/ _interactiveComponentId = 0;
                            static /*WebRootComponent */ Create(/*Renderer*/ renderer, /*Type*/ componentType, /*int*/ ssrComponentId, /*ComponentMarkerKey?*/ key, /*WebRootComponentParameters*/ initialParameters)
                            {
                                if (!$.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).HasValue$get.call(key))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10("An invalid component marker key was provided.");
                                }
                                /*var*/ let ssrComponentIdString = $.$spc.System.Int32.ToString$2.call(ssrComponentId, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
                                /*var*/ let interactiveComponentId = renderer.AddRootComponent(componentType, ssrComponentIdString);
                                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent().$ctor$1(componentType, ssrComponentIdString, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(key), interactiveComponentId, $.$ref(() => initialParameters, ));
                            }
                            $ctor$1(/*Type*/ componentType, /*string*/ ssrComponentIdString, /*ComponentMarkerKey*/ key, /*int*/ interactiveComponentId, /*in WebRootComponentParameters*/ initialParameters)
                            {
                                super.$ctor();
                                {
                                    this._componentType = componentType;
                                    this._ssrComponentIdString = ssrComponentIdString;
                                    this._key = key.Clone();
                                    this._interactiveComponentId = interactiveComponentId;
                                    this._latestParameters = initialParameters.$v;
                                }
                                return this;
                            }
                            /*void */ Deconstruct(/*out int*/ interactiveComponentId, /*out ComponentMarkerKey*/ key, /*out Type*/ componentType, /*out ParameterView*/ parameters)
                            {
                                interactiveComponentId.$v = this._interactiveComponentId;
                                key.$v = this._key.Clone();
                                componentType.$v = this._componentType;
                                parameters.$v = this._latestParameters.Parameters;
                            }
                            /*Task */ UpdateAsync(/*Renderer*/ renderer, /*Type*/ newComponentType, /*ComponentMarkerKey?*/ newKey, /*WebRootComponentParameters*/ newParameters, /*Task*/ currentUpdateTask)
                            {
                                if ($.$spc.System.Type.op_Inequality$1(this._componentType, newComponentType))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Cannot update components with mismatching types.");
                                }
                                if (!$.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).HasValue$get.call(newKey))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10("An invalid component marker key was provided.");
                                }
                                if (!$.$spc.System.String.Equals$5(this._key.LocationHash, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(newKey).LocationHash, 4/*StringComparison.Ordinal*/) || !$.$spc.System.String.Equals$5(this._key.FormattedComponentKey, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).Value$get.call(newKey).FormattedComponentKey, 4/*StringComparison.Ordinal*/))
                                {
                                    throw new $.$spc.System.InvalidOperationException().$ctor$10("Cannot update components with mismatching keys.");
                                }
                                if (!$.$spc.System.String.IsNullOrEmpty(this._key.FormattedComponentKey))
                                {
                                    this._latestParameters = newParameters;
                                    return this.RenderAsync$1(renderer, currentUpdateTask);
                                }
                                else 
                                {
                                    if (this._latestParameters.DefinitelyEquals($.$ref(() => newParameters, )))
                                    {
                                        return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                                    }
                                    else 
                                    {
                                        renderer.RemoveRootComponent(this._interactiveComponentId);
                                        this._interactiveComponentId = renderer.AddRootComponent(this._componentType, this._ssrComponentIdString);
                                        this._latestParameters = newParameters;
                                        return this.RenderAsync$1(renderer, currentUpdateTask);
                                    }
                                }
                            }
                            /*Task */ RenderAsync(/*Renderer*/ renderer)
                            {
                                return renderer.RenderRootComponentAsync$1(this._interactiveComponentId, this._latestParameters.Parameters);
                            }
                            /*Task *//*async*/  RenderAsync$1(/*Renderer*/ renderer, /*Task*/ updateTask)
                            {
                                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                                {
                                    await updateTask;
                                    await renderer.RenderRootComponentAsync$1(this._interactiveComponentId, this._latestParameters.Parameters);
                                });
                            }
                            /*void */ Remove(/*Renderer*/ renderer)
                            {
                                renderer.RemoveRootComponent(this._interactiveComponentId);
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._key = $.$default($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey);
                                this._latestParameters = $.$default($.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters);
                            }
                            static $h = 3145740;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3145740,"p":[{"n":"renderer","p":2949132},{"n":"componentType","p":142606337},{"n":"ssrComponentId","p":655361},{"n":"key","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h},{"n":"initialParameters","p":4390924}],"n":"Create","d":3145740,"h":25772949516,"f":33},{"r":65537,"p":[{"n":"interactiveComponentId","p":655361,"f":2},{"n":"key","p":196620,"f":2},{"n":"componentType","p":142606337,"f":2},{"n":"parameters","p":5767176,"f":2}],"n":"Deconstruct","d":3145740,"h":34362884108,"f":1},{"r":133300225,"p":[{"n":"renderer","p":2949132},{"n":"newComponentType","p":142606337},{"n":"newKey","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h},{"n":"newParameters","p":4390924},{"n":"currentUpdateTask","p":133300225}],"n":"UpdateAsync","d":3145740,"h":38657851404,"f":1},{"r":133300225,"p":[{"n":"renderer","p":2949132}],"n":"RenderAsync","d":3145740,"h":42952818700,"f":1},{"r":133300225,"p":[{"n":"renderer","p":2949132},{"n":"updateTask","p":133300225}],"n":"RenderAsync","o":"@$1","d":3145740,"h":47247785996,"f":4097},{"r":65537,"p":[{"n":"renderer","p":2949132}],"n":"Remove","d":3145740,"h":51542753292,"f":1}],"l":[{"t":142606337,"n":"_componentType","d":3145740,"h":4298113036,"f":2},{"t":1310721,"n":"_ssrComponentIdString","d":3145740,"h":8593080332,"f":2},{"t":196620,"n":"_key","d":3145740,"h":12888047628,"f":2},{"t":4390924,"n":"_latestParameters","d":3145740,"h":17183014924,"f":2},{"t":655361,"n":"_interactiveComponentId","d":3145740,"h":21477982220,"f":2}],"c":[{"p":[{"n":"componentType","p":142606337},{"n":"ssrComponentIdString","p":1310721},{"n":"key","p":196620},{"n":"interactiveComponentId","p":655361},{"n":"initialParameters","p":4390924,"f":8}],"n":".ctor","o":"$ctor$1","d":3145740,"h":30067916812,"f":2}],"d":3080204,"h":3145740}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `WebAssemblyRenderer.WebRootComponentManager.WebRootComponent`; }
                        }, $cls, ($v) => $cls.$_WebRootComponent = $v);
                    }
                    //Begin primary constructor
                    /*Renderer*/ renderer = null;
                    $ctor$1(/*Renderer*/$renderer)
                    {
                        this.renderer = $renderer;
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._webRootComponents = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Int32, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent))().$ctor$1();
                        this._currentUpdateTask = $.$spc.System.Threading.Tasks.Task.CompletedTask;
                    }
                    static $h = 3080204;
                    static $f = 0b10000000010010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133300225,"p":[{"n":"ssrComponentId","p":655361},{"n":"componentType","p":142606337},{"n":"key","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h},{"n":"parameters","p":4390924}],"n":"AddRootComponentAsync","d":3080204,"h":21477916684,"f":4097},{"r":133300225,"p":[{"n":"ssrComponentId","p":655361},{"n":"newComponentType","p":142606337},{"n":"newKey","p":$.$typeNullable($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey).$h},{"n":"newParameters","p":4390924}],"n":"UpdateRootComponentAsync","d":3080204,"h":25772883980,"f":1},{"r":65537,"p":[{"n":"ssrComponentId","p":655361}],"n":"RemoveRootComponent","d":3080204,"h":30067851276,"f":1},{"r":3145740,"p":[{"n":"ssrComponentId","p":655361}],"n":"GetRequiredWebRootComponent","d":3080204,"h":34362818572,"f":2},{"r":196620,"p":[{"n":"componentId","p":655361}],"n":"GetRootComponentKey","d":3080204,"h":38657785868,"f":8},{"r":65537,"p":[{"n":"postStateTask","p":133300225}],"n":"SetCurrentUpdateTask","d":3080204,"h":42952753164,"f":8}],"l":[{"t":2949132,"n":"\u003Crenderer\u003EP","d":3080204,"h":8593014796,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Int32, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.WebRootComponentManager.WebRootComponent).$h,"n":"_webRootComponents","d":3080204,"h":12887982092,"f":2},{"t":133300225,"n":"_currentUpdateTask","d":3080204,"h":17182949388,"f":2}],"c":[{"p":[{"n":"renderer","p":2949132}],"n":".ctor","o":"$ctor$1","d":3080204,"h":4298047500,"f":1}],"j":[3145740],"d":2949132,"h":3080204}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `WebAssemblyRenderer.WebRootComponentManager`; }
                }, $cls, ($v) => $cls.$_WebRootComponentManager = $v);
            }
            static $_Log;
            static get Log()
            {
                let $cls = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer;
                return $cls.$_Log ??= $asm.$ncls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log", ($self) => class Log
                {
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.Exception?>*/ static __UnhandledExceptionRenderingComponentCallback = null;
                    static /*void */ UnhandledExceptionRenderingComponent(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ message, /*global::System.Exception*/ exception)
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/))
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.__UnhandledExceptionRenderingComponentCallback.Invoke(logger, message, exception);
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.__UnhandledExceptionRenderingComponentCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$3($.$spc.System.String, 5/*global::Microsoft.Extensions.Logging.LogLevel.Critical*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(100, "ExceptionRenderingComponent"), "Unhandled exception rendering component: {Message}", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                        }
                    }
                    static $h = 3014668;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"exception","p":47251457}],"n":"UnhandledExceptionRenderingComponent","d":3014668,"h":8592949260,"f":33,"a":[{"t":2228245,"c":8592162837,"a":[{"v":100,"t":655361},{"v":5,"t":2293781},{"v":"Unhandled exception rendering component: {Message}","t":1310721}],"n":[{"n":"EventName","v":"ExceptionRenderingComponent","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"l":[{"t":$.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.String, $.$spc.System.Exception).$h,"n":"__UnhandledExceptionRenderingComponentCallback","d":3014668,"h":4297981964,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"d":2949132,"h":3014668}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            /*ILogger*/ _logger = null;
            /*Dispatcher*/ _dispatcher = null;
            /*ResourceAssetCollection*/ _resourceCollection = null;
            /*IInternalJSImportMethods*/ _jsMethods = null;
            /*ComponentStatePersistenceManager*/ _componentStatePersistenceManager = null;
            /*RendererInfo*/ static _componentPlatform = null;
            $ctor$4(/*IServiceProvider*/ serviceProvider, /*ResourceAssetCollection*/ resourceCollection, /*ILoggerFactory*/ loggerFactory, /*JSComponentInterop*/ jsComponentInterop)
            {
                super.$ctor$3(serviceProvider, loggerFactory, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.ReadJsonSerializerOptions(), jsComponentInterop);
                {
                    this._logger = $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, loggerFactory);
                    this._jsMethods = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.IInternalJSImportMethods, serviceProvider);
                    this._componentStatePersistenceManager = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mac.Microsoft.AspNetCore.Components.Infrastructure.ComponentStatePersistenceManager, serviceProvider);
                    this._dispatcher = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher._mainSynchronizationContext === null ? $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.NullDispatcher.Instance : new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyDispatcher().$ctor$2();
                    this._resourceCollection = resourceCollection;
                    this.ElementReferenceContext = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.ElementReferenceContext;
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.add_OnUpdateRootComponents(new ($.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$spc.System.String))().$ctor(this, this.OnUpdateRootComponents));
                }
                return this;
            }
            /*void */ OnUpdateRootComponents(/*RootComponentOperationBatch*/ batch, /*string*/ appState)
            {
                /*var*/ let webRootComponentManager = this.GetOrCreateWebRootComponentManager();
                /*TaskCompletionSource?*/ let taskCompletionSource = null;
                /*var*/ let stateUpdateTask = $.$spc.System.Threading.Tasks.Task.CompletedTask;
                /*var*/ let store = !$.$spc.System.String.IsNullOrEmpty(appState) ? new $.$macwa.Microsoft.AspNetCore.Components.PrerenderComponentApplicationStore().$ctor$2(appState) : null;
                if (store !== null)
                {
                    taskCompletionSource = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    stateUpdateTask = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.EnqueueRestore(taskCompletionSource.Task, this._componentStatePersistenceManager, store);
                }
                webRootComponentManager.SetCurrentUpdateTask(stateUpdateTask);
                for(/*var*/ let i = 0; i < batch.Operations.length; i++)
                {
                    /*var*/ let operation = $.$spc.System.Array.$ReadT1.call(batch.Operations, i);
                    let $switch1 = operation.Type;
                    switch($switch1)
                    {
                        case 0/*RootComponentOperationType.Add*/:
                        _ = webRootComponentManager.AddRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Key, operation.Descriptor.Parameters);
                        break;
                        case 1/*RootComponentOperationType.Update*/:
                        _ = webRootComponentManager.UpdateRootComponentAsync(operation.SsrComponentId, operation.Descriptor.ComponentType, (operation.Marker?.Key ?? null), operation.Descriptor.Parameters);
                        break;
                        case 2/*RootComponentOperationType.Remove*/:
                        webRootComponentManager.RemoveRootComponent(operation.SsrComponentId);
                        break;
                    }
                }
                taskCompletionSource?.SetResult();
                store?.ExistingState.Clear();
                this.NotifyEndUpdateRootComponents(batch.BatchId);
            }
            static /*Task *//*async*/  EnqueueRestore(/*Task*/ task, /*ComponentStatePersistenceManager*/ componentStatePersistenceManager, /*PrerenderComponentApplicationStore*/ store)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    await task;
                    await componentStatePersistenceManager.RestoreStateAsync$1(store, $.$mac.Microsoft.AspNetCore.Components.RestoreContext.ValueUpdate);
                });
            }
            /*IComponentRenderMode? */ GetComponentRenderMode(/*IComponent*/ component)
            {
                return $.$macw.Microsoft.AspNetCore.Components.Web.RenderMode.InteractiveWebAssembly;
            }
            /*void */ NotifyEndUpdateRootComponents(/*long*/ batchId)
            {
                this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$EndUpdateRootComponents(batchId);
            }
            /*ResourceAssetCollection */ get Assets()
            {
                return this._resourceCollection;
            }
            /*RendererInfo */ get RendererInfo()
            {
                return $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer._componentPlatform;
            }
            /*Dispatcher */ get Dispatcher()
            {
                return this._dispatcher;
            }
            /*Task */ AddComponentAsync(/*Type*/ componentType, /*ParameterView*/ parameters, /*string*/ domElementSelector)
            {
                /*var*/ let componentId = this.AddRootComponent(componentType, domElementSelector);
                return this.RenderRootComponentAsync$1(componentId, parameters);
            }
            /*int */ GetWebRendererId()
            {
                return 2/*WebRendererId.WebAssembly*/;
            }
            /*void */ AttachRootComponentToBrowser(/*int*/ componentId, /*string*/ domElementSelector)
            {
                this._jsMethods.Microsoft$AspNetCore$Components$WebAssembly$Services$IInternalJSImportMethods$AttachRootComponentToElement(domElementSelector, componentId, this.RendererId);
            }
            /*void */ Dispose(/*bool*/ disposing)
            {
                super.Dispose(disposing);
            }
            /*void */ ProcessPendingRender()
            {
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.IsInProgress)
                {
                    super.ProcessPendingRender();
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, this, new ($.$spc.System.Action$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, /*static*/ (/**/ $this) =>
                    {
                        return $this.CallBaseProcessPendingRender();
                    }, {"r":65537,"p":[{"n":"this","p":2949132}],"n":"","d":2949132,"h":0,"f":1048610}));
                }
            }
            /*void */ CallBaseProcessPendingRender()
            {
                return super.ProcessPendingRender();
            }
            /*Task */ UpdateDisplayAsync(/*in RenderBatch*/ batch)
            {
                /*var*/ let batchCopy = batch.$v;
                Blazor._internal.renderBatch(this.RendererId, $.$spc.System.Runtime.CompilerServices.Unsafe.AsPointer($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderBatch, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$mac.Microsoft.AspNetCore.Components.RenderTree.RenderBatch, () => batchCopy, ($v) => batchCopy = $v, null)));
                if ($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.HasUnstartedWork)
                {
                    /*var*/ let tcs = new $.$spc.System.Threading.Tasks.TaskCompletionSource().$ctor$1();
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$spc.System.Threading.Tasks.TaskCompletionSource, tcs, new ($.$spc.System.Action$$($.$spc.System.Threading.Tasks.TaskCompletionSource))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer, /*static*/ (/*tcs*/ tcs) =>
                    {
                        return tcs.SetResult();
                    }, {"r":65537,"p":[{"n":"tcs","p":134414337}],"n":"","d":2949132,"h":0,"f":1048610}));
                    return tcs.Task;
                }
                else 
                {
                    return $.$spc.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            /*void */ HandleException(/*Exception*/ exception)
            {
                let aggregateException;
                if ($.$is(exception, $.$spc.System.AggregateException, { set $v(v){ aggregateException = v; } }))
                {
                    var $en3 = aggregateException.Flatten().InnerExceptions.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var innerException = $en3.Current;
                        {
                            $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger, innerException.Message, innerException);
                        }
                    }
                }
                else 
                {
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyRenderer.Log.UnhandledExceptionRenderingComponent(this._logger, exception.Message, exception);
                }
            }
            /*IComponent */ ResolveComponentForRenderMode(/*Type*/ componentType, /*int?*/ parentComponentId, /*IComponentActivator*/ componentActivator, /*IComponentRenderMode*/ renderMode)
            {
                return (() =>
                {
                    if ((renderMode === $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveWebAssemblyRenderMode) || (renderMode === $.$macw.Microsoft.AspNetCore.Components.Web.InteractiveAutoRenderMode))
                    {
                        return componentActivator.Microsoft$AspNetCore$Components$IComponentActivator$CreateInstance(componentType);
                    }
                    throw new $.$spc.System.NotSupportedException().$ctor$10(`Cannot create a component of type '${$.$spc.System.Type.ToString.call(componentType)}' because its render mode '${$.$spc.System.Object.ToString.call(renderMode)}' is not supported by WebAssembly rendering.`);
                })();
            }
            /*ComponentState */ CreateComponentState(/*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                return new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyComponentState().$ctor$2(this, componentId, component, parentComponentState);
            }
            /*ComponentMarkerKey */ GetMarkerKey(/*WebAssemblyComponentState*/ webAssemblyComponentState)
            {
                return webAssemblyComponentState.ParentComponentState !== null ? new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey() : this._webRootComponentManager.GetRootComponentKey(webAssemblyComponentState.ComponentId);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._componentPlatform = new $.$mac.Microsoft.AspNetCore.Components.RendererInfo().$ctor$1("WebAssembly", true);
                }
            }
            static $h = 2949132;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3866633,"p":[{"p":9437192,"g":{"r":0,"d":0,"h":73017393164,"f":32772},"n":"Assets","d":2949132,"h":68722425868,"f":32772},{"p":6815752,"g":{"r":0,"d":0,"h":81607327756,"f":32772},"n":"RendererInfo","d":2949132,"h":77312360460,"f":32772},{"p":1703944,"g":{"r":0,"d":0,"h":90197262348,"f":32769},"n":"Dispatcher","d":2949132,"h":85902295052,"f":32769}],"m":[{"r":3080204,"n":"GetOrCreateWebRootComponentManager","d":2949132,"h":8592883724,"f":1},{"r":65537,"p":[{"n":"batch","p":1048588},{"n":"appState","p":1310721}],"n":"OnUpdateRootComponents","d":2949132,"h":51542556684,"f":2},{"r":133300225,"p":[{"n":"task","p":133300225},{"n":"componentStatePersistenceManager","p":3342344},{"n":"store","p":720908}],"n":"EnqueueRestore","d":2949132,"h":55837523980,"f":4130},{"r":2883592,"p":[{"n":"component","p":2752520}],"n":"GetComponentRenderMode","d":2949132,"h":60132491276,"f":32772},{"r":65537,"p":[{"n":"batchId","p":917505}],"n":"NotifyEndUpdateRootComponents","d":2949132,"h":64427458572,"f":1},{"r":133300225,"p":[{"n":"componentType","p":142606337},{"n":"parameters","p":5767176},{"n":"domElementSelector","p":1310721}],"n":"AddComponentAsync","d":2949132,"h":94492229644,"f":1},{"r":655361,"n":"GetWebRendererId","d":2949132,"h":98787196940,"f":32772},{"r":65537,"p":[{"n":"componentId","p":655361},{"n":"domElementSelector","p":1310721}],"n":"AttachRootComponentToBrowser","d":2949132,"h":103082164236,"f":32772},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","d":2949132,"h":107377131532,"f":32772},{"r":65537,"n":"ProcessPendingRender","d":2949132,"h":111672098828,"f":32772},{"r":65537,"n":"CallBaseProcessPendingRender","d":2949132,"h":115967066124,"f":2},{"r":133300225,"p":[{"n":"batch","p":8388616,"f":8}],"n":"UpdateDisplayAsync","d":2949132,"h":120262033420,"f":32772},{"r":65537,"p":[{"n":"exception","p":47251457}],"n":"HandleException","d":2949132,"h":124557000716,"f":32772},{"r":2752520,"p":[{"n":"componentType","p":142606337},{"n":"parentComponentId","p":$.$typeNullable($.$spc.System.Int32).$h},{"n":"componentActivator","p":2818056},{"n":"renderMode","p":2883592}],"n":"ResolveComponentForRenderMode","d":2949132,"h":128851968012,"f":32772},{"r":7077896,"p":[{"n":"componentId","p":655361},{"n":"component","p":2752520},{"n":"parentComponentState","p":7077896}],"n":"CreateComponentState","d":2949132,"h":133146935308,"f":32772},{"r":196620,"p":[{"n":"webAssemblyComponentState","p":2818060}],"n":"GetMarkerKey","d":2949132,"h":137441902604,"f":8}],"l":[{"t":3080204,"n":"_webRootComponentManager","d":2949132,"h":4297916428,"f":2},{"t":917525,"n":"_logger","d":2949132,"h":21477785612,"f":2},{"t":1703944,"n":"_dispatcher","d":2949132,"h":25772752908,"f":2},{"t":9437192,"n":"_resourceCollection","d":2949132,"h":30067720204,"f":2},{"t":3342348,"n":"_jsMethods","d":2949132,"h":34362687500,"f":2},{"t":3342344,"n":"_componentStatePersistenceManager","d":2949132,"h":38657654796,"f":2},{"t":6815752,"n":"_componentPlatform","d":2949132,"h":42952622092,"f":34}],"c":[{"p":[{"n":"serviceProvider","p":327717},{"n":"resourceCollection","p":9437192},{"n":"loggerFactory","p":1048597},{"n":"jsComponentInterop","p":5898249}],"n":".ctor","o":"$ctor$4","d":2949132,"h":47247589388,"f":1}],"i":[57540609,56950785],"j":[3080204,3014668],"h":2949132}; }
            static get $b() { return $.$macw.Microsoft.AspNetCore.Components.RenderTree.WebRenderer; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyRenderer`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream", ($self) => class PullFromJSDataStream extends $.$spc.System.IO.Stream
        {
            /*IJSRuntime*/ _runtime = null;
            /*IJSStreamReference*/ _jsStreamReference = null;
            /*long*/ _totalLength = 0n;
            /*CancellationToken*/ _streamCancellationToken;
            /*long*/ _offset = 0n;
            static /*PullFromJSDataStream */ CreateJSDataStream(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let jsDataStream = new $.$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream().$ctor$3(runtime, jsStreamReference, totalLength, cancellationToken);
                return jsDataStream;
            }
            $ctor$3(/*IJSRuntime*/ runtime, /*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                super.$ctor$2();
                {
                    this._runtime = runtime;
                    this._jsStreamReference = jsStreamReference;
                    this._totalLength = totalLength;
                    this._streamCancellationToken = cancellationToken;
                    this._offset = 0n;
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                return this._totalLength;
            }
            /*long */ get Position()
            {
                return this._offset;
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Threading.Tasks.Task.CompletedTask;
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10("Synchronous reads are not supported.");
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*Task<int> *//*async*/  ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    return await this.ReadAsync$2($.$spc.System.MemoryExtensions.AsMemory$8($.$spc.System.Byte, buffer, offset, count), cancellationToken);
                });
            }
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                {
                    /*var*/ let bytesRead = await this.RequestDataFromJSAsync(buffer.Length);
                    this.ThrowIfCancellationRequested(cancellationToken);
                    $.$spc.System.MemoryExtensions.CopyTo$1($.$spc.System.Byte, bytesRead, buffer);
                    return bytesRead.length;
                });
            }
            /*void */ ThrowIfCancellationRequested(/*CancellationToken*/ cancellationToken)
            {
                if (cancellationToken.IsCancellationRequested || this._streamCancellationToken.IsCancellationRequested)
                {
                    throw new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$16();
                }
            }
            /*ValueTask<byte[]> *//*async*/  RequestDataFromJSAsync(/*int*/ numBytesToRead)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$typeArray($.$spc.System.Byte)), $.$typeArray($.$spc.System.Byte), async () => 
                {
                    numBytesToRead = $.$cast($.$spc.System.Math.Min$5(BigInt(numBytesToRead), this._totalLength - this._offset), $.$spc.System.Int32);
                    /*var*/ let bytesRead = await $.$mj.Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync($.$typeArray($.$spc.System.Byte), this._runtime, "Blazor._internal.getJSDataStreamChunk", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ this._jsStreamReference, $.$box(this._offset, $.$spc.System.Int64), $.$box(numBytesToRead, $.$spc.System.Int32) ], null, null));
                    if (bytesRead.length !== numBytesToRead)
                    {
                        throw new $.$spc.System.IO.EndOfStreamException().$ctor$15("Failed to read the requested number of bytes from the stream.");
                    }
                    this._offset += BigInt(bytesRead.length);
                    if (this._offset === this._totalLength)
                    {
                        this.Dispose$1(true);
                    }
                    return bytesRead;
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this._streamCancellationToken = $.$default($.$spc.System.Threading.CancellationToken);
            }
            static $h = 851980;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38655557644,"f":32769},"n":"CanRead","d":851980,"h":34360590348,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245492236,"f":32769},"n":"CanSeek","d":851980,"h":42950524940,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835426828,"f":32769},"n":"CanWrite","d":851980,"h":51540459532,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64425361420,"f":32769},"n":"Length","d":851980,"h":60130394124,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":73015296012,"f":32769},"s":{"r":0,"d":0,"h":77310263308,"f":32769},"n":"Position","d":851980,"h":68720328716,"f":32769}],"m":[{"r":851980,"p":[{"n":"runtime","p":524318},{"n":"jsStreamReference","p":589854},{"n":"totalLength","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CreateJSDataStream","d":851980,"h":25770655756,"f":33},{"r":65537,"n":"Flush","d":851980,"h":81605230604,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":851980,"h":85900197900,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":851980,"h":90195165196,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":851980,"h":94490132492,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":851980,"h":98785099788,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":851980,"h":103080067084,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":851980,"h":107375034380,"f":36865},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":851980,"h":111670001676,"f":36865},{"r":65537,"p":[{"n":"cancellationToken","p":125960193}],"n":"ThrowIfCancellationRequested","d":851980,"h":115964968972,"f":2},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$typeArray($.$spc.System.Byte)).$h,"p":[{"n":"numBytesToRead","p":655361}],"n":"RequestDataFromJSAsync","d":851980,"h":120259936268,"f":4098}],"l":[{"t":524318,"n":"_runtime","d":851980,"h":4295819276,"f":2},{"t":589854,"n":"_jsStreamReference","d":851980,"h":8590786572,"f":2},{"t":917505,"n":"_totalLength","d":851980,"h":12885753868,"f":2},{"t":125960193,"n":"_streamCancellationToken","d":851980,"h":17180721164,"f":2},{"t":917505,"n":"_offset","d":851980,"h":21475688460,"f":2}],"c":[{"p":[{"n":"runtime","p":524318},{"n":"jsStreamReference","p":589854},{"n":"totalLength","p":917505},{"n":"cancellationToken","p":125960193}],"n":".ctor","o":"$ctor$3","d":851980,"h":30065623052,"f":2}],"i":[57540609,56950785],"h":851980}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `PullFromJSDataStream`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType", ($self) => class RootComponentOperationType extends $.$spc.System.Enum
        {
            static Add = 0;
            static Update = 1;
            static Remove = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Add": 0n,
                    "Update": 1n,
                    "Remove": 2n
                };
            }
            static $h = 1114124;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1114124,"n":"Add","d":1114124,"h":4296081420,"f":33},{"t":1114124,"n":"Update","d":1114124,"h":8591048716,"f":33},{"t":1114124,"n":"Remove","d":1114124,"h":12886016012,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1114124,"h":17180983308,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1114124,"a":[{"t":13276845,"c":4308244141,"a":[{"v":$.$stj.System.Text.Json.Serialization.JsonStringEnumConverter$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationType).$h,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `RootComponentOperationType`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebRendererId", ($self) => class WebRendererId extends $.$spc.System.Enum
        {
            static Default = 0;
            static Server = 1;
            static WebAssembly = 2;
            static WebView = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "Server": 1n,
                    "WebAssembly": 2n,
                    "WebView": 3n
                };
            }
            static $h = 4259852;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4259852,"n":"Default","d":4259852,"h":4299227148,"f":33},{"t":4259852,"n":"Server","d":4259852,"h":8594194444,"f":33},{"t":4259852,"n":"WebAssembly","d":4259852,"h":12889161740,"f":33},{"t":4259852,"n":"WebView","d":4259852,"h":17184129036,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4259852,"h":21479096332,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":4259852}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `WebRendererId`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCache", ($self) => class BrowserRequestCache extends $.$spc.System.Enum
        {
            static Default = 0;
            static NoStore = 1;
            static Reload = 2;
            static NoCache = 3;
            static ForceCache = 4;
            static OnlyIfCached = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "NoStore": 1n,
                    "Reload": 2n,
                    "NoCache": 3n,
                    "ForceCache": 4n,
                    "OnlyIfCached": 5n
                };
            }
            static $h = 2359308;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2359308,"n":"Default","d":2359308,"h":4297326604,"f":33},{"t":2359308,"n":"NoStore","d":2359308,"h":8592293900,"f":33},{"t":2359308,"n":"Reload","d":2359308,"h":12887261196,"f":33},{"t":2359308,"n":"NoCache","d":2359308,"h":17182228492,"f":33},{"t":2359308,"n":"ForceCache","d":2359308,"h":21477195788,"f":33},{"t":2359308,"n":"OnlyIfCached","d":2359308,"h":25772163084,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2359308,"h":30067130380,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2359308}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestCache`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestCredentials", ($self) => class BrowserRequestCredentials extends $.$spc.System.Enum
        {
            static Omit = 0;
            static SameOrigin = 1;
            static Include = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Omit": 0n,
                    "SameOrigin": 1n,
                    "Include": 2n
                };
            }
            static $h = 2424844;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2424844,"n":"Omit","d":2424844,"h":4297392140,"f":33},{"t":2424844,"n":"SameOrigin","d":2424844,"h":8592359436,"f":33},{"t":2424844,"n":"Include","d":2424844,"h":12887326732,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2424844,"h":17182294028,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2424844}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestCredentials`; }
        });
        
        $asm.$str("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Http.BrowserRequestMode", ($self) => class BrowserRequestMode extends $.$spc.System.Enum
        {
            static SameOrigin = 0;
            static NoCors = 1;
            static Cors = 2;
            static Navigate = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SameOrigin": 0n,
                    "NoCors": 1n,
                    "Cors": 2n,
                    "Navigate": 3n
                };
            }
            static $h = 2490380;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2490380,"n":"SameOrigin","d":2490380,"h":4297457676,"f":33},{"t":2490380,"n":"NoCors","d":2490380,"h":8592424972,"f":33},{"t":2490380,"n":"Cors","d":2490380,"h":12887392268,"f":33},{"t":2490380,"n":"Navigate","d":2490380,"h":17182359564,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2490380,"h":21477326860,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2490380}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `BrowserRequestMode`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime", ($self) => class DefaultWebAssemblyJSRuntime extends $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime
        {
            /*DefaultWebAssemblyJSRuntime*/ static Instance = null;
            /*RootTypeCache*/ _rootComponentCache = null;
            /*ElementReferenceContext*/ ElementReferenceContext = null;
            /*Action<RootComponentOperationBatch, string>?*/ OnUpdateRootComponents = null;
            add_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                this.OnUpdateRootComponents = $.$spc.System.Delegate.Combine(this.OnUpdateRootComponents, value);
            }
            remove_OnUpdateRootComponents(/*Action<RootComponentOperationBatch, string>?*/ value)
            {
                this.OnUpdateRootComponents = $.$spc.System.Delegate.Remove(this.OnUpdateRootComponents, value);
            }
            $ctor$4()
            {
                super.$ctor$3();
                {
                    this.ElementReferenceContext = new $.$macw.Microsoft.AspNetCore.Components.WebElementReferenceContext().$ctor$2(this);
                    this.JsonSerializerOptions.Converters.System$Collections$Generic$ICollection$$$Add(new $.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter().$ctor$1(this.ElementReferenceContext), [$.$stj.System.Text.Json.Serialization.JsonConverter]);
                }
                return this;
            }
            /*JsonSerializerOptions */ ReadJsonSerializerOptions()
            {
                return this.JsonSerializerOptions;
            }
            static /*string? */ InvokeDotNet(/*string?*/ assemblyName, /*string*/ methodIdentifier, /*long*/ dotNetObjectId, /*string*/ argsJson)
            {
                /*var*/ let callInfo = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo().$ctor$2(assemblyName, methodIdentifier, dotNetObjectId, null);
                return $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.Invoke($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, $.$ref(() => callInfo, ), argsJson);
            }
            static /*void */ EndInvokeJS(/*string*/ argsJson)
            {
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$spc.System.String, argsJson, new ($.$spc.System.Action$$($.$spc.System.String))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime, /*static*/ (/*argsJson*/ argsJson) =>
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.EndInvokeJS($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, argsJson);
                }, {"r":65537,"p":[{"n":"argsJson","p":1310721}],"n":"","d":3276812,"h":0,"f":1048610}));
            }
            static /*void */ BeginInvokeDotNet(/*string?*/ callId, /*string*/ assemblyNameOrDotNetObjectId, /*string*/ methodIdentifier, /*string*/ argsJson)
            {
                /*string?*/ let assemblyName;
                /*long*/ let dotNetObjectId;
                if ($.$spc.System.Char.IsDigit($.$spc.System.String.get_Chars.call(assemblyNameOrDotNetObjectId, 0)))
                {
                    dotNetObjectId = $.$spc.System.Int64.Parse$2(assemblyNameOrDotNetObjectId, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
                    assemblyName = null;
                }
                else 
                {
                    dotNetObjectId = 0n;
                    assemblyName = assemblyNameOrDotNetObjectId;
                }
                /*var*/ let callInfo = new $.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo().$ctor$2(assemblyName, methodIdentifier, dotNetObjectId, callId);
                $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.WebAssemblyCallQueue.Schedule($.$spc.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$spc.System.String), new ($.$spc.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$spc.System.String))().$ctor$2(callInfo, argsJson), new ($.$spc.System.Action$$($.$spc.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$spc.System.String)))().$ctor($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime, /*static*/ (/*state*/ state) =>
                {
                    $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.BeginInvokeDotNet($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, state.Item1, state.Item2);
                }, {"r":65537,"p":[{"n":"state","p":$.$spc.System.ValueTuple$$$($.$mj.Microsoft.JSInterop.Infrastructure.DotNetInvocationInfo, $.$spc.System.String).$h}],"n":"","d":3276812,"h":0,"f":1048610}));
            }
            static /*void */ UpdateRootComponentsCore(/*string*/ operationsJson, /*string*/ appState)
            {
                try
                {
                    /*var*/ let operations = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeOperations(operationsJson);
                    $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance.OnUpdateRootComponents?.Invoke(operations, appState);
                }
                catch(ex)
                {
                    $.$scsl.System.Console.Error.WriteLine$13(`Error deserializing root component operations: ${$.$spc.System.Exception.ToString.call(ex)}`);
                }
            }
            static /*RootComponentOperationBatch */ DeserializeOperations(/*string*/ operationsJson)
            {
                /*var*/ let deserialized = $.$stj.System.Text.Json.JsonSerializer.Deserialize$34($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, operationsJson, $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Infrastructure.WebAssemblyJsonSerializerContext.Default.RootComponentOperationBatch);
                for(/*var*/ let i = 0; i < deserialized.Operations.length; i++)
                {
                    /*var*/ let operation = $.$spc.System.Array.$ReadT1.call(deserialized.Operations, i);
                    if (operation.Type === 2/*RootComponentOperationType.Remove*/)
                    {
                        continue;
                    }
                    if (operation.Marker === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`The component operation of type '${operation.Type}' requires a '${"Marker"}' to be specified.`);
                    }
                    /*var*/ let componentType = $.$firstOf($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance._rootComponentCache.GetRootType($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Assembly, $.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).TypeName), () => { throw new $.$spc.System.InvalidOperationException().$ctor$10(`Root component type '${$.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).TypeName}' could not be found in the assembly '${$.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker).Assembly}'.`) });
                    /*var*/ let parameters = $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.DeserializeComponentParameters($.$spc.System.Nullable$$($.$macwa.Microsoft.AspNetCore.Components.ComponentMarker).Value$get.call(operation.Marker));
                    operation.Descriptor = new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentDescriptor().$ctor$1(componentType, parameters);
                }
                return deserialized;
            }
            static /*WebRootComponentParameters */ DeserializeComponentParameters(/*ComponentMarker*/ marker)
            {
                /*var*/ let definitions = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterDefinitions(marker.ParameterDefinitions);
                /*var*/ let values = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.GetParameterValues(marker.ParameterValues);
                /*var*/ let componentDeserializer = $.$macwa.Microsoft.AspNetCore.Components.WebAssemblyComponentParameterDeserializer.Instance;
                /*var*/ let parameters = componentDeserializer.DeserializeParameters(definitions, values);
                return new $.$macwa.Microsoft.AspNetCore.Components.WebRootComponentParameters().$ctor$2(parameters, definitions, $.$spc.System.Collections.Generic.CollectionExtensions.AsReadOnly($.$spc.System.Object, values));
            }
            static /*void */ ReceiveByteArrayFromJS(/*int*/ id, /*byte[]*/ data)
            {
                $.$mj.Microsoft.JSInterop.Infrastructure.DotNetDispatcher.ReceiveByteArray($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime.Instance, id, data);
            }
            /*Task<Stream> */ ReadJSDataAsStreamAsync(/*IJSStreamReference*/ jsStreamReference, /*long*/ totalLength, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.IO.Stream, $.$macwa.Microsoft.AspNetCore.Components.PullFromJSDataStream.CreateJSDataStream(this, jsStreamReference, totalLength, cancellationToken));
            }
            /*Task */ TransmitStreamAsync(/*long*/ streamId, /*DotNetStreamReference*/ dotNetStreamReference)
            {
                return $.$macwa.Microsoft.AspNetCore.Components.TransmitDataStreamToJS.TransmitStreamAsync(this, "Blazor._internal.receiveWebAssemblyDotNetDataStream", streamId, dotNetStreamReference);
            }
            /*string */ Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS(/*string*/ identifier, /*string?*/ argsJson, /*JSCallResultType*/ resultType, /*long*/ targetInstanceId)
            {
                return this.InvokeJS$1(identifier, argsJson, resultType, targetInstanceId);
            }
            /*string */ Microsoft$AspNetCore$Components$Web$Internal$IInternalWebJSInProcessRuntime$InvokeJS$1(/*in JSInvocationInfo*/ invocationInfo)
            {
                return this.InvokeJS$2(invocationInfo);
            }
            //default member initializer
            constructor()
            {
                super();
                this._rootComponentCache = new $.$macwa.Microsoft.AspNetCore.Components.RootTypeCache().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Services.DefaultWebAssemblyJSRuntime().$ctor$4();
                }
            }
            //Method exports
            static $exports()
            {
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_InvokeDotNet = this.InvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_EndInvokeJS = this.EndInvokeJS;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_BeginInvokeDotNet = this.BeginInvokeDotNet;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_UpdateRootComponentsCore = this.UpdateRootComponentsCore;
                $.$exports.Microsoft_AspNetCore_Components_WebAssembly_Services_DefaultWebAssemblyJSRuntime_ReceiveByteArrayFromJS = this.ReceiveByteArrayFromJS;
            }
            static $h = 3276812;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":262175,"p":[{"p":1966088,"g":{"r":0,"d":0,"h":21478113292,"f":1},"n":"ElementReferenceContext","d":3276812,"h":17183145996,"f":1}],"m":[{"r":3380909,"n":"ReadJsonSerializerOptions","d":3276812,"h":42952949772,"f":1},{"r":1310721,"p":[{"n":"assemblyName","p":1310721},{"n":"methodIdentifier","p":1310721},{"n":"dotNetObjectId","p":917505,"a":[{"t":$.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.Number).$h,"c":Number(BigInt($.$srij.System.Runtime.InteropServices.JavaScript.JSMarshalAsAttribute$$($.$srij.System.Runtime.InteropServices.JavaScript.JSType.Number).$h)|0x100000000n)}]},{"n":"argsJson","p":1310721}],"n":"InvokeDotNet","d":3276812,"h":47247917068,"f":33,"a":[{"t":519561,"c":4295486857},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"argsJson","p":1310721}],"n":"EndInvokeJS","d":3276812,"h":51542884364,"f":33,"a":[{"t":519561,"c":4295486857},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"callId","p":1310721},{"n":"assemblyNameOrDotNetObjectId","p":1310721},{"n":"methodIdentifier","p":1310721},{"n":"argsJson","p":1310721}],"n":"BeginInvokeDotNet","d":3276812,"h":55837851660,"f":33,"a":[{"t":519561,"c":4295486857},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"p":[{"n":"operationsJson","p":1310721},{"n":"appState","p":1310721}],"n":"UpdateRootComponentsCore","d":3276812,"h":60132818956,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]},{"t":519561,"c":4295486857}]},{"r":1048588,"p":[{"n":"operationsJson","p":1310721}],"n":"DeserializeOperations","d":3276812,"h":64427786252,"f":40},{"r":4390924,"p":[{"n":"marker","p":131084}],"n":"DeserializeComponentParameters","d":3276812,"h":68722753548,"f":34},{"r":65537,"p":[{"n":"id","p":655361},{"n":"data","p":0}],"n":"ReceiveByteArrayFromJS","d":3276812,"h":73017720844,"f":34,"a":[{"t":519561,"c":4295486857},{"t":114950145,"c":4409917441,"a":[{"v":"browser","t":1310721}]}]},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"jsStreamReference","p":589854},{"n":"totalLength","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadJSDataAsStreamAsync","d":3276812,"h":77312688140,"f":32772},{"r":133300225,"p":[{"n":"streamId","p":917505},{"n":"dotNetStreamReference","p":262174}],"n":"TransmitStreamAsync","d":3276812,"h":81607655436,"f":32772}],"l":[{"t":3276812,"n":"Instance","d":3276812,"h":4298244108,"f":33},{"t":1179660,"n":"_rootComponentCache","d":3276812,"h":8593211404,"f":2}],"c":[{"n":".ctor","o":"$ctor$4","d":3276812,"h":38657982476,"f":2}],"e":[{"e":$.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$spc.System.String).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$spc.System.String).$h}],"n":"add_OnUpdateRootComponents","d":3276812,"h":25773080588,"f":1},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.Action$$$($.$macwa.Microsoft.AspNetCore.Components.RootComponentOperationBatch, $.$spc.System.String).$h}],"n":"remove_OnUpdateRootComponents","d":3276812,"h":30068047884,"f":1},"n":"OnUpdateRootComponents","d":3276812,"h":34363015180,"f":1}],"i":[57540609,393246,524318,6357001],"h":3276812}; }
            static get $b() { return $.$mjw.Microsoft.JSInterop.WebAssembly.WebAssemblyJSRuntime; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$mj.Microsoft.JSInterop.IJSInProcessRuntime, $.$mj.Microsoft.JSInterop.IJSRuntime, $.$macw.Microsoft.AspNetCore.Components.Web.Internal.IInternalWebJSInProcessRuntime ]; }
            static get $fullName() { return `DefaultWebAssemblyJSRuntime`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter", ($self) => class ElementReferenceJsonConverter extends $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mac.Microsoft.AspNetCore.Components.ElementReference)
        {
            /*JsonEncodedText*/ static IdProperty;
            /*ElementReferenceContext*/ _elementReferenceContext = null;
            $ctor$1(/*ElementReferenceContext*/ elementReferenceContext)
            {
                super.$ctor$2();
                {
                    this._elementReferenceContext = elementReferenceContext;
                }
                return this;
            }
            /*ElementReference */ Read(/*ref Utf8JsonReader*/ reader, /*Type*/ typeToConvert, /*JsonSerializerOptions*/ options)
            {
                /*string?*/ let id = null;
                while(reader.$v.Read() && reader.$v.TokenType !== 2/*JsonTokenType.EndObject*/)
                {
                    if (reader.$v.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.$v.ValueTextEquals($.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter.IdProperty.EncodedUtf8Bytes))
                        {
                            reader.$v.Read();
                            id = reader.$v.GetString();
                        }
                        else 
                        {
                            throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON property '${reader.$v.GetString()}'.`);
                        }
                    }
                    else 
                    {
                        throw new $.$stj.System.Text.Json.JsonException().$ctor$8(`Unexpected JSON Token ${reader.$v.TokenType}.`);
                    }
                }
                if (id === null)
                {
                    throw new $.$stj.System.Text.Json.JsonException().$ctor$8("__internalId is required.");
                }
                return new $.$mac.Microsoft.AspNetCore.Components.ElementReference().$ctor$2(id, this._elementReferenceContext);
            }
            /*void */ Write(/*Utf8JsonWriter*/ writer, /*ElementReference*/ value, /*JsonSerializerOptions*/ options)
            {
                writer.WriteStartObject();
                writer.WriteString$13($.$macwa.Microsoft.AspNetCore.Components.ElementReferenceJsonConverter.IdProperty, value.Id);
                writer.WriteEndObject();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IdProperty = $.$stj.System.Text.Json.JsonEncodedText.Encode("__internalId", null);
                }
            }
            static $h = 458764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1900552,"p":[{"n":"reader","p":18978477,"f":4},{"n":"typeToConvert","p":142606337},{"n":"options","p":3380909}],"n":"Read","d":458764,"h":17180327948,"f":32769},{"r":65537,"p":[{"n":"writer","p":19109549},{"n":"value","p":1900552},{"n":"options","p":3380909}],"n":"Write","d":458764,"h":21475295244,"f":32769}],"l":[{"t":2332333,"n":"IdProperty","d":458764,"h":4295426060,"f":34},{"t":1966088,"n":"_elementReferenceContext","d":458764,"h":8590393356,"f":2}],"c":[{"p":[{"n":"elementReferenceContext","p":1966088}],"n":".ctor","o":"$ctor$1","d":458764,"h":12885360652,"f":1}],"h":458764}; }
            static get $b() { return $.$stj.System.Text.Json.Serialization.JsonConverter$$($.$mac.Microsoft.AspNetCore.Components.ElementReference); }
            static get $fullName() { return `ElementReferenceJsonConverter`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Rendering.WebAssemblyComponentState", ($self) => class WebAssemblyComponentState extends $.$mac.Microsoft.AspNetCore.Components.Rendering.ComponentState
        {
            /*WebAssemblyRenderer*/ _renderer = null;
            $ctor$2(/*WebAssemblyRenderer*/ renderer, /*int*/ componentId, /*IComponent*/ component, /*ComponentState?*/ parentComponentState)
            {
                super.$ctor$1(renderer, componentId, component, parentComponentState);
                {
                    this._renderer = renderer;
                }
                return this;
            }
            /*object? */ GetComponentKey()
            {
                /*var*/ let markerKey = this._renderer.GetMarkerKey(this);
                if ($.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey.op_Inequality(markerKey, new $.$macwa.Microsoft.AspNetCore.Components.ComponentMarkerKey()))
                {
                    return markerKey.Serialized();
                }
                return super.GetComponentKey();
            }
            static $h = 2818060;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7077896,"m":[{"r":131073,"n":"GetComponentKey","d":2818060,"h":12887719948,"f":32772}],"l":[{"t":2949132,"n":"_renderer","d":2818060,"h":4297785356,"f":2}],"c":[{"p":[{"n":"renderer","p":2949132},{"n":"componentId","p":655361},{"n":"component","p":2752520},{"n":"parentComponentState","p":7077896}],"n":".ctor","o":"$ctor$2","d":2818060,"h":8592752652,"f":1}],"i":[56950785],"h":2818060}; }
            static get $b() { return $.$mac.Microsoft.AspNetCore.Components.Rendering.ComponentState; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `WebAssemblyComponentState`; }
        });
        
        $asm.$cls("$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMappingCollection", ($self) => class RootComponentMappingCollection extends $.$spc.System.Collections.ObjectModel.Collection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping)
        {
            /*JSComponentConfigurationStore*/ JSComponents = null;
            /*void */ Add$1(TComponent, /*string*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                this.Add(new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping().$ctor$2(TComponent.$type, selector));
            }
            /*void */ Add$2(/*Type*/ componentType, /*string*/ selector)
            {
                this.Add$3(componentType, selector, $.$mac.Microsoft.AspNetCore.Components.ParameterView.Empty);
            }
            /*void */ Add$3(/*Type*/ componentType, /*string*/ selector, /*ParameterView*/ parameters)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(componentType, "componentType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                this.Add(new $.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping().$ctor$3(componentType, selector, parameters));
            }
            /*void */ AddRange(/*IEnumerable<RootComponentMapping>*/ items)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(items, "items");
                var $en2 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Add(item);
                    }
                }
            }
            //Generated interface implemetation for Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration.JSComponents.get
            get Microsoft$AspNetCore$Components$Web$IJSComponentConfiguration$JSComponents()
            {
                return this.JSComponents;
            }
            //default reference type constructor overload
            $ctor$3()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.JSComponents = new $.$macw.Microsoft.AspNetCore.Components.Web.JSComponentConfigurationStore().$ctor$1();
            }
            static $h = 1703948;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":6488073,"g":{"r":0,"d":0,"h":12886605836,"f":1},"n":"JSComponents","d":1703948,"h":8591638540,"f":1}],"m":[{"r":65537,"p":[{"n":"selector","p":1310721}],"g":["TComponent"],"n":"Add","o":"@$1","d":1703948,"h":17181573132,"f":131073},{"r":65537,"p":[{"n":"componentType","p":142606337},{"n":"selector","p":1310721}],"n":"Add","o":"@$2","d":1703948,"h":21476540428,"f":1},{"r":65537,"p":[{"n":"componentType","p":142606337},{"n":"selector","p":1310721},{"n":"parameters","p":5767176}],"n":"Add","o":"@$3","d":1703948,"h":25771507724,"f":1},{"r":65537,"p":[{"n":"items","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h}],"n":"AddRange","d":1703948,"h":30066475020,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":1703948,"h":34361442316,"f":1}],"i":[$.$spc.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$spc.System.Collections.Generic.ICollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,31981569,31391745,$.$spc.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping).$h,31653889,5832713],"h":1703948}; }
            static get $b() { return $.$spc.System.Collections.ObjectModel.Collection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$spc.System.Collections.Generic.ICollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyList$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$spc.System.Collections.Generic.IEnumerable$$($.$macwa.Microsoft.AspNetCore.Components.WebAssembly.Hosting.RootComponentMapping), $.$spc.System.Collections.IEnumerable, $.$macw.Microsoft.AspNetCore.Components.Web.IJSComponentConfiguration ]; }
            static get $fullName() { return `RootComponentMappingCollection`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions", "NetJs.Microsoft.Extensions.Diagnostics", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.IO.Pipes", "NetJs.System.Diagnostics.Process", "NetJs.System.Xml.ReaderWriter", "NetJs.System.Transactions.Local", "NetJs.System.Xml.XmlSerializer", "NetJs.System.Data.Common", "NetJs.System.Text.Encodings.Web", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Json", "NetJs.Microsoft.AspNetCore.Components", "NetJs.Microsoft.Extensions.Validation", "NetJs.System.Runtime.Serialization.Primitives", "NetJs.Microsoft.AspNetCore.Components.Forms", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.JSInterop", "NetJs.Microsoft.AspNetCore.Components.Web", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.Microsoft.Extensions.Configuration.Json", "NetJs.Microsoft.Extensions.Logging", "NetJs.Microsoft.JSInterop.WebAssembly"))