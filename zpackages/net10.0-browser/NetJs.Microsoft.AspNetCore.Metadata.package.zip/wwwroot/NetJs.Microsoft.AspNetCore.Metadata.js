
//--TRIMMABLE-BOUNDARY-START(111)
(async function () {
(function ($global, $, $$) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {
  "h": 111,
  "f": "Microsoft.AspNetCore.Metadata",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "ASP.NET Core metadata.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131183)
        $asm.$cls(`$mam.MAA.IAuthorizeData`, ($self) => class IAuthorizeData
        {
            static $h = 131183;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359869551),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474967663,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834706031,
        "f": 83886337
      },
      "n": "Policy",
      "o": "MAA$IAuthorizeData$Policy",
      "d": 131183,
      "h": 34359869551,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34359869551),
//--TRIMMABLE-BOUNDARY-START(38654836847),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902255,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424640623,
        "f": 83886337
      },
      "n": "Roles",
      "o": "MAA$IAuthorizeData$Roles",
      "d": 131183,
      "h": 38654836847,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38654836847),
//--TRIMMABLE-BOUNDARY-START(4295098479),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885033071,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244771439,
        "f": 83886337
      },
      "n": "AuthenticationSchemes",
      "o": "MAA$IAuthorizeData$AuthenticationSchemes",
      "d": 131183,
      "h": 4295098479,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295098479)
  ],
  "h": 131183
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAuthorizeData`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAuthorizeData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131183)
        
        

        //--TRIMMABLE-BOUNDARY-START(65647)
        $asm.$cls(`$mam.MAA.IAllowAnonymous`, ($self) => class IAllowAnonymous
        {
            static $h = 65647;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 65647
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Authorization.IAllowAnonymous`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Authorization${separator}IAllowAnonymous`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65647)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib"));
})();
//--TRIMMABLE-BOUNDARY-END(111)
