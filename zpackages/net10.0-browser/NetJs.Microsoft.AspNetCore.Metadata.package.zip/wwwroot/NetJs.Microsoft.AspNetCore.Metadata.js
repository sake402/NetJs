
//--TRIMMABLE-BOUNDARY-START(104)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {
  "h": 104,
  "f": "Microsoft.AspNetCore.Metadata",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "ASP.NET Core metadata.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65640)
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous", ($self) => class IAllowAnonymous
        {
            static $h = 65640;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 65640
}; }
            static get $fullName() { return `IAllowAnonymous`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65640)
        
        
        //--TRIMMABLE-BOUNDARY-START(131176)
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData", ($self) => class IAuthorizeData
        {
            static $h = 131176;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359869544),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474967656,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834706024,
        "f": 83886337
      },
      "n": "Policy",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy",
      "d": 131176,
      "h": 34359869544,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34359869544),
//--TRIMMABLE-BOUNDARY-START(38654836840),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902248,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424640616,
        "f": 83886337
      },
      "n": "Roles",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles",
      "d": 131176,
      "h": 38654836840,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38654836840),
//--TRIMMABLE-BOUNDARY-START(4295098472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885033064,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244771432,
        "f": 83886337
      },
      "n": "AuthenticationSchemes",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes",
      "d": 131176,
      "h": 4295098472,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295098472)
  ],
  "h": 131176
}; }
            static get $fullName() { return `IAuthorizeData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131176)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(104)
