
//--TRIMMABLE-BOUNDARY-START(104)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {
  "h": 104,
  "f": "Microsoft.AspNetCore.Metadata",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "ASP.NET Core metadata.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.Metadata",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65640)
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous", ($self) => class IAllowAnonymous
        {
            static $h = 65640;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 65640
}; }
            static get $fullName() { return `IAllowAnonymous`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65640)
        
        
        //--TRIMMABLE-BOUNDARY-START(131176)
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData", ($self) => class IAuthorizeData
        {
            static $h = 131176;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359869544),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474967656,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834706024,
        "f": 83886337
      },
      "n": "Policy",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy",
      "d": 131176,
      "h": 34359869544,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34359869544),
//--TRIMMABLE-BOUNDARY-START(38654836840),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902248,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424640616,
        "f": 83886337
      },
      "n": "Roles",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles",
      "d": 131176,
      "h": 38654836840,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38654836840),
//--TRIMMABLE-BOUNDARY-START(4295098472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885033064,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244771432,
        "f": 83886337
      },
      "n": "AuthenticationSchemes",
      "o": "Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes",
      "d": 131176,
      "h": 4295098472,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295098472)
  ],
  "h": 131176
}; }
            static get $fullName() { return `IAuthorizeData`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131176)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(104)
