
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {"h":57063,"f":"Microsoft.AspNetCore.Metadata","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core metadata.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous", ($self) => class IAllowAnonymous
        {
            static $h = 122599;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":122599}; }
            static get $fullName() { return `IAllowAnonymous`; }
        });
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData", ($self) => class IAuthorizeData
        {
            static $h = 188135;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590122727,"f":257},"s":{"r":0,"d":0,"h":12885090023,"f":257},"n":"Policy","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy","d":188135,"h":4295155431,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":21475024615,"f":257},"s":{"r":0,"d":0,"h":25769991911,"f":257},"n":"Roles","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles","d":188135,"h":17180057319,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":34359926503,"f":257},"s":{"r":0,"d":0,"h":38654893799,"f":257},"n":"AuthenticationSchemes","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes","d":188135,"h":30064959207,"f":257}],"h":188135}; }
            static get $fullName() { return `IAuthorizeData`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))