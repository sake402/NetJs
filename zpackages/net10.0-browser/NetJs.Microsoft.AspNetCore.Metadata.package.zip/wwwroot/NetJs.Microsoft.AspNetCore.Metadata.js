
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {"h":59619,"f":"Microsoft.AspNetCore.Metadata","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core metadata.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData", ($self) => class IAuthorizeData
        {
            static $h = 190691;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590125283,"f":50331905},"s":{"r":0,"d":0,"h":12885092579,"f":83886337},"n":"Policy","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy","d":190691,"h":4295157987,"f":2097409},{"p":1310721,"g":{"r":0,"d":0,"h":21475027171,"f":50331905},"s":{"r":0,"d":0,"h":25769994467,"f":83886337},"n":"Roles","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles","d":190691,"h":17180059875,"f":2097409},{"p":1310721,"g":{"r":0,"d":0,"h":34359929059,"f":50331905},"s":{"r":0,"d":0,"h":38654896355,"f":83886337},"n":"AuthenticationSchemes","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes","d":190691,"h":30064961763,"f":2097409}],"h":190691}; }
            static get $fullName() { return `IAuthorizeData`; }
        });
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous", ($self) => class IAllowAnonymous
        {
            static $h = 125155;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":125155}; }
            static get $fullName() { return `IAllowAnonymous`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))