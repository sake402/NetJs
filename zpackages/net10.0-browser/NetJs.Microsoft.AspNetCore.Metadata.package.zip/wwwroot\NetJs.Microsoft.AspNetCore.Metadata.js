
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.Metadata", 
    {"h":38854,"f":"Microsoft.AspNetCore.Metadata","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core metadata.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.Metadata","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAuthorizeData", ($self) => class IAuthorizeData
        {
            static $h = 169926;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590104518,"f":257},"s":{"r":0,"d":0,"h":12885071814,"f":257},"n":"Policy","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Policy","d":169926,"h":4295137222,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":21475006406,"f":257},"s":{"r":0,"d":0,"h":25769973702,"f":257},"n":"Roles","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$Roles","d":169926,"h":17180039110,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":34359908294,"f":257},"s":{"r":0,"d":0,"h":38654875590,"f":257},"n":"AuthenticationSchemes","o":"Microsoft$AspNetCore$Authorization$IAuthorizeData$AuthenticationSchemes","d":169926,"h":30064940998,"f":257}],"h":169926}; }
            static get $fullName() { return `IAuthorizeData`; }
        });
        
        $asm.$cls("$mam.Microsoft.AspNetCore.Authorization.IAllowAnonymous", ($self) => class IAllowAnonymous
        {
            static $h = 104390;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":104390}; }
            static get $fullName() { return `IAllowAnonymous`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))