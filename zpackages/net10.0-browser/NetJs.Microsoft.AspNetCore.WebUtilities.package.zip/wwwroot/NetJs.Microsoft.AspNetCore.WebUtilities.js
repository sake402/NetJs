
//--TRIMMABLE-BOUNDARY-START(123)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mnhh, $sipl, $stew) {
    "use strict";
    let _;
    let $CwnRxf;
    let $cComLf;
    let $GqWWll;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.WebUtilities", 
    {
  "h": 123,
  "f": "Microsoft.AspNetCore.WebUtilities",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "ASP.NET Core utilities, such as for working with forms, multipart messages, and query strings.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.WebUtilities",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.WebUtilities",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.WebUtilities.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.AspNetCore.WebUtilities.Microbenchmarks",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589947)
        $asm.$cls(`$maw.MAW.FileMultipartSection`, ($self) => class FileMultipartSection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557243)
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            //--TRIMMABLE-BOUNDARY-END(4295557243)
            
            //--TRIMMABLE-BOUNDARY-START(25770393723)
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.MAW.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393723);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393723)
            
            //--TRIMMABLE-BOUNDARY-START(21475426427)
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426427);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null || !$.$mnhh.MNHH.ContentDispositionHeaderValueIdentityExtensions.IsFileDisposition(header))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("Argument must be a file section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name).ToString();
                    this.FileName = $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.FileNameStar.HasValue ? this._contentDispositionHeader.FileNameStar : this._contentDispositionHeader.FileName).ToString();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426427)
            
            //--TRIMMABLE-BOUNDARY-START(77310001275)
            /*MultipartSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(77310001275)
            
            //--TRIMMABLE-BOUNDARY-START(34360328315)
            /*Stream? */ get FileStream()
            {
                return this.Section.Body;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328315)
            
            //--TRIMMABLE-BOUNDARY-START(73015033979)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73015033979)
            
            //--TRIMMABLE-BOUNDARY-START(30065361019)
            /*string*/ FileName = null;
            //--TRIMMABLE-BOUNDARY-END(30065361019)
            
            static $h = 589947;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310001275),
    {
      "p": 1310843,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066683,
        "f": 50331649
      },
      "n": "Section",
      "d": 589947,
      "h": 77310001275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310001275),
//--TRIMMABLE-BOUNDARY-START(34360328315),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197499,
        "f": 50331649
      },
      "n": "FileStream",
      "d": 589947,
      "h": 34360328315,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328315),
//--TRIMMABLE-BOUNDARY-START(73015033979),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132091,
        "f": 50331649
      },
      "n": "Name",
      "d": 589947,
      "h": 73015033979,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015033979),
//--TRIMMABLE-BOUNDARY-START(30065361019),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262907,
        "f": 50331649
      },
      "n": "FileName",
      "d": 589947,
      "h": 30065361019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065361019)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557243),
    {
      "t": 196730,
      "n": "_contentDispositionHeader",
      "d": 589947,
      "h": 4295557243,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557243)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770393723),
    {
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589947,
      "h": 25770393723,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393723),
//--TRIMMABLE-BOUNDARY-START(21475426427),
    {
      "p": [
        {
          "n": "section",
          "p": 1310843
        },
        {
          "n": "header",
          "p": 196730
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589947,
      "h": 21475426427,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426427)
  ],
  "h": 589947
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FileMultipartSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FileMultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589947)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031739)
        $asm.$cls(`$maw.MEWS.EncoderResources`, ($self) => class EncoderResources
        {
            //--TRIMMABLE-BOUNDARY-START(12886933627)
            /*string*/ static WebEncoders_InvalidCountOffsetOrLength = null;
            //--TRIMMABLE-BOUNDARY-END(12886933627)
            
            //--TRIMMABLE-BOUNDARY-START(17181900923)
            /*string*/ static WebEncoders_MalformedInput = null;
            //--TRIMMABLE-BOUNDARY-END(17181900923)
            
            //--TRIMMABLE-BOUNDARY-START(4296999035)
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ p0, /*object*/ p1, /*object*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296999035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$2($.$$.SG.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*WebEncoders_InvalidCountOffsetOrLength*/, p0, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(4296999035)
            
            //--TRIMMABLE-BOUNDARY-START(8591966331)
            static /*string */ FormatWebEncoders_MalformedInput(/*object*/ p0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$4($.$$.SG.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*WebEncoders_MalformedInput*/, p0);
            }
            //--TRIMMABLE-BOUNDARY-END(8591966331)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12886933627)
                    this.WebEncoders_InvalidCountOffsetOrLength = "Invalid {0}, {1} or {2} length.";
                    //--TRIMMABLE-BOUNDARY-END(12886933627)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181900923)
                    this.WebEncoders_MalformedInput = "Malformed input: {0} is an invalid input length.";
                    //--TRIMMABLE-BOUNDARY-END(17181900923)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2031739;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296999035),
    {
      "r": 1310721,
      "p": [
        {
          "n": "p0",
          "p": 131073
        },
        {
          "n": "p1",
          "p": 131073
        },
        {
          "n": "p2",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_InvalidCountOffsetOrLength",
      "d": 2031739,
      "h": 4296999035,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296999035),
//--TRIMMABLE-BOUNDARY-START(8591966331),
    {
      "r": 1310721,
      "p": [
        {
          "n": "p0",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_MalformedInput",
      "d": 2031739,
      "h": 8591966331,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591966331)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886933627),
    {
      "t": 1310721,
      "n": "WebEncoders_InvalidCountOffsetOrLength",
      "d": 2031739,
      "h": 12886933627,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886933627),
//--TRIMMABLE-BOUNDARY-START(17181900923),
    {
      "t": 1310721,
      "n": "WebEncoders_MalformedInput",
      "d": 2031739,
      "h": 17181900923,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181900923)
  ],
  "h": 2031739
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.WebEncoders.Sources.EncoderResources`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}WebEncoders${separator}Sources${separator}EncoderResources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031739)
        
        

        //--TRIMMABLE-BOUNDARY-START(262267)
        $asm.$cls(`$maw.MAS.ArgumentOutOfRangeThrowHelper`, ($self) => class ArgumentOutOfRangeThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(34360000635)
            static /*void */ ThrowIfZero(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfZero($.$$.S.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000635)
            
            //--TRIMMABLE-BOUNDARY-START(21475098747)
            static /*void */ ThrowIfNegative(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(21475098747)
            
            //--TRIMMABLE-BOUNDARY-START(25770066043)
            static /*void */ ThrowIfNegative$1(/*long*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int64, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(25770066043)
            
            //--TRIMMABLE-BOUNDARY-START(30065033339)
            static /*void */ ThrowIfNegativeOrZero(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(30065033339)
            
            //--TRIMMABLE-BOUNDARY-START(4295229563)
            static /*void */ ThrowIfGreaterThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229563)
            
            //--TRIMMABLE-BOUNDARY-START(8590196859)
            static /*void */ ThrowIfGreaterThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196859)
            
            //--TRIMMABLE-BOUNDARY-START(12885164155)
            static /*void */ ThrowIfLessThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThan(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164155)
            
            //--TRIMMABLE-BOUNDARY-START(17180131451)
            static /*void */ ThrowIfLessThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131451)
            
            static $h = 262267;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360000635),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfZero",
      "d": 262267,
      "h": 34360000635,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360000635),
//--TRIMMABLE-BOUNDARY-START(21475098747),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegative",
      "d": 262267,
      "h": 21475098747,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098747),
//--TRIMMABLE-BOUNDARY-START(25770066043),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegative",
      "o": "@$1",
      "d": 262267,
      "h": 25770066043,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770066043),
//--TRIMMABLE-BOUNDARY-START(30065033339),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegativeOrZero",
      "d": 262267,
      "h": 30065033339,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065033339),
//--TRIMMABLE-BOUNDARY-START(4295229563),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfGreaterThan",
      "d": 262267,
      "h": 4295229563,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295229563),
//--TRIMMABLE-BOUNDARY-START(8590196859),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfGreaterThanOrEqual",
      "d": 262267,
      "h": 8590196859,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590196859),
//--TRIMMABLE-BOUNDARY-START(12885164155),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfLessThan",
      "d": 262267,
      "h": 12885164155,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885164155),
//--TRIMMABLE-BOUNDARY-START(17180131451),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfLessThanOrEqual",
      "d": 262267,
      "h": 17180131451,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180131451)
  ],
  "h": 262267
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentOutOfRangeThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262267)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114235)
        $asm.$cls(`$maw.MAW.MultipartBoundary`, ($self) => class MultipartBoundary extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081531)
            /*byte[]*/ _boundaryBytes = null;
            //--TRIMMABLE-BOUNDARY-END(4296081531)
            
            //--TRIMMABLE-BOUNDARY-START(8591048827)
            /*bool*/ _expectLeadingCrlf = false;
            //--TRIMMABLE-BOUNDARY-END(8591048827)
            
            //--TRIMMABLE-BOUNDARY-START(17180983419)
            $ctor$1(/*string*/ boundary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180983419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._expectLeadingCrlf = false;
                    this._boundaryBytes = $.$$.ST.Encoding.UTF8.GetBytes$8("\r\n--" + $.$strNN(boundary));
                    this.FinalBoundaryLength = ((this.BoundaryBytes.Length + 2) | 0);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983419)
            
            //--TRIMMABLE-BOUNDARY-START(30065885307)
            /*void */ ExpectLeadingCrlf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._expectLeadingCrlf = true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885307)
            
            //--TRIMMABLE-BOUNDARY-START(21475950715)
            /*bool */ BeforeFirstBoundary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._expectLeadingCrlf;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950715)
            
            //--TRIMMABLE-BOUNDARY-START(25770918011)
            /*ReadOnlySpan<byte> */ get BoundaryBytes()
            {
                return $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Byte, this._boundaryBytes, this._expectLeadingCrlf ? 0 : 2));
            }
            //--TRIMMABLE-BOUNDARY-END(25770918011)
            
            //--TRIMMABLE-BOUNDARY-START(34360852603)
            /*int*/ FinalBoundaryLength = 0;
            //--TRIMMABLE-BOUNDARY-END(34360852603)
            
            static $h = 1114235;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770918011),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787195,
        "f": 50331649
      },
      "n": "BoundaryBytes",
      "d": 1114235,
      "h": 25770918011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770918011),
//--TRIMMABLE-BOUNDARY-START(34360852603),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721787,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130656379,
        "f": 83886082
      },
      "n": "FinalBoundaryLength",
      "d": 1114235,
      "h": 34360852603,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360852603)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065885307),
    {
      "r": 65537,
      "n": "ExpectLeadingCrlf",
      "d": 1114235,
      "h": 30065885307,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065885307),
//--TRIMMABLE-BOUNDARY-START(21475950715),
    {
      "r": 262145,
      "n": "BeforeFirstBoundary",
      "d": 1114235,
      "h": 21475950715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475950715)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081531),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_boundaryBytes",
      "d": 1114235,
      "h": 4296081531,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081531),
//--TRIMMABLE-BOUNDARY-START(8591048827),
    {
      "t": 262145,
      "n": "_expectLeadingCrlf",
      "d": 1114235,
      "h": 8591048827,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048827)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983419),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114235,
      "h": 17180983419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983419)
  ],
  "h": 1114235
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartBoundary`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartBoundary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114235)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097275)
        $asm.$cls(`$maw.Resources`, ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(124556148859)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(124556148859)
            
            //--TRIMMABLE-BOUNDARY-START(115966214267)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(115966214267)
            
            //--TRIMMABLE-BOUNDARY-START(120261181563)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491377787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$maw.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.AspNetCore.WebUtilities", $.$maw.Resources.$type.Assembly);
                    $.$maw.Resources.s_resourceManager = temp;
                }
                return $.$maw.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(120261181563)
            
            //--TRIMMABLE-BOUNDARY-START(4297064571)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951770235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146083451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064571)
            
            //--TRIMMABLE-BOUNDARY-START(25771901051)
            static /*string */ get FormPipeReader_KeyOrValueTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541704827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form key length limit {0} or value length limit {1} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771901051)
            
            //--TRIMMABLE-BOUNDARY-START(8592031867)
            static /*string */ FormatFormPipeReader_KeyOrValueTooLarge(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Form key length limit {0} or value length limit {1} exceeded.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(8592031867)
            
            //--TRIMMABLE-BOUNDARY-START(30066868347)
            static /*string */ get FormPipeReader_KeyTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131639419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form key length limit {0} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066868347)
            
            //--TRIMMABLE-BOUNDARY-START(12886999163)
            static /*string */ FormatFormPipeReader_KeyTooLarge(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886999163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Form key length limit {0} exceeded.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(12886999163)
            
            //--TRIMMABLE-BOUNDARY-START(34361835643)
            static /*string */ get FormPipeReader_ValueTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721574011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form value length limit {0} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361835643)
            
            //--TRIMMABLE-BOUNDARY-START(17181966459)
            static /*string */ FormatFormPipeReader_ValueTooLarge(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181966459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Form value length limit {0} exceeded.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(17181966459)
            
            //--TRIMMABLE-BOUNDARY-START(107376279675)
            static /*string */ get HttpRequestStreamReader_StreamNotReadable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311508603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The stream must support reading.";
            }
            //--TRIMMABLE-BOUNDARY-END(107376279675)
            
            //--TRIMMABLE-BOUNDARY-START(111671246971)
            static /*string */ get HttpResponseStreamWriter_StreamNotWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901443195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The stream must support writing.";
            }
            //--TRIMMABLE-BOUNDARY-END(111671246971)
            
            //--TRIMMABLE-BOUNDARY-START(137441050747)
            static /*string */ get WebEncoders_InvalidCountOffsetOrLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081312379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid {0}, {1} or {2} length.";
            }
            //--TRIMMABLE-BOUNDARY-END(137441050747)
            
            //--TRIMMABLE-BOUNDARY-START(21476933755)
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Invalid {0}, {1} or {2} length.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(21476933755)
            
            static $h = 2097275;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261181563),
    {
      "p": 123535361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491377787,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 2097275,
      "h": 120261181563,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261181563),
//--TRIMMABLE-BOUNDARY-START(4297064571),
    {
      "p": 84738049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951770235,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146083451,
        "f": 83886120
      },
      "n": "Culture",
      "d": 2097275,
      "h": 4297064571,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297064571),
//--TRIMMABLE-BOUNDARY-START(25771901051),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541704827,
        "f": 50331688
      },
      "n": "FormPipeReader_KeyOrValueTooLarge",
      "d": 2097275,
      "h": 25771901051,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25771901051),
//--TRIMMABLE-BOUNDARY-START(30066868347),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131639419,
        "f": 50331688
      },
      "n": "FormPipeReader_KeyTooLarge",
      "d": 2097275,
      "h": 30066868347,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(30066868347),
//--TRIMMABLE-BOUNDARY-START(34361835643),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721574011,
        "f": 50331688
      },
      "n": "FormPipeReader_ValueTooLarge",
      "d": 2097275,
      "h": 34361835643,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34361835643),
//--TRIMMABLE-BOUNDARY-START(107376279675),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311508603,
        "f": 50331688
      },
      "n": "HttpRequestStreamReader_StreamNotReadable",
      "d": 2097275,
      "h": 107376279675,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(107376279675),
//--TRIMMABLE-BOUNDARY-START(111671246971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901443195,
        "f": 50331688
      },
      "n": "HttpResponseStreamWriter_StreamNotWritable",
      "d": 2097275,
      "h": 111671246971,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111671246971),
//--TRIMMABLE-BOUNDARY-START(137441050747),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081312379,
        "f": 50331688
      },
      "n": "WebEncoders_InvalidCountOffsetOrLength",
      "d": 2097275,
      "h": 137441050747,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(137441050747)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592031867),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_KeyOrValueTooLarge",
      "d": 2097275,
      "h": 8592031867,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592031867),
//--TRIMMABLE-BOUNDARY-START(12886999163),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_KeyTooLarge",
      "d": 2097275,
      "h": 12886999163,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886999163),
//--TRIMMABLE-BOUNDARY-START(17181966459),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_ValueTooLarge",
      "d": 2097275,
      "h": 17181966459,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181966459),
//--TRIMMABLE-BOUNDARY-START(21476933755),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        },
        {
          "n": "arg3",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_InvalidCountOffsetOrLength",
      "d": 2097275,
      "h": 21476933755,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476933755)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124556148859),
    {
      "t": 123535361,
      "n": "s_resourceManager",
      "d": 2097275,
      "h": 124556148859,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124556148859),
//--TRIMMABLE-BOUNDARY-START(115966214267),
    {
      "t": 84738049,
      "n": "resourceCulture",
      "d": 2097275,
      "h": 115966214267,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(115966214267)
  ],
  "h": 2097275,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71237633,
      "c": 4366204929
    },
    {
      "t": 126550017,
      "c": 4421517313
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Resources`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097275)
        
        

        //--TRIMMABLE-BOUNDARY-START(655483)
        $asm.$cls(`$maw.MAW.FormMultipartSection`, ($self) => class FormMultipartSection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622779)
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            //--TRIMMABLE-BOUNDARY-END(4295622779)
            
            //--TRIMMABLE-BOUNDARY-START(21475491963)
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.MAW.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475491963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475491963)
            
            //--TRIMMABLE-BOUNDARY-START(17180524667)
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180524667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null || !$.$mnhh.MNHH.ContentDispositionHeaderValueIdentityExtensions.IsFormDisposition(header))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("Argument must be a form section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name).ToString();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524667)
            
            //--TRIMMABLE-BOUNDARY-START(55835230331)
            /*MultipartSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(55835230331)
            
            //--TRIMMABLE-BOUNDARY-START(51540263035)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51540263035)
            
            //--TRIMMABLE-BOUNDARY-START(42950328443)
            /*Task<string> */ GetValueAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950328443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.MAW.MultipartSectionStreamExtensions.ReadAsStringAsync$1(this.Section);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950328443)
            
            //--TRIMMABLE-BOUNDARY-START(47245295739)
            /*ValueTask<string> */ GetValueAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245295739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.MAW.MultipartSectionStreamExtensions.ReadAsStringAsync(this.Section, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245295739)
            
            static $h = 655483;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835230331),
    {
      "p": 1310843,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361147,
        "f": 50331649
      },
      "n": "Section",
      "d": 655483,
      "h": 55835230331,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230331),
//--TRIMMABLE-BOUNDARY-START(51540263035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426555,
        "f": 50331649
      },
      "n": "Name",
      "d": 655483,
      "h": 51540263035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540263035)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950328443),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "n": "GetValueAsync",
      "d": 655483,
      "h": 42950328443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328443),
//--TRIMMABLE-BOUNDARY-START(47245295739),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.String).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 655483,
      "h": 47245295739,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295739)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622779),
    {
      "t": 196730,
      "n": "_contentDispositionHeader",
      "d": 655483,
      "h": 4295622779,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491963),
    {
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655483,
      "h": 21475491963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491963),
//--TRIMMABLE-BOUNDARY-START(17180524667),
    {
      "p": [
        {
          "n": "section",
          "p": 1310843
        },
        {
          "n": "header",
          "p": 196730
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655483,
      "h": 17180524667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524667)
  ],
  "h": 655483
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FormMultipartSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FormMultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655483)
        
        

        //--TRIMMABLE-BOUNDARY-START(327803)
        $asm.$cls(`$maw.MAW.Base64UrlTextEncoder`, ($self) => class Base64UrlTextEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(8590262395)
            static /*string */ Encode(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.MAW.WebEncoders.Base64UrlEncode$2(data);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262395)
            
            //--TRIMMABLE-BOUNDARY-START(4295295099)
            static /*byte[] */ Decode(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.MAW.WebEncoders.Base64UrlDecode$2(text);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295099)
            
            static $h = 327803;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262395),
    {
      "r": 1310721,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Encode",
      "d": 327803,
      "h": 8590262395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590262395),
//--TRIMMABLE-BOUNDARY-START(4295295099),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "Decode",
      "d": 327803,
      "h": 4295295099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295295099)
  ],
  "h": 327803
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.Base64UrlTextEncoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}Base64UrlTextEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327803)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376379)
        $asm.$cls(`$maw.MAW.MultipartSectionConverterExtensions`, ($self) => class MultipartSectionConverterExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296343675)
            static /*FileMultipartSection? */ AsFileSection(/*this MultipartSection*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.MAW.FileMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343675)
            
            //--TRIMMABLE-BOUNDARY-START(8591310971)
            static /*FormMultipartSection? */ AsFormDataSection(/*this MultipartSection*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.MAW.FormMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591310971)
            
            //--TRIMMABLE-BOUNDARY-START(12886278267)
            static /*ContentDispositionHeaderValue? */ GetContentDispositionHeader(/*this MultipartSection*/ section)
            {
                /*var*/ let header;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$mnhh.MNHH.ContentDispositionHeaderValue.TryParse($.$mep.MEP.StringSegment.op_Implicit$2(section.ContentDisposition), $.$ref(() => header, ($v) => header = $v, $.$mnhh.MNHH.ContentDispositionHeaderValue)))
                {
                    return null;
                }
                return header;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278267)
            
            static $h = 1376379;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343675),
    {
      "r": 589947,
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": "AsFileSection",
      "d": 1376379,
      "h": 4296343675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296343675),
//--TRIMMABLE-BOUNDARY-START(8591310971),
    {
      "r": 655483,
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": "AsFormDataSection",
      "d": 1376379,
      "h": 8591310971,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591310971),
//--TRIMMABLE-BOUNDARY-START(12886278267),
    {
      "r": 196730,
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": "GetContentDispositionHeader",
      "d": 1376379,
      "h": 12886278267,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886278267)
  ],
  "h": 1376379
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartSectionConverterExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376379)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310843)
        $asm.$cls(`$maw.MAW.MultipartSection`, ($self) => class MultipartSection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361049211)
            /*string? */ get ContentType()
            {
                /*var*/ let values;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.MNHH.HeaderNames.ContentType, $.$ref(() => values, ($v) => values = $v, $.$mep.MEP.StringValues)))
                {
                    return $.$mep.MEP.StringValues.op_Implicit(values);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049211)
            
            //--TRIMMABLE-BOUNDARY-START(30066081915)
            /*string? */ get ContentDisposition()
            {
                /*var*/ let values;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.MNHH.HeaderNames.ContentDisposition, $.$ref(() => values, ($v) => values = $v, $.$mep.MEP.StringValues)))
                {
                    return $.$mep.MEP.StringValues.op_Implicit(values);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081915)
            
            //--TRIMMABLE-BOUNDARY-START(81605689467)
            /*Dictionary<string, StringValues>?*/ Headers = null;
            //--TRIMMABLE-BOUNDARY-END(81605689467)
            
            //--TRIMMABLE-BOUNDARY-START(25771114619)
            /*Stream*/ Body = null;
            //--TRIMMABLE-BOUNDARY-END(25771114619)
            
            //--TRIMMABLE-BOUNDARY-START(21476147323)
            /*long?*/ BaseStreamOffset = null;
            //--TRIMMABLE-BOUNDARY-END(21476147323)
            
            //--TRIMMABLE-BOUNDARY-START(17181180027)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181180027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181180027)
            
            //--TRIMMABLE-BOUNDARY-START(17181180027)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181180027)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771114619)
                this.Body = null;
                //--TRIMMABLE-BOUNDARY-END(25771114619)
                
            }
            static $h = 1310843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049211),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720787579,
        "f": 50331649
      },
      "n": "ContentType",
      "d": 1310843,
      "h": 34361049211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049211),
//--TRIMMABLE-BOUNDARY-START(30066081915),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130852987,
        "f": 50331649
      },
      "n": "ContentDisposition",
      "d": 1310843,
      "h": 30066081915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081915),
//--TRIMMABLE-BOUNDARY-START(81605689467),
    {
      "p": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310722171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375493243,
        "f": 83886081
      },
      "n": "Headers",
      "d": 1310843,
      "h": 81605689467,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605689467),
//--TRIMMABLE-BOUNDARY-START(25771114619),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918395,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785558651,
        "f": 83886081
      },
      "n": "Body",
      "d": 1310843,
      "h": 25771114619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771114619),
//--TRIMMABLE-BOUNDARY-START(21476147323),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195624059,
        "f": 83886081
      },
      "n": "BaseStreamOffset",
      "d": 1310843,
      "h": 21476147323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476147323)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181180027),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310843,
      "h": 17181180027,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181180027)
  ],
  "h": 1310843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310843)
        
        

        //--TRIMMABLE-BOUNDARY-START(196731)
        $asm.$cls(`$maw.MAS.ArgumentNullThrowHelper`, ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295164027)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164027)
            
            //--TRIMMABLE-BOUNDARY-START(8590131323)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131323)
            
            static $h = 196731;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164027),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 196731,
      "h": 4295164027,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164027),
//--TRIMMABLE-BOUNDARY-START(8590131323),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 196731,
      "h": 8590131323,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131323)
  ],
  "h": 196731
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196731)
        
        

        //--TRIMMABLE-BOUNDARY-START(65659)
        $asm.$cls(`$maw.MAI.AspNetCoreTempDirectory`, ($self) => class AspNetCoreTempDirectory
        {
            //--TRIMMABLE-BOUNDARY-START(4295032955)
            /*string?*/ static _tempDirectory = null;
            //--TRIMMABLE-BOUNDARY-END(4295032955)
            
            //--TRIMMABLE-BOUNDARY-START(25769869435)
            static /*string */ get TempDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$maw.MAI.AspNetCoreTempDirectory._tempDirectory === null)
                {
                    /*var*/ let temp = $.$$.S.Environment.GetEnvironmentVariable$1("ASPNETCORE_TEMP") ?? $.$$.SI.Path.GetTempPath();
                    if (!$.$$.SI.Directory.Exists(temp))
                    {
                        throw new $.$$.SI.DirectoryNotFoundException().$ctor$17(temp);
                    }
                    $.$maw.MAI.AspNetCoreTempDirectory._tempDirectory = temp;
                }
                return $.$maw.MAI.AspNetCoreTempDirectory._tempDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869435)
            
            //--TRIMMABLE-BOUNDARY-START(30064836731)
            static /*Func<string> */ get TempDirectoryFactory()
            {
                return new ($.$$.S.Func$$($.$$.S.String))().$ctor(this,  () =>
                {
                    return $.$maw.MAI.AspNetCoreTempDirectory.TempDirectory;
                }, $CwnRxf ??= {"r":1310721,"n":"","d":65659,"h":0,"f":17825794});
            }
            //--TRIMMABLE-BOUNDARY-END(30064836731)
            
            static $h = 65659;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769869435),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884967547,
        "f": 50331681
      },
      "n": "TempDirectory",
      "d": 65659,
      "h": 25769869435,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25769869435),
//--TRIMMABLE-BOUNDARY-START(30064836731),
    {
      "p": $.$$.S.Func$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902139,
        "f": 50331681
      },
      "n": "TempDirectoryFactory",
      "d": 65659,
      "h": 30064836731,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836731)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032955),
    {
      "t": 1310721,
      "n": "_tempDirectory",
      "d": 65659,
      "h": 4295032955,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032955)
  ],
  "h": 65659
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Internal${separator}AspNetCoreTempDirectory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65659)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900667)
        $asm.$cls(`$maw.MAW.StreamHelperExtensions`, ($self) => class StreamHelperExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296867963)
            /*int*/ static _maxReadBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(4296867963)
            
            //--TRIMMABLE-BOUNDARY-START(17181769851)
            static /*Task */ DrainAsync$2(/*this Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.MAW.StreamHelperExtensions.DrainAsync(stream, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(17181769851)
            
            //--TRIMMABLE-BOUNDARY-START(12886802555)
            static /*Task */ DrainAsync$1(/*this Stream*/ stream, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886802555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.MAW.StreamHelperExtensions.DrainAsync(stream, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, limit, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(12886802555)
            
            //--TRIMMABLE-BOUNDARY-START(8591835259)
            static /*Task *//*async*/  DrainAsync(/*this Stream*/ stream, /*ArrayPool<byte>*/ bytePool, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    /*var*/ let buffer = bytePool.Rent(4096/*_maxReadBufferSize*/);
                    /*long*/ let total = 0n;
                    try
                    {
                        let $t1, $r1;
                        /*var*/ let read = ($t1 = stream.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$12($.$$.S.Byte, buffer), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        while(read > 0)
                        {
                            let $t2, $r2;
                            cancellationToken.ThrowIfCancellationRequested();
                            if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(limit) && BigInt.asIntN(64, $.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(limit) - total) < BigInt(read))
                            {
                                throw new $.$$.SI.InvalidDataException().$ctor$12(`The stream exceeded the data limit ${$.$strNN($.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(limit))}.`);
                            }
                            total += BigInt(read);
                            read = ($t2 = stream.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$12($.$$.S.Byte, buffer), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                    }
                    finally
                    {
                        {
                            bytePool.Return(buffer, false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591835259)
            
            static $h = 1900667;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181769851),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "DrainAsync",
      "o": "@$2",
      "d": 1900667,
      "h": 17181769851,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181769851),
//--TRIMMABLE-BOUNDARY-START(12886802555),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "limit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "DrainAsync",
      "o": "@$1",
      "d": 1900667,
      "h": 12886802555,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886802555),
//--TRIMMABLE-BOUNDARY-START(8591835259),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        },
        {
          "n": "limit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "DrainAsync",
      "d": 1900667,
      "h": 8591835259,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(8591835259)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867963),
    {
      "t": 655361,
      "n": "_maxReadBufferSize",
      "d": 1900667,
      "h": 4296867963,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296867963)
  ],
  "h": 1900667
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}StreamHelperExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900667)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835131)
        $asm.$cls(`$maw.MAW.ReasonPhrases`, ($self) => class ReasonPhrases
        {
            //--TRIMMABLE-BOUNDARY-START(12886737019)
            /*string[][]*/ static HttpReasonPhrases = null;
            //--TRIMMABLE-BOUNDARY-END(12886737019)
            
            //--TRIMMABLE-BOUNDARY-START(8591769723)
            static /*string */ GetReasonPhrase(/*int*/ statusCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((statusCode - 100) | 0)) >>> 0) < 500)
                {
                    /*var*/ let  [ i, j ] = $.$destructure($.$$.S.Math.DivRem$9((statusCode >>> 0), 100), 2);
                    /*string[]*/ let phrases = $.$$.System.Array.$ReadT1.call($.$maw.MAW.ReasonPhrases.HttpReasonPhrases, i);
                    if (j < (phrases.length >>> 0))
                    {
                        return $.$$.System.Array.$ReadT1.call(phrases, j);
                    }
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769723)
            
            //--TRIMMABLE-BOUNDARY-START(4296802427)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886737019)
                    this.HttpReasonPhrases = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeArray($.$$.S.String).$type, [ $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [  ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Continue", "Switching Protocols", "Processing" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "OK", "Created", "Accepted", "Non-Authoritative Information", "No Content", "Reset Content", "Partial Content", "Multi-Status", "Already Reported", $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, "IM Used" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Multiple Choices", "Moved Permanently", "Found", "See Other", "Not Modified", "Use Proxy", "Switch Proxy", "Temporary Redirect", "Permanent Redirect" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Bad Request", "Unauthorized", "Payment Required", "Forbidden", "Not Found", "Method Not Allowed", "Not Acceptable", "Proxy Authentication Required", "Request Timeout", "Conflict", "Gone", "Length Required", "Precondition Failed", "Payload Too Large", "URI Too Long", "Unsupported Media Type", "Range Not Satisfiable", "Expectation Failed", "I'm a teapot", "Authentication Timeout", $.$$.S.String.Empty, "Misdirected Request", "Unprocessable Entity", "Locked", "Failed Dependency", $.$$.S.String.Empty, "Upgrade Required", $.$$.S.String.Empty, "Precondition Required", "Too Many Requests", $.$$.S.String.Empty, "Request Header Fields Too Large", $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, "Unavailable For Legal Reasons", $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, $.$$.S.String.Empty, "Client Closed Request" ], null, null), $.$$.SRC.RuntimeHelpers.CreateArray($.$$.S.String.$type, [ "Internal Server Error", "Not Implemented", "Bad Gateway", "Service Unavailable", "Gateway Timeout", "HTTP Version Not Supported", "Variant Also Negotiates", "Insufficient Storage", "Loop Detected", $.$$.S.String.Empty, "Not Extended", "Network Authentication Required" ], null, null) ], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12886737019)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802427)
            
            static $h = 1835131;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591769723),
    {
      "r": 1310721,
      "p": [
        {
          "n": "statusCode",
          "p": 655361
        }
      ],
      "n": "GetReasonPhrase",
      "d": 1835131,
      "h": 8591769723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591769723)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886737019),
    {
      "t": $.$typeArray($.$typeArray($.$$.S.String)).$h,
      "n": "HttpReasonPhrases",
      "d": 1835131,
      "h": 12886737019,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886737019)
  ],
  "h": 1835131
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.ReasonPhrases`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}ReasonPhrases`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835131)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179771)
        $asm.$cls(`$maw.MAW.MultipartReader`, ($self) => class MultipartReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245820027)
            /*int*/ static DefaultHeadersCountLimit = 16;
            //--TRIMMABLE-BOUNDARY-END(47245820027)
            
            //--TRIMMABLE-BOUNDARY-START(51540787323)
            /*int*/ static DefaultHeadersLengthLimit = 16384;
            //--TRIMMABLE-BOUNDARY-END(51540787323)
            
            //--TRIMMABLE-BOUNDARY-START(42950852731)
            /*int*/ static DefaultBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(42950852731)
            
            //--TRIMMABLE-BOUNDARY-START(12886081659)
            /*BufferedReadStream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(12886081659)
            
            //--TRIMMABLE-BOUNDARY-START(4296147067)
            /*MultipartBoundary*/ _boundary = null;
            //--TRIMMABLE-BOUNDARY-END(4296147067)
            
            //--TRIMMABLE-BOUNDARY-START(8591114363)
            /*MultipartReaderStream?*/ _currentStream = null;
            //--TRIMMABLE-BOUNDARY-END(8591114363)
            
            //--TRIMMABLE-BOUNDARY-START(34360918139)
            $ctor$2(/*string*/ boundary, /*Stream*/ stream)
            {
                this.$ctor$1(boundary, stream, 4096/*DefaultBufferSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360918139)
            
            //--TRIMMABLE-BOUNDARY-START(30065950843)
            $ctor$1(/*string*/ boundary, /*Stream*/ stream, /*int*/ bufferSize)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065950843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (bufferSize < ((boundary.length + 8) | 0))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("bufferSize", $.$box(bufferSize, $.$$.S.Int32), "Insufficient buffer space, the buffer must be larger than the boundary: " + $.$strNN(boundary));
                    }
                    this._stream = new $.$maw.MAW.BufferedReadStream().$ctor$4(stream, bufferSize);
                    boundary = $.$mnhh.MNHH.HeaderUtilities.RemoveQuotes(new $.$mep.MEP.StringSegment().$ctor$4(boundary)).ToString();
                    this._boundary = new $.$maw.MAW.MultipartBoundary().$ctor$1(boundary);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950843)
            
            //--TRIMMABLE-BOUNDARY-START(81605558395)
            /*int*/ HeadersCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(81605558395)
            
            //--TRIMMABLE-BOUNDARY-START(85900525691)
            /*int*/ HeadersLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(85900525691)
            
            //--TRIMMABLE-BOUNDARY-START(38655885435)
            /*long?*/ BodyLengthLimit = null;
            //--TRIMMABLE-BOUNDARY-END(38655885435)
            
            //--TRIMMABLE-BOUNDARY-START(94490460283)
            /*Task<MultipartSection?> *//*async*/  ReadNextSectionAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$maw.MAW.MultipartSection), $.$maw.MAW.MultipartSection, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    let $t4, $r4;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490460283);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._currentStream ??= (() =>
                    {
                        //new $.$maw.MAW.MultipartReaderStream()
                        const $t1 = $.$maw.MAW.MultipartReaderStream;
                        const $i1 = new $t1();
                        $i1.$ctor$4(this._stream, this._boundary);
                        $i1.LengthLimit = this.HeadersLengthLimit;
                        return $i1;
                    })();
                    ($t2 = $.$maw.MAW.StreamHelperExtensions.DrainAsync$2(this._currentStream, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if (this._currentStream.FinalBoundaryFound)
                    {
                        let $t3, $r3;
                        ($t3 = $.$maw.MAW.StreamHelperExtensions.DrainAsync$1(this._stream, this.HeadersLengthLimit, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    /*var*/ let headers = ($t4 = this.ReadHeadersAsync(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                    this._boundary.ExpectLeadingCrlf();
                    this._currentStream = (() =>
                    {
                        //new $.$maw.MAW.MultipartReaderStream()
                        const $t5 = $.$maw.MAW.MultipartReaderStream;
                        const $i5 = new $t5();
                        $i5.$ctor$4(this._stream, this._boundary);
                        $i5.LengthLimit = this.BodyLengthLimit;
                        return $i5;
                    })();
                    /*long?*/ let baseStreamOffset = this._stream.CanSeek ? $.$cast(this._stream.Position, $.$$.S.Nullable$$($.$$.S.Int64)) : null;
                    return $.$$.N.AsyncResolver.Result($asnycContext, (() =>
                    {
                        //new $.$maw.MAW.MultipartSection()
                        const $t6 = $.$maw.MAW.MultipartSection;
                        const $i6 = new $t6();
                        $i6.$ctor$1();
                        $i6.Headers = headers;
                        $i6.Body = this._currentStream;
                        $i6.BaseStreamOffset = baseStreamOffset;
                        return $i6;
                    })());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490460283)
            
            //--TRIMMABLE-BOUNDARY-START(90195492987)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadHeadersAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)), $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues), async ($asnycContext) => 
                {
                    let $t7, $r7;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195492987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*int*/ let totalSize = 0;
                    /*var*/ let accumulator = new $.$maw.MAW.KeyValueAccumulator().$ctor$2();
                    /*var*/ let line = ($t7 = this._stream.ReadLineAsync(this.HeadersLengthLimit, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                    while(!$.$$.S.String.IsNullOrEmpty(line))
                    {
                        let $t8, $r8;
                        if (((this.HeadersLengthLimit - totalSize) | 0) < line.length)
                        {
                            throw new $.$$.SI.InvalidDataException().$ctor$12(`Multipart headers length limit ${$.$strNN(this.HeadersLengthLimit)} exceeded.`);
                        }
                        totalSize += line.length;
                        /*int*/ let splitIndex = $.$$.S.String.IndexOf$3.call(line, /*:*/ 58);
                        if (splitIndex <= 0)
                        {
                            throw new $.$$.SI.InvalidDataException().$ctor$12(`Invalid header line: ${$.$strNN(line)}`);
                        }
                        /*var*/ let name = line.substr(0, splitIndex);
                        /*var*/ let value = line.substr(((splitIndex + 1) | 0), ((((line.length - splitIndex) | 0) - 1) | 0)).trim();
                        accumulator.Append(name, value);
                        if (accumulator.KeyCount > this.HeadersCountLimit)
                        {
                            throw new $.$$.SI.InvalidDataException().$ctor$12(`Multipart headers count limit ${$.$strNN(this.HeadersCountLimit)} exceeded.`);
                        }
                        line = ($t8 = this._stream.ReadLineAsync(((this.HeadersLengthLimit - totalSize) | 0), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, accumulator.GetResults());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195492987)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(81605558395)
                this.HeadersCountLimit = 16;
                //--TRIMMABLE-BOUNDARY-END(81605558395)
                
                //--TRIMMABLE-BOUNDARY-START(85900525691)
                this.HeadersLengthLimit = 16384;
                //--TRIMMABLE-BOUNDARY-END(85900525691)
                
            }
            static $h = 1179771;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605558395),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670329467,
        "f": 83886081
      },
      "n": "HeadersCountLimit",
      "d": 1179771,
      "h": 81605558395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605558395),
//--TRIMMABLE-BOUNDARY-START(85900525691),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310591099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260264059,
        "f": 83886081
      },
      "n": "HeadersLengthLimit",
      "d": 1179771,
      "h": 85900525691,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900525691),
//--TRIMMABLE-BOUNDARY-START(38655885435),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080394875,
        "f": 83886081
      },
      "n": "BodyLengthLimit",
      "d": 1179771,
      "h": 38655885435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655885435)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490460283),
    {
      "r": $.$$.STT.Task$$($.$maw.MAW.MultipartSection).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadNextSectionAsync",
      "d": 1179771,
      "h": 94490460283,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(94490460283),
//--TRIMMABLE-BOUNDARY-START(90195492987),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadHeadersAsync",
      "d": 1179771,
      "h": 90195492987,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90195492987)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245820027),
    {
      "t": 655361,
      "n": "DefaultHeadersCountLimit",
      "d": 1179771,
      "h": 47245820027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245820027),
//--TRIMMABLE-BOUNDARY-START(51540787323),
    {
      "t": 655361,
      "n": "DefaultHeadersLengthLimit",
      "d": 1179771,
      "h": 51540787323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540787323),
//--TRIMMABLE-BOUNDARY-START(42950852731),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 1179771,
      "h": 42950852731,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42950852731),
//--TRIMMABLE-BOUNDARY-START(12886081659),
    {
      "t": 393339,
      "n": "_stream",
      "d": 1179771,
      "h": 12886081659,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081659),
//--TRIMMABLE-BOUNDARY-START(4296147067),
    {
      "t": 1114235,
      "n": "_boundary",
      "d": 1179771,
      "h": 4296147067,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147067),
//--TRIMMABLE-BOUNDARY-START(8591114363),
    {
      "t": 1245307,
      "n": "_currentStream",
      "d": 1179771,
      "h": 8591114363,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114363)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360918139),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179771,
      "h": 34360918139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918139),
//--TRIMMABLE-BOUNDARY-START(30065950843),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179771,
      "h": 30065950843,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065950843)
  ],
  "h": 1179771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179771)
        
        

        //--TRIMMABLE-BOUNDARY-START(131195)
        $asm.$cls(`$maw.MAI.UrlDecoder`, ($self) => class UrlDecoder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34359869563)
            static /*int */ DecodeRequestLine(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < source.Length)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13("Length of the destination byte span is less than the source.", "destination");
                }
                source.CopyTo(destination);
                return $.$maw.MAI.UrlDecoder.DecodeInPlace(destination.Slice(0, source.Length), isFormEncoding);
            }
            //--TRIMMABLE-BOUNDARY-END(34359869563)
            
            //--TRIMMABLE-BOUNDARY-START(25769934971)
            static /*int */ DecodeInPlace(/*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sourceIndex = 0;
                /*var*/ let destinationIndex = 0;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer._reference.GetAt(sourceIndex) === /*+*/ 43 && isFormEncoding)
                    {
                        buffer._reference.SetAt(32, sourceIndex);
                    }
                    else if (buffer._reference.GetAt(sourceIndex) === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.MAI.UrlDecoder.DecodeCore($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.S.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.S.Int32), buffer, isFormEncoding))
                        {
                            $.$maw.MAI.UrlDecoder.Copy($.$$.S.Byte, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.S.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer._reference.SetAt(buffer._reference.GetAt(sourceIndex++), destinationIndex++);
                    }
                }
                return destinationIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934971)
            
            //--TRIMMABLE-BOUNDARY-START(17180000379)
            static /*bool */ DecodeCore(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let byte1 = $.$maw.MAI.UrlDecoder.UnescapePercentEncoding$1(sourceIndex, buffer, isFormEncoding);
                if (byte1 === -1)
                {
                    return false;
                }
                if (byte1 === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (byte1 <= 127)
                {
                    buffer._reference.SetAt($.$cast(byte1, $.$$.S.Byte), destinationIndex.$v++);
                    return true;
                }
                /*int*/ let byte2 = 0, byte3 = 0, byte4 = 0;
                /*int*/ let currentDecodeBits;
                /*int*/ let byteCount;
                /*int*/ let expectValueMin;
                if ((byte1 & 224) === 192)
                {
                    currentDecodeBits = byte1 & 31;
                    byteCount = 2;
                    expectValueMin = 128;
                }
                else if ((byte1 & 240) === 224)
                {
                    currentDecodeBits = byte1 & 15;
                    byteCount = 3;
                    expectValueMin = 2048;
                }
                else if ((byte1 & 248) === 240)
                {
                    currentDecodeBits = byte1 & 7;
                    byteCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingBytes = ((byteCount - 1) | 0);
                while(remainingBytes > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextByte = $.$maw.MAI.UrlDecoder.UnescapePercentEncoding$1($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.S.Int32), buffer, isFormEncoding);
                    if (nextByte === -1)
                    {
                        return false;
                    }
                    if ((nextByte & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextByte & 63);
                    remainingBytes--;
                    if (remainingBytes === 1 && currentDecodeBits >= 864 && currentDecodeBits <= 895)
                    {
                        return false;
                    }
                    if (remainingBytes === 2 && currentDecodeBits >= 272)
                    {
                        return false;
                    }
                    sourceIndex.$v = nextSourceIndex;
                    if (((byteCount - remainingBytes) | 0) === 2)
                    {
                        byte2 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 3)
                    {
                        byte3 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 4)
                    {
                        byte4 = nextByte;
                    }
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                if (byteCount > 0)
                {
                    buffer._reference.SetAt($.$cast(byte1, $.$$.S.Byte), destinationIndex.$v++);
                }
                if (byteCount > 1)
                {
                    buffer._reference.SetAt($.$cast(byte2, $.$$.S.Byte), destinationIndex.$v++);
                }
                if (byteCount > 2)
                {
                    buffer._reference.SetAt($.$cast(byte3, $.$$.S.Byte), destinationIndex.$v++);
                }
                if (byteCount > 3)
                {
                    buffer._reference.SetAt($.$cast(byte4, $.$$.S.Byte), destinationIndex.$v++);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000379)
            
            //--TRIMMABLE-BOUNDARY-START(12885033083)
            static /*void */ Copy(T, /*int*/ begin, /*int*/ end, /*ref int*/ writer, /*Span<T>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(begin !== end)
                {
                    buffer._reference.SetAt(buffer._reference.GetAt(begin++), writer.$v++);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033083)
            
            //--TRIMMABLE-BOUNDARY-START(73014575227)
            static /*int */ UnescapePercentEncoding$1(/*ref int*/ scan, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer._reference.GetAt(scan.$v++) !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*var*/ let value1 = $.$maw.MAI.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.S.Int32), buffer);
                if (value1 === -1)
                {
                    return -1;
                }
                /*var*/ let value2 = $.$maw.MAI.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.S.Int32), buffer);
                if (value2 === -1)
                {
                    return -1;
                }
                if ($.$maw.MAI.UrlDecoder.SkipUnescape(value1, value2, isFormEncoding))
                {
                    return -1;
                }
                scan.$v = probe;
                return (((value1 << 4) + value2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73014575227)
            
            //--TRIMMABLE-BOUNDARY-START(60129673339)
            static /*int */ ReadHex$1(/*ref int*/ scan, /*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (scan.$v === buffer.Length)
                {
                    return -1;
                }
                /*var*/ let value = buffer._reference.GetAt(scan.$v++);
                /*var*/ let isHex = ((value >= /*0*/ 48) && (value <= /*9*/ 57)) || ((value >= /*A*/ 65) && (value <= /*F*/ 70)) || ((value >= /*a*/ 97) && (value <= /*f*/ 102));
                if (!isHex)
                {
                    return -1;
                }
                if (value <= /*9*/ 57)
                {
                    return value - /*0*/ 48;
                }
                else if (value <= /*F*/ 70)
                {
                    return (((value - /*A*/ 65) + 10) | 0);
                }
                else 
                {
                    return (((value - /*a*/ 97) + 10) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129673339)
            
            //--TRIMMABLE-BOUNDARY-START(64424640635)
            static /*bool */ SkipUnescape(/*int*/ value1, /*int*/ value2, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isFormEncoding)
                {
                    return false;
                }
                if (value1 === 2 && value2 === 15)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640635)
            
            //--TRIMMABLE-BOUNDARY-START(38654836859)
            static /*int */ DecodeRequestLine$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                source.CopyTo(destination);
                return $.$maw.MAI.UrlDecoder.DecodeInPlace$1(destination.Slice(0, source.Length));
            }
            //--TRIMMABLE-BOUNDARY-END(38654836859)
            
            //--TRIMMABLE-BOUNDARY-START(30064902267)
            static /*int */ DecodeInPlace$1(/*Span<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let position = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, $.$$.S.Span$$($.$$.S.Char).op_Implicit(buffer), /*%*/ 37);
                if (position === -1)
                {
                    return buffer.Length;
                }
                /*var*/ let sourceIndex = position;
                /*var*/ let destinationIndex = position;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer._reference.GetAt(sourceIndex) === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.MAI.UrlDecoder.DecodeCore$1($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.S.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.S.Int32), buffer))
                        {
                            $.$maw.MAI.UrlDecoder.Copy($.$$.S.Char, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.S.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer._reference.SetAt(buffer._reference.GetAt(sourceIndex++), destinationIndex++);
                    }
                }
                return destinationIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902267)
            
            //--TRIMMABLE-BOUNDARY-START(21474967675)
            static /*bool */ DecodeCore$1(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<char>*/ buffer)
            {
                /*var*/ let rune;
                /*var*/ let charsWritten;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let codeUnit1 = $.$maw.MAI.UrlDecoder.UnescapePercentEncoding(sourceIndex, $.$$.S.Span$$($.$$.S.Char).op_Implicit(buffer));
                if (codeUnit1 === -1)
                {
                    return false;
                }
                if (codeUnit1 === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (codeUnit1 <= 127)
                {
                    buffer._reference.SetAt($.$cast(codeUnit1, $.$$.S.Char), destinationIndex.$v++);
                    return true;
                }
                /*int*/ let currentDecodeBits;
                /*int*/ let codeUnitCount;
                /*int*/ let expectValueMin;
                if ((codeUnit1 & 224) === 192)
                {
                    currentDecodeBits = codeUnit1 & 31;
                    codeUnitCount = 2;
                    expectValueMin = 128;
                }
                else if ((codeUnit1 & 240) === 224)
                {
                    currentDecodeBits = codeUnit1 & 15;
                    codeUnitCount = 3;
                    expectValueMin = 2048;
                }
                else if ((codeUnit1 & 248) === 240)
                {
                    currentDecodeBits = codeUnit1 & 7;
                    codeUnitCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingCodeUnits = ((codeUnitCount - 1) | 0);
                while(remainingCodeUnits > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextCodeUnit = $.$maw.MAI.UrlDecoder.UnescapePercentEncoding($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.S.Int32), $.$$.S.Span$$($.$$.S.Char).op_Implicit(buffer));
                    if (nextCodeUnit === -1)
                    {
                        return false;
                    }
                    if ((nextCodeUnit & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextCodeUnit & 63);
                    remainingCodeUnits--;
                    sourceIndex.$v = nextSourceIndex;
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                if (!$.$$.ST.Rune.TryCreate$2(currentDecodeBits, $.$ref(() => rune, ($v) => rune = $v, $.$$.ST.Rune)) || !rune.TryEncodeToUtf16(buffer.Slice$1(destinationIndex.$v), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int32)))
                {
                    return false;
                }
                destinationIndex.$v += charsWritten;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967675)
            
            //--TRIMMABLE-BOUNDARY-START(68719607931)
            static /*int */ UnescapePercentEncoding(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tempIdx = scan.$v++;
                if (buffer._reference.GetAt(tempIdx) !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*int*/ let firstNibble = $.$maw.MAI.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.S.Int32), buffer);
                /*int*/ let secondNibble = $.$maw.MAI.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.S.Int32), buffer);
                /*int*/ let value = firstNibble << 4 | secondNibble;
                if (value < 0 || value === /*/*/ 47)
                {
                    return -1;
                }
                scan.$v = probe;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607931)
            
            //--TRIMMABLE-BOUNDARY-START(55834706043)
            static /*int */ ReadHex(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tempIdx = scan.$v++;
                if ((tempIdx >>> 0) >= (buffer.Length >>> 0))
                {
                    return -1;
                }
                /*int*/ let value = buffer._reference.GetAt(tempIdx);
                return $.$maw.MAI.UrlDecoder.FromChar(value);
            }
            //--TRIMMABLE-BOUNDARY-END(55834706043)
            
            //--TRIMMABLE-BOUNDARY-START(42949804155)
            static /*int */ FromChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c >>> 0) >= ($.$maw.MAI.UrlDecoder.CharToHexLookup.Length >>> 0) ? -1 : $.$maw.MAI.UrlDecoder.CharToHexLookup._reference.GetAt(c);
            }
            //--TRIMMABLE-BOUNDARY-END(42949804155)
            
            //--TRIMMABLE-BOUNDARY-START(8590065787)
            static /*ReadOnlySpan<sbyte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= $.$$.S.ReadOnlySpan$$($.$$.S.SByte).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.SByte), [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590065787)
            
            //--TRIMMABLE-BOUNDARY-START(4295098491)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098491)
            
            //--TRIMMABLE-BOUNDARY-START(4295098491)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098491)
            
            static $h = 131195;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065787),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.SByte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539738747,
        "f": 50331682
      },
      "n": "CharToHexLookup",
      "d": 131195,
      "h": 8590065787,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(8590065787)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359869563),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeRequestLine",
      "d": 131195,
      "h": 34359869563,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359869563),
//--TRIMMABLE-BOUNDARY-START(25769934971),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeInPlace",
      "d": 131195,
      "h": 25769934971,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934971),
//--TRIMMABLE-BOUNDARY-START(17180000379),
    {
      "r": 262145,
      "p": [
        {
          "n": "sourceIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "destinationIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeCore",
      "d": 131195,
      "h": 17180000379,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180000379),
//--TRIMMABLE-BOUNDARY-START(12885033083),
    {
      "r": 65537,
      "p": [
        {
          "n": "begin",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "writer",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": (T) => $.$$.S.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Copy",
      "d": 131195,
      "h": 12885033083,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(12885033083),
//--TRIMMABLE-BOUNDARY-START(73014575227),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "UnescapePercentEncoding",
      "o": "@$1",
      "d": 131195,
      "h": 73014575227,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014575227),
//--TRIMMABLE-BOUNDARY-START(60129673339),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "ReadHex",
      "o": "@$1",
      "d": 131195,
      "h": 60129673339,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129673339),
//--TRIMMABLE-BOUNDARY-START(64424640635),
    {
      "r": 262145,
      "p": [
        {
          "n": "value1",
          "p": 655361
        },
        {
          "n": "value2",
          "p": 655361
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "SkipUnescape",
      "d": 131195,
      "h": 64424640635,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424640635),
//--TRIMMABLE-BOUNDARY-START(38654836859),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "DecodeRequestLine",
      "o": "@$1",
      "d": 131195,
      "h": 38654836859,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836859),
//--TRIMMABLE-BOUNDARY-START(30064902267),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "DecodeInPlace",
      "o": "@$1",
      "d": 131195,
      "h": 30064902267,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064902267),
//--TRIMMABLE-BOUNDARY-START(21474967675),
    {
      "r": 262145,
      "p": [
        {
          "n": "sourceIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "destinationIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "DecodeCore",
      "o": "@$1",
      "d": 131195,
      "h": 21474967675,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474967675),
//--TRIMMABLE-BOUNDARY-START(68719607931),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "UnescapePercentEncoding",
      "d": 131195,
      "h": 68719607931,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719607931),
//--TRIMMABLE-BOUNDARY-START(55834706043),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "ReadHex",
      "d": 131195,
      "h": 55834706043,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834706043),
//--TRIMMABLE-BOUNDARY-START(42949804155),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromChar",
      "d": 131195,
      "h": 42949804155,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949804155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098491),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131195,
      "h": 4295098491,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098491)
  ],
  "h": 131195
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Internal.UrlDecoder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Internal${separator}UrlDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131195)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966203)
        $asm.$cls(`$maw.MAW.WebEncoders`, ($self) => class WebEncoders
        {
            //--TRIMMABLE-BOUNDARY-START(55836541051)
            /*SearchValues<char>*/ static s_base64vsBase64UrlDifferentiators = null;
            //--TRIMMABLE-BOUNDARY-END(55836541051)
            
            //--TRIMMABLE-BOUNDARY-START(17181835387)
            static /*byte[] */ Base64UrlDecode$2(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.MAW.WebEncoders.Base64UrlDecode$1(input, 0, input.length);
            }
            //--TRIMMABLE-BOUNDARY-END(17181835387)
            
            //--TRIMMABLE-BOUNDARY-START(12886868091)
            static /*byte[] */ Base64UrlDecode$1(/*string*/ input, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.MAW.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                if (count === 0)
                {
                    return $.$$.S.Array.Empty($.$$.S.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.S.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.S.MemoryExtensions.IndexOfAny$2($.$$.S.Char, inputSpan, $.$maw.MAW.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan._reference.GetAt(indexOfFirstDifferentiator) === /*-*/ 45) || (inputSpan._reference.GetAt(indexOfFirstDifferentiator) === /*_*/ 95))
                {
                    return $.$$.SBT.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.S.Convert.FromBase64String(input);
                }
                /*var*/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [$.$maw.MAW.WebEncoders.GetArraySizeRequiredToDecode(count)], null);
                return $.$maw.MAW.WebEncoders.Base64UrlDecode(input, offset, buffer, 0, count);
            }
            //--TRIMMABLE-BOUNDARY-END(12886868091)
            
            //--TRIMMABLE-BOUNDARY-START(8591900795)
            static /*byte[] */ Base64UrlDecode(/*string*/ input, /*int*/ offset, /*char[]*/ buffer, /*int*/ bufferOffset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(buffer, "buffer");
                $.$maw.MAW.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.MAS.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(bufferOffset, "bufferOffset");
                if (count === 0)
                {
                    return $.$$.S.Array.Empty($.$$.S.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.S.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.S.MemoryExtensions.IndexOfAny$2($.$$.S.Char, inputSpan, $.$maw.MAW.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan._reference.GetAt(indexOfFirstDifferentiator) === /*-*/ 45) || (inputSpan._reference.GetAt(indexOfFirstDifferentiator) === /*_*/ 95))
                {
                    return $.$$.SBT.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.S.Convert.FromBase64String(input);
                }
                /*var*/ let paddingCharsToAdd = $.$maw.MAW.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                /*var*/ let arraySizeRequired = $.$checked(count + paddingCharsToAdd, 1);
                $.$$.SD.Debug.Assert$4(arraySizeRequired % 4 === 0, "Invariant: Array length must be a multiple of 4.");
                if (((buffer.length - bufferOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$$.S.String.Format$2($.$$.SG.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "bufferOffset", "input"), "count");
                }
                /*var*/ let i = bufferOffset;
                /*Span<char>*/ let bufferSpan = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, buffer, i, count);
                inputSpan.CopyTo(bufferSpan);
                $.$$.S.MemoryExtensions.Replace$3($.$$.S.Char, bufferSpan, /*-*/ 45, /*+*/ 43);
                $.$$.S.MemoryExtensions.Replace$3($.$$.S.Char, bufferSpan, /*_*/ 95, /*/*/ 47);
                i += count;
                for(; paddingCharsToAdd > 0; i++, paddingCharsToAdd--)
                {
                    $.$$.System.Array.$WriteT1.call(buffer, /*=*/ 61, i);
                }
                return $.$$.S.Convert.FromBase64CharArray(buffer, bufferOffset, arraySizeRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(8591900795)
            
            //--TRIMMABLE-BOUNDARY-START(42951639163)
            static /*int */ GetArraySizeRequiredToDecode(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951639163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (count === 0)
                {
                    return 0;
                }
                /*var*/ let numPaddingCharsToAdd = $.$maw.MAW.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                return $.$checked(count + numPaddingCharsToAdd, 1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951639163)
            
            //--TRIMMABLE-BOUNDARY-START(30066737275)
            static /*string */ Base64UrlEncode$2(/*byte[]*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.MAW.WebEncoders.Base64UrlEncode$1(input, 0, input.length);
            }
            //--TRIMMABLE-BOUNDARY-END(30066737275)
            
            //--TRIMMABLE-BOUNDARY-START(25771769979)
            static /*string */ Base64UrlEncode$1(/*byte[]*/ input, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.MAW.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                return $.$maw.MAW.WebEncoders.Base64UrlEncode$4($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, input, offset, count)));
            }
            //--TRIMMABLE-BOUNDARY-END(25771769979)
            
            //--TRIMMABLE-BOUNDARY-START(21476802683)
            static /*int */ Base64UrlEncode(/*byte[]*/ input, /*int*/ offset, /*char[]*/ output, /*int*/ outputOffset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.MAS.ArgumentNullThrowHelper.ThrowIfNull(output, "output");
                $.$maw.MAW.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.MAS.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(outputOffset, "outputOffset");
                /*var*/ let arraySizeRequired = $.$maw.MAW.WebEncoders.GetArraySizeRequiredToEncode(count);
                if (((output.length - outputOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$$.S.String.Format$2($.$$.SG.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "outputOffset", "output"), "count");
                }
                return $.$maw.MAW.WebEncoders.Base64UrlEncode$3($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, input, offset, count)), $.$$.S.MemoryExtensions.AsSpan$12($.$$.S.Char, output, outputOffset));
            }
            //--TRIMMABLE-BOUNDARY-END(21476802683)
            
            //--TRIMMABLE-BOUNDARY-START(47246606459)
            static /*int */ GetArraySizeRequiredToEncode(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numWholeOrPartialInputBlocks = $.trunc($.$checked(count + 2, 1) / 3);
                return $.$checked(numWholeOrPartialInputBlocks * 4, 1);
            }
            //--TRIMMABLE-BOUNDARY-END(47246606459)
            
            //--TRIMMABLE-BOUNDARY-START(38656671867)
            static /*string */ Base64UrlEncode$4(/*ReadOnlySpan<byte>*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656671867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SBT.Base64Url.EncodeToString(input);
            }
            //--TRIMMABLE-BOUNDARY-END(38656671867)
            
            //--TRIMMABLE-BOUNDARY-START(34361704571)
            static /*int */ Base64UrlEncode$3(/*ReadOnlySpan<byte>*/ input, /*Span<char>*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361704571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SBT.Base64Url.EncodeToChars$1(input, output);
            }
            //--TRIMMABLE-BOUNDARY-END(34361704571)
            
            //--TRIMMABLE-BOUNDARY-START(51541573755)
            static /*int */ GetNumBase64PaddingCharsToAddForDecode(/*int*/ inputLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541573755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = inputLength % 4;
                switch($switch1)
                {
                    case 0:
                    return 0;
                    case 2:
                    return 2;
                    case 3:
                    return 1;
                    default:
                    throw new $.$$.S.FormatException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*EncoderResources.WebEncoders_MalformedInput*/, $.$box(inputLength, $.$$.S.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541573755)
            
            //--TRIMMABLE-BOUNDARY-START(60131508347)
            static /*void */ ValidateParameters(/*int*/ bufferLength, /*string*/ inputName, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131508347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.MAS.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(offset, "offset");
                $.$maw.MAS.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (((bufferLength - offset) | 0) < count)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$$.S.String.Format$2($.$$.SG.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "offset", inputName), "count");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131508347)
            
            //--TRIMMABLE-BOUNDARY-START(4296933499)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55836541051)
                    this.s_base64vsBase64UrlDifferentiators = $.$$.SB.SearchValues.Create$1($.$$.S.String.op_Implicit("+/-_"));
                    //--TRIMMABLE-BOUNDARY-END(55836541051)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296933499)
            
            static $h = 1966203;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181835387),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDecode",
      "o": "@$2",
      "d": 1966203,
      "h": 17181835387,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181835387),
//--TRIMMABLE-BOUNDARY-START(12886868091),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlDecode",
      "o": "@$1",
      "d": 1966203,
      "h": 12886868091,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886868091),
//--TRIMMABLE-BOUNDARY-START(8591900795),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "bufferOffset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlDecode",
      "d": 1966203,
      "h": 8591900795,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591900795),
//--TRIMMABLE-BOUNDARY-START(42951639163),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetArraySizeRequiredToDecode",
      "d": 1966203,
      "h": 42951639163,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951639163),
//--TRIMMABLE-BOUNDARY-START(30066737275),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$2",
      "d": 1966203,
      "h": 30066737275,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066737275),
//--TRIMMABLE-BOUNDARY-START(25771769979),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$1",
      "d": 1966203,
      "h": 25771769979,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771769979),
//--TRIMMABLE-BOUNDARY-START(21476802683),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "output",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "outputOffset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlEncode",
      "d": 1966203,
      "h": 21476802683,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802683),
//--TRIMMABLE-BOUNDARY-START(47246606459),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetArraySizeRequiredToEncode",
      "d": 1966203,
      "h": 47246606459,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246606459),
//--TRIMMABLE-BOUNDARY-START(38656671867),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$4",
      "d": 1966203,
      "h": 38656671867,
      "f": 16777249,
      "a": [
        {
          "t": 133693441,
          "c": 4428660737
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656671867),
//--TRIMMABLE-BOUNDARY-START(34361704571),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "output",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$3",
      "d": 1966203,
      "h": 34361704571,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361704571),
//--TRIMMABLE-BOUNDARY-START(51541573755),
    {
      "r": 655361,
      "p": [
        {
          "n": "inputLength",
          "p": 655361
        }
      ],
      "n": "GetNumBase64PaddingCharsToAddForDecode",
      "d": 1966203,
      "h": 51541573755,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541573755),
//--TRIMMABLE-BOUNDARY-START(60131508347),
    {
      "r": 65537,
      "p": [
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "inputName",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateParameters",
      "d": 1966203,
      "h": 60131508347,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60131508347)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836541051),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "s_base64vsBase64UrlDifferentiators",
      "d": 1966203,
      "h": 55836541051,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836541051)
  ],
  "h": 1966203
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.WebEncoders`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}WebEncoders`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966203)
        
        

        //--TRIMMABLE-BOUNDARY-START(721019)
        $asm.$cls(`$maw.MAW.FormPipeReader`, ($self) => class FormPipeReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167504445563)
            /*int*/ static StackAllocThreshold = 128;
            //--TRIMMABLE-BOUNDARY-END(167504445563)
            
            //--TRIMMABLE-BOUNDARY-START(51540328571)
            /*int*/ static DefaultValueCountLimit = 1024;
            //--TRIMMABLE-BOUNDARY-END(51540328571)
            
            //--TRIMMABLE-BOUNDARY-START(47245361275)
            /*int*/ static DefaultKeyLengthLimit = 2048;
            //--TRIMMABLE-BOUNDARY-END(47245361275)
            
            //--TRIMMABLE-BOUNDARY-START(55835295867)
            /*int*/ static DefaultValueLengthLimit = 4194304;
            //--TRIMMABLE-BOUNDARY-END(55835295867)
            
            //--TRIMMABLE-BOUNDARY-START(188979282043)
            static /*ReadOnlySpan<byte> */ get UTF8EqualEncoded()
            {
                return this.$cacheUTF8EqualEncoded ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([61]);
            }
            //--TRIMMABLE-BOUNDARY-END(188979282043)
            
            //--TRIMMABLE-BOUNDARY-START(184684314747)
            static /*ReadOnlySpan<byte> */ get UTF8AndEncoded()
            {
                return this.$cacheUTF8AndEncoded ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))().$ctor$7([38]);
            }
            //--TRIMMABLE-BOUNDARY-END(184684314747)
            
            //--TRIMMABLE-BOUNDARY-START(12885622907)
            /*byte[]?*/ _otherEqualEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(12885622907)
            
            //--TRIMMABLE-BOUNDARY-START(8590655611)
            /*byte[]?*/ _otherAndEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(8590655611)
            
            //--TRIMMABLE-BOUNDARY-START(17180590203)
            /*PipeReader*/ _pipeReader = null;
            //--TRIMMABLE-BOUNDARY-END(17180590203)
            
            //--TRIMMABLE-BOUNDARY-START(4295688315)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(4295688315)
            
            //--TRIMMABLE-BOUNDARY-START(38655426683)
            $ctor$2(/*PipeReader*/ pipeReader)
            {
                this.$ctor$1(pipeReader, $.$$.ST.Encoding.UTF8);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426683);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426683)
            
            //--TRIMMABLE-BOUNDARY-START(34360459387)
            $ctor$1(/*PipeReader*/ pipeReader, /*Encoding*/ encoding)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360459387);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encoding !== null && ($.$is(encoding, $.$$.ST.Encoding) && encoding.CodePage === 65000))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14("UTF7 is unsupported and insecure. Please select a different encoding.");
                    }
                    this._pipeReader = pipeReader;
                    this._encoding = encoding;
                    if (this._encoding !== $.$$.ST.Encoding.UTF8 && this._encoding !== $.$$.ST.Encoding.ASCII)
                    {
                        this._otherEqualEncoding = this._encoding.GetBytes$8("=");
                        this._otherAndEncoding = this._encoding.GetBytes$8("&");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459387)
            
            //--TRIMMABLE-BOUNDARY-START(193274249339)
            /*int*/ ValueCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(193274249339)
            
            //--TRIMMABLE-BOUNDARY-START(120259805307)
            /*int*/ KeyLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(120259805307)
            
            //--TRIMMABLE-BOUNDARY-START(197569216635)
            /*int*/ ValueLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(197569216635)
            
            //--TRIMMABLE-BOUNDARY-START(137439674491)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)), $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439674491);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*KeyValueAccumulator*/ let accumulator = new $.$maw.MAW.KeyValueAccumulator();
                    while(true)
                    {
                        let $t1, $r1;
                        /*var*/ let readResult = ($t1 = this._pipeReader.ReadAsync(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                        /*var*/ let buffer = readResult.Buffer;
                        if (!buffer.IsEmpty)
                        {
                            try
                            {
                                this.ParseFormValues($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte), () => buffer, ($v) => buffer = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$maw.MAW.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null, true), readResult.IsCompleted);
                            }
                            catch($e)
                            {
                                this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                                throw $e;
                            }
                        }
                        if (readResult.IsCompleted)
                        {
                            this._pipeReader.AdvanceTo$1(buffer.End);
                            if (!buffer.IsEmpty)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$12("End of body before form was fully parsed.");
                            }
                            break;
                        }
                        this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, accumulator.GetResults());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137439674491)
            
            //--TRIMMABLE-BOUNDARY-START(124554772603)
            /*void */ ParseFormValues(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer.$v.IsSingleSegment)
                {
                    /*var*/ let consumed;
                    this.ParseFormValuesFast(buffer.$v.FirstSpan, accumulator, isFinalBlock, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.S.Int32));
                    buffer.$v = buffer.$v.Slice$4(BigInt(consumed));
                    return;
                }
                this.ParseValuesSlow(buffer, accumulator, isFinalBlock);
            }
            //--TRIMMABLE-BOUNDARY-END(124554772603)
            
            //--TRIMMABLE-BOUNDARY-START(128849739899)
            /*void */ ParseFormValuesFast(/*ReadOnlySpan<byte>*/ span, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock, /*out int*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let key;
                /*ReadOnlySpan<byte>*/ let value;
                consumed.$v = 0;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(span.Length > 0)
                {
                    /*var*/ let ampersand = $.$$.S.MemoryExtensions.IndexOf$2($.$$.S.Byte, span, andDelimiter);
                    /*ReadOnlySpan<byte>*/ let keyValuePair;
                    /*int*/ let equals;
                    /*var*/ let foundAmpersand = ampersand !== -1;
                    if (foundAmpersand)
                    {
                        keyValuePair = span.Slice(0, ampersand);
                        span = span.Slice$1(((keyValuePair.Length + andDelimiter.Length) | 0));
                        consumed.$v += ((keyValuePair.Length + andDelimiter.Length) | 0);
                    }
                    else 
                    {
                        if (!isFinalBlock)
                        {
                            if ((span.Length >>> 0) > ((((this.KeyLengthLimit >>> 0) + (this.ValueLengthLimit >>> 0)) >>> 0) >>> 0))
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            return;
                        }
                        keyValuePair = span;
                        span = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                        consumed.$v += keyValuePair.Length;
                    }
                    equals = $.$$.S.MemoryExtensions.IndexOf$2($.$$.S.Byte, keyValuePair, equalsDelimiter);
                    if (equals === -1)
                    {
                        if (keyValuePair.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$$.S.ReadOnlySpan$$($.$$.S.Byte))();
                    }
                    else 
                    {
                        key = keyValuePair.Slice(0, equals);
                        if (key.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$1(((equals + equalsDelimiter.Length) | 0));
                        if (value.Length > this.ValueLengthLimit)
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    /*var*/ let decodedKey = this.GetDecodedString(key);
                    /*var*/ let decodedValue = this.GetDecodedString(value);
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849739899)
            
            //--TRIMMABLE-BOUNDARY-START(133144707195)
            /*void */ ParseValuesSlow(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sequenceReader = new ($.$sm.SB.SequenceReader$$($.$$.S.Byte))().$ctor$3(buffer.$v);
                /*ReadOnlySequence<byte>*/ let keyValuePair;
                /*var*/ let consumed = sequenceReader.Position;
                /*var*/ let consumedBytes = 0n;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(!sequenceReader.End)
                {
                    /*ReadOnlySequence<byte>*/ let key;
                    if (!sequenceReader.TryReadTo($.$ref(() => keyValuePair, ($v) => keyValuePair = $v, $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte)), andDelimiter, true))
                    {
                        if (!isFinalBlock)
                        {
                            if ((BigInt.asIntN(64, sequenceReader.Length - consumedBytes)) > BigInt.asIntN(64, BigInt.asIntN(64, $.$cast(this.KeyLengthLimit, $.$$.S.Int64) + $.$cast(this.ValueLengthLimit, $.$$.S.Int64)) + 2n))
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            break;
                        }
                        keyValuePair = buffer.$v.Slice$8(sequenceReader.Position);
                        sequenceReader.Advance(keyValuePair.Length);
                    }
                    if (keyValuePair.IsSingleSegment)
                    {
                        /*var*/ let segmentConsumed;
                        this.ParseFormValuesFast(keyValuePair.FirstSpan, accumulator, true, $.$ref(() => segmentConsumed, ($v) => segmentConsumed = $v, $.$$.S.Int32));
                        $.$$.SD.Debug.Assert$4(segmentConsumed === keyValuePair.FirstSpan.Length, "segmentConsumed == keyValuePair.FirstSpan.Length");
                        consumedBytes = sequenceReader.Consumed;
                        consumed = sequenceReader.Position;
                        continue;
                    }
                    /*var*/ let keyValueReader = new ($.$sm.SB.SequenceReader$$($.$$.S.Byte))().$ctor$3(keyValuePair);
                    /*ReadOnlySequence<byte>*/ let value;
                    if (keyValueReader.TryReadTo($.$ref(() => key, ($v) => key = $v, $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte)), equalsDelimiter, true))
                    {
                        if (key.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$8(keyValueReader.Position);
                        if (value.Length > BigInt(this.ValueLengthLimit))
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    else 
                    {
                        if (keyValuePair.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$sm.SB.ReadOnlySequence$$($.$$.S.Byte))();
                    }
                    /*var*/ let decodedKey = this.GetDecodedStringFromReadOnlySequence($.$ref(() => key, ));
                    /*var*/ let decodedValue = this.GetDecodedStringFromReadOnlySequence($.$ref(() => value, ));
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                    consumedBytes = sequenceReader.Consumed;
                    consumed = sequenceReader.Position;
                }
                buffer.$v = buffer.$v.Slice$8(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(133144707195)
            
            //--TRIMMABLE-BOUNDARY-START(171799412859)
            /*void */ ThrowKeyOrValueTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799412859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.SI.InvalidDataException().$ctor$12($.$$.S.String.Format$3($.$$.SG.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyOrValueTooLarge, $.$box(this.KeyLengthLimit, $.$$.S.Int32), $.$box(this.ValueLengthLimit, $.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(171799412859)
            
            //--TRIMMABLE-BOUNDARY-START(176094380155)
            /*void */ ThrowKeyTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.SI.InvalidDataException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyTooLarge, $.$box(this.KeyLengthLimit, $.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(176094380155)
            
            //--TRIMMABLE-BOUNDARY-START(180389347451)
            /*void */ ThrowValueTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.SI.InvalidDataException().$ctor$12($.$$.S.String.Format$4($.$$.SG.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_ValueTooLarge, $.$box(this.ValueLengthLimit, $.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(180389347451)
            
            //--TRIMMABLE-BOUNDARY-START(111669870715)
            /*string */ GetDecodedStringFromReadOnlySequence(/*in ReadOnlySequence<byte>*/ ros)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ros.$v.IsSingleSegment)
                {
                    return this.GetDecodedString(ros.$v.FirstSpan);
                }
                if (ros.$v.Length < BigInt(128/*StackAllocThreshold*/))
                {
                    /*Span<byte>*/ let buffer = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, 128/*StackAllocThreshold*/, null).Slice(0, $.$cast(ros.$v.Length, $.$$.S.Int32));
                    $.$sm.SB.BuffersExtensions.CopyTo($.$$.S.Byte, ros, buffer);
                    return this.GetDecodedString($.$$.S.Span$$($.$$.S.Byte).op_Implicit(buffer));
                }
                else 
                {
                    /*var*/ let byteArray = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent($.$cast(ros.$v.Length, $.$$.S.Int32));
                    try
                    {
                        /*Span<byte>*/ let buffer = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, byteArray, 0, $.$cast(ros.$v.Length, $.$$.S.Int32));
                        $.$sm.SB.BuffersExtensions.CopyTo($.$$.S.Byte, ros, buffer);
                        return this.GetDecodedString($.$$.S.Span$$($.$$.S.Byte).op_Implicit(buffer));
                    }
                    finally
                    {
                        {
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(byteArray, false);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669870715)
            
            //--TRIMMABLE-BOUNDARY-START(42950393979)
            /*void */ AppendAndVerify(/*ref KeyValueAccumulator*/ accumulator, /*string*/ decodedKey, /*string*/ decodedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                accumulator.$v.Append(decodedKey, decodedValue);
                if (accumulator.$v.ValueCount > this.ValueCountLimit)
                {
                    throw new $.$$.SI.InvalidDataException().$ctor$12(`Form value count limit ${$.$strNN(this.ValueCountLimit)} exceeded.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393979)
            
            //--TRIMMABLE-BOUNDARY-START(107374903419)
            /*string */ GetDecodedString(/*ReadOnlySpan<byte>*/ readOnlySpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (readOnlySpan.Length === 0)
                {
                    return $.$$.S.String.Empty;
                }
                else if (this._encoding === $.$$.ST.Encoding.UTF8 || this._encoding === $.$$.ST.Encoding.ASCII)
                {
                    /*var*/ let span = $.$$.SRI.MemoryMarshal.CreateSpan($.$$.S.Byte, $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Byte, readOnlySpan), readOnlySpan.Length);
                    try
                    {
                        /*var*/ let bytes = $.$maw.MAI.UrlDecoder.DecodeInPlace(span, true);
                        span = span.Slice(0, bytes);
                        return this._encoding.GetString$3($.$$.S.Span$$($.$$.S.Byte).op_Implicit(span));
                    }
                    catch(ex)
                    {
                        throw new $.$$.SI.InvalidDataException().$ctor$11("The form value contains invalid characters.", ex);
                    }
                }
                else 
                {
                    /*var*/ let decodedString = this._encoding.GetString$3(readOnlySpan);
                    decodedString = $.$$.S.String.Replace.call(decodedString, /*+*/ 43, /* */ 32);
                    return $.$spu.S.Uri.UnescapeDataString$2(decodedString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374903419)
            
            //--TRIMMABLE-BOUNDARY-START(115964838011)
            /*ReadOnlySpan<byte> */ GetEqualsForEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964838011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encoding === $.$$.ST.Encoding.UTF8 || this._encoding === $.$$.ST.Encoding.ASCII)
                {
                    return $.$maw.MAW.FormPipeReader.UTF8EqualEncoded;
                }
                else 
                {
                    return $.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(this._otherEqualEncoding);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964838011)
            
            //--TRIMMABLE-BOUNDARY-START(103079936123)
            /*ReadOnlySpan<byte> */ GetAndForEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encoding === $.$$.ST.Encoding.UTF8 || this._encoding === $.$$.ST.Encoding.ASCII)
                {
                    return $.$maw.MAW.FormPipeReader.UTF8AndEncoded;
                }
                else 
                {
                    return $.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1(this._otherAndEncoding);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936123)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(193274249339)
                this.ValueCountLimit = 1024;
                //--TRIMMABLE-BOUNDARY-END(193274249339)
                
                //--TRIMMABLE-BOUNDARY-START(120259805307)
                this.KeyLengthLimit = 2048;
                //--TRIMMABLE-BOUNDARY-END(120259805307)
                
                //--TRIMMABLE-BOUNDARY-START(197569216635)
                this.ValueLengthLimit = 4194304;
                //--TRIMMABLE-BOUNDARY-END(197569216635)
                
            }
            static $h = 721019;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(188979282043),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099643,
        "f": 50331682
      },
      "n": "UTF8EqualEncoded",
      "d": 721019,
      "h": 188979282043,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(188979282043),
//--TRIMMABLE-BOUNDARY-START(184684314747),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015165051,
        "f": 50331682
      },
      "n": "UTF8AndEncoded",
      "d": 721019,
      "h": 184684314747,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(184684314747),
//--TRIMMABLE-BOUNDARY-START(193274249339),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034235,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619543675,
        "f": 83886081
      },
      "n": "ValueCountLimit",
      "d": 721019,
      "h": 193274249339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274249339),
//--TRIMMABLE-BOUNDARY-START(120259805307),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230459,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029609083,
        "f": 83886081
      },
      "n": "KeyLengthLimit",
      "d": 721019,
      "h": 120259805307,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259805307),
//--TRIMMABLE-BOUNDARY-START(197569216635),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968827,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209478267,
        "f": 83886081
      },
      "n": "ValueLengthLimit",
      "d": 721019,
      "h": 197569216635,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569216635)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439674491),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadFormAsync",
      "d": 721019,
      "h": 137439674491,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(137439674491),
//--TRIMMABLE-BOUNDARY-START(124554772603),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "accumulator",
          "p": 1048699,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "ParseFormValues",
      "d": 721019,
      "h": 124554772603,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(124554772603),
//--TRIMMABLE-BOUNDARY-START(128849739899),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "accumulator",
          "p": 1048699,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        },
        {
          "n": "consumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ParseFormValuesFast",
      "d": 721019,
      "h": 128849739899,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849739899),
//--TRIMMABLE-BOUNDARY-START(133144707195),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "accumulator",
          "p": 1048699,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "ParseValuesSlow",
      "d": 721019,
      "h": 133144707195,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707195),
//--TRIMMABLE-BOUNDARY-START(171799412859),
    {
      "r": 65537,
      "n": "ThrowKeyOrValueTooLargeException",
      "d": 721019,
      "h": 171799412859,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799412859),
//--TRIMMABLE-BOUNDARY-START(176094380155),
    {
      "r": 65537,
      "n": "ThrowKeyTooLargeException",
      "d": 721019,
      "h": 176094380155,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094380155),
//--TRIMMABLE-BOUNDARY-START(180389347451),
    {
      "r": 65537,
      "n": "ThrowValueTooLargeException",
      "d": 721019,
      "h": 180389347451,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389347451),
//--TRIMMABLE-BOUNDARY-START(111669870715),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ros",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 8
        }
      ],
      "n": "GetDecodedStringFromReadOnlySequence",
      "d": 721019,
      "h": 111669870715,
      "f": 16777218,
      "a": [
        {
          "t": 133693441,
          "c": 4428660737
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669870715),
//--TRIMMABLE-BOUNDARY-START(42950393979),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulator",
          "p": 1048699,
          "f": 4
        },
        {
          "n": "decodedKey",
          "p": 1310721
        },
        {
          "n": "decodedValue",
          "p": 1310721
        }
      ],
      "n": "AppendAndVerify",
      "d": 721019,
      "h": 42950393979,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393979),
//--TRIMMABLE-BOUNDARY-START(107374903419),
    {
      "r": 1310721,
      "p": [
        {
          "n": "readOnlySpan",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetDecodedString",
      "d": 721019,
      "h": 107374903419,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374903419),
//--TRIMMABLE-BOUNDARY-START(115964838011),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "n": "GetEqualsForEncoding",
      "d": 721019,
      "h": 115964838011,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964838011),
//--TRIMMABLE-BOUNDARY-START(103079936123),
    {
      "r": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h,
      "n": "GetAndForEncoding",
      "d": 721019,
      "h": 103079936123,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079936123)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167504445563),
    {
      "t": 655361,
      "n": "StackAllocThreshold",
      "d": 721019,
      "h": 167504445563,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167504445563),
//--TRIMMABLE-BOUNDARY-START(51540328571),
    {
      "t": 655361,
      "n": "DefaultValueCountLimit",
      "d": 721019,
      "h": 51540328571,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540328571),
//--TRIMMABLE-BOUNDARY-START(47245361275),
    {
      "t": 655361,
      "n": "DefaultKeyLengthLimit",
      "d": 721019,
      "h": 47245361275,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245361275),
//--TRIMMABLE-BOUNDARY-START(55835295867),
    {
      "t": 655361,
      "n": "DefaultValueLengthLimit",
      "d": 721019,
      "h": 55835295867,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835295867),
//--TRIMMABLE-BOUNDARY-START(12885622907),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_otherEqualEncoding",
      "d": 721019,
      "h": 12885622907,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622907),
//--TRIMMABLE-BOUNDARY-START(8590655611),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_otherAndEncoding",
      "d": 721019,
      "h": 8590655611,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655611),
//--TRIMMABLE-BOUNDARY-START(17180590203),
    {
      "t": 1376337,
      "n": "_pipeReader",
      "d": 721019,
      "h": 17180590203,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590203),
//--TRIMMABLE-BOUNDARY-START(4295688315),
    {
      "t": 166723585,
      "n": "_encoding",
      "d": 721019,
      "h": 4295688315,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688315)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426683),
    {
      "p": [
        {
          "n": "pipeReader",
          "p": 1376337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721019,
      "h": 38655426683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426683),
//--TRIMMABLE-BOUNDARY-START(34360459387),
    {
      "p": [
        {
          "n": "pipeReader",
          "p": 1376337
        },
        {
          "n": "encoding",
          "p": 166723585
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721019,
      "h": 34360459387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360459387)
  ],
  "h": 721019
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FormPipeReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FormPipeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721019)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441915)
        $asm.$cls(`$maw.MAW.MultipartSectionStreamExtensions`, ($self) => class MultipartSectionStreamExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591376507)
            static /*Task<string> */ ReadAsStringAsync$1(/*this MultipartSection*/ section)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.MAW.MultipartSectionStreamExtensions.ReadAsStringAsync(section, $.$$.ST$1.CancellationToken.None).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591376507)
            
            //--TRIMMABLE-BOUNDARY-START(4296409211)
            static /*ValueTask<string> *//*async*/  ReadAsStringAsync(/*this MultipartSection*/ section, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    /*var*/ let sectionMediaType;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(section, "section");
                    if (section.Body === null)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("Multipart section must have a body to be read.", "section");
                    }
                    _ = $.$mnhh.MNHH.MediaTypeHeaderValue.TryParse($.$mep.MEP.StringSegment.op_Implicit$2(section.ContentType), $.$ref(() => sectionMediaType, ($v) => sectionMediaType = $v, $.$mnhh.MNHH.MediaTypeHeaderValue));
                    /*var*/ let streamEncoding = (sectionMediaType?.Encoding ?? null);
                    if (streamEncoding === null || streamEncoding.CodePage === 65000)
                    {
                        streamEncoding = $.$$.ST.Encoding.UTF8;
                    }
                    /*var*/ let reader = new $.$$.SI.StreamReader().$ctor$5(section.Body, streamEncoding, true, 1024, true);
                    try
                    {
                        let $t2, $r2;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t2 = reader.ReadToEndAsync$1(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2))));
                    }
                    finally
                    {
                        reader?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4296409211)
            
            static $h = 1441915;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591376507),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "section",
          "p": 1310843
        }
      ],
      "n": "ReadAsStringAsync",
      "o": "@$1",
      "d": 1441915,
      "h": 8591376507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591376507),
//--TRIMMABLE-BOUNDARY-START(4296409211),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.String).$h,
      "p": [
        {
          "n": "section",
          "p": 1310843
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsStringAsync",
      "d": 1441915,
      "h": 4296409211,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(4296409211)
  ],
  "h": 1441915
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartSectionStreamExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441915)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572987)
        $asm.$cls(`$maw.MAW.QueryHelpers`, ($self) => class QueryHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(17181442171)
            static /*string */ AddQueryString$3(/*string*/ uri, /*string*/ name, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$maw.MAW.QueryHelpers.AddQueryString$2(uri, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), [new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))().$ctor$3(name, value)], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181442171)
            
            //--TRIMMABLE-BOUNDARY-START(4296540283)
            static /*string */ AddQueryString(/*string*/ uri, /*IDictionary<string, string?>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.MAW.QueryHelpers.AddQueryString$2(uri, queryString);
            }
            //--TRIMMABLE-BOUNDARY-END(4296540283)
            
            //--TRIMMABLE-BOUNDARY-START(8591507579)
            static /*string */ AddQueryString$1(/*string*/ uri, /*IEnumerable<KeyValuePair<string, StringValues>>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.MAW.QueryHelpers.AddQueryString$2(uri, $.$sl.SL.Enumerable.SelectMany($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues), $.$$.S.String, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String), queryString, new ($.$$.S.Func$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues), $.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return kvp.Value;
                }, $cComLf ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.String).$h,"p":[{"n":"kvp","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues).$h}],"n":"","d":1572987,"h":0,"f":17825794}), new ($.$$.S.Func$$$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues), $.$$.S.String, $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)))().$ctor(this,  (/*kvp*/ kvp, /*v*/ v) =>
                {
                    return $.$$.SCG.KeyValuePair.Create($.$$.S.String, $.$$.S.String, kvp.Key, v);
                }, $GqWWll ??= {"r":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String).$h,"p":[{"n":"kvp","p":$.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues).$h},{"n":"v","p":1310721}],"n":"","d":1572987,"h":0,"f":17825794})));
            }
            //--TRIMMABLE-BOUNDARY-END(8591507579)
            
            //--TRIMMABLE-BOUNDARY-START(12886474875)
            static /*string */ AddQueryString$2(/*string*/ uri, /*IEnumerable<KeyValuePair<string, string?>>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                /*var*/ let anchorIndex = $.$$.S.String.IndexOf$3.call(uri, /*#*/ 35);
                /*var*/ let uriToBeAppended = $.$$.S.MemoryExtensions.AsSpan$4(uri);
                /*var*/ let anchorText = $.$$.S.ReadOnlySpan$$($.$$.S.Char).Empty;
                if (anchorIndex !== -1)
                {
                    anchorText = uriToBeAppended.Slice$1(anchorIndex);
                    uriToBeAppended = uriToBeAppended.Slice(0, anchorIndex);
                }
                /*var*/ let queryIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, uriToBeAppended, /*?*/ 63);
                /*var*/ let hasQuery = queryIndex !== -1;
                /*var*/ let sb = new $.$$.ST.StringBuilder().$ctor$1();
                sb.Append$17(uriToBeAppended);
                let $en1 = queryString.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let parameter = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (parameter.Value === null)
                        {
                            continue;
                        }
                        sb.Append$5(hasQuery ? /*&*/ 38 : /*?*/ 63);
                        sb.Append$21($.$stew.STEW.UrlEncoder.Default.Encode$4(parameter.Key));
                        sb.Append$5(/*=*/ 61);
                        sb.Append$21($.$stew.STEW.UrlEncoder.Default.Encode$4(parameter.Value));
                        hasQuery = true;
                    }
                }
                sb.Append$17(anchorText);
                return sb.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(12886474875)
            
            //--TRIMMABLE-BOUNDARY-START(25771376763)
            static /*Dictionary<string, StringValues> */ ParseQuery(/*string?*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$maw.MAW.QueryHelpers.ParseNullableQuery(queryString);
                if (result === null)
                {
                    return new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues))().$ctor$1();
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376763)
            
            //--TRIMMABLE-BOUNDARY-START(21476409467)
            static /*Dictionary<string, StringValues>? */ ParseNullableQuery(/*string?*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476409467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accumulator = new $.$maw.MAW.KeyValueAccumulator().$ctor$2();
                /*var*/ let enumerable = new $.$maw.MAW.QueryStringEnumerable().$ctor$4(queryString);
                let $en2 = enumerable.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let pair = $en2.Current;
                    {
                        accumulator.Append(pair.DecodeName().ToString(), pair.DecodeValue().ToString());
                    }
                }
                if (!accumulator.HasValues)
                {
                    return null;
                }
                return accumulator.GetResults();
            }
            //--TRIMMABLE-BOUNDARY-END(21476409467)
            
            static $h = 1572987;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181442171),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddQueryString",
      "o": "@$3",
      "d": 1572987,
      "h": 17181442171,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181442171),
//--TRIMMABLE-BOUNDARY-START(4296540283),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        }
      ],
      "n": "AddQueryString",
      "d": 1572987,
      "h": 4296540283,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296540283),
//--TRIMMABLE-BOUNDARY-START(8591507579),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$mep.MEP.StringValues)).$h
        }
      ],
      "n": "AddQueryString",
      "o": "@$1",
      "d": 1572987,
      "h": 8591507579,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591507579),
//--TRIMMABLE-BOUNDARY-START(12886474875),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": "AddQueryString",
      "o": "@$2",
      "d": 1572987,
      "h": 12886474875,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886474875),
//--TRIMMABLE-BOUNDARY-START(25771376763),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": "ParseQuery",
      "d": 1572987,
      "h": 25771376763,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771376763),
//--TRIMMABLE-BOUNDARY-START(21476409467),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": "ParseNullableQuery",
      "d": 1572987,
      "h": 21476409467,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476409467)
  ],
  "h": 1572987
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.QueryHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}QueryHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572987)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507451)
        $asm.$cls(`$maw.MAW.PagedByteBuffer`, ($self) => class PagedByteBuffer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115965624443)
            /*int*/ static PageSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(115965624443)
            
            //--TRIMMABLE-BOUNDARY-START(4296474747)
            /*ArrayPool<byte>*/ _arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(4296474747)
            
            //--TRIMMABLE-BOUNDARY-START(8591442043)
            /*byte[]?*/ _currentPage = null;
            //--TRIMMABLE-BOUNDARY-END(8591442043)
            
            //--TRIMMABLE-BOUNDARY-START(12886409339)
            /*int*/ _currentPageIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(12886409339)
            
            //--TRIMMABLE-BOUNDARY-START(30066278523)
            $ctor$1(/*ArrayPool<byte>*/ arrayPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066278523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayPool = arrayPool;
                    this.Pages = new ($.$$.SCG.List$$($.$typeArray($.$$.S.Byte)))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278523)
            
            //--TRIMMABLE-BOUNDARY-START(94490787963)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(94490787963)
            
            //--TRIMMABLE-BOUNDARY-START(55836082299)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(55836082299)
            
            //--TRIMMABLE-BOUNDARY-START(111670657147)
            /*List<byte[]>*/ Pages = null;
            //--TRIMMABLE-BOUNDARY-END(111670657147)
            
            //--TRIMMABLE-BOUNDARY-START(47246147707)
            /*byte[] */ get CurrentPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentPage === null || this._currentPageIndex === this._currentPage.length)
                {
                    this._currentPage = this._arrayPool.Rent(1024/*PageSize*/);
                    this.Pages.Add(this._currentPage);
                    this._currentPageIndex = 0;
                }
                return this._currentPage;
            }
            //--TRIMMABLE-BOUNDARY-END(47246147707)
            
            //--TRIMMABLE-BOUNDARY-START(34361245819)
            /*void */ Add(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245819);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add$1($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245819)
            
            //--TRIMMABLE-BOUNDARY-START(38656213115)
            /*void */ Add$1(/*ReadOnlyMemory<byte>*/ memory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                while(!memory.IsEmpty)
                {
                    /*var*/ let currentPage = this.CurrentPage;
                    /*var*/ let copyLength = $.$$.S.Math.Min$4(memory.Length, ((currentPage.length - this._currentPageIndex) | 0));
                    memory.Slice(0, copyLength).CopyTo($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, currentPage, this._currentPageIndex, copyLength));
                    this.Length += copyLength;
                    this._currentPageIndex += copyLength;
                    memory = memory.Slice$1(copyLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656213115)
            
            //--TRIMMABLE-BOUNDARY-START(98785755259)
            /*void */ MoveTo(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    /*var*/ let page = this.Pages.get_Item(i);
                    /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                    stream.Write(page, 0, length);
                }
                this.ClearBuffers();
            }
            //--TRIMMABLE-BOUNDARY-END(98785755259)
            
            //--TRIMMABLE-BOUNDARY-START(103080722555)
            /*Task *//*async*/  MoveToAsync(/*PipeWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080722555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        let $t1, $r1;
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        ($t1 = writer.WriteAsync($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, page, 0, length)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    }
                    this.ClearBuffers();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080722555)
            
            //--TRIMMABLE-BOUNDARY-START(107375689851)
            /*Task *//*async*/  MoveToAsync$1(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375689851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        let $t2, $r2;
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        ($t2 = stream.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, page, 0, length)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    }
                    this.ClearBuffers();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375689851)
            
            //--TRIMMABLE-BOUNDARY-START(51541115003)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541115003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.ClearBuffers();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541115003)
            
            //--TRIMMABLE-BOUNDARY-START(42951180411)
            /*void */ ClearBuffers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    this._arrayPool.Return(this.Pages.get_Item(i), false);
                }
                this.Pages.Clear();
                this._currentPage = null;
                this.Length = 0;
                this._currentPageIndex = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(42951180411)
            
            //--TRIMMABLE-BOUNDARY-START(137440460923)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440460923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(137440460923)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 1507451;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490787963),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605886075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145493627,
        "f": 83886082
      },
      "n": "Length",
      "d": 1507451,
      "h": 94490787963,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490787963),
//--TRIMMABLE-BOUNDARY-START(55836082299),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015951483,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555559035,
        "f": 83886082
      },
      "n": "Disposed",
      "d": 1507451,
      "h": 55836082299,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55836082299),
//--TRIMMABLE-BOUNDARY-START(111670657147),
    {
      "p": $.$$.SCG.List$$($.$typeArray($.$$.S.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195820667,
        "f": 50331656
      },
      "n": "Pages",
      "d": 1507451,
      "h": 111670657147,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(111670657147),
//--TRIMMABLE-BOUNDARY-START(47246147707),
    {
      "p": $.$typeArray($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426016891,
        "f": 50331650
      },
      "n": "CurrentPage",
      "d": 1507451,
      "h": 47246147707,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246147707)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361245819),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Add",
      "d": 1507451,
      "h": 34361245819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245819),
//--TRIMMABLE-BOUNDARY-START(38656213115),
    {
      "r": 65537,
      "p": [
        {
          "n": "memory",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1507451,
      "h": 38656213115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656213115),
//--TRIMMABLE-BOUNDARY-START(98785755259),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "MoveTo",
      "d": 1507451,
      "h": 98785755259,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785755259),
//--TRIMMABLE-BOUNDARY-START(103080722555),
    {
      "r": 178454529,
      "p": [
        {
          "n": "writer",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "MoveToAsync",
      "d": 1507451,
      "h": 103080722555,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103080722555),
//--TRIMMABLE-BOUNDARY-START(107375689851),
    {
      "r": 178454529,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "MoveToAsync",
      "o": "@$1",
      "d": 1507451,
      "h": 107375689851,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107375689851),
//--TRIMMABLE-BOUNDARY-START(51541115003),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507451,
      "h": 51541115003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541115003),
//--TRIMMABLE-BOUNDARY-START(42951180411),
    {
      "r": 65537,
      "n": "ClearBuffers",
      "d": 1507451,
      "h": 42951180411,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951180411),
//--TRIMMABLE-BOUNDARY-START(137440460923),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 1507451,
      "h": 137440460923,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440460923)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115965624443),
    {
      "t": 655361,
      "n": "PageSize",
      "d": 1507451,
      "h": 115965624443,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965624443),
//--TRIMMABLE-BOUNDARY-START(4296474747),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_arrayPool",
      "d": 1507451,
      "h": 4296474747,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474747),
//--TRIMMABLE-BOUNDARY-START(8591442043),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_currentPage",
      "d": 1507451,
      "h": 8591442043,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442043),
//--TRIMMABLE-BOUNDARY-START(12886409339),
    {
      "t": 655361,
      "n": "_currentPageIndex",
      "d": 1507451,
      "h": 12886409339,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409339)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066278523),
    {
      "p": [
        {
          "n": "arrayPool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507451,
      "h": 30066278523,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066278523)
  ],
  "h": 1507451
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.PagedByteBuffer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}PagedByteBuffer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507451)
        
        

        //--TRIMMABLE-BOUNDARY-START(786555)
        $asm.$cls(`$maw.MAW.FormReader`, ($self) => class FormReader extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107374968955)
            /*int*/ static DefaultValueCountLimit = 1024;
            //--TRIMMABLE-BOUNDARY-END(107374968955)
            
            //--TRIMMABLE-BOUNDARY-START(103080001659)
            /*int*/ static DefaultKeyLengthLimit = 2048;
            //--TRIMMABLE-BOUNDARY-END(103080001659)
            
            //--TRIMMABLE-BOUNDARY-START(111669936251)
            /*int*/ static DefaultValueLengthLimit = 4194304;
            //--TRIMMABLE-BOUNDARY-END(111669936251)
            
            //--TRIMMABLE-BOUNDARY-START(47245426811)
            /*int*/ static _rentedCharPoolLength = 8192;
            //--TRIMMABLE-BOUNDARY-END(47245426811)
            
            //--TRIMMABLE-BOUNDARY-START(42950459515)
            /*TextReader*/ _reader = null;
            //--TRIMMABLE-BOUNDARY-END(42950459515)
            
            //--TRIMMABLE-BOUNDARY-START(4295753851)
            /*char[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295753851)
            
            //--TRIMMABLE-BOUNDARY-START(21475623035)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(21475623035)
            
            //--TRIMMABLE-BOUNDARY-START(17180655739)
            /*StringBuilder*/ _builder = null;
            //--TRIMMABLE-BOUNDARY-END(17180655739)
            
            //--TRIMMABLE-BOUNDARY-START(12885688443)
            /*int*/ _bufferOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(12885688443)
            
            //--TRIMMABLE-BOUNDARY-START(8590721147)
            /*int*/ _bufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(8590721147)
            
            //--TRIMMABLE-BOUNDARY-START(25770590331)
            /*string?*/ _currentKey = null;
            //--TRIMMABLE-BOUNDARY-END(25770590331)
            
            //--TRIMMABLE-BOUNDARY-START(30065557627)
            /*string?*/ _currentValue = null;
            //--TRIMMABLE-BOUNDARY-END(30065557627)
            
            //--TRIMMABLE-BOUNDARY-START(38655492219)
            /*bool*/ _endOfStream = false;
            //--TRIMMABLE-BOUNDARY-END(38655492219)
            
            //--TRIMMABLE-BOUNDARY-START(34360524923)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(34360524923)
            
            //--TRIMMABLE-BOUNDARY-START(81605165179)
            $ctor$5(/*string*/ data)
            {
                this.$ctor$4(data, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605165179);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605165179)
            
            //--TRIMMABLE-BOUNDARY-START(77310197883)
            $ctor$4(/*string*/ data, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310197883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(data, "data");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.SI.StringReader().$ctor$3(data);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310197883)
            
            //--TRIMMABLE-BOUNDARY-START(73015230587)
            $ctor$3(/*Stream*/ stream)
            {
                this.$ctor$1(stream, $.$$.ST.Encoding.UTF8, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015230587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015230587)
            
            //--TRIMMABLE-BOUNDARY-START(68720263291)
            $ctor$2(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$1(stream, encoding, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720263291);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263291)
            
            //--TRIMMABLE-BOUNDARY-START(64425295995)
            $ctor$1(/*Stream*/ stream, /*Encoding*/ encoding, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425295995);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.SI.StreamReader().$ctor$5(stream, encoding, true, ((1024 * 2) | 0), true);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425295995)
            
            //--TRIMMABLE-BOUNDARY-START(223339085947)
            /*int*/ ValueCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(223339085947)
            
            //--TRIMMABLE-BOUNDARY-START(146029674619)
            /*int*/ KeyLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(146029674619)
            
            //--TRIMMABLE-BOUNDARY-START(227634053243)
            /*int*/ ValueLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(227634053243)
            
            //--TRIMMABLE-BOUNDARY-START(163209543803)
            /*KeyValuePair<string, string>? */ ReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209543803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReadNextPairImpl();
                if (this.ReadSucceeded())
                {
                    return new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))().$ctor$3(this._currentKey, this._currentValue);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(163209543803)
            
            //--TRIMMABLE-BOUNDARY-START(176094445691)
            /*void */ ReadNextPairImpl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094445691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StartReadNextPair();
                while(!this._endOfStream)
                {
                    if (this._bufferCount === 0)
                    {
                        this.Buffer();
                    }
                    if (this.TryReadNextPair())
                    {
                        break;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094445691)
            
            //--TRIMMABLE-BOUNDARY-START(167504511099)
            /*Task<KeyValuePair<string, string>?> *//*async*/  ReadNextPairAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Nullable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))), $.$typeNullable($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504511099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.ReadNextPairAsyncImpl(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (this.ReadSucceeded())
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))().$ctor$3(this._currentKey, this._currentValue));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, null);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504511099)
            
            //--TRIMMABLE-BOUNDARY-START(171799478395)
            /*Task *//*async*/  ReadNextPairAsyncImpl(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799478395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.StartReadNextPair();
                    while(!this._endOfStream)
                    {
                        if (this._bufferCount === 0)
                        {
                            let $t2, $r2;
                            ($t2 = this.BufferAsync(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        }
                        if (this.TryReadNextPair())
                        {
                            break;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799478395)
            
            //--TRIMMABLE-BOUNDARY-START(210454184059)
            /*void */ StartReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454184059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._currentKey = null;
                this._currentValue = null;
            }
            //--TRIMMABLE-BOUNDARY-END(210454184059)
            
            //--TRIMMABLE-BOUNDARY-START(214749151355)
            /*bool */ TryReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749151355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentKey === null)
                {
                    if (!this.TryReadWord(/*=*/ 61, this.KeyLengthLimit, $.$ref(() => this._currentKey, ($v) => this._currentKey = $v, $.$$.S.String)))
                    {
                        return false;
                    }
                    if (this._bufferCount === 0)
                    {
                        return false;
                    }
                }
                if (this._currentValue === null)
                {
                    if (!this.TryReadWord(/*&*/ 38, this.ValueLengthLimit, $.$ref(() => this._currentValue, ($v) => this._currentValue = $v, $.$$.S.String)))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(214749151355)
            
            //--TRIMMABLE-BOUNDARY-START(219044118651)
            /*bool */ TryReadWord(/*char*/ separator, /*int*/ limit, /*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044118651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                do
                {
                    if (this.ReadChar(separator, limit, value))
                    {
                        return true;
                    }
                }
                while(this._bufferCount > 0);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(219044118651)
            
            //--TRIMMABLE-BOUNDARY-START(150324641915)
            /*bool */ ReadChar(/*char*/ separator, /*int*/ limit, /*out string?*/ word)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324641915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferCount === 0)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                /*var*/ let c = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset++);
                this._bufferCount--;
                if (c === separator)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                if (this._builder.Length >= limit)
                {
                    throw new $.$$.SI.InvalidDataException().$ctor$12(`Form key or value length limit ${$.$strNN(limit)} exceeded.`);
                }
                this._builder.Append$5(c);
                word.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(150324641915)
            
            //--TRIMMABLE-BOUNDARY-START(98785034363)
            /*string */ BuildWord()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._builder.Replace$1(/*+*/ 43, /* */ 32);
                /*var*/ let result = this._builder.ToString();
                this._builder.Clear();
                return $.$spu.S.Uri.UnescapeDataString$2(result);
            }
            //--TRIMMABLE-BOUNDARY-END(98785034363)
            
            //--TRIMMABLE-BOUNDARY-START(90195099771)
            /*void */ Buffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._bufferOffset = 0;
                this._bufferCount = this._reader.Read$1(this._buffer, 0, this._buffer.length);
                this._endOfStream = this._bufferCount === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(90195099771)
            
            //--TRIMMABLE-BOUNDARY-START(94490067067)
            /*Task *//*async*/  BufferAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490067067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    this._bufferOffset = 0;
                    this._bufferCount = ($t6 = this._reader.ReadAsync(this._buffer, 0, this._buffer.length), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                    this._endOfStream = this._bufferCount === 0;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490067067)
            
            //--TRIMMABLE-BOUNDARY-START(154619609211)
            /*Dictionary<string, StringValues> */ ReadForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619609211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accumulator = new $.$maw.MAW.KeyValueAccumulator().$ctor$2();
                while(!this._endOfStream)
                {
                    this.ReadNextPairImpl();
                    this.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$maw.MAW.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null, true));
                }
                return accumulator.GetResults();
            }
            //--TRIMMABLE-BOUNDARY-END(154619609211)
            
            //--TRIMMABLE-BOUNDARY-START(158914576507)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)), $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues), async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914576507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let accumulator = new $.$maw.MAW.KeyValueAccumulator().$ctor$2();
                    while(!this._endOfStream)
                    {
                        let $t8, $r8;
                        ($t8 = this.ReadNextPairAsyncImpl(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        this.Append($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$maw.MAW.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null, true));
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, accumulator.GetResults());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914576507)
            
            //--TRIMMABLE-BOUNDARY-START(180389412987)
            /*bool */ ReadSucceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389412987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._currentKey !== null && this._currentValue !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(180389412987)
            
            //--TRIMMABLE-BOUNDARY-START(85900132475)
            /*void */ Append(/*ref KeyValueAccumulator*/ accumulator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ReadSucceeded())
                {
                    accumulator.$v.Append(this._currentKey, this._currentValue);
                    if (accumulator.$v.ValueCount > this.ValueCountLimit)
                    {
                        throw new $.$$.SI.InvalidDataException().$ctor$12(`Form value count limit ${$.$strNN(this.ValueCountLimit)} exceeded.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900132475)
            
            //--TRIMMABLE-BOUNDARY-START(115964903547)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._charPool.Return(this._buffer, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903547)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180655739)
                this._builder = new $.$$.ST.StringBuilder().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180655739)
                
                //--TRIMMABLE-BOUNDARY-START(223339085947)
                this.ValueCountLimit = 1024;
                //--TRIMMABLE-BOUNDARY-END(223339085947)
                
                //--TRIMMABLE-BOUNDARY-START(146029674619)
                this.KeyLengthLimit = 2048;
                //--TRIMMABLE-BOUNDARY-END(146029674619)
                
                //--TRIMMABLE-BOUNDARY-START(227634053243)
                this.ValueLengthLimit = 4194304;
                //--TRIMMABLE-BOUNDARY-END(227634053243)
                
            }
            static $h = 786555;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(223339085947),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144772731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569282171,
        "f": 83886081
      },
      "n": "ValueCountLimit",
      "d": 786555,
      "h": 223339085947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339085947),
//--TRIMMABLE-BOUNDARY-START(146029674619),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554838139,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979347579,
        "f": 83886081
      },
      "n": "KeyLengthLimit",
      "d": 786555,
      "h": 146029674619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029674619),
//--TRIMMABLE-BOUNDARY-START(227634053243),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734707323,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159216763,
        "f": 83886081
      },
      "n": "ValueLengthLimit",
      "d": 786555,
      "h": 227634053243,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634053243)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163209543803),
    {
      "r": $.$typeNullable($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "n": "ReadNextPair",
      "d": 786555,
      "h": 163209543803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209543803),
//--TRIMMABLE-BOUNDARY-START(176094445691),
    {
      "r": 65537,
      "n": "ReadNextPairImpl",
      "d": 786555,
      "h": 176094445691,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094445691),
//--TRIMMABLE-BOUNDARY-START(167504511099),
    {
      "r": $.$$.STT.Task$$($.$$.S.Nullable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadNextPairAsync",
      "d": 786555,
      "h": 167504511099,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(167504511099),
//--TRIMMABLE-BOUNDARY-START(171799478395),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadNextPairAsyncImpl",
      "d": 786555,
      "h": 171799478395,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799478395),
//--TRIMMABLE-BOUNDARY-START(210454184059),
    {
      "r": 65537,
      "n": "StartReadNextPair",
      "d": 786555,
      "h": 210454184059,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454184059),
//--TRIMMABLE-BOUNDARY-START(214749151355),
    {
      "r": 262145,
      "n": "TryReadNextPair",
      "d": 786555,
      "h": 214749151355,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214749151355),
//--TRIMMABLE-BOUNDARY-START(219044118651),
    {
      "r": 262145,
      "p": [
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "limit",
          "p": 655361
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryReadWord",
      "d": 786555,
      "h": 219044118651,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044118651),
//--TRIMMABLE-BOUNDARY-START(150324641915),
    {
      "r": 262145,
      "p": [
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "limit",
          "p": 655361
        },
        {
          "n": "word",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "ReadChar",
      "d": 786555,
      "h": 150324641915,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324641915),
//--TRIMMABLE-BOUNDARY-START(98785034363),
    {
      "r": 1310721,
      "n": "BuildWord",
      "d": 786555,
      "h": 98785034363,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785034363),
//--TRIMMABLE-BOUNDARY-START(90195099771),
    {
      "r": 65537,
      "n": "Buffer",
      "d": 786555,
      "h": 90195099771,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195099771),
//--TRIMMABLE-BOUNDARY-START(94490067067),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "BufferAsync",
      "d": 786555,
      "h": 94490067067,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(94490067067),
//--TRIMMABLE-BOUNDARY-START(154619609211),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "n": "ReadForm",
      "d": 786555,
      "h": 154619609211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619609211),
//--TRIMMABLE-BOUNDARY-START(158914576507),
    {
      "r": $.$$.STT.Task$$($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadFormAsync",
      "d": 786555,
      "h": 158914576507,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(158914576507),
//--TRIMMABLE-BOUNDARY-START(180389412987),
    {
      "r": 262145,
      "n": "ReadSucceeded",
      "d": 786555,
      "h": 180389412987,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389412987),
//--TRIMMABLE-BOUNDARY-START(85900132475),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulator",
          "p": 1048699,
          "f": 4
        }
      ],
      "n": "Append",
      "d": 786555,
      "h": 85900132475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900132475),
//--TRIMMABLE-BOUNDARY-START(115964903547),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786555,
      "h": 115964903547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964903547)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374968955),
    {
      "t": 655361,
      "n": "DefaultValueCountLimit",
      "d": 786555,
      "h": 107374968955,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374968955),
//--TRIMMABLE-BOUNDARY-START(103080001659),
    {
      "t": 655361,
      "n": "DefaultKeyLengthLimit",
      "d": 786555,
      "h": 103080001659,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080001659),
//--TRIMMABLE-BOUNDARY-START(111669936251),
    {
      "t": 655361,
      "n": "DefaultValueLengthLimit",
      "d": 786555,
      "h": 111669936251,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669936251),
//--TRIMMABLE-BOUNDARY-START(47245426811),
    {
      "t": 655361,
      "n": "_rentedCharPoolLength",
      "d": 786555,
      "h": 47245426811,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245426811),
//--TRIMMABLE-BOUNDARY-START(42950459515),
    {
      "t": 96468993,
      "n": "_reader",
      "d": 786555,
      "h": 42950459515,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950459515),
//--TRIMMABLE-BOUNDARY-START(4295753851),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_buffer",
      "d": 786555,
      "h": 4295753851,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753851),
//--TRIMMABLE-BOUNDARY-START(21475623035),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Char).$h,
      "n": "_charPool",
      "d": 786555,
      "h": 21475623035,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475623035),
//--TRIMMABLE-BOUNDARY-START(17180655739),
    {
      "t": 167837697,
      "n": "_builder",
      "d": 786555,
      "h": 17180655739,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655739),
//--TRIMMABLE-BOUNDARY-START(12885688443),
    {
      "t": 655361,
      "n": "_bufferOffset",
      "d": 786555,
      "h": 12885688443,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688443),
//--TRIMMABLE-BOUNDARY-START(8590721147),
    {
      "t": 655361,
      "n": "_bufferCount",
      "d": 786555,
      "h": 8590721147,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721147),
//--TRIMMABLE-BOUNDARY-START(25770590331),
    {
      "t": 1310721,
      "n": "_currentKey",
      "d": 786555,
      "h": 25770590331,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770590331),
//--TRIMMABLE-BOUNDARY-START(30065557627),
    {
      "t": 1310721,
      "n": "_currentValue",
      "d": 786555,
      "h": 30065557627,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065557627),
//--TRIMMABLE-BOUNDARY-START(38655492219),
    {
      "t": 262145,
      "n": "_endOfStream",
      "d": 786555,
      "h": 38655492219,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655492219),
//--TRIMMABLE-BOUNDARY-START(34360524923),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 786555,
      "h": 34360524923,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360524923)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81605165179),
    {
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786555,
      "h": 81605165179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605165179),
//--TRIMMABLE-BOUNDARY-START(77310197883),
    {
      "p": [
        {
          "n": "data",
          "p": 1310721
        },
        {
          "n": "charPool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786555,
      "h": 77310197883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310197883),
//--TRIMMABLE-BOUNDARY-START(73015230587),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786555,
      "h": 73015230587,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015230587),
//--TRIMMABLE-BOUNDARY-START(68720263291),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786555,
      "h": 68720263291,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263291),
//--TRIMMABLE-BOUNDARY-START(64425295995),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "charPool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786555,
      "h": 64425295995,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425295995)
  ],
  "h": 786555
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FormReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FormReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786555)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048699)
        $asm.$str(`$maw.MAW.KeyValueAccumulator`, ($self) => class KeyValueAccumulator extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296015995)
            /*Dictionary<string, StringValues>*/ _accumulator = null;
            //--TRIMMABLE-BOUNDARY-END(4296015995)
            
            //--TRIMMABLE-BOUNDARY-START(8590983291)
            /*Dictionary<string, List<string>>*/ _expandingAccumulator = null;
            //--TRIMMABLE-BOUNDARY-END(8590983291)
            
            //--TRIMMABLE-BOUNDARY-START(21475885179)
            /*void */ Append(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._accumulator === null)
                {
                    this._accumulator = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                }
                /*StringValues*/ let values;
                if (this._accumulator.TryGetValue(key, $.$ref(() => values, ($v) => values = $v, $.$mep.MEP.StringValues)))
                {
                    if (values.Count === 0)
                    {
                        this._expandingAccumulator.get_Item(key).Add(value);
                    }
                    else if (values.Count === 1)
                    {
                        this._accumulator.set_Item(key, $.$mep.MEP.StringValues.op_Implicit$3($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.String), [values.get_Item$1(0), value], [-1], null)));
                    }
                    else 
                    {
                        this._accumulator.set_Item(key, $.$default($.$mep.MEP.StringValues));
                        if (this._expandingAccumulator === null)
                        {
                            this._expandingAccumulator = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                        }
                        /*var*/ let list = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$3(8);
                        /*var*/ let array = values.ToArray();
                        list.Add($.$$.System.Array.$ReadT1.call(array, 0));
                        list.Add($.$$.System.Array.$ReadT1.call(array, 1));
                        list.Add(value);
                        this._expandingAccumulator.set_Item(key, list);
                    }
                }
                else 
                {
                    this._accumulator.set_Item(key, new $.$mep.MEP.StringValues().$ctor$3(value));
                }
                this.ValueCount++;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885179)
            
            //--TRIMMABLE-BOUNDARY-START(55835623547)
            /*bool */ get HasValues()
            {
                return this.ValueCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(55835623547)
            
            //--TRIMMABLE-BOUNDARY-START(60130590843)
            /*int */ get KeyCount()
            {
                return (this._accumulator?.Count ?? null) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(60130590843)
            
            //--TRIMMABLE-BOUNDARY-START(73015492731)
            /*int*/ ValueCount = 0;
            //--TRIMMABLE-BOUNDARY-END(73015492731)
            
            //--TRIMMABLE-BOUNDARY-START(51540656251)
            /*Dictionary<string, StringValues> */ GetResults()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._expandingAccumulator !== null)
                {
                    let $en2 = this._expandingAccumulator.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let entry = $en2.Current;
                        {
                            this._accumulator.set_Item(entry.Key, new $.$mep.MEP.StringValues().$ctor$4(entry.Value.ToArray()));
                        }
                    }
                }
                return this._accumulator ?? new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues))().$ctor$7(0, $.$$.S.StringComparer.OrdinalIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(51540656251)
            
            //--TRIMMABLE-BOUNDARY-START(17180917883)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180917883)
            
            //--TRIMMABLE-BOUNDARY-START(17180917883)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(17180917883)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._accumulator = this._accumulator;
                copy._expandingAccumulator = this._expandingAccumulator;
                copy.ValueCount = this.ValueCount;
                return copy;
            }
            static $h = 1048699;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835623547),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065819771,
        "f": 50331649
      },
      "n": "HasValues",
      "d": 1048699,
      "h": 55835623547,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835623547),
//--TRIMMABLE-BOUNDARY-START(60130590843),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655754363,
        "f": 50331649
      },
      "n": "KeyCount",
      "d": 1048699,
      "h": 60130590843,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130590843),
//--TRIMMABLE-BOUNDARY-START(73015492731),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245688955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720525435,
        "f": 83886082
      },
      "n": "ValueCount",
      "d": 1048699,
      "h": 73015492731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015492731)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475885179),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Append",
      "d": 1048699,
      "h": 21475885179,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885179),
//--TRIMMABLE-BOUNDARY-START(51540656251),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "n": "GetResults",
      "d": 1048699,
      "h": 51540656251,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540656251)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296015995),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$mep.MEP.StringValues).$h,
      "n": "_accumulator",
      "d": 1048699,
      "h": 4296015995,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015995),
//--TRIMMABLE-BOUNDARY-START(8590983291),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.SCG.List$$($.$$.S.String)).$h,
      "n": "_expandingAccumulator",
      "d": 1048699,
      "h": 8590983291,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983291)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180917883),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048699,
      "h": 17180917883,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917883)
  ],
  "h": 1048699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}KeyValueAccumulator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048699)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638523)
        $asm.$str(`$maw.MAW.QueryStringEnumerable`, ($self) => class QueryStringEnumerable extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296605819)
            /*ReadOnlyMemory<char>*/ _queryString;
            //--TRIMMABLE-BOUNDARY-END(4296605819)
            
            //--TRIMMABLE-BOUNDARY-START(17181507707)
            $ctor$4(/*string?*/ queryString)
            {
                this.$ctor$3($.$$.S.MemoryExtensions.AsMemory$4(queryString));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181507707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507707)
            
            //--TRIMMABLE-BOUNDARY-START(12886540411)
            $ctor$3(/*ReadOnlyMemory<char>*/ queryString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540411);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._queryString = queryString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540411)
            
            //--TRIMMABLE-BOUNDARY-START(21476475003)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476475003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$maw.MAW.QueryStringEnumerable.Enumerator().$ctor$3(this._queryString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476475003)
            
            //--TRIMMABLE-BOUNDARY-START(1704059)
            static $_EncodedNameValuePair;
            static get EncodedNameValuePair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1704059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$maw.MAW.QueryStringEnumerable;
                return $cls.$_EncodedNameValuePair ??= $asm.$nstr(`$maw.MAW.QueryStringEnumerable.EncodedNameValuePair`, ($self) => class EncodedNameValuePair extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34361442427)
                    /*ReadOnlyMemory<char>*/ EncodedName;
                    //--TRIMMABLE-BOUNDARY-END(34361442427)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656409723)
                    /*ReadOnlyMemory<char>*/ EncodedValue;
                    //--TRIMMABLE-BOUNDARY-END(38656409723)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181573243)
                    $ctor$3(/*ReadOnlyMemory<char>*/ encodedName, /*ReadOnlyMemory<char>*/ encodedValue)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181573243);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.EncodedName = encodedName;
                            this.EncodedValue = encodedValue;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181573243)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771507835)
                    /*ReadOnlyMemory<char> */ DecodeName()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771507835);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedName);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771507835)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066475131)
                    /*ReadOnlyMemory<char> */ DecodeValue()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066475131);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedValue);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066475131)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476540539)
                    static /*ReadOnlyMemory<char> */ Decode(/*ReadOnlyMemory<char>*/ chars)
                    {
                        /*var*/ let unescapedLength;
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476540539);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ReadOnlySpan<char>*/ let source = chars.Span;
                        if (!$.$$.S.MemoryExtensions.ContainsAny$8($.$$.S.Char, source, /*%*/ 37, /*+*/ 43))
                        {
                            return chars;
                        }
                        /*var*/ let buffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), null, [source.Length], null);
                        $.$$.S.MemoryExtensions.Replace$1($.$$.S.Char, source, $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(buffer), /*+*/ 43, /* */ 32);
                        /*var*/ let success = $.$spu.S.Uri.TryUnescapeDataString($.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1(buffer), $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(buffer), $.$ref(() => unescapedLength, ($v) => unescapedLength = $v, $.$$.S.Int32));
                        $.$$.SD.Debug.Assert$4(success, "success");
                        return $.$$.S.Memory$$($.$$.S.Char).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Char, buffer, 0, unescapedLength));
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476540539)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886605947)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886605947);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886605947)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886605947)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886605947)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.EncodedName = this.EncodedName.$clone();
                        copy.EncodedValue = this.EncodedValue.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34361442427)
                        this.EncodedName = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Char));
                        //--TRIMMABLE-BOUNDARY-END(34361442427)
                        
                        //--TRIMMABLE-BOUNDARY-START(38656409723)
                        this.EncodedValue = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Char));
                        //--TRIMMABLE-BOUNDARY-END(38656409723)
                        
                    }
                    static $h = 1704059;
                    static $z = 24;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361442427),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246344315,
        "f": 50331649
      },
      "n": "EncodedName",
      "d": 1704059,
      "h": 34361442427,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361442427),
//--TRIMMABLE-BOUNDARY-START(38656409723),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836278907,
        "f": 50331649
      },
      "n": "EncodedValue",
      "d": 1704059,
      "h": 38656409723,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409723)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771507835),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "DecodeName",
      "d": 1704059,
      "h": 25771507835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507835),
//--TRIMMABLE-BOUNDARY-START(30066475131),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "DecodeValue",
      "d": 1704059,
      "h": 30066475131,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475131),
//--TRIMMABLE-BOUNDARY-START(21476540539),
    {
      "r": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "p": [
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": "Decode",
      "d": 1704059,
      "h": 21476540539,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476540539)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181573243),
    {
      "p": [
        {
          "n": "encodedName",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        },
        {
          "n": "encodedValue",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704059,
      "h": 17181573243,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181573243),
//--TRIMMABLE-BOUNDARY-START(12886605947),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704059,
      "h": 12886605947,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605947)
  ],
  "d": 1638523,
  "h": 1704059
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable+EncodedNameValuePair`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}QueryStringEnumerable${separator}EncodedNameValuePair`; }
                }, $cls, ($v) => $cls.$_EncodedNameValuePair = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1704059)
            
            //--TRIMMABLE-BOUNDARY-START(1769595)
            static $_Enumerator;
            static get Enumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1769595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$maw.MAW.QueryStringEnumerable;
                return $cls.$_Enumerator ??= $asm.$nstr(`$maw.MAW.QueryStringEnumerable.Enumerator`, ($self) => class Enumerator extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736891)
                    /*ReadOnlyMemory<char>*/ _query;
                    //--TRIMMABLE-BOUNDARY-END(4296736891)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638779)
                    $ctor$3(/*ReadOnlyMemory<char>*/ query)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181638779);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Current = new $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair();
                            this._query = query.IsEmpty || query.Span._reference.GetAt(0) !== /*?*/ 63 ? query : query.Slice$1(1);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181638779)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476606075)
                    /*EncodedNameValuePair*/ Current;
                    //--TRIMMABLE-BOUNDARY-END(21476606075)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361507963)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361507963);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        while(!this._query.IsEmpty)
                        {
                            /*ReadOnlyMemory<char>*/ let segment;
                            /*var*/ let delimiterIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, this._query.Span, /*&*/ 38);
                            if (delimiterIndex >= 0)
                            {
                                segment = this._query.Slice(0, delimiterIndex);
                                this._query = this._query.Slice$1(((delimiterIndex + 1) | 0));
                            }
                            else 
                            {
                                segment = this._query;
                                this._query = new ($.$$.S.ReadOnlyMemory$$($.$$.S.Char))();
                            }
                            /*var*/ let equalIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, segment.Span, /*=*/ 61);
                            if (equalIndex >= 0)
                            {
                                this.Current = new $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment.Slice(0, equalIndex), segment.Slice$1(((equalIndex + 1) | 0)));
                                return true;
                            }
                            else if (!segment.IsEmpty)
                            {
                                this.Current = new $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment, new ($.$$.S.ReadOnlyMemory$$($.$$.S.Char))());
                                return true;
                            }
                        }
                        this.Current = new $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair();
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361507963)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671483)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886671483);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671483)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671483)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671483)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._query = this._query.$clone();
                        copy.Current = this.Current.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296736891)
                        this._query = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Char));
                        //--TRIMMABLE-BOUNDARY-END(4296736891)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476606075)
                        this.Current = $.$default($.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair);
                        //--TRIMMABLE-BOUNDARY-END(21476606075)
                        
                    }
                    static $h = 1769595;
                    static $z = 36;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476606075),
    {
      "p": 1704059,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951442555,
        "f": 83886082
      },
      "n": "Current",
      "d": 1769595,
      "h": 21476606075,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476606075)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361507963),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1769595,
      "h": 34361507963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361507963)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736891),
    {
      "t": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "_query",
      "d": 1769595,
      "h": 4296736891,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736891)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638779),
    {
      "p": [
        {
          "n": "query",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769595,
      "h": 17181638779,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181638779),
//--TRIMMABLE-BOUNDARY-START(12886671483),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769595,
      "h": 12886671483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671483)
  ],
  "d": 1638523,
  "h": 1769595
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable+Enumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}QueryStringEnumerable${separator}Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769595)
            
            //--TRIMMABLE-BOUNDARY-START(8591573115)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573115)
            
            //--TRIMMABLE-BOUNDARY-START(8591573115)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8591573115)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._queryString = this._queryString.$clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296605819)
                this._queryString = $.$default($.$$.S.ReadOnlyMemory$$($.$$.S.Char));
                //--TRIMMABLE-BOUNDARY-END(4296605819)
                
            }
            static $h = 1638523;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476475003),
    {
      "r": 1769595,
      "n": "GetEnumerator",
      "d": 1638523,
      "h": 21476475003,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476475003)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605819),
    {
      "t": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h,
      "n": "_queryString",
      "d": 1638523,
      "h": 4296605819,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181507707),
    {
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1638523,
      "h": 17181507707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181507707),
//--TRIMMABLE-BOUNDARY-START(12886540411),
    {
      "p": [
        {
          "n": "queryString",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638523,
      "h": 12886540411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540411),
//--TRIMMABLE-BOUNDARY-START(8591573115),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638523,
      "h": 8591573115,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591573115)
  ],
  "h": 1638523
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$maw.MAW.QueryStringEnumerable.EncodedNameValuePair, $.$maw.MAW.QueryStringEnumerable.Enumerator ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}QueryStringEnumerable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638523)
        
        

        //--TRIMMABLE-BOUNDARY-START(852091)
        $asm.$cls(`$maw.MAW.HttpRequestStreamReader`, ($self) => class HttpRequestStreamReader extends $.$$.SI.TextReader
        {
            //--TRIMMABLE-BOUNDARY-START(73015296123)
            /*int*/ static DefaultBufferSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(73015296123)
            
            //--TRIMMABLE-BOUNDARY-START(55835426939)
            /*Stream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(55835426939)
            
            //--TRIMMABLE-BOUNDARY-START(47245492347)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(47245492347)
            
            //--TRIMMABLE-BOUNDARY-START(38655557755)
            /*Decoder*/ _decoder = null;
            //--TRIMMABLE-BOUNDARY-END(38655557755)
            
            //--TRIMMABLE-BOUNDARY-START(12885753979)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(12885753979)
            
            //--TRIMMABLE-BOUNDARY-START(30065623163)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(30065623163)
            
            //--TRIMMABLE-BOUNDARY-START(8590786683)
            /*int*/ _byteBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(8590786683)
            
            //--TRIMMABLE-BOUNDARY-START(4295819387)
            /*byte[]*/ _byteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295819387)
            
            //--TRIMMABLE-BOUNDARY-START(21475688571)
            /*char[]*/ _charBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(21475688571)
            
            //--TRIMMABLE-BOUNDARY-START(25770655867)
            /*int*/ _charBufferIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(25770655867)
            
            //--TRIMMABLE-BOUNDARY-START(34360590459)
            /*int*/ _charsRead = 0;
            //--TRIMMABLE-BOUNDARY-END(34360590459)
            
            //--TRIMMABLE-BOUNDARY-START(17180721275)
            /*int*/ _bytesRead = 0;
            //--TRIMMABLE-BOUNDARY-END(17180721275)
            
            //--TRIMMABLE-BOUNDARY-START(51540459643)
            /*bool*/ _isBlocked = false;
            //--TRIMMABLE-BOUNDARY-END(51540459643)
            
            //--TRIMMABLE-BOUNDARY-START(42950525051)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(42950525051)
            
            //--TRIMMABLE-BOUNDARY-START(68720328827)
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$3(stream, encoding, 1024/*DefaultBufferSize*/, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720328827);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328827)
            
            //--TRIMMABLE-BOUNDARY-START(64425361531)
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$3(stream, encoding, bufferSize, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361531);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425361531)
            
            //--TRIMMABLE-BOUNDARY-START(60130394235)
            $ctor$3(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130394235);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("stream") });
                    this._encoding = $.$firstOf(encoding, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, bufferSize, "bufferSize");
                    if (!stream.CanRead)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$maw.Resources.HttpRequestStreamReader_StreamNotReadable, "stream");
                    }
                    this._byteBufferSize = bufferSize;
                    this._decoder = encoding.GetDecoder();
                    this._byteBuffer = this._bytePool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxCharCount(bufferSize);
                        this._charBuffer = this._charPool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        this._bytePool.Return(this._byteBuffer, false);
                        if (this._charBuffer !== null)
                        {
                            this._charPool.Return(this._charBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130394235)
            
            //--TRIMMABLE-BOUNDARY-START(77310263419)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._byteBuffer, false);
                    this._charPool.Return(this._charBuffer, false);
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(77310263419)
            
            //--TRIMMABLE-BOUNDARY-START(81605230715)
            /*int */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this._isBlocked || this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(81605230715)
            
            //--TRIMMABLE-BOUNDARY-START(85900198011)
            /*int */ Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900198011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex++);
            }
            //--TRIMMABLE-BOUNDARY-END(85900198011)
            
            //--TRIMMABLE-BOUNDARY-START(90195165307)
            /*int */ Read$1(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let span = new ($.$$.S.Span$$($.$$.S.Char))().$ctor$6(buffer, index, count);
                return this.Read$2(span);
            }
            //--TRIMMABLE-BOUNDARY-END(90195165307)
            
            //--TRIMMABLE-BOUNDARY-START(94490132603)
            /*int */ Read$2(/*Span<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let count = buffer.Length;
                /*var*/ let charsRead = 0;
                while(count > 0)
                {
                    /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                    if (charsRemaining === 0)
                    {
                        charsRemaining = this.ReadIntoBuffer();
                    }
                    if (charsRemaining === 0)
                    {
                        break;
                    }
                    if (charsRemaining > count)
                    {
                        charsRemaining = count;
                    }
                    /*var*/ let source = new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))().$ctor$6(this._charBuffer, this._charBufferIndex, charsRemaining);
                    source.CopyTo(buffer);
                    this._charBufferIndex += charsRemaining;
                    charsRead += charsRemaining;
                    count -= charsRemaining;
                    buffer = buffer.Slice(charsRemaining, count);
                    if (this._isBlocked)
                    {
                        break;
                    }
                }
                return charsRead;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132603)
            
            //--TRIMMABLE-BOUNDARY-START(98785099899)
            /*Task<int> */ ReadAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let memory = new ($.$$.S.Memory$$($.$$.S.Char))().$ctor$6(buffer, index, count);
                return this.ReadAsync$1(memory, new $.$$.ST$1.CancellationToken()).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(98785099899)
            
            //--TRIMMABLE-BOUNDARY-START(103080067195)
            /*ValueTask<int> *//*async*/  ReadAsync$1(/*Memory<char>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080067195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if (this._charBufferIndex === this._charsRead && ($t1 = this.ReadIntoBufferAsync(), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))) === 0)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                    }
                    /*var*/ let count = buffer.Length;
                    /*var*/ let charsRead = 0;
                    while(count > 0)
                    {
                        /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                        if (charsRemaining === 0)
                        {
                            this._charsRead = 0;
                            this._charBufferIndex = 0;
                            this._bytesRead = 0;
                            do
                            {
                                let $t2, $r2;
                                $.$$.SD.Debug.Assert$4(charsRemaining === 0, "charsRemaining == 0");
                                this._bytesRead = ($t2 = this._stream.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._byteBuffer, 0, this._byteBufferSize), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                                if (this._bytesRead === 0)
                                {
                                    this._isBlocked = true;
                                    break;
                                }
                                this._isBlocked = (this._bytesRead < this._byteBufferSize);
                                $.$$.SD.Debug.Assert$4(charsRemaining === 0, "charsRemaining == 0");
                                this._charBufferIndex = 0;
                                charsRemaining = this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, 0);
                                $.$$.SD.Debug.Assert$4(charsRemaining > 0, "charsRemaining > 0");
                                this._charsRead += charsRemaining;
                            }
                            while(charsRemaining === 0);
                            if (charsRemaining === 0)
                            {
                                break;
                            }
                        }
                        if (charsRemaining > count)
                        {
                            charsRemaining = count;
                        }
                        /*var*/ let source = new ($.$$.S.Memory$$($.$$.S.Char))().$ctor$6(this._charBuffer, this._charBufferIndex, charsRemaining);
                        source.CopyTo(buffer);
                        this._charBufferIndex += charsRemaining;
                        charsRead += charsRemaining;
                        count -= charsRemaining;
                        buffer = buffer.Slice(charsRemaining, count);
                        if (this._isBlocked)
                        {
                            break;
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, charsRead);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080067195)
            
            //--TRIMMABLE-BOUNDARY-START(120259936379)
            /*Task<string?> *//*async*/  ReadLineAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259936379);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    /*StringBuilder?*/ let sb = null;
                    /*var*/ let consumeLineFeed = false;
                    while(true)
                    {
                        if (this._charBufferIndex === this._charsRead)
                        {
                            let $t3, $r3;
                            if (($t3 = this.ReadIntoBufferAsync(), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))) === 0)
                            {
                                return $.$$.N.AsyncResolver.Result($asnycContext, sb?.ToString() ?? null);
                            }
                        }
                        /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.ST.StringBuilder), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null, true));
                        if (stepResult.Completed)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, stepResult.Result ?? (sb?.ToString() ?? null));
                        }
                        continue;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(120259936379)
            
            //--TRIMMABLE-BOUNDARY-START(115964969083)
            /*string? */ ReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*StringBuilder?*/ let sb = null;
                /*var*/ let consumeLineFeed = false;
                while(true)
                {
                    if (this._charBufferIndex === this._charsRead)
                    {
                        if (this.ReadIntoBuffer() === 0)
                        {
                            return sb?.ToString() ?? null;
                        }
                    }
                    /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.ST.StringBuilder), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null, true));
                    if (stepResult.Completed)
                    {
                        return stepResult.Result ?? (sb?.ToString() ?? null);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964969083)
            
            //--TRIMMABLE-BOUNDARY-START(124554903675)
            /*ReadLineStepResult */ ReadLineStep(/*ref StringBuilder?*/ sb, /*ref bool*/ consumeLineFeed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char*/ let carriageReturn = /*\r*/ 13;
                /*char*/ let lineFeed = /*\n*/ 10;
                if (consumeLineFeed.$v)
                {
                    if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                    {
                        this._charBufferIndex++;
                    }
                    return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.Done;
                }
                /*var*/ let span = new ($.$$.S.Span$$($.$$.S.Char))().$ctor$6(this._charBuffer, this._charBufferIndex, ((this._charsRead - this._charBufferIndex) | 0));
                /*var*/ let index = $.$$.S.MemoryExtensions.IndexOfAny$8($.$$.S.Char, $.$$.S.Span$$($.$$.S.Char).op_Implicit(span), carriageReturn, lineFeed);
                if (index !== -1)
                {
                    if (span._reference.GetAt(index) === carriageReturn)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (this._charBufferIndex < this._charsRead)
                        {
                            if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                            {
                                this._charBufferIndex++;
                            }
                            if (sb.$v !== null)
                            {
                                sb.$v.Append$17($.$$.S.Span$$($.$$.S.Char).op_Implicit(span));
                                return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.Done;
                            }
                            return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.FromResult(span.ToString());
                        }
                        sb.$v ??= new $.$$.ST.StringBuilder().$ctor$1();
                        sb.$v.Append$17($.$$.S.Span$$($.$$.S.Char).op_Implicit(span));
                        consumeLineFeed.$v = true;
                        return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.Continue;
                    }
                    if (span._reference.GetAt(index) === lineFeed)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (sb.$v !== null)
                        {
                            sb.$v.Append$17($.$$.S.Span$$($.$$.S.Char).op_Implicit(span));
                            return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.Done;
                        }
                        return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.FromResult(span.ToString());
                    }
                }
                sb.$v ??= new $.$$.ST.StringBuilder().$ctor$1();
                sb.$v.Append$17($.$$.S.Span$$($.$$.S.Char).op_Implicit(span));
                this._charBufferIndex = this._charsRead;
                return $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult.Continue;
            }
            //--TRIMMABLE-BOUNDARY-END(124554903675)
            
            //--TRIMMABLE-BOUNDARY-START(107375034491)
            /*int */ ReadIntoBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375034491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._charsRead = 0;
                this._charBufferIndex = 0;
                this._bytesRead = 0;
                do
                {
                    this._bytesRead = this._stream.Read(this._byteBuffer, 0, this._byteBufferSize);
                    if (this._bytesRead === 0)
                    {
                        return this._charsRead;
                    }
                    this._isBlocked = (this._bytesRead < this._byteBufferSize);
                    this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                }
                while(this._charsRead === 0);
                return this._charsRead;
            }
            //--TRIMMABLE-BOUNDARY-END(107375034491)
            
            //--TRIMMABLE-BOUNDARY-START(111670001787)
            /*Task<int> *//*async*/  ReadIntoBufferAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670001787);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._charsRead = 0;
                    this._charBufferIndex = 0;
                    this._bytesRead = 0;
                    do
                    {
                        let $t8, $r8;
                        this._bytesRead = ($t8 = this._stream.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._byteBuffer, 0, this._byteBufferSize), new $.$$.ST$1.CancellationToken()).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        if (this._bytesRead === 0)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, this._charsRead);
                        }
                        this._isBlocked = (this._bytesRead < this._byteBufferSize);
                        this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                    }
                    while(this._charsRead === 0);
                    return $.$$.N.AsyncResolver.Result($asnycContext, this._charsRead);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(111670001787)
            
            //--TRIMMABLE-BOUNDARY-START(128849870971)
            /*Task<string> *//*async*/  ReadToEndAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849870971);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*StringBuilder*/ let sb = new $.$$.ST.StringBuilder().$ctor$4(((this._charsRead - this._charBufferIndex) | 0));
                    do
                    {
                        let $t9, $r9;
                        /*int*/ let tmpCharPos = this._charBufferIndex;
                        sb.Append$6(this._charBuffer, tmpCharPos, ((this._charsRead - tmpCharPos) | 0));
                        this._charBufferIndex = this._charsRead;
                        ($t9 = this.ReadIntoBufferAsync().ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                    }
                    while(this._charsRead > 0);
                    return $.$$.N.AsyncResolver.Result($asnycContext, sb.ToString());
                });
            }
            //--TRIMMABLE-BOUNDARY-END(128849870971)
            
            //--TRIMMABLE-BOUNDARY-START(917627)
            static $_ReadLineStepResult;
            static get ReadLineStepResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$maw.MAW.HttpRequestStreamReader;
                return $cls.$_ReadLineStepResult ??= $asm.$nstr(`$maw.MAW.HttpRequestStreamReader.ReadLineStepResult`, ($self) => class ReadLineStepResult extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655995)
                    /*ReadLineStepResult*/ static Done;
                    //--TRIMMABLE-BOUNDARY-END(34360655995)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688699)
                    /*ReadLineStepResult*/ static Continue;
                    //--TRIMMABLE-BOUNDARY-END(30065688699)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655623291)
                    static /*ReadLineStepResult */ FromResult(/*string*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655623291);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655623291)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754107)
                    $ctor$3(/*bool*/ completed, /*string?*/ result)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475754107);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Completed = completed;
                            this.Result = result;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475754107)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721403)
                    /*bool*/ Completed = false;
                    //--TRIMMABLE-BOUNDARY-END(25770721403)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130459771)
                    /*string?*/ Result = null;
                    //--TRIMMABLE-BOUNDARY-END(60130459771)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786811)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180786811);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786811)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786811)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786811)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Completed = this.Completed;
                        copy.Result = this.Result;
                        return copy;
                    }
                    //--TRIMMABLE-BOUNDARY-START(12885819515)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885819515);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(34360655995)
                            this.Done = new $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, null);
                            //--TRIMMABLE-BOUNDARY-END(34360655995)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065688699)
                            this.Continue = new $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(false, null);
                            //--TRIMMABLE-BOUNDARY-END(30065688699)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885819515)
                    
                    static $h = 917627;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770721403),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557883,
        "f": 50331649
      },
      "n": "Completed",
      "d": 917627,
      "h": 25770721403,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721403),
//--TRIMMABLE-BOUNDARY-START(60130459771),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835492475,
        "f": 50331649
      },
      "n": "Result",
      "d": 917627,
      "h": 60130459771,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459771)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655623291),
    {
      "r": 917627,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "FromResult",
      "d": 917627,
      "h": 38655623291,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655623291)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360655995),
    {
      "t": 917627,
      "n": "Done",
      "d": 917627,
      "h": 34360655995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655995),
//--TRIMMABLE-BOUNDARY-START(30065688699),
    {
      "t": 917627,
      "n": "Continue",
      "d": 917627,
      "h": 30065688699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475754107),
    {
      "p": [
        {
          "n": "completed",
          "p": 262145
        },
        {
          "n": "result",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917627,
      "h": 21475754107,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475754107),
//--TRIMMABLE-BOUNDARY-START(17180786811),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917627,
      "h": 17180786811,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786811)
  ],
  "d": 852091,
  "h": 917627
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader+ReadLineStepResult`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}HttpRequestStreamReader${separator}ReadLineStepResult`; }
                }, $cls, ($v) => $cls.$_ReadLineStepResult = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917627)
            
            //--TRIMMABLE-BOUNDARY-START(133144838267)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(133144838267)
            
            static $h = 852091;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.TextReader; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310263419),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 852091,
      "h": 77310263419,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(77310263419),
//--TRIMMABLE-BOUNDARY-START(81605230715),
    {
      "r": 655361,
      "n": "Peek",
      "d": 852091,
      "h": 81605230715,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605230715),
//--TRIMMABLE-BOUNDARY-START(85900198011),
    {
      "r": 655361,
      "n": "Read",
      "d": 852091,
      "h": 85900198011,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900198011),
//--TRIMMABLE-BOUNDARY-START(90195165307),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 852091,
      "h": 90195165307,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195165307),
//--TRIMMABLE-BOUNDARY-START(94490132603),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "Read",
      "o": "@$2",
      "d": 852091,
      "h": 94490132603,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490132603),
//--TRIMMABLE-BOUNDARY-START(98785099899),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ReadAsync",
      "d": 852091,
      "h": 98785099899,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785099899),
//--TRIMMABLE-BOUNDARY-START(103080067195),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$1",
      "d": 852091,
      "h": 103080067195,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(103080067195),
//--TRIMMABLE-BOUNDARY-START(120259936379),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "n": "ReadLineAsync",
      "d": 852091,
      "h": 120259936379,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(120259936379),
//--TRIMMABLE-BOUNDARY-START(115964969083),
    {
      "r": 1310721,
      "n": "ReadLine",
      "d": 852091,
      "h": 115964969083,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964969083),
//--TRIMMABLE-BOUNDARY-START(124554903675),
    {
      "r": 917627,
      "p": [
        {
          "n": "sb",
          "p": 167837697,
          "f": 4
        },
        {
          "n": "consumeLineFeed",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ReadLineStep",
      "d": 852091,
      "h": 124554903675,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554903675),
//--TRIMMABLE-BOUNDARY-START(107375034491),
    {
      "r": 655361,
      "n": "ReadIntoBuffer",
      "d": 852091,
      "h": 107375034491,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107375034491),
//--TRIMMABLE-BOUNDARY-START(111670001787),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "n": "ReadIntoBufferAsync",
      "d": 852091,
      "h": 111670001787,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(111670001787),
//--TRIMMABLE-BOUNDARY-START(128849870971),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "n": "ReadToEndAsync",
      "d": 852091,
      "h": 128849870971,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(128849870971),
//--TRIMMABLE-BOUNDARY-START(133144838267),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 852091,
      "h": 133144838267,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144838267)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015296123),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 852091,
      "h": 73015296123,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015296123),
//--TRIMMABLE-BOUNDARY-START(55835426939),
    {
      "t": 95748097,
      "n": "_stream",
      "d": 852091,
      "h": 55835426939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835426939),
//--TRIMMABLE-BOUNDARY-START(47245492347),
    {
      "t": 166723585,
      "n": "_encoding",
      "d": 852091,
      "h": 47245492347,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245492347),
//--TRIMMABLE-BOUNDARY-START(38655557755),
    {
      "t": 165412865,
      "n": "_decoder",
      "d": 852091,
      "h": 38655557755,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655557755),
//--TRIMMABLE-BOUNDARY-START(12885753979),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_bytePool",
      "d": 852091,
      "h": 12885753979,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753979),
//--TRIMMABLE-BOUNDARY-START(30065623163),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Char).$h,
      "n": "_charPool",
      "d": 852091,
      "h": 30065623163,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065623163),
//--TRIMMABLE-BOUNDARY-START(8590786683),
    {
      "t": 655361,
      "n": "_byteBufferSize",
      "d": 852091,
      "h": 8590786683,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786683),
//--TRIMMABLE-BOUNDARY-START(4295819387),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_byteBuffer",
      "d": 852091,
      "h": 4295819387,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819387),
//--TRIMMABLE-BOUNDARY-START(21475688571),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_charBuffer",
      "d": 852091,
      "h": 21475688571,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688571),
//--TRIMMABLE-BOUNDARY-START(25770655867),
    {
      "t": 655361,
      "n": "_charBufferIndex",
      "d": 852091,
      "h": 25770655867,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655867),
//--TRIMMABLE-BOUNDARY-START(34360590459),
    {
      "t": 655361,
      "n": "_charsRead",
      "d": 852091,
      "h": 34360590459,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360590459),
//--TRIMMABLE-BOUNDARY-START(17180721275),
    {
      "t": 655361,
      "n": "_bytesRead",
      "d": 852091,
      "h": 17180721275,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721275),
//--TRIMMABLE-BOUNDARY-START(51540459643),
    {
      "t": 262145,
      "n": "_isBlocked",
      "d": 852091,
      "h": 51540459643,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540459643),
//--TRIMMABLE-BOUNDARY-START(42950525051),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 852091,
      "h": 42950525051,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950525051)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(68720328827),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 852091,
      "h": 68720328827,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328827),
//--TRIMMABLE-BOUNDARY-START(64425361531),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 852091,
      "h": 64425361531,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425361531),
//--TRIMMABLE-BOUNDARY-START(60130394235),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        },
        {
          "n": "charPool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852091,
      "h": 60130394235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130394235)
  ],
  "h": 852091
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$maw.MAW.HttpRequestStreamReader.ReadLineStepResult ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}HttpRequestStreamReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852091)
        
        

        //--TRIMMABLE-BOUNDARY-START(458875)
        $asm.$cls(`$maw.MAW.FileBufferingReadStream`, ($self) => class FileBufferingReadStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(34360197243)
            /*int*/ static _maxRentedBufferSize = 1048576;
            //--TRIMMABLE-BOUNDARY-END(34360197243)
            
            //--TRIMMABLE-BOUNDARY-START(30065229947)
            /*Stream*/ _inner = null;
            //--TRIMMABLE-BOUNDARY-END(30065229947)
            
            //--TRIMMABLE-BOUNDARY-START(12885360763)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(12885360763)
            
            //--TRIMMABLE-BOUNDARY-START(38655164539)
            /*int*/ _memoryThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(38655164539)
            
            //--TRIMMABLE-BOUNDARY-START(8590393467)
            /*long?*/ _bufferLimit = null;
            //--TRIMMABLE-BOUNDARY-END(8590393467)
            
            //--TRIMMABLE-BOUNDARY-START(47245099131)
            /*string?*/ _tempFileDirectory = null;
            //--TRIMMABLE-BOUNDARY-END(47245099131)
            
            //--TRIMMABLE-BOUNDARY-START(51540066427)
            /*Func<string>?*/ _tempFileDirectoryAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(51540066427)
            
            //--TRIMMABLE-BOUNDARY-START(55835033723)
            /*string?*/ _tempFileName = null;
            //--TRIMMABLE-BOUNDARY-END(55835033723)
            
            //--TRIMMABLE-BOUNDARY-START(4295426171)
            /*Stream*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295426171)
            
            //--TRIMMABLE-BOUNDARY-START(42950131835)
            /*byte[]?*/ _rentedBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(42950131835)
            
            //--TRIMMABLE-BOUNDARY-START(25770262651)
            /*bool*/ _inMemory = true;
            //--TRIMMABLE-BOUNDARY-END(25770262651)
            
            //--TRIMMABLE-BOUNDARY-START(17180328059)
            /*bool*/ _completelyBuffered = false;
            //--TRIMMABLE-BOUNDARY-END(17180328059)
            
            //--TRIMMABLE-BOUNDARY-START(21475295355)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475295355)
            
            //--TRIMMABLE-BOUNDARY-START(77309870203)
            $ctor$7(/*Stream*/ inner, /*int*/ memoryThreshold)
            {
                this.$ctor$4(inner, memoryThreshold, null, $.$maw.MAI.AspNetCoreTempDirectory.TempDirectoryFactory);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309870203);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309870203)
            
            //--TRIMMABLE-BOUNDARY-START(64424968315)
            $ctor$4(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor)
            {
                this.$ctor$3(inner, memoryThreshold, bufferLimit, tempFileDirectoryAccessor, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424968315);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968315)
            
            //--TRIMMABLE-BOUNDARY-START(60130001019)
            $ctor$3(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130001019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(tempFileDirectoryAccessor, "tempFileDirectoryAccessor");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.SI.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.SI.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130001019)
            
            //--TRIMMABLE-BOUNDARY-START(73014902907)
            $ctor$6(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory)
            {
                this.$ctor$5(inner, memoryThreshold, bufferLimit, tempFileDirectory, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014902907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014902907)
            
            //--TRIMMABLE-BOUNDARY-START(68719935611)
            $ctor$5(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719935611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(tempFileDirectory, "tempFileDirectory");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.SI.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.SI.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectory = tempFileDirectory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719935611)
            
            //--TRIMMABLE-BOUNDARY-START(193273987195)
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(193273987195)
            
            //--TRIMMABLE-BOUNDARY-START(184684052603)
            /*bool */ get InMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inMemory;
            }
            //--TRIMMABLE-BOUNDARY-END(184684052603)
            
            //--TRIMMABLE-BOUNDARY-START(236223660155)
            /*string? */ get TempFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389085307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tempFileName;
            }
            //--TRIMMABLE-BOUNDARY-END(236223660155)
            
            //--TRIMMABLE-BOUNDARY-START(81604837499)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(81604837499)
            
            //--TRIMMABLE-BOUNDARY-START(85899804795)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(85899804795)
            
            //--TRIMMABLE-BOUNDARY-START(90194772091)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90194772091)
            
            //--TRIMMABLE-BOUNDARY-START(188979019899)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._buffer.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(188979019899)
            
            //--TRIMMABLE-BOUNDARY-START(197568954491)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799150715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._buffer.Position;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._buffer.Position = value;
            }
            //--TRIMMABLE-BOUNDARY-END(197568954491)
            
            //--TRIMMABLE-BOUNDARY-START(219043790971)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (!this._completelyBuffered && origin === 2/*SeekOrigin.End*/)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 1/*SeekOrigin.Current*/ && BigInt.asIntN(64, offset + this.Position) > this.Length)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 0/*SeekOrigin.Begin*/ && offset > this.Length)
                {
                    throw new $.$$.S.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                return this._buffer.Seek(offset, origin);
            }
            //--TRIMMABLE-BOUNDARY-END(219043790971)
            
            //--TRIMMABLE-BOUNDARY-START(98784706683)
            /*Stream */ CreateTempFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._tempFileDirectory === null)
                {
                    $.$$.SD.Debug.Assert$4(this._tempFileDirectoryAccessor !== null, "_tempFileDirectoryAccessor != null");
                    this._tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    $.$$.SD.Debug.Assert$4(this._tempFileDirectory !== null, "_tempFileDirectory != null");
                }
                this._tempFileName = $.$$.SI.Path.Combine$3(this._tempFileDirectory, "ASPNETCORE_" + $.$strNN($.$$.S.Guid.NewGuid().ToString()) + ".tmp");
                if (!$.$$.SRI.RuntimeInformation.IsOSPlatform($.$$.SRI.OSPlatform.Windows))
                {
                    /*var*/ let tempTempFileName = $.$$.SI.Path.GetTempFileName();
                    $.$$.SI.File.Move$1(tempTempFileName, this._tempFileName);
                }
                return new $.$$.SI.FileStream().$ctor$12(this._tempFileName, 2/*FileMode.Create*/, 3/*FileAccess.ReadWrite*/, 4/*FileShare.Delete*/, ((1024 * 16) | 0), 1073741824/*FileOptions.Asynchronous*/ | 67108864/*FileOptions.DeleteOnClose*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(98784706683)
            
            //--TRIMMABLE-BOUNDARY-START(206158889083)
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158889083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                {
                    return this._buffer.Read$1(buffer);
                }
                /*var*/ let read = this._inner.Read$1(buffer);
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._bufferLimit) && $.$$.S.Int64.op_Subtraction(this._bufferLimit, read) < this._buffer.Length)
                {
                    throw new $.$$.SI.IOException().$ctor$13("Buffer limit exceeded.");
                }
                if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                {
                    this._inMemory = false;
                    /*var*/ let oldBuffer = this._buffer;
                    this._buffer = this.CreateTempFile();
                    if (this._rentedBuffer === null)
                    {
                        oldBuffer.Position = 0n;
                        /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.S.Math.Min$4($.$cast(oldBuffer.Length, $.$$.S.Int32), 1048576/*_maxRentedBufferSize*/));
                        try
                        {
                            /*var*/ let copyRead = oldBuffer.Read$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rentedBuffer));
                            while(copyRead > 0)
                            {
                                this._buffer.Write$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, rentedBuffer, 0, copyRead)));
                                copyRead = oldBuffer.Read$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rentedBuffer));
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(rentedBuffer, false);
                            }
                        }
                    }
                    else 
                    {
                        this._buffer.Write$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.S.Int32))));
                        this._bytePool.Return(this._rentedBuffer, false);
                        this._rentedBuffer = null;
                    }
                }
                if (read > 0)
                {
                    this._buffer.Write$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit(buffer.Slice(0, read)));
                }
                else if (buffer.Length > 0)
                {
                    this._completelyBuffered = true;
                }
                return read;
            }
            //--TRIMMABLE-BOUNDARY-END(206158889083)
            
            //--TRIMMABLE-BOUNDARY-START(201863921787)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read$1($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, offset, count));
            }
            //--TRIMMABLE-BOUNDARY-END(201863921787)
            
            //--TRIMMABLE-BOUNDARY-START(210453856379)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(210453856379)
            
            //--TRIMMABLE-BOUNDARY-START(214748823675)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748823675);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                    {
                        let $t1, $r1;
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this._buffer.ReadAsync$2(buffer, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                    }
                    /*var*/ let read = ($t2 = this._inner.ReadAsync$2(buffer, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._bufferLimit) && $.$$.S.Int64.op_Subtraction(this._bufferLimit, read) < this._buffer.Length)
                    {
                        throw new $.$$.SI.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                    {
                        this._inMemory = false;
                        /*var*/ let oldBuffer = this._buffer;
                        this._buffer = this.CreateTempFile();
                        if (this._rentedBuffer === null)
                        {
                            oldBuffer.Position = 0n;
                            /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.S.Math.Min$4($.$cast(oldBuffer.Length, $.$$.S.Int32), 1048576/*_maxRentedBufferSize*/));
                            try
                            {
                                /*var*/ let copyRead = oldBuffer.Read$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rentedBuffer));
                                while(copyRead > 0)
                                {
                                    let $t3, $r3;
                                    ($t3 = this._buffer.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, rentedBuffer, 0, copyRead)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                                    copyRead = oldBuffer.Read$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rentedBuffer));
                                }
                            }
                            finally
                            {
                                {
                                    this._bytePool.Return(rentedBuffer, false);
                                }
                            }
                        }
                        else 
                        {
                            let $t4, $r4;
                            ($t4 = this._buffer.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.S.Int32))), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            this._bytePool.Return(this._rentedBuffer, false);
                            this._rentedBuffer = null;
                        }
                    }
                    if (read > 0)
                    {
                        let $t5, $r5;
                        ($t5 = this._buffer.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit(buffer.Slice(0, read)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    }
                    else if (buffer.Length > 0)
                    {
                        this._completelyBuffered = true;
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, read);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214748823675)
            
            //--TRIMMABLE-BOUNDARY-START(244813594747)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(244813594747)
            
            //--TRIMMABLE-BOUNDARY-START(253403529339)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(253403529339)
            
            //--TRIMMABLE-BOUNDARY-START(249108562043)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108562043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(249108562043)
            
            //--TRIMMABLE-BOUNDARY-START(231928692859)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(231928692859)
            
            //--TRIMMABLE-BOUNDARY-START(111669608571)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111669608571)
            
            //--TRIMMABLE-BOUNDARY-START(94489739387)
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.S.Math.Max$4(4096, bufferSize);
                if (this._completelyBuffered)
                {
                    return this._buffer.CopyToAsync(destination, bufferSize, cancellationToken);
                }
                /*Task*/ /*async*/  function CopyToAsyncImpl()
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                    {
                        /*byte[]*/ let buffer = this._bytePool.Rent(bufferSize);
                        try
                        {
                            while(true)
                            {
                                let $t6, $r6;
                                let $t7, $r7;
                                /*int*/ let bytesRead = ($t6 = this.ReadAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit$2(buffer), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                                if (bytesRead === 0)
                                {
                                    break;
                                }
                                ($t7 = destination.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, 0, bytesRead)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(buffer, false);
                            }
                        }
                    });
                }
                return CopyToAsyncImpl.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(94489739387)
            
            //--TRIMMABLE-BOUNDARY-START(103079673979)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    if (this._rentedBuffer !== null)
                    {
                        this._bytePool.Return(this._rentedBuffer, false);
                    }
                    if (disposing)
                    {
                        this._buffer.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673979)
            
            //--TRIMMABLE-BOUNDARY-START(107374641275)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374641275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._disposed)
                    {
                        let $t8, $r8;
                        this._disposed = true;
                        if (this._rentedBuffer !== null)
                        {
                            this._bytePool.Return(this._rentedBuffer, false);
                        }
                        ($t8 = this._buffer.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107374641275)
            
            //--TRIMMABLE-BOUNDARY-START(240518627451)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(240518627451)
            
            static $h = 458875;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273987195),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209216123,
        "f": 50331649
      },
      "n": "MemoryThreshold",
      "d": 458875,
      "h": 193273987195,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273987195),
//--TRIMMABLE-BOUNDARY-START(184684052603),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029346939,
        "f": 50331649
      },
      "n": "InMemory",
      "d": 458875,
      "h": 184684052603,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684052603),
//--TRIMMABLE-BOUNDARY-START(236223660155),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389085307,
        "f": 50331649
      },
      "n": "TempFileName",
      "d": 458875,
      "h": 236223660155,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236223660155),
//--TRIMMABLE-BOUNDARY-START(81604837499),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543163,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 458875,
      "h": 81604837499,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604837499),
//--TRIMMABLE-BOUNDARY-START(85899804795),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477755,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 458875,
      "h": 85899804795,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899804795),
//--TRIMMABLE-BOUNDARY-START(90194772091),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439412347,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 458875,
      "h": 90194772091,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194772091),
//--TRIMMABLE-BOUNDARY-START(188979019899),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619281531,
        "f": 50364417
      },
      "n": "Length",
      "d": 458875,
      "h": 188979019899,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979019899),
//--TRIMMABLE-BOUNDARY-START(197568954491),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799150715,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633725563,
        "f": 83918849
      },
      "n": "Position",
      "d": 458875,
      "h": 197568954491,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197568954491)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(219043790971),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 458875,
      "h": 219043790971,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043790971),
//--TRIMMABLE-BOUNDARY-START(98784706683),
    {
      "r": 95748097,
      "n": "CreateTempFile",
      "d": 458875,
      "h": 98784706683,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784706683),
//--TRIMMABLE-BOUNDARY-START(206158889083),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 458875,
      "h": 206158889083,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206158889083),
//--TRIMMABLE-BOUNDARY-START(201863921787),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 458875,
      "h": 201863921787,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201863921787),
//--TRIMMABLE-BOUNDARY-START(210453856379),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 458875,
      "h": 210453856379,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210453856379),
//--TRIMMABLE-BOUNDARY-START(214748823675),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 458875,
      "h": 214748823675,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(214748823675),
//--TRIMMABLE-BOUNDARY-START(244813594747),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 458875,
      "h": 244813594747,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244813594747),
//--TRIMMABLE-BOUNDARY-START(253403529339),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 458875,
      "h": 253403529339,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253403529339),
//--TRIMMABLE-BOUNDARY-START(249108562043),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 458875,
      "h": 249108562043,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108562043),
//--TRIMMABLE-BOUNDARY-START(231928692859),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 458875,
      "h": 231928692859,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231928692859),
//--TRIMMABLE-BOUNDARY-START(111669608571),
    {
      "r": 65537,
      "n": "Flush",
      "d": 458875,
      "h": 111669608571,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669608571),
//--TRIMMABLE-BOUNDARY-START(94489739387),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CopyToAsync",
      "d": 458875,
      "h": 94489739387,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489739387),
//--TRIMMABLE-BOUNDARY-START(103079673979),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 458875,
      "h": 103079673979,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103079673979),
//--TRIMMABLE-BOUNDARY-START(107374641275),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 458875,
      "h": 107374641275,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(107374641275),
//--TRIMMABLE-BOUNDARY-START(240518627451),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 458875,
      "h": 240518627451,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518627451)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360197243),
    {
      "t": 655361,
      "n": "_maxRentedBufferSize",
      "d": 458875,
      "h": 34360197243,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360197243),
//--TRIMMABLE-BOUNDARY-START(30065229947),
    {
      "t": 95748097,
      "n": "_inner",
      "d": 458875,
      "h": 30065229947,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065229947),
//--TRIMMABLE-BOUNDARY-START(12885360763),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_bytePool",
      "d": 458875,
      "h": 12885360763,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360763),
//--TRIMMABLE-BOUNDARY-START(38655164539),
    {
      "t": 655361,
      "n": "_memoryThreshold",
      "d": 458875,
      "h": 38655164539,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655164539),
//--TRIMMABLE-BOUNDARY-START(8590393467),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_bufferLimit",
      "d": 458875,
      "h": 8590393467,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393467),
//--TRIMMABLE-BOUNDARY-START(47245099131),
    {
      "t": 1310721,
      "n": "_tempFileDirectory",
      "d": 458875,
      "h": 47245099131,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245099131),
//--TRIMMABLE-BOUNDARY-START(51540066427),
    {
      "t": $.$$.S.Func$$($.$$.S.String).$h,
      "n": "_tempFileDirectoryAccessor",
      "d": 458875,
      "h": 51540066427,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540066427),
//--TRIMMABLE-BOUNDARY-START(55835033723),
    {
      "t": 1310721,
      "n": "_tempFileName",
      "d": 458875,
      "h": 55835033723,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835033723),
//--TRIMMABLE-BOUNDARY-START(4295426171),
    {
      "t": 95748097,
      "n": "_buffer",
      "d": 458875,
      "h": 4295426171,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426171),
//--TRIMMABLE-BOUNDARY-START(42950131835),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_rentedBuffer",
      "d": 458875,
      "h": 42950131835,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950131835),
//--TRIMMABLE-BOUNDARY-START(25770262651),
    {
      "t": 262145,
      "n": "_inMemory",
      "d": 458875,
      "h": 25770262651,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770262651),
//--TRIMMABLE-BOUNDARY-START(17180328059),
    {
      "t": 262145,
      "n": "_completelyBuffered",
      "d": 458875,
      "h": 17180328059,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328059),
//--TRIMMABLE-BOUNDARY-START(21475295355),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 458875,
      "h": 21475295355,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295355)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77309870203),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 458875,
      "h": 77309870203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309870203),
//--TRIMMABLE-BOUNDARY-START(64424968315),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.S.Func$$($.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458875,
      "h": 64424968315,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424968315),
//--TRIMMABLE-BOUNDARY-START(60130001019),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.S.Func$$($.$$.S.String).$h
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458875,
      "h": 60130001019,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130001019),
//--TRIMMABLE-BOUNDARY-START(73014902907),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "tempFileDirectory",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458875,
      "h": 73014902907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014902907),
//--TRIMMABLE-BOUNDARY-START(68719935611),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.S.Int64).$h
        },
        {
          "n": "tempFileDirectory",
          "p": 1310721
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458875,
      "h": 68719935611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719935611)
  ],
  "h": 458875
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FileBufferingReadStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FileBufferingReadStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458875)
        
        

        //--TRIMMABLE-BOUNDARY-START(393339)
        $asm.$cls(`$maw.MAW.BufferedReadStream`, ($self) => class BufferedReadStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(64424902779)
            /*byte*/ static CR = 13;
            //--TRIMMABLE-BOUNDARY-END(64424902779)
            
            //--TRIMMABLE-BOUNDARY-START(167504117883)
            /*byte*/ static LF = 10;
            //--TRIMMABLE-BOUNDARY-END(167504117883)
            
            //--TRIMMABLE-BOUNDARY-START(25770197115)
            /*Stream*/ _inner = null;
            //--TRIMMABLE-BOUNDARY-END(25770197115)
            
            //--TRIMMABLE-BOUNDARY-START(4295360635)
            /*byte[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295360635)
            
            //--TRIMMABLE-BOUNDARY-START(17180262523)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(17180262523)
            
            //--TRIMMABLE-BOUNDARY-START(12885295227)
            /*int*/ _bufferOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(12885295227)
            
            //--TRIMMABLE-BOUNDARY-START(8590327931)
            /*int*/ _bufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(8590327931)
            
            //--TRIMMABLE-BOUNDARY-START(21475229819)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475229819)
            
            //--TRIMMABLE-BOUNDARY-START(34360131707)
            $ctor$4(/*Stream*/ inner, /*int*/ bufferSize)
            {
                this.$ctor$3(inner, bufferSize, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131707)
            
            //--TRIMMABLE-BOUNDARY-START(30065164411)
            $ctor$3(/*Stream*/ inner, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164411);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    this._inner = inner;
                    this._bytePool = bytePool;
                    this._buffer = bytePool.Rent(bufferSize);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065164411)
            
            //--TRIMMABLE-BOUNDARY-START(38655099003)
            /*ArraySegment<byte> */ get BufferedData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$$.S.ArraySegment$$($.$$.S.Byte))().$ctor$3(this._buffer, this._bufferOffset, this._bufferCount);
            }
            //--TRIMMABLE-BOUNDARY-END(38655099003)
            
            //--TRIMMABLE-BOUNDARY-START(42950066299)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanRead || this._bufferCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066299)
            
            //--TRIMMABLE-BOUNDARY-START(47245033595)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554444923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanSeek;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033595)
            
            //--TRIMMABLE-BOUNDARY-START(51540000891)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144379515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanTimeout;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000891)
            
            //--TRIMMABLE-BOUNDARY-START(55834968187)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanWrite;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968187)
            
            //--TRIMMABLE-BOUNDARY-START(163209150587)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(163209150587)
            
            //--TRIMMABLE-BOUNDARY-START(171799085179)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914183291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return BigInt.asIntN(64, this._inner.Position - BigInt(this._bufferCount));
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453790843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), "Position must be positive.");
                }
                if (value === this.Position)
                {
                    return;
                }
                if (value <= this._inner.Position)
                {
                    /*var*/ let innerOffset = $.$cast((BigInt.asIntN(64, this._inner.Position - value)), $.$$.S.Int32);
                    if (innerOffset <= this._bufferCount)
                    {
                        this._bufferOffset += ((this._bufferCount - innerOffset) | 0);
                        this._bufferCount = innerOffset;
                    }
                    else 
                    {
                        this._bufferOffset = 0;
                        this._bufferCount = 0;
                        this._inner.Position = value;
                    }
                }
                else 
                {
                    this._bufferOffset = 0;
                    this._bufferCount = 0;
                    this._inner.Position = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799085179)
            
            //--TRIMMABLE-BOUNDARY-START(201863856251)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863856251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = BigInt.asIntN(64, this.Position + offset);
                }
                else 
                {
                    this.Position = BigInt.asIntN(64, this.Length + offset);
                }
                return this.Position;
            }
            //--TRIMMABLE-BOUNDARY-END(201863856251)
            
            //--TRIMMABLE-BOUNDARY-START(214748758139)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748758139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.SetLength(value);
            }
            //--TRIMMABLE-BOUNDARY-END(214748758139)
            
            //--TRIMMABLE-BOUNDARY-START(73014837371)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._buffer, false);
                    if (disposing)
                    {
                        this._inner.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837371)
            
            //--TRIMMABLE-BOUNDARY-START(94489673851)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(94489673851)
            
            //--TRIMMABLE-BOUNDARY-START(98784641147)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784641147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.FlushAsync$1(cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(98784641147)
            
            //--TRIMMABLE-BOUNDARY-START(219043725435)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043725435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.Write(buffer, offset, count);
            }
            //--TRIMMABLE-BOUNDARY-END(219043725435)
            
            //--TRIMMABLE-BOUNDARY-START(227633660027)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633660027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.WriteAsync$2(buffer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(227633660027)
            
            //--TRIMMABLE-BOUNDARY-START(223338692731)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338692731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.WriteAsync(buffer, offset, count, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(223338692731)
            
            //--TRIMMABLE-BOUNDARY-START(180389019771)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389019771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SI.Stream.ValidateBufferArguments(buffer, offset, count);
                if (this._bufferCount > 0)
                {
                    /*int*/ let toCopy = $.$$.S.Math.Min$4(this._bufferCount, count);
                    $.$$.S.Buffer.BlockCopy(this._buffer, this._bufferOffset, buffer, offset, toCopy);
                    this._bufferOffset += toCopy;
                    this._bufferCount -= toCopy;
                    return toCopy;
                }
                return this._inner.Read(buffer, offset, count);
            }
            //--TRIMMABLE-BOUNDARY-END(180389019771)
            
            //--TRIMMABLE-BOUNDARY-START(184683987067)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683987067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(184683987067)
            
            //--TRIMMABLE-BOUNDARY-START(188978954363)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188978954363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._bufferCount > 0)
                    {
                        /*int*/ let toCopy = $.$$.S.Math.Min$4(this._bufferCount, buffer.Length);
                        $.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._buffer, this._bufferOffset, toCopy).CopyTo(buffer);
                        this._bufferOffset += toCopy;
                        this._bufferCount -= toCopy;
                        return $.$$.N.AsyncResolver.Result($asnycContext, toCopy);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, ($t1 = this._inner.ReadAsync$2(buffer, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1))));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188978954363)
            
            //--TRIMMABLE-BOUNDARY-START(77309804667)
            /*bool */ EnsureBuffered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferCount > 0)
                {
                    return true;
                }
                this._bufferOffset = 0;
                this._bufferCount = this._inner.Read(this._buffer, 0, this._buffer.length);
                return this._bufferCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804667)
            
            //--TRIMMABLE-BOUNDARY-START(90194706555)
            /*Task<bool> *//*async*/  EnsureBufferedAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    let $t2, $r2;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194706555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._bufferCount > 0)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, true);
                    }
                    this._bufferOffset = 0;
                    this._bufferCount = ($t2 = this._inner.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$12($.$$.S.Byte, this._buffer), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, this._bufferCount > 0);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90194706555)
            
            //--TRIMMABLE-BOUNDARY-START(81604771963)
            /*bool */ EnsureBuffered$1(/*int*/ minCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minCount > this._buffer.length)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.S.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                }
                while(this._bufferCount < minCount)
                {
                    if (this._bufferOffset > 0)
                    {
                        if (this._bufferCount > 0)
                        {
                            $.$$.S.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                        }
                        this._bufferOffset = 0;
                    }
                    /*int*/ let read = this._inner.Read(this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0));
                    this._bufferCount += read;
                    if (read === 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771963)
            
            //--TRIMMABLE-BOUNDARY-START(85899739259)
            /*Task<bool> *//*async*/  EnsureBufferedAsync(/*int*/ minCount, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Boolean), $.$$.S.Boolean, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899739259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (minCount > this._buffer.length)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.S.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                    }
                    while(this._bufferCount < minCount)
                    {
                        let $t3, $r3;
                        if (this._bufferOffset > 0)
                        {
                            if (this._bufferCount > 0)
                            {
                                $.$$.S.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                            }
                            this._bufferOffset = 0;
                        }
                        /*int*/ let read = ($t3 = this._inner.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                        this._bufferCount += read;
                        if (read === 0)
                        {
                            return $.$$.N.AsyncResolver.Result($asnycContext, false);
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, true);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899739259)
            
            //--TRIMMABLE-BOUNDARY-START(193273921659)
            /*string */ ReadLine(/*int*/ lengthLimit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273921659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                let builder = null;
                try
                {
                    builder = new $.$$.SI.MemoryStream().$ctor$9(200);
                    /*bool*/ let foundCR = false, foundCRLF = false;
                    while(!foundCRLF && this.EnsureBuffered())
                    {
                        this.ProcessLineChar(builder, lengthLimit, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => foundCR, ($v) => foundCR = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null, true));
                    }
                    return $.$maw.MAW.BufferedReadStream.DecodeLine(builder, foundCRLF);
                }
                finally
                {
                    builder?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273921659)
            
            //--TRIMMABLE-BOUNDARY-START(197568888955)
            /*Task<string> *//*async*/  ReadLineAsync(/*int*/ lengthLimit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197568888955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CheckDisposed();
                    let builder = null;
                    try
                    {
                        let $t6, $r6;
                        builder = new $.$$.SI.MemoryStream().$ctor$9(200);
                        /*bool*/ let foundCR = false, foundCRLF = false;
                        while(!foundCRLF && ($t6 = this.EnsureBufferedAsync$1(cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))))
                        {
                            this.ProcessLineChar(builder, lengthLimit, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => foundCR, ($v) => foundCR = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null, true));
                        }
                        return $.$$.N.AsyncResolver.Result($asnycContext, $.$maw.MAW.BufferedReadStream.DecodeLine(builder, foundCRLF));
                    }
                    finally
                    {
                        builder?.S$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197568888955)
            
            //--TRIMMABLE-BOUNDARY-START(176094052475)
            /*void */ ProcessLineChar(/*MemoryStream*/ builder, /*int*/ lengthLimit, /*ref bool*/ foundCR, /*ref bool*/ foundCRLF)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094052475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let writeCount = 0;
                while(this._bufferCount > 0)
                {
                    /*var*/ let b = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset);
                    this._bufferOffset++;
                    this._bufferCount--;
                    writeCount++;
                    if (b === 10/*LF*/ && foundCR.$v)
                    {
                        builder.Write$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
                        foundCRLF.$v = true;
                        return;
                    }
                    foundCR.$v = b === 13/*CR*/;
                    if (writeCount > lengthLimit)
                    {
                        throw new $.$$.SI.InvalidDataException().$ctor$12(`Line length limit ${$.$strNN(lengthLimit)} exceeded.`);
                    }
                }
                builder.Write$1($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
            }
            //--TRIMMABLE-BOUNDARY-END(176094052475)
            
            //--TRIMMABLE-BOUNDARY-START(68719870075)
            static /*string */ DecodeLine(/*MemoryStream*/ builder, /*bool*/ foundCRLF)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let length = foundCRLF ? BigInt.asIntN(64, builder.Length - 2n) : builder.Length;
                return $.$$.ST.Encoding.UTF8.GetString(builder.GetBuffer(), 0, $.$cast(length, $.$$.S.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(68719870075)
            
            //--TRIMMABLE-BOUNDARY-START(60129935483)
            /*void */ CheckDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(60129935483)
            
            static $h = 393339;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655099003),
    {
      "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374575739,
        "f": 50331649
      },
      "n": "BufferedData",
      "d": 393339,
      "h": 38655099003,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655099003),
//--TRIMMABLE-BOUNDARY-START(42950066299),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964510331,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 393339,
      "h": 42950066299,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950066299),
//--TRIMMABLE-BOUNDARY-START(47245033595),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554444923,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 393339,
      "h": 47245033595,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245033595),
//--TRIMMABLE-BOUNDARY-START(51540000891),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144379515,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 393339,
      "h": 51540000891,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540000891),
//--TRIMMABLE-BOUNDARY-START(55834968187),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734314107,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 393339,
      "h": 55834968187,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55834968187),
//--TRIMMABLE-BOUNDARY-START(163209150587),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324248699,
        "f": 50364417
      },
      "n": "Length",
      "d": 393339,
      "h": 163209150587,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209150587),
//--TRIMMABLE-BOUNDARY-START(171799085179),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914183291,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453790843,
        "f": 83918849
      },
      "n": "Position",
      "d": 393339,
      "h": 171799085179,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799085179)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(201863856251),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 393339,
      "h": 201863856251,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201863856251),
//--TRIMMABLE-BOUNDARY-START(214748758139),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 393339,
      "h": 214748758139,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748758139),
//--TRIMMABLE-BOUNDARY-START(73014837371),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 393339,
      "h": 73014837371,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73014837371),
//--TRIMMABLE-BOUNDARY-START(94489673851),
    {
      "r": 65537,
      "n": "Flush",
      "d": 393339,
      "h": 94489673851,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489673851),
//--TRIMMABLE-BOUNDARY-START(98784641147),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 393339,
      "h": 98784641147,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784641147),
//--TRIMMABLE-BOUNDARY-START(219043725435),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 393339,
      "h": 219043725435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043725435),
//--TRIMMABLE-BOUNDARY-START(227633660027),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 393339,
      "h": 227633660027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633660027),
//--TRIMMABLE-BOUNDARY-START(223338692731),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 393339,
      "h": 223338692731,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223338692731),
//--TRIMMABLE-BOUNDARY-START(180389019771),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 393339,
      "h": 180389019771,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389019771),
//--TRIMMABLE-BOUNDARY-START(184683987067),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 393339,
      "h": 184683987067,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184683987067),
//--TRIMMABLE-BOUNDARY-START(188978954363),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 393339,
      "h": 188978954363,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(188978954363),
//--TRIMMABLE-BOUNDARY-START(77309804667),
    {
      "r": 262145,
      "n": "EnsureBuffered",
      "d": 393339,
      "h": 77309804667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309804667),
//--TRIMMABLE-BOUNDARY-START(90194706555),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "EnsureBufferedAsync",
      "o": "@$1",
      "d": 393339,
      "h": 90194706555,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(90194706555),
//--TRIMMABLE-BOUNDARY-START(81604771963),
    {
      "r": 262145,
      "p": [
        {
          "n": "minCount",
          "p": 655361
        }
      ],
      "n": "EnsureBuffered",
      "o": "@$1",
      "d": 393339,
      "h": 81604771963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604771963),
//--TRIMMABLE-BOUNDARY-START(85899739259),
    {
      "r": $.$$.STT.Task$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "minCount",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "EnsureBufferedAsync",
      "d": 393339,
      "h": 85899739259,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(85899739259),
//--TRIMMABLE-BOUNDARY-START(193273921659),
    {
      "r": 1310721,
      "p": [
        {
          "n": "lengthLimit",
          "p": 655361
        }
      ],
      "n": "ReadLine",
      "d": 393339,
      "h": 193273921659,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193273921659),
//--TRIMMABLE-BOUNDARY-START(197568888955),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "lengthLimit",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadLineAsync",
      "d": 393339,
      "h": 197568888955,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(197568888955),
//--TRIMMABLE-BOUNDARY-START(176094052475),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 94568449
        },
        {
          "n": "lengthLimit",
          "p": 655361
        },
        {
          "n": "foundCR",
          "p": 262145,
          "f": 4
        },
        {
          "n": "foundCRLF",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ProcessLineChar",
      "d": 393339,
      "h": 176094052475,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094052475),
//--TRIMMABLE-BOUNDARY-START(68719870075),
    {
      "r": 1310721,
      "p": [
        {
          "n": "builder",
          "p": 94568449
        },
        {
          "n": "foundCRLF",
          "p": 262145
        }
      ],
      "n": "DecodeLine",
      "d": 393339,
      "h": 68719870075,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719870075),
//--TRIMMABLE-BOUNDARY-START(60129935483),
    {
      "r": 65537,
      "n": "CheckDisposed",
      "d": 393339,
      "h": 60129935483,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129935483)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64424902779),
    {
      "t": 393217,
      "n": "CR",
      "d": 393339,
      "h": 64424902779,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424902779),
//--TRIMMABLE-BOUNDARY-START(167504117883),
    {
      "t": 393217,
      "n": "LF",
      "d": 393339,
      "h": 167504117883,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167504117883),
//--TRIMMABLE-BOUNDARY-START(25770197115),
    {
      "t": 95748097,
      "n": "_inner",
      "d": 393339,
      "h": 25770197115,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770197115),
//--TRIMMABLE-BOUNDARY-START(4295360635),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_buffer",
      "d": 393339,
      "h": 4295360635,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360635),
//--TRIMMABLE-BOUNDARY-START(17180262523),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_bytePool",
      "d": 393339,
      "h": 17180262523,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180262523),
//--TRIMMABLE-BOUNDARY-START(12885295227),
    {
      "t": 655361,
      "n": "_bufferOffset",
      "d": 393339,
      "h": 12885295227,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885295227),
//--TRIMMABLE-BOUNDARY-START(8590327931),
    {
      "t": 655361,
      "n": "_bufferCount",
      "d": 393339,
      "h": 8590327931,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327931),
//--TRIMMABLE-BOUNDARY-START(21475229819),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 393339,
      "h": 21475229819,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360131707),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393339,
      "h": 34360131707,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360131707),
//--TRIMMABLE-BOUNDARY-START(30065164411),
    {
      "p": [
        {
          "n": "inner",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393339,
      "h": 30065164411,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164411)
  ],
  "h": 393339
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.BufferedReadStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}BufferedReadStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393339)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245307)
        $asm.$cls(`$maw.MAW.MultipartReaderStream`, ($self) => class MultipartReaderStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4296212603)
            /*MultipartBoundary*/ _boundary = null;
            //--TRIMMABLE-BOUNDARY-END(4296212603)
            
            //--TRIMMABLE-BOUNDARY-START(21476081787)
            /*BufferedReadStream*/ _innerStream = null;
            //--TRIMMABLE-BOUNDARY-END(21476081787)
            
            //--TRIMMABLE-BOUNDARY-START(8591179899)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(8591179899)
            
            //--TRIMMABLE-BOUNDARY-START(17181114491)
            /*long*/ _innerOffset = 0n;
            //--TRIMMABLE-BOUNDARY-END(17181114491)
            
            //--TRIMMABLE-BOUNDARY-START(30066016379)
            /*long*/ _position = 0n;
            //--TRIMMABLE-BOUNDARY-END(30066016379)
            
            //--TRIMMABLE-BOUNDARY-START(25771049083)
            /*long*/ _observedLength = 0n;
            //--TRIMMABLE-BOUNDARY-END(25771049083)
            
            //--TRIMMABLE-BOUNDARY-START(12886147195)
            /*bool*/ _finished = false;
            //--TRIMMABLE-BOUNDARY-END(12886147195)
            
            //--TRIMMABLE-BOUNDARY-START(47245885563)
            $ctor$4(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary)
            {
                this.$ctor$3(stream, boundary, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245885563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245885563)
            
            //--TRIMMABLE-BOUNDARY-START(42950918267)
            $ctor$3(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950918267);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._bytePool = bytePool;
                    this._innerStream = stream;
                    this._innerOffset = this._innerStream.CanSeek ? this._innerStream.Position : 0n;
                    this._boundary = boundary;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950918267)
            
            //--TRIMMABLE-BOUNDARY-START(73015689339)
            /*bool*/ FinalBoundaryFound = false;
            //--TRIMMABLE-BOUNDARY-END(73015689339)
            
            //--TRIMMABLE-BOUNDARY-START(146030133371)
            /*long?*/ LengthLimit = null;
            //--TRIMMABLE-BOUNDARY-END(146030133371)
            
            //--TRIMMABLE-BOUNDARY-START(51540852859)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540852859)
            
            //--TRIMMABLE-BOUNDARY-START(55835820155)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerStream.CanSeek;
            }
            //--TRIMMABLE-BOUNDARY-END(55835820155)
            
            //--TRIMMABLE-BOUNDARY-START(60130787451)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60130787451)
            
            //--TRIMMABLE-BOUNDARY-START(141735166075)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._observedLength;
            }
            //--TRIMMABLE-BOUNDARY-END(141735166075)
            
            //--TRIMMABLE-BOUNDARY-START(150325100667)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._position;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), "The Position must be positive.");
                }
                if (value > this._observedLength)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), "The Position must be less than length.");
                }
                this._position = value;
                if (this._position < this._observedLength)
                {
                    this._finished = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325100667)
            
            //--TRIMMABLE-BOUNDARY-START(171799937147)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = BigInt.asIntN(64, this.Position + offset);
                }
                else 
                {
                    this.Position = BigInt.asIntN(64, this.Length + offset);
                }
                return this.Position;
            }
            //--TRIMMABLE-BOUNDARY-END(171799937147)
            
            //--TRIMMABLE-BOUNDARY-START(201864708219)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864708219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(201864708219)
            
            //--TRIMMABLE-BOUNDARY-START(214749610107)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749610107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(214749610107)
            
            //--TRIMMABLE-BOUNDARY-START(223339544699)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339544699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(223339544699)
            
            //--TRIMMABLE-BOUNDARY-START(219044577403)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044577403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(219044577403)
            
            //--TRIMMABLE-BOUNDARY-START(77310656635)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(77310656635)
            
            //--TRIMMABLE-BOUNDARY-START(154620067963)
            /*void */ PositionInnerStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerStream.CanSeek && this._innerStream.Position !== (BigInt.asIntN(64, this._innerOffset + this._position)))
                {
                    this._innerStream.Position = BigInt.asIntN(64, this._innerOffset + this._position);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620067963)
            
            //--TRIMMABLE-BOUNDARY-START(210454642811)
            /*int */ UpdatePosition(/*int*/ read)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454642811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._position += BigInt(read);
                if (this._observedLength < this._position)
                {
                    this._observedLength = this._position;
                    let lengthLimit;
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this.LengthLimit) && (lengthLimit = $.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(this.LengthLimit)) && this._observedLength > lengthLimit)
                    {
                        if (this._boundary.BeforeFirstBoundary())
                        {
                            throw new $.$$.SI.InvalidDataException().$ctor$12(`Multipart header length limit ${$.$strNN(lengthLimit)} exceeded. Too much data before the first boundary.`);
                        }
                        else 
                        {
                            throw new $.$$.SI.InvalidDataException().$ctor$12(`Multipart body length limit ${$.$strNN(lengthLimit)} exceeded.`);
                        }
                    }
                }
                return read;
            }
            //--TRIMMABLE-BOUNDARY-END(210454642811)
            
            //--TRIMMABLE-BOUNDARY-START(158915035259)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                /*var*/ let matchOffset;
                /*var*/ let matchCount;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915035259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._finished)
                {
                    return 0;
                }
                this.PositionInnerStream();
                if (!this._innerStream.EnsureBuffered$1(this._boundary.FinalBoundaryLength))
                {
                    throw new $.$$.SI.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                }
                /*var*/ let bufferedData = this._innerStream.BufferedData;
                /*var*/ let index = $.$$.S.MemoryExtensions.IndexOf$2($.$$.S.Byte, $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$9($.$$.S.Byte, bufferedData)), this._boundary.BoundaryBytes);
                if (index >= 0)
                {
                    if (index !== 0)
                    {
                        /*var*/ let slice = $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, buffer, offset, $.$$.S.Math.Min$4(count, index));
                        /*var*/ let readAmount = this._innerStream.Read$1(slice);
                        return this.UpdatePosition(readAmount);
                    }
                    else 
                    {
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        return ReadBoundary(this, length);
                    }
                }
                /*int*/ let read;
                if ($.$maw.MAW.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.S.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.S.Int32)))
                {
                    if (matchOffset > bufferedData.Offset)
                    {
                        read = this._innerStream.Read(buffer, offset, $.$$.S.Math.Min$4(count, ((matchOffset - bufferedData.Offset) | 0)));
                        return this.UpdatePosition(read);
                    }
                    /*var*/ let length = this._boundary.BoundaryBytes.Length;
                    $.$$.SD.Debug.Assert$4(matchCount === length, "matchCount == length");
                    return ReadBoundary(this, length);
                }
                read = this._innerStream.Read(buffer, offset, $.$$.S.Math.Min$4(count, bufferedData.Count));
                return this.UpdatePosition(read);
                /*static int*/  function ReadBoundary(/*MultipartReaderStream*/ stream, /*int*/ length)
                {
                    /*var*/ let boundary = stream._bytePool.Rent(length);
                    /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                    stream._bytePool.Return(boundary, false);
                    $.$$.SD.Debug.Assert$4(read === length, "read == length");
                    /*var*/ let remainder = $.$$.S.MemoryExtensions.AsSpan$4(stream._innerStream.ReadLine(100));
                    remainder = $.$$.S.MemoryExtensions.Trim$4(remainder);
                    if ($.$$.S.MemoryExtensions.Equals$2(remainder, $.$$.S.String.op_Implicit("--"), 4/*StringComparison.Ordinal*/))
                    {
                        stream.FinalBoundaryFound = true;
                    }
                    $.$$.SD.Debug.Assert$4(stream.FinalBoundaryFound || remainder.IsEmpty, "Un-expected data found on the boundary line: " + $.$strNN(remainder.ToString()));
                    stream._finished = true;
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915035259)
            
            //--TRIMMABLE-BOUNDARY-START(163210002555)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163210002555);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ReadAsync$2($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count), cancellationToken).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210002555)
            
            //--TRIMMABLE-BOUNDARY-START(167504969851)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                {
                    let $t3, $r3;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504969851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._finished)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                    }
                    this.PositionInnerStream();
                    if (!($t3 = this._innerStream.EnsureBufferedAsync(this._boundary.FinalBoundaryLength, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3))))
                    {
                        throw new $.$$.SI.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                    }
                    /*var*/ let bufferedData = this._innerStream.BufferedData;
                    /*var*/ let index = $.$$.S.MemoryExtensions.IndexOf$2($.$$.S.Byte, $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$9($.$$.S.Byte, bufferedData)), this._boundary.BoundaryBytes);
                    if (index >= 0)
                    {
                        if (index !== 0)
                        {
                            let $t4 = buffer;
                            /*var*/ let slice = $t4.Slice(0, $.$$.S.Math.Min$4(buffer.Length, index));
                            /*var*/ let readAmount = this._innerStream.Read$1(slice.Span);
                            return $.$$.N.AsyncResolver.Result($asnycContext, this.UpdatePosition(readAmount));
                        }
                        else 
                        {
                            let $t5, $r5;
                            /*var*/ let length = this._boundary.BoundaryBytes.Length;
                            return $.$$.N.AsyncResolver.Result($asnycContext, ($t5 = ReadBoundaryAsync(this, length, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5))));
                        }
                    }
                    /*int*/ let matchOffset;
                    /*int*/ let matchCount;
                    /*int*/ let read;
                    if ($.$maw.MAW.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.S.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.S.Int32)))
                    {
                        let $t9, $r9;
                        if (matchOffset > bufferedData.Offset)
                        {
                            let $t8 = buffer;
                            /*var*/ let slice = $t8.Slice(0, $.$$.S.Math.Min$4(buffer.Length, ((matchOffset - bufferedData.Offset) | 0)));
                            read = this._innerStream.Read$1(slice.Span);
                            return $.$$.N.AsyncResolver.Result($asnycContext, this.UpdatePosition(read));
                        }
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        $.$$.SD.Debug.Assert$4(matchCount === length, "matchCount == length");
                        return $.$$.N.AsyncResolver.Result($asnycContext, ($t9 = ReadBoundaryAsync(this, length, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9))));
                    }
                    let $t10 = buffer.Span;
                    read = this._innerStream.Read$1($t10.Slice(0, $.$$.S.Math.Min$4(buffer.Length, bufferedData.Count)));
                    return $.$$.N.AsyncResolver.Result($asnycContext, this.UpdatePosition(read));
                    /*static Task<int>*/ /*async*/  function ReadBoundaryAsync(/*MultipartReaderStream*/ stream, /*int*/ length, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.Int32), $.$$.S.Int32, async ($asnycContext) => 
                        {
                            let $t11, $r11;
                            /*var*/ let boundary = stream._bytePool.Rent(length);
                            /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                            stream._bytePool.Return(boundary, false);
                            $.$$.SD.Debug.Assert$4(read === length, "read == length");
                            /*var*/ let remainder = ($t11 = stream._innerStream.ReadLineAsync(100, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                            remainder = remainder.trim();
                            if ($.$$.S.String.Equals$3("--", remainder, 4/*StringComparison.Ordinal*/))
                            {
                                stream.FinalBoundaryFound = true;
                            }
                            $.$$.SD.Debug.Assert$4(stream.FinalBoundaryFound || $.$$.S.String.Equals$3($.$$.S.String.Empty, remainder, 4/*StringComparison.Ordinal*/), "Un-expected data found on the boundary line: " + $.$strNN(remainder));
                            stream._finished = true;
                            return $.$$.N.AsyncResolver.Result($asnycContext, 0);
                        });
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504969851)
            
            //--TRIMMABLE-BOUNDARY-START(206159675515)
            static /*bool */ SubMatch(/*ArraySegment<byte>*/ segment1, /*ReadOnlySpan<byte>*/ matchBytes, /*out int*/ matchOffset, /*out int*/ matchCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159675515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                matchOffset.$v = $.$$.S.Math.Max$4(segment1.Offset, ((((segment1.Offset + segment1.Count) | 0) - matchBytes.Length) | 0));
                /*var*/ let segmentEnd = ((segment1.Offset + segment1.Count) | 0);
                matchCount.$v = 0;
                for(; matchOffset.$v < segmentEnd; matchOffset.$v++)
                {
                    /*var*/ let countLimit = ((segmentEnd - matchOffset.$v) | 0);
                    for(matchCount.$v = 0; matchCount.$v < matchBytes.Length && matchCount.$v < countLimit; matchCount.$v++)
                    {
                        if (matchBytes._reference.GetAt(matchCount.$v) !== $.$$.System.Array.$ReadT1.call(segment1.Array, ((matchOffset.$v + matchCount.$v) | 0)))
                        {
                            matchCount.$v = 0;
                            break;
                        }
                    }
                    if (matchCount.$v > 0)
                    {
                        break;
                    }
                }
                return matchCount.$v > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(206159675515)
            
            //--TRIMMABLE-BOUNDARY-START(64425754747)
            /*void */ CopyTo(/*Stream*/ destination, /*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.S.Math.Max$4(4096, bufferSize);
                super.CopyTo(destination, bufferSize);
            }
            //--TRIMMABLE-BOUNDARY-END(64425754747)
            
            //--TRIMMABLE-BOUNDARY-START(68720722043)
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720722043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.S.Math.Max$4(4096, bufferSize);
                return super.CopyToAsync(destination, bufferSize, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(68720722043)
            
            static $h = 1245307;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015689339),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670395003,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389871739,
        "f": 83886082
      },
      "n": "FinalBoundaryFound",
      "d": 1245307,
      "h": 73015689339,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015689339),
//--TRIMMABLE-BOUNDARY-START(146030133371),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850264187,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979806331,
        "f": 83886081
      },
      "n": "LengthLimit",
      "d": 1245307,
      "h": 146030133371,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030133371),
//--TRIMMABLE-BOUNDARY-START(51540852859),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900591227,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 1245307,
      "h": 51540852859,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540852859),
//--TRIMMABLE-BOUNDARY-START(55835820155),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490525819,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 1245307,
      "h": 55835820155,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835820155),
//--TRIMMABLE-BOUNDARY-START(60130787451),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080460411,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 1245307,
      "h": 60130787451,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130787451),
//--TRIMMABLE-BOUNDARY-START(141735166075),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260329595,
        "f": 50364417
      },
      "n": "Length",
      "d": 1245307,
      "h": 141735166075,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735166075),
//--TRIMMABLE-BOUNDARY-START(150325100667),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440198779,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569740923,
        "f": 83918849
      },
      "n": "Position",
      "d": 1245307,
      "h": 150325100667,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325100667)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171799937147),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 1245307,
      "h": 171799937147,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799937147),
//--TRIMMABLE-BOUNDARY-START(201864708219),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1245307,
      "h": 201864708219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201864708219),
//--TRIMMABLE-BOUNDARY-START(214749610107),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1245307,
      "h": 214749610107,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214749610107),
//--TRIMMABLE-BOUNDARY-START(223339544699),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 1245307,
      "h": 223339544699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223339544699),
//--TRIMMABLE-BOUNDARY-START(219044577403),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 1245307,
      "h": 219044577403,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219044577403),
//--TRIMMABLE-BOUNDARY-START(77310656635),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1245307,
      "h": 77310656635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310656635),
//--TRIMMABLE-BOUNDARY-START(154620067963),
    {
      "r": 65537,
      "n": "PositionInnerStream",
      "d": 1245307,
      "h": 154620067963,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154620067963),
//--TRIMMABLE-BOUNDARY-START(210454642811),
    {
      "r": 655361,
      "p": [
        {
          "n": "read",
          "p": 655361
        }
      ],
      "n": "UpdatePosition",
      "d": 1245307,
      "h": 210454642811,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454642811),
//--TRIMMABLE-BOUNDARY-START(158915035259),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1245307,
      "h": 158915035259,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158915035259),
//--TRIMMABLE-BOUNDARY-START(163210002555),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 1245307,
      "h": 163210002555,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163210002555),
//--TRIMMABLE-BOUNDARY-START(167504969851),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 1245307,
      "h": 167504969851,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(167504969851),
//--TRIMMABLE-BOUNDARY-START(206159675515),
    {
      "r": 262145,
      "p": [
        {
          "n": "segment1",
          "p": $.$$.S.ArraySegment$$($.$$.S.Byte).$h
        },
        {
          "n": "matchBytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "matchOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "matchCount",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "SubMatch",
      "d": 1245307,
      "h": 206159675515,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206159675515),
//--TRIMMABLE-BOUNDARY-START(64425754747),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1245307,
      "h": 64425754747,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425754747),
//--TRIMMABLE-BOUNDARY-START(68720722043),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "CopyToAsync",
      "d": 1245307,
      "h": 68720722043,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720722043)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212603),
    {
      "t": 1114235,
      "n": "_boundary",
      "d": 1245307,
      "h": 4296212603,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212603),
//--TRIMMABLE-BOUNDARY-START(21476081787),
    {
      "t": 393339,
      "n": "_innerStream",
      "d": 1245307,
      "h": 21476081787,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081787),
//--TRIMMABLE-BOUNDARY-START(8591179899),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_bytePool",
      "d": 1245307,
      "h": 8591179899,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179899),
//--TRIMMABLE-BOUNDARY-START(17181114491),
    {
      "t": 917505,
      "n": "_innerOffset",
      "d": 1245307,
      "h": 17181114491,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114491),
//--TRIMMABLE-BOUNDARY-START(30066016379),
    {
      "t": 917505,
      "n": "_position",
      "d": 1245307,
      "h": 30066016379,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066016379),
//--TRIMMABLE-BOUNDARY-START(25771049083),
    {
      "t": 917505,
      "n": "_observedLength",
      "d": 1245307,
      "h": 25771049083,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049083),
//--TRIMMABLE-BOUNDARY-START(12886147195),
    {
      "t": 262145,
      "n": "_finished",
      "d": 1245307,
      "h": 12886147195,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245885563),
    {
      "p": [
        {
          "n": "stream",
          "p": 393339
        },
        {
          "n": "boundary",
          "p": 1114235
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1245307,
      "h": 47245885563,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245885563),
//--TRIMMABLE-BOUNDARY-START(42950918267),
    {
      "p": [
        {
          "n": "stream",
          "p": 393339
        },
        {
          "n": "boundary",
          "p": 1114235
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245307,
      "h": 42950918267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950918267)
  ],
  "h": 1245307
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.MultipartReaderStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}MultipartReaderStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245307)
        
        

        //--TRIMMABLE-BOUNDARY-START(524411)
        $asm.$cls(`$maw.MAW.FileBufferingWriteStream`, ($self) => class FileBufferingWriteStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(47245164667)
            /*int*/ static DefaultMemoryThreshold = 32768;
            //--TRIMMABLE-BOUNDARY-END(47245164667)
            
            //--TRIMMABLE-BOUNDARY-START(8590459003)
            /*int*/ _memoryThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(8590459003)
            
            //--TRIMMABLE-BOUNDARY-START(4295491707)
            /*long?*/ _bufferLimit = null;
            //--TRIMMABLE-BOUNDARY-END(4295491707)
            
            //--TRIMMABLE-BOUNDARY-START(12885426299)
            /*Func<string>*/ _tempFileDirectoryAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(12885426299)
            
            //--TRIMMABLE-BOUNDARY-START(30065295483)
            $ctor$3(/*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>?*/ tempFileDirectoryAccessor)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, memoryThreshold, "memoryThreshold");
                    if (bufferLimit !== null && $.$$.S.Int64.op_LessThan(bufferLimit, memoryThreshold))
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("bufferLimit", `${$.$strNN("bufferLimit")} must be larger than ${$.$strNN("memoryThreshold")}.`);
                    }
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor ?? $.$maw.MAI.AspNetCoreTempDirectory.TempDirectoryFactory;
                    this.PagedByteBuffer = new $.$maw.MAW.PagedByteBuffer().$ctor$1($.$$.SB.ArrayPool$$($.$$.S.Byte).Shared);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295483)
            
            //--TRIMMABLE-BOUNDARY-START(171799216251)
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(171799216251)
            
            //--TRIMMABLE-BOUNDARY-START(34360262779)
            /*bool */ get CanRead()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262779)
            
            //--TRIMMABLE-BOUNDARY-START(38655230075)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655230075)
            
            //--TRIMMABLE-BOUNDARY-START(42950197371)
            /*bool */ get CanWrite()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197371)
            
            //--TRIMMABLE-BOUNDARY-START(167504248955)
            /*long */ get Length()
            {
                return BigInt.asIntN(64, BigInt(this.PagedByteBuffer.Length) + ((this.FileStream?.Length ?? null) ?? 0n));
            }
            //--TRIMMABLE-BOUNDARY-END(167504248955)
            
            //--TRIMMABLE-BOUNDARY-START(180389150843)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338823803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(180389150843)
            
            //--TRIMMABLE-BOUNDARY-START(176094183547)
            /*PagedByteBuffer*/ PagedByteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(176094183547)
            
            //--TRIMMABLE-BOUNDARY-START(77309935739)
            /*FileStream?*/ FileStream = null;
            //--TRIMMABLE-BOUNDARY-END(77309935739)
            
            //--TRIMMABLE-BOUNDARY-START(60130066555)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(60130066555)
            
            //--TRIMMABLE-BOUNDARY-START(197569020027)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569020027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569020027)
            
            //--TRIMMABLE-BOUNDARY-START(184684118139)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684118139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684118139)
            
            //--TRIMMABLE-BOUNDARY-START(188979085435)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979085435);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979085435)
            
            //--TRIMMABLE-BOUNDARY-START(193274052731)
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274052731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274052731)
            
            //--TRIMMABLE-BOUNDARY-START(236223725691)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223725691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SI.Stream.ValidateBufferArguments(buffer, offset, count);
                this.ThrowIfDisposed();
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._bufferLimit) && BigInt.asIntN(64, this._bufferLimit - this.Length) < count)
                {
                    this.Dispose();
                    throw new $.$$.SI.IOException().$ctor$13("Buffer limit exceeded.");
                }
                /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - count) | 0)) >= this.PagedByteBuffer.Length;
                if (allowMemoryBuffer)
                {
                    this.PagedByteBuffer.Add(buffer, offset, count);
                    $.$$.SD.Debug.Assert$4(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                }
                else 
                {
                    this.EnsureFileStream();
                    this.PagedByteBuffer.MoveTo(this.FileStream);
                    this.FileStream.Write(buffer, offset, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223725691)
            
            //--TRIMMABLE-BOUNDARY-START(240518692987)
            /*Task *//*async*/  WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518692987);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t1 = this.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, buffer, offset, count)), cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(240518692987)
            
            //--TRIMMABLE-BOUNDARY-START(244813660283)
            /*ValueTask *//*async*/  WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813660283);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(this._bufferLimit) && BigInt.asIntN(64, this._bufferLimit - this.Length) < buffer.Length)
                    {
                        this.Dispose();
                        throw new $.$$.SI.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - buffer.Length) | 0)) >= this.PagedByteBuffer.Length;
                    if (allowMemoryBuffer)
                    {
                        this.PagedByteBuffer.Add$1(buffer);
                        $.$$.SD.Debug.Assert$4(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                    }
                    else 
                    {
                        let $t2, $r2;
                        let $t3, $r3;
                        this.EnsureFileStream();
                        ($t2 = this.PagedByteBuffer.MoveToAsync$1(this.FileStream, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                        ($t3 = this.FileStream.WriteAsync$2(buffer, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t3, { set $v($v) { $r3 = $v; } }) ? $r3 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t3)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(244813660283)
            
            //--TRIMMABLE-BOUNDARY-START(81604903035)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81604903035)
            
            //--TRIMMABLE-BOUNDARY-START(85899870331)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899870331);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899870331)
            
            //--TRIMMABLE-BOUNDARY-START(227633791099)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633791099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633791099)
            
            //--TRIMMABLE-BOUNDARY-START(68720001147)
            /*Task *//*async*/  DrainBufferAsync$1(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t6, $r6;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720001147);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.SI.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            let $t4, $r4;
                            let $t5, $r5;
                            ($t4 = readStream.CopyToAsync$2(destination, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            ($t5 = this.FileStream.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.S$IDisposable$Dispose();
                        }
                    }
                    ($t6 = this.PagedByteBuffer.MoveToAsync$1(destination, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720001147)
            
            //--TRIMMABLE-BOUNDARY-START(64425033851)
            /*Task *//*async*/  DrainBufferAsync(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t9, $r9;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425033851);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.SI.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            let $t7, $r7;
                            let $t8, $r8;
                            ($t7 = $.$sipl.SIP.StreamPipeExtensions.CopyToAsync(readStream, destination, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t7, { set $v($v) { $r7 = $v; } }) ? $r7 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t7)));
                            ($t8 = this.FileStream.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.S$IDisposable$Dispose();
                        }
                    }
                    ($t9 = this.PagedByteBuffer.MoveToAsync(destination, cancellationToken), ($.$$.N.AsyncResolver.IsCompleted($t9, { set $v($v) { $r9 = $v; } }) ? $r9 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t9)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425033851)
            
            //--TRIMMABLE-BOUNDARY-START(51540131963)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.PagedByteBuffer.Dispose();
                    this.FileStream?.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131963)
            
            //--TRIMMABLE-BOUNDARY-START(55835099259)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835099259);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Disposed)
                    {
                        let $t10, $r10;
                        this.Disposed = true;
                        this.PagedByteBuffer.Dispose();
                        ($t10 = ((this.FileStream?.DisposeAsync() ?? null) ?? new $.$$.STT.ValueTask()), ($.$$.N.AsyncResolver.IsCompleted($t10, { set $v($v) { $r10 = $v; } }) ? $r10 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t10)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835099259)
            
            //--TRIMMABLE-BOUNDARY-START(73014968443)
            /*void */ EnsureFileStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.FileStream === null)
                {
                    /*var*/ let tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    /*var*/ let tempFileName = $.$$.SI.Path.Combine$3(tempFileDirectory, "ASPNETCORE_" + $.$strNN($.$$.S.Guid.NewGuid().ToString()) + ".tmp");
                    if (!$.$$.SRI.RuntimeInformation.IsOSPlatform($.$$.SRI.OSPlatform.Windows))
                    {
                        /*var*/ let tempTempFileName = $.$$.SI.Path.GetTempFileName();
                        $.$$.SI.File.Move$1(tempTempFileName, tempFileName);
                    }
                    this.FileStream = new $.$$.SI.FileStream().$ctor$12(tempFileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/ | 67108864/*FileOptions.DeleteOnClose*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014968443)
            
            //--TRIMMABLE-BOUNDARY-START(231928758395)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928758395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(231928758395)
            
            static $h = 524411;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799216251),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029412475,
        "f": 50331649
      },
      "n": "MemoryThreshold",
      "d": 524411,
      "h": 171799216251,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799216251),
//--TRIMMABLE-BOUNDARY-START(34360262779),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489804923,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 524411,
      "h": 34360262779,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360262779),
//--TRIMMABLE-BOUNDARY-START(38655230075),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079739515,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 524411,
      "h": 38655230075,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655230075),
//--TRIMMABLE-BOUNDARY-START(42950197371),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669674107,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 524411,
      "h": 42950197371,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950197371),
//--TRIMMABLE-BOUNDARY-START(167504248955),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439477883,
        "f": 50364417
      },
      "n": "Length",
      "d": 524411,
      "h": 167504248955,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504248955),
//--TRIMMABLE-BOUNDARY-START(180389150843),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209281659,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338823803,
        "f": 83918849
      },
      "n": "Position",
      "d": 524411,
      "h": 180389150843,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389150843),
//--TRIMMABLE-BOUNDARY-START(176094183547),
    {
      "p": 1507451,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619347067,
        "f": 50331656
      },
      "n": "PagedByteBuffer",
      "d": 524411,
      "h": 176094183547,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(176094183547),
//--TRIMMABLE-BOUNDARY-START(77309935739),
    {
      "p": 93913089,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849543291,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748889211,
        "f": 83886082
      },
      "n": "FileStream",
      "d": 524411,
      "h": 77309935739,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77309935739),
//--TRIMMABLE-BOUNDARY-START(60130066555),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259608699,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158954619,
        "f": 83886082
      },
      "n": "Disposed",
      "d": 524411,
      "h": 60130066555,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60130066555)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(197569020027),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 524411,
      "h": 197569020027,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569020027),
//--TRIMMABLE-BOUNDARY-START(184684118139),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 524411,
      "h": 184684118139,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684118139),
//--TRIMMABLE-BOUNDARY-START(188979085435),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 524411,
      "h": 188979085435,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188979085435),
//--TRIMMABLE-BOUNDARY-START(193274052731),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 524411,
      "h": 193274052731,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274052731),
//--TRIMMABLE-BOUNDARY-START(236223725691),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 524411,
      "h": 236223725691,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(236223725691),
//--TRIMMABLE-BOUNDARY-START(240518692987),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 524411,
      "h": 240518692987,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(240518692987),
//--TRIMMABLE-BOUNDARY-START(244813660283),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 524411,
      "h": 244813660283,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(244813660283),
//--TRIMMABLE-BOUNDARY-START(81604903035),
    {
      "r": 65537,
      "n": "Flush",
      "d": 524411,
      "h": 81604903035,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604903035),
//--TRIMMABLE-BOUNDARY-START(85899870331),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 524411,
      "h": 85899870331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899870331),
//--TRIMMABLE-BOUNDARY-START(227633791099),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 524411,
      "h": 227633791099,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633791099),
//--TRIMMABLE-BOUNDARY-START(68720001147),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 95748097
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "DrainBufferAsync",
      "o": "@$1",
      "d": 524411,
      "h": 68720001147,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(68720001147),
//--TRIMMABLE-BOUNDARY-START(64425033851),
    {
      "r": 178454529,
      "p": [
        {
          "n": "destination",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "DrainBufferAsync",
      "d": 524411,
      "h": 64425033851,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64425033851),
//--TRIMMABLE-BOUNDARY-START(51540131963),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 524411,
      "h": 51540131963,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540131963),
//--TRIMMABLE-BOUNDARY-START(55835099259),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 524411,
      "h": 55835099259,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(55835099259),
//--TRIMMABLE-BOUNDARY-START(73014968443),
    {
      "r": 65537,
      "n": "EnsureFileStream",
      "d": 524411,
      "h": 73014968443,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014968443),
//--TRIMMABLE-BOUNDARY-START(231928758395),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 524411,
      "h": 231928758395,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231928758395)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245164667),
    {
      "t": 655361,
      "n": "DefaultMemoryThreshold",
      "d": 524411,
      "h": 47245164667,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245164667),
//--TRIMMABLE-BOUNDARY-START(8590459003),
    {
      "t": 655361,
      "n": "_memoryThreshold",
      "d": 524411,
      "h": 8590459003,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590459003),
//--TRIMMABLE-BOUNDARY-START(4295491707),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_bufferLimit",
      "d": 524411,
      "h": 4295491707,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491707),
//--TRIMMABLE-BOUNDARY-START(12885426299),
    {
      "t": $.$$.S.Func$$($.$$.S.String).$h,
      "n": "_tempFileDirectoryAccessor",
      "d": 524411,
      "h": 12885426299,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426299)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295483),
    {
      "p": [
        {
          "n": "memoryThreshold",
          "p": 655361,
          "f": 65,
          "v": 32768
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.S.Int64).$h,
          "f": 65
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.S.Func$$($.$$.S.String).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524411,
      "h": 30065295483,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295483)
  ],
  "h": 524411
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.FileBufferingWriteStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}FileBufferingWriteStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524411)
        
        

        //--TRIMMABLE-BOUNDARY-START(983163)
        $asm.$cls(`$maw.MAW.HttpResponseStreamWriter`, ($self) => class HttpResponseStreamWriter extends $.$$.SI.TextWriter
        {
            //--TRIMMABLE-BOUNDARY-START(77310394491)
            /*int*/ static DefaultBufferSize = 16384;
            //--TRIMMABLE-BOUNDARY-END(77310394491)
            
            //--TRIMMABLE-BOUNDARY-START(38655688827)
            /*Stream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(38655688827)
            
            //--TRIMMABLE-BOUNDARY-START(34360721531)
            /*Encoder*/ _encoder = null;
            //--TRIMMABLE-BOUNDARY-END(34360721531)
            
            //--TRIMMABLE-BOUNDARY-START(8590917755)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(8590917755)
            
            //--TRIMMABLE-BOUNDARY-START(25770786939)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(25770786939)
            
            //--TRIMMABLE-BOUNDARY-START(21475819643)
            /*int*/ _charBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(21475819643)
            
            //--TRIMMABLE-BOUNDARY-START(4295950459)
            /*byte[]*/ _byteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295950459)
            
            //--TRIMMABLE-BOUNDARY-START(12885885051)
            /*char[]*/ _charBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(12885885051)
            
            //--TRIMMABLE-BOUNDARY-START(17180852347)
            /*int*/ _charBufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(17180852347)
            
            //--TRIMMABLE-BOUNDARY-START(30065754235)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30065754235)
            
            //--TRIMMABLE-BOUNDARY-START(55835558011)
            $ctor$6(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$4(stream, encoding, 16384/*DefaultBufferSize*/, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835558011);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835558011)
            
            //--TRIMMABLE-BOUNDARY-START(51540590715)
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$4(stream, encoding, bufferSize, $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared, $.$$.SB.ArrayPool$$($.$$.S.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540590715);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590715)
            
            //--TRIMMABLE-BOUNDARY-START(47245623419)
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245623419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("stream") });
                    this.Encoding = $.$firstOf(encoding, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.S.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, bufferSize, "bufferSize");
                    if (!this._stream.CanWrite)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$maw.Resources.HttpResponseStreamWriter_StreamNotWritable, "stream");
                    }
                    this._charBufferSize = bufferSize;
                    this._encoder = encoding.GetEncoder();
                    this._charBuffer = charPool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxByteCount(bufferSize);
                        this._byteBuffer = bytePool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        charPool.Return(this._charBuffer, false);
                        if (this._byteBuffer !== null)
                        {
                            bytePool.Return(this._byteBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623419)
            
            //--TRIMMABLE-BOUNDARY-START(90195296379)
            /*Encoding*/ Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(90195296379)
            
            //--TRIMMABLE-BOUNDARY-START(128850002043)
            /*void */ Write$1(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850002043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferCount === this._charBufferSize)
                {
                    this.FlushInternal(false);
                }
                $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                this._charBufferCount++;
            }
            //--TRIMMABLE-BOUNDARY-END(128850002043)
            
            //--TRIMMABLE-BOUNDARY-START(133144969339)
            /*void */ Write$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (values === null)
                {
                    return;
                }
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144969339)
            
            //--TRIMMABLE-BOUNDARY-START(137439936635)
            /*void */ Write$9(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439936635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let remaining = value.Length;
                while(remaining > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    /*var*/ let written = this.CopyToCharBuffer$1(value);
                    remaining -= written;
                    value = value.Slice$1(written);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439936635)
            
            //--TRIMMABLE-BOUNDARY-START(141734903931)
            /*void */ Write$16(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (value === null)
                {
                    return;
                }
                /*var*/ let count = value.length;
                /*var*/ let index = 0;
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734903931)
            
            //--TRIMMABLE-BOUNDARY-START(180389609595)
            /*void */ WriteLine$10(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389609595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this.Write$9(value);
                this.Write$16(this.NewLine);
            }
            //--TRIMMABLE-BOUNDARY-END(180389609595)
            
            //--TRIMMABLE-BOUNDARY-START(146029871227)
            /*Task */ WriteAsync(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (this._charBufferCount === this._charBufferSize)
                {
                    return this.WriteAsyncAwaited(value);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    return $.$$.STT.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029871227)
            
            //--TRIMMABLE-BOUNDARY-START(163209740411)
            /*Task *//*async*/  WriteAsyncAwaited(/*char*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t5, $r5;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209740411);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(this._charBufferCount === this._charBufferSize, "_charBufferCount == _charBufferSize");
                    ($t5 = this.FlushInternalAsync(false), ($.$$.N.AsyncResolver.IsCompleted($t5, { set $v($v) { $r5 = $v; } }) ? $r5 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t5)));
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209740411)
            
            //--TRIMMABLE-BOUNDARY-START(150324838523)
            /*Task */ WriteAsync$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324838523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (values === null || count === 0)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= count)
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$1(values, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324838523)
            
            //--TRIMMABLE-BOUNDARY-START(167504707707)
            /*Task *//*async*/  WriteAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504707707);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(count > 0, "count > 0");
                    $.$$.SD.Debug.Assert$4(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            let $t8, $r8;
                            ($t8 = this.FlushInternalAsync(false), ($.$$.N.AsyncResolver.IsCompleted($t8, { set $v($v) { $r8 = $v; } }) ? $r8 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t8)));
                        }
                        this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504707707)
            
            //--TRIMMABLE-BOUNDARY-START(158914773115)
            /*Task */ WriteAsync$4(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914773115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.S.String.IsNullOrEmpty(value))
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.length)
                {
                    this.CopyToCharBuffer$3(value);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$3(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914773115)
            
            //--TRIMMABLE-BOUNDARY-START(176094642299)
            /*Task *//*async*/  WriteAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094642299);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let count = value.length;
                    $.$$.SD.Debug.Assert$4(count > 0, "count > 0");
                    $.$$.SD.Debug.Assert$4(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    /*var*/ let index = 0;
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            let $t11, $r11;
                            ($t11 = this.FlushInternalAsync(false), ($.$$.N.AsyncResolver.IsCompleted($t11, { set $v($v) { $r11 = $v; } }) ? $r11 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t11)));
                        }
                        this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094642299)
            
            //--TRIMMABLE-BOUNDARY-START(154619805819)
            /*Task */ WriteAsync$3(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.Length)
                {
                    this.CopyToCharBuffer$1(value.Span);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619805819)
            
            //--TRIMMABLE-BOUNDARY-START(171799675003)
            /*Task *//*async*/  WriteAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799675003);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4(value.Length > 0, "value.Length > 0");
                    $.$$.SD.Debug.Assert$4(((this._charBufferSize - this._charBufferCount) | 0) < value.Length, "_charBufferSize - _charBufferCount < value.Length");
                    /*var*/ let remaining = value.Length;
                    while(remaining > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            let $t14, $r14;
                            ($t14 = this.FlushInternalAsync(false), ($.$$.N.AsyncResolver.IsCompleted($t14, { set $v($v) { $r14 = $v; } }) ? $r14 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t14)));
                        }
                        /*var*/ let written = this.CopyToCharBuffer$1(value.Span);
                        remaining -= written;
                        value = value.Slice$1(written);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799675003)
            
            //--TRIMMABLE-BOUNDARY-START(193274511483)
            /*Task */ WriteLineAsync$4(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274511483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.STT.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty && this.NewLine.length === 0)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.Length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$1(value.Span);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274511483)
            
            //--TRIMMABLE-BOUNDARY-START(210454380667)
            /*Task *//*async*/  WriteLineAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t15, $r15;
                    let $t16, $r16;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210454380667);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t15 = this.WriteAsync$3(value, new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t15, { set $v($v) { $r15 = $v; } }) ? $r15 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t15)));
                    ($t16 = this.WriteAsync$4(this.NewLine), ($.$$.N.AsyncResolver.IsCompleted($t16, { set $v($v) { $r16 = $v; } }) ? $r16 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t16)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210454380667)
            
            //--TRIMMABLE-BOUNDARY-START(188979544187)
            /*Task */ WriteLineAsync$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979544187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ((values === null || count === 0) && this.NewLine.length === 0)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                values ??= $.$$.S.Array.Empty($.$$.S.Char);
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((values.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.S.Int32));
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$1(values, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979544187)
            
            //--TRIMMABLE-BOUNDARY-START(206159413371)
            /*Task *//*async*/  WriteLineAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t19, $r19;
                    let $t20, $r20;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159413371);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t19 = this.WriteAsync$1(values, index, count), ($.$$.N.AsyncResolver.IsCompleted($t19, { set $v($v) { $r19 = $v; } }) ? $r19 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t19)));
                    ($t20 = this.WriteAsync$4(this.NewLine), ($.$$.N.AsyncResolver.IsCompleted($t20, { set $v($v) { $r20 = $v; } }) ? $r20 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t20)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206159413371)
            
            //--TRIMMABLE-BOUNDARY-START(184684576891)
            /*Task */ WriteLineAsync$1(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684576891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((this.NewLine.length + 1) | 0))
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684576891)
            
            //--TRIMMABLE-BOUNDARY-START(201864446075)
            /*Task *//*async*/  WriteLineAsyncAwaited(/*char*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t21, $r21;
                    let $t22, $r22;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864446075);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t21 = this.WriteAsync(value), ($.$$.N.AsyncResolver.IsCompleted($t21, { set $v($v) { $r21 = $v; } }) ? $r21 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t21)));
                    ($t22 = this.WriteAsync$4(this.NewLine), ($.$$.N.AsyncResolver.IsCompleted($t22, { set $v($v) { $r22 = $v; } }) ? $r22 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t22)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864446075)
            
            //--TRIMMABLE-BOUNDARY-START(197569478779)
            /*Task */ WriteLineAsync$5(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569478779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.S.String.IsNullOrEmpty(value) && this.NewLine.length === 0)
                {
                    return $.$$.STT.Task.CompletedTask;
                }
                value ??= $.$$.S.String.Empty;
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$3(value);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.STT.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$3(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569478779)
            
            //--TRIMMABLE-BOUNDARY-START(214749347963)
            /*Task *//*async*/  WriteLineAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t23, $r23;
                    let $t24, $r24;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749347963);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    ($t23 = this.WriteAsync$4(value), ($.$$.N.AsyncResolver.IsCompleted($t23, { set $v($v) { $r23 = $v; } }) ? $r23 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t23)));
                    ($t24 = this.WriteAsync$4(this.NewLine), ($.$$.N.AsyncResolver.IsCompleted($t24, { set $v($v) { $r24 = $v; } }) ? $r24 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t24)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214749347963)
            
            //--TRIMMABLE-BOUNDARY-START(94490263675)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490263675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this.FlushInternal(true);
            }
            //--TRIMMABLE-BOUNDARY-END(94490263675)
            
            //--TRIMMABLE-BOUNDARY-START(98785230971)
            /*Task */ FlushAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.MAW.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                return this.FlushInternalAsync(true);
            }
            //--TRIMMABLE-BOUNDARY-END(98785230971)
            
            //--TRIMMABLE-BOUNDARY-START(81605361787)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    try
                    {
                        this.FlushInternal(true);
                    }
                    finally
                    {
                        {
                            this._bytePool.Return(this._byteBuffer, false);
                            this._charPool.Return(this._charBuffer, false);
                        }
                    }
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(81605361787)
            
            //--TRIMMABLE-BOUNDARY-START(85900329083)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                {
                    let $t26, $r26;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900329083);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._disposed)
                    {
                        this._disposed = true;
                        try
                        {
                            let $t25, $r25;
                            ($t25 = this.FlushInternalAsync(true), ($.$$.N.AsyncResolver.IsCompleted($t25, { set $v($v) { $r25 = $v; } }) ? $r25 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t25)));
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(this._byteBuffer, false);
                                this._charPool.Return(this._charBuffer, false);
                            }
                        }
                    }
                    ($t26 = super.DisposeAsync(), ($.$$.N.AsyncResolver.IsCompleted($t26, { set $v($v) { $r26 = $v; } }) ? $r26 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t26)));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900329083)
            
            //--TRIMMABLE-BOUNDARY-START(103080198267)
            /*void */ FlushInternal(/*bool*/ flushEncoder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080198267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._charBufferCount === 0)
                {
                    return;
                }
                /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                this._charBufferCount = 0;
                if (count > 0)
                {
                    this._stream.Write(this._byteBuffer, 0, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080198267)
            
            //--TRIMMABLE-BOUNDARY-START(107375165563)
            /*Task *//*async*/  FlushInternalAsync(/*bool*/ flushEncoder)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task, $.$$.S.Void, async ($asnycContext) => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375165563);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._charBufferCount === 0)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext,);
                    }
                    /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                    this._charBufferCount = 0;
                    if (count > 0)
                    {
                        let $t27, $r27;
                        ($t27 = this._stream.WriteAsync$2($.$$.S.Memory$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9($.$$.S.Byte, this._byteBuffer, 0, count)), new $.$$.ST$1.CancellationToken()), ($.$$.N.AsyncResolver.IsCompleted($t27, { set $v($v) { $r27 = $v; } }) ? $r27 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t27)));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375165563)
            
            //--TRIMMABLE-BOUNDARY-START(73015427195)
            /*void */ CopyToCharBuffer$3(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(((this._charBufferSize - this._charBufferCount) | 0) >= value.length, "_charBufferSize - _charBufferCount >= value.Length");
                $.$$.S.String.CopyTo.call(value, 0, this._charBuffer, this._charBufferCount, value.length);
                this._charBufferCount += value.length;
            }
            //--TRIMMABLE-BOUNDARY-END(73015427195)
            
            //--TRIMMABLE-BOUNDARY-START(68720459899)
            /*void */ CopyToCharBuffer$2(/*string*/ value, /*ref int*/ index, /*ref int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.S.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.S.String.CopyTo.call(value, index.$v, this._charBuffer, this._charBufferCount, remaining);
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459899)
            
            //--TRIMMABLE-BOUNDARY-START(60130525307)
            /*void */ CopyToCharBuffer(/*char[]*/ values, /*ref int*/ index, /*ref int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.S.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.S.Buffer.BlockCopy(values, ((index.$v * 2) | 0), this._charBuffer, ((this._charBufferCount * 2) | 0), ((remaining * 2) | 0));
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(60130525307)
            
            //--TRIMMABLE-BOUNDARY-START(64425492603)
            /*int */ CopyToCharBuffer$1(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.S.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), value.Length);
                /*var*/ let source = value.Slice(0, remaining);
                /*var*/ let destination = new ($.$$.S.Span$$($.$$.S.Char))().$ctor$6(this._charBuffer, this._charBufferCount, remaining);
                source.CopyTo(destination);
                this._charBufferCount += remaining;
                return remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(64425492603)
            
            //--TRIMMABLE-BOUNDARY-START(120260067451)
            static /*Task */ GetObjectDisposedTask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.STT.Task.FromException(new $.$$.S.ObjectDisposedException().$ctor$17("HttpResponseStreamWriter"));
            }
            //--TRIMMABLE-BOUNDARY-END(120260067451)
            
            //--TRIMMABLE-BOUNDARY-START(124555034747)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034747)
            
            static $h = 983163;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.TextWriter; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195296379),
    {
      "p": 166723585,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965100155,
        "f": 50364417
      },
      "n": "Encoding",
      "d": 983163,
      "h": 90195296379,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195296379)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850002043),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 983163,
      "h": 128850002043,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850002043),
//--TRIMMABLE-BOUNDARY-START(133144969339),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 983163,
      "h": 133144969339,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144969339),
//--TRIMMABLE-BOUNDARY-START(137439936635),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "Write",
      "o": "@$9",
      "d": 983163,
      "h": 137439936635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439936635),
//--TRIMMABLE-BOUNDARY-START(141734903931),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$16",
      "d": 983163,
      "h": 141734903931,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734903931),
//--TRIMMABLE-BOUNDARY-START(180389609595),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "WriteLine",
      "o": "@$10",
      "d": 983163,
      "h": 180389609595,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389609595),
//--TRIMMABLE-BOUNDARY-START(146029871227),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteAsync",
      "d": 983163,
      "h": 146029871227,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029871227),
//--TRIMMABLE-BOUNDARY-START(163209740411),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteAsyncAwaited",
      "d": 983163,
      "h": 163209740411,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(163209740411),
//--TRIMMABLE-BOUNDARY-START(150324838523),
    {
      "r": 178454529,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteAsync",
      "o": "@$1",
      "d": 983163,
      "h": 150324838523,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324838523),
//--TRIMMABLE-BOUNDARY-START(167504707707),
    {
      "r": 178454529,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$1",
      "d": 983163,
      "h": 167504707707,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(167504707707),
//--TRIMMABLE-BOUNDARY-START(158914773115),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteAsync",
      "o": "@$4",
      "d": 983163,
      "h": 158914773115,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914773115),
//--TRIMMABLE-BOUNDARY-START(176094642299),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$3",
      "d": 983163,
      "h": 176094642299,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(176094642299),
//--TRIMMABLE-BOUNDARY-START(154619805819),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$3",
      "d": 983163,
      "h": 154619805819,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619805819),
//--TRIMMABLE-BOUNDARY-START(171799675003),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$2",
      "d": 983163,
      "h": 171799675003,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799675003),
//--TRIMMABLE-BOUNDARY-START(193274511483),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$4",
      "d": 983163,
      "h": 193274511483,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274511483),
//--TRIMMABLE-BOUNDARY-START(210454380667),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Char).$h
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$2",
      "d": 983163,
      "h": 210454380667,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(210454380667),
//--TRIMMABLE-BOUNDARY-START(188979544187),
    {
      "r": 178454529,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$2",
      "d": 983163,
      "h": 188979544187,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188979544187),
//--TRIMMABLE-BOUNDARY-START(206159413371),
    {
      "r": 178454529,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$1",
      "d": 983163,
      "h": 206159413371,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(206159413371),
//--TRIMMABLE-BOUNDARY-START(184684576891),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$1",
      "d": 983163,
      "h": 184684576891,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684576891),
//--TRIMMABLE-BOUNDARY-START(201864446075),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "d": 983163,
      "h": 201864446075,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(201864446075),
//--TRIMMABLE-BOUNDARY-START(197569478779),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$5",
      "d": 983163,
      "h": 197569478779,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569478779),
//--TRIMMABLE-BOUNDARY-START(214749347963),
    {
      "r": 178454529,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$3",
      "d": 983163,
      "h": 214749347963,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(214749347963),
//--TRIMMABLE-BOUNDARY-START(94490263675),
    {
      "r": 65537,
      "n": "Flush",
      "d": 983163,
      "h": 94490263675,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490263675),
//--TRIMMABLE-BOUNDARY-START(98785230971),
    {
      "r": 178454529,
      "n": "FlushAsync",
      "d": 983163,
      "h": 98785230971,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785230971),
//--TRIMMABLE-BOUNDARY-START(81605361787),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 983163,
      "h": 81605361787,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81605361787),
//--TRIMMABLE-BOUNDARY-START(85900329083),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 983163,
      "h": 85900329083,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(85900329083),
//--TRIMMABLE-BOUNDARY-START(103080198267),
    {
      "r": 65537,
      "p": [
        {
          "n": "flushEncoder",
          "p": 262145
        }
      ],
      "n": "FlushInternal",
      "d": 983163,
      "h": 103080198267,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080198267),
//--TRIMMABLE-BOUNDARY-START(107375165563),
    {
      "r": 178454529,
      "p": [
        {
          "n": "flushEncoder",
          "p": 262145
        }
      ],
      "n": "FlushInternalAsync",
      "d": 983163,
      "h": 107375165563,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107375165563),
//--TRIMMABLE-BOUNDARY-START(73015427195),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$3",
      "d": 983163,
      "h": 73015427195,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015427195),
//--TRIMMABLE-BOUNDARY-START(68720459899),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "count",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$2",
      "d": 983163,
      "h": 68720459899,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720459899),
//--TRIMMABLE-BOUNDARY-START(60130525307),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.S.Char).$h
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "count",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "CopyToCharBuffer",
      "d": 983163,
      "h": 60130525307,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130525307),
//--TRIMMABLE-BOUNDARY-START(64425492603),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$1",
      "d": 983163,
      "h": 64425492603,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425492603),
//--TRIMMABLE-BOUNDARY-START(120260067451),
    {
      "r": 178454529,
      "n": "GetObjectDisposedTask",
      "d": 983163,
      "h": 120260067451,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120260067451),
//--TRIMMABLE-BOUNDARY-START(124555034747),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 983163,
      "h": 124555034747,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555034747)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310394491),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 983163,
      "h": 77310394491,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310394491),
//--TRIMMABLE-BOUNDARY-START(38655688827),
    {
      "t": 95748097,
      "n": "_stream",
      "d": 983163,
      "h": 38655688827,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655688827),
//--TRIMMABLE-BOUNDARY-START(34360721531),
    {
      "t": 166002689,
      "n": "_encoder",
      "d": 983163,
      "h": 34360721531,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360721531),
//--TRIMMABLE-BOUNDARY-START(8590917755),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h,
      "n": "_bytePool",
      "d": 983163,
      "h": 8590917755,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917755),
//--TRIMMABLE-BOUNDARY-START(25770786939),
    {
      "t": $.$$.SB.ArrayPool$$($.$$.S.Char).$h,
      "n": "_charPool",
      "d": 983163,
      "h": 25770786939,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786939),
//--TRIMMABLE-BOUNDARY-START(21475819643),
    {
      "t": 655361,
      "n": "_charBufferSize",
      "d": 983163,
      "h": 21475819643,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819643),
//--TRIMMABLE-BOUNDARY-START(4295950459),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_byteBuffer",
      "d": 983163,
      "h": 4295950459,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950459),
//--TRIMMABLE-BOUNDARY-START(12885885051),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_charBuffer",
      "d": 983163,
      "h": 12885885051,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885051),
//--TRIMMABLE-BOUNDARY-START(17180852347),
    {
      "t": 655361,
      "n": "_charBufferCount",
      "d": 983163,
      "h": 17180852347,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852347),
//--TRIMMABLE-BOUNDARY-START(30065754235),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 983163,
      "h": 30065754235,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065754235)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835558011),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 983163,
      "h": 55835558011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835558011),
//--TRIMMABLE-BOUNDARY-START(51540590715),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 983163,
      "h": 51540590715,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590715),
//--TRIMMABLE-BOUNDARY-START(47245623419),
    {
      "p": [
        {
          "n": "stream",
          "p": 95748097
        },
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Byte).$h
        },
        {
          "n": "charPool",
          "p": $.$$.SB.ArrayPool$$($.$$.S.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 983163,
      "h": 47245623419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245623419)
  ],
  "h": 983163
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}WebUtilities${separator}HttpResponseStreamWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983163)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.Net.Http.Headers", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web"));
})();
//--TRIMMABLE-BOUNDARY-END(123)
