
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mnhh, $sipl, $stew) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.WebUtilities", 
    {"h":49384,"f":"Microsoft.AspNetCore.WebUtilities","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"ASP.NET Core utilities, such as for working with forms, multipart messages, and query strings.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.AspNetCore.WebUtilities","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.AspNetCore.WebUtilities","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.WebUtilities.Tests","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.AspNetCore.WebUtilities.Microbenchmarks","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper", ($self) => class ArgumentOutOfRangeThrowHelper
        {
            static /*void */ ThrowIfZero(/*int*/ value, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfZero($.$$.System.Int32, value, paramName);
            }
            static /*void */ ThrowIfNegative(/*int*/ value, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, value, paramName);
            }
            static /*void */ ThrowIfNegative$1(/*long*/ value, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, value, paramName);
            }
            static /*void */ ThrowIfNegativeOrZero(/*int*/ value, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, value, paramName);
            }
            static /*void */ ThrowIfGreaterThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan(T, value, other, paramName);
            }
            static /*void */ ThrowIfGreaterThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual(T, value, other, paramName);
            }
            static /*void */ ThrowIfLessThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan(T, value, other, paramName);
            }
            static /*void */ ThrowIfLessThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(T, value, other, paramName);
            }
            static $h = 311528;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"value","p":655361},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"n":"ThrowIfZero","d":311528,"h":4295278824,"f":16777249},{"r":65537,"p":[{"n":"value","p":655361},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"n":"ThrowIfNegative","d":311528,"h":8590246120,"f":16777249},{"r":65537,"p":[{"n":"value","p":917505},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"n":"ThrowIfNegative","o":"@$1","d":311528,"h":12885213416,"f":16777249},{"r":65537,"p":[{"n":"value","p":655361},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"n":"ThrowIfNegativeOrZero","d":311528,"h":17180180712,"f":16777249},{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"other","p":(T) => T.$h},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"g":["T"],"n":"ThrowIfGreaterThan","d":311528,"h":21475148008,"f":16908321},{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"other","p":(T) => T.$h},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"g":["T"],"n":"ThrowIfGreaterThanOrEqual","d":311528,"h":25770115304,"f":16908321},{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"other","p":(T) => T.$h},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"g":["T"],"n":"ThrowIfLessThan","d":311528,"h":30065082600,"f":16908321},{"r":65537,"p":[{"n":"value","p":(T) => T.$h},{"n":"other","p":(T) => T.$h},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"value","t":1310721}]}]}],"g":["T"],"n":"ThrowIfLessThanOrEqual","d":311528,"h":34360049896,"f":16908321}],"h":311528}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentOutOfRangeThrowHelper`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartReader", ($self) => class MultipartReader extends $.$$.System.Object
        {
            /*int*/ static DefaultHeadersCountLimit = 16;
            /*int*/ static DefaultHeadersLengthLimit = 16384;
            /*int*/ static DefaultBufferSize = 4096;
            /*BufferedReadStream*/ _stream = null;
            /*MultipartBoundary*/ _boundary = null;
            /*MultipartReaderStream?*/ _currentStream = null;
            $ctor$2(/*string*/ boundary, /*Stream*/ stream)
            {
                this.$ctor$1(boundary, stream, 4096/*DefaultBufferSize*/);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ boundary, /*Stream*/ stream, /*int*/ bufferSize)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (bufferSize < ((boundary.length + 8) | 0))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("bufferSize", $.$box(bufferSize, $.$$.System.Int32), "Insufficient buffer space, the buffer must be larger than the boundary: " + boundary);
                    }
                    this._stream = new $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream().$ctor$4(stream, bufferSize);
                    boundary = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$4(boundary)));
                    this._boundary = new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartBoundary().$ctor$1(boundary);
                }
                return this;
            }
            /*int*/ HeadersCountLimit = 0;
            /*int*/ HeadersLengthLimit = 0;
            /*long?*/ BodyLengthLimit = null;
            /*Task<MultipartSection?> *//*async*/  ReadNextSectionAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection), $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection, async () => 
                {
                    this._currentStream ??= (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream()
                        const $t1 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream;
                        const $i1 = new $t1();
                        $i1.$ctor$4(this._stream, this._boundary);
                        $i1.LengthLimit = this.HeadersLengthLimit;
                        return $i1;
                    })();
                    await $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync$2(this._currentStream, cancellationToken);
                    if (this._currentStream.FinalBoundaryFound)
                    {
                        await $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync$1(this._stream, this.HeadersLengthLimit, cancellationToken);
                        return null;
                    }
                    /*var*/ let headers = await this.ReadHeadersAsync(cancellationToken);
                    this._boundary.ExpectLeadingCrlf();
                    this._currentStream = (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream()
                        const $t2 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream;
                        const $i2 = new $t2();
                        $i2.$ctor$4(this._stream, this._boundary);
                        $i2.LengthLimit = this.BodyLengthLimit;
                        return $i2;
                    })();
                    /*long?*/ let baseStreamOffset = this._stream.CanSeek ? $.$cast(this._stream.Position, $.$$.System.Nullable$$($.$$.System.Int64)) : null;
                    return (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection()
                        const $t3 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection;
                        const $i3 = new $t3();
                        $i3.Headers = headers;
                        $i3.Body = this._currentStream;
                        $i3.BaseStreamOffset = baseStreamOffset;
                        return $i3;
                    })();
                });
            }
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadHeadersAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    /*int*/ let totalSize = 0;
                    /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                    /*var*/ let line = await this._stream.ReadLineAsync(this.HeadersLengthLimit, cancellationToken);
                    while(!$.$$.System.String.IsNullOrEmpty(line))
                    {
                        if (((this.HeadersLengthLimit - totalSize) | 0) < line.length)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart headers length limit ${this.HeadersLengthLimit} exceeded.`);
                        }
                        totalSize += line.length;
                        /*int*/ let splitIndex = $.$$.System.String.IndexOf$3.call(line, /*:*/ 58);
                        if (splitIndex <= 0)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Invalid header line: ${line}`);
                        }
                        /*var*/ let name = $.$$.System.String.Substring.call(line, 0, splitIndex);
                        /*var*/ let value = $.$$.System.String.Trim.call($.$$.System.String.Substring.call(line, ((splitIndex + 1) | 0), ((((line.length - splitIndex) | 0) - 1) | 0)));
                        accumulator.Append(name, value);
                        if (accumulator.KeyCount > this.HeadersCountLimit)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart headers count limit ${this.HeadersCountLimit} exceeded.`);
                        }
                        line = await this._stream.ReadLineAsync(((this.HeadersLengthLimit - totalSize) | 0), cancellationToken);
                    }
                    return accumulator.GetResults();
                });
            }
            //default member initializer
            constructor()
            {
                super();
                this.HeadersCountLimit = 16;
                this.HeadersLengthLimit = 16384;
                this.BodyLengthLimit = null;
            }
            static $h = 1229032;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":47245869288,"f":50331649},"s":{"r":0,"d":0,"h":51540836584,"f":83886081},"n":"HeadersCountLimit","d":1229032,"h":42950901992,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":64425738472,"f":50331649},"s":{"r":0,"d":0,"h":68720705768,"f":83886081},"n":"HeadersLengthLimit","d":1229032,"h":60130771176,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":81605607656,"f":50331649},"s":{"r":0,"d":0,"h":85900574952,"f":83886081},"n":"BodyLengthLimit","d":1229032,"h":77310640360,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadNextSectionAsync","d":1229032,"h":90195542248,"f":16781313},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"ReadHeadersAsync","d":1229032,"h":94490509544,"f":16781314}],"l":[{"t":655361,"n":"DefaultHeadersCountLimit","d":1229032,"h":4296196328,"f":4194337},{"t":655361,"n":"DefaultHeadersLengthLimit","d":1229032,"h":8591163624,"f":4194337},{"t":655361,"n":"DefaultBufferSize","d":1229032,"h":12886130920,"f":4194338},{"t":442600,"n":"_stream","d":1229032,"h":17181098216,"f":4194306},{"t":1163496,"n":"_boundary","d":1229032,"h":21476065512,"f":4194306},{"t":1294568,"n":"_currentStream","d":1229032,"h":25771032808,"f":4194306}],"c":[{"p":[{"n":"boundary","p":1310721},{"n":"stream","p":62193665}],"n":".ctor","o":"$ctor$2","d":1229032,"h":30066000104,"f":16777217},{"p":[{"n":"boundary","p":1310721},{"n":"stream","p":62193665},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$1","d":1229032,"h":34360967400,"f":16777217}],"h":1229032}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartReader`; }
        });
        
        $asm.$cls("$maw.Resources", ($self) => class Resources
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$maw.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.AspNetCore.WebUtilities", $.$maw.Resources.$type.Assembly);
                    $.$maw.Resources.s_resourceManager = temp;
                }
                return $.$maw.Resources.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$maw.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$maw.Resources.resourceCulture = value;
            }
            static /*string */ get FormPipeReader_KeyOrValueTooLarge()
            {
                return "Form key length limit {0} or value length limit {1} exceeded.";
            }
            static /*string */ FormatFormPipeReader_KeyOrValueTooLarge(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Form key length limit {0} or value length limit {1} exceeded.", arg1, arg2);
            }
            static /*string */ get FormPipeReader_KeyTooLarge()
            {
                return "Form key length limit {0} exceeded.";
            }
            static /*string */ FormatFormPipeReader_KeyTooLarge(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Form key length limit {0} exceeded.", arg1);
            }
            static /*string */ get FormPipeReader_ValueTooLarge()
            {
                return "Form value length limit {0} exceeded.";
            }
            static /*string */ FormatFormPipeReader_ValueTooLarge(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Form value length limit {0} exceeded.", arg1);
            }
            static /*string */ get HttpRequestStreamReader_StreamNotReadable()
            {
                return "The stream must support reading.";
            }
            static /*string */ get HttpResponseStreamWriter_StreamNotWritable()
            {
                return "The stream must support writing.";
            }
            static /*string */ get WebEncoders_InvalidCountOffsetOrLength()
            {
                return "Invalid {0}, {1} or {2} length.";
            }
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Invalid {0}, {1} or {2} length.", arg1, arg2, arg3);
            }
            static $h = 2146536;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":85393409,"g":{"r":0,"d":0,"h":17182015720,"f":50331688},"n":"ResourceManager","d":2146536,"h":12887048424,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":51183617,"g":{"r":0,"d":0,"h":25771950312,"f":50331688},"s":{"r":0,"d":0,"h":30066917608,"f":83886120},"n":"Culture","d":2146536,"h":21476983016,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38656852200,"f":50331688},"n":"FormPipeReader_KeyOrValueTooLarge","d":2146536,"h":34361884904,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":51541754088,"f":50331688},"n":"FormPipeReader_KeyTooLarge","d":2146536,"h":47246786792,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":64426655976,"f":50331688},"n":"FormPipeReader_ValueTooLarge","d":2146536,"h":60131688680,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":77311557864,"f":50331688},"n":"HttpRequestStreamReader_StreamNotReadable","d":2146536,"h":73016590568,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":85901492456,"f":50331688},"n":"HttpResponseStreamWriter_StreamNotWritable","d":2146536,"h":81606525160,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":94491427048,"f":50331688},"n":"WebEncoders_InvalidCountOffsetOrLength","d":2146536,"h":90196459752,"f":2097192}],"m":[{"r":1310721,"p":[{"n":"arg1","p":131073},{"n":"arg2","p":131073}],"n":"FormatFormPipeReader_KeyOrValueTooLarge","d":2146536,"h":42951819496,"f":16777256},{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatFormPipeReader_KeyTooLarge","d":2146536,"h":55836721384,"f":16777256},{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatFormPipeReader_ValueTooLarge","d":2146536,"h":68721623272,"f":16777256},{"r":1310721,"p":[{"n":"arg1","p":131073},{"n":"arg2","p":131073},{"n":"arg3","p":131073}],"n":"FormatWebEncoders_InvalidCountOffsetOrLength","d":2146536,"h":98786394344,"f":16777256}],"l":[{"t":85393409,"n":"s_resourceManager","d":2146536,"h":4297113832,"f":4194338},{"t":51183617,"n":"resourceCulture","d":2146536,"h":8592081128,"f":4194338}],"h":2146536,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Resources.Tools.StronglyTypedResourceBuilder","t":1310721},{"v":"17.0.0.0","t":1310721}]},{"t":37748737,"c":4332716033},{"t":88408065,"c":4383375361}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            static $h = 245992;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":245992,"h":4295213288,"f":16777249},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":2212072,"c":4297179368,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":245992,"h":8590180584,"f":16777249}],"h":245992}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$maw.Microsoft.Extensions.WebEncoders.Sources.EncoderResources", ($self) => class EncoderResources
        {
            /*string*/ static WebEncoders_InvalidCountOffsetOrLength = null;
            /*string*/ static WebEncoders_MalformedInput = null;
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ p0, /*object*/ p1, /*object*/ p2)
            {
                return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*WebEncoders_InvalidCountOffsetOrLength*/, p0, p1, p2);
            }
            static /*string */ FormatWebEncoders_MalformedInput(/*object*/ p0)
            {
                return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*WebEncoders_MalformedInput*/, p0);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.WebEncoders_InvalidCountOffsetOrLength = "Invalid {0}, {1} or {2} length.";
                }
                {
                    this.WebEncoders_MalformedInput = "Malformed input: {0} is an invalid input length.";
                }
            }
            static $h = 2081000;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"p0","p":131073},{"n":"p1","p":131073},{"n":"p2","p":131073}],"n":"FormatWebEncoders_InvalidCountOffsetOrLength","d":2081000,"h":12886982888,"f":16777256},{"r":1310721,"p":[{"n":"p0","p":131073}],"n":"FormatWebEncoders_MalformedInput","d":2081000,"h":17181950184,"f":16777256}],"l":[{"t":1310721,"n":"WebEncoders_InvalidCountOffsetOrLength","d":2081000,"h":4297048296,"f":4194344},{"t":1310721,"n":"WebEncoders_MalformedInput","d":2081000,"h":8592015592,"f":4194344}],"h":2081000}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EncoderResources`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormMultipartSection", ($self) => class FormMultipartSection extends $.$$.System.Object
        {
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                }
                return this;
            }
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    if (header === null || !$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions.IsFormDisposition(header))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Argument must be a form section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name));
                }
                return this;
            }
            /*MultipartSection*/ Section = null;
            /*string*/ Name = null;
            /*Task<string> */ GetValueAsync()
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync$1(this.Section);
            }
            /*ValueTask<string> */ GetValueAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync(this.Section, cancellationToken);
            }
            static $h = 704744;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1360104,"g":{"r":0,"d":0,"h":25770508520,"f":50331649},"n":"Section","d":704744,"h":21475541224,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38655410408,"f":50331649},"n":"Name","d":704744,"h":34360443112,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"n":"GetValueAsync","d":704744,"h":42950377704,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"GetValueAsync","o":"@$1","d":704744,"h":47245345000,"f":16777217}],"l":[{"t":232145,"n":"_contentDispositionHeader","d":704744,"h":4295672040,"f":4194306}],"c":[{"p":[{"n":"section","p":1360104}],"n":".ctor","o":"$ctor$2","d":704744,"h":8590639336,"f":16777217},{"p":[{"n":"section","p":1360104},{"n":"header","p":232145}],"n":".ctor","o":"$ctor$1","d":704744,"h":12885606632,"f":16777217}],"h":704744}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormMultipartSection`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.Base64UrlTextEncoder", ($self) => class Base64UrlTextEncoder
        {
            static /*string */ Encode(/*byte[]*/ data)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$2(data);
            }
            static /*byte[] */ Decode(/*string*/ text)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode$2(text);
            }
            static $h = 377064;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"data","p":$.$typeArray($.$$.System.Byte).$h}],"n":"Encode","d":377064,"h":4295344360,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"text","p":1310721}],"n":"Decode","d":377064,"h":8590311656,"f":16777249}],"h":377064}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Base64UrlTextEncoder`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartBoundary", ($self) => class MultipartBoundary extends $.$$.System.Object
        {
            /*byte[]*/ _boundaryBytes = null;
            /*bool*/ _expectLeadingCrlf = false;
            $ctor$1(/*string*/ boundary)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._expectLeadingCrlf = false;
                    this._boundaryBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8("\r\n--" + boundary);
                    this.FinalBoundaryLength = ((this.BoundaryBytes.Length + 2) | 0);
                }
                return this;
            }
            /*void */ ExpectLeadingCrlf()
            {
                this._expectLeadingCrlf = true;
            }
            /*bool */ BeforeFirstBoundary()
            {
                return !this._expectLeadingCrlf;
            }
            /*ReadOnlySpan<byte> */ get BoundaryBytes()
            {
                return $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._boundaryBytes, this._expectLeadingCrlf ? 0 : 2));
            }
            /*int*/ FinalBoundaryLength = 0;
            static $h = 1163496;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30065934568,"f":50331649},"n":"BoundaryBytes","d":1163496,"h":25770967272,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42950836456,"f":50331649},"s":{"r":0,"d":0,"h":47245803752,"f":83886082},"n":"FinalBoundaryLength","d":1163496,"h":38655869160,"f":2097153}],"m":[{"r":65537,"n":"ExpectLeadingCrlf","d":1163496,"h":17181032680,"f":16777217},{"r":262145,"n":"BeforeFirstBoundary","d":1163496,"h":21475999976,"f":16777217}],"l":[{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_boundaryBytes","d":1163496,"h":4296130792,"f":4194306},{"t":262145,"n":"_expectLeadingCrlf","d":1163496,"h":8591098088,"f":4194306}],"c":[{"p":[{"n":"boundary","p":1310721}],"n":".ctor","o":"$ctor$1","d":1163496,"h":12886065384,"f":16777217}],"h":1163496}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartBoundary`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileMultipartSection", ($self) => class FileMultipartSection extends $.$$.System.Object
        {
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                }
                return this;
            }
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    if (header === null || !$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions.IsFileDisposition(header))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Argument must be a file section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name));
                    this.FileName = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.FileNameStar.HasValue ? this._contentDispositionHeader.FileNameStar : this._contentDispositionHeader.FileName));
                }
                return this;
            }
            /*MultipartSection*/ Section = null;
            /*Stream? */ get FileStream()
            {
                return this.Section.Body;
            }
            /*string*/ Name = null;
            /*string*/ FileName = null;
            static $h = 639208;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1360104,"g":{"r":0,"d":0,"h":25770442984,"f":50331649},"n":"Section","d":639208,"h":21475475688,"f":2097153},{"p":62193665,"g":{"r":0,"d":0,"h":34360377576,"f":50331649},"n":"FileStream","d":639208,"h":30065410280,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47245279464,"f":50331649},"n":"Name","d":639208,"h":42950312168,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":60130181352,"f":50331649},"n":"FileName","d":639208,"h":55835214056,"f":2097153}],"l":[{"t":232145,"n":"_contentDispositionHeader","d":639208,"h":4295606504,"f":4194306}],"c":[{"p":[{"n":"section","p":1360104}],"n":".ctor","o":"$ctor$2","d":639208,"h":8590573800,"f":16777217},{"p":[{"n":"section","p":1360104},{"n":"header","p":232145}],"n":".ctor","o":"$ctor$1","d":639208,"h":12885541096,"f":16777217}],"h":639208}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FileMultipartSection`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions", ($self) => class MultipartSectionConverterExtensions
        {
            static /*FileMultipartSection? */ AsFileSection(/*this MultipartSection*/ section)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.Microsoft.AspNetCore.WebUtilities.FileMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            static /*FormMultipartSection? */ AsFormDataSection(/*this MultipartSection*/ section)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.Microsoft.AspNetCore.WebUtilities.FormMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            static /*ContentDispositionHeaderValue? */ GetContentDispositionHeader(/*this MultipartSection*/ section)
            {
                /*var*/ let header;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryParse($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(section.ContentDisposition), $.$ref(() => header, ($v) => header = $v, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue)))
                {
                    return null;
                }
                return header;
            }
            static $h = 1425640;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":639208,"p":[{"n":"section","p":1360104}],"n":"AsFileSection","d":1425640,"h":4296392936,"f":16777249},{"r":704744,"p":[{"n":"section","p":1360104}],"n":"AsFormDataSection","d":1425640,"h":8591360232,"f":16777249},{"r":232145,"p":[{"n":"section","p":1360104}],"n":"GetContentDispositionHeader","d":1425640,"h":12886327528,"f":16777249}],"h":1425640}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSectionConverterExtensions`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions", ($self) => class MultipartSectionStreamExtensions
        {
            static /*Task<string> */ ReadAsStringAsync$1(/*this MultipartSection*/ section)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync(section, $.$$.System.Threading.CancellationToken.None).AsTask();
            }
            static /*ValueTask<string> *//*async*/  ReadAsStringAsync(/*this MultipartSection*/ section, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                    if (section.Body === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Multipart section must have a body to be read.", "section");
                    }
                    /*var*/ let sectionMediaType;
                    _ = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.TryParse($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(section.ContentType), $.$ref(() => sectionMediaType, ($v) => sectionMediaType = $v, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue));
                    /*var*/ let streamEncoding = (sectionMediaType?.Encoding ?? null);
                    if (streamEncoding === null || streamEncoding.CodePage === 65000)
                    {
                        streamEncoding = $.$$.System.Text.Encoding.UTF8;
                    }
                    /*var*/ let reader = new $.$$.System.IO.StreamReader().$ctor$5(section.Body, null, true, 1024, true);
                    try
                    {
                        return await reader.ReadToEndAsync$1(cancellationToken);
                    }
                    finally
                    {
                        reader?.System$IDisposable$Dispose();
                    }
                });
            }
            static $h = 1491176;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"p":[{"n":"section","p":1360104}],"n":"ReadAsStringAsync","o":"@$1","d":1491176,"h":4296458472,"f":16777249},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String).$h,"p":[{"n":"section","p":1360104},{"n":"cancellationToken","p":125829121}],"n":"ReadAsStringAsync","d":1491176,"h":8591425768,"f":16781345}],"h":1491176}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSectionStreamExtensions`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions", ($self) => class StreamHelperExtensions
        {
            /*int*/ static _maxReadBufferSize = 4096;
            static /*Task */ DrainAsync$2(/*this Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync(stream, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, null, cancellationToken);
            }
            static /*Task */ DrainAsync$1(/*this Stream*/ stream, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                return $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync(stream, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, limit, cancellationToken);
            }
            static /*Task *//*async*/  DrainAsync(/*this Stream*/ stream, /*ArrayPool<byte>*/ bytePool, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    /*var*/ let buffer = bytePool.Rent(4096/*_maxReadBufferSize*/);
                    /*long*/ let total = 0n;
                    try
                    {
                        /*var*/ let read = await stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, buffer), cancellationToken);
                        while(read > 0)
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(limit) && $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(limit) - total < BigInt(read))
                            {
                                throw new $.$$.System.IO.InvalidDataException().$ctor$12(`The stream exceeded the data limit ${$.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(limit)}.`);
                            }
                            total += BigInt(read);
                            read = await stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, buffer), cancellationToken);
                        }
                    }
                    finally
                    {
                        {
                            bytePool.Return(buffer, false);
                        }
                    }
                });
            }
            static $h = 1949928;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125829121}],"n":"DrainAsync","o":"@$2","d":1949928,"h":8591884520,"f":16777249},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"limit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"cancellationToken","p":125829121}],"n":"DrainAsync","o":"@$1","d":1949928,"h":12886851816,"f":16777249},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h},{"n":"limit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"cancellationToken","p":125829121}],"n":"DrainAsync","d":1949928,"h":17181819112,"f":16781345}],"l":[{"t":655361,"n":"_maxReadBufferSize","d":1949928,"h":4296917224,"f":4194338}],"h":1949928}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StreamHelperExtensions`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader", ($self) => class FormPipeReader extends $.$$.System.Object
        {
            /*int*/ static StackAllocThreshold = 128;
            /*int*/ static DefaultValueCountLimit = 1024;
            /*int*/ static DefaultKeyLengthLimit = 2048;
            /*int*/ static DefaultValueLengthLimit = 4194304;
            static /*ReadOnlySpan<byte> */ get UTF8EqualEncoded()
            {
                return this.$cacheUTF8EqualEncoded ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([61]);
            }
            static /*ReadOnlySpan<byte> */ get UTF8AndEncoded()
            {
                return this.$cacheUTF8AndEncoded ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38]);
            }
            /*byte[]?*/ _otherEqualEncoding = null;
            /*byte[]?*/ _otherAndEncoding = null;
            /*PipeReader*/ _pipeReader = null;
            /*Encoding*/ _encoding = null;
            $ctor$2(/*PipeReader*/ pipeReader)
            {
                this.$ctor$1(pipeReader, $.$$.System.Text.Encoding.UTF8);
                {
                }
                return this;
            }
            $ctor$1(/*PipeReader*/ pipeReader, /*Encoding*/ encoding)
            {
                super.$ctor();
                {
                    if (encoding !== null && ($.$is(encoding, $.$$.System.Text.Encoding) && encoding.CodePage === 65000))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("UTF7 is unsupported and insecure. Please select a different encoding.");
                    }
                    this._pipeReader = pipeReader;
                    this._encoding = encoding;
                    if (this._encoding !== $.$$.System.Text.Encoding.UTF8 && this._encoding !== $.$$.System.Text.Encoding.ASCII)
                    {
                        this._otherEqualEncoding = this._encoding.GetBytes$8("=");
                        this._otherAndEncoding = this._encoding.GetBytes$8("&");
                    }
                }
                return this;
            }
            /*int*/ ValueCountLimit = 0;
            /*int*/ KeyLengthLimit = 0;
            /*int*/ ValueLengthLimit = 0;
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    /*KeyValueAccumulator*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator();
                    while(true)
                    {
                        /*var*/ let readResult = await this._pipeReader.ReadAsync(cancellationToken);
                        /*var*/ let buffer = readResult.Buffer;
                        if (!buffer.IsEmpty)
                        {
                            try
                            {
                                this.ParseFormValues($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte), () => buffer, ($v) => buffer = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null), readResult.IsCompleted);
                            }
                            catch($e)
                            {
                                this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                                throw $e;
                            }
                        }
                        if (readResult.IsCompleted)
                        {
                            this._pipeReader.AdvanceTo$1(buffer.End);
                            if (!buffer.IsEmpty)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12("End of body before form was fully parsed.");
                            }
                            break;
                        }
                        this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                    }
                    return accumulator.GetResults();
                });
            }
            /*void */ ParseFormValues(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                if (buffer.$v.IsSingleSegment)
                {
                    /*var*/ let consumed;
                    this.ParseFormValuesFast(buffer.$v.FirstSpan, accumulator, isFinalBlock, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                    buffer.$v = buffer.$v.Slice$4(BigInt(consumed));
                    return;
                }
                this.ParseValuesSlow(buffer, accumulator, isFinalBlock);
            }
            /*void */ ParseFormValuesFast(/*ReadOnlySpan<byte>*/ span, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock, /*out int*/ consumed)
            {
                /*ReadOnlySpan<byte>*/ let key;
                /*ReadOnlySpan<byte>*/ let value;
                consumed.$v = 0;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(span.Length > 0)
                {
                    /*var*/ let ampersand = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, span, andDelimiter);
                    /*ReadOnlySpan<byte>*/ let keyValuePair;
                    /*int*/ let equals;
                    /*var*/ let foundAmpersand = ampersand !== -1;
                    if (foundAmpersand)
                    {
                        keyValuePair = span.Slice(0, ampersand);
                        span = span.Slice$1(((keyValuePair.Length + andDelimiter.Length) | 0));
                        consumed.$v += ((keyValuePair.Length + andDelimiter.Length) | 0);
                    }
                    else 
                    {
                        if (!isFinalBlock)
                        {
                            if ((span.Length >>> 0) > ((((this.KeyLengthLimit >>> 0) + (this.ValueLengthLimit >>> 0)) >>> 0) >>> 0))
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            return;
                        }
                        keyValuePair = span;
                        span = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                        consumed.$v += keyValuePair.Length;
                    }
                    equals = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, keyValuePair, equalsDelimiter);
                    if (equals === -1)
                    {
                        if (keyValuePair.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    }
                    else 
                    {
                        key = keyValuePair.Slice(0, equals);
                        if (key.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$1(((equals + equalsDelimiter.Length) | 0));
                        if (value.Length > this.ValueLengthLimit)
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    /*var*/ let decodedKey = this.GetDecodedString(key);
                    /*var*/ let decodedValue = this.GetDecodedString(value);
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                }
            }
            /*void */ ParseValuesSlow(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                /*var*/ let sequenceReader = new ($.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte))().$ctor$3(buffer.$v);
                /*ReadOnlySequence<byte>*/ let keyValuePair;
                /*var*/ let consumed = sequenceReader.Position;
                /*var*/ let consumedBytes = 0n;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(!sequenceReader.End)
                {
                    if (!sequenceReader.TryReadTo$3($.$ref(() => keyValuePair, ($v) => keyValuePair = $v, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte)), andDelimiter, true))
                    {
                        if (!isFinalBlock)
                        {
                            if ((sequenceReader.Length - consumedBytes) > $.$cast(this.KeyLengthLimit, $.$$.System.Int64) + $.$cast(this.ValueLengthLimit, $.$$.System.Int64) + 2n)
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            break;
                        }
                        keyValuePair = buffer.$v.Slice$8(sequenceReader.Position);
                        sequenceReader.Advance(keyValuePair.Length);
                    }
                    if (keyValuePair.IsSingleSegment)
                    {
                        /*var*/ let segmentConsumed;
                        this.ParseFormValuesFast(keyValuePair.FirstSpan, accumulator, true, $.$ref(() => segmentConsumed, ($v) => segmentConsumed = $v, $.$$.System.Int32));
                        $.$$.System.Diagnostics.Debug.Assert$2(segmentConsumed === keyValuePair.FirstSpan.Length, "segmentConsumed == keyValuePair.FirstSpan.Length");
                        consumedBytes = sequenceReader.Consumed;
                        consumed = sequenceReader.Position;
                        continue;
                    }
                    /*var*/ let keyValueReader = new ($.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte))().$ctor$3(keyValuePair);
                    /*ReadOnlySequence<byte>*/ let value;
                    /*ReadOnlySequence<byte>*/ let key;
                    if (keyValueReader.TryReadTo$3($.$ref(() => key, ($v) => key = $v, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte)), equalsDelimiter, true))
                    {
                        if (key.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$8(keyValueReader.Position);
                        if (value.Length > BigInt(this.ValueLengthLimit))
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    else 
                    {
                        if (keyValuePair.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))();
                    }
                    /*var*/ let decodedKey = this.GetDecodedStringFromReadOnlySequence($.$ref(() => key, ));
                    /*var*/ let decodedValue = this.GetDecodedStringFromReadOnlySequence($.$ref(() => value, ));
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                    consumedBytes = sequenceReader.Consumed;
                    consumed = sequenceReader.Position;
                }
                buffer.$v = buffer.$v.Slice$8(consumed);
            }
            /*void */ ThrowKeyOrValueTooLargeException()
            {
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyOrValueTooLarge, $.$box(this.KeyLengthLimit, $.$$.System.Int32), $.$box(this.ValueLengthLimit, $.$$.System.Int32)));
            }
            /*void */ ThrowKeyTooLargeException()
            {
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyTooLarge, $.$box(this.KeyLengthLimit, $.$$.System.Int32)));
            }
            /*void */ ThrowValueTooLargeException()
            {
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_ValueTooLarge, $.$box(this.ValueLengthLimit, $.$$.System.Int32)));
            }
            /*string */ GetDecodedStringFromReadOnlySequence(/*in ReadOnlySequence<byte>*/ ros)
            {
                if (ros.$v.IsSingleSegment)
                {
                    return this.GetDecodedString(ros.$v.FirstSpan);
                }
                if (ros.$v.Length < BigInt(128/*StackAllocThreshold*/))
                {
                    /*Span<byte>*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 128/*StackAllocThreshold*/, null).Slice(0, $.$cast(ros.$v.Length, $.$$.System.Int32));
                    $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Byte, $.$ref(() => ros, ), buffer);
                    return this.GetDecodedString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer));
                }
                else 
                {
                    /*var*/ let byteArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$cast(ros.$v.Length, $.$$.System.Int32));
                    try
                    {
                        /*Span<byte>*/ let buffer = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, byteArray, 0, $.$cast(ros.$v.Length, $.$$.System.Int32));
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Byte, $.$ref(() => ros, ), buffer);
                        return this.GetDecodedString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer));
                    }
                    finally
                    {
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(byteArray, false);
                        }
                    }
                }
            }
            /*void */ AppendAndVerify(/*ref KeyValueAccumulator*/ accumulator, /*string*/ decodedKey, /*string*/ decodedValue)
            {
                accumulator.$v.Append(decodedKey, decodedValue);
                if (accumulator.$v.ValueCount > this.ValueCountLimit)
                {
                    throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form value count limit ${this.ValueCountLimit} exceeded.`);
                }
            }
            /*string */ GetDecodedString(/*ReadOnlySpan<byte>*/ readOnlySpan)
            {
                if (readOnlySpan.Length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                else if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    /*var*/ let span = $.$$.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, readOnlySpan), readOnlySpan.Length);
                    try
                    {
                        /*var*/ let bytes = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace(span, true);
                        span = span.Slice(0, bytes);
                        return this._encoding.GetString$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit(span));
                    }
                    catch(ex)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$11("The form value contains invalid characters.", ex);
                    }
                }
                else 
                {
                    /*var*/ let decodedString = this._encoding.GetString$3(readOnlySpan);
                    decodedString = $.$$.System.String.Replace.call(decodedString, /*+*/ 43, /* */ 32);
                    return $.$spu.System.Uri.UnescapeDataString$2(decodedString);
                }
            }
            /*ReadOnlySpan<byte> */ GetEqualsForEncoding()
            {
                if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader.UTF8EqualEncoded;
                }
                else 
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(this._otherEqualEncoding);
                }
            }
            /*ReadOnlySpan<byte> */ GetAndForEncoding()
            {
                if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader.UTF8AndEncoded;
                }
                else 
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(this._otherAndEncoding);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.ValueCountLimit = 1024;
                this.KeyLengthLimit = 2048;
                this.ValueLengthLimit = 4194304;
            }
            static $h = 770280;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":25770574056,"f":50331682},"n":"UTF8EqualEncoded","d":770280,"h":21475606760,"f":2097186},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":34360508648,"f":50331682},"n":"UTF8AndEncoded","d":770280,"h":30065541352,"f":2097186},{"p":655361,"g":{"r":0,"d":0,"h":73015214312,"f":50331649},"s":{"r":0,"d":0,"h":77310181608,"f":83886081},"n":"ValueCountLimit","d":770280,"h":68720247016,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":90195083496,"f":50331649},"s":{"r":0,"d":0,"h":94490050792,"f":83886081},"n":"KeyLengthLimit","d":770280,"h":85900116200,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":107374952680,"f":50331649},"s":{"r":0,"d":0,"h":111669919976,"f":83886081},"n":"ValueLengthLimit","d":770280,"h":103079985384,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadFormAsync","d":770280,"h":115964887272,"f":16781313},{"r":65537,"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":4},{"n":"accumulator","p":1097960,"f":4},{"n":"isFinalBlock","p":262145}],"n":"ParseFormValues","d":770280,"h":120259854568,"f":16777224},{"r":65537,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"accumulator","p":1097960,"f":4},{"n":"isFinalBlock","p":262145},{"n":"consumed","p":655361,"f":2}],"n":"ParseFormValuesFast","d":770280,"h":124554821864,"f":16777218},{"r":65537,"p":[{"n":"buffer","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":4},{"n":"accumulator","p":1097960,"f":4},{"n":"isFinalBlock","p":262145}],"n":"ParseValuesSlow","d":770280,"h":128849789160,"f":16777218},{"r":65537,"n":"ThrowKeyOrValueTooLargeException","d":770280,"h":133144756456,"f":16777218},{"r":65537,"n":"ThrowKeyTooLargeException","d":770280,"h":137439723752,"f":16777218},{"r":65537,"n":"ThrowValueTooLargeException","d":770280,"h":141734691048,"f":16777218},{"r":1310721,"p":[{"n":"ros","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":8}],"n":"GetDecodedStringFromReadOnlySequence","d":770280,"h":146029658344,"f":16777218,"a":[{"t":95354881,"c":4390322177}]},{"r":65537,"p":[{"n":"accumulator","p":1097960,"f":4},{"n":"decodedKey","p":1310721},{"n":"decodedValue","p":1310721}],"n":"AppendAndVerify","d":770280,"h":150324625640,"f":16777218},{"r":1310721,"p":[{"n":"readOnlySpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetDecodedString","d":770280,"h":154619592936,"f":16777218},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"n":"GetEqualsForEncoding","d":770280,"h":158914560232,"f":16777218},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"n":"GetAndForEncoding","d":770280,"h":163209527528,"f":16777218}],"l":[{"t":655361,"n":"StackAllocThreshold","d":770280,"h":4295737576,"f":4194338},{"t":655361,"n":"DefaultValueCountLimit","d":770280,"h":8590704872,"f":4194338},{"t":655361,"n":"DefaultKeyLengthLimit","d":770280,"h":12885672168,"f":4194338},{"t":655361,"n":"DefaultValueLengthLimit","d":770280,"h":17180639464,"f":4194338},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_otherEqualEncoding","d":770280,"h":38655475944,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_otherAndEncoding","d":770280,"h":42950443240,"f":4194306},{"t":1413098,"n":"_pipeReader","d":770280,"h":47245410536,"f":4194306},{"t":121700353,"n":"_encoding","d":770280,"h":51540377832,"f":4194306}],"c":[{"p":[{"n":"pipeReader","p":1413098}],"n":".ctor","o":"$ctor$2","d":770280,"h":55835345128,"f":16777217},{"p":[{"n":"pipeReader","p":1413098},{"n":"encoding","p":121700353}],"n":".ctor","o":"$ctor$1","d":770280,"h":60130312424,"f":16777217}],"h":770280}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormPipeReader`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.Internal.UrlDecoder", ($self) => class UrlDecoder extends $.$$.System.Object
        {
            static /*int */ DecodeRequestLine(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*bool*/ isFormEncoding)
            {
                if (destination.Length < source.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Length of the destination byte span is less than the source.", "destination");
                }
                source.CopyTo(destination);
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace(destination.Slice(0, source.Length), isFormEncoding);
            }
            static /*int */ DecodeInPlace(/*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                /*var*/ let sourceIndex = 0;
                /*var*/ let destinationIndex = 0;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer.get_Item(sourceIndex).$v === /*+*/ 43 && isFormEncoding)
                    {
                        buffer.get_Item(sourceIndex).$v = 32;
                    }
                    else if (buffer.get_Item(sourceIndex).$v === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeCore($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.System.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer, isFormEncoding))
                        {
                            $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.Copy($.$$.System.Byte, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer.get_Item(destinationIndex++).$v = buffer.get_Item(sourceIndex++).$v;
                    }
                }
                return destinationIndex;
            }
            static /*bool */ DecodeCore(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                /*var*/ let byte1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding$1(sourceIndex, buffer, isFormEncoding);
                if (byte1 === -1)
                {
                    return false;
                }
                if (byte1 === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (byte1 <= 127)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte1, $.$$.System.Byte);
                    return true;
                }
                /*int*/ let byte2 = 0, byte3 = 0, byte4 = 0;
                /*int*/ let currentDecodeBits;
                /*int*/ let byteCount;
                /*int*/ let expectValueMin;
                if ((byte1 & 224) === 192)
                {
                    currentDecodeBits = byte1 & 31;
                    byteCount = 2;
                    expectValueMin = 128;
                }
                else if ((byte1 & 240) === 224)
                {
                    currentDecodeBits = byte1 & 15;
                    byteCount = 3;
                    expectValueMin = 2048;
                }
                else if ((byte1 & 248) === 240)
                {
                    currentDecodeBits = byte1 & 7;
                    byteCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingBytes = ((byteCount - 1) | 0);
                while(remainingBytes > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextByte = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding$1($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.System.Int32), buffer, isFormEncoding);
                    if (nextByte === -1)
                    {
                        return false;
                    }
                    if ((nextByte & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextByte & 63);
                    remainingBytes--;
                    if (remainingBytes === 1 && currentDecodeBits >= 864 && currentDecodeBits <= 895)
                    {
                        return false;
                    }
                    if (remainingBytes === 2 && currentDecodeBits >= 272)
                    {
                        return false;
                    }
                    sourceIndex.$v = nextSourceIndex;
                    if (((byteCount - remainingBytes) | 0) === 2)
                    {
                        byte2 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 3)
                    {
                        byte3 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 4)
                    {
                        byte4 = nextByte;
                    }
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                if (byteCount > 0)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte1, $.$$.System.Byte);
                }
                if (byteCount > 1)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte2, $.$$.System.Byte);
                }
                if (byteCount > 2)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte3, $.$$.System.Byte);
                }
                if (byteCount > 3)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte4, $.$$.System.Byte);
                }
                return true;
            }
            static /*void */ Copy(T, /*int*/ begin, /*int*/ end, /*ref int*/ writer, /*Span<T>*/ buffer)
            {
                while(begin !== end)
                {
                    buffer.get_Item(writer.$v++).$v = buffer.get_Item(begin++).$v;
                }
            }
            static /*int */ UnescapePercentEncoding$1(/*ref int*/ scan, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                if (buffer.get_Item(scan.$v++).$v !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*var*/ let value1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                if (value1 === -1)
                {
                    return -1;
                }
                /*var*/ let value2 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                if (value2 === -1)
                {
                    return -1;
                }
                if ($.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.SkipUnescape(value1, value2, isFormEncoding))
                {
                    return -1;
                }
                scan.$v = probe;
                return (((value1 << 4) + value2) | 0);
            }
            static /*int */ ReadHex$1(/*ref int*/ scan, /*Span<byte>*/ buffer)
            {
                if (scan.$v === buffer.Length)
                {
                    return -1;
                }
                /*var*/ let value = buffer.get_Item(scan.$v++).$v;
                /*var*/ let isHex = ((value >= /*0*/ 48) && (value <= /*9*/ 57)) || ((value >= /*A*/ 65) && (value <= /*F*/ 70)) || ((value >= /*a*/ 97) && (value <= /*f*/ 102));
                if (!isHex)
                {
                    return -1;
                }
                if (value <= /*9*/ 57)
                {
                    return value - /*0*/ 48;
                }
                else if (value <= /*F*/ 70)
                {
                    return (((value - /*A*/ 65) + 10) | 0);
                }
                else 
                {
                    return (((value - /*a*/ 97) + 10) | 0);
                }
            }
            static /*bool */ SkipUnescape(/*int*/ value1, /*int*/ value2, /*bool*/ isFormEncoding)
            {
                if (isFormEncoding)
                {
                    return false;
                }
                if (value1 === 2 && value2 === 15)
                {
                    return true;
                }
                return false;
            }
            static /*int */ DecodeRequestLine$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination)
            {
                source.CopyTo(destination);
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace$1(destination.Slice(0, source.Length));
            }
            static /*int */ DecodeInPlace$1(/*Span<char>*/ buffer)
            {
                /*int*/ let position = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer), /*%*/ 37);
                if (position === -1)
                {
                    return buffer.Length;
                }
                /*var*/ let sourceIndex = position;
                /*var*/ let destinationIndex = position;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer.get_Item(sourceIndex).$v === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeCore$1($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.System.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer))
                        {
                            $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.Copy($.$$.System.Char, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer.get_Item(destinationIndex++).$v = buffer.get_Item(sourceIndex++).$v;
                    }
                }
                return destinationIndex;
            }
            static /*bool */ DecodeCore$1(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<char>*/ buffer)
            {
                /*var*/ let codeUnit1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding(sourceIndex, $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer));
                if (codeUnit1 === -1)
                {
                    return false;
                }
                if (codeUnit1 === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (codeUnit1 <= 127)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(codeUnit1, $.$$.System.Char);
                    return true;
                }
                /*int*/ let currentDecodeBits;
                /*int*/ let codeUnitCount;
                /*int*/ let expectValueMin;
                if ((codeUnit1 & 224) === 192)
                {
                    currentDecodeBits = codeUnit1 & 31;
                    codeUnitCount = 2;
                    expectValueMin = 128;
                }
                else if ((codeUnit1 & 240) === 224)
                {
                    currentDecodeBits = codeUnit1 & 15;
                    codeUnitCount = 3;
                    expectValueMin = 2048;
                }
                else if ((codeUnit1 & 248) === 240)
                {
                    currentDecodeBits = codeUnit1 & 7;
                    codeUnitCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingCodeUnits = ((codeUnitCount - 1) | 0);
                while(remainingCodeUnits > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextCodeUnit = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.System.Int32), $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer));
                    if (nextCodeUnit === -1)
                    {
                        return false;
                    }
                    if ((nextCodeUnit & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextCodeUnit & 63);
                    remainingCodeUnits--;
                    sourceIndex.$v = nextSourceIndex;
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                /*var*/ let rune;
                /*var*/ let charsWritten;
                if (!$.$$.System.Text.Rune.TryCreate$2(currentDecodeBits, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)) || !rune.TryEncodeToUtf16(buffer.Slice$1(destinationIndex.$v), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                destinationIndex.$v += charsWritten;
                return true;
            }
            static /*int */ UnescapePercentEncoding(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                /*int*/ let tempIdx = scan.$v++;
                if (buffer.get_Item(tempIdx).$v !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*int*/ let firstNibble = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                /*int*/ let secondNibble = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                /*int*/ let value = firstNibble << 4 | secondNibble;
                if (value < 0 || value === /*/*/ 47)
                {
                    return -1;
                }
                scan.$v = probe;
                return value;
            }
            static /*int */ ReadHex(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                /*int*/ let tempIdx = scan.$v++;
                if ((tempIdx >>> 0) >= (buffer.Length >>> 0))
                {
                    return -1;
                }
                /*int*/ let value = buffer.get_Item(tempIdx).$v;
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.FromChar(value);
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >>> 0) >= ($.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.CharToHexLookup.Length >>> 0) ? -1 : $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.CharToHexLookup.get_Item(c).$v;
            }
            static /*ReadOnlySpan<sbyte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= $.$$.System.ReadOnlySpan$$($.$$.System.SByte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.SByte), [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], null, null));
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 180456;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.SByte).$h,"g":{"r":0,"d":0,"h":64424689896,"f":50331682},"n":"CharToHexLookup","d":180456,"h":60129722600,"f":2097186}],"m":[{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isFormEncoding","p":262145}],"n":"DecodeRequestLine","d":180456,"h":4295147752,"f":16777249},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isFormEncoding","p":262145}],"n":"DecodeInPlace","d":180456,"h":8590115048,"f":16777249},{"r":262145,"p":[{"n":"sourceIndex","p":655361,"f":4},{"n":"destinationIndex","p":655361,"f":4},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isFormEncoding","p":262145}],"n":"DecodeCore","d":180456,"h":12885082344,"f":16777250},{"r":65537,"p":[{"n":"begin","p":655361},{"n":"end","p":655361},{"n":"writer","p":655361,"f":4},{"n":"buffer","p":(T) => $.$$.System.Span$$(T).$h}],"g":["T"],"n":"Copy","d":180456,"h":17180049640,"f":16908322},{"r":655361,"p":[{"n":"scan","p":655361,"f":4},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"isFormEncoding","p":262145}],"n":"UnescapePercentEncoding","o":"@$1","d":180456,"h":21475016936,"f":16777250},{"r":655361,"p":[{"n":"scan","p":655361,"f":4},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"ReadHex","o":"@$1","d":180456,"h":25769984232,"f":16777250},{"r":262145,"p":[{"n":"value1","p":655361},{"n":"value2","p":655361},{"n":"isFormEncoding","p":262145}],"n":"SkipUnescape","d":180456,"h":30064951528,"f":16777250},{"r":655361,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"DecodeRequestLine","o":"@$1","d":180456,"h":34359918824,"f":16777249},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"DecodeInPlace","o":"@$1","d":180456,"h":38654886120,"f":16777249},{"r":262145,"p":[{"n":"sourceIndex","p":655361,"f":4},{"n":"destinationIndex","p":655361,"f":4},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"DecodeCore","o":"@$1","d":180456,"h":42949853416,"f":16777250},{"r":655361,"p":[{"n":"scan","p":655361,"f":4},{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"UnescapePercentEncoding","d":180456,"h":47244820712,"f":16777250},{"r":655361,"p":[{"n":"scan","p":655361,"f":4},{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"ReadHex","d":180456,"h":51539788008,"f":16777250},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":180456,"h":55834755304,"f":16777250}],"c":[{"n":".ctor","o":"$ctor$1","d":180456,"h":68719657192,"f":16777217}],"h":180456}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `UrlDecoder`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection", ($self) => class MultipartSection extends $.$$.System.Object
        {
            /*string? */ get ContentType()
            {
                /*var*/ let values;
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.Microsoft.Net.Http.Headers.HeaderNames.ContentType, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit(values);
                }
                return null;
            }
            /*string? */ get ContentDisposition()
            {
                /*var*/ let values;
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.Microsoft.Net.Http.Headers.HeaderNames.ContentDisposition, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit(values);
                }
                return null;
            }
            /*Dictionary<string, StringValues>?*/ Headers = null;
            /*Stream*/ Body = null;
            /*long?*/ BaseStreamOffset = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Body = null;
                this.BaseStreamOffset = null;
            }
            static $h = 1360104;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8591294696,"f":50331649},"n":"ContentType","d":1360104,"h":4296327400,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":17181229288,"f":50331649},"n":"ContentDisposition","d":1360104,"h":12886261992,"f":2097153},{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"g":{"r":0,"d":0,"h":30066131176,"f":50331649},"s":{"r":0,"d":0,"h":34361098472,"f":83886081},"n":"Headers","d":1360104,"h":25771163880,"f":2097153},{"p":62193665,"g":{"r":0,"d":0,"h":47246000360,"f":50331649},"s":{"r":0,"d":0,"h":51540967656,"f":83886081},"n":"Body","d":1360104,"h":42951033064,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":64425869544,"f":50331649},"s":{"r":0,"d":0,"h":68720836840,"f":83886081},"n":"BaseStreamOffset","d":1360104,"h":60130902248,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":1360104,"h":73015804136,"f":16777217}],"h":1360104}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSection`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.ReasonPhrases", ($self) => class ReasonPhrases
        {
            /*string[][]*/ static HttpReasonPhrases = null;
            static /*string */ GetReasonPhrase(/*int*/ statusCode)
            {
                if (((((statusCode - 100) | 0)) >>> 0) < 500)
                {
                    /*var*/ let  [ i, j ] = $.$destructure($.$$.System.Math.DivRem$9((statusCode >>> 0), 100));
                    /*string[]*/ let phrases = $.$$.System.Array.$ReadT1.call($.$maw.Microsoft.AspNetCore.WebUtilities.ReasonPhrases.HttpReasonPhrases, i);
                    if (j < (phrases.length >>> 0))
                    {
                        return $.$$.System.Array.$ReadT1.call(phrases, j);
                    }
                }
                return $.$$.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.HttpReasonPhrases = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeArray($.$$.System.String).$type, [ $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [  ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Continue", "Switching Protocols", "Processing" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "OK", "Created", "Accepted", "Non-Authoritative Information", "No Content", "Reset Content", "Partial Content", "Multi-Status", "Already Reported", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "IM Used" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Multiple Choices", "Moved Permanently", "Found", "See Other", "Not Modified", "Use Proxy", "Switch Proxy", "Temporary Redirect", "Permanent Redirect" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Bad Request", "Unauthorized", "Payment Required", "Forbidden", "Not Found", "Method Not Allowed", "Not Acceptable", "Proxy Authentication Required", "Request Timeout", "Conflict", "Gone", "Length Required", "Precondition Failed", "Payload Too Large", "URI Too Long", "Unsupported Media Type", "Range Not Satisfiable", "Expectation Failed", "I'm a teapot", "Authentication Timeout", $.$$.System.String.Empty, "Misdirected Request", "Unprocessable Entity", "Locked", "Failed Dependency", $.$$.System.String.Empty, "Upgrade Required", $.$$.System.String.Empty, "Precondition Required", "Too Many Requests", $.$$.System.String.Empty, "Request Header Fields Too Large", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "Unavailable For Legal Reasons", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "Client Closed Request" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Internal Server Error", "Not Implemented", "Bad Gateway", "Service Unavailable", "Gateway Timeout", "HTTP Version Not Supported", "Variant Also Negotiates", "Insufficient Storage", "Loop Detected", $.$$.System.String.Empty, "Not Extended", "Network Authentication Required" ], null, null) ], null, null);
                }
            }
            static $h = 1884392;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"statusCode","p":655361}],"n":"GetReasonPhrase","d":1884392,"h":8591818984,"f":16777249}],"l":[{"t":$.$typeArray($.$typeArray($.$$.System.String)).$h,"n":"HttpReasonPhrases","d":1884392,"h":4296851688,"f":4194338}],"h":1884392}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ReasonPhrases`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders", ($self) => class WebEncoders
        {
            /*SearchValues<char>*/ static s_base64vsBase64UrlDifferentiators = null;
            static /*byte[] */ Base64UrlDecode$2(/*string*/ input)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode$1(input, 0, input.length);
            }
            static /*byte[] */ Base64UrlDecode$1(/*string*/ input, /*int*/ offset, /*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                if (count === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.System.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, inputSpan, $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*-*/ 45) || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*_*/ 95))
                {
                    return $.$$.System.Buffers.Text.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.System.Convert.FromBase64String(input);
                }
                /*var*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [$.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetArraySizeRequiredToDecode(count)], null);
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode(input, offset, buffer, 0, count);
            }
            static /*byte[] */ Base64UrlDecode(/*string*/ input, /*int*/ offset, /*char[]*/ buffer, /*int*/ bufferOffset, /*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(buffer, "buffer");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(bufferOffset, "bufferOffset");
                if (count === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.System.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, inputSpan, $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*-*/ 45) || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*_*/ 95))
                {
                    return $.$$.System.Buffers.Text.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.System.Convert.FromBase64String(input);
                }
                /*var*/ let paddingCharsToAdd = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                /*var*/ let arraySizeRequired = $.$checked(count + paddingCharsToAdd, 1);
                $.$$.System.Diagnostics.Debug.Assert$2(arraySizeRequired % 4 === 0, "Invariant: Array length must be a multiple of 4.");
                if (((buffer.length - bufferOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "bufferOffset", "input"), "count");
                }
                /*var*/ let i = bufferOffset;
                /*Span<char>*/ let bufferSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, buffer, i, count);
                inputSpan.CopyTo(bufferSpan);
                $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, bufferSpan, /*-*/ 45, /*+*/ 43);
                $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, bufferSpan, /*_*/ 95, /*/*/ 47);
                i += count;
                for(; paddingCharsToAdd > 0; i++, paddingCharsToAdd--)
                {
                    $.$$.System.Array.$WriteT1.call(buffer, /*=*/ 61, i);
                }
                return $.$$.System.Convert.FromBase64CharArray(buffer, bufferOffset, arraySizeRequired);
            }
            static /*int */ GetArraySizeRequiredToDecode(/*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (count === 0)
                {
                    return 0;
                }
                /*var*/ let numPaddingCharsToAdd = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                return $.$checked(count + numPaddingCharsToAdd, 1);
            }
            static /*string */ Base64UrlEncode$2(/*byte[]*/ input)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$1(input, 0, input.length);
            }
            static /*string */ Base64UrlEncode$1(/*byte[]*/ input, /*int*/ offset, /*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$4($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, input, offset, count)));
            }
            static /*int */ Base64UrlEncode(/*byte[]*/ input, /*int*/ offset, /*char[]*/ output, /*int*/ outputOffset, /*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(output, "output");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(outputOffset, "outputOffset");
                /*var*/ let arraySizeRequired = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetArraySizeRequiredToEncode(count);
                if (((output.length - outputOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "outputOffset", "output"), "count");
                }
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, input, offset, count)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, output, outputOffset));
            }
            static /*int */ GetArraySizeRequiredToEncode(/*int*/ count)
            {
                /*var*/ let numWholeOrPartialInputBlocks = $.trunc($.$checked(count + 2, 1) / 3);
                return $.$checked(numWholeOrPartialInputBlocks * 4, 1);
            }
            static /*string */ Base64UrlEncode$4(/*ReadOnlySpan<byte>*/ input)
            {
                return $.$$.System.Buffers.Text.Base64Url.EncodeToString(input);
            }
            static /*int */ Base64UrlEncode$3(/*ReadOnlySpan<byte>*/ input, /*Span<char>*/ output)
            {
                return $.$$.System.Buffers.Text.Base64Url.EncodeToChars$1(input, output);
            }
            static /*int */ GetNumBase64PaddingCharsToAddForDecode(/*int*/ inputLength)
            {
                let $switch1 = inputLength % 4;
                switch($switch1)
                {
                    case 0:
                    return 0;
                    case 2:
                    return 2;
                    case 3:
                    return 1;
                    default:
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*EncoderResources.WebEncoders_MalformedInput*/, $.$box(inputLength, $.$$.System.Int32)));
                }
            }
            static /*void */ ValidateParameters(/*int*/ bufferLength, /*string*/ inputName, /*int*/ offset, /*int*/ count)
            {
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(offset, "offset");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (((bufferLength - offset) | 0) < count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "offset", inputName), "count");
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_base64vsBase64UrlDifferentiators = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("+/-_"));
                }
            }
            static $h = 2015464;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"input","p":1310721}],"n":"Base64UrlDecode","o":"@$2","d":2015464,"h":8591950056,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"input","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Base64UrlDecode","o":"@$1","d":2015464,"h":12886917352,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"input","p":1310721},{"n":"offset","p":655361},{"n":"buffer","p":$.$typeArray($.$$.System.Char).$h},{"n":"bufferOffset","p":655361},{"n":"count","p":655361}],"n":"Base64UrlDecode","d":2015464,"h":17181884648,"f":16777249},{"r":655361,"p":[{"n":"count","p":655361}],"n":"GetArraySizeRequiredToDecode","d":2015464,"h":21476851944,"f":16777249},{"r":1310721,"p":[{"n":"input","p":$.$typeArray($.$$.System.Byte).$h}],"n":"Base64UrlEncode","o":"@$2","d":2015464,"h":25771819240,"f":16777249},{"r":1310721,"p":[{"n":"input","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Base64UrlEncode","o":"@$1","d":2015464,"h":30066786536,"f":16777249},{"r":655361,"p":[{"n":"input","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"output","p":$.$typeArray($.$$.System.Char).$h},{"n":"outputOffset","p":655361},{"n":"count","p":655361}],"n":"Base64UrlEncode","d":2015464,"h":34361753832,"f":16777249},{"r":655361,"p":[{"n":"count","p":655361}],"n":"GetArraySizeRequiredToEncode","d":2015464,"h":38656721128,"f":16777249},{"r":1310721,"p":[{"n":"input","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Base64UrlEncode","o":"@$4","d":2015464,"h":42951688424,"f":16777249,"a":[{"t":95354881,"c":4390322177}]},{"r":655361,"p":[{"n":"input","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"output","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"Base64UrlEncode","o":"@$3","d":2015464,"h":47246655720,"f":16777249},{"r":655361,"p":[{"n":"inputLength","p":655361}],"n":"GetNumBase64PaddingCharsToAddForDecode","d":2015464,"h":51541623016,"f":16777250},{"r":65537,"p":[{"n":"bufferLength","p":655361},{"n":"inputName","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ValidateParameters","d":2015464,"h":55836590312,"f":16777250}],"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_base64vsBase64UrlDifferentiators","d":2015464,"h":4296982760,"f":4194338}],"h":2015464}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEncoders`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers", ($self) => class QueryHelpers
        {
            static /*string */ AddQueryString$3(/*string*/ uri, /*string*/ name, /*string*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)), [new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(name, value)], null, null));
            }
            static /*string */ AddQueryString(/*string*/ uri, /*IDictionary<string, string?>*/ queryString)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, queryString);
            }
            static /*string */ AddQueryString$2(/*string*/ uri, /*IEnumerable<KeyValuePair<string, StringValues>>*/ queryString)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, $.$sl.System.Linq.Enumerable.SelectMany($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.String, $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String), queryString, new ($.$$.System.Func$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String)))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return kvp.Value;
                }, {"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"p":[{"n":"kvp","p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h}],"n":"","d":1622248,"h":0,"f":17825794}), new ($.$$.System.Func$$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.String, $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)))().$ctor(this,  (/*kvp*/ kvp, /*v*/ v) =>
                {
                    return $.$$.System.Collections.Generic.KeyValuePair.Create($.$$.System.String, $.$$.System.String, kvp.Key, v);
                }, {"r":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String).$h,"p":[{"n":"kvp","p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h},{"n":"v","p":1310721}],"n":"","d":1622248,"h":0,"f":17825794})));
            }
            static /*string */ AddQueryString$1(/*string*/ uri, /*IEnumerable<KeyValuePair<string, string?>>*/ queryString)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                /*var*/ let anchorIndex = $.$$.System.String.IndexOf$3.call(uri, /*#*/ 35);
                /*var*/ let uriToBeAppended = $.$$.System.MemoryExtensions.AsSpan$4(uri);
                /*var*/ let anchorText = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                if (anchorIndex !== -1)
                {
                    anchorText = uriToBeAppended.Slice$1(anchorIndex);
                    uriToBeAppended = uriToBeAppended.Slice(0, anchorIndex);
                }
                /*var*/ let queryIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, uriToBeAppended, /*?*/ 63);
                /*var*/ let hasQuery = queryIndex !== -1;
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(uriToBeAppended);
                var $en2 = queryString.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var parameter = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.op_Equality(parameter.Value, null))
                        {
                            continue;
                        }
                        sb.Append$3(hasQuery ? /*&*/ 38 : /*?*/ 63);
                        sb.Append$19($.$stew.System.Text.Encodings.Web.UrlEncoder.Default.Encode$4(parameter.Key));
                        sb.Append$3(/*=*/ 61);
                        sb.Append$19($.$stew.System.Text.Encodings.Web.UrlEncoder.Default.Encode$4(parameter.Value));
                        hasQuery = true;
                    }
                }
                sb.Append$15(anchorText);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*Dictionary<string, StringValues> */ ParseQuery(/*string?*/ queryString)
            {
                /*var*/ let result = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseNullableQuery(queryString);
                if (result === null)
                {
                    return new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$1();
                }
                return result;
            }
            static /*Dictionary<string, StringValues>? */ ParseNullableQuery(/*string?*/ queryString)
            {
                /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                /*var*/ let enumerable = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable().$ctor$4(queryString);
                var $en2 = enumerable.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var pair = $en2.Current;
                    {
                        accumulator.Append($.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(pair.DecodeName()), $.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(pair.DecodeValue()));
                    }
                }
                if (!accumulator.HasValues)
                {
                    return null;
                }
                return accumulator.GetResults();
            }
            static $h = 1622248;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"uri","p":1310721},{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"AddQueryString","o":"@$3","d":1622248,"h":4296589544,"f":16777249},{"r":1310721,"p":[{"n":"uri","p":1310721},{"n":"queryString","p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h}],"n":"AddQueryString","d":1622248,"h":8591556840,"f":16777249},{"r":1310721,"p":[{"n":"uri","p":1310721},{"n":"queryString","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h}],"n":"AddQueryString","o":"@$2","d":1622248,"h":12886524136,"f":16777249},{"r":1310721,"p":[{"n":"uri","p":1310721},{"n":"queryString","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h}],"n":"AddQueryString","o":"@$1","d":1622248,"h":17181491432,"f":16777249},{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"p":[{"n":"queryString","p":1310721}],"n":"ParseQuery","d":1622248,"h":21476458728,"f":16777249},{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"p":[{"n":"queryString","p":1310721}],"n":"ParseNullableQuery","d":1622248,"h":25771426024,"f":16777249}],"h":1622248}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `QueryHelpers`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory", ($self) => class AspNetCoreTempDirectory
        {
            /*string?*/ static _tempDirectory = null;
            static /*string */ get TempDirectory()
            {
                if ($.$$.System.String.op_Equality($.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory, null))
                {
                    /*var*/ let temp = $.$$.System.Environment.GetEnvironmentVariable$1("ASPNETCORE_TEMP") ?? $.$$.System.IO.Path.GetTempPath();
                    if (!$.$$.System.IO.Directory.Exists(temp))
                    {
                        throw new $.$$.System.IO.DirectoryNotFoundException().$ctor$17(temp);
                    }
                    $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory = temp;
                }
                return $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory;
            }
            static /*Func<string> */ get TempDirectoryFactory()
            {
                return new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectory;
                }, {"r":1310721,"n":"","d":114920,"h":0,"f":17825794});
            }
            static $h = 114920;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885016808,"f":50331681},"n":"TempDirectory","d":114920,"h":8590049512,"f":2097185},{"p":$.$$.System.Func$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":21474951400,"f":50331681},"n":"TempDirectoryFactory","d":114920,"h":17179984104,"f":2097185}],"l":[{"t":1310721,"n":"_tempDirectory","d":114920,"h":4295082216,"f":4194338}],"h":114920}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AspNetCoreTempDirectory`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormReader", ($self) => class FormReader extends $.$$.System.Object
        {
            /*int*/ static DefaultValueCountLimit = 1024;
            /*int*/ static DefaultKeyLengthLimit = 2048;
            /*int*/ static DefaultValueLengthLimit = 4194304;
            /*int*/ static _rentedCharPoolLength = 8192;
            /*TextReader*/ _reader = null;
            /*char[]*/ _buffer = null;
            /*ArrayPool<char>*/ _charPool = null;
            /*StringBuilder*/ _builder = null;
            /*int*/ _bufferOffset = 0;
            /*int*/ _bufferCount = 0;
            /*string?*/ _currentKey = null;
            /*string?*/ _currentValue = null;
            /*bool*/ _endOfStream = false;
            /*bool*/ _disposed = false;
            $ctor$5(/*string*/ data)
            {
                this.$ctor$4(data, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ data, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(data, "data");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.System.IO.StringReader().$ctor$3(data);
                }
                return this;
            }
            $ctor$3(/*Stream*/ stream)
            {
                this.$ctor$1(stream, $.$$.System.Text.Encoding.UTF8, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$2(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$1(stream, encoding, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$1(/*Stream*/ stream, /*Encoding*/ encoding, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.System.IO.StreamReader().$ctor$5(stream, null, true, ((1024 * 2) | 0), true);
                }
                return this;
            }
            /*int*/ ValueCountLimit = 0;
            /*int*/ KeyLengthLimit = 0;
            /*int*/ ValueLengthLimit = 0;
            /*KeyValuePair<string, string>? */ ReadNextPair()
            {
                this.ReadNextPairImpl();
                if (this.ReadSucceeded())
                {
                    return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(this._currentKey, this._currentValue);
                }
                return null;
            }
            /*void */ ReadNextPairImpl()
            {
                this.StartReadNextPair();
                while(!this._endOfStream)
                {
                    if (this._bufferCount === 0)
                    {
                        this.Buffer();
                    }
                    if (this.TryReadNextPair())
                    {
                        break;
                    }
                }
            }
            /*Task<KeyValuePair<string, string>?> *//*async*/  ReadNextPairAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Nullable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))), $.$typeNullable($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)), async () => 
                {
                    await this.ReadNextPairAsyncImpl(cancellationToken);
                    if (this.ReadSucceeded())
                    {
                        return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(this._currentKey, this._currentValue);
                    }
                    return null;
                });
            }
            /*Task *//*async*/  ReadNextPairAsyncImpl(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.StartReadNextPair();
                    while(!this._endOfStream)
                    {
                        if (this._bufferCount === 0)
                        {
                            await this.BufferAsync(cancellationToken);
                        }
                        if (this.TryReadNextPair())
                        {
                            break;
                        }
                    }
                });
            }
            /*void */ StartReadNextPair()
            {
                this._currentKey = null;
                this._currentValue = null;
            }
            /*bool */ TryReadNextPair()
            {
                if ($.$$.System.String.op_Equality(this._currentKey, null))
                {
                    if (!this.TryReadWord(/*=*/ 61, this.KeyLengthLimit, $.$ref(() => this._currentKey, ($v) => this._currentKey = $v, $.$$.System.String)))
                    {
                        return false;
                    }
                    if (this._bufferCount === 0)
                    {
                        return false;
                    }
                }
                if ($.$$.System.String.op_Equality(this._currentValue, null))
                {
                    if (!this.TryReadWord(/*&*/ 38, this.ValueLengthLimit, $.$ref(() => this._currentValue, ($v) => this._currentValue = $v, $.$$.System.String)))
                    {
                        return false;
                    }
                }
                return true;
            }
            /*bool */ TryReadWord(/*char*/ separator, /*int*/ limit, /*out string?*/ value)
            {
                do
                {
                    if (this.ReadChar(separator, limit, value))
                    {
                        return true;
                    }
                }
                while(this._bufferCount > 0);
                return false;
            }
            /*bool */ ReadChar(/*char*/ separator, /*int*/ limit, /*out string?*/ word)
            {
                if (this._bufferCount === 0)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                /*var*/ let c = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset++);
                this._bufferCount--;
                if (c === separator)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                if (this._builder.Length >= limit)
                {
                    throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form key or value length limit ${limit} exceeded.`);
                }
                this._builder.Append$3(c);
                word.$v = null;
                return false;
            }
            /*string */ BuildWord()
            {
                this._builder.Replace$1(/*+*/ 43, /* */ 32);
                /*var*/ let result = $.$$.System.Text.StringBuilder.ToString.call(this._builder);
                this._builder.Clear();
                return $.$spu.System.Uri.UnescapeDataString$2(result);
            }
            /*void */ Buffer()
            {
                this._bufferOffset = 0;
                this._bufferCount = this._reader.Read$1(this._buffer, 0, this._buffer.length);
                this._endOfStream = this._bufferCount === 0;
            }
            /*Task *//*async*/  BufferAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    this._bufferOffset = 0;
                    this._bufferCount = await this._reader.ReadAsync(this._buffer, 0, this._buffer.length);
                    this._endOfStream = this._bufferCount === 0;
                });
            }
            /*Dictionary<string, StringValues> */ ReadForm()
            {
                /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                while(!this._endOfStream)
                {
                    this.ReadNextPairImpl();
                    this.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null));
                }
                return accumulator.GetResults();
            }
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                    while(!this._endOfStream)
                    {
                        await this.ReadNextPairAsyncImpl(cancellationToken);
                        this.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null));
                    }
                    return accumulator.GetResults();
                });
            }
            /*bool */ ReadSucceeded()
            {
                return $.$$.System.String.op_Inequality(this._currentKey, null) && $.$$.System.String.op_Inequality(this._currentValue, null);
            }
            /*void */ Append(/*ref KeyValueAccumulator*/ accumulator)
            {
                if (this.ReadSucceeded())
                {
                    accumulator.$v.Append(this._currentKey, this._currentValue);
                    if (accumulator.$v.ValueCount > this.ValueCountLimit)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form value count limit ${this.ValueCountLimit} exceeded.`);
                    }
                }
            }
            /*void */ Dispose()
            {
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._charPool.Return(this._buffer, false);
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._builder = new $.$$.System.Text.StringBuilder().$ctor$1();
                this.ValueCountLimit = 1024;
                this.KeyLengthLimit = 2048;
                this.ValueLengthLimit = 4194304;
            }
            static $h = 835816;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":94490116328,"f":50331649},"s":{"r":0,"d":0,"h":98785083624,"f":83886081},"n":"ValueCountLimit","d":835816,"h":90195149032,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":111669985512,"f":50331649},"s":{"r":0,"d":0,"h":115964952808,"f":83886081},"n":"KeyLengthLimit","d":835816,"h":107375018216,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":128849854696,"f":50331649},"s":{"r":0,"d":0,"h":133144821992,"f":83886081},"n":"ValueLengthLimit","d":835816,"h":124554887400,"f":2097153}],"m":[{"r":$.$typeNullable($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,"n":"ReadNextPair","d":835816,"h":137439789288,"f":16777217},{"r":65537,"n":"ReadNextPairImpl","d":835816,"h":141734756584,"f":16777218},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Nullable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadNextPairAsync","d":835816,"h":146029723880,"f":16781313},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadNextPairAsyncImpl","d":835816,"h":150324691176,"f":16781314},{"r":65537,"n":"StartReadNextPair","d":835816,"h":154619658472,"f":16777218},{"r":262145,"n":"TryReadNextPair","d":835816,"h":158914625768,"f":16777218},{"r":262145,"p":[{"n":"separator","p":458753},{"n":"limit","p":655361},{"n":"value","p":1310721,"f":2}],"n":"TryReadWord","d":835816,"h":163209593064,"f":16777218},{"r":262145,"p":[{"n":"separator","p":458753},{"n":"limit","p":655361},{"n":"word","p":1310721,"f":2}],"n":"ReadChar","d":835816,"h":167504560360,"f":16777218},{"r":1310721,"n":"BuildWord","d":835816,"h":171799527656,"f":16777218},{"r":65537,"n":"Buffer","d":835816,"h":176094494952,"f":16777218},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"BufferAsync","d":835816,"h":180389462248,"f":16781314},{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"n":"ReadForm","d":835816,"h":184684429544,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadFormAsync","d":835816,"h":188979396840,"f":16781313},{"r":262145,"n":"ReadSucceeded","d":835816,"h":193274364136,"f":16777218},{"r":65537,"p":[{"n":"accumulator","p":1097960,"f":4}],"n":"Append","d":835816,"h":197569331432,"f":16777218},{"r":65537,"n":"Dispose","d":835816,"h":201864298728,"f":16777217}],"l":[{"t":655361,"n":"DefaultValueCountLimit","d":835816,"h":4295803112,"f":4194337},{"t":655361,"n":"DefaultKeyLengthLimit","d":835816,"h":8590770408,"f":4194337},{"t":655361,"n":"DefaultValueLengthLimit","d":835816,"h":12885737704,"f":4194337},{"t":655361,"n":"_rentedCharPoolLength","d":835816,"h":17180705000,"f":4194338},{"t":62914561,"n":"_reader","d":835816,"h":21475672296,"f":4194306},{"t":$.$typeArray($.$$.System.Char).$h,"n":"_buffer","d":835816,"h":25770639592,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,"n":"_charPool","d":835816,"h":30065606888,"f":4194306},{"t":122814465,"n":"_builder","d":835816,"h":34360574184,"f":4194306},{"t":655361,"n":"_bufferOffset","d":835816,"h":38655541480,"f":4194306},{"t":655361,"n":"_bufferCount","d":835816,"h":42950508776,"f":4194306},{"t":1310721,"n":"_currentKey","d":835816,"h":47245476072,"f":4194306},{"t":1310721,"n":"_currentValue","d":835816,"h":51540443368,"f":4194306},{"t":262145,"n":"_endOfStream","d":835816,"h":55835410664,"f":4194306},{"t":262145,"n":"_disposed","d":835816,"h":60130377960,"f":4194306}],"c":[{"p":[{"n":"data","p":1310721}],"n":".ctor","o":"$ctor$5","d":835816,"h":64425345256,"f":16777217},{"p":[{"n":"data","p":1310721},{"n":"charPool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":835816,"h":68720312552,"f":16777217},{"p":[{"n":"stream","p":62193665}],"n":".ctor","o":"$ctor$3","d":835816,"h":73015279848,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353}],"n":".ctor","o":"$ctor$2","d":835816,"h":77310247144,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353},{"n":"charPool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$1","d":835816,"h":81605214440,"f":16777217}],"i":[57540609],"h":835816}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `FormReader`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.PagedByteBuffer", ($self) => class PagedByteBuffer extends $.$$.System.Object
        {
            /*int*/ static PageSize = 1024;
            /*ArrayPool<byte>*/ _arrayPool = null;
            /*byte[]?*/ _currentPage = null;
            /*int*/ _currentPageIndex = 0;
            $ctor$1(/*ArrayPool<byte>*/ arrayPool)
            {
                super.$ctor();
                {
                    this._arrayPool = arrayPool;
                    this.Pages = new ($.$$.System.Collections.Generic.List$$($.$typeArray($.$$.System.Byte)))().$ctor$1();
                }
                return this;
            }
            /*int*/ Length = 0;
            /*bool*/ Disposed = false;
            /*List<byte[]>*/ Pages = null;
            /*byte[] */ get CurrentPage()
            {
                if (this._currentPage === null || this._currentPageIndex === this._currentPage.length)
                {
                    this._currentPage = this._arrayPool.Rent(1024/*PageSize*/);
                    this.Pages.Add(this._currentPage);
                    this._currentPageIndex = 0;
                }
                return this._currentPage;
            }
            /*void */ Add(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.Add$1($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count)));
            }
            /*void */ Add$1(/*ReadOnlyMemory<byte>*/ memory)
            {
                this.ThrowIfDisposed();
                while(!memory.IsEmpty)
                {
                    /*var*/ let currentPage = this.CurrentPage;
                    /*var*/ let copyLength = $.$$.System.Math.Min$4(memory.Length, ((currentPage.length - this._currentPageIndex) | 0));
                    memory.Slice(0, copyLength).CopyTo($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, currentPage, this._currentPageIndex, copyLength));
                    this.Length += copyLength;
                    this._currentPageIndex += copyLength;
                    memory = memory.Slice$1(copyLength);
                }
            }
            /*void */ MoveTo(/*Stream*/ stream)
            {
                this.ThrowIfDisposed();
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    /*var*/ let page = this.Pages.get_Item(i);
                    /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                    stream.Write(page, 0, length);
                }
                this.ClearBuffers();
            }
            /*Task *//*async*/  MoveToAsync$1(/*PipeWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        await writer.WriteAsync($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, page, 0, length)), cancellationToken);
                    }
                    this.ClearBuffers();
                });
            }
            /*Task *//*async*/  MoveToAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        await stream.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, page, 0, length)), cancellationToken);
                    }
                    this.ClearBuffers();
                });
            }
            /*void */ Dispose()
            {
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.ClearBuffers();
                }
            }
            /*void */ ClearBuffers()
            {
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    this._arrayPool.Return(this.Pages.get_Item(i), false);
                }
                this.Pages.Clear();
                this._currentPage = null;
                this.Length = 0;
                this._currentPageIndex = 0;
            }
            /*void */ ThrowIfDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Disposed = false;
            }
            static $h = 1556712;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34361295080,"f":50331649},"s":{"r":0,"d":0,"h":38656262376,"f":83886082},"n":"Length","d":1556712,"h":30066327784,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51541164264,"f":50331656},"s":{"r":0,"d":0,"h":55836131560,"f":83886082},"n":"Disposed","d":1556712,"h":47246196968,"f":2097160},{"p":$.$$.System.Collections.Generic.List$$($.$typeArray($.$$.System.Byte)).$h,"g":{"r":0,"d":0,"h":68721033448,"f":50331656},"n":"Pages","d":1556712,"h":64426066152,"f":2097160},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":77310968040,"f":50331650},"n":"CurrentPage","d":1556712,"h":73016000744,"f":2097154}],"m":[{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Add","d":1556712,"h":81605935336,"f":16777217},{"r":65537,"p":[{"n":"memory","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h}],"n":"Add","o":"@$1","d":1556712,"h":85900902632,"f":16777217},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"MoveTo","d":1556712,"h":90195869928,"f":16777217},{"r":133169153,"p":[{"n":"writer","p":1609706},{"n":"cancellationToken","p":125829121}],"n":"MoveToAsync","o":"@$1","d":1556712,"h":94490837224,"f":16781313},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"cancellationToken","p":125829121}],"n":"MoveToAsync","d":1556712,"h":98785804520,"f":16781313},{"r":65537,"n":"Dispose","d":1556712,"h":103080771816,"f":16777217},{"r":65537,"n":"ClearBuffers","d":1556712,"h":107375739112,"f":16777218},{"r":65537,"n":"ThrowIfDisposed","d":1556712,"h":111670706408,"f":16777218}],"l":[{"t":655361,"n":"PageSize","d":1556712,"h":4296524008,"f":4194344},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_arrayPool","d":1556712,"h":8591491304,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_currentPage","d":1556712,"h":12886458600,"f":4194306},{"t":655361,"n":"_currentPageIndex","d":1556712,"h":17181425896,"f":4194306}],"c":[{"p":[{"n":"arrayPool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$1","d":1556712,"h":21476393192,"f":16777217}],"i":[57540609],"h":1556712}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `PagedByteBuffer`; }
        });
        
        $asm.$str("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable", ($self) => class QueryStringEnumerable extends $.$$.System.ValueType
        {
            /*ReadOnlyMemory<char>*/  get _queryString() { return this.$getField(0, 12); }
            /*ReadOnlyMemory<char>*/  set _queryString(value) { this.$setField(0, 12, value); }
            $ctor$4(/*string?*/ queryString)
            {
                this.$ctor$3($.$$.System.MemoryExtensions.AsMemory$4(queryString));
                {
                }
                return this;
            }
            $ctor$3(/*ReadOnlyMemory<char>*/ queryString)
            {
                super.$ctor$1();
                {
                    this._queryString = queryString;
                }
                return this;
            }
            /*Enumerator */ GetEnumerator()
            {
                return new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.Enumerator().$ctor$3(this._queryString);
            }
            static $_EncodedNameValuePair;
            static get EncodedNameValuePair()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable;
                return $cls.$_EncodedNameValuePair ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair", ($self) => class EncodedNameValuePair extends $.$$.System.ValueType
                {
                    /*ReadOnlyMemory<char>*/ EncodedName;
                    /*ReadOnlyMemory<char>*/ EncodedValue;
                    $ctor$3(/*ReadOnlyMemory<char>*/ encodedName, /*ReadOnlyMemory<char>*/ encodedValue)
                    {
                        super.$ctor$1();
                        {
                            this.EncodedName = encodedName;
                            this.EncodedValue = encodedValue;
                        }
                        return this;
                    }
                    /*ReadOnlyMemory<char> */ DecodeName()
                    {
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedName);
                    }
                    /*ReadOnlyMemory<char> */ DecodeValue()
                    {
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedValue);
                    }
                    static /*ReadOnlyMemory<char> */ Decode(/*ReadOnlyMemory<char>*/ chars)
                    {
                        /*ReadOnlySpan<char>*/ let source = chars.Span;
                        if (!$.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, source, /*%*/ 37, /*+*/ 43))
                        {
                            return chars;
                        }
                        /*var*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [source.Length], null);
                        $.$$.System.MemoryExtensions.Replace$1($.$$.System.Char, source, $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(buffer), /*+*/ 43, /* */ 32);
                        /*var*/ let unescapedLength;
                        /*var*/ let success = $.$spu.System.Uri.TryUnescapeDataString($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1(buffer), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(buffer), $.$ref(() => unescapedLength, ($v) => unescapedLength = $v, $.$$.System.Int32));
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        return $.$$.System.Memory$$($.$$.System.Char).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Char, buffer, 0, unescapedLength));
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.EncodedName = this.EncodedName.Clone();
                        copy.EncodedValue = this.EncodedValue.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.EncodedName = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                        this.EncodedValue = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                    }
                    static $h = 1753320;
                    static $z = 24;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"g":{"r":0,"d":0,"h":12886655208,"f":50331649},"n":"EncodedName","d":1753320,"h":8591687912,"f":2097153},{"p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"g":{"r":0,"d":0,"h":25771557096,"f":50331649},"n":"EncodedValue","d":1753320,"h":21476589800,"f":2097153}],"m":[{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"n":"DecodeName","d":1753320,"h":34361491688,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"n":"DecodeValue","d":1753320,"h":38656458984,"f":16777217},{"r":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"p":[{"n":"chars","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":"Decode","d":1753320,"h":42951426280,"f":16777250}],"c":[{"p":[{"n":"encodedName","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h},{"n":"encodedValue","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":1753320,"h":30066524392,"f":16777224},{"n":".ctor","o":"$ctor$2","d":1753320,"h":47246393576,"f":16777217}],"d":1687784,"h":1753320}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `QueryStringEnumerable.EncodedNameValuePair`; }
                }, $cls, ($v) => $cls.$_EncodedNameValuePair = $v);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable;
                return $cls.$_Enumerator ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*ReadOnlyMemory<char>*/  get _query() { return this.$getField(0, 12); }
                    /*ReadOnlyMemory<char>*/  set _query(value) { this.$setField(0, 12, value); }
                    $ctor$3(/*ReadOnlyMemory<char>*/ query)
                    {
                        super.$ctor$1();
                        {
                            this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair();
                            this._query = query.IsEmpty || query.Span.get_Item(0).$v !== /*?*/ 63 ? query : query.Slice$1(1);
                        }
                        return this;
                    }
                    /*EncodedNameValuePair*/ Current;
                    /*bool */ MoveNext()
                    {
                        while(!this._query.IsEmpty)
                        {
                            /*ReadOnlyMemory<char>*/ let segment;
                            /*var*/ let delimiterIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, this._query.Span, /*&*/ 38);
                            if (delimiterIndex >= 0)
                            {
                                segment = this._query.Slice(0, delimiterIndex);
                                this._query = this._query.Slice$1(((delimiterIndex + 1) | 0));
                            }
                            else 
                            {
                                segment = this._query;
                                this._query = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Char))();
                            }
                            /*var*/ let equalIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, segment.Span, /*=*/ 61);
                            if (equalIndex >= 0)
                            {
                                this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment.Slice(0, equalIndex), segment.Slice$1(((equalIndex + 1) | 0)));
                                return true;
                            }
                            else if (!segment.IsEmpty)
                            {
                                this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment, new ($.$$.System.ReadOnlyMemory$$($.$$.System.Char))());
                                return true;
                            }
                        }
                        this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair();
                        return false;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._query = this._query.Clone();
                        copy.Current = this.Current.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._query = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                        this.Current = $.$default($.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair);
                    }
                    static $h = 1818856;
                    static $z = 36;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1753320,"g":{"r":0,"d":0,"h":21476655336,"f":50331649},"s":{"r":0,"d":0,"h":25771622632,"f":83886082},"n":"Current","d":1818856,"h":17181688040,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":1818856,"h":30066589928,"f":16777217}],"l":[{"t":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"n":"_query","d":1818856,"h":4296786152,"f":4194306}],"c":[{"p":[{"n":"query","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":1818856,"h":8591753448,"f":16777224},{"n":".ctor","o":"$ctor$2","d":1818856,"h":34361557224,"f":16777217}],"d":1687784,"h":1818856}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `QueryStringEnumerable.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._queryString = this._queryString.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._queryString = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
            }
            static $h = 1687784;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":1818856,"n":"GetEnumerator","d":1687784,"h":17181556968,"f":16777217}],"l":[{"t":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,"n":"_queryString","d":1687784,"h":4296655080,"f":4194306}],"c":[{"p":[{"n":"queryString","p":1310721}],"n":".ctor","o":"$ctor$4","d":1687784,"h":8591622376,"f":16777217},{"p":[{"n":"queryString","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":1687784,"h":12886589672,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1687784,"h":30066458856,"f":16777217}],"j":[1753320,1818856],"h":1687784}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `QueryStringEnumerable`; }
        });
        
        $asm.$cls("$maw.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 2212072;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182081256,"f":50331649},"n":"ParameterName","d":2212072,"h":12887113960,"f":2097153}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":2212072,"h":4297179368,"f":16777217}],"h":2212072,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2048,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        
        $asm.$str("$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator", ($self) => class KeyValueAccumulator extends $.$$.System.ValueType
        {
            /*Dictionary<string, StringValues>*/  get _accumulator() { return this.$getField(0, 4); }
            /*Dictionary<string, StringValues>*/  set _accumulator(value) { this.$setField(0, 4, value); }
            /*Dictionary<string, List<string>>*/  get _expandingAccumulator() { return this.$getField(4, 4); }
            /*Dictionary<string, List<string>>*/  set _expandingAccumulator(value) { this.$setField(4, 4, value); }
            /*void */ Append(/*string*/ key, /*string*/ value)
            {
                if (this._accumulator === null)
                {
                    this._accumulator = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                /*StringValues*/ let values;
                if (this._accumulator.TryGetValue(key, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    if (values.Count === 0)
                    {
                        this._expandingAccumulator.get_Item(key).Add(value);
                    }
                    else if (values.Count === 1)
                    {
                        this._accumulator.set_Item(key, $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [values.get_Item(0), value], [-1], null)));
                    }
                    else 
                    {
                        this._accumulator.set_Item(key, $.$default($.$mep.Microsoft.Extensions.Primitives.StringValues));
                        if (this._expandingAccumulator === null)
                        {
                            this._expandingAccumulator = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                        }
                        /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3(8);
                        /*var*/ let array = values.ToArray();
                        list.Add($.$$.System.Array.$ReadT1.call(array, 0));
                        list.Add($.$$.System.Array.$ReadT1.call(array, 1));
                        list.Add(value);
                        this._expandingAccumulator.set_Item(key, list);
                    }
                }
                else 
                {
                    this._accumulator.set_Item(key, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(value));
                }
                this.ValueCount++;
            }
            /*bool */ get HasValues()
            {
                return this.ValueCount > 0;
            }
            /*int */ get KeyCount()
            {
                return (this._accumulator?.Count ?? null) ?? 0;
            }
            /*int*/ ValueCount = 0;
            /*Dictionary<string, StringValues> */ GetResults()
            {
                if (this._expandingAccumulator !== null)
                {
                    var $en3 = this._expandingAccumulator.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            this._accumulator.set_Item(entry.Key, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$4(entry.Value.ToArray()));
                        }
                    }
                }
                return this._accumulator ?? new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$7(0, $.$$.System.StringComparer.OrdinalIgnoreCase);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._accumulator = this._accumulator;
                copy._expandingAccumulator = this._expandingAccumulator;
                copy.ValueCount = this.ValueCount;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._accumulator = null;
                this._expandingAccumulator = null;
            }
            static $h = 1097960;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475934440,"f":50331649},"n":"HasValues","d":1097960,"h":17180967144,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065869032,"f":50331649},"n":"KeyCount","d":1097960,"h":25770901736,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":42950770920,"f":50331649},"s":{"r":0,"d":0,"h":47245738216,"f":83886082},"n":"ValueCount","d":1097960,"h":38655803624,"f":2097153}],"m":[{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Append","d":1097960,"h":12885999848,"f":16777217},{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"n":"GetResults","d":1097960,"h":51540705512,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,"n":"_accumulator","d":1097960,"h":4296065256,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$h,"n":"_expandingAccumulator","d":1097960,"h":8591032552,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1097960,"h":55835672808,"f":16777217}],"h":1097960}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `KeyValueAccumulator`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader", ($self) => class HttpRequestStreamReader extends $.$$.System.IO.TextReader
        {
            /*int*/ static DefaultBufferSize = 1024;
            /*Stream*/ _stream = null;
            /*Encoding*/ _encoding = null;
            /*Decoder*/ _decoder = null;
            /*ArrayPool<byte>*/ _bytePool = null;
            /*ArrayPool<char>*/ _charPool = null;
            /*int*/ _byteBufferSize = 0;
            /*byte[]*/ _byteBuffer = null;
            /*char[]*/ _charBuffer = null;
            /*int*/ _charBufferIndex = 0;
            /*int*/ _charsRead = 0;
            /*int*/ _bytesRead = 0;
            /*bool*/ _isBlocked = false;
            /*bool*/ _disposed = false;
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$3(stream, encoding, 1024/*DefaultBufferSize*/, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$3(stream, encoding, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$3(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("stream") });
                    this._encoding = $.$firstOf(encoding, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, bufferSize, "bufferSize");
                    if (!stream.CanRead)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$maw.Resources.HttpRequestStreamReader_StreamNotReadable, "stream");
                    }
                    this._byteBufferSize = bufferSize;
                    this._decoder = encoding.GetDecoder();
                    this._byteBuffer = this._bytePool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxCharCount(bufferSize);
                        this._charBuffer = this._charPool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        this._bytePool.Return(this._byteBuffer, false);
                        if (this._charBuffer !== null)
                        {
                            this._charPool.Return(this._charBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._byteBuffer, false);
                    this._charPool.Return(this._charBuffer, false);
                }
                super.Dispose$1(disposing);
            }
            /*int */ Peek()
            {
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this._isBlocked || this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex);
            }
            /*int */ Read()
            {
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex++);
            }
            /*int */ Read$1(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let span = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(buffer, index, count);
                return this.Read$2(span);
            }
            /*int */ Read$2(/*Span<char>*/ buffer)
            {
                this.ThrowIfDisposed();
                /*var*/ let count = buffer.Length;
                /*var*/ let charsRead = 0;
                while(count > 0)
                {
                    /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                    if (charsRemaining === 0)
                    {
                        charsRemaining = this.ReadIntoBuffer();
                    }
                    if (charsRemaining === 0)
                    {
                        break;
                    }
                    if (charsRemaining > count)
                    {
                        charsRemaining = count;
                    }
                    /*var*/ let source = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferIndex, charsRemaining);
                    source.CopyTo(buffer);
                    this._charBufferIndex += charsRemaining;
                    charsRead += charsRemaining;
                    count -= charsRemaining;
                    buffer = buffer.Slice(charsRemaining, count);
                    if (this._isBlocked)
                    {
                        break;
                    }
                }
                return charsRead;
            }
            /*Task<int> */ ReadAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let memory = new ($.$$.System.Memory$$($.$$.System.Char))().$ctor$5(buffer, index, count);
                return this.ReadAsync$1(memory, new $.$$.System.Threading.CancellationToken()).AsTask();
            }
            /*ValueTask<int> *//*async*/  ReadAsync$1(/*Memory<char>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    this.ThrowIfDisposed();
                    if (this._charBufferIndex === this._charsRead && await this.ReadIntoBufferAsync() === 0)
                    {
                        return 0;
                    }
                    /*var*/ let count = buffer.Length;
                    /*var*/ let charsRead = 0;
                    while(count > 0)
                    {
                        /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                        if (charsRemaining === 0)
                        {
                            this._charsRead = 0;
                            this._charBufferIndex = 0;
                            this._bytesRead = 0;
                            do
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining === 0, "charsRemaining == 0");
                                this._bytesRead = await this._stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, this._byteBufferSize), cancellationToken);
                                if (this._bytesRead === 0)
                                {
                                    this._isBlocked = true;
                                    break;
                                }
                                this._isBlocked = (this._bytesRead < this._byteBufferSize);
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining === 0, "charsRemaining == 0");
                                this._charBufferIndex = 0;
                                charsRemaining = this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, 0);
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining > 0, "charsRemaining > 0");
                                this._charsRead += charsRemaining;
                            }
                            while(charsRemaining === 0);
                            if (charsRemaining === 0)
                            {
                                break;
                            }
                        }
                        if (charsRemaining > count)
                        {
                            charsRemaining = count;
                        }
                        /*var*/ let source = new ($.$$.System.Memory$$($.$$.System.Char))().$ctor$5(this._charBuffer, this._charBufferIndex, charsRemaining);
                        source.CopyTo(buffer);
                        this._charBufferIndex += charsRemaining;
                        charsRead += charsRemaining;
                        count -= charsRemaining;
                        buffer = buffer.Slice(charsRemaining, count);
                        if (this._isBlocked)
                        {
                            break;
                        }
                    }
                    return charsRead;
                });
            }
            /*Task<string?> *//*async*/  ReadLineAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    this.ThrowIfDisposed();
                    /*StringBuilder?*/ let sb = null;
                    /*var*/ let consumeLineFeed = false;
                    while(true)
                    {
                        if (this._charBufferIndex === this._charsRead)
                        {
                            if (await this.ReadIntoBufferAsync() === 0)
                            {
                                const $t1 = sb;
                                return $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                            }
                        }
                        /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.System.Text.StringBuilder), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null));
                        if (stepResult.Completed)
                        {
                            const $t3 = sb;
                            return stepResult.Result ?? $.$ifnn($t3, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                        }
                        continue;
                    }
                });
            }
            /*string? */ ReadLine()
            {
                this.ThrowIfDisposed();
                /*StringBuilder?*/ let sb = null;
                /*var*/ let consumeLineFeed = false;
                while(true)
                {
                    if (this._charBufferIndex === this._charsRead)
                    {
                        if (this.ReadIntoBuffer() === 0)
                        {
                            const $t1 = sb;
                            return $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                        }
                    }
                    /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.System.Text.StringBuilder), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null));
                    if (stepResult.Completed)
                    {
                        const $t3 = sb;
                        return stepResult.Result ?? $.$ifnn($t3, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                    }
                }
            }
            /*ReadLineStepResult */ ReadLineStep(/*ref StringBuilder?*/ sb, /*ref bool*/ consumeLineFeed)
            {
                /*char*/ let carriageReturn = /*\r*/ 13;
                /*char*/ let lineFeed = /*\n*/ 10;
                if (consumeLineFeed.$v)
                {
                    if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                    {
                        this._charBufferIndex++;
                    }
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                }
                /*var*/ let span = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferIndex, ((this._charsRead - this._charBufferIndex) | 0));
                /*var*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(span), carriageReturn, lineFeed);
                if (index !== -1)
                {
                    if (span.get_Item(index).$v === carriageReturn)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (this._charBufferIndex < this._charsRead)
                        {
                            if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                            {
                                this._charBufferIndex++;
                            }
                            if (sb.$v !== null)
                            {
                                sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                                return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                            }
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.FromResult($.$$.System.Span$$($.$$.System.Char).ToString.call(span));
                        }
                        sb.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                        sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                        consumeLineFeed.$v = true;
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Continue;
                    }
                    if (span.get_Item(index).$v === lineFeed)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (sb.$v !== null)
                        {
                            sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                        }
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.FromResult($.$$.System.Span$$($.$$.System.Char).ToString.call(span));
                    }
                }
                sb.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                this._charBufferIndex = this._charsRead;
                return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Continue;
            }
            /*int */ ReadIntoBuffer()
            {
                this._charsRead = 0;
                this._charBufferIndex = 0;
                this._bytesRead = 0;
                do
                {
                    this._bytesRead = this._stream.Read(this._byteBuffer, 0, this._byteBufferSize);
                    if (this._bytesRead === 0)
                    {
                        return this._charsRead;
                    }
                    this._isBlocked = (this._bytesRead < this._byteBufferSize);
                    this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                }
                while(this._charsRead === 0);
                return this._charsRead;
            }
            /*Task<int> *//*async*/  ReadIntoBufferAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    this._charsRead = 0;
                    this._charBufferIndex = 0;
                    this._bytesRead = 0;
                    do
                    {
                        this._bytesRead = await this._stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, this._byteBufferSize), new $.$$.System.Threading.CancellationToken()).ConfigureAwait(false);
                        if (this._bytesRead === 0)
                        {
                            return this._charsRead;
                        }
                        this._isBlocked = (this._bytesRead < this._byteBufferSize);
                        this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                    }
                    while(this._charsRead === 0);
                    return this._charsRead;
                });
            }
            /*Task<string> *//*async*/  ReadToEndAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$4(((this._charsRead - this._charBufferIndex) | 0));
                    do
                    {
                        /*int*/ let tmpCharPos = this._charBufferIndex;
                        sb.Append$4(this._charBuffer, tmpCharPos, ((this._charsRead - tmpCharPos) | 0));
                        this._charBufferIndex = this._charsRead;
                        await this.ReadIntoBufferAsync().ConfigureAwait$2(false);
                    }
                    while(this._charsRead > 0);
                    return $.$$.System.Text.StringBuilder.ToString.call(sb);
                });
            }
            static $_ReadLineStepResult;
            static get ReadLineStepResult()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader;
                return $cls.$_ReadLineStepResult ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult", ($self) => class ReadLineStepResult extends $.$$.System.ValueType
                {
                    /*ReadLineStepResult*/ static Done;
                    /*ReadLineStepResult*/ static Continue;
                    static /*ReadLineStepResult */ FromResult(/*string*/ value)
                    {
                        return new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, value);
                    }
                    $ctor$3(/*bool*/ completed, /*string?*/ result)
                    {
                        super.$ctor$1();
                        {
                            this.Completed = completed;
                            this.Result = result;
                        }
                        return this;
                    }
                    /*bool*/ Completed = false;
                    /*string?*/ Result = null;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Completed = this.Completed;
                        copy.Result = this.Result;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Completed = false;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Done = new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, null);
                        }
                        {
                            this.Continue = new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(false, null);
                        }
                    }
                    static $h = 966888;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065737960,"f":50331649},"n":"Completed","d":966888,"h":25770770664,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950639848,"f":50331649},"n":"Result","d":966888,"h":38655672552,"f":2097153}],"m":[{"r":966888,"p":[{"n":"value","p":1310721}],"n":"FromResult","d":966888,"h":12885868776,"f":16777249}],"l":[{"t":966888,"n":"Done","d":966888,"h":4295934184,"f":4194337},{"t":966888,"n":"Continue","d":966888,"h":8590901480,"f":4194337}],"c":[{"p":[{"n":"completed","p":262145},{"n":"result","p":1310721}],"n":".ctor","o":"$ctor$3","d":966888,"h":17180836072,"f":16777218},{"n":".ctor","o":"$ctor$2","d":966888,"h":47245607144,"f":16777217}],"d":901352,"h":966888}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `HttpRequestStreamReader.ReadLineStepResult`; }
                }, $cls, ($v) => $cls.$_ReadLineStepResult = $v);
            }
            /*void */ ThrowIfDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            static $h = 901352;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62914561,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":901352,"h":77310312680,"f":16809988},{"r":655361,"n":"Peek","d":901352,"h":81605279976,"f":16809985},{"r":655361,"n":"Read","d":901352,"h":85900247272,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Read","o":"@$1","d":901352,"h":90195214568,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"Read","o":"@$2","d":901352,"h":94490181864,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ReadAsync","d":901352,"h":98785149160,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Char).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$1","d":901352,"h":103080116456,"f":16814081},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"n":"ReadLineAsync","d":901352,"h":107375083752,"f":16814081},{"r":1310721,"n":"ReadLine","d":901352,"h":111670051048,"f":16809985},{"r":966888,"p":[{"n":"sb","p":122814465,"f":4},{"n":"consumeLineFeed","p":262145,"f":4}],"n":"ReadLineStep","d":901352,"h":115965018344,"f":16777218},{"r":655361,"n":"ReadIntoBuffer","d":901352,"h":120259985640,"f":16777218},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"n":"ReadIntoBufferAsync","d":901352,"h":124554952936,"f":16781314},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"n":"ReadToEndAsync","d":901352,"h":128849920232,"f":16814081},{"r":65537,"n":"ThrowIfDisposed","d":901352,"h":137439854824,"f":16777218}],"l":[{"t":655361,"n":"DefaultBufferSize","d":901352,"h":4295868648,"f":4194338},{"t":62193665,"n":"_stream","d":901352,"h":8590835944,"f":4194306},{"t":121700353,"n":"_encoding","d":901352,"h":12885803240,"f":4194306},{"t":120389633,"n":"_decoder","d":901352,"h":17180770536,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_bytePool","d":901352,"h":21475737832,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,"n":"_charPool","d":901352,"h":25770705128,"f":4194306},{"t":655361,"n":"_byteBufferSize","d":901352,"h":30065672424,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_byteBuffer","d":901352,"h":34360639720,"f":4194306},{"t":$.$typeArray($.$$.System.Char).$h,"n":"_charBuffer","d":901352,"h":38655607016,"f":4194306},{"t":655361,"n":"_charBufferIndex","d":901352,"h":42950574312,"f":4194306},{"t":655361,"n":"_charsRead","d":901352,"h":47245541608,"f":4194306},{"t":655361,"n":"_bytesRead","d":901352,"h":51540508904,"f":4194306},{"t":262145,"n":"_isBlocked","d":901352,"h":55835476200,"f":4194306},{"t":262145,"n":"_disposed","d":901352,"h":60130443496,"f":4194306}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353}],"n":".ctor","o":"$ctor$5","d":901352,"h":64425410792,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":901352,"h":68720378088,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353},{"n":"bufferSize","p":655361},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h},{"n":"charPool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$3","d":901352,"h":73015345384,"f":16777217}],"i":[57540609],"j":[966888],"h":901352}; }
            static get $b() { return $.$$.System.IO.TextReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `HttpRequestStreamReader`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream", ($self) => class MultipartReaderStream extends $.$$.System.IO.Stream
        {
            /*MultipartBoundary*/ _boundary = null;
            /*BufferedReadStream*/ _innerStream = null;
            /*ArrayPool<byte>*/ _bytePool = null;
            /*long*/ _innerOffset = 0n;
            /*long*/ _position = 0n;
            /*long*/ _observedLength = 0n;
            /*bool*/ _finished = false;
            $ctor$4(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary)
            {
                this.$ctor$3(stream, boundary, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                }
                return this;
            }
            $ctor$3(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._bytePool = bytePool;
                    this._innerStream = stream;
                    this._innerOffset = this._innerStream.CanSeek ? this._innerStream.Position : 0n;
                    this._boundary = boundary;
                }
                return this;
            }
            /*bool*/ FinalBoundaryFound = false;
            /*long?*/ LengthLimit = null;
            /*bool */ get CanRead()
            {
                return true;
            }
            /*bool */ get CanSeek()
            {
                return this._innerStream.CanSeek;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                return this._observedLength;
            }
            /*long */ get Position()
            {
                return this._position;
            }
            /*long */ set Position(value)
            {
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The Position must be positive.");
                }
                if (value > this._observedLength)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The Position must be less than length.");
                }
                this._position = value;
                if (this._position < this._observedLength)
                {
                    this._finished = false;
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = this.Position + offset;
                }
                else 
                {
                    this.Position = this.Length + offset;
                }
                return this.Position;
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ PositionInnerStream()
            {
                if (this._innerStream.CanSeek && this._innerStream.Position !== (this._innerOffset + this._position))
                {
                    this._innerStream.Position = this._innerOffset + this._position;
                }
            }
            /*int */ UpdatePosition(/*int*/ read)
            {
                this._position += BigInt(read);
                if (this._observedLength < this._position)
                {
                    this._observedLength = this._position;
                    let lengthLimit;
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this.LengthLimit) && (lengthLimit = $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.LengthLimit)) && this._observedLength > lengthLimit)
                    {
                        if (this._boundary.BeforeFirstBoundary())
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart header length limit ${lengthLimit} exceeded. Too much data before the first boundary.`);
                        }
                        else 
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart body length limit ${lengthLimit} exceeded.`);
                        }
                    }
                }
                return read;
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                if (this._finished)
                {
                    return 0;
                }
                this.PositionInnerStream();
                if (!this._innerStream.EnsureBuffered$1(this._boundary.FinalBoundaryLength))
                {
                    throw new $.$$.System.IO.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                }
                /*var*/ let bufferedData = this._innerStream.BufferedData;
                /*var*/ let index = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$9($.$$.System.Byte, bufferedData)), this._boundary.BoundaryBytes);
                if (index >= 0)
                {
                    if (index !== 0)
                    {
                        /*var*/ let slice = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, buffer, offset, $.$$.System.Math.Min$4(count, index));
                        /*var*/ let readAmount = this._innerStream.Read$1(slice);
                        return this.UpdatePosition(readAmount);
                    }
                    else 
                    {
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        return ReadBoundary(this, length);
                    }
                }
                /*int*/ let read;
                /*var*/ let matchOffset;
                /*var*/ let matchCount;
                if ($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.System.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.System.Int32)))
                {
                    if (matchOffset > bufferedData.Offset)
                    {
                        read = this._innerStream.Read(buffer, offset, $.$$.System.Math.Min$4(count, ((matchOffset - bufferedData.Offset) | 0)));
                        return this.UpdatePosition(read);
                    }
                    /*var*/ let length = this._boundary.BoundaryBytes.Length;
                    $.$$.System.Diagnostics.Debug.Assert$2(matchCount === length, "matchCount == length");
                    return ReadBoundary(this, length);
                }
                read = this._innerStream.Read(buffer, offset, $.$$.System.Math.Min$4(count, bufferedData.Count));
                return this.UpdatePosition(read);
                /*static int*/  function ReadBoundary(/*MultipartReaderStream*/ stream, /*int*/ length)
                {
                    /*var*/ let boundary = stream._bytePool.Rent(length);
                    /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                    stream._bytePool.Return(boundary, false);
                    $.$$.System.Diagnostics.Debug.Assert$2(read === length, "read == length");
                    /*var*/ let remainder = $.$$.System.MemoryExtensions.AsSpan$4(stream._innerStream.ReadLine(100));
                    remainder = $.$$.System.MemoryExtensions.Trim$4(remainder);
                    if ($.$$.System.MemoryExtensions.Equals$2(remainder, $.$$.System.String.op_Implicit("--"), 4/*StringComparison.Ordinal*/))
                    {
                        stream.FinalBoundaryFound = true;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(stream.FinalBoundaryFound || remainder.IsEmpty, "Un-expected data found on the boundary line: " + $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(remainder));
                    stream._finished = true;
                    return 0;
                }
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    if (this._finished)
                    {
                        return 0;
                    }
                    this.PositionInnerStream();
                    if (!await this._innerStream.EnsureBufferedAsync(this._boundary.FinalBoundaryLength, cancellationToken))
                    {
                        throw new $.$$.System.IO.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                    }
                    /*var*/ let bufferedData = this._innerStream.BufferedData;
                    /*var*/ let index = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$9($.$$.System.Byte, bufferedData)), this._boundary.BoundaryBytes);
                    if (index >= 0)
                    {
                        if (index !== 0)
                        {
                            let $t1 = buffer;
                            /*var*/ let slice = $t1.Slice(0, $.$$.System.Math.Min$4(buffer.Length, index));
                            /*var*/ let readAmount = this._innerStream.Read$1(slice.Span);
                            return this.UpdatePosition(readAmount);
                        }
                        else 
                        {
                            /*var*/ let length = this._boundary.BoundaryBytes.Length;
                            return await ReadBoundaryAsync(this, length, cancellationToken);
                        }
                    }
                    /*int*/ let matchOffset;
                    /*int*/ let matchCount;
                    /*int*/ let read;
                    if ($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.System.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.System.Int32)))
                    {
                        if (matchOffset > bufferedData.Offset)
                        {
                            let $t3 = buffer;
                            /*var*/ let slice = $t3.Slice(0, $.$$.System.Math.Min$4(buffer.Length, ((matchOffset - bufferedData.Offset) | 0)));
                            read = this._innerStream.Read$1(slice.Span);
                            return this.UpdatePosition(read);
                        }
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        $.$$.System.Diagnostics.Debug.Assert$2(matchCount === length, "matchCount == length");
                        return await ReadBoundaryAsync(this, length, cancellationToken);
                    }
                    let $t3 = buffer.Span;
                    read = this._innerStream.Read$1($t3.Slice(0, $.$$.System.Math.Min$4(buffer.Length, bufferedData.Count)));
                    return this.UpdatePosition(read);
                    /*static Task<int>*/ /*async*/  function ReadBoundaryAsync(/*MultipartReaderStream*/ stream, /*int*/ length, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                        {
                            /*var*/ let boundary = stream._bytePool.Rent(length);
                            /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                            stream._bytePool.Return(boundary, false);
                            $.$$.System.Diagnostics.Debug.Assert$2(read === length, "read == length");
                            /*var*/ let remainder = await stream._innerStream.ReadLineAsync(100, cancellationToken);
                            remainder = $.$$.System.String.Trim.call(remainder);
                            if ($.$$.System.String.Equals$2("--", remainder, 4/*StringComparison.Ordinal*/))
                            {
                                stream.FinalBoundaryFound = true;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(stream.FinalBoundaryFound || $.$$.System.String.Equals$2($.$$.System.String.Empty, remainder, 4/*StringComparison.Ordinal*/), "Un-expected data found on the boundary line: " + remainder);
                            stream._finished = true;
                            return 0;
                        });
                    }
                });
            }
            static /*bool */ SubMatch(/*ArraySegment<byte>*/ segment1, /*ReadOnlySpan<byte>*/ matchBytes, /*out int*/ matchOffset, /*out int*/ matchCount)
            {
                matchOffset.$v = $.$$.System.Math.Max$4(segment1.Offset, ((((segment1.Offset + segment1.Count) | 0) - matchBytes.Length) | 0));
                /*var*/ let segmentEnd = ((segment1.Offset + segment1.Count) | 0);
                matchCount.$v = 0;
                for(; matchOffset.$v < segmentEnd; matchOffset.$v++)
                {
                    /*var*/ let countLimit = ((segmentEnd - matchOffset.$v) | 0);
                    for(matchCount.$v = 0; matchCount.$v < matchBytes.Length && matchCount.$v < countLimit; matchCount.$v++)
                    {
                        if (matchBytes.get_Item(matchCount.$v).$v !== $.$$.System.Array.$ReadT1.call(segment1.Array, ((matchOffset.$v + matchCount.$v) | 0)))
                        {
                            matchCount.$v = 0;
                            break;
                        }
                    }
                    if (matchCount.$v > 0)
                    {
                        break;
                    }
                }
                return matchCount.$v > 0;
            }
            /*void */ CopyTo(/*Stream*/ destination, /*int*/ bufferSize)
            {
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                super.CopyTo(destination, bufferSize);
            }
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                return super.CopyToAsync(destination, bufferSize, cancellationToken);
            }
            //default member initializer
            constructor()
            {
                super();
                this.FinalBoundaryFound = false;
                this.LengthLimit = null;
            }
            static $h = 1294568;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":51540902120,"f":50331649},"s":{"r":0,"d":0,"h":55835869416,"f":83886082},"n":"FinalBoundaryFound","d":1294568,"h":47245934824,"f":2097153},{"p":$.$typeNullable($.$$.System.Int64).$h,"g":{"r":0,"d":0,"h":68720771304,"f":50331649},"s":{"r":0,"d":0,"h":73015738600,"f":83886081},"n":"LengthLimit","d":1294568,"h":64425804008,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81605673192,"f":50364417},"n":"CanRead","d":1294568,"h":77310705896,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":90195607784,"f":50364417},"n":"CanSeek","d":1294568,"h":85900640488,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":98785542376,"f":50364417},"n":"CanWrite","d":1294568,"h":94490575080,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":107375476968,"f":50364417},"n":"Length","d":1294568,"h":103080509672,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":115965411560,"f":50364417},"s":{"r":0,"d":0,"h":120260378856,"f":83918849},"n":"Position","d":1294568,"h":111670444264,"f":2129921}],"m":[{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1294568,"h":124555346152,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1294568,"h":128850313448,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1294568,"h":133145280744,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":1294568,"h":137440248040,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":1294568,"h":141735215336,"f":16809985},{"r":65537,"n":"Flush","d":1294568,"h":146030182632,"f":16809985},{"r":65537,"n":"PositionInnerStream","d":1294568,"h":150325149928,"f":16777218},{"r":655361,"p":[{"n":"read","p":655361}],"n":"UpdatePosition","d":1294568,"h":154620117224,"f":16777218},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1294568,"h":158915084520,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":1294568,"h":163210051816,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","o":"@$2","d":1294568,"h":167505019112,"f":16814081},{"r":262145,"p":[{"n":"segment1","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"matchBytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"matchOffset","p":655361,"f":2},{"n":"matchCount","p":655361,"f":2}],"n":"SubMatch","d":1294568,"h":171799986408,"f":16777250},{"r":65537,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361}],"n":"CopyTo","d":1294568,"h":176094953704,"f":16809985},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125829121}],"n":"CopyToAsync","d":1294568,"h":180389921000,"f":16809985}],"l":[{"t":1163496,"n":"_boundary","d":1294568,"h":4296261864,"f":4194306},{"t":442600,"n":"_innerStream","d":1294568,"h":8591229160,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_bytePool","d":1294568,"h":12886196456,"f":4194306},{"t":917505,"n":"_innerOffset","d":1294568,"h":17181163752,"f":4194306},{"t":917505,"n":"_position","d":1294568,"h":21476131048,"f":4194306},{"t":917505,"n":"_observedLength","d":1294568,"h":25771098344,"f":4194306},{"t":262145,"n":"_finished","d":1294568,"h":30066065640,"f":4194306}],"c":[{"p":[{"n":"stream","p":442600},{"n":"boundary","p":1163496}],"n":".ctor","o":"$ctor$4","d":1294568,"h":34361032936,"f":16777217},{"p":[{"n":"stream","p":442600},{"n":"boundary","p":1163496},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":1294568,"h":38656000232,"f":16777217}],"i":[57540609,56950785],"h":1294568}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `MultipartReaderStream`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter", ($self) => class HttpResponseStreamWriter extends $.$$.System.IO.TextWriter
        {
            /*int*/ static DefaultBufferSize = 16384;
            /*Stream*/ _stream = null;
            /*Encoder*/ _encoder = null;
            /*ArrayPool<byte>*/ _bytePool = null;
            /*ArrayPool<char>*/ _charPool = null;
            /*int*/ _charBufferSize = 0;
            /*byte[]*/ _byteBuffer = null;
            /*char[]*/ _charBuffer = null;
            /*int*/ _charBufferCount = 0;
            /*bool*/ _disposed = false;
            $ctor$6(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$4(stream, encoding, 16384/*DefaultBufferSize*/, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$4(stream, encoding, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("stream") });
                    this.Encoding = $.$firstOf(encoding, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, bufferSize, "bufferSize");
                    if (!this._stream.CanWrite)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$maw.Resources.HttpResponseStreamWriter_StreamNotWritable, "stream");
                    }
                    this._charBufferSize = bufferSize;
                    this._encoder = encoding.GetEncoder();
                    this._charBuffer = charPool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxByteCount(bufferSize);
                        this._byteBuffer = bytePool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        charPool.Return(this._charBuffer, false);
                        if (this._byteBuffer !== null)
                        {
                            bytePool.Return(this._byteBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            /*Encoding*/ Encoding = null;
            /*void */ Write$1(/*char*/ value)
            {
                this.ThrowIfDisposed();
                if (this._charBufferCount === this._charBufferSize)
                {
                    this.FlushInternal(false);
                }
                $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                this._charBufferCount++;
            }
            /*void */ Write$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                this.ThrowIfDisposed();
                if (values === null)
                {
                    return;
                }
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                }
            }
            /*void */ Write$9(/*ReadOnlySpan<char>*/ value)
            {
                this.ThrowIfDisposed();
                /*var*/ let remaining = value.Length;
                while(remaining > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    /*var*/ let written = this.CopyToCharBuffer$1(value);
                    remaining -= written;
                    value = value.Slice$1(written);
                }
            }
            /*void */ Write$16(/*string?*/ value)
            {
                this.ThrowIfDisposed();
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return;
                }
                /*var*/ let count = value.length;
                /*var*/ let index = 0;
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                }
            }
            /*void */ WriteLine$10(/*ReadOnlySpan<char>*/ value)
            {
                this.ThrowIfDisposed();
                this.Write$9(value);
                this.Write$16(this.NewLine);
            }
            /*Task */ WriteAsync(/*char*/ value)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (this._charBufferCount === this._charBufferSize)
                {
                    return this.WriteAsyncAwaited(value);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            /*Task *//*async*/  WriteAsyncAwaited(/*char*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._charBufferCount === this._charBufferSize, "_charBufferCount == _charBufferSize");
                    await this.FlushInternalAsync(false);
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                });
            }
            /*Task */ WriteAsync$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (values === null || count === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= count)
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$1(values, index, count);
                }
            }
            /*Task *//*async*/  WriteAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(count > 0, "count > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    }
                });
            }
            /*Task */ WriteAsync$4(/*string?*/ value)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.length)
                {
                    this.CopyToCharBuffer$3(value);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$3(value);
                }
            }
            /*Task *//*async*/  WriteAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*var*/ let count = value.length;
                    $.$$.System.Diagnostics.Debug.Assert$2(count > 0, "count > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    /*var*/ let index = 0;
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    }
                });
            }
            /*Task */ WriteAsync$3(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.Length)
                {
                    this.CopyToCharBuffer$1(value.Span);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$2(value);
                }
            }
            /*Task *//*async*/  WriteAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(value.Length > 0, "value.Length > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < value.Length, "_charBufferSize - _charBufferCount < value.Length");
                    /*var*/ let remaining = value.Length;
                    while(remaining > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        /*var*/ let written = this.CopyToCharBuffer$1(value.Span);
                        remaining -= written;
                        value = value.Slice$1(written);
                    }
                });
            }
            /*Task */ WriteLineAsync$4(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.Length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$1(value.Span);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$2(value);
                }
            }
            /*Task *//*async*/  WriteLineAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.WriteAsync$3(value, new $.$$.System.Threading.CancellationToken());
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            /*Task */ WriteLineAsync$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ((values === null || count === 0) && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                values ??= $.$$.System.Array.Empty($.$$.System.Char);
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((values.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$1(values, index, count);
                }
            }
            /*Task *//*async*/  WriteLineAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.WriteAsync$1(values, index, count);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            /*Task */ WriteLineAsync$1(/*char*/ value)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((this.NewLine.length + 1) | 0))
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited(value);
                }
            }
            /*Task *//*async*/  WriteLineAsyncAwaited(/*char*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.WriteAsync(value);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            /*Task */ WriteLineAsync$5(/*string?*/ value)
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.System.String.IsNullOrEmpty(value) && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                value ??= $.$$.System.String.Empty;
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$3(value);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$3(value);
                }
            }
            /*Task *//*async*/  WriteLineAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.WriteAsync$4(value);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            /*void */ Flush()
            {
                this.ThrowIfDisposed();
                this.FlushInternal(true);
            }
            /*Task */ FlushAsync()
            {
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                return this.FlushInternalAsync(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    try
                    {
                        this.FlushInternal(true);
                    }
                    finally
                    {
                        {
                            this._bytePool.Return(this._byteBuffer, false);
                            this._charPool.Return(this._charBuffer, false);
                        }
                    }
                }
                super.Dispose$1(disposing);
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    if (!this._disposed)
                    {
                        this._disposed = true;
                        try
                        {
                            await this.FlushInternalAsync(true);
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(this._byteBuffer, false);
                                this._charPool.Return(this._charBuffer, false);
                            }
                        }
                    }
                    await super.DisposeAsync();
                });
            }
            /*void */ FlushInternal(/*bool*/ flushEncoder)
            {
                if (this._charBufferCount === 0)
                {
                    return;
                }
                /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                this._charBufferCount = 0;
                if (count > 0)
                {
                    this._stream.Write(this._byteBuffer, 0, count);
                }
            }
            /*Task *//*async*/  FlushInternalAsync(/*bool*/ flushEncoder)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this._charBufferCount === 0)
                    {
                        return;
                    }
                    /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                    this._charBufferCount = 0;
                    if (count > 0)
                    {
                        await this._stream.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, count)), new $.$$.System.Threading.CancellationToken());
                    }
                });
            }
            /*void */ CopyToCharBuffer$3(/*string*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) >= value.length, "_charBufferSize - _charBufferCount >= value.Length");
                $.$$.System.String.CopyTo.call(value, 0, this._charBuffer, this._charBufferCount, value.length);
                this._charBufferCount += value.length;
            }
            /*void */ CopyToCharBuffer$2(/*string*/ value, /*ref int*/ index, /*ref int*/ count)
            {
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.System.String.CopyTo.call(value, index.$v, this._charBuffer, this._charBufferCount, remaining);
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            /*void */ CopyToCharBuffer(/*char[]*/ values, /*ref int*/ index, /*ref int*/ count)
            {
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.System.Buffer.BlockCopy(values, ((index.$v * $.$$.System.Char.$z) | 0), this._charBuffer, ((this._charBufferCount * $.$$.System.Char.$z) | 0), ((remaining * $.$$.System.Char.$z) | 0));
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            /*int */ CopyToCharBuffer$1(/*ReadOnlySpan<char>*/ value)
            {
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), value.Length);
                /*var*/ let source = value.Slice(0, remaining);
                /*var*/ let destination = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferCount, remaining);
                source.CopyTo(destination);
                this._charBufferCount += remaining;
                return remaining;
            }
            static /*Task */ GetObjectDisposedTask()
            {
                return $.$$.System.Threading.Tasks.Task.FromException(new $.$$.System.ObjectDisposedException().$ctor$17("HttpResponseStreamWriter"));
            }
            /*void */ ThrowIfDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            static $h = 1032424;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":63045633,"p":[{"p":121700353,"g":{"r":0,"d":0,"h":68720509160,"f":50364417},"n":"Encoding","d":1032424,"h":64425541864,"f":2129921}],"m":[{"r":65537,"p":[{"n":"value","p":458753}],"n":"Write","o":"@$1","d":1032424,"h":73015476456,"f":16809985},{"r":65537,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Write","o":"@$2","d":1032424,"h":77310443752,"f":16809985},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Write","o":"@$9","d":1032424,"h":81605411048,"f":16809985},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"Write","o":"@$16","d":1032424,"h":85900378344,"f":16809985},{"r":65537,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"WriteLine","o":"@$10","d":1032424,"h":90195345640,"f":16809985},{"r":133169153,"p":[{"n":"value","p":458753}],"n":"WriteAsync","d":1032424,"h":94490312936,"f":16809985},{"r":133169153,"p":[{"n":"value","p":458753}],"n":"WriteAsyncAwaited","d":1032424,"h":98785280232,"f":16781314},{"r":133169153,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteAsync","o":"@$1","d":1032424,"h":103080247528,"f":16809985},{"r":133169153,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteAsyncAwaited","o":"@$1","d":1032424,"h":107375214824,"f":16781314},{"r":133169153,"p":[{"n":"value","p":1310721}],"n":"WriteAsync","o":"@$4","d":1032424,"h":111670182120,"f":16809985},{"r":133169153,"p":[{"n":"value","p":1310721}],"n":"WriteAsyncAwaited","o":"@$3","d":1032424,"h":115965149416,"f":16781314},{"r":133169153,"p":[{"n":"value","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$3","d":1032424,"h":120260116712,"f":16809985},{"r":133169153,"p":[{"n":"value","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":"WriteAsyncAwaited","o":"@$2","d":1032424,"h":124555084008,"f":16781314},{"r":133169153,"p":[{"n":"value","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteLineAsync","o":"@$4","d":1032424,"h":128850051304,"f":16809985},{"r":133169153,"p":[{"n":"value","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h}],"n":"WriteLineAsyncAwaited","o":"@$2","d":1032424,"h":133145018600,"f":16781314},{"r":133169153,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteLineAsync","o":"@$2","d":1032424,"h":137439985896,"f":16809985},{"r":133169153,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteLineAsyncAwaited","o":"@$1","d":1032424,"h":141734953192,"f":16781314},{"r":133169153,"p":[{"n":"value","p":458753}],"n":"WriteLineAsync","o":"@$1","d":1032424,"h":146029920488,"f":16809985},{"r":133169153,"p":[{"n":"value","p":458753}],"n":"WriteLineAsyncAwaited","d":1032424,"h":150324887784,"f":16781314},{"r":133169153,"p":[{"n":"value","p":1310721}],"n":"WriteLineAsync","o":"@$5","d":1032424,"h":154619855080,"f":16809985},{"r":133169153,"p":[{"n":"value","p":1310721}],"n":"WriteLineAsyncAwaited","o":"@$3","d":1032424,"h":158914822376,"f":16781314},{"r":65537,"n":"Flush","d":1032424,"h":163209789672,"f":16809985},{"r":133169153,"n":"FlushAsync","d":1032424,"h":167504756968,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1032424,"h":171799724264,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":1032424,"h":176094691560,"f":16814081},{"r":65537,"p":[{"n":"flushEncoder","p":262145}],"n":"FlushInternal","d":1032424,"h":180389658856,"f":16777218},{"r":133169153,"p":[{"n":"flushEncoder","p":262145}],"n":"FlushInternalAsync","d":1032424,"h":184684626152,"f":16781314},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"CopyToCharBuffer","o":"@$3","d":1032424,"h":188979593448,"f":16777218},{"r":65537,"p":[{"n":"value","p":1310721},{"n":"index","p":655361,"f":4},{"n":"count","p":655361,"f":4}],"n":"CopyToCharBuffer","o":"@$2","d":1032424,"h":193274560744,"f":16777218},{"r":65537,"p":[{"n":"values","p":$.$typeArray($.$$.System.Char).$h},{"n":"index","p":655361,"f":4},{"n":"count","p":655361,"f":4}],"n":"CopyToCharBuffer","d":1032424,"h":197569528040,"f":16777218},{"r":655361,"p":[{"n":"value","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"CopyToCharBuffer","o":"@$1","d":1032424,"h":201864495336,"f":16777218},{"r":133169153,"n":"GetObjectDisposedTask","d":1032424,"h":206159462632,"f":16777250},{"r":65537,"n":"ThrowIfDisposed","d":1032424,"h":210454429928,"f":16777218}],"l":[{"t":655361,"n":"DefaultBufferSize","d":1032424,"h":4295999720,"f":4194344},{"t":62193665,"n":"_stream","d":1032424,"h":8590967016,"f":4194306},{"t":120979457,"n":"_encoder","d":1032424,"h":12885934312,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_bytePool","d":1032424,"h":17180901608,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,"n":"_charPool","d":1032424,"h":21475868904,"f":4194306},{"t":655361,"n":"_charBufferSize","d":1032424,"h":25770836200,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_byteBuffer","d":1032424,"h":30065803496,"f":4194306},{"t":$.$typeArray($.$$.System.Char).$h,"n":"_charBuffer","d":1032424,"h":34360770792,"f":4194306},{"t":655361,"n":"_charBufferCount","d":1032424,"h":38655738088,"f":4194306},{"t":262145,"n":"_disposed","d":1032424,"h":42950705384,"f":4194306}],"c":[{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353}],"n":".ctor","o":"$ctor$6","d":1032424,"h":47245672680,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$5","d":1032424,"h":51540639976,"f":16777217},{"p":[{"n":"stream","p":62193665},{"n":"encoding","p":121700353},{"n":"bufferSize","p":655361},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h},{"n":"charPool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h}],"n":".ctor","o":"$ctor$4","d":1032424,"h":55835607272,"f":16777217}],"i":[57540609,56950785],"h":1032424}; }
            static get $b() { return $.$$.System.IO.TextWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `HttpResponseStreamWriter`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileBufferingReadStream", ($self) => class FileBufferingReadStream extends $.$$.System.IO.Stream
        {
            /*int*/ static _maxRentedBufferSize = 1048576;
            /*Stream*/ _inner = null;
            /*ArrayPool<byte>*/ _bytePool = null;
            /*int*/ _memoryThreshold = 0;
            /*long?*/ _bufferLimit = null;
            /*string?*/ _tempFileDirectory = null;
            /*Func<string>?*/ _tempFileDirectoryAccessor = null;
            /*string?*/ _tempFileName = null;
            /*Stream*/ _buffer = null;
            /*byte[]?*/ _rentedBuffer = null;
            /*bool*/ _inMemory = true;
            /*bool*/ _completelyBuffered = false;
            /*bool*/ _disposed = false;
            $ctor$7(/*Stream*/ inner, /*int*/ memoryThreshold)
            {
                this.$ctor$4(inner, memoryThreshold, null, $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectoryFactory);
                {
                }
                return this;
            }
            $ctor$4(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor)
            {
                this.$ctor$3(inner, memoryThreshold, bufferLimit, tempFileDirectoryAccessor, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                }
                return this;
            }
            $ctor$3(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(tempFileDirectoryAccessor, "tempFileDirectoryAccessor");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor;
                }
                return this;
            }
            $ctor$6(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory)
            {
                this.$ctor$5(inner, memoryThreshold, bufferLimit, tempFileDirectory, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                }
                return this;
            }
            $ctor$5(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(tempFileDirectory, "tempFileDirectory");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectory = tempFileDirectory;
                }
                return this;
            }
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            /*bool */ get InMemory()
            {
                return this._inMemory;
            }
            /*string? */ get TempFileName()
            {
                return this._tempFileName;
            }
            /*bool */ get CanRead()
            {
                return !this._disposed;
            }
            /*bool */ get CanSeek()
            {
                return !this._disposed;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*long */ get Length()
            {
                return this._buffer.Length;
            }
            /*long */ get Position()
            {
                return this._buffer.Position;
            }
            /*long */ set Position(value)
            {
                this.ThrowIfDisposed();
                this._buffer.Position = value;
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                this.ThrowIfDisposed();
                if (!this._completelyBuffered && origin === 2/*SeekOrigin.End*/)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 1/*SeekOrigin.Current*/ && offset + this.Position > this.Length)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 0/*SeekOrigin.Begin*/ && offset > this.Length)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                return this._buffer.Seek(offset, origin);
            }
            /*Stream */ CreateTempFile()
            {
                if ($.$$.System.String.op_Equality(this._tempFileDirectory, null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._tempFileDirectoryAccessor !== null, "_tempFileDirectoryAccessor != null");
                    this._tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this._tempFileDirectory, null), "_tempFileDirectory != null");
                }
                this._tempFileName = $.$$.System.IO.Path.Combine$3(this._tempFileDirectory, "ASPNETCORE_" + $.$$.System.Guid.ToString.call($.$$.System.Guid.NewGuid()) + ".tmp");
                if (!$.$$.System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform($.$$.System.Runtime.InteropServices.OSPlatform.Windows))
                {
                    /*var*/ let tempTempFileName = $.$$.System.IO.Path.GetTempFileName();
                    $.$$.System.IO.File.Move$1(tempTempFileName, this._tempFileName);
                }
                return new $.$$.System.IO.FileStream().$ctor$12(this._tempFileName, 2/*FileMode.Create*/, 3/*FileAccess.ReadWrite*/, 4/*FileShare.Delete*/, ((1024 * 16) | 0), 1073741824/*FileOptions.Asynchronous*/ | 67108864/*FileOptions.DeleteOnClose*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                this.ThrowIfDisposed();
                if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                {
                    return this._buffer.Read$1(buffer);
                }
                /*var*/ let read = this._inner.Read$1(buffer);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - read < this._buffer.Length)
                {
                    throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                }
                if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                {
                    this._inMemory = false;
                    /*var*/ let oldBuffer = this._buffer;
                    this._buffer = this.CreateTempFile();
                    if (this._rentedBuffer === null)
                    {
                        oldBuffer.Position = 0n;
                        /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.System.Math.Min$4($.$cast(oldBuffer.Length, $.$$.System.Int32), 1048576/*_maxRentedBufferSize*/));
                        try
                        {
                            /*var*/ let copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                            while(copyRead > 0)
                            {
                                this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rentedBuffer, 0, copyRead)));
                                copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(rentedBuffer, false);
                            }
                        }
                    }
                    else 
                    {
                        this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.System.Int32))));
                        this._bytePool.Return(this._rentedBuffer, false);
                        this._rentedBuffer = null;
                    }
                }
                if (read > 0)
                {
                    this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer.Slice(0, read)));
                }
                else if (buffer.Length > 0)
                {
                    this._completelyBuffered = true;
                }
                return read;
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                return this.Read$1($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, buffer, offset, count));
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    this.ThrowIfDisposed();
                    if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                    {
                        return await this._buffer.ReadAsync$2(buffer, cancellationToken);
                    }
                    /*var*/ let read = await this._inner.ReadAsync$2(buffer, cancellationToken);
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - read < this._buffer.Length)
                    {
                        throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                    {
                        this._inMemory = false;
                        /*var*/ let oldBuffer = this._buffer;
                        this._buffer = this.CreateTempFile();
                        if (this._rentedBuffer === null)
                        {
                            oldBuffer.Position = 0n;
                            /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.System.Math.Min$4($.$cast(oldBuffer.Length, $.$$.System.Int32), 1048576/*_maxRentedBufferSize*/));
                            try
                            {
                                /*var*/ let copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                                while(copyRead > 0)
                                {
                                    await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, rentedBuffer, 0, copyRead)), cancellationToken);
                                    copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                                }
                            }
                            finally
                            {
                                {
                                    this._bytePool.Return(rentedBuffer, false);
                                }
                            }
                        }
                        else 
                        {
                            await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.System.Int32))), cancellationToken);
                            this._bytePool.Return(this._rentedBuffer, false);
                            this._rentedBuffer = null;
                        }
                    }
                    if (read > 0)
                    {
                        await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2(buffer.Slice(0, read)), cancellationToken);
                    }
                    else if (buffer.Length > 0)
                    {
                        this._completelyBuffered = true;
                    }
                    return read;
                });
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Flush()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                if (this._completelyBuffered)
                {
                    return this._buffer.CopyToAsync(destination, bufferSize, cancellationToken);
                }
                /*Task*/ /*async*/  function CopyToAsyncImpl()
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                    {
                        /*byte[]*/ let buffer = this._bytePool.Rent(bufferSize);
                        try
                        {
                            while(true)
                            {
                                /*int*/ let bytesRead = await this.ReadAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$1(buffer), cancellationToken);
                                if (bytesRead === 0)
                                {
                                    break;
                                }
                                await destination.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, 0, bytesRead)), cancellationToken);
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(buffer, false);
                            }
                        }
                    });
                }
                return CopyToAsyncImpl.call(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    this._disposed = true;
                    if (this._rentedBuffer !== null)
                    {
                        this._bytePool.Return(this._rentedBuffer, false);
                    }
                    if (disposing)
                    {
                        this._buffer.Dispose();
                    }
                }
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    if (!this._disposed)
                    {
                        this._disposed = true;
                        if (this._rentedBuffer !== null)
                        {
                            this._bytePool.Return(this._rentedBuffer, false);
                        }
                        await this._buffer.DisposeAsync();
                    }
                });
            }
            /*void */ ThrowIfDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            static $h = 508136;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":655361,"g":{"r":0,"d":0,"h":85899854056,"f":50331649},"n":"MemoryThreshold","d":508136,"h":81604886760,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94489788648,"f":50331649},"n":"InMemory","d":508136,"h":90194821352,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":103079723240,"f":50331649},"n":"TempFileName","d":508136,"h":98784755944,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":111669657832,"f":50364417},"n":"CanRead","d":508136,"h":107374690536,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":120259592424,"f":50364417},"n":"CanSeek","d":508136,"h":115964625128,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":128849527016,"f":50364417},"n":"CanWrite","d":508136,"h":124554559720,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":137439461608,"f":50364417},"n":"Length","d":508136,"h":133144494312,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":146029396200,"f":50364417},"s":{"r":0,"d":0,"h":150324363496,"f":83918849},"n":"Position","d":508136,"h":141734428904,"f":2129921}],"m":[{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":508136,"h":154619330792,"f":16809985},{"r":62193665,"n":"CreateTempFile","d":508136,"h":158914298088,"f":16777218},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":508136,"h":163209265384,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":508136,"h":167504232680,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":508136,"h":171799199976,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":508136,"h":176094167272,"f":16814081},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":508136,"h":180389134568,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","o":"@$2","d":508136,"h":184684101864,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":508136,"h":188979069160,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":508136,"h":193274036456,"f":16809985},{"r":65537,"n":"Flush","d":508136,"h":197569003752,"f":16809985},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"bufferSize","p":655361},{"n":"cancellationToken","p":125829121}],"n":"CopyToAsync","d":508136,"h":201863971048,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":508136,"h":206158938344,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":508136,"h":210453905640,"f":16814081},{"r":65537,"n":"ThrowIfDisposed","d":508136,"h":214748872936,"f":16777218}],"l":[{"t":655361,"n":"_maxRentedBufferSize","d":508136,"h":4295475432,"f":4194338},{"t":62193665,"n":"_inner","d":508136,"h":8590442728,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_bytePool","d":508136,"h":12885410024,"f":4194306},{"t":655361,"n":"_memoryThreshold","d":508136,"h":17180377320,"f":4194306},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_bufferLimit","d":508136,"h":21475344616,"f":4194306},{"t":1310721,"n":"_tempFileDirectory","d":508136,"h":25770311912,"f":4194306},{"t":$.$$.System.Func$$($.$$.System.String).$h,"n":"_tempFileDirectoryAccessor","d":508136,"h":30065279208,"f":4194306},{"t":1310721,"n":"_tempFileName","d":508136,"h":34360246504,"f":4194306},{"t":62193665,"n":"_buffer","d":508136,"h":38655213800,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_rentedBuffer","d":508136,"h":42950181096,"f":4194306},{"t":262145,"n":"_inMemory","d":508136,"h":47245148392,"f":4194306},{"t":262145,"n":"_completelyBuffered","d":508136,"h":51540115688,"f":4194306},{"t":262145,"n":"_disposed","d":508136,"h":55835082984,"f":4194306}],"c":[{"p":[{"n":"inner","p":62193665},{"n":"memoryThreshold","p":655361}],"n":".ctor","o":"$ctor$7","d":508136,"h":60130050280,"f":16777217},{"p":[{"n":"inner","p":62193665},{"n":"memoryThreshold","p":655361},{"n":"bufferLimit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"tempFileDirectoryAccessor","p":$.$$.System.Func$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$4","d":508136,"h":64425017576,"f":16777217},{"p":[{"n":"inner","p":62193665},{"n":"memoryThreshold","p":655361},{"n":"bufferLimit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"tempFileDirectoryAccessor","p":$.$$.System.Func$$($.$$.System.String).$h},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":508136,"h":68719984872,"f":16777217},{"p":[{"n":"inner","p":62193665},{"n":"memoryThreshold","p":655361},{"n":"bufferLimit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"tempFileDirectory","p":1310721}],"n":".ctor","o":"$ctor$6","d":508136,"h":73014952168,"f":16777217},{"p":[{"n":"inner","p":62193665},{"n":"memoryThreshold","p":655361},{"n":"bufferLimit","p":$.$typeNullable($.$$.System.Int64).$h},{"n":"tempFileDirectory","p":1310721},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$5","d":508136,"h":77309919464,"f":16777217}],"i":[57540609,56950785],"h":508136}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `FileBufferingReadStream`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream", ($self) => class BufferedReadStream extends $.$$.System.IO.Stream
        {
            /*byte*/ static CR = 13;
            /*byte*/ static LF = 10;
            /*Stream*/ _inner = null;
            /*byte[]*/ _buffer = null;
            /*ArrayPool<byte>*/ _bytePool = null;
            /*int*/ _bufferOffset = 0;
            /*int*/ _bufferCount = 0;
            /*bool*/ _disposed = false;
            $ctor$4(/*Stream*/ inner, /*int*/ bufferSize)
            {
                this.$ctor$3(inner, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                }
                return this;
            }
            $ctor$3(/*Stream*/ inner, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    this._inner = inner;
                    this._bytePool = bytePool;
                    this._buffer = bytePool.Rent(bufferSize);
                }
                return this;
            }
            /*ArraySegment<byte> */ get BufferedData()
            {
                return new ($.$$.System.ArraySegment$$($.$$.System.Byte))().$ctor$3(this._buffer, this._bufferOffset, this._bufferCount);
            }
            /*bool */ get CanRead()
            {
                return this._inner.CanRead || this._bufferCount > 0;
            }
            /*bool */ get CanSeek()
            {
                return this._inner.CanSeek;
            }
            /*bool */ get CanTimeout()
            {
                return this._inner.CanTimeout;
            }
            /*bool */ get CanWrite()
            {
                return this._inner.CanWrite;
            }
            /*long */ get Length()
            {
                return this._inner.Length;
            }
            /*long */ get Position()
            {
                return this._inner.Position - BigInt(this._bufferCount);
            }
            /*long */ set Position(value)
            {
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "Position must be positive.");
                }
                if (value === this.Position)
                {
                    return;
                }
                if (value <= this._inner.Position)
                {
                    /*var*/ let innerOffset = $.$cast((this._inner.Position - value), $.$$.System.Int32);
                    if (innerOffset <= this._bufferCount)
                    {
                        this._bufferOffset += ((this._bufferCount - innerOffset) | 0);
                        this._bufferCount = innerOffset;
                    }
                    else 
                    {
                        this._bufferOffset = 0;
                        this._bufferCount = 0;
                        this._inner.Position = value;
                    }
                }
                else 
                {
                    this._bufferOffset = 0;
                    this._bufferCount = 0;
                    this._inner.Position = value;
                }
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = this.Position + offset;
                }
                else 
                {
                    this.Position = this.Length + offset;
                }
                return this.Position;
            }
            /*void */ SetLength(/*long*/ value)
            {
                this._inner.SetLength(value);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._buffer, false);
                    if (disposing)
                    {
                        this._inner.Dispose();
                    }
                }
            }
            /*void */ Flush()
            {
                this._inner.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return this._inner.FlushAsync$1(cancellationToken);
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this._inner.Write(buffer, offset, count);
            }
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return this._inner.WriteAsync$2(buffer, cancellationToken);
            }
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this._inner.WriteAsync(buffer, offset, count, cancellationToken);
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (this._bufferCount > 0)
                {
                    /*int*/ let toCopy = $.$$.System.Math.Min$4(this._bufferCount, count);
                    $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, buffer, offset, toCopy);
                    this._bufferOffset += toCopy;
                    this._bufferCount -= toCopy;
                    return toCopy;
                }
                return this._inner.Read(buffer, offset, count);
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    if (this._bufferCount > 0)
                    {
                        /*int*/ let toCopy = $.$$.System.Math.Min$4(this._bufferCount, buffer.Length);
                        $.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._buffer, this._bufferOffset, toCopy).CopyTo(buffer);
                        this._bufferOffset += toCopy;
                        this._bufferCount -= toCopy;
                        return toCopy;
                    }
                    return await this._inner.ReadAsync$2(buffer, cancellationToken);
                });
            }
            /*bool */ EnsureBuffered()
            {
                if (this._bufferCount > 0)
                {
                    return true;
                }
                this._bufferOffset = 0;
                this._bufferCount = this._inner.Read(this._buffer, 0, this._buffer.length);
                return this._bufferCount > 0;
            }
            /*Task<bool> *//*async*/  EnsureBufferedAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    if (this._bufferCount > 0)
                    {
                        return true;
                    }
                    this._bufferOffset = 0;
                    this._bufferCount = await this._inner.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, this._buffer), cancellationToken);
                    return this._bufferCount > 0;
                });
            }
            /*bool */ EnsureBuffered$1(/*int*/ minCount)
            {
                if (minCount > this._buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.System.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                }
                while(this._bufferCount < minCount)
                {
                    if (this._bufferOffset > 0)
                    {
                        if (this._bufferCount > 0)
                        {
                            $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                        }
                        this._bufferOffset = 0;
                    }
                    /*int*/ let read = this._inner.Read(this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0));
                    this._bufferCount += read;
                    if (read === 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            /*Task<bool> *//*async*/  EnsureBufferedAsync(/*int*/ minCount, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    if (minCount > this._buffer.length)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.System.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                    }
                    while(this._bufferCount < minCount)
                    {
                        if (this._bufferOffset > 0)
                        {
                            if (this._bufferCount > 0)
                            {
                                $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                            }
                            this._bufferOffset = 0;
                        }
                        /*int*/ let read = await this._inner.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0)), cancellationToken);
                        this._bufferCount += read;
                        if (read === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                });
            }
            /*string */ ReadLine(/*int*/ lengthLimit)
            {
                this.CheckDisposed();
                let builder = null;
                try
                {
                    builder = new $.$$.System.IO.MemoryStream().$ctor$9(200);
                    /*bool*/ let foundCR = false, foundCRLF = false;
                    while(!foundCRLF && this.EnsureBuffered())
                    {
                        this.ProcessLineChar(builder, lengthLimit, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCR, ($v) => foundCR = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null));
                    }
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream.DecodeLine(builder, foundCRLF);
                }
                finally
                {
                    builder?.System$IDisposable$Dispose();
                }
            }
            /*Task<string> *//*async*/  ReadLineAsync(/*int*/ lengthLimit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    this.CheckDisposed();
                    let builder = null;
                    try
                    {
                        builder = new $.$$.System.IO.MemoryStream().$ctor$9(200);
                        /*bool*/ let foundCR = false, foundCRLF = false;
                        while(!foundCRLF && await this.EnsureBufferedAsync$1(cancellationToken))
                        {
                            this.ProcessLineChar(builder, lengthLimit, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCR, ($v) => foundCR = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null));
                        }
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream.DecodeLine(builder, foundCRLF);
                    }
                    finally
                    {
                        builder?.System$IDisposable$Dispose();
                    }
                });
            }
            /*void */ ProcessLineChar(/*MemoryStream*/ builder, /*int*/ lengthLimit, /*ref bool*/ foundCR, /*ref bool*/ foundCRLF)
            {
                /*var*/ let writeCount = 0;
                while(this._bufferCount > 0)
                {
                    /*var*/ let b = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset);
                    this._bufferOffset++;
                    this._bufferCount--;
                    writeCount++;
                    if (b === 10/*LF*/ && foundCR.$v)
                    {
                        builder.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
                        foundCRLF.$v = true;
                        return;
                    }
                    foundCR.$v = b === 13/*CR*/;
                    if (writeCount > lengthLimit)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Line length limit ${lengthLimit} exceeded.`);
                    }
                }
                builder.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
            }
            static /*string */ DecodeLine(/*MemoryStream*/ builder, /*bool*/ foundCRLF)
            {
                /*var*/ let length = foundCRLF ? builder.Length - 2n : builder.Length;
                return $.$$.System.Text.Encoding.UTF8.GetString(builder.GetBuffer(), 0, $.$cast(length, $.$$.System.Int32));
            }
            /*void */ CheckDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            static $h = 442600;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":51540050152,"f":50331649},"n":"BufferedData","d":442600,"h":47245082856,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60129984744,"f":50364417},"n":"CanRead","d":442600,"h":55835017448,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":68719919336,"f":50364417},"n":"CanSeek","d":442600,"h":64424952040,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":77309853928,"f":50364417},"n":"CanTimeout","d":442600,"h":73014886632,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":85899788520,"f":50364417},"n":"CanWrite","d":442600,"h":81604821224,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":94489723112,"f":50364417},"n":"Length","d":442600,"h":90194755816,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":103079657704,"f":50364417},"s":{"r":0,"d":0,"h":107374625000,"f":83918849},"n":"Position","d":442600,"h":98784690408,"f":2129921}],"m":[{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":442600,"h":111669592296,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":442600,"h":115964559592,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":442600,"h":120259526888,"f":16809988},{"r":65537,"n":"Flush","d":442600,"h":124554494184,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":442600,"h":128849461480,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":442600,"h":133144428776,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","o":"@$2","d":442600,"h":137439396072,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":442600,"h":141734363368,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":442600,"h":146029330664,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":442600,"h":150324297960,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","o":"@$2","d":442600,"h":154619265256,"f":16814081},{"r":262145,"n":"EnsureBuffered","d":442600,"h":158914232552,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"EnsureBufferedAsync","o":"@$1","d":442600,"h":163209199848,"f":16781313},{"r":262145,"p":[{"n":"minCount","p":655361}],"n":"EnsureBuffered","o":"@$1","d":442600,"h":167504167144,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,"p":[{"n":"minCount","p":655361},{"n":"cancellationToken","p":125829121}],"n":"EnsureBufferedAsync","d":442600,"h":171799134440,"f":16781313},{"r":1310721,"p":[{"n":"lengthLimit","p":655361}],"n":"ReadLine","d":442600,"h":176094101736,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,"p":[{"n":"lengthLimit","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadLineAsync","d":442600,"h":180389069032,"f":16781313},{"r":65537,"p":[{"n":"builder","p":61014017},{"n":"lengthLimit","p":655361},{"n":"foundCR","p":262145,"f":4},{"n":"foundCRLF","p":262145,"f":4}],"n":"ProcessLineChar","d":442600,"h":184684036328,"f":16777218},{"r":1310721,"p":[{"n":"builder","p":61014017},{"n":"foundCRLF","p":262145}],"n":"DecodeLine","d":442600,"h":188979003624,"f":16777250},{"r":65537,"n":"CheckDisposed","d":442600,"h":193273970920,"f":16777218}],"l":[{"t":393217,"n":"CR","d":442600,"h":4295409896,"f":4194338},{"t":393217,"n":"LF","d":442600,"h":8590377192,"f":4194338},{"t":62193665,"n":"_inner","d":442600,"h":12885344488,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_buffer","d":442600,"h":17180311784,"f":4194306},{"t":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,"n":"_bytePool","d":442600,"h":21475279080,"f":4194306},{"t":655361,"n":"_bufferOffset","d":442600,"h":25770246376,"f":4194306},{"t":655361,"n":"_bufferCount","d":442600,"h":30065213672,"f":4194306},{"t":262145,"n":"_disposed","d":442600,"h":34360180968,"f":4194306}],"c":[{"p":[{"n":"inner","p":62193665},{"n":"bufferSize","p":655361}],"n":".ctor","o":"$ctor$4","d":442600,"h":38655148264,"f":16777217},{"p":[{"n":"inner","p":62193665},{"n":"bufferSize","p":655361},{"n":"bytePool","p":$.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":442600,"h":42950115560,"f":16777217}],"i":[57540609,56950785],"h":442600}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `BufferedReadStream`; }
        });
        
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileBufferingWriteStream", ($self) => class FileBufferingWriteStream extends $.$$.System.IO.Stream
        {
            /*int*/ static DefaultMemoryThreshold = 32768;
            /*int*/ _memoryThreshold = 0;
            /*long?*/ _bufferLimit = null;
            /*Func<string>*/ _tempFileDirectoryAccessor = null;
            $ctor$3(/*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>?*/ tempFileDirectoryAccessor)
            {
                super.$ctor$2();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, memoryThreshold, "memoryThreshold");
                    if (bufferLimit !== null && bufferLimit < memoryThreshold)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("bufferLimit", `${"bufferLimit"} must be larger than ${"memoryThreshold"}.`);
                    }
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor ?? $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectoryFactory;
                    this.PagedByteBuffer = new $.$maw.Microsoft.AspNetCore.WebUtilities.PagedByteBuffer().$ctor$1($.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                }
                return this;
            }
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            /*bool */ get CanRead()
            {
                return false;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*bool */ get CanWrite()
            {
                return true;
            }
            /*long */ get Length()
            {
                return BigInt(this.PagedByteBuffer.Length) + ((this.FileStream?.Length ?? null) ?? 0n);
            }
            /*long */ get Position()
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*PagedByteBuffer*/ PagedByteBuffer = null;
            /*FileStream?*/ FileStream = null;
            /*bool*/ Disposed = false;
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.ThrowIfDisposed();
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - this.Length < count)
                {
                    this.Dispose();
                    throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                }
                /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - count) | 0)) >= this.PagedByteBuffer.Length;
                if (allowMemoryBuffer)
                {
                    this.PagedByteBuffer.Add(buffer, offset, count);
                    $.$$.System.Diagnostics.Debug.Assert$2(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                }
                else 
                {
                    this.EnsureFileStream();
                    this.PagedByteBuffer.MoveTo(this.FileStream);
                    this.FileStream.Write(buffer, offset, count);
                }
            }
            /*Task *//*async*/  WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    await this.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count)), cancellationToken);
                });
            }
            /*ValueTask *//*async*/  WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    this.ThrowIfDisposed();
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - this.Length < buffer.Length)
                    {
                        this.Dispose();
                        throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - buffer.Length) | 0)) >= this.PagedByteBuffer.Length;
                    if (allowMemoryBuffer)
                    {
                        this.PagedByteBuffer.Add$1(buffer);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                    }
                    else 
                    {
                        this.EnsureFileStream();
                        await this.PagedByteBuffer.MoveToAsync(this.FileStream, cancellationToken);
                        await this.FileStream.WriteAsync$2(buffer, cancellationToken);
                    }
                });
            }
            /*void */ Flush()
            {
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.System.Threading.Tasks.Task.CompletedTask;
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*Task *//*async*/  DrainBufferAsync(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.System.IO.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            await readStream.CopyToAsync$2(destination, cancellationToken);
                            await this.FileStream.DisposeAsync();
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.System$IDisposable$Dispose();
                        }
                    }
                    await this.PagedByteBuffer.MoveToAsync(destination, cancellationToken);
                });
            }
            /*Task *//*async*/  DrainBufferAsync$1(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.System.IO.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(readStream, destination, cancellationToken);
                            await this.FileStream.DisposeAsync();
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.System$IDisposable$Dispose();
                        }
                    }
                    await this.PagedByteBuffer.MoveToAsync$1(destination, cancellationToken);
                });
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.PagedByteBuffer.Dispose();
                    this.FileStream?.Dispose();
                }
            }
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    if (!this.Disposed)
                    {
                        this.Disposed = true;
                        this.PagedByteBuffer.Dispose();
                        await ((this.FileStream?.DisposeAsync() ?? null) ?? new $.$$.System.Threading.Tasks.ValueTask());
                    }
                });
            }
            /*void */ EnsureFileStream()
            {
                if (this.FileStream === null)
                {
                    /*var*/ let tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    /*var*/ let tempFileName = $.$$.System.IO.Path.Combine$3(tempFileDirectory, "ASPNETCORE_" + $.$$.System.Guid.ToString.call($.$$.System.Guid.NewGuid()) + ".tmp");
                    if (!$.$$.System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform($.$$.System.Runtime.InteropServices.OSPlatform.Windows))
                    {
                        /*var*/ let tempTempFileName = $.$$.System.IO.Path.GetTempFileName();
                        $.$$.System.IO.File.Move$1(tempTempFileName, tempFileName);
                    }
                    this.FileStream = new $.$$.System.IO.FileStream().$ctor$12(tempFileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/ | 67108864/*FileOptions.DeleteOnClose*/);
                }
            }
            /*void */ ThrowIfDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Disposed = false;
            }
            static $h = 573672;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065344744,"f":50331649},"n":"MemoryThreshold","d":573672,"h":25770377448,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655279336,"f":50364417},"n":"CanRead","d":573672,"h":34360312040,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":47245213928,"f":50364417},"n":"CanSeek","d":573672,"h":42950246632,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":55835148520,"f":50364417},"n":"CanWrite","d":573672,"h":51540181224,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":64425083112,"f":50364417},"n":"Length","d":573672,"h":60130115816,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":73015017704,"f":50364417},"s":{"r":0,"d":0,"h":77309985000,"f":83918849},"n":"Position","d":573672,"h":68720050408,"f":2129921},{"p":1556712,"g":{"r":0,"d":0,"h":90194886888,"f":50331656},"n":"PagedByteBuffer","d":573672,"h":85899919592,"f":2097160},{"p":60358657,"g":{"r":0,"d":0,"h":103079788776,"f":50331656},"s":{"r":0,"d":0,"h":107374756072,"f":83886082},"n":"FileStream","d":573672,"h":98784821480,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":120259657960,"f":50331656},"s":{"r":0,"d":0,"h":124554625256,"f":83886082},"n":"Disposed","d":573672,"h":115964690664,"f":2097160}],"m":[{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":573672,"h":128849592552,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":573672,"h":133144559848,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":573672,"h":137439527144,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","o":"@$2","d":573672,"h":141734494440,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":573672,"h":146029461736,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":573672,"h":150324429032,"f":16814081},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":573672,"h":154619396328,"f":16814081},{"r":65537,"n":"Flush","d":573672,"h":158914363624,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":573672,"h":163209330920,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":573672,"h":167504298216,"f":16809985},{"r":133169153,"p":[{"n":"destination","p":62193665},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DrainBufferAsync","d":573672,"h":171799265512,"f":16781313},{"r":133169153,"p":[{"n":"destination","p":1609706},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DrainBufferAsync","o":"@$1","d":573672,"h":176094232808,"f":16781313},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":573672,"h":180389200104,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":573672,"h":184684167400,"f":16814081},{"r":65537,"n":"EnsureFileStream","d":573672,"h":188979134696,"f":16777218},{"r":65537,"n":"ThrowIfDisposed","d":573672,"h":193274101992,"f":16777218}],"l":[{"t":655361,"n":"DefaultMemoryThreshold","d":573672,"h":4295540968,"f":4194338},{"t":655361,"n":"_memoryThreshold","d":573672,"h":8590508264,"f":4194306},{"t":$.$typeNullable($.$$.System.Int64).$h,"n":"_bufferLimit","d":573672,"h":12885475560,"f":4194306},{"t":$.$$.System.Func$$($.$$.System.String).$h,"n":"_tempFileDirectoryAccessor","d":573672,"h":17180442856,"f":4194306}],"c":[{"p":[{"n":"memoryThreshold","p":655361,"f":65,"v":32768},{"n":"bufferLimit","p":$.$typeNullable($.$$.System.Int64).$h,"f":65},{"n":"tempFileDirectoryAccessor","p":$.$$.System.Func$$($.$$.System.String).$h,"f":65}],"n":".ctor","o":"$ctor$3","d":573672,"h":21475410152,"f":16777217}],"i":[57540609,56950785],"h":573672}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `FileBufferingWriteStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.Net.Http.Headers", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web"))