
//--TRIMMABLE-BOUNDARY-START(116)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mnhh, $sipl, $stew) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.AspNetCore.WebUtilities", 
    {
  "h": 116,
  "f": "Microsoft.AspNetCore.WebUtilities",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "ASP.NET Core utilities, such as for working with forms, multipart messages, and query strings.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.WebUtilities",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.AspNetCore.WebUtilities",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.AspNetCore.WebUtilities.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.AspNetCore.WebUtilities.Microbenchmarks",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262260)
        $asm.$cls("$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper", ($self) => class ArgumentOutOfRangeThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(34360000628)
            static /*void */ ThrowIfZero(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfZero($.$$.System.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000628)
            
            //--TRIMMABLE-BOUNDARY-START(21475098740)
            static /*void */ ThrowIfNegative(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(21475098740)
            
            //--TRIMMABLE-BOUNDARY-START(25770066036)
            static /*void */ ThrowIfNegative$1(/*long*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(25770066036)
            
            //--TRIMMABLE-BOUNDARY-START(30065033332)
            static /*void */ ThrowIfNegativeOrZero(/*int*/ value, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, value, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(30065033332)
            
            //--TRIMMABLE-BOUNDARY-START(4295229556)
            static /*void */ ThrowIfGreaterThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229556)
            
            //--TRIMMABLE-BOUNDARY-START(8590196852)
            static /*void */ ThrowIfGreaterThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196852)
            
            //--TRIMMABLE-BOUNDARY-START(12885164148)
            static /*void */ ThrowIfLessThan(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164148)
            
            //--TRIMMABLE-BOUNDARY-START(17180131444)
            static /*void */ ThrowIfLessThanOrEqual(T, /*T*/ value, /*T*/ other, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual(T, value, other, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131444)
            
            static $h = 262260;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360000628),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfZero",
      "d": 262260,
      "h": 34360000628,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360000628),
//--TRIMMABLE-BOUNDARY-START(21475098740),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegative",
      "d": 262260,
      "h": 21475098740,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098740),
//--TRIMMABLE-BOUNDARY-START(25770066036),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegative",
      "o": "@$1",
      "d": 262260,
      "h": 25770066036,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770066036),
//--TRIMMABLE-BOUNDARY-START(30065033332),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNegativeOrZero",
      "d": 262260,
      "h": 30065033332,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065033332),
//--TRIMMABLE-BOUNDARY-START(4295229556),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfGreaterThan",
      "d": 262260,
      "h": 4295229556,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295229556),
//--TRIMMABLE-BOUNDARY-START(8590196852),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfGreaterThanOrEqual",
      "d": 262260,
      "h": 8590196852,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590196852),
//--TRIMMABLE-BOUNDARY-START(12885164148),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfLessThan",
      "d": 262260,
      "h": 12885164148,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885164148),
//--TRIMMABLE-BOUNDARY-START(17180131444),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "other",
          "p": (T) => T.$h
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "value",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowIfLessThanOrEqual",
      "d": 262260,
      "h": 17180131444,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180131444)
  ],
  "h": 262260
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentOutOfRangeThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262260)
        
        
        //--TRIMMABLE-BOUNDARY-START(327796)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.Base64UrlTextEncoder", ($self) => class Base64UrlTextEncoder
        {
            //--TRIMMABLE-BOUNDARY-START(8590262388)
            static /*string */ Encode(/*byte[]*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$2(data);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262388)
            
            //--TRIMMABLE-BOUNDARY-START(4295295092)
            static /*byte[] */ Decode(/*string*/ text)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode$2(text);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295092)
            
            static $h = 327796;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262388),
    {
      "r": 1310721,
      "p": [
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "Encode",
      "d": 327796,
      "h": 8590262388,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590262388),
//--TRIMMABLE-BOUNDARY-START(4295295092),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "text",
          "p": 1310721
        }
      ],
      "n": "Decode",
      "d": 327796,
      "h": 4295295092,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295295092)
  ],
  "h": 327796
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Base64UrlTextEncoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327796)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179764)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartReader", ($self) => class MultipartReader extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245820020)
            /*int*/ static DefaultHeadersCountLimit = 16;
            //--TRIMMABLE-BOUNDARY-END(47245820020)
            
            //--TRIMMABLE-BOUNDARY-START(51540787316)
            /*int*/ static DefaultHeadersLengthLimit = 16384;
            //--TRIMMABLE-BOUNDARY-END(51540787316)
            
            //--TRIMMABLE-BOUNDARY-START(42950852724)
            /*int*/ static DefaultBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(42950852724)
            
            //--TRIMMABLE-BOUNDARY-START(12886081652)
            /*BufferedReadStream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(12886081652)
            
            //--TRIMMABLE-BOUNDARY-START(4296147060)
            /*MultipartBoundary*/ _boundary = null;
            //--TRIMMABLE-BOUNDARY-END(4296147060)
            
            //--TRIMMABLE-BOUNDARY-START(8591114356)
            /*MultipartReaderStream?*/ _currentStream = null;
            //--TRIMMABLE-BOUNDARY-END(8591114356)
            
            //--TRIMMABLE-BOUNDARY-START(34360918132)
            $ctor$2(/*string*/ boundary, /*Stream*/ stream)
            {
                this.$ctor$1(boundary, stream, 4096/*DefaultBufferSize*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360918132)
            
            //--TRIMMABLE-BOUNDARY-START(30065950836)
            $ctor$1(/*string*/ boundary, /*Stream*/ stream, /*int*/ bufferSize)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065950836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    if (bufferSize < ((boundary.length + 8) | 0))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("bufferSize", $.$box(bufferSize, $.$$.System.Int32), "Insufficient buffer space, the buffer must be larger than the boundary: " + boundary);
                    }
                    this._stream = new $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream().$ctor$4(stream, bufferSize);
                    boundary = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(new $.$mep.Microsoft.Extensions.Primitives.StringSegment().$ctor$4(boundary)));
                    this._boundary = new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartBoundary().$ctor$1(boundary);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950836)
            
            //--TRIMMABLE-BOUNDARY-START(81605558388)
            /*int*/ HeadersCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(81605558388)
            
            //--TRIMMABLE-BOUNDARY-START(85900525684)
            /*int*/ HeadersLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(85900525684)
            
            //--TRIMMABLE-BOUNDARY-START(38655885428)
            /*long?*/ BodyLengthLimit = null;
            //--TRIMMABLE-BOUNDARY-END(38655885428)
            
            //--TRIMMABLE-BOUNDARY-START(94490460276)
            /*Task<MultipartSection?> *//*async*/  ReadNextSectionAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection), $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490460276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._currentStream ??= (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream()
                        const $t1 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream;
                        const $i1 = new $t1();
                        $i1.$ctor$4(this._stream, this._boundary);
                        $i1.LengthLimit = this.HeadersLengthLimit;
                        return $i1;
                    })();
                    await $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync$2(this._currentStream, cancellationToken);
                    if (this._currentStream.FinalBoundaryFound)
                    {
                        await $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync$1(this._stream, this.HeadersLengthLimit, cancellationToken);
                        return null;
                    }
                    /*var*/ let headers = await this.ReadHeadersAsync(cancellationToken);
                    this._boundary.ExpectLeadingCrlf();
                    this._currentStream = (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream()
                        const $t2 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream;
                        const $i2 = new $t2();
                        $i2.$ctor$4(this._stream, this._boundary);
                        $i2.LengthLimit = this.BodyLengthLimit;
                        return $i2;
                    })();
                    /*long?*/ let baseStreamOffset = this._stream.CanSeek ? $.$cast(this._stream.Position, $.$$.System.Nullable$$($.$$.System.Int64)) : null;
                    return (() =>
                    {
                        //new $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection()
                        const $t3 = $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection;
                        const $i3 = new $t3();
                        $i3.Headers = headers;
                        $i3.Body = this._currentStream;
                        $i3.BaseStreamOffset = baseStreamOffset;
                        return $i3;
                    })();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490460276)
            
            //--TRIMMABLE-BOUNDARY-START(90195492980)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadHeadersAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195492980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*int*/ let totalSize = 0;
                    /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                    /*var*/ let line = await this._stream.ReadLineAsync(this.HeadersLengthLimit, cancellationToken);
                    while(!$.$$.System.String.IsNullOrEmpty(line))
                    {
                        if (((this.HeadersLengthLimit - totalSize) | 0) < line.length)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart headers length limit ${this.HeadersLengthLimit} exceeded.`);
                        }
                        totalSize += line.length;
                        /*int*/ let splitIndex = $.$$.System.String.IndexOf$3.call(line, /*:*/ 58);
                        if (splitIndex <= 0)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Invalid header line: ${line}`);
                        }
                        /*var*/ let name = $.$$.System.String.Substring.call(line, 0, splitIndex);
                        /*var*/ let value = $.$$.System.String.Trim.call($.$$.System.String.Substring.call(line, ((splitIndex + 1) | 0), ((((line.length - splitIndex) | 0) - 1) | 0)));
                        accumulator.Append(name, value);
                        if (accumulator.KeyCount > this.HeadersCountLimit)
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart headers count limit ${this.HeadersCountLimit} exceeded.`);
                        }
                        line = await this._stream.ReadLineAsync(((this.HeadersLengthLimit - totalSize) | 0), cancellationToken);
                    }
                    return accumulator.GetResults();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90195492980)
            
            //default member initializer
            constructor()
            {
                super();
                this.HeadersCountLimit = 16;
                this.HeadersLengthLimit = 16384;
            }
            static $h = 1179764;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605558388),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656500,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670329460,
        "f": 83886081
      },
      "n": "HeadersCountLimit",
      "d": 1179764,
      "h": 81605558388,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605558388),
//--TRIMMABLE-BOUNDARY-START(85900525684),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310591092,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260264052,
        "f": 83886081
      },
      "n": "HeadersLengthLimit",
      "d": 1179764,
      "h": 85900525684,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900525684),
//--TRIMMABLE-BOUNDARY-START(38655885428),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721908,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080394868,
        "f": 83886081
      },
      "n": "BodyLengthLimit",
      "d": 1179764,
      "h": 38655885428,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655885428)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490460276),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadNextSectionAsync",
      "d": 1179764,
      "h": 94490460276,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(94490460276),
//--TRIMMABLE-BOUNDARY-START(90195492980),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadHeadersAsync",
      "d": 1179764,
      "h": 90195492980,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(90195492980)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245820020),
    {
      "t": 655361,
      "n": "DefaultHeadersCountLimit",
      "d": 1179764,
      "h": 47245820020,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245820020),
//--TRIMMABLE-BOUNDARY-START(51540787316),
    {
      "t": 655361,
      "n": "DefaultHeadersLengthLimit",
      "d": 1179764,
      "h": 51540787316,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540787316),
//--TRIMMABLE-BOUNDARY-START(42950852724),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 1179764,
      "h": 42950852724,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42950852724),
//--TRIMMABLE-BOUNDARY-START(12886081652),
    {
      "t": 393332,
      "n": "_stream",
      "d": 1179764,
      "h": 12886081652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081652),
//--TRIMMABLE-BOUNDARY-START(4296147060),
    {
      "t": 1114228,
      "n": "_boundary",
      "d": 1179764,
      "h": 4296147060,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147060),
//--TRIMMABLE-BOUNDARY-START(8591114356),
    {
      "t": 1245300,
      "n": "_currentStream",
      "d": 1179764,
      "h": 8591114356,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114356)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360918132),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179764,
      "h": 34360918132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918132),
//--TRIMMABLE-BOUNDARY-START(30065950836),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        },
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179764,
      "h": 30065950836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065950836)
  ],
  "h": 1179764
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179764)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966196)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders", ($self) => class WebEncoders
        {
            //--TRIMMABLE-BOUNDARY-START(55836541044)
            /*SearchValues<char>*/ static s_base64vsBase64UrlDifferentiators = null;
            //--TRIMMABLE-BOUNDARY-END(55836541044)
            
            //--TRIMMABLE-BOUNDARY-START(17181835380)
            static /*byte[] */ Base64UrlDecode$2(/*string*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode$1(input, 0, input.length);
            }
            //--TRIMMABLE-BOUNDARY-END(17181835380)
            
            //--TRIMMABLE-BOUNDARY-START(12886868084)
            static /*byte[] */ Base64UrlDecode$1(/*string*/ input, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                if (count === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.System.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, inputSpan, $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*-*/ 45) || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*_*/ 95))
                {
                    return $.$$.System.Buffers.Text.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.System.Convert.FromBase64String(input);
                }
                /*var*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [$.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetArraySizeRequiredToDecode(count)], null);
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlDecode(input, offset, buffer, 0, count);
            }
            //--TRIMMABLE-BOUNDARY-END(12886868084)
            
            //--TRIMMABLE-BOUNDARY-START(8591900788)
            static /*byte[] */ Base64UrlDecode(/*string*/ input, /*int*/ offset, /*char[]*/ buffer, /*int*/ bufferOffset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(buffer, "buffer");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(bufferOffset, "bufferOffset");
                if (count === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Byte);
                }
                /*ReadOnlySpan<char>*/ let inputSpan = $.$$.System.MemoryExtensions.AsSpan$1(input, offset, count);
                /*int*/ let indexOfFirstDifferentiator = $.$$.System.MemoryExtensions.IndexOfAny$2($.$$.System.Char, inputSpan, $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.s_base64vsBase64UrlDifferentiators);
                if (indexOfFirstDifferentiator < 0 || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*-*/ 45) || (inputSpan.get_Item(indexOfFirstDifferentiator).$v === /*_*/ 95))
                {
                    return $.$$.System.Buffers.Text.Base64Url.DecodeFromChars$2(inputSpan);
                }
                if (offset === 0 && count === input.length)
                {
                    return $.$$.System.Convert.FromBase64String(input);
                }
                /*var*/ let paddingCharsToAdd = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                /*var*/ let arraySizeRequired = $.$checked(count + paddingCharsToAdd, 1);
                $.$$.System.Diagnostics.Debug.Assert$2(arraySizeRequired % 4 === 0, "Invariant: Array length must be a multiple of 4.");
                if (((buffer.length - bufferOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "bufferOffset", "input"), "count");
                }
                /*var*/ let i = bufferOffset;
                /*Span<char>*/ let bufferSpan = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, buffer, i, count);
                inputSpan.CopyTo(bufferSpan);
                $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, bufferSpan, /*-*/ 45, /*+*/ 43);
                $.$$.System.MemoryExtensions.Replace$3($.$$.System.Char, bufferSpan, /*_*/ 95, /*/*/ 47);
                i += count;
                for(; paddingCharsToAdd > 0; i++, paddingCharsToAdd--)
                {
                    $.$$.System.Array.$WriteT1.call(buffer, /*=*/ 61, i);
                }
                return $.$$.System.Convert.FromBase64CharArray(buffer, bufferOffset, arraySizeRequired);
            }
            //--TRIMMABLE-BOUNDARY-END(8591900788)
            
            //--TRIMMABLE-BOUNDARY-START(42951639156)
            static /*int */ GetArraySizeRequiredToDecode(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951639156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (count === 0)
                {
                    return 0;
                }
                /*var*/ let numPaddingCharsToAdd = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetNumBase64PaddingCharsToAddForDecode(count);
                return $.$checked(count + numPaddingCharsToAdd, 1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951639156)
            
            //--TRIMMABLE-BOUNDARY-START(30066737268)
            static /*string */ Base64UrlEncode$2(/*byte[]*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$1(input, 0, input.length);
            }
            //--TRIMMABLE-BOUNDARY-END(30066737268)
            
            //--TRIMMABLE-BOUNDARY-START(25771769972)
            static /*string */ Base64UrlEncode$1(/*byte[]*/ input, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$4($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, input, offset, count)));
            }
            //--TRIMMABLE-BOUNDARY-END(25771769972)
            
            //--TRIMMABLE-BOUNDARY-START(21476802676)
            static /*int */ Base64UrlEncode(/*byte[]*/ input, /*int*/ offset, /*char[]*/ output, /*int*/ outputOffset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(input, "input");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(output, "output");
                $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.ValidateParameters(input.length, "input", offset, count);
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(outputOffset, "outputOffset");
                /*var*/ let arraySizeRequired = $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.GetArraySizeRequiredToEncode(count);
                if (((output.length - outputOffset) | 0) < arraySizeRequired)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "outputOffset", "output"), "count");
                }
                return $.$maw.Microsoft.AspNetCore.WebUtilities.WebEncoders.Base64UrlEncode$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, input, offset, count)), $.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Char, output, outputOffset));
            }
            //--TRIMMABLE-BOUNDARY-END(21476802676)
            
            //--TRIMMABLE-BOUNDARY-START(47246606452)
            static /*int */ GetArraySizeRequiredToEncode(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let numWholeOrPartialInputBlocks = $.trunc($.$checked(count + 2, 1) / 3);
                return $.$checked(numWholeOrPartialInputBlocks * 4, 1);
            }
            //--TRIMMABLE-BOUNDARY-END(47246606452)
            
            //--TRIMMABLE-BOUNDARY-START(38656671860)
            static /*string */ Base64UrlEncode$4(/*ReadOnlySpan<byte>*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656671860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Buffers.Text.Base64Url.EncodeToString(input);
            }
            //--TRIMMABLE-BOUNDARY-END(38656671860)
            
            //--TRIMMABLE-BOUNDARY-START(34361704564)
            static /*int */ Base64UrlEncode$3(/*ReadOnlySpan<byte>*/ input, /*Span<char>*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361704564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Buffers.Text.Base64Url.EncodeToChars$1(input, output);
            }
            //--TRIMMABLE-BOUNDARY-END(34361704564)
            
            //--TRIMMABLE-BOUNDARY-START(51541573748)
            static /*int */ GetNumBase64PaddingCharsToAddForDecode(/*int*/ inputLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541573748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = inputLength % 4;
                switch($switch1)
                {
                    case 0:
                    return 0;
                    case 2:
                    return 2;
                    case 3:
                    return 1;
                    default:
                    throw new $.$$.System.FormatException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*EncoderResources.WebEncoders_MalformedInput*/, $.$box(inputLength, $.$$.System.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541573748)
            
            //--TRIMMABLE-BOUNDARY-START(60131508340)
            static /*void */ ValidateParameters(/*int*/ bufferLength, /*string*/ inputName, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131508340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(offset, "offset");
                $.$maw.Microsoft.AspNetCore.Shared.ArgumentOutOfRangeThrowHelper.ThrowIfNegative(count, "count");
                if (((bufferLength - offset) | 0) < count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*EncoderResources.WebEncoders_InvalidCountOffsetOrLength*/, "count", "offset", inputName), "count");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131508340)
            
            //--TRIMMABLE-BOUNDARY-START(4296933492)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(55836541044)
                    this.s_base64vsBase64UrlDifferentiators = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("+/-_"));
                    //--TRIMMABLE-BOUNDARY-END(55836541044)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296933492)
            
            static $h = 1966196;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181835380),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDecode",
      "o": "@$2",
      "d": 1966196,
      "h": 17181835380,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181835380),
//--TRIMMABLE-BOUNDARY-START(12886868084),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlDecode",
      "o": "@$1",
      "d": 1966196,
      "h": 12886868084,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886868084),
//--TRIMMABLE-BOUNDARY-START(8591900788),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "input",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "bufferOffset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlDecode",
      "d": 1966196,
      "h": 8591900788,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591900788),
//--TRIMMABLE-BOUNDARY-START(42951639156),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetArraySizeRequiredToDecode",
      "d": 1966196,
      "h": 42951639156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951639156),
//--TRIMMABLE-BOUNDARY-START(30066737268),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$2",
      "d": 1966196,
      "h": 30066737268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066737268),
//--TRIMMABLE-BOUNDARY-START(25771769972),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$1",
      "d": 1966196,
      "h": 25771769972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771769972),
//--TRIMMABLE-BOUNDARY-START(21476802676),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "output",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "outputOffset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Base64UrlEncode",
      "d": 1966196,
      "h": 21476802676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802676),
//--TRIMMABLE-BOUNDARY-START(47246606452),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetArraySizeRequiredToEncode",
      "d": 1966196,
      "h": 47246606452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246606452),
//--TRIMMABLE-BOUNDARY-START(38656671860),
    {
      "r": 1310721,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$4",
      "d": 1966196,
      "h": 38656671860,
      "f": 16777249,
      "a": [
        {
          "t": 132972545,
          "c": 4427939841
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38656671860),
//--TRIMMABLE-BOUNDARY-START(34361704564),
    {
      "r": 655361,
      "p": [
        {
          "n": "input",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "output",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "Base64UrlEncode",
      "o": "@$3",
      "d": 1966196,
      "h": 34361704564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361704564),
//--TRIMMABLE-BOUNDARY-START(51541573748),
    {
      "r": 655361,
      "p": [
        {
          "n": "inputLength",
          "p": 655361
        }
      ],
      "n": "GetNumBase64PaddingCharsToAddForDecode",
      "d": 1966196,
      "h": 51541573748,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541573748),
//--TRIMMABLE-BOUNDARY-START(60131508340),
    {
      "r": 65537,
      "p": [
        {
          "n": "bufferLength",
          "p": 655361
        },
        {
          "n": "inputName",
          "p": 1310721
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateParameters",
      "d": 1966196,
      "h": 60131508340,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60131508340)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836541044),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "s_base64vsBase64UrlDifferentiators",
      "d": 1966196,
      "h": 55836541044,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836541044)
  ],
  "h": 1966196
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `WebEncoders`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966196)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097268)
        $asm.$cls("$maw.Resources", ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(124556148852)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(124556148852)
            
            //--TRIMMABLE-BOUNDARY-START(115966214260)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(115966214260)
            
            //--TRIMMABLE-BOUNDARY-START(120261181556)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491377780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$maw.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.AspNetCore.WebUtilities", $.$maw.Resources.$type.Assembly);
                    $.$maw.Resources.s_resourceManager = temp;
                }
                return $.$maw.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(120261181556)
            
            //--TRIMMABLE-BOUNDARY-START(4297064564)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951770228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146083444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$maw.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064564)
            
            //--TRIMMABLE-BOUNDARY-START(25771901044)
            static /*string */ get FormPipeReader_KeyOrValueTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541704820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form key length limit {0} or value length limit {1} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771901044)
            
            //--TRIMMABLE-BOUNDARY-START(8592031860)
            static /*string */ FormatFormPipeReader_KeyOrValueTooLarge(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Form key length limit {0} or value length limit {1} exceeded.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(8592031860)
            
            //--TRIMMABLE-BOUNDARY-START(30066868340)
            static /*string */ get FormPipeReader_KeyTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131639412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form key length limit {0} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066868340)
            
            //--TRIMMABLE-BOUNDARY-START(12886999156)
            static /*string */ FormatFormPipeReader_KeyTooLarge(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886999156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Form key length limit {0} exceeded.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(12886999156)
            
            //--TRIMMABLE-BOUNDARY-START(34361835636)
            static /*string */ get FormPipeReader_ValueTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721574004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Form value length limit {0} exceeded.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361835636)
            
            //--TRIMMABLE-BOUNDARY-START(17181966452)
            static /*string */ FormatFormPipeReader_ValueTooLarge(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181966452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Form value length limit {0} exceeded.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(17181966452)
            
            //--TRIMMABLE-BOUNDARY-START(107376279668)
            static /*string */ get HttpRequestStreamReader_StreamNotReadable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311508596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The stream must support reading.";
            }
            //--TRIMMABLE-BOUNDARY-END(107376279668)
            
            //--TRIMMABLE-BOUNDARY-START(111671246964)
            static /*string */ get HttpResponseStreamWriter_StreamNotWritable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901443188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The stream must support writing.";
            }
            //--TRIMMABLE-BOUNDARY-END(111671246964)
            
            //--TRIMMABLE-BOUNDARY-START(137441050740)
            static /*string */ get WebEncoders_InvalidCountOffsetOrLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081312372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid {0}, {1} or {2} length.";
            }
            //--TRIMMABLE-BOUNDARY-END(137441050740)
            
            //--TRIMMABLE-BOUNDARY-START(21476933748)
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Invalid {0}, {1} or {2} length.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(21476933748)
            
            static $h = 2097268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120261181556),
    {
      "p": 122814465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491377780,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 2097268,
      "h": 120261181556,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(120261181556),
//--TRIMMABLE-BOUNDARY-START(4297064564),
    {
      "p": 83951617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951770228,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133146083444,
        "f": 83886120
      },
      "n": "Culture",
      "d": 2097268,
      "h": 4297064564,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4297064564),
//--TRIMMABLE-BOUNDARY-START(25771901044),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541704820,
        "f": 50331688
      },
      "n": "FormPipeReader_KeyOrValueTooLarge",
      "d": 2097268,
      "h": 25771901044,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25771901044),
//--TRIMMABLE-BOUNDARY-START(30066868340),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131639412,
        "f": 50331688
      },
      "n": "FormPipeReader_KeyTooLarge",
      "d": 2097268,
      "h": 30066868340,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(30066868340),
//--TRIMMABLE-BOUNDARY-START(34361835636),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721574004,
        "f": 50331688
      },
      "n": "FormPipeReader_ValueTooLarge",
      "d": 2097268,
      "h": 34361835636,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(34361835636),
//--TRIMMABLE-BOUNDARY-START(107376279668),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311508596,
        "f": 50331688
      },
      "n": "HttpRequestStreamReader_StreamNotReadable",
      "d": 2097268,
      "h": 107376279668,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(107376279668),
//--TRIMMABLE-BOUNDARY-START(111671246964),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901443188,
        "f": 50331688
      },
      "n": "HttpResponseStreamWriter_StreamNotWritable",
      "d": 2097268,
      "h": 111671246964,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111671246964),
//--TRIMMABLE-BOUNDARY-START(137441050740),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081312372,
        "f": 50331688
      },
      "n": "WebEncoders_InvalidCountOffsetOrLength",
      "d": 2097268,
      "h": 137441050740,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(137441050740)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592031860),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_KeyOrValueTooLarge",
      "d": 2097268,
      "h": 8592031860,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592031860),
//--TRIMMABLE-BOUNDARY-START(12886999156),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_KeyTooLarge",
      "d": 2097268,
      "h": 12886999156,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886999156),
//--TRIMMABLE-BOUNDARY-START(17181966452),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatFormPipeReader_ValueTooLarge",
      "d": 2097268,
      "h": 17181966452,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181966452),
//--TRIMMABLE-BOUNDARY-START(21476933748),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        },
        {
          "n": "arg3",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_InvalidCountOffsetOrLength",
      "d": 2097268,
      "h": 21476933748,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21476933748)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124556148852),
    {
      "t": 122814465,
      "n": "s_resourceManager",
      "d": 2097268,
      "h": 124556148852,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124556148852),
//--TRIMMABLE-BOUNDARY-START(115966214260),
    {
      "t": 83951617,
      "n": "resourceCulture",
      "d": 2097268,
      "h": 115966214260,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(115966214260)
  ],
  "h": 2097268,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70516737,
      "c": 4365484033
    },
    {
      "t": 125829121,
      "c": 4420796417
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097268)
        
        
        //--TRIMMABLE-BOUNDARY-START(655476)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormMultipartSection", ($self) => class FormMultipartSection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622772)
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            //--TRIMMABLE-BOUNDARY-END(4295622772)
            
            //--TRIMMABLE-BOUNDARY-START(21475491956)
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475491956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475491956)
            
            //--TRIMMABLE-BOUNDARY-START(17180524660)
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180524660);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null || !$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions.IsFormDisposition(header))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Argument must be a form section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524660)
            
            //--TRIMMABLE-BOUNDARY-START(55835230324)
            /*MultipartSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(55835230324)
            
            //--TRIMMABLE-BOUNDARY-START(51540263028)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51540263028)
            
            //--TRIMMABLE-BOUNDARY-START(42950328436)
            /*Task<string> */ GetValueAsync()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950328436);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync$1(this.Section);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950328436)
            
            //--TRIMMABLE-BOUNDARY-START(47245295732)
            /*ValueTask<string> */ GetValueAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245295732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync(this.Section, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245295732)
            
            static $h = 655476;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835230324),
    {
      "p": 1310836,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361140,
        "f": 50331649
      },
      "n": "Section",
      "d": 655476,
      "h": 55835230324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835230324),
//--TRIMMABLE-BOUNDARY-START(51540263028),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426548,
        "f": 50331649
      },
      "n": "Name",
      "d": 655476,
      "h": 51540263028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540263028)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950328436),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "n": "GetValueAsync",
      "d": 655476,
      "h": 42950328436,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328436),
//--TRIMMABLE-BOUNDARY-START(47245295732),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "GetValueAsync",
      "o": "@$1",
      "d": 655476,
      "h": 47245295732,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295732)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622772),
    {
      "t": 196723,
      "n": "_contentDispositionHeader",
      "d": 655476,
      "h": 4295622772,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622772)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491956),
    {
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655476,
      "h": 21475491956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491956),
//--TRIMMABLE-BOUNDARY-START(17180524660),
    {
      "p": [
        {
          "n": "section",
          "p": 1310836
        },
        {
          "n": "header",
          "p": 196723
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655476,
      "h": 17180524660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524660)
  ],
  "h": 655476
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormMultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655476)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031732)
        $asm.$cls("$maw.Microsoft.Extensions.WebEncoders.Sources.EncoderResources", ($self) => class EncoderResources
        {
            //--TRIMMABLE-BOUNDARY-START(12886933620)
            /*string*/ static WebEncoders_InvalidCountOffsetOrLength = null;
            //--TRIMMABLE-BOUNDARY-END(12886933620)
            
            //--TRIMMABLE-BOUNDARY-START(17181900916)
            /*string*/ static WebEncoders_MalformedInput = null;
            //--TRIMMABLE-BOUNDARY-END(17181900916)
            
            //--TRIMMABLE-BOUNDARY-START(4296999028)
            static /*string */ FormatWebEncoders_InvalidCountOffsetOrLength(/*object*/ p0, /*object*/ p1, /*object*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296999028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, "Invalid {0}, {1} or {2} length."/*WebEncoders_InvalidCountOffsetOrLength*/, p0, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(4296999028)
            
            //--TRIMMABLE-BOUNDARY-START(8591966324)
            static /*string */ FormatWebEncoders_MalformedInput(/*object*/ p0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, "Malformed input: {0} is an invalid input length."/*WebEncoders_MalformedInput*/, p0);
            }
            //--TRIMMABLE-BOUNDARY-END(8591966324)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12886933620)
                    this.WebEncoders_InvalidCountOffsetOrLength = "Invalid {0}, {1} or {2} length.";
                    //--TRIMMABLE-BOUNDARY-END(12886933620)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181900916)
                    this.WebEncoders_MalformedInput = "Malformed input: {0} is an invalid input length.";
                    //--TRIMMABLE-BOUNDARY-END(17181900916)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2031732;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296999028),
    {
      "r": 1310721,
      "p": [
        {
          "n": "p0",
          "p": 131073
        },
        {
          "n": "p1",
          "p": 131073
        },
        {
          "n": "p2",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_InvalidCountOffsetOrLength",
      "d": 2031732,
      "h": 4296999028,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296999028),
//--TRIMMABLE-BOUNDARY-START(8591966324),
    {
      "r": 1310721,
      "p": [
        {
          "n": "p0",
          "p": 131073
        }
      ],
      "n": "FormatWebEncoders_MalformedInput",
      "d": 2031732,
      "h": 8591966324,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591966324)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886933620),
    {
      "t": 1310721,
      "n": "WebEncoders_InvalidCountOffsetOrLength",
      "d": 2031732,
      "h": 12886933620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886933620),
//--TRIMMABLE-BOUNDARY-START(17181900916),
    {
      "t": 1310721,
      "n": "WebEncoders_MalformedInput",
      "d": 2031732,
      "h": 17181900916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181900916)
  ],
  "h": 2031732
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `EncoderResources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031732)
        
        
        //--TRIMMABLE-BOUNDARY-START(196724)
        $asm.$cls("$maw.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295164020)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164020)
            
            //--TRIMMABLE-BOUNDARY-START(8590131316)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131316)
            
            static $h = 196724;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164020),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 196724,
      "h": 4295164020,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164020),
//--TRIMMABLE-BOUNDARY-START(8590131316),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 2162804,
              "c": 8592097396,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 196724,
      "h": 8590131316,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131316)
  ],
  "h": 196724
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196724)
        
        
        //--TRIMMABLE-BOUNDARY-START(589940)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileMultipartSection", ($self) => class FileMultipartSection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557236)
            /*ContentDispositionHeaderValue*/ _contentDispositionHeader = null;
            //--TRIMMABLE-BOUNDARY-END(4295557236)
            
            //--TRIMMABLE-BOUNDARY-START(25770393716)
            $ctor$2(/*MultipartSection*/ section)
            {
                this.$ctor$1(section, $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions.GetContentDispositionHeader(section));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393716);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393716)
            
            //--TRIMMABLE-BOUNDARY-START(21475426420)
            $ctor$1(/*MultipartSection*/ section, /*ContentDispositionHeaderValue?*/ header)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null || !$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValueIdentityExtensions.IsFileDisposition(header))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Argument must be a file section", "section");
                    }
                    this.Section = section;
                    this._contentDispositionHeader = header;
                    this.Name = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.Name));
                    this.FileName = $.$mep.Microsoft.Extensions.Primitives.StringSegment.ToString.call($.$mnhh.Microsoft.Net.Http.Headers.HeaderUtilities.RemoveQuotes(this._contentDispositionHeader.FileNameStar.HasValue ? this._contentDispositionHeader.FileNameStar : this._contentDispositionHeader.FileName));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426420)
            
            //--TRIMMABLE-BOUNDARY-START(77310001268)
            /*MultipartSection*/ Section = null;
            //--TRIMMABLE-BOUNDARY-END(77310001268)
            
            //--TRIMMABLE-BOUNDARY-START(34360328308)
            /*Stream? */ get FileStream()
            {
                return this.Section.Body;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328308)
            
            //--TRIMMABLE-BOUNDARY-START(73015033972)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(73015033972)
            
            //--TRIMMABLE-BOUNDARY-START(30065361012)
            /*string*/ FileName = null;
            //--TRIMMABLE-BOUNDARY-END(30065361012)
            
            static $h = 589940;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310001268),
    {
      "p": 1310836,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066676,
        "f": 50331649
      },
      "n": "Section",
      "d": 589940,
      "h": 77310001268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310001268),
//--TRIMMABLE-BOUNDARY-START(34360328308),
    {
      "p": 94961665,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197492,
        "f": 50331649
      },
      "n": "FileStream",
      "d": 589940,
      "h": 34360328308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328308),
//--TRIMMABLE-BOUNDARY-START(73015033972),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132084,
        "f": 50331649
      },
      "n": "Name",
      "d": 589940,
      "h": 73015033972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015033972),
//--TRIMMABLE-BOUNDARY-START(30065361012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262900,
        "f": 50331649
      },
      "n": "FileName",
      "d": 589940,
      "h": 30065361012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065361012)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557236),
    {
      "t": 196723,
      "n": "_contentDispositionHeader",
      "d": 589940,
      "h": 4295557236,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557236)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770393716),
    {
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589940,
      "h": 25770393716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393716),
//--TRIMMABLE-BOUNDARY-START(21475426420),
    {
      "p": [
        {
          "n": "section",
          "p": 1310836
        },
        {
          "n": "header",
          "p": 196723
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589940,
      "h": 21475426420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426420)
  ],
  "h": 589940
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FileMultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589940)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376372)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionConverterExtensions", ($self) => class MultipartSectionConverterExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296343668)
            static /*FileMultipartSection? */ AsFileSection(/*this MultipartSection*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.Microsoft.AspNetCore.WebUtilities.FileMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343668)
            
            //--TRIMMABLE-BOUNDARY-START(8591310964)
            static /*FormMultipartSection? */ AsFormDataSection(/*this MultipartSection*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                try
                {
                    return new $.$maw.Microsoft.AspNetCore.WebUtilities.FormMultipartSection().$ctor$2(section);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591310964)
            
            //--TRIMMABLE-BOUNDARY-START(12886278260)
            static /*ContentDispositionHeaderValue? */ GetContentDispositionHeader(/*this MultipartSection*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let header;
                if (!$.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue.TryParse($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(section.ContentDisposition), $.$ref(() => header, ($v) => header = $v, $.$mnhh.Microsoft.Net.Http.Headers.ContentDispositionHeaderValue)))
                {
                    return null;
                }
                return header;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278260)
            
            static $h = 1376372;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296343668),
    {
      "r": 589940,
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": "AsFileSection",
      "d": 1376372,
      "h": 4296343668,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296343668),
//--TRIMMABLE-BOUNDARY-START(8591310964),
    {
      "r": 655476,
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": "AsFormDataSection",
      "d": 1376372,
      "h": 8591310964,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591310964),
//--TRIMMABLE-BOUNDARY-START(12886278260),
    {
      "r": 196723,
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": "GetContentDispositionHeader",
      "d": 1376372,
      "h": 12886278260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886278260)
  ],
  "h": 1376372
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSectionConverterExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376372)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441908)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions", ($self) => class MultipartSectionStreamExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591376500)
            static /*Task<string> */ ReadAsStringAsync$1(/*this MultipartSection*/ section)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.MultipartSectionStreamExtensions.ReadAsStringAsync(section, $.$$.System.Threading.CancellationToken.None).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591376500)
            
            //--TRIMMABLE-BOUNDARY-START(4296409204)
            static /*ValueTask<string> *//*async*/  ReadAsStringAsync(/*this MultipartSection*/ section, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(section, "section");
                    if (section.Body === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("Multipart section must have a body to be read.", "section");
                    }
                    /*var*/ let sectionMediaType;
                    _ = $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue.TryParse($.$mep.Microsoft.Extensions.Primitives.StringSegment.op_Implicit$2(section.ContentType), $.$ref(() => sectionMediaType, ($v) => sectionMediaType = $v, $.$mnhh.Microsoft.Net.Http.Headers.MediaTypeHeaderValue));
                    /*var*/ let streamEncoding = (sectionMediaType?.Encoding ?? null);
                    if (streamEncoding === null || streamEncoding.CodePage === 65000)
                    {
                        streamEncoding = $.$$.System.Text.Encoding.UTF8;
                    }
                    /*var*/ let reader = new $.$$.System.IO.StreamReader().$ctor$5(section.Body, null, true, 1024, true);
                    try
                    {
                        return await reader.ReadToEndAsync$1(cancellationToken);
                    }
                    finally
                    {
                        reader?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(4296409204)
            
            static $h = 1441908;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591376500),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "p": [
        {
          "n": "section",
          "p": 1310836
        }
      ],
      "n": "ReadAsStringAsync",
      "o": "@$1",
      "d": 1441908,
      "h": 8591376500,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591376500),
//--TRIMMABLE-BOUNDARY-START(4296409204),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String).$h,
      "p": [
        {
          "n": "section",
          "p": 1310836
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsStringAsync",
      "d": 1441908,
      "h": 4296409204,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(4296409204)
  ],
  "h": 1441908
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSectionStreamExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441908)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114228)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartBoundary", ($self) => class MultipartBoundary extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081524)
            /*byte[]*/ _boundaryBytes = null;
            //--TRIMMABLE-BOUNDARY-END(4296081524)
            
            //--TRIMMABLE-BOUNDARY-START(8591048820)
            /*bool*/ _expectLeadingCrlf = false;
            //--TRIMMABLE-BOUNDARY-END(8591048820)
            
            //--TRIMMABLE-BOUNDARY-START(17180983412)
            $ctor$1(/*string*/ boundary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180983412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._expectLeadingCrlf = false;
                    this._boundaryBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8("\r\n--" + boundary);
                    this.FinalBoundaryLength = ((this.BoundaryBytes.Length + 2) | 0);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983412)
            
            //--TRIMMABLE-BOUNDARY-START(30065885300)
            /*void */ ExpectLeadingCrlf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._expectLeadingCrlf = true;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885300)
            
            //--TRIMMABLE-BOUNDARY-START(21475950708)
            /*bool */ BeforeFirstBoundary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._expectLeadingCrlf;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950708)
            
            //--TRIMMABLE-BOUNDARY-START(25770918004)
            /*ReadOnlySpan<byte> */ get BoundaryBytes()
            {
                return $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$12($.$$.System.Byte, this._boundaryBytes, this._expectLeadingCrlf ? 0 : 2));
            }
            //--TRIMMABLE-BOUNDARY-END(25770918004)
            
            //--TRIMMABLE-BOUNDARY-START(34360852596)
            /*int*/ FinalBoundaryLength = 0;
            //--TRIMMABLE-BOUNDARY-END(34360852596)
            
            static $h = 1114228;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770918004),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787188,
        "f": 50331649
      },
      "n": "BoundaryBytes",
      "d": 1114228,
      "h": 25770918004,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770918004),
//--TRIMMABLE-BOUNDARY-START(34360852596),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130656372,
        "f": 83886082
      },
      "n": "FinalBoundaryLength",
      "d": 1114228,
      "h": 34360852596,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360852596)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065885300),
    {
      "r": 65537,
      "n": "ExpectLeadingCrlf",
      "d": 1114228,
      "h": 30065885300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065885300),
//--TRIMMABLE-BOUNDARY-START(21475950708),
    {
      "r": 262145,
      "n": "BeforeFirstBoundary",
      "d": 1114228,
      "h": 21475950708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475950708)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081524),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_boundaryBytes",
      "d": 1114228,
      "h": 4296081524,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081524),
//--TRIMMABLE-BOUNDARY-START(8591048820),
    {
      "t": 262145,
      "n": "_expectLeadingCrlf",
      "d": 1114228,
      "h": 8591048820,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983412),
    {
      "p": [
        {
          "n": "boundary",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114228,
      "h": 17180983412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983412)
  ],
  "h": 1114228
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartBoundary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114228)
        
        
        //--TRIMMABLE-BOUNDARY-START(131188)
        $asm.$cls("$maw.Microsoft.AspNetCore.Internal.UrlDecoder", ($self) => class UrlDecoder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34359869556)
            static /*int */ DecodeRequestLine(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ destination, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (destination.Length < source.Length)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13("Length of the destination byte span is less than the source.", "destination");
                }
                source.CopyTo(destination);
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace(destination.Slice(0, source.Length), isFormEncoding);
            }
            //--TRIMMABLE-BOUNDARY-END(34359869556)
            
            //--TRIMMABLE-BOUNDARY-START(25769934964)
            static /*int */ DecodeInPlace(/*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sourceIndex = 0;
                /*var*/ let destinationIndex = 0;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer.get_Item(sourceIndex).$v === /*+*/ 43 && isFormEncoding)
                    {
                        buffer.get_Item(sourceIndex).$v = 32;
                    }
                    else if (buffer.get_Item(sourceIndex).$v === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeCore($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.System.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer, isFormEncoding))
                        {
                            $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.Copy($.$$.System.Byte, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer.get_Item(destinationIndex++).$v = buffer.get_Item(sourceIndex++).$v;
                    }
                }
                return destinationIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934964)
            
            //--TRIMMABLE-BOUNDARY-START(17180000372)
            static /*bool */ DecodeCore(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let byte1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding$1(sourceIndex, buffer, isFormEncoding);
                if (byte1 === -1)
                {
                    return false;
                }
                if (byte1 === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (byte1 <= 127)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte1, $.$$.System.Byte);
                    return true;
                }
                /*int*/ let byte2 = 0, byte3 = 0, byte4 = 0;
                /*int*/ let currentDecodeBits;
                /*int*/ let byteCount;
                /*int*/ let expectValueMin;
                if ((byte1 & 224) === 192)
                {
                    currentDecodeBits = byte1 & 31;
                    byteCount = 2;
                    expectValueMin = 128;
                }
                else if ((byte1 & 240) === 224)
                {
                    currentDecodeBits = byte1 & 15;
                    byteCount = 3;
                    expectValueMin = 2048;
                }
                else if ((byte1 & 248) === 240)
                {
                    currentDecodeBits = byte1 & 7;
                    byteCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingBytes = ((byteCount - 1) | 0);
                while(remainingBytes > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextByte = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding$1($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.System.Int32), buffer, isFormEncoding);
                    if (nextByte === -1)
                    {
                        return false;
                    }
                    if ((nextByte & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextByte & 63);
                    remainingBytes--;
                    if (remainingBytes === 1 && currentDecodeBits >= 864 && currentDecodeBits <= 895)
                    {
                        return false;
                    }
                    if (remainingBytes === 2 && currentDecodeBits >= 272)
                    {
                        return false;
                    }
                    sourceIndex.$v = nextSourceIndex;
                    if (((byteCount - remainingBytes) | 0) === 2)
                    {
                        byte2 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 3)
                    {
                        byte3 = nextByte;
                    }
                    else if (((byteCount - remainingBytes) | 0) === 4)
                    {
                        byte4 = nextByte;
                    }
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                if (byteCount > 0)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte1, $.$$.System.Byte);
                }
                if (byteCount > 1)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte2, $.$$.System.Byte);
                }
                if (byteCount > 2)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte3, $.$$.System.Byte);
                }
                if (byteCount > 3)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(byte4, $.$$.System.Byte);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000372)
            
            //--TRIMMABLE-BOUNDARY-START(12885033076)
            static /*void */ Copy(T, /*int*/ begin, /*int*/ end, /*ref int*/ writer, /*Span<T>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(begin !== end)
                {
                    buffer.get_Item(writer.$v++).$v = buffer.get_Item(begin++).$v;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033076)
            
            //--TRIMMABLE-BOUNDARY-START(73014575220)
            static /*int */ UnescapePercentEncoding$1(/*ref int*/ scan, /*Span<byte>*/ buffer, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer.get_Item(scan.$v++).$v !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*var*/ let value1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                if (value1 === -1)
                {
                    return -1;
                }
                /*var*/ let value2 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex$1($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                if (value2 === -1)
                {
                    return -1;
                }
                if ($.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.SkipUnescape(value1, value2, isFormEncoding))
                {
                    return -1;
                }
                scan.$v = probe;
                return (((value1 << 4) + value2) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(73014575220)
            
            //--TRIMMABLE-BOUNDARY-START(60129673332)
            static /*int */ ReadHex$1(/*ref int*/ scan, /*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (scan.$v === buffer.Length)
                {
                    return -1;
                }
                /*var*/ let value = buffer.get_Item(scan.$v++).$v;
                /*var*/ let isHex = ((value >= /*0*/ 48) && (value <= /*9*/ 57)) || ((value >= /*A*/ 65) && (value <= /*F*/ 70)) || ((value >= /*a*/ 97) && (value <= /*f*/ 102));
                if (!isHex)
                {
                    return -1;
                }
                if (value <= /*9*/ 57)
                {
                    return value - /*0*/ 48;
                }
                else if (value <= /*F*/ 70)
                {
                    return (((value - /*A*/ 65) + 10) | 0);
                }
                else 
                {
                    return (((value - /*a*/ 97) + 10) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129673332)
            
            //--TRIMMABLE-BOUNDARY-START(64424640628)
            static /*bool */ SkipUnescape(/*int*/ value1, /*int*/ value2, /*bool*/ isFormEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isFormEncoding)
                {
                    return false;
                }
                if (value1 === 2 && value2 === 15)
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64424640628)
            
            //--TRIMMABLE-BOUNDARY-START(38654836852)
            static /*int */ DecodeRequestLine$1(/*ReadOnlySpan<char>*/ source, /*Span<char>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                source.CopyTo(destination);
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace$1(destination.Slice(0, source.Length));
            }
            //--TRIMMABLE-BOUNDARY-END(38654836852)
            
            //--TRIMMABLE-BOUNDARY-START(30064902260)
            static /*int */ DecodeInPlace$1(/*Span<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let position = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer), /*%*/ 37);
                if (position === -1)
                {
                    return buffer.Length;
                }
                /*var*/ let sourceIndex = position;
                /*var*/ let destinationIndex = position;
                while(true)
                {
                    if (sourceIndex === buffer.Length)
                    {
                        break;
                    }
                    if (buffer.get_Item(sourceIndex).$v === /*%*/ 37)
                    {
                        /*var*/ let decodeIndex = sourceIndex;
                        if (!$.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeCore$1($.$ref(() => decodeIndex, ($v) => decodeIndex = $v, $.$$.System.Int32), $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer))
                        {
                            $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.Copy($.$$.System.Char, sourceIndex, decodeIndex, $.$ref(() => destinationIndex, ($v) => destinationIndex = $v, $.$$.System.Int32), buffer);
                        }
                        sourceIndex = decodeIndex;
                    }
                    else 
                    {
                        buffer.get_Item(destinationIndex++).$v = buffer.get_Item(sourceIndex++).$v;
                    }
                }
                return destinationIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902260)
            
            //--TRIMMABLE-BOUNDARY-START(21474967668)
            static /*bool */ DecodeCore$1(/*ref int*/ sourceIndex, /*ref int*/ destinationIndex, /*Span<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let codeUnit1 = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding(sourceIndex, $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer));
                if (codeUnit1 === -1)
                {
                    return false;
                }
                if (codeUnit1 === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("The path contains null characters.");
                }
                if (codeUnit1 <= 127)
                {
                    buffer.get_Item(destinationIndex.$v++).$v = $.$cast(codeUnit1, $.$$.System.Char);
                    return true;
                }
                /*int*/ let currentDecodeBits;
                /*int*/ let codeUnitCount;
                /*int*/ let expectValueMin;
                if ((codeUnit1 & 224) === 192)
                {
                    currentDecodeBits = codeUnit1 & 31;
                    codeUnitCount = 2;
                    expectValueMin = 128;
                }
                else if ((codeUnit1 & 240) === 224)
                {
                    currentDecodeBits = codeUnit1 & 15;
                    codeUnitCount = 3;
                    expectValueMin = 2048;
                }
                else if ((codeUnit1 & 248) === 240)
                {
                    currentDecodeBits = codeUnit1 & 7;
                    codeUnitCount = 4;
                    expectValueMin = 65536;
                }
                else 
                {
                    return false;
                }
                /*var*/ let remainingCodeUnits = ((codeUnitCount - 1) | 0);
                while(remainingCodeUnits > 0)
                {
                    if (sourceIndex.$v === buffer.Length)
                    {
                        return false;
                    }
                    /*var*/ let nextSourceIndex = sourceIndex.$v;
                    /*var*/ let nextCodeUnit = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.UnescapePercentEncoding($.$ref(() => nextSourceIndex, ($v) => nextSourceIndex = $v, $.$$.System.Int32), $.$$.System.Span$$($.$$.System.Char).op_Implicit(buffer));
                    if (nextCodeUnit === -1)
                    {
                        return false;
                    }
                    if ((nextCodeUnit & 192) !== 128)
                    {
                        return false;
                    }
                    currentDecodeBits = (currentDecodeBits << 6) | (nextCodeUnit & 63);
                    remainingCodeUnits--;
                    sourceIndex.$v = nextSourceIndex;
                }
                if (currentDecodeBits < expectValueMin)
                {
                    return false;
                }
                /*var*/ let rune;
                /*var*/ let charsWritten;
                if (!$.$$.System.Text.Rune.TryCreate$2(currentDecodeBits, $.$ref(() => rune, ($v) => rune = $v, $.$$.System.Text.Rune)) || !rune.TryEncodeToUtf16(buffer.Slice$1(destinationIndex.$v), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32)))
                {
                    return false;
                }
                destinationIndex.$v += charsWritten;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967668)
            
            //--TRIMMABLE-BOUNDARY-START(68719607924)
            static /*int */ UnescapePercentEncoding(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tempIdx = scan.$v++;
                if (buffer.get_Item(tempIdx).$v !== /*%*/ 37)
                {
                    return -1;
                }
                /*var*/ let probe = scan.$v;
                /*int*/ let firstNibble = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                /*int*/ let secondNibble = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.ReadHex($.$ref(() => probe, ($v) => probe = $v, $.$$.System.Int32), buffer);
                /*int*/ let value = firstNibble << 4 | secondNibble;
                if (value < 0 || value === /*/*/ 47)
                {
                    return -1;
                }
                scan.$v = probe;
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607924)
            
            //--TRIMMABLE-BOUNDARY-START(55834706036)
            static /*int */ ReadHex(/*ref int*/ scan, /*ReadOnlySpan<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tempIdx = scan.$v++;
                if ((tempIdx >>> 0) >= (buffer.Length >>> 0))
                {
                    return -1;
                }
                /*int*/ let value = buffer.get_Item(tempIdx).$v;
                return $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.FromChar(value);
            }
            //--TRIMMABLE-BOUNDARY-END(55834706036)
            
            //--TRIMMABLE-BOUNDARY-START(42949804148)
            static /*int */ FromChar(/*int*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (c >>> 0) >= ($.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.CharToHexLookup.Length >>> 0) ? -1 : $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.CharToHexLookup.get_Item(c).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804148)
            
            //--TRIMMABLE-BOUNDARY-START(8590065780)
            static /*ReadOnlySpan<sbyte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= $.$$.System.ReadOnlySpan$$($.$$.System.SByte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.SByte), [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(8590065780)
            
            //--TRIMMABLE-BOUNDARY-START(4295098484)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098484)
            
            static $h = 131188;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065780),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.SByte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539738740,
        "f": 50331682
      },
      "n": "CharToHexLookup",
      "d": 131188,
      "h": 8590065780,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(8590065780)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359869556),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeRequestLine",
      "d": 131188,
      "h": 34359869556,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359869556),
//--TRIMMABLE-BOUNDARY-START(25769934964),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeInPlace",
      "d": 131188,
      "h": 25769934964,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934964),
//--TRIMMABLE-BOUNDARY-START(17180000372),
    {
      "r": 262145,
      "p": [
        {
          "n": "sourceIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "destinationIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "DecodeCore",
      "d": 131188,
      "h": 17180000372,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180000372),
//--TRIMMABLE-BOUNDARY-START(12885033076),
    {
      "r": 65537,
      "p": [
        {
          "n": "begin",
          "p": 655361
        },
        {
          "n": "end",
          "p": 655361
        },
        {
          "n": "writer",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": (T) => $.$$.System.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Copy",
      "d": 131188,
      "h": 12885033076,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(12885033076),
//--TRIMMABLE-BOUNDARY-START(73014575220),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "UnescapePercentEncoding",
      "o": "@$1",
      "d": 131188,
      "h": 73014575220,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014575220),
//--TRIMMABLE-BOUNDARY-START(60129673332),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "ReadHex",
      "o": "@$1",
      "d": 131188,
      "h": 60129673332,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129673332),
//--TRIMMABLE-BOUNDARY-START(64424640628),
    {
      "r": 262145,
      "p": [
        {
          "n": "value1",
          "p": 655361
        },
        {
          "n": "value2",
          "p": 655361
        },
        {
          "n": "isFormEncoding",
          "p": 262145
        }
      ],
      "n": "SkipUnescape",
      "d": 131188,
      "h": 64424640628,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424640628),
//--TRIMMABLE-BOUNDARY-START(38654836852),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "DecodeRequestLine",
      "o": "@$1",
      "d": 131188,
      "h": 38654836852,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836852),
//--TRIMMABLE-BOUNDARY-START(30064902260),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "DecodeInPlace",
      "o": "@$1",
      "d": 131188,
      "h": 30064902260,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064902260),
//--TRIMMABLE-BOUNDARY-START(21474967668),
    {
      "r": 262145,
      "p": [
        {
          "n": "sourceIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "destinationIndex",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "DecodeCore",
      "o": "@$1",
      "d": 131188,
      "h": 21474967668,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474967668),
//--TRIMMABLE-BOUNDARY-START(68719607924),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "UnescapePercentEncoding",
      "d": 131188,
      "h": 68719607924,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719607924),
//--TRIMMABLE-BOUNDARY-START(55834706036),
    {
      "r": 655361,
      "p": [
        {
          "n": "scan",
          "p": 655361,
          "f": 4
        },
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "ReadHex",
      "d": 131188,
      "h": 55834706036,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834706036),
//--TRIMMABLE-BOUNDARY-START(42949804148),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 655361
        }
      ],
      "n": "FromChar",
      "d": 131188,
      "h": 42949804148,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949804148)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098484),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131188,
      "h": 4295098484,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098484)
  ],
  "h": 131188
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `UrlDecoder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131188)
        
        
        //--TRIMMABLE-BOUNDARY-START(721012)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader", ($self) => class FormPipeReader extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167504445556)
            /*int*/ static StackAllocThreshold = 128;
            //--TRIMMABLE-BOUNDARY-END(167504445556)
            
            //--TRIMMABLE-BOUNDARY-START(51540328564)
            /*int*/ static DefaultValueCountLimit = 1024;
            //--TRIMMABLE-BOUNDARY-END(51540328564)
            
            //--TRIMMABLE-BOUNDARY-START(47245361268)
            /*int*/ static DefaultKeyLengthLimit = 2048;
            //--TRIMMABLE-BOUNDARY-END(47245361268)
            
            //--TRIMMABLE-BOUNDARY-START(55835295860)
            /*int*/ static DefaultValueLengthLimit = 4194304;
            //--TRIMMABLE-BOUNDARY-END(55835295860)
            
            //--TRIMMABLE-BOUNDARY-START(188979282036)
            static /*ReadOnlySpan<byte> */ get UTF8EqualEncoded()
            {
                return this.$cacheUTF8EqualEncoded ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([61]);
            }
            //--TRIMMABLE-BOUNDARY-END(188979282036)
            
            //--TRIMMABLE-BOUNDARY-START(184684314740)
            static /*ReadOnlySpan<byte> */ get UTF8AndEncoded()
            {
                return this.$cacheUTF8AndEncoded ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([38]);
            }
            //--TRIMMABLE-BOUNDARY-END(184684314740)
            
            //--TRIMMABLE-BOUNDARY-START(12885622900)
            /*byte[]?*/ _otherEqualEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(12885622900)
            
            //--TRIMMABLE-BOUNDARY-START(8590655604)
            /*byte[]?*/ _otherAndEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(8590655604)
            
            //--TRIMMABLE-BOUNDARY-START(17180590196)
            /*PipeReader*/ _pipeReader = null;
            //--TRIMMABLE-BOUNDARY-END(17180590196)
            
            //--TRIMMABLE-BOUNDARY-START(4295688308)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(4295688308)
            
            //--TRIMMABLE-BOUNDARY-START(38655426676)
            $ctor$2(/*PipeReader*/ pipeReader)
            {
                this.$ctor$1(pipeReader, $.$$.System.Text.Encoding.UTF8);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426676)
            
            //--TRIMMABLE-BOUNDARY-START(34360459380)
            $ctor$1(/*PipeReader*/ pipeReader, /*Encoding*/ encoding)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360459380);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encoding !== null && ($.$is(encoding, $.$$.System.Text.Encoding) && encoding.CodePage === 65000))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14("UTF7 is unsupported and insecure. Please select a different encoding.");
                    }
                    this._pipeReader = pipeReader;
                    this._encoding = encoding;
                    if (this._encoding !== $.$$.System.Text.Encoding.UTF8 && this._encoding !== $.$$.System.Text.Encoding.ASCII)
                    {
                        this._otherEqualEncoding = this._encoding.GetBytes$8("=");
                        this._otherAndEncoding = this._encoding.GetBytes$8("&");
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459380)
            
            //--TRIMMABLE-BOUNDARY-START(193274249332)
            /*int*/ ValueCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(193274249332)
            
            //--TRIMMABLE-BOUNDARY-START(120259805300)
            /*int*/ KeyLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(120259805300)
            
            //--TRIMMABLE-BOUNDARY-START(197569216628)
            /*int*/ ValueLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(197569216628)
            
            //--TRIMMABLE-BOUNDARY-START(137439674484)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439674484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*KeyValueAccumulator*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator();
                    while(true)
                    {
                        /*var*/ let readResult = await this._pipeReader.ReadAsync(cancellationToken);
                        /*var*/ let buffer = readResult.Buffer;
                        if (!buffer.IsEmpty)
                        {
                            try
                            {
                                this.ParseFormValues($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte), () => buffer, ($v) => buffer = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null), readResult.IsCompleted);
                            }
                            catch($e)
                            {
                                this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                                throw $e;
                            }
                        }
                        if (readResult.IsCompleted)
                        {
                            this._pipeReader.AdvanceTo$1(buffer.End);
                            if (!buffer.IsEmpty)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12("End of body before form was fully parsed.");
                            }
                            break;
                        }
                        this._pipeReader.AdvanceTo(buffer.Start, buffer.End);
                    }
                    return accumulator.GetResults();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(137439674484)
            
            //--TRIMMABLE-BOUNDARY-START(124554772596)
            /*void */ ParseFormValues(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (buffer.$v.IsSingleSegment)
                {
                    /*var*/ let consumed;
                    this.ParseFormValuesFast(buffer.$v.FirstSpan, accumulator, isFinalBlock, $.$ref(() => consumed, ($v) => consumed = $v, $.$$.System.Int32));
                    buffer.$v = buffer.$v.Slice$4(BigInt(consumed));
                    return;
                }
                this.ParseValuesSlow(buffer, accumulator, isFinalBlock);
            }
            //--TRIMMABLE-BOUNDARY-END(124554772596)
            
            //--TRIMMABLE-BOUNDARY-START(128849739892)
            /*void */ ParseFormValuesFast(/*ReadOnlySpan<byte>*/ span, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock, /*out int*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let key;
                /*ReadOnlySpan<byte>*/ let value;
                consumed.$v = 0;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(span.Length > 0)
                {
                    /*var*/ let ampersand = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, span, andDelimiter);
                    /*ReadOnlySpan<byte>*/ let keyValuePair;
                    /*int*/ let equals;
                    /*var*/ let foundAmpersand = ampersand !== -1;
                    if (foundAmpersand)
                    {
                        keyValuePair = span.Slice(0, ampersand);
                        span = span.Slice$1(((keyValuePair.Length + andDelimiter.Length) | 0));
                        consumed.$v += ((keyValuePair.Length + andDelimiter.Length) | 0);
                    }
                    else 
                    {
                        if (!isFinalBlock)
                        {
                            if ((span.Length >>> 0) > ((((this.KeyLengthLimit >>> 0) + (this.ValueLengthLimit >>> 0)) >>> 0) >>> 0))
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            return;
                        }
                        keyValuePair = span;
                        span = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                        consumed.$v += keyValuePair.Length;
                    }
                    equals = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, keyValuePair, equalsDelimiter);
                    if (equals === -1)
                    {
                        if (keyValuePair.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))();
                    }
                    else 
                    {
                        key = keyValuePair.Slice(0, equals);
                        if (key.Length > this.KeyLengthLimit)
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$1(((equals + equalsDelimiter.Length) | 0));
                        if (value.Length > this.ValueLengthLimit)
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    /*var*/ let decodedKey = this.GetDecodedString(key);
                    /*var*/ let decodedValue = this.GetDecodedString(value);
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849739892)
            
            //--TRIMMABLE-BOUNDARY-START(133144707188)
            /*void */ ParseValuesSlow(/*ref ReadOnlySequence<byte>*/ buffer, /*ref KeyValueAccumulator*/ accumulator, /*bool*/ isFinalBlock)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let sequenceReader = new ($.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte))().$ctor$3(buffer.$v);
                /*ReadOnlySequence<byte>*/ let keyValuePair;
                /*var*/ let consumed = sequenceReader.Position;
                /*var*/ let consumedBytes = 0n;
                /*var*/ let equalsDelimiter = this.GetEqualsForEncoding();
                /*var*/ let andDelimiter = this.GetAndForEncoding();
                while(!sequenceReader.End)
                {
                    if (!sequenceReader.TryReadTo$3($.$ref(() => keyValuePair, ($v) => keyValuePair = $v, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte)), andDelimiter, true))
                    {
                        if (!isFinalBlock)
                        {
                            if ((sequenceReader.Length - consumedBytes) > $.$cast(this.KeyLengthLimit, $.$$.System.Int64) + $.$cast(this.ValueLengthLimit, $.$$.System.Int64) + 2n)
                            {
                                this.ThrowKeyOrValueTooLargeException();
                            }
                            break;
                        }
                        keyValuePair = buffer.$v.Slice$8(sequenceReader.Position);
                        sequenceReader.Advance(keyValuePair.Length);
                    }
                    if (keyValuePair.IsSingleSegment)
                    {
                        /*var*/ let segmentConsumed;
                        this.ParseFormValuesFast(keyValuePair.FirstSpan, accumulator, true, $.$ref(() => segmentConsumed, ($v) => segmentConsumed = $v, $.$$.System.Int32));
                        $.$$.System.Diagnostics.Debug.Assert$2(segmentConsumed === keyValuePair.FirstSpan.Length, "segmentConsumed == keyValuePair.FirstSpan.Length");
                        consumedBytes = sequenceReader.Consumed;
                        consumed = sequenceReader.Position;
                        continue;
                    }
                    /*var*/ let keyValueReader = new ($.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte))().$ctor$3(keyValuePair);
                    /*ReadOnlySequence<byte>*/ let value;
                    /*ReadOnlySequence<byte>*/ let key;
                    if (keyValueReader.TryReadTo$3($.$ref(() => key, ($v) => key = $v, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte)), equalsDelimiter, true))
                    {
                        if (key.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        value = keyValuePair.Slice$8(keyValueReader.Position);
                        if (value.Length > BigInt(this.ValueLengthLimit))
                        {
                            this.ThrowValueTooLargeException();
                        }
                    }
                    else 
                    {
                        if (keyValuePair.Length > BigInt(this.KeyLengthLimit))
                        {
                            this.ThrowKeyTooLargeException();
                        }
                        key = keyValuePair;
                        value = new ($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte))();
                    }
                    /*var*/ let decodedKey = this.GetDecodedStringFromReadOnlySequence($.$ref(() => key, ));
                    /*var*/ let decodedValue = this.GetDecodedStringFromReadOnlySequence($.$ref(() => value, ));
                    this.AppendAndVerify(accumulator, decodedKey, decodedValue);
                    consumedBytes = sequenceReader.Consumed;
                    consumed = sequenceReader.Position;
                }
                buffer.$v = buffer.$v.Slice$8(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(133144707188)
            
            //--TRIMMABLE-BOUNDARY-START(171799412852)
            /*void */ ThrowKeyOrValueTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799412852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyOrValueTooLarge, $.$box(this.KeyLengthLimit, $.$$.System.Int32), $.$box(this.ValueLengthLimit, $.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(171799412852)
            
            //--TRIMMABLE-BOUNDARY-START(176094380148)
            /*void */ ThrowKeyTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_KeyTooLarge, $.$box(this.KeyLengthLimit, $.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(176094380148)
            
            //--TRIMMABLE-BOUNDARY-START(180389347444)
            /*void */ ThrowValueTooLargeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.IO.InvalidDataException().$ctor$12($.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, $.$maw.Resources.FormPipeReader_ValueTooLarge, $.$box(this.ValueLengthLimit, $.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(180389347444)
            
            //--TRIMMABLE-BOUNDARY-START(111669870708)
            /*string */ GetDecodedStringFromReadOnlySequence(/*in ReadOnlySequence<byte>*/ ros)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (ros.$v.IsSingleSegment)
                {
                    return this.GetDecodedString(ros.$v.FirstSpan);
                }
                if (ros.$v.Length < BigInt(128/*StackAllocThreshold*/))
                {
                    /*Span<byte>*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 128/*StackAllocThreshold*/, null).Slice(0, $.$cast(ros.$v.Length, $.$$.System.Int32));
                    $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Byte, $.$ref(() => ros, ), buffer);
                    return this.GetDecodedString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer));
                }
                else 
                {
                    /*var*/ let byteArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent($.$cast(ros.$v.Length, $.$$.System.Int32));
                    try
                    {
                        /*Span<byte>*/ let buffer = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, byteArray, 0, $.$cast(ros.$v.Length, $.$$.System.Int32));
                        $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Byte, $.$ref(() => ros, ), buffer);
                        return this.GetDecodedString($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer));
                    }
                    finally
                    {
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(byteArray, false);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669870708)
            
            //--TRIMMABLE-BOUNDARY-START(42950393972)
            /*void */ AppendAndVerify(/*ref KeyValueAccumulator*/ accumulator, /*string*/ decodedKey, /*string*/ decodedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                accumulator.$v.Append(decodedKey, decodedValue);
                if (accumulator.$v.ValueCount > this.ValueCountLimit)
                {
                    throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form value count limit ${this.ValueCountLimit} exceeded.`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393972)
            
            //--TRIMMABLE-BOUNDARY-START(107374903412)
            /*string */ GetDecodedString(/*ReadOnlySpan<byte>*/ readOnlySpan)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (readOnlySpan.Length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                else if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    /*var*/ let span = $.$$.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, readOnlySpan), readOnlySpan.Length);
                    try
                    {
                        /*var*/ let bytes = $.$maw.Microsoft.AspNetCore.Internal.UrlDecoder.DecodeInPlace(span, true);
                        span = span.Slice(0, bytes);
                        return this._encoding.GetString$3($.$$.System.Span$$($.$$.System.Byte).op_Implicit(span));
                    }
                    catch(ex)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$11("The form value contains invalid characters.", ex);
                    }
                }
                else 
                {
                    /*var*/ let decodedString = this._encoding.GetString$3(readOnlySpan);
                    decodedString = $.$$.System.String.Replace.call(decodedString, /*+*/ 43, /* */ 32);
                    return $.$spu.System.Uri.UnescapeDataString$2(decodedString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374903412)
            
            //--TRIMMABLE-BOUNDARY-START(115964838004)
            /*ReadOnlySpan<byte> */ GetEqualsForEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964838004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader.UTF8EqualEncoded;
                }
                else 
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(this._otherEqualEncoding);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964838004)
            
            //--TRIMMABLE-BOUNDARY-START(103079936116)
            /*ReadOnlySpan<byte> */ GetAndForEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._encoding === $.$$.System.Text.Encoding.UTF8 || this._encoding === $.$$.System.Text.Encoding.ASCII)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.FormPipeReader.UTF8AndEncoded;
                }
                else 
                {
                    return $.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(this._otherAndEncoding);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936116)
            
            //default member initializer
            constructor()
            {
                super();
                this.ValueCountLimit = 1024;
                this.KeyLengthLimit = 2048;
                this.ValueLengthLimit = 4194304;
            }
            static $h = 721012;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(188979282036),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099636,
        "f": 50331682
      },
      "n": "UTF8EqualEncoded",
      "d": 721012,
      "h": 188979282036,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(188979282036),
//--TRIMMABLE-BOUNDARY-START(184684314740),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015165044,
        "f": 50331682
      },
      "n": "UTF8AndEncoded",
      "d": 721012,
      "h": 184684314740,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(184684314740),
//--TRIMMABLE-BOUNDARY-START(193274249332),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619543668,
        "f": 83886081
      },
      "n": "ValueCountLimit",
      "d": 721012,
      "h": 193274249332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274249332),
//--TRIMMABLE-BOUNDARY-START(120259805300),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230452,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029609076,
        "f": 83886081
      },
      "n": "KeyLengthLimit",
      "d": 721012,
      "h": 120259805300,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259805300),
//--TRIMMABLE-BOUNDARY-START(197569216628),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209478260,
        "f": 83886081
      },
      "n": "ValueLengthLimit",
      "d": 721012,
      "h": 197569216628,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569216628)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439674484),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadFormAsync",
      "d": 721012,
      "h": 137439674484,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(137439674484),
//--TRIMMABLE-BOUNDARY-START(124554772596),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "accumulator",
          "p": 1048692,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "ParseFormValues",
      "d": 721012,
      "h": 124554772596,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(124554772596),
//--TRIMMABLE-BOUNDARY-START(128849739892),
    {
      "r": 65537,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "accumulator",
          "p": 1048692,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        },
        {
          "n": "consumed",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "ParseFormValuesFast",
      "d": 721012,
      "h": 128849739892,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849739892),
//--TRIMMABLE-BOUNDARY-START(133144707188),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "accumulator",
          "p": 1048692,
          "f": 4
        },
        {
          "n": "isFinalBlock",
          "p": 262145
        }
      ],
      "n": "ParseValuesSlow",
      "d": 721012,
      "h": 133144707188,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707188),
//--TRIMMABLE-BOUNDARY-START(171799412852),
    {
      "r": 65537,
      "n": "ThrowKeyOrValueTooLargeException",
      "d": 721012,
      "h": 171799412852,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171799412852),
//--TRIMMABLE-BOUNDARY-START(176094380148),
    {
      "r": 65537,
      "n": "ThrowKeyTooLargeException",
      "d": 721012,
      "h": 176094380148,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094380148),
//--TRIMMABLE-BOUNDARY-START(180389347444),
    {
      "r": 65537,
      "n": "ThrowValueTooLargeException",
      "d": 721012,
      "h": 180389347444,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389347444),
//--TRIMMABLE-BOUNDARY-START(111669870708),
    {
      "r": 1310721,
      "p": [
        {
          "n": "ros",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 8
        }
      ],
      "n": "GetDecodedStringFromReadOnlySequence",
      "d": 721012,
      "h": 111669870708,
      "f": 16777218,
      "a": [
        {
          "t": 132972545,
          "c": 4427939841
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669870708),
//--TRIMMABLE-BOUNDARY-START(42950393972),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulator",
          "p": 1048692,
          "f": 4
        },
        {
          "n": "decodedKey",
          "p": 1310721
        },
        {
          "n": "decodedValue",
          "p": 1310721
        }
      ],
      "n": "AppendAndVerify",
      "d": 721012,
      "h": 42950393972,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393972),
//--TRIMMABLE-BOUNDARY-START(107374903412),
    {
      "r": 1310721,
      "p": [
        {
          "n": "readOnlySpan",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetDecodedString",
      "d": 721012,
      "h": 107374903412,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374903412),
//--TRIMMABLE-BOUNDARY-START(115964838004),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "n": "GetEqualsForEncoding",
      "d": 721012,
      "h": 115964838004,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964838004),
//--TRIMMABLE-BOUNDARY-START(103079936116),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "n": "GetAndForEncoding",
      "d": 721012,
      "h": 103079936116,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079936116)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167504445556),
    {
      "t": 655361,
      "n": "StackAllocThreshold",
      "d": 721012,
      "h": 167504445556,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167504445556),
//--TRIMMABLE-BOUNDARY-START(51540328564),
    {
      "t": 655361,
      "n": "DefaultValueCountLimit",
      "d": 721012,
      "h": 51540328564,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51540328564),
//--TRIMMABLE-BOUNDARY-START(47245361268),
    {
      "t": 655361,
      "n": "DefaultKeyLengthLimit",
      "d": 721012,
      "h": 47245361268,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245361268),
//--TRIMMABLE-BOUNDARY-START(55835295860),
    {
      "t": 655361,
      "n": "DefaultValueLengthLimit",
      "d": 721012,
      "h": 55835295860,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835295860),
//--TRIMMABLE-BOUNDARY-START(12885622900),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_otherEqualEncoding",
      "d": 721012,
      "h": 12885622900,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622900),
//--TRIMMABLE-BOUNDARY-START(8590655604),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_otherAndEncoding",
      "d": 721012,
      "h": 8590655604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655604),
//--TRIMMABLE-BOUNDARY-START(17180590196),
    {
      "t": 1376337,
      "n": "_pipeReader",
      "d": 721012,
      "h": 17180590196,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590196),
//--TRIMMABLE-BOUNDARY-START(4295688308),
    {
      "t": 165937153,
      "n": "_encoding",
      "d": 721012,
      "h": 4295688308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688308)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426676),
    {
      "p": [
        {
          "n": "pipeReader",
          "p": 1376337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 721012,
      "h": 38655426676,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426676),
//--TRIMMABLE-BOUNDARY-START(34360459380),
    {
      "p": [
        {
          "n": "pipeReader",
          "p": 1376337
        },
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721012,
      "h": 34360459380,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360459380)
  ],
  "h": 721012
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `FormPipeReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721012)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900660)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions", ($self) => class StreamHelperExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296867956)
            /*int*/ static _maxReadBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(4296867956)
            
            //--TRIMMABLE-BOUNDARY-START(17181769844)
            static /*Task */ DrainAsync$2(/*this Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync(stream, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(17181769844)
            
            //--TRIMMABLE-BOUNDARY-START(12886802548)
            static /*Task */ DrainAsync$1(/*this Stream*/ stream, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886802548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$maw.Microsoft.AspNetCore.WebUtilities.StreamHelperExtensions.DrainAsync(stream, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, limit, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(12886802548)
            
            //--TRIMMABLE-BOUNDARY-START(8591835252)
            static /*Task *//*async*/  DrainAsync(/*this Stream*/ stream, /*ArrayPool<byte>*/ bytePool, /*long?*/ limit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    /*var*/ let buffer = bytePool.Rent(4096/*_maxReadBufferSize*/);
                    /*long*/ let total = 0n;
                    try
                    {
                        /*var*/ let read = await stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, buffer), cancellationToken);
                        while(read > 0)
                        {
                            cancellationToken.ThrowIfCancellationRequested();
                            if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(limit) && $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(limit) - total < BigInt(read))
                            {
                                throw new $.$$.System.IO.InvalidDataException().$ctor$12(`The stream exceeded the data limit ${$.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(limit)}.`);
                            }
                            total += BigInt(read);
                            read = await stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, buffer), cancellationToken);
                        }
                    }
                    finally
                    {
                        {
                            bytePool.Return(buffer, false);
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(8591835252)
            
            static $h = 1900660;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181769844),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "DrainAsync",
      "o": "@$2",
      "d": 1900660,
      "h": 17181769844,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181769844),
//--TRIMMABLE-BOUNDARY-START(12886802548),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "limit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "DrainAsync",
      "o": "@$1",
      "d": 1900660,
      "h": 12886802548,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886802548),
//--TRIMMABLE-BOUNDARY-START(8591835252),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        },
        {
          "n": "limit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "DrainAsync",
      "d": 1900660,
      "h": 8591835252,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(8591835252)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867956),
    {
      "t": 655361,
      "n": "_maxReadBufferSize",
      "d": 1900660,
      "h": 4296867956,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296867956)
  ],
  "h": 1900660
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StreamHelperExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900660)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835124)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.ReasonPhrases", ($self) => class ReasonPhrases
        {
            //--TRIMMABLE-BOUNDARY-START(12886737012)
            /*string[][]*/ static HttpReasonPhrases = null;
            //--TRIMMABLE-BOUNDARY-END(12886737012)
            
            //--TRIMMABLE-BOUNDARY-START(8591769716)
            static /*string */ GetReasonPhrase(/*int*/ statusCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591769716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (((((statusCode - 100) | 0)) >>> 0) < 500)
                {
                    /*var*/ let  [ i, j ] = $.$destructure($.$$.System.Math.DivRem$9((statusCode >>> 0), 100));
                    /*string[]*/ let phrases = $.$$.System.Array.$ReadT1.call($.$maw.Microsoft.AspNetCore.WebUtilities.ReasonPhrases.HttpReasonPhrases, i);
                    if (j < (phrases.length >>> 0))
                    {
                        return $.$$.System.Array.$ReadT1.call(phrases, j);
                    }
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(8591769716)
            
            //--TRIMMABLE-BOUNDARY-START(4296802420)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12886737012)
                    this.HttpReasonPhrases = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeArray($.$$.System.String).$type, [ $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [  ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Continue", "Switching Protocols", "Processing" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "OK", "Created", "Accepted", "Non-Authoritative Information", "No Content", "Reset Content", "Partial Content", "Multi-Status", "Already Reported", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "IM Used" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Multiple Choices", "Moved Permanently", "Found", "See Other", "Not Modified", "Use Proxy", "Switch Proxy", "Temporary Redirect", "Permanent Redirect" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Bad Request", "Unauthorized", "Payment Required", "Forbidden", "Not Found", "Method Not Allowed", "Not Acceptable", "Proxy Authentication Required", "Request Timeout", "Conflict", "Gone", "Length Required", "Precondition Failed", "Payload Too Large", "URI Too Long", "Unsupported Media Type", "Range Not Satisfiable", "Expectation Failed", "I'm a teapot", "Authentication Timeout", $.$$.System.String.Empty, "Misdirected Request", "Unprocessable Entity", "Locked", "Failed Dependency", $.$$.System.String.Empty, "Upgrade Required", $.$$.System.String.Empty, "Precondition Required", "Too Many Requests", $.$$.System.String.Empty, "Request Header Fields Too Large", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "Unavailable For Legal Reasons", $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty, "Client Closed Request" ], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.String.$type, [ "Internal Server Error", "Not Implemented", "Bad Gateway", "Service Unavailable", "Gateway Timeout", "HTTP Version Not Supported", "Variant Also Negotiates", "Insufficient Storage", "Loop Detected", $.$$.System.String.Empty, "Not Extended", "Network Authentication Required" ], null, null) ], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12886737012)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802420)
            
            static $h = 1835124;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591769716),
    {
      "r": 1310721,
      "p": [
        {
          "n": "statusCode",
          "p": 655361
        }
      ],
      "n": "GetReasonPhrase",
      "d": 1835124,
      "h": 8591769716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591769716)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886737012),
    {
      "t": $.$typeArray($.$typeArray($.$$.System.String)).$h,
      "n": "HttpReasonPhrases",
      "d": 1835124,
      "h": 12886737012,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886737012)
  ],
  "h": 1835124
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ReasonPhrases`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835124)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310836)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartSection", ($self) => class MultipartSection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361049204)
            /*string? */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let values;
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.Microsoft.Net.Http.Headers.HeaderNames.ContentType, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit(values);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049204)
            
            //--TRIMMABLE-BOUNDARY-START(30066081908)
            /*string? */ get ContentDisposition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let values;
                if (this.Headers !== null && this.Headers.TryGetValue($.$mnhh.Microsoft.Net.Http.Headers.HeaderNames.ContentDisposition, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    return $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit(values);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081908)
            
            //--TRIMMABLE-BOUNDARY-START(81605689460)
            /*Dictionary<string, StringValues>?*/ Headers = null;
            //--TRIMMABLE-BOUNDARY-END(81605689460)
            
            //--TRIMMABLE-BOUNDARY-START(25771114612)
            /*Stream*/ Body = null;
            //--TRIMMABLE-BOUNDARY-END(25771114612)
            
            //--TRIMMABLE-BOUNDARY-START(21476147316)
            /*long?*/ BaseStreamOffset = null;
            //--TRIMMABLE-BOUNDARY-END(21476147316)
            
            //--TRIMMABLE-BOUNDARY-START(17181180020)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181180020)
            
            //default member initializer
            constructor()
            {
                super();
                this.Body = null;
            }
            static $h = 1310836;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049204),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720787572,
        "f": 50331649
      },
      "n": "ContentType",
      "d": 1310836,
      "h": 34361049204,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049204),
//--TRIMMABLE-BOUNDARY-START(30066081908),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130852980,
        "f": 50331649
      },
      "n": "ContentDisposition",
      "d": 1310836,
      "h": 30066081908,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081908),
//--TRIMMABLE-BOUNDARY-START(81605689460),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310722164,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375493236,
        "f": 83886081
      },
      "n": "Headers",
      "d": 1310836,
      "h": 81605689460,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605689460),
//--TRIMMABLE-BOUNDARY-START(25771114612),
    {
      "p": 94961665,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918388,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785558644,
        "f": 83886081
      },
      "n": "Body",
      "d": 1310836,
      "h": 25771114612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771114612),
//--TRIMMABLE-BOUNDARY-START(21476147316),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983796,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195624052,
        "f": 83886081
      },
      "n": "BaseStreamOffset",
      "d": 1310836,
      "h": 21476147316,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476147316)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181180020),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310836,
      "h": 17181180020,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181180020)
  ],
  "h": 1310836
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `MultipartSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310836)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572980)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers", ($self) => class QueryHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(17181442164)
            static /*string */ AddQueryString$3(/*string*/ uri, /*string*/ name, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(name, "name");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)), [new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(name, value)], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(17181442164)
            
            //--TRIMMABLE-BOUNDARY-START(4296540276)
            static /*string */ AddQueryString(/*string*/ uri, /*IDictionary<string, string?>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, queryString);
            }
            //--TRIMMABLE-BOUNDARY-END(4296540276)
            
            //--TRIMMABLE-BOUNDARY-START(12886474868)
            static /*string */ AddQueryString$2(/*string*/ uri, /*IEnumerable<KeyValuePair<string, StringValues>>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString$1(uri, $.$sl.System.Linq.Enumerable.SelectMany($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.String, $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String), queryString, new ($.$$.System.Func$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String)))().$ctor(this,  (/*kvp*/ kvp) =>
                {
                    return kvp.Value;
                }, {
  "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
  "p": [
    {
      "n": "kvp",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h
    }
  ],
  "n": "",
  "d": 1572980,
  "h": 0,
  "f": 17825794
}), new ($.$$.System.Func$$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), $.$$.System.String, $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)))().$ctor(this,  (/*kvp*/ kvp, /*v*/ v) =>
                {
                    return $.$$.System.Collections.Generic.KeyValuePair.Create($.$$.System.String, $.$$.System.String, kvp.Key, v);
                }, {
  "r": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String).$h,
  "p": [
    {
      "n": "kvp",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h
    },
    {
      "n": "v",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 1572980,
  "h": 0,
  "f": 17825794
})));
            }
            //--TRIMMABLE-BOUNDARY-END(12886474868)
            
            //--TRIMMABLE-BOUNDARY-START(8591507572)
            static /*string */ AddQueryString$1(/*string*/ uri, /*IEnumerable<KeyValuePair<string, string?>>*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591507572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queryString, "queryString");
                /*var*/ let anchorIndex = $.$$.System.String.IndexOf$3.call(uri, /*#*/ 35);
                /*var*/ let uriToBeAppended = $.$$.System.MemoryExtensions.AsSpan$4(uri);
                /*var*/ let anchorText = $.$$.System.ReadOnlySpan$$($.$$.System.Char).Empty;
                if (anchorIndex !== -1)
                {
                    anchorText = uriToBeAppended.Slice$1(anchorIndex);
                    uriToBeAppended = uriToBeAppended.Slice(0, anchorIndex);
                }
                /*var*/ let queryIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, uriToBeAppended, /*?*/ 63);
                /*var*/ let hasQuery = queryIndex !== -1;
                /*var*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.Append$15(uriToBeAppended);
                var $en2 = queryString.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var parameter = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.op_Equality(parameter.Value, null))
                        {
                            continue;
                        }
                        sb.Append$3(hasQuery ? /*&*/ 38 : /*?*/ 63);
                        sb.Append$19($.$stew.System.Text.Encodings.Web.UrlEncoder.Default.Encode$4(parameter.Key));
                        sb.Append$3(/*=*/ 61);
                        sb.Append$19($.$stew.System.Text.Encodings.Web.UrlEncoder.Default.Encode$4(parameter.Value));
                        hasQuery = true;
                    }
                }
                sb.Append$15(anchorText);
                return $.$$.System.Text.StringBuilder.ToString.call(sb);
            }
            //--TRIMMABLE-BOUNDARY-END(8591507572)
            
            //--TRIMMABLE-BOUNDARY-START(25771376756)
            static /*Dictionary<string, StringValues> */ ParseQuery(/*string?*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let result = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryHelpers.ParseNullableQuery(queryString);
                if (result === null)
                {
                    return new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$1();
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376756)
            
            //--TRIMMABLE-BOUNDARY-START(21476409460)
            static /*Dictionary<string, StringValues>? */ ParseNullableQuery(/*string?*/ queryString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476409460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                /*var*/ let enumerable = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable().$ctor$4(queryString);
                var $en2 = enumerable.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var pair = $en2.Current;
                    {
                        accumulator.Append($.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(pair.DecodeName()), $.$$.System.ReadOnlyMemory$$($.$$.System.Char).ToString.call(pair.DecodeValue()));
                    }
                }
                if (!accumulator.HasValues)
                {
                    return null;
                }
                return accumulator.GetResults();
            }
            //--TRIMMABLE-BOUNDARY-END(21476409460)
            
            static $h = 1572980;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181442164),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "AddQueryString",
      "o": "@$3",
      "d": 1572980,
      "h": 17181442164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181442164),
//--TRIMMABLE-BOUNDARY-START(4296540276),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        }
      ],
      "n": "AddQueryString",
      "d": 1572980,
      "h": 4296540276,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296540276),
//--TRIMMABLE-BOUNDARY-START(12886474868),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h
        }
      ],
      "n": "AddQueryString",
      "o": "@$2",
      "d": 1572980,
      "h": 12886474868,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886474868),
//--TRIMMABLE-BOUNDARY-START(8591507572),
    {
      "r": 1310721,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        },
        {
          "n": "queryString",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h
        }
      ],
      "n": "AddQueryString",
      "o": "@$1",
      "d": 1572980,
      "h": 8591507572,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591507572),
//--TRIMMABLE-BOUNDARY-START(25771376756),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": "ParseQuery",
      "d": 1572980,
      "h": 25771376756,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771376756),
//--TRIMMABLE-BOUNDARY-START(21476409460),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": "ParseNullableQuery",
      "d": 1572980,
      "h": 21476409460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476409460)
  ],
  "h": 1572980
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `QueryHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572980)
        
        
        //--TRIMMABLE-BOUNDARY-START(65652)
        $asm.$cls("$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory", ($self) => class AspNetCoreTempDirectory
        {
            //--TRIMMABLE-BOUNDARY-START(4295032948)
            /*string?*/ static _tempDirectory = null;
            //--TRIMMABLE-BOUNDARY-END(4295032948)
            
            //--TRIMMABLE-BOUNDARY-START(25769869428)
            static /*string */ get TempDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality($.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory, null))
                {
                    /*var*/ let temp = $.$$.System.Environment.GetEnvironmentVariable$1("ASPNETCORE_TEMP") ?? $.$$.System.IO.Path.GetTempPath();
                    if (!$.$$.System.IO.Directory.Exists(temp))
                    {
                        throw new $.$$.System.IO.DirectoryNotFoundException().$ctor$17(temp);
                    }
                    $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory = temp;
                }
                return $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory._tempDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869428)
            
            //--TRIMMABLE-BOUNDARY-START(30064836724)
            static /*Func<string> */ get TempDirectoryFactory()
            {
                return new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectory;
                }, {
  "r": 1310721,
  "n": "",
  "d": 65652,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(30064836724)
            
            static $h = 65652;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769869428),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12884967540,
        "f": 50331681
      },
      "n": "TempDirectory",
      "d": 65652,
      "h": 25769869428,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25769869428),
//--TRIMMABLE-BOUNDARY-START(30064836724),
    {
      "p": $.$$.System.Func$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902132,
        "f": 50331681
      },
      "n": "TempDirectoryFactory",
      "d": 65652,
      "h": 30064836724,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032948),
    {
      "t": 1310721,
      "n": "_tempDirectory",
      "d": 65652,
      "h": 4295032948,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032948)
  ],
  "h": 65652
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AspNetCoreTempDirectory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65652)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507444)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.PagedByteBuffer", ($self) => class PagedByteBuffer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(115965624436)
            /*int*/ static PageSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(115965624436)
            
            //--TRIMMABLE-BOUNDARY-START(4296474740)
            /*ArrayPool<byte>*/ _arrayPool = null;
            //--TRIMMABLE-BOUNDARY-END(4296474740)
            
            //--TRIMMABLE-BOUNDARY-START(8591442036)
            /*byte[]?*/ _currentPage = null;
            //--TRIMMABLE-BOUNDARY-END(8591442036)
            
            //--TRIMMABLE-BOUNDARY-START(12886409332)
            /*int*/ _currentPageIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(12886409332)
            
            //--TRIMMABLE-BOUNDARY-START(30066278516)
            $ctor$1(/*ArrayPool<byte>*/ arrayPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066278516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayPool = arrayPool;
                    this.Pages = new ($.$$.System.Collections.Generic.List$$($.$typeArray($.$$.System.Byte)))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278516)
            
            //--TRIMMABLE-BOUNDARY-START(94490787956)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(94490787956)
            
            //--TRIMMABLE-BOUNDARY-START(55836082292)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(55836082292)
            
            //--TRIMMABLE-BOUNDARY-START(111670657140)
            /*List<byte[]>*/ Pages = null;
            //--TRIMMABLE-BOUNDARY-END(111670657140)
            
            //--TRIMMABLE-BOUNDARY-START(47246147700)
            /*byte[] */ get CurrentPage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._currentPage === null || this._currentPageIndex === this._currentPage.length)
                {
                    this._currentPage = this._arrayPool.Rent(1024/*PageSize*/);
                    this.Pages.Add(this._currentPage);
                    this._currentPageIndex = 0;
                }
                return this._currentPage;
            }
            //--TRIMMABLE-BOUNDARY-END(47246147700)
            
            //--TRIMMABLE-BOUNDARY-START(34361245812)
            /*void */ Add(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add$1($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245812)
            
            //--TRIMMABLE-BOUNDARY-START(38656213108)
            /*void */ Add$1(/*ReadOnlyMemory<byte>*/ memory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                while(!memory.IsEmpty)
                {
                    /*var*/ let currentPage = this.CurrentPage;
                    /*var*/ let copyLength = $.$$.System.Math.Min$4(memory.Length, ((currentPage.length - this._currentPageIndex) | 0));
                    memory.Slice(0, copyLength).CopyTo($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, currentPage, this._currentPageIndex, copyLength));
                    this.Length += copyLength;
                    this._currentPageIndex += copyLength;
                    memory = memory.Slice$1(copyLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656213108)
            
            //--TRIMMABLE-BOUNDARY-START(98785755252)
            /*void */ MoveTo(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    /*var*/ let page = this.Pages.get_Item(i);
                    /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                    stream.Write(page, 0, length);
                }
                this.ClearBuffers();
            }
            //--TRIMMABLE-BOUNDARY-END(98785755252)
            
            //--TRIMMABLE-BOUNDARY-START(107375689844)
            /*Task *//*async*/  MoveToAsync$1(/*PipeWriter*/ writer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375689844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        await writer.WriteAsync($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, page, 0, length)), cancellationToken);
                    }
                    this.ClearBuffers();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375689844)
            
            //--TRIMMABLE-BOUNDARY-START(103080722548)
            /*Task *//*async*/  MoveToAsync(/*Stream*/ stream, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103080722548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                    {
                        /*var*/ let page = this.Pages.get_Item(i);
                        /*var*/ let length = (i === ((this.Pages.Count - 1) | 0)) ? this._currentPageIndex : page.length;
                        await stream.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, page, 0, length)), cancellationToken);
                    }
                    this.ClearBuffers();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(103080722548)
            
            //--TRIMMABLE-BOUNDARY-START(51541114996)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.ClearBuffers();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541114996)
            
            //--TRIMMABLE-BOUNDARY-START(42951180404)
            /*void */ ClearBuffers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*var*/ let i = 0; i < this.Pages.Count; i++)
                {
                    this._arrayPool.Return(this.Pages.get_Item(i), false);
                }
                this.Pages.Clear();
                this._currentPage = null;
                this.Length = 0;
                this._currentPageIndex = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(42951180404)
            
            //--TRIMMABLE-BOUNDARY-START(137440460916)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440460916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(137440460916)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            static $h = 1507444;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490787956),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605886068,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145493620,
        "f": 83886082
      },
      "n": "Length",
      "d": 1507444,
      "h": 94490787956,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490787956),
//--TRIMMABLE-BOUNDARY-START(55836082292),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015951476,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555559028,
        "f": 83886082
      },
      "n": "Disposed",
      "d": 1507444,
      "h": 55836082292,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55836082292),
//--TRIMMABLE-BOUNDARY-START(111670657140),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$typeArray($.$$.System.Byte)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195820660,
        "f": 50331656
      },
      "n": "Pages",
      "d": 1507444,
      "h": 111670657140,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(111670657140),
//--TRIMMABLE-BOUNDARY-START(47246147700),
    {
      "p": $.$typeArray($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426016884,
        "f": 50331650
      },
      "n": "CurrentPage",
      "d": 1507444,
      "h": 47246147700,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47246147700)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361245812),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Add",
      "d": 1507444,
      "h": 34361245812,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245812),
//--TRIMMABLE-BOUNDARY-START(38656213108),
    {
      "r": 65537,
      "p": [
        {
          "n": "memory",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1507444,
      "h": 38656213108,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656213108),
//--TRIMMABLE-BOUNDARY-START(98785755252),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "MoveTo",
      "d": 1507444,
      "h": 98785755252,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785755252),
//--TRIMMABLE-BOUNDARY-START(107375689844),
    {
      "r": 177668097,
      "p": [
        {
          "n": "writer",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "MoveToAsync",
      "o": "@$1",
      "d": 1507444,
      "h": 107375689844,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(107375689844),
//--TRIMMABLE-BOUNDARY-START(103080722548),
    {
      "r": 177668097,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "MoveToAsync",
      "d": 1507444,
      "h": 103080722548,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(103080722548),
//--TRIMMABLE-BOUNDARY-START(51541114996),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507444,
      "h": 51541114996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541114996),
//--TRIMMABLE-BOUNDARY-START(42951180404),
    {
      "r": 65537,
      "n": "ClearBuffers",
      "d": 1507444,
      "h": 42951180404,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951180404),
//--TRIMMABLE-BOUNDARY-START(137440460916),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 1507444,
      "h": 137440460916,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440460916)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(115965624436),
    {
      "t": 655361,
      "n": "PageSize",
      "d": 1507444,
      "h": 115965624436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965624436),
//--TRIMMABLE-BOUNDARY-START(4296474740),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_arrayPool",
      "d": 1507444,
      "h": 4296474740,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474740),
//--TRIMMABLE-BOUNDARY-START(8591442036),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_currentPage",
      "d": 1507444,
      "h": 8591442036,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442036),
//--TRIMMABLE-BOUNDARY-START(12886409332),
    {
      "t": 655361,
      "n": "_currentPageIndex",
      "d": 1507444,
      "h": 12886409332,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066278516),
    {
      "p": [
        {
          "n": "arrayPool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507444,
      "h": 30066278516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066278516)
  ],
  "i": [90308609
  ],
  "h": 1507444
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `PagedByteBuffer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507444)
        
        
        //--TRIMMABLE-BOUNDARY-START(786548)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FormReader", ($self) => class FormReader extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(107374968948)
            /*int*/ static DefaultValueCountLimit = 1024;
            //--TRIMMABLE-BOUNDARY-END(107374968948)
            
            //--TRIMMABLE-BOUNDARY-START(103080001652)
            /*int*/ static DefaultKeyLengthLimit = 2048;
            //--TRIMMABLE-BOUNDARY-END(103080001652)
            
            //--TRIMMABLE-BOUNDARY-START(111669936244)
            /*int*/ static DefaultValueLengthLimit = 4194304;
            //--TRIMMABLE-BOUNDARY-END(111669936244)
            
            //--TRIMMABLE-BOUNDARY-START(47245426804)
            /*int*/ static _rentedCharPoolLength = 8192;
            //--TRIMMABLE-BOUNDARY-END(47245426804)
            
            //--TRIMMABLE-BOUNDARY-START(42950459508)
            /*TextReader*/ _reader = null;
            //--TRIMMABLE-BOUNDARY-END(42950459508)
            
            //--TRIMMABLE-BOUNDARY-START(4295753844)
            /*char[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295753844)
            
            //--TRIMMABLE-BOUNDARY-START(21475623028)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(21475623028)
            
            //--TRIMMABLE-BOUNDARY-START(17180655732)
            /*StringBuilder*/ _builder = null;
            //--TRIMMABLE-BOUNDARY-END(17180655732)
            
            //--TRIMMABLE-BOUNDARY-START(12885688436)
            /*int*/ _bufferOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(12885688436)
            
            //--TRIMMABLE-BOUNDARY-START(8590721140)
            /*int*/ _bufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(8590721140)
            
            //--TRIMMABLE-BOUNDARY-START(25770590324)
            /*string?*/ _currentKey = null;
            //--TRIMMABLE-BOUNDARY-END(25770590324)
            
            //--TRIMMABLE-BOUNDARY-START(30065557620)
            /*string?*/ _currentValue = null;
            //--TRIMMABLE-BOUNDARY-END(30065557620)
            
            //--TRIMMABLE-BOUNDARY-START(38655492212)
            /*bool*/ _endOfStream = false;
            //--TRIMMABLE-BOUNDARY-END(38655492212)
            
            //--TRIMMABLE-BOUNDARY-START(34360524916)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(34360524916)
            
            //--TRIMMABLE-BOUNDARY-START(81605165172)
            $ctor$5(/*string*/ data)
            {
                this.$ctor$4(data, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605165172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605165172)
            
            //--TRIMMABLE-BOUNDARY-START(77310197876)
            $ctor$4(/*string*/ data, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310197876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(data, "data");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.System.IO.StringReader().$ctor$3(data);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310197876)
            
            //--TRIMMABLE-BOUNDARY-START(73015230580)
            $ctor$3(/*Stream*/ stream)
            {
                this.$ctor$1(stream, $.$$.System.Text.Encoding.UTF8, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015230580);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015230580)
            
            //--TRIMMABLE-BOUNDARY-START(68720263284)
            $ctor$2(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$1(stream, encoding, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720263284);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720263284)
            
            //--TRIMMABLE-BOUNDARY-START(64425295988)
            $ctor$1(/*Stream*/ stream, /*Encoding*/ encoding, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425295988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                    this._buffer = charPool.Rent(8192/*_rentedCharPoolLength*/);
                    this._charPool = charPool;
                    this._reader = new $.$$.System.IO.StreamReader().$ctor$5(stream, null, true, ((1024 * 2) | 0), true);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425295988)
            
            //--TRIMMABLE-BOUNDARY-START(223339085940)
            /*int*/ ValueCountLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(223339085940)
            
            //--TRIMMABLE-BOUNDARY-START(146029674612)
            /*int*/ KeyLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(146029674612)
            
            //--TRIMMABLE-BOUNDARY-START(227634053236)
            /*int*/ ValueLengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(227634053236)
            
            //--TRIMMABLE-BOUNDARY-START(163209543796)
            /*KeyValuePair<string, string>? */ ReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209543796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ReadNextPairImpl();
                if (this.ReadSucceeded())
                {
                    return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(this._currentKey, this._currentValue);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(163209543796)
            
            //--TRIMMABLE-BOUNDARY-START(176094445684)
            /*void */ ReadNextPairImpl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094445684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.StartReadNextPair();
                while(!this._endOfStream)
                {
                    if (this._bufferCount === 0)
                    {
                        this.Buffer();
                    }
                    if (this.TryReadNextPair())
                    {
                        break;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094445684)
            
            //--TRIMMABLE-BOUNDARY-START(167504511092)
            /*Task<KeyValuePair<string, string>?> *//*async*/  ReadNextPairAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Nullable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))), $.$typeNullable($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504511092);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.ReadNextPairAsyncImpl(cancellationToken);
                    if (this.ReadSucceeded())
                    {
                        return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3(this._currentKey, this._currentValue);
                    }
                    return null;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504511092)
            
            //--TRIMMABLE-BOUNDARY-START(171799478388)
            /*Task *//*async*/  ReadNextPairAsyncImpl(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799478388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.StartReadNextPair();
                    while(!this._endOfStream)
                    {
                        if (this._bufferCount === 0)
                        {
                            await this.BufferAsync(cancellationToken);
                        }
                        if (this.TryReadNextPair())
                        {
                            break;
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799478388)
            
            //--TRIMMABLE-BOUNDARY-START(210454184052)
            /*void */ StartReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454184052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._currentKey = null;
                this._currentValue = null;
            }
            //--TRIMMABLE-BOUNDARY-END(210454184052)
            
            //--TRIMMABLE-BOUNDARY-START(214749151348)
            /*bool */ TryReadNextPair()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749151348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._currentKey, null))
                {
                    if (!this.TryReadWord(/*=*/ 61, this.KeyLengthLimit, $.$ref(() => this._currentKey, ($v) => this._currentKey = $v, $.$$.System.String)))
                    {
                        return false;
                    }
                    if (this._bufferCount === 0)
                    {
                        return false;
                    }
                }
                if ($.$$.System.String.op_Equality(this._currentValue, null))
                {
                    if (!this.TryReadWord(/*&*/ 38, this.ValueLengthLimit, $.$ref(() => this._currentValue, ($v) => this._currentValue = $v, $.$$.System.String)))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(214749151348)
            
            //--TRIMMABLE-BOUNDARY-START(219044118644)
            /*bool */ TryReadWord(/*char*/ separator, /*int*/ limit, /*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044118644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                do
                {
                    if (this.ReadChar(separator, limit, value))
                    {
                        return true;
                    }
                }
                while(this._bufferCount > 0);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(219044118644)
            
            //--TRIMMABLE-BOUNDARY-START(150324641908)
            /*bool */ ReadChar(/*char*/ separator, /*int*/ limit, /*out string?*/ word)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324641908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferCount === 0)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                /*var*/ let c = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset++);
                this._bufferCount--;
                if (c === separator)
                {
                    word.$v = this.BuildWord();
                    return true;
                }
                if (this._builder.Length >= limit)
                {
                    throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form key or value length limit ${limit} exceeded.`);
                }
                this._builder.Append$3(c);
                word.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(150324641908)
            
            //--TRIMMABLE-BOUNDARY-START(98785034356)
            /*string */ BuildWord()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._builder.Replace$1(/*+*/ 43, /* */ 32);
                /*var*/ let result = $.$$.System.Text.StringBuilder.ToString.call(this._builder);
                this._builder.Clear();
                return $.$spu.System.Uri.UnescapeDataString$2(result);
            }
            //--TRIMMABLE-BOUNDARY-END(98785034356)
            
            //--TRIMMABLE-BOUNDARY-START(90195099764)
            /*void */ Buffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._bufferOffset = 0;
                this._bufferCount = this._reader.Read$1(this._buffer, 0, this._buffer.length);
                this._endOfStream = this._bufferCount === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(90195099764)
            
            //--TRIMMABLE-BOUNDARY-START(94490067060)
            /*Task *//*async*/  BufferAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490067060);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    cancellationToken.ThrowIfCancellationRequested();
                    this._bufferOffset = 0;
                    this._bufferCount = await this._reader.ReadAsync(this._buffer, 0, this._buffer.length);
                    this._endOfStream = this._bufferCount === 0;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(94490067060)
            
            //--TRIMMABLE-BOUNDARY-START(154619609204)
            /*Dictionary<string, StringValues> */ ReadForm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619609204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                while(!this._endOfStream)
                {
                    this.ReadNextPairImpl();
                    this.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null));
                }
                return accumulator.GetResults();
            }
            //--TRIMMABLE-BOUNDARY-END(154619609204)
            
            //--TRIMMABLE-BOUNDARY-START(158914576500)
            /*Task<Dictionary<string, StringValues>> *//*async*/  ReadFormAsync(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)), $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues), async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914576500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let accumulator = new $.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator().$ctor$2();
                    while(!this._endOfStream)
                    {
                        await this.ReadNextPairAsyncImpl(cancellationToken);
                        this.Append($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator, () => accumulator, ($v) => accumulator = $v, null));
                    }
                    return accumulator.GetResults();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(158914576500)
            
            //--TRIMMABLE-BOUNDARY-START(180389412980)
            /*bool */ ReadSucceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389412980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.op_Inequality(this._currentKey, null) && $.$$.System.String.op_Inequality(this._currentValue, null);
            }
            //--TRIMMABLE-BOUNDARY-END(180389412980)
            
            //--TRIMMABLE-BOUNDARY-START(85900132468)
            /*void */ Append(/*ref KeyValueAccumulator*/ accumulator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ReadSucceeded())
                {
                    accumulator.$v.Append(this._currentKey, this._currentValue);
                    if (accumulator.$v.ValueCount > this.ValueCountLimit)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Form value count limit ${this.ValueCountLimit} exceeded.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900132468)
            
            //--TRIMMABLE-BOUNDARY-START(115964903540)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964903540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._charPool.Return(this._buffer, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903540)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180655732)
                this._builder = new $.$$.System.Text.StringBuilder().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180655732)
                
                this.ValueCountLimit = 1024;
                this.KeyLengthLimit = 2048;
                this.ValueLengthLimit = 4194304;
            }
            static $h = 786548;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(223339085940),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144772724,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569282164,
        "f": 83886081
      },
      "n": "ValueCountLimit",
      "d": 786548,
      "h": 223339085940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223339085940),
//--TRIMMABLE-BOUNDARY-START(146029674612),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554838132,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979347572,
        "f": 83886081
      },
      "n": "KeyLengthLimit",
      "d": 786548,
      "h": 146029674612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029674612),
//--TRIMMABLE-BOUNDARY-START(227634053236),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734707316,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159216756,
        "f": 83886081
      },
      "n": "ValueLengthLimit",
      "d": 786548,
      "h": 227634053236,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227634053236)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163209543796),
    {
      "r": $.$typeNullable($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,
      "n": "ReadNextPair",
      "d": 786548,
      "h": 163209543796,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209543796),
//--TRIMMABLE-BOUNDARY-START(176094445684),
    {
      "r": 65537,
      "n": "ReadNextPairImpl",
      "d": 786548,
      "h": 176094445684,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094445684),
//--TRIMMABLE-BOUNDARY-START(167504511092),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Nullable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadNextPairAsync",
      "d": 786548,
      "h": 167504511092,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(167504511092),
//--TRIMMABLE-BOUNDARY-START(171799478388),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadNextPairAsyncImpl",
      "d": 786548,
      "h": 171799478388,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799478388),
//--TRIMMABLE-BOUNDARY-START(210454184052),
    {
      "r": 65537,
      "n": "StartReadNextPair",
      "d": 786548,
      "h": 210454184052,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454184052),
//--TRIMMABLE-BOUNDARY-START(214749151348),
    {
      "r": 262145,
      "n": "TryReadNextPair",
      "d": 786548,
      "h": 214749151348,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214749151348),
//--TRIMMABLE-BOUNDARY-START(219044118644),
    {
      "r": 262145,
      "p": [
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "limit",
          "p": 655361
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryReadWord",
      "d": 786548,
      "h": 219044118644,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219044118644),
//--TRIMMABLE-BOUNDARY-START(150324641908),
    {
      "r": 262145,
      "p": [
        {
          "n": "separator",
          "p": 458753
        },
        {
          "n": "limit",
          "p": 655361
        },
        {
          "n": "word",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "ReadChar",
      "d": 786548,
      "h": 150324641908,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324641908),
//--TRIMMABLE-BOUNDARY-START(98785034356),
    {
      "r": 1310721,
      "n": "BuildWord",
      "d": 786548,
      "h": 98785034356,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98785034356),
//--TRIMMABLE-BOUNDARY-START(90195099764),
    {
      "r": 65537,
      "n": "Buffer",
      "d": 786548,
      "h": 90195099764,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195099764),
//--TRIMMABLE-BOUNDARY-START(94490067060),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "BufferAsync",
      "d": 786548,
      "h": 94490067060,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(94490067060),
//--TRIMMABLE-BOUNDARY-START(154619609204),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "n": "ReadForm",
      "d": 786548,
      "h": 154619609204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619609204),
//--TRIMMABLE-BOUNDARY-START(158914576500),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues)).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadFormAsync",
      "d": 786548,
      "h": 158914576500,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(158914576500),
//--TRIMMABLE-BOUNDARY-START(180389412980),
    {
      "r": 262145,
      "n": "ReadSucceeded",
      "d": 786548,
      "h": 180389412980,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389412980),
//--TRIMMABLE-BOUNDARY-START(85900132468),
    {
      "r": 65537,
      "p": [
        {
          "n": "accumulator",
          "p": 1048692,
          "f": 4
        }
      ],
      "n": "Append",
      "d": 786548,
      "h": 85900132468,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900132468),
//--TRIMMABLE-BOUNDARY-START(115964903540),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786548,
      "h": 115964903540,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964903540)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374968948),
    {
      "t": 655361,
      "n": "DefaultValueCountLimit",
      "d": 786548,
      "h": 107374968948,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374968948),
//--TRIMMABLE-BOUNDARY-START(103080001652),
    {
      "t": 655361,
      "n": "DefaultKeyLengthLimit",
      "d": 786548,
      "h": 103080001652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080001652),
//--TRIMMABLE-BOUNDARY-START(111669936244),
    {
      "t": 655361,
      "n": "DefaultValueLengthLimit",
      "d": 786548,
      "h": 111669936244,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669936244),
//--TRIMMABLE-BOUNDARY-START(47245426804),
    {
      "t": 655361,
      "n": "_rentedCharPoolLength",
      "d": 786548,
      "h": 47245426804,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245426804),
//--TRIMMABLE-BOUNDARY-START(42950459508),
    {
      "t": 95682561,
      "n": "_reader",
      "d": 786548,
      "h": 42950459508,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950459508),
//--TRIMMABLE-BOUNDARY-START(4295753844),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_buffer",
      "d": 786548,
      "h": 4295753844,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753844),
//--TRIMMABLE-BOUNDARY-START(21475623028),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,
      "n": "_charPool",
      "d": 786548,
      "h": 21475623028,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475623028),
//--TRIMMABLE-BOUNDARY-START(17180655732),
    {
      "t": 167051265,
      "n": "_builder",
      "d": 786548,
      "h": 17180655732,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655732),
//--TRIMMABLE-BOUNDARY-START(12885688436),
    {
      "t": 655361,
      "n": "_bufferOffset",
      "d": 786548,
      "h": 12885688436,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688436),
//--TRIMMABLE-BOUNDARY-START(8590721140),
    {
      "t": 655361,
      "n": "_bufferCount",
      "d": 786548,
      "h": 8590721140,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721140),
//--TRIMMABLE-BOUNDARY-START(25770590324),
    {
      "t": 1310721,
      "n": "_currentKey",
      "d": 786548,
      "h": 25770590324,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770590324),
//--TRIMMABLE-BOUNDARY-START(30065557620),
    {
      "t": 1310721,
      "n": "_currentValue",
      "d": 786548,
      "h": 30065557620,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065557620),
//--TRIMMABLE-BOUNDARY-START(38655492212),
    {
      "t": 262145,
      "n": "_endOfStream",
      "d": 786548,
      "h": 38655492212,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655492212),
//--TRIMMABLE-BOUNDARY-START(34360524916),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 786548,
      "h": 34360524916,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360524916)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81605165172),
    {
      "p": [
        {
          "n": "data",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786548,
      "h": 81605165172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605165172),
//--TRIMMABLE-BOUNDARY-START(77310197876),
    {
      "p": [
        {
          "n": "data",
          "p": 1310721
        },
        {
          "n": "charPool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786548,
      "h": 77310197876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310197876),
//--TRIMMABLE-BOUNDARY-START(73015230580),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786548,
      "h": 73015230580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015230580),
//--TRIMMABLE-BOUNDARY-START(68720263284),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786548,
      "h": 68720263284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263284),
//--TRIMMABLE-BOUNDARY-START(64425295988),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        },
        {
          "n": "charPool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786548,
      "h": 64425295988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425295988)
  ],
  "i": [90308609
  ],
  "h": 786548
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `FormReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786548)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638516)
        $asm.$str("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable", ($self) => class QueryStringEnumerable extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296605812)
            /*ReadOnlyMemory<char>*/  get _queryString() { return this.$getField(0, 12); }
            /*ReadOnlyMemory<char>*/  set _queryString(value) { this.$setField(0, 12, value); }
            //--TRIMMABLE-BOUNDARY-END(4296605812)
            
            //--TRIMMABLE-BOUNDARY-START(25771442292)
            $ctor$4(/*string?*/ queryString)
            {
                this.$ctor$3($.$$.System.MemoryExtensions.AsMemory$4(queryString));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771442292);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442292)
            
            //--TRIMMABLE-BOUNDARY-START(21476474996)
            $ctor$3(/*ReadOnlyMemory<char>*/ queryString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476474996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._queryString = queryString;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476474996)
            
            //--TRIMMABLE-BOUNDARY-START(30066409588)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066409588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.Enumerator().$ctor$3(this._queryString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066409588)
            
            //--TRIMMABLE-BOUNDARY-START(1704052)
            static $_EncodedNameValuePair;
            static get EncodedNameValuePair()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable;
                return $cls.$_EncodedNameValuePair ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair", ($self) => class EncodedNameValuePair extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34361442420)
                    /*ReadOnlyMemory<char>*/ EncodedName;
                    //--TRIMMABLE-BOUNDARY-END(34361442420)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656409716)
                    /*ReadOnlyMemory<char>*/ EncodedValue;
                    //--TRIMMABLE-BOUNDARY-END(38656409716)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181573236)
                    $ctor$3(/*ReadOnlyMemory<char>*/ encodedName, /*ReadOnlyMemory<char>*/ encodedValue)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181573236);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.EncodedName = encodedName;
                            this.EncodedValue = encodedValue;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181573236)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771507828)
                    /*ReadOnlyMemory<char> */ DecodeName()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771507828);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedName);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771507828)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066475124)
                    /*ReadOnlyMemory<char> */ DecodeValue()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066475124);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair.Decode(this.EncodedValue);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066475124)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476540532)
                    static /*ReadOnlyMemory<char> */ Decode(/*ReadOnlyMemory<char>*/ chars)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476540532);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ReadOnlySpan<char>*/ let source = chars.Span;
                        if (!$.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, source, /*%*/ 37, /*+*/ 43))
                        {
                            return chars;
                        }
                        /*var*/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [source.Length], null);
                        $.$$.System.MemoryExtensions.Replace$1($.$$.System.Char, source, $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(buffer), /*+*/ 43, /* */ 32);
                        /*var*/ let unescapedLength;
                        /*var*/ let success = $.$spu.System.Uri.TryUnescapeDataString($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1(buffer), $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(buffer), $.$ref(() => unescapedLength, ($v) => unescapedLength = $v, $.$$.System.Int32));
                        $.$$.System.Diagnostics.Debug.Assert$2(success, "success");
                        return $.$$.System.Memory$$($.$$.System.Char).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Char, buffer, 0, unescapedLength));
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476540532)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886605940)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886605940)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.EncodedName = this.EncodedName.Clone();
                        copy.EncodedValue = this.EncodedValue.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.EncodedName = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                        this.EncodedValue = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                    }
                    static $h = 1704052;
                    static $z = 24;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361442420),
    {
      "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246344308,
        "f": 50331649
      },
      "n": "EncodedName",
      "d": 1704052,
      "h": 34361442420,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361442420),
//--TRIMMABLE-BOUNDARY-START(38656409716),
    {
      "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836278900,
        "f": 50331649
      },
      "n": "EncodedValue",
      "d": 1704052,
      "h": 38656409716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656409716)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771507828),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "n": "DecodeName",
      "d": 1704052,
      "h": 25771507828,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771507828),
//--TRIMMABLE-BOUNDARY-START(30066475124),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "n": "DecodeValue",
      "d": 1704052,
      "h": 30066475124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475124),
//--TRIMMABLE-BOUNDARY-START(21476540532),
    {
      "r": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": "Decode",
      "d": 1704052,
      "h": 21476540532,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476540532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181573236),
    {
      "p": [
        {
          "n": "encodedName",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        },
        {
          "n": "encodedValue",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704052,
      "h": 17181573236,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181573236),
//--TRIMMABLE-BOUNDARY-START(12886605940),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704052,
      "h": 12886605940,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605940)
  ],
  "d": 1638516,
  "h": 1704052
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `QueryStringEnumerable.EncodedNameValuePair`; }
                }, $cls, ($v) => $cls.$_EncodedNameValuePair = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1704052)
            
            //--TRIMMABLE-BOUNDARY-START(1769588)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable;
                return $cls.$_Enumerator ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736884)
                    /*ReadOnlyMemory<char>*/  get _query() { return this.$getField(0, 12); }
                    /*ReadOnlyMemory<char>*/  set _query(value) { this.$setField(0, 12, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296736884)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638772)
                    $ctor$3(/*ReadOnlyMemory<char>*/ query)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181638772);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair();
                            this._query = query.IsEmpty || query.Span.get_Item(0).$v !== /*?*/ 63 ? query : query.Slice$1(1);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181638772)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476606068)
                    /*EncodedNameValuePair*/ Current;
                    //--TRIMMABLE-BOUNDARY-END(21476606068)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361507956)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361507956);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        while(!this._query.IsEmpty)
                        {
                            /*ReadOnlyMemory<char>*/ let segment;
                            /*var*/ let delimiterIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, this._query.Span, /*&*/ 38);
                            if (delimiterIndex >= 0)
                            {
                                segment = this._query.Slice(0, delimiterIndex);
                                this._query = this._query.Slice$1(((delimiterIndex + 1) | 0));
                            }
                            else 
                            {
                                segment = this._query;
                                this._query = new ($.$$.System.ReadOnlyMemory$$($.$$.System.Char))();
                            }
                            /*var*/ let equalIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, segment.Span, /*=*/ 61);
                            if (equalIndex >= 0)
                            {
                                this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment.Slice(0, equalIndex), segment.Slice$1(((equalIndex + 1) | 0)));
                                return true;
                            }
                            else if (!segment.IsEmpty)
                            {
                                this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair().$ctor$3(segment, new ($.$$.System.ReadOnlyMemory$$($.$$.System.Char))());
                                return true;
                            }
                        }
                        this.Current = new $.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair();
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361507956)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671476)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671476)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._query = this._query.Clone();
                        copy.Current = this.Current.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296736884)
                        this._query = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                        //--TRIMMABLE-BOUNDARY-END(4296736884)
                        
                        this.Current = $.$default($.$maw.Microsoft.AspNetCore.WebUtilities.QueryStringEnumerable.EncodedNameValuePair);
                    }
                    static $h = 1769588;
                    static $z = 36;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476606068),
    {
      "p": 1704052,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540660,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951442548,
        "f": 83886082
      },
      "n": "Current",
      "d": 1769588,
      "h": 21476606068,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476606068)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361507956),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1769588,
      "h": 34361507956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361507956)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736884),
    {
      "t": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "n": "_query",
      "d": 1769588,
      "h": 4296736884,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736884)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638772),
    {
      "p": [
        {
          "n": "query",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769588,
      "h": 17181638772,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181638772),
//--TRIMMABLE-BOUNDARY-START(12886671476),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769588,
      "h": 12886671476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671476)
  ],
  "d": 1638516,
  "h": 1769588
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `QueryStringEnumerable.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769588)
            
            //--TRIMMABLE-BOUNDARY-START(17181507700)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507700)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._queryString = this._queryString.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296605812)
                this._queryString = $.$default($.$$.System.ReadOnlyMemory$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(4296605812)
                
            }
            static $h = 1638516;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066409588),
    {
      "r": 1769588,
      "n": "GetEnumerator",
      "d": 1638516,
      "h": 30066409588,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066409588)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605812),
    {
      "t": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h,
      "n": "_queryString",
      "d": 1638516,
      "h": 4296605812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771442292),
    {
      "p": [
        {
          "n": "queryString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1638516,
      "h": 25771442292,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771442292),
//--TRIMMABLE-BOUNDARY-START(21476474996),
    {
      "p": [
        {
          "n": "queryString",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638516,
      "h": 21476474996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476474996),
//--TRIMMABLE-BOUNDARY-START(17181507700),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638516,
      "h": 17181507700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181507700)
  ],
  "j": [1704052,1769588
  ],
  "h": 1638516
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `QueryStringEnumerable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638516)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162804)
        $asm.$cls("$maw.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592097396)
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592097396);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterName = parameterName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097396)
            
            //--TRIMMABLE-BOUNDARY-START(21476999284)
            /*string*/ ParameterName = null;
            //--TRIMMABLE-BOUNDARY-END(21476999284)
            
            static $h = 2162804;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476999284),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182031988,
        "f": 50331649
      },
      "n": "ParameterName",
      "d": 2162804,
      "h": 21476999284,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476999284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592097396),
    {
      "p": [
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2162804,
      "h": 8592097396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592097396)
  ],
  "h": 2162804,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2048,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162804)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048692)
        $asm.$str("$maw.Microsoft.AspNetCore.WebUtilities.KeyValueAccumulator", ($self) => class KeyValueAccumulator extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296015988)
            /*Dictionary<string, StringValues>*/  get _accumulator() { return this.$getField(0, 4); }
            /*Dictionary<string, StringValues>*/  set _accumulator(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296015988)
            
            //--TRIMMABLE-BOUNDARY-START(8590983284)
            /*Dictionary<string, List<string>>*/  get _expandingAccumulator() { return this.$getField(4, 4); }
            /*Dictionary<string, List<string>>*/  set _expandingAccumulator(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590983284)
            
            //--TRIMMABLE-BOUNDARY-START(21475885172)
            /*void */ Append(/*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._accumulator === null)
                {
                    this._accumulator = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                /*StringValues*/ let values;
                if (this._accumulator.TryGetValue(key, $.$ref(() => values, ($v) => values = $v, $.$mep.Microsoft.Extensions.Primitives.StringValues)))
                {
                    if (values.Count === 0)
                    {
                        this._expandingAccumulator.get_Item(key).Add(value);
                    }
                    else if (values.Count === 1)
                    {
                        this._accumulator.set_Item(key, $.$mep.Microsoft.Extensions.Primitives.StringValues.op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [values.get_Item$1(0), value], [-1], null)));
                    }
                    else 
                    {
                        this._accumulator.set_Item(key, $.$default($.$mep.Microsoft.Extensions.Primitives.StringValues));
                        if (this._expandingAccumulator === null)
                        {
                            this._expandingAccumulator = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                        }
                        /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3(8);
                        /*var*/ let array = values.ToArray();
                        list.Add($.$$.System.Array.$ReadT1.call(array, 0));
                        list.Add($.$$.System.Array.$ReadT1.call(array, 1));
                        list.Add(value);
                        this._expandingAccumulator.set_Item(key, list);
                    }
                }
                else 
                {
                    this._accumulator.set_Item(key, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$3(value));
                }
                this.ValueCount++;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885172)
            
            //--TRIMMABLE-BOUNDARY-START(55835623540)
            /*bool */ get HasValues()
            {
                return this.ValueCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(55835623540)
            
            //--TRIMMABLE-BOUNDARY-START(60130590836)
            /*int */ get KeyCount()
            {
                return (this._accumulator?.Count ?? null) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(60130590836)
            
            //--TRIMMABLE-BOUNDARY-START(73015492724)
            /*int*/ ValueCount = 0;
            //--TRIMMABLE-BOUNDARY-END(73015492724)
            
            //--TRIMMABLE-BOUNDARY-START(51540656244)
            /*Dictionary<string, StringValues> */ GetResults()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._expandingAccumulator !== null)
                {
                    var $en3 = this._expandingAccumulator.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            this._accumulator.set_Item(entry.Key, new $.$mep.Microsoft.Extensions.Primitives.StringValues().$ctor$4(entry.Value.ToArray()));
                        }
                    }
                }
                return this._accumulator ?? new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues))().$ctor$7(0, $.$$.System.StringComparer.OrdinalIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(51540656244)
            
            //--TRIMMABLE-BOUNDARY-START(17180917876)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180917876)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._accumulator = this._accumulator;
                copy._expandingAccumulator = this._expandingAccumulator;
                copy.ValueCount = this.ValueCount;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296015988)
                this._accumulator = null;
                //--TRIMMABLE-BOUNDARY-END(4296015988)
                
                //--TRIMMABLE-BOUNDARY-START(8590983284)
                this._expandingAccumulator = null;
                //--TRIMMABLE-BOUNDARY-END(8590983284)
                
            }
            static $h = 1048692;
            static $z = 12;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835623540),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065819764,
        "f": 50331649
      },
      "n": "HasValues",
      "d": 1048692,
      "h": 55835623540,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835623540),
//--TRIMMABLE-BOUNDARY-START(60130590836),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655754356,
        "f": 50331649
      },
      "n": "KeyCount",
      "d": 1048692,
      "h": 60130590836,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130590836),
//--TRIMMABLE-BOUNDARY-START(73015492724),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245688948,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720525428,
        "f": 83886082
      },
      "n": "ValueCount",
      "d": 1048692,
      "h": 73015492724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015492724)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475885172),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Append",
      "d": 1048692,
      "h": 21475885172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885172),
//--TRIMMABLE-BOUNDARY-START(51540656244),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "n": "GetResults",
      "d": 1048692,
      "h": 51540656244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540656244)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296015988),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$mep.Microsoft.Extensions.Primitives.StringValues).$h,
      "n": "_accumulator",
      "d": 1048692,
      "h": 4296015988,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015988),
//--TRIMMABLE-BOUNDARY-START(8590983284),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)).$h,
      "n": "_expandingAccumulator",
      "d": 1048692,
      "h": 8590983284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983284)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180917876),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048692,
      "h": 17180917876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917876)
  ],
  "h": 1048692
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `KeyValueAccumulator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048692)
        
        
        //--TRIMMABLE-BOUNDARY-START(852084)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader", ($self) => class HttpRequestStreamReader extends $.$$.System.IO.TextReader
        {
            //--TRIMMABLE-BOUNDARY-START(77310263412)
            /*int*/ static DefaultBufferSize = 1024;
            //--TRIMMABLE-BOUNDARY-END(77310263412)
            
            //--TRIMMABLE-BOUNDARY-START(55835426932)
            /*Stream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(55835426932)
            
            //--TRIMMABLE-BOUNDARY-START(47245492340)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(47245492340)
            
            //--TRIMMABLE-BOUNDARY-START(38655557748)
            /*Decoder*/ _decoder = null;
            //--TRIMMABLE-BOUNDARY-END(38655557748)
            
            //--TRIMMABLE-BOUNDARY-START(12885753972)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(12885753972)
            
            //--TRIMMABLE-BOUNDARY-START(30065623156)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(30065623156)
            
            //--TRIMMABLE-BOUNDARY-START(8590786676)
            /*int*/ _byteBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(8590786676)
            
            //--TRIMMABLE-BOUNDARY-START(4295819380)
            /*byte[]*/ _byteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295819380)
            
            //--TRIMMABLE-BOUNDARY-START(21475688564)
            /*char[]*/ _charBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(21475688564)
            
            //--TRIMMABLE-BOUNDARY-START(25770655860)
            /*int*/ _charBufferIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(25770655860)
            
            //--TRIMMABLE-BOUNDARY-START(34360590452)
            /*int*/ _charsRead = 0;
            //--TRIMMABLE-BOUNDARY-END(34360590452)
            
            //--TRIMMABLE-BOUNDARY-START(17180721268)
            /*int*/ _bytesRead = 0;
            //--TRIMMABLE-BOUNDARY-END(17180721268)
            
            //--TRIMMABLE-BOUNDARY-START(51540459636)
            /*bool*/ _isBlocked = false;
            //--TRIMMABLE-BOUNDARY-END(51540459636)
            
            //--TRIMMABLE-BOUNDARY-START(42950525044)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(42950525044)
            
            //--TRIMMABLE-BOUNDARY-START(73015296116)
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$3(stream, encoding, 1024/*DefaultBufferSize*/, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015296116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015296116)
            
            //--TRIMMABLE-BOUNDARY-START(68720328820)
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$3(stream, encoding, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720328820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328820)
            
            //--TRIMMABLE-BOUNDARY-START(64425361524)
            $ctor$3(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("stream") });
                    this._encoding = $.$firstOf(encoding, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, bufferSize, "bufferSize");
                    if (!stream.CanRead)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$maw.Resources.HttpRequestStreamReader_StreamNotReadable, "stream");
                    }
                    this._byteBufferSize = bufferSize;
                    this._decoder = encoding.GetDecoder();
                    this._byteBuffer = this._bytePool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxCharCount(bufferSize);
                        this._charBuffer = this._charPool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        this._bytePool.Return(this._byteBuffer, false);
                        if (this._charBuffer !== null)
                        {
                            this._charPool.Return(this._charBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425361524)
            
            //--TRIMMABLE-BOUNDARY-START(81605230708)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._byteBuffer, false);
                    this._charPool.Return(this._charBuffer, false);
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(81605230708)
            
            //--TRIMMABLE-BOUNDARY-START(85900198004)
            /*int */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900198004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this._isBlocked || this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(85900198004)
            
            //--TRIMMABLE-BOUNDARY-START(90195165300)
            /*int */ Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferIndex === this._charsRead)
                {
                    if (this.ReadIntoBuffer() === 0)
                    {
                        return -1;
                    }
                }
                return $.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex++);
            }
            //--TRIMMABLE-BOUNDARY-END(90195165300)
            
            //--TRIMMABLE-BOUNDARY-START(94490132596)
            /*int */ Read$1(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let span = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(buffer, index, count);
                return this.Read$2(span);
            }
            //--TRIMMABLE-BOUNDARY-END(94490132596)
            
            //--TRIMMABLE-BOUNDARY-START(98785099892)
            /*int */ Read$2(/*Span<char>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785099892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let count = buffer.Length;
                /*var*/ let charsRead = 0;
                while(count > 0)
                {
                    /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                    if (charsRemaining === 0)
                    {
                        charsRemaining = this.ReadIntoBuffer();
                    }
                    if (charsRemaining === 0)
                    {
                        break;
                    }
                    if (charsRemaining > count)
                    {
                        charsRemaining = count;
                    }
                    /*var*/ let source = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferIndex, charsRemaining);
                    source.CopyTo(buffer);
                    this._charBufferIndex += charsRemaining;
                    charsRead += charsRemaining;
                    count -= charsRemaining;
                    buffer = buffer.Slice(charsRemaining, count);
                    if (this._isBlocked)
                    {
                        break;
                    }
                }
                return charsRead;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099892)
            
            //--TRIMMABLE-BOUNDARY-START(103080067188)
            /*Task<int> */ ReadAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (count < 0 || ((index + count) | 0) > buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("count");
                }
                /*var*/ let memory = new ($.$$.System.Memory$$($.$$.System.Char))().$ctor$5(buffer, index, count);
                return this.ReadAsync$1(memory, new $.$$.System.Threading.CancellationToken()).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(103080067188)
            
            //--TRIMMABLE-BOUNDARY-START(107375034484)
            /*ValueTask<int> *//*async*/  ReadAsync$1(/*Memory<char>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375034484);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if (this._charBufferIndex === this._charsRead && await this.ReadIntoBufferAsync() === 0)
                    {
                        return 0;
                    }
                    /*var*/ let count = buffer.Length;
                    /*var*/ let charsRead = 0;
                    while(count > 0)
                    {
                        /*var*/ let charsRemaining = ((this._charsRead - this._charBufferIndex) | 0);
                        if (charsRemaining === 0)
                        {
                            this._charsRead = 0;
                            this._charBufferIndex = 0;
                            this._bytesRead = 0;
                            do
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining === 0, "charsRemaining == 0");
                                this._bytesRead = await this._stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, this._byteBufferSize), cancellationToken);
                                if (this._bytesRead === 0)
                                {
                                    this._isBlocked = true;
                                    break;
                                }
                                this._isBlocked = (this._bytesRead < this._byteBufferSize);
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining === 0, "charsRemaining == 0");
                                this._charBufferIndex = 0;
                                charsRemaining = this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, 0);
                                $.$$.System.Diagnostics.Debug.Assert$2(charsRemaining > 0, "charsRemaining > 0");
                                this._charsRead += charsRemaining;
                            }
                            while(charsRemaining === 0);
                            if (charsRemaining === 0)
                            {
                                break;
                            }
                        }
                        if (charsRemaining > count)
                        {
                            charsRemaining = count;
                        }
                        /*var*/ let source = new ($.$$.System.Memory$$($.$$.System.Char))().$ctor$5(this._charBuffer, this._charBufferIndex, charsRemaining);
                        source.CopyTo(buffer);
                        this._charBufferIndex += charsRemaining;
                        charsRead += charsRemaining;
                        count -= charsRemaining;
                        buffer = buffer.Slice(charsRemaining, count);
                        if (this._isBlocked)
                        {
                            break;
                        }
                    }
                    return charsRead;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375034484)
            
            //--TRIMMABLE-BOUNDARY-START(124554903668)
            /*Task<string?> *//*async*/  ReadLineAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554903668);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    /*StringBuilder?*/ let sb = null;
                    /*var*/ let consumeLineFeed = false;
                    while(true)
                    {
                        if (this._charBufferIndex === this._charsRead)
                        {
                            if (await this.ReadIntoBufferAsync() === 0)
                            {
                                const $t1 = sb;
                                return $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                            }
                        }
                        /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.System.Text.StringBuilder), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null));
                        if (stepResult.Completed)
                        {
                            const $t3 = sb;
                            return stepResult.Result ?? $.$ifnn($t3, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                        }
                        continue;
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(124554903668)
            
            //--TRIMMABLE-BOUNDARY-START(120259936372)
            /*string? */ ReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259936372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*StringBuilder?*/ let sb = null;
                /*var*/ let consumeLineFeed = false;
                while(true)
                {
                    if (this._charBufferIndex === this._charsRead)
                    {
                        if (this.ReadIntoBuffer() === 0)
                        {
                            const $t1 = sb;
                            return $.$ifnn($t1, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                        }
                    }
                    /*var*/ let stepResult = this.ReadLineStep($.$ref(() => sb, ($v) => sb = $v, $.$$.System.Text.StringBuilder), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => consumeLineFeed, ($v) => consumeLineFeed = $v, null));
                    if (stepResult.Completed)
                    {
                        const $t3 = sb;
                        return stepResult.Result ?? $.$ifnn($t3, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259936372)
            
            //--TRIMMABLE-BOUNDARY-START(128849870964)
            /*ReadLineStepResult */ ReadLineStep(/*ref StringBuilder?*/ sb, /*ref bool*/ consumeLineFeed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849870964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char*/ let carriageReturn = /*\r*/ 13;
                /*char*/ let lineFeed = /*\n*/ 10;
                if (consumeLineFeed.$v)
                {
                    if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                    {
                        this._charBufferIndex++;
                    }
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                }
                /*var*/ let span = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferIndex, ((this._charsRead - this._charBufferIndex) | 0));
                /*var*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(span), carriageReturn, lineFeed);
                if (index !== -1)
                {
                    if (span.get_Item(index).$v === carriageReturn)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (this._charBufferIndex < this._charsRead)
                        {
                            if ($.$$.System.Array.$ReadT1.call(this._charBuffer, this._charBufferIndex) === lineFeed)
                            {
                                this._charBufferIndex++;
                            }
                            if (sb.$v !== null)
                            {
                                sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                                return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                            }
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.FromResult($.$$.System.Span$$($.$$.System.Char).ToString.call(span));
                        }
                        sb.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                        sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                        consumeLineFeed.$v = true;
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Continue;
                    }
                    if (span.get_Item(index).$v === lineFeed)
                    {
                        span = span.Slice(0, index);
                        this._charBufferIndex += ((index + 1) | 0);
                        if (sb.$v !== null)
                        {
                            sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                            return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Done;
                        }
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.FromResult($.$$.System.Span$$($.$$.System.Char).ToString.call(span));
                    }
                }
                sb.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                sb.$v.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(span));
                this._charBufferIndex = this._charsRead;
                return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult.Continue;
            }
            //--TRIMMABLE-BOUNDARY-END(128849870964)
            
            //--TRIMMABLE-BOUNDARY-START(111670001780)
            /*int */ ReadIntoBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670001780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._charsRead = 0;
                this._charBufferIndex = 0;
                this._bytesRead = 0;
                do
                {
                    this._bytesRead = this._stream.Read(this._byteBuffer, 0, this._byteBufferSize);
                    if (this._bytesRead === 0)
                    {
                        return this._charsRead;
                    }
                    this._isBlocked = (this._bytesRead < this._byteBufferSize);
                    this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                }
                while(this._charsRead === 0);
                return this._charsRead;
            }
            //--TRIMMABLE-BOUNDARY-END(111670001780)
            
            //--TRIMMABLE-BOUNDARY-START(115964969076)
            /*Task<int> *//*async*/  ReadIntoBufferAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964969076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._charsRead = 0;
                    this._charBufferIndex = 0;
                    this._bytesRead = 0;
                    do
                    {
                        this._bytesRead = await this._stream.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, this._byteBufferSize), new $.$$.System.Threading.CancellationToken()).ConfigureAwait(false);
                        if (this._bytesRead === 0)
                        {
                            return this._charsRead;
                        }
                        this._isBlocked = (this._bytesRead < this._byteBufferSize);
                        this._charsRead += this._decoder.GetChars$1(this._byteBuffer, 0, this._bytesRead, this._charBuffer, this._charsRead);
                    }
                    while(this._charsRead === 0);
                    return this._charsRead;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(115964969076)
            
            //--TRIMMABLE-BOUNDARY-START(133144838260)
            /*Task<string> *//*async*/  ReadToEndAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144838260);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*StringBuilder*/ let sb = new $.$$.System.Text.StringBuilder().$ctor$4(((this._charsRead - this._charBufferIndex) | 0));
                    do
                    {
                        /*int*/ let tmpCharPos = this._charBufferIndex;
                        sb.Append$4(this._charBuffer, tmpCharPos, ((this._charsRead - tmpCharPos) | 0));
                        this._charBufferIndex = this._charsRead;
                        await this.ReadIntoBufferAsync().ConfigureAwait$2(false);
                    }
                    while(this._charsRead > 0);
                    return $.$$.System.Text.StringBuilder.ToString.call(sb);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(133144838260)
            
            //--TRIMMABLE-BOUNDARY-START(917620)
            static $_ReadLineStepResult;
            static get ReadLineStepResult()
            {
                let $cls = $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader;
                return $cls.$_ReadLineStepResult ??= $asm.$nstr("$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult", ($self) => class ReadLineStepResult extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655988)
                    /*ReadLineStepResult*/ static Done;
                    //--TRIMMABLE-BOUNDARY-END(34360655988)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688692)
                    /*ReadLineStepResult*/ static Continue;
                    //--TRIMMABLE-BOUNDARY-END(30065688692)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655623284)
                    static /*ReadLineStepResult */ FromResult(/*string*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655623284);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655623284)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754100)
                    $ctor$3(/*bool*/ completed, /*string?*/ result)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475754100);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Completed = completed;
                            this.Result = result;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475754100)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721396)
                    /*bool*/ Completed = false;
                    //--TRIMMABLE-BOUNDARY-END(25770721396)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130459764)
                    /*string?*/ Result = null;
                    //--TRIMMABLE-BOUNDARY-END(60130459764)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786804)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786804)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Completed = this.Completed;
                        copy.Result = this.Result;
                        return copy;
                    }
                    //--TRIMMABLE-BOUNDARY-START(12885819508)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(34360655988)
                            this.Done = new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(true, null);
                            //--TRIMMABLE-BOUNDARY-END(34360655988)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065688692)
                            this.Continue = new $.$maw.Microsoft.AspNetCore.WebUtilities.HttpRequestStreamReader.ReadLineStepResult().$ctor$3(false, null);
                            //--TRIMMABLE-BOUNDARY-END(30065688692)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885819508)
                    
                    static $h = 917620;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770721396),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557876,
        "f": 50331649
      },
      "n": "Completed",
      "d": 917620,
      "h": 25770721396,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721396),
//--TRIMMABLE-BOUNDARY-START(60130459764),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835492468,
        "f": 50331649
      },
      "n": "Result",
      "d": 917620,
      "h": 60130459764,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459764)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655623284),
    {
      "r": 917620,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "FromResult",
      "d": 917620,
      "h": 38655623284,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655623284)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360655988),
    {
      "t": 917620,
      "n": "Done",
      "d": 917620,
      "h": 34360655988,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655988),
//--TRIMMABLE-BOUNDARY-START(30065688692),
    {
      "t": 917620,
      "n": "Continue",
      "d": 917620,
      "h": 30065688692,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688692)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475754100),
    {
      "p": [
        {
          "n": "completed",
          "p": 262145
        },
        {
          "n": "result",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917620,
      "h": 21475754100,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475754100),
//--TRIMMABLE-BOUNDARY-START(17180786804),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917620,
      "h": 17180786804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786804)
  ],
  "d": 852084,
  "h": 917620
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `HttpRequestStreamReader.ReadLineStepResult`; }
                }, $cls, ($v) => $cls.$_ReadLineStepResult = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917620)
            
            //--TRIMMABLE-BOUNDARY-START(137439805556)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439805556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(137439805556)
            
            static $h = 852084;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 95682561,
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605230708),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 852084,
      "h": 81605230708,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81605230708),
//--TRIMMABLE-BOUNDARY-START(85900198004),
    {
      "r": 655361,
      "n": "Peek",
      "d": 852084,
      "h": 85900198004,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900198004),
//--TRIMMABLE-BOUNDARY-START(90195165300),
    {
      "r": 655361,
      "n": "Read",
      "d": 852084,
      "h": 90195165300,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195165300),
//--TRIMMABLE-BOUNDARY-START(94490132596),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 852084,
      "h": 94490132596,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490132596),
//--TRIMMABLE-BOUNDARY-START(98785099892),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "Read",
      "o": "@$2",
      "d": 852084,
      "h": 98785099892,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785099892),
//--TRIMMABLE-BOUNDARY-START(103080067188),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ReadAsync",
      "d": 852084,
      "h": 103080067188,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080067188),
//--TRIMMABLE-BOUNDARY-START(107375034484),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$1",
      "d": 852084,
      "h": 107375034484,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(107375034484),
//--TRIMMABLE-BOUNDARY-START(124554903668),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "n": "ReadLineAsync",
      "d": 852084,
      "h": 124554903668,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(124554903668),
//--TRIMMABLE-BOUNDARY-START(120259936372),
    {
      "r": 1310721,
      "n": "ReadLine",
      "d": 852084,
      "h": 120259936372,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120259936372),
//--TRIMMABLE-BOUNDARY-START(128849870964),
    {
      "r": 917620,
      "p": [
        {
          "n": "sb",
          "p": 167051265,
          "f": 4
        },
        {
          "n": "consumeLineFeed",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ReadLineStep",
      "d": 852084,
      "h": 128849870964,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849870964),
//--TRIMMABLE-BOUNDARY-START(111670001780),
    {
      "r": 655361,
      "n": "ReadIntoBuffer",
      "d": 852084,
      "h": 111670001780,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111670001780),
//--TRIMMABLE-BOUNDARY-START(115964969076),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "n": "ReadIntoBufferAsync",
      "d": 852084,
      "h": 115964969076,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(115964969076),
//--TRIMMABLE-BOUNDARY-START(133144838260),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "n": "ReadToEndAsync",
      "d": 852084,
      "h": 133144838260,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(133144838260),
//--TRIMMABLE-BOUNDARY-START(137439805556),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 852084,
      "h": 137439805556,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439805556)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310263412),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 852084,
      "h": 77310263412,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310263412),
//--TRIMMABLE-BOUNDARY-START(55835426932),
    {
      "t": 94961665,
      "n": "_stream",
      "d": 852084,
      "h": 55835426932,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835426932),
//--TRIMMABLE-BOUNDARY-START(47245492340),
    {
      "t": 165937153,
      "n": "_encoding",
      "d": 852084,
      "h": 47245492340,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245492340),
//--TRIMMABLE-BOUNDARY-START(38655557748),
    {
      "t": 164626433,
      "n": "_decoder",
      "d": 852084,
      "h": 38655557748,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655557748),
//--TRIMMABLE-BOUNDARY-START(12885753972),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_bytePool",
      "d": 852084,
      "h": 12885753972,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753972),
//--TRIMMABLE-BOUNDARY-START(30065623156),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,
      "n": "_charPool",
      "d": 852084,
      "h": 30065623156,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065623156),
//--TRIMMABLE-BOUNDARY-START(8590786676),
    {
      "t": 655361,
      "n": "_byteBufferSize",
      "d": 852084,
      "h": 8590786676,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786676),
//--TRIMMABLE-BOUNDARY-START(4295819380),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_byteBuffer",
      "d": 852084,
      "h": 4295819380,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819380),
//--TRIMMABLE-BOUNDARY-START(21475688564),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_charBuffer",
      "d": 852084,
      "h": 21475688564,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688564),
//--TRIMMABLE-BOUNDARY-START(25770655860),
    {
      "t": 655361,
      "n": "_charBufferIndex",
      "d": 852084,
      "h": 25770655860,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655860),
//--TRIMMABLE-BOUNDARY-START(34360590452),
    {
      "t": 655361,
      "n": "_charsRead",
      "d": 852084,
      "h": 34360590452,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360590452),
//--TRIMMABLE-BOUNDARY-START(17180721268),
    {
      "t": 655361,
      "n": "_bytesRead",
      "d": 852084,
      "h": 17180721268,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721268),
//--TRIMMABLE-BOUNDARY-START(51540459636),
    {
      "t": 262145,
      "n": "_isBlocked",
      "d": 852084,
      "h": 51540459636,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540459636),
//--TRIMMABLE-BOUNDARY-START(42950525044),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 852084,
      "h": 42950525044,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950525044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(73015296116),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 852084,
      "h": 73015296116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015296116),
//--TRIMMABLE-BOUNDARY-START(68720328820),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 852084,
      "h": 68720328820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720328820),
//--TRIMMABLE-BOUNDARY-START(64425361524),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        },
        {
          "n": "charPool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852084,
      "h": 64425361524,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425361524)
  ],
  "i": [90308609
  ],
  "j": [917620
  ],
  "h": 852084
}; }
            static get $b() { return $.$$.System.IO.TextReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `HttpRequestStreamReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852084)
        
        
        //--TRIMMABLE-BOUNDARY-START(393332)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream", ($self) => class BufferedReadStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(64424902772)
            /*byte*/ static CR = 13;
            //--TRIMMABLE-BOUNDARY-END(64424902772)
            
            //--TRIMMABLE-BOUNDARY-START(167504117876)
            /*byte*/ static LF = 10;
            //--TRIMMABLE-BOUNDARY-END(167504117876)
            
            //--TRIMMABLE-BOUNDARY-START(25770197108)
            /*Stream*/ _inner = null;
            //--TRIMMABLE-BOUNDARY-END(25770197108)
            
            //--TRIMMABLE-BOUNDARY-START(4295360628)
            /*byte[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295360628)
            
            //--TRIMMABLE-BOUNDARY-START(17180262516)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(17180262516)
            
            //--TRIMMABLE-BOUNDARY-START(12885295220)
            /*int*/ _bufferOffset = 0;
            //--TRIMMABLE-BOUNDARY-END(12885295220)
            
            //--TRIMMABLE-BOUNDARY-START(8590327924)
            /*int*/ _bufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(8590327924)
            
            //--TRIMMABLE-BOUNDARY-START(21475229812)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475229812)
            
            //--TRIMMABLE-BOUNDARY-START(34360131700)
            $ctor$4(/*Stream*/ inner, /*int*/ bufferSize)
            {
                this.$ctor$3(inner, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360131700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131700)
            
            //--TRIMMABLE-BOUNDARY-START(30065164404)
            $ctor$3(/*Stream*/ inner, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    this._inner = inner;
                    this._bytePool = bytePool;
                    this._buffer = bytePool.Rent(bufferSize);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065164404)
            
            //--TRIMMABLE-BOUNDARY-START(38655098996)
            /*ArraySegment<byte> */ get BufferedData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$$.System.ArraySegment$$($.$$.System.Byte))().$ctor$3(this._buffer, this._bufferOffset, this._bufferCount);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098996)
            
            //--TRIMMABLE-BOUNDARY-START(42950066292)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanRead || this._bufferCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066292)
            
            //--TRIMMABLE-BOUNDARY-START(47245033588)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554444916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanSeek;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033588)
            
            //--TRIMMABLE-BOUNDARY-START(51540000884)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144379508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanTimeout;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000884)
            
            //--TRIMMABLE-BOUNDARY-START(55834968180)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.CanWrite;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968180)
            
            //--TRIMMABLE-BOUNDARY-START(163209150580)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(163209150580)
            
            //--TRIMMABLE-BOUNDARY-START(171799085172)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914183284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.Position - BigInt(this._bufferCount);
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453790836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "Position must be positive.");
                }
                if (value === this.Position)
                {
                    return;
                }
                if (value <= this._inner.Position)
                {
                    /*var*/ let innerOffset = $.$cast((this._inner.Position - value), $.$$.System.Int32);
                    if (innerOffset <= this._bufferCount)
                    {
                        this._bufferOffset += ((this._bufferCount - innerOffset) | 0);
                        this._bufferCount = innerOffset;
                    }
                    else 
                    {
                        this._bufferOffset = 0;
                        this._bufferCount = 0;
                        this._inner.Position = value;
                    }
                }
                else 
                {
                    this._bufferOffset = 0;
                    this._bufferCount = 0;
                    this._inner.Position = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799085172)
            
            //--TRIMMABLE-BOUNDARY-START(201863856244)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863856244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = this.Position + offset;
                }
                else 
                {
                    this.Position = this.Length + offset;
                }
                return this.Position;
            }
            //--TRIMMABLE-BOUNDARY-END(201863856244)
            
            //--TRIMMABLE-BOUNDARY-START(214748758132)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748758132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.SetLength(value);
            }
            //--TRIMMABLE-BOUNDARY-END(214748758132)
            
            //--TRIMMABLE-BOUNDARY-START(73014837364)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    this._bytePool.Return(this._buffer, false);
                    if (disposing)
                    {
                        this._inner.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837364)
            
            //--TRIMMABLE-BOUNDARY-START(94489673844)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(94489673844)
            
            //--TRIMMABLE-BOUNDARY-START(98784641140)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784641140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.FlushAsync$1(cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(98784641140)
            
            //--TRIMMABLE-BOUNDARY-START(219043725428)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043725428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inner.Write(buffer, offset, count);
            }
            //--TRIMMABLE-BOUNDARY-END(219043725428)
            
            //--TRIMMABLE-BOUNDARY-START(227633660020)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633660020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.WriteAsync$2(buffer, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(227633660020)
            
            //--TRIMMABLE-BOUNDARY-START(223338692724)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338692724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inner.WriteAsync(buffer, offset, count, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(223338692724)
            
            //--TRIMMABLE-BOUNDARY-START(180389019764)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389019764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (this._bufferCount > 0)
                {
                    /*int*/ let toCopy = $.$$.System.Math.Min$4(this._bufferCount, count);
                    $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, buffer, offset, toCopy);
                    this._bufferOffset += toCopy;
                    this._bufferCount -= toCopy;
                    return toCopy;
                }
                return this._inner.Read(buffer, offset, count);
            }
            //--TRIMMABLE-BOUNDARY-END(180389019764)
            
            //--TRIMMABLE-BOUNDARY-START(184683987060)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683987060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(184683987060)
            
            //--TRIMMABLE-BOUNDARY-START(188978954356)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188978954356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._bufferCount > 0)
                    {
                        /*int*/ let toCopy = $.$$.System.Math.Min$4(this._bufferCount, buffer.Length);
                        $.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._buffer, this._bufferOffset, toCopy).CopyTo(buffer);
                        this._bufferOffset += toCopy;
                        this._bufferCount -= toCopy;
                        return toCopy;
                    }
                    return await this._inner.ReadAsync$2(buffer, cancellationToken);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(188978954356)
            
            //--TRIMMABLE-BOUNDARY-START(77309804660)
            /*bool */ EnsureBuffered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._bufferCount > 0)
                {
                    return true;
                }
                this._bufferOffset = 0;
                this._bufferCount = this._inner.Read(this._buffer, 0, this._buffer.length);
                return this._bufferCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804660)
            
            //--TRIMMABLE-BOUNDARY-START(90194706548)
            /*Task<bool> *//*async*/  EnsureBufferedAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194706548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._bufferCount > 0)
                    {
                        return true;
                    }
                    this._bufferOffset = 0;
                    this._bufferCount = await this._inner.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$12($.$$.System.Byte, this._buffer), cancellationToken);
                    return this._bufferCount > 0;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(90194706548)
            
            //--TRIMMABLE-BOUNDARY-START(81604771956)
            /*bool */ EnsureBuffered$1(/*int*/ minCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minCount > this._buffer.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.System.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                }
                while(this._bufferCount < minCount)
                {
                    if (this._bufferOffset > 0)
                    {
                        if (this._bufferCount > 0)
                        {
                            $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                        }
                        this._bufferOffset = 0;
                    }
                    /*int*/ let read = this._inner.Read(this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0));
                    this._bufferCount += read;
                    if (read === 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771956)
            
            //--TRIMMABLE-BOUNDARY-START(85899739252)
            /*Task<bool> *//*async*/  EnsureBufferedAsync(/*int*/ minCount, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean), $.$$.System.Boolean, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899739252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (minCount > this._buffer.length)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("minCount", $.$box(minCount, $.$$.System.Int32), "The value must be smaller than the buffer size: " + this._buffer.length);
                    }
                    while(this._bufferCount < minCount)
                    {
                        if (this._bufferOffset > 0)
                        {
                            if (this._bufferCount > 0)
                            {
                                $.$$.System.Buffer.BlockCopy(this._buffer, this._bufferOffset, this._buffer, 0, this._bufferCount);
                            }
                            this._bufferOffset = 0;
                        }
                        /*int*/ let read = await this._inner.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._buffer, ((this._bufferOffset + this._bufferCount) | 0), ((((this._buffer.length - this._bufferCount) | 0) - this._bufferOffset) | 0)), cancellationToken);
                        this._bufferCount += read;
                        if (read === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85899739252)
            
            //--TRIMMABLE-BOUNDARY-START(193273921652)
            /*string */ ReadLine(/*int*/ lengthLimit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273921652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                let builder = null;
                try
                {
                    builder = new $.$$.System.IO.MemoryStream().$ctor$9(200);
                    /*bool*/ let foundCR = false, foundCRLF = false;
                    while(!foundCRLF && this.EnsureBuffered())
                    {
                        this.ProcessLineChar(builder, lengthLimit, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCR, ($v) => foundCR = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null));
                    }
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream.DecodeLine(builder, foundCRLF);
                }
                finally
                {
                    builder?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273921652)
            
            //--TRIMMABLE-BOUNDARY-START(197568888948)
            /*Task<string> *//*async*/  ReadLineAsync(/*int*/ lengthLimit, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.String), $.$$.System.String, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197568888948);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CheckDisposed();
                    let builder = null;
                    try
                    {
                        builder = new $.$$.System.IO.MemoryStream().$ctor$9(200);
                        /*bool*/ let foundCR = false, foundCRLF = false;
                        while(!foundCRLF && await this.EnsureBufferedAsync$1(cancellationToken))
                        {
                            this.ProcessLineChar(builder, lengthLimit, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCR, ($v) => foundCR = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => foundCRLF, ($v) => foundCRLF = $v, null));
                        }
                        return $.$maw.Microsoft.AspNetCore.WebUtilities.BufferedReadStream.DecodeLine(builder, foundCRLF);
                    }
                    finally
                    {
                        builder?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(197568888948)
            
            //--TRIMMABLE-BOUNDARY-START(176094052468)
            /*void */ ProcessLineChar(/*MemoryStream*/ builder, /*int*/ lengthLimit, /*ref bool*/ foundCR, /*ref bool*/ foundCRLF)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094052468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let writeCount = 0;
                while(this._bufferCount > 0)
                {
                    /*var*/ let b = $.$$.System.Array.$ReadT1.call(this._buffer, this._bufferOffset);
                    this._bufferOffset++;
                    this._bufferCount--;
                    writeCount++;
                    if (b === 10/*LF*/ && foundCR.$v)
                    {
                        builder.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
                        foundCRLF.$v = true;
                        return;
                    }
                    foundCR.$v = b === 13/*CR*/;
                    if (writeCount > lengthLimit)
                    {
                        throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Line length limit ${lengthLimit} exceeded.`);
                    }
                }
                builder.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._buffer, ((this._bufferOffset - writeCount) | 0), writeCount)));
            }
            //--TRIMMABLE-BOUNDARY-END(176094052468)
            
            //--TRIMMABLE-BOUNDARY-START(68719870068)
            static /*string */ DecodeLine(/*MemoryStream*/ builder, /*bool*/ foundCRLF)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let length = foundCRLF ? builder.Length - 2n : builder.Length;
                return $.$$.System.Text.Encoding.UTF8.GetString(builder.GetBuffer(), 0, $.$cast(length, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(68719870068)
            
            //--TRIMMABLE-BOUNDARY-START(60129935476)
            /*void */ CheckDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(60129935476)
            
            static $h = 393332;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655098996),
    {
      "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374575732,
        "f": 50331649
      },
      "n": "BufferedData",
      "d": 393332,
      "h": 38655098996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655098996),
//--TRIMMABLE-BOUNDARY-START(42950066292),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964510324,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 393332,
      "h": 42950066292,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950066292),
//--TRIMMABLE-BOUNDARY-START(47245033588),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554444916,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 393332,
      "h": 47245033588,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47245033588),
//--TRIMMABLE-BOUNDARY-START(51540000884),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144379508,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 393332,
      "h": 51540000884,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540000884),
//--TRIMMABLE-BOUNDARY-START(55834968180),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734314100,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 393332,
      "h": 55834968180,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55834968180),
//--TRIMMABLE-BOUNDARY-START(163209150580),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324248692,
        "f": 50364417
      },
      "n": "Length",
      "d": 393332,
      "h": 163209150580,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209150580),
//--TRIMMABLE-BOUNDARY-START(171799085172),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914183284,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453790836,
        "f": 83918849
      },
      "n": "Position",
      "d": 393332,
      "h": 171799085172,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799085172)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(201863856244),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 393332,
      "h": 201863856244,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201863856244),
//--TRIMMABLE-BOUNDARY-START(214748758132),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 393332,
      "h": 214748758132,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214748758132),
//--TRIMMABLE-BOUNDARY-START(73014837364),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 393332,
      "h": 73014837364,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73014837364),
//--TRIMMABLE-BOUNDARY-START(94489673844),
    {
      "r": 65537,
      "n": "Flush",
      "d": 393332,
      "h": 94489673844,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489673844),
//--TRIMMABLE-BOUNDARY-START(98784641140),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 393332,
      "h": 98784641140,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98784641140),
//--TRIMMABLE-BOUNDARY-START(219043725428),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 393332,
      "h": 219043725428,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043725428),
//--TRIMMABLE-BOUNDARY-START(227633660020),
    {
      "r": 180551681,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 393332,
      "h": 227633660020,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633660020),
//--TRIMMABLE-BOUNDARY-START(223338692724),
    {
      "r": 177668097,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 393332,
      "h": 223338692724,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223338692724),
//--TRIMMABLE-BOUNDARY-START(180389019764),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 393332,
      "h": 180389019764,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389019764),
//--TRIMMABLE-BOUNDARY-START(184683987060),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 393332,
      "h": 184683987060,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184683987060),
//--TRIMMABLE-BOUNDARY-START(188978954356),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 393332,
      "h": 188978954356,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(188978954356),
//--TRIMMABLE-BOUNDARY-START(77309804660),
    {
      "r": 262145,
      "n": "EnsureBuffered",
      "d": 393332,
      "h": 77309804660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309804660),
//--TRIMMABLE-BOUNDARY-START(90194706548),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "EnsureBufferedAsync",
      "o": "@$1",
      "d": 393332,
      "h": 90194706548,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(90194706548),
//--TRIMMABLE-BOUNDARY-START(81604771956),
    {
      "r": 262145,
      "p": [
        {
          "n": "minCount",
          "p": 655361
        }
      ],
      "n": "EnsureBuffered",
      "o": "@$1",
      "d": 393332,
      "h": 81604771956,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604771956),
//--TRIMMABLE-BOUNDARY-START(85899739252),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Boolean).$h,
      "p": [
        {
          "n": "minCount",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "EnsureBufferedAsync",
      "d": 393332,
      "h": 85899739252,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(85899739252),
//--TRIMMABLE-BOUNDARY-START(193273921652),
    {
      "r": 1310721,
      "p": [
        {
          "n": "lengthLimit",
          "p": 655361
        }
      ],
      "n": "ReadLine",
      "d": 393332,
      "h": 193273921652,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193273921652),
//--TRIMMABLE-BOUNDARY-START(197568888948),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "p": [
        {
          "n": "lengthLimit",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadLineAsync",
      "d": 393332,
      "h": 197568888948,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(197568888948),
//--TRIMMABLE-BOUNDARY-START(176094052468),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 93782017
        },
        {
          "n": "lengthLimit",
          "p": 655361
        },
        {
          "n": "foundCR",
          "p": 262145,
          "f": 4
        },
        {
          "n": "foundCRLF",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "ProcessLineChar",
      "d": 393332,
      "h": 176094052468,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094052468),
//--TRIMMABLE-BOUNDARY-START(68719870068),
    {
      "r": 1310721,
      "p": [
        {
          "n": "builder",
          "p": 93782017
        },
        {
          "n": "foundCRLF",
          "p": 262145
        }
      ],
      "n": "DecodeLine",
      "d": 393332,
      "h": 68719870068,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719870068),
//--TRIMMABLE-BOUNDARY-START(60129935476),
    {
      "r": 65537,
      "n": "CheckDisposed",
      "d": 393332,
      "h": 60129935476,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129935476)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64424902772),
    {
      "t": 393217,
      "n": "CR",
      "d": 393332,
      "h": 64424902772,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64424902772),
//--TRIMMABLE-BOUNDARY-START(167504117876),
    {
      "t": 393217,
      "n": "LF",
      "d": 393332,
      "h": 167504117876,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167504117876),
//--TRIMMABLE-BOUNDARY-START(25770197108),
    {
      "t": 94961665,
      "n": "_inner",
      "d": 393332,
      "h": 25770197108,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770197108),
//--TRIMMABLE-BOUNDARY-START(4295360628),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_buffer",
      "d": 393332,
      "h": 4295360628,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360628),
//--TRIMMABLE-BOUNDARY-START(17180262516),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_bytePool",
      "d": 393332,
      "h": 17180262516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180262516),
//--TRIMMABLE-BOUNDARY-START(12885295220),
    {
      "t": 655361,
      "n": "_bufferOffset",
      "d": 393332,
      "h": 12885295220,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885295220),
//--TRIMMABLE-BOUNDARY-START(8590327924),
    {
      "t": 655361,
      "n": "_bufferCount",
      "d": 393332,
      "h": 8590327924,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327924),
//--TRIMMABLE-BOUNDARY-START(21475229812),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 393332,
      "h": 21475229812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229812)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360131700),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393332,
      "h": 34360131700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360131700),
//--TRIMMABLE-BOUNDARY-START(30065164404),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393332,
      "h": 30065164404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164404)
  ],
  "i": [90308609,89718785
  ],
  "h": 393332
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `BufferedReadStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393332)
        
        
        //--TRIMMABLE-BOUNDARY-START(458868)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileBufferingReadStream", ($self) => class FileBufferingReadStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(34360197236)
            /*int*/ static _maxRentedBufferSize = 1048576;
            //--TRIMMABLE-BOUNDARY-END(34360197236)
            
            //--TRIMMABLE-BOUNDARY-START(30065229940)
            /*Stream*/ _inner = null;
            //--TRIMMABLE-BOUNDARY-END(30065229940)
            
            //--TRIMMABLE-BOUNDARY-START(12885360756)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(12885360756)
            
            //--TRIMMABLE-BOUNDARY-START(38655164532)
            /*int*/ _memoryThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(38655164532)
            
            //--TRIMMABLE-BOUNDARY-START(8590393460)
            /*long?*/ _bufferLimit = null;
            //--TRIMMABLE-BOUNDARY-END(8590393460)
            
            //--TRIMMABLE-BOUNDARY-START(47245099124)
            /*string?*/ _tempFileDirectory = null;
            //--TRIMMABLE-BOUNDARY-END(47245099124)
            
            //--TRIMMABLE-BOUNDARY-START(51540066420)
            /*Func<string>?*/ _tempFileDirectoryAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(51540066420)
            
            //--TRIMMABLE-BOUNDARY-START(55835033716)
            /*string?*/ _tempFileName = null;
            //--TRIMMABLE-BOUNDARY-END(55835033716)
            
            //--TRIMMABLE-BOUNDARY-START(4295426164)
            /*Stream*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295426164)
            
            //--TRIMMABLE-BOUNDARY-START(42950131828)
            /*byte[]?*/ _rentedBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(42950131828)
            
            //--TRIMMABLE-BOUNDARY-START(25770262644)
            /*bool*/ _inMemory = true;
            //--TRIMMABLE-BOUNDARY-END(25770262644)
            
            //--TRIMMABLE-BOUNDARY-START(17180328052)
            /*bool*/ _completelyBuffered = false;
            //--TRIMMABLE-BOUNDARY-END(17180328052)
            
            //--TRIMMABLE-BOUNDARY-START(21475295348)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475295348)
            
            //--TRIMMABLE-BOUNDARY-START(77309870196)
            $ctor$7(/*Stream*/ inner, /*int*/ memoryThreshold)
            {
                this.$ctor$4(inner, memoryThreshold, null, $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectoryFactory);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309870196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309870196)
            
            //--TRIMMABLE-BOUNDARY-START(64424968308)
            $ctor$4(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor)
            {
                this.$ctor$3(inner, memoryThreshold, bufferLimit, tempFileDirectoryAccessor, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424968308);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968308)
            
            //--TRIMMABLE-BOUNDARY-START(60130001012)
            $ctor$3(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>*/ tempFileDirectoryAccessor, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130001012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(tempFileDirectoryAccessor, "tempFileDirectoryAccessor");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130001012)
            
            //--TRIMMABLE-BOUNDARY-START(73014902900)
            $ctor$6(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory)
            {
                this.$ctor$5(inner, memoryThreshold, bufferLimit, tempFileDirectory, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014902900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014902900)
            
            //--TRIMMABLE-BOUNDARY-START(68719935604)
            $ctor$5(/*Stream*/ inner, /*int*/ memoryThreshold, /*long?*/ bufferLimit, /*string*/ tempFileDirectory, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719935604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(tempFileDirectory, "tempFileDirectory");
                    this._bytePool = bytePool;
                    if (memoryThreshold <= 1048576/*_maxRentedBufferSize*/)
                    {
                        this._rentedBuffer = bytePool.Rent(memoryThreshold);
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$8(this._rentedBuffer);
                        this._buffer.SetLength(0n);
                    }
                    else 
                    {
                        this._buffer = new $.$$.System.IO.MemoryStream().$ctor$3();
                    }
                    this._inner = inner;
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectory = tempFileDirectory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719935604)
            
            //--TRIMMABLE-BOUNDARY-START(193273987188)
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(193273987188)
            
            //--TRIMMABLE-BOUNDARY-START(184684052596)
            /*bool */ get InMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inMemory;
            }
            //--TRIMMABLE-BOUNDARY-END(184684052596)
            
            //--TRIMMABLE-BOUNDARY-START(236223660148)
            /*string? */ get TempFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389085300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tempFileName;
            }
            //--TRIMMABLE-BOUNDARY-END(236223660148)
            
            //--TRIMMABLE-BOUNDARY-START(81604837492)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(81604837492)
            
            //--TRIMMABLE-BOUNDARY-START(85899804788)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return !this._disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(85899804788)
            
            //--TRIMMABLE-BOUNDARY-START(90194772084)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90194772084)
            
            //--TRIMMABLE-BOUNDARY-START(188979019892)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._buffer.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(188979019892)
            
            //--TRIMMABLE-BOUNDARY-START(197568954484)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799150708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._buffer.Position;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this._buffer.Position = value;
            }
            //--TRIMMABLE-BOUNDARY-END(197568954484)
            
            //--TRIMMABLE-BOUNDARY-START(219043790964)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (!this._completelyBuffered && origin === 2/*SeekOrigin.End*/)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 1/*SeekOrigin.Current*/ && offset + this.Position > this.Length)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                else if (!this._completelyBuffered && origin === 0/*SeekOrigin.Begin*/ && offset > this.Length)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12("The content has not been fully buffered yet.");
                }
                return this._buffer.Seek(offset, origin);
            }
            //--TRIMMABLE-BOUNDARY-END(219043790964)
            
            //--TRIMMABLE-BOUNDARY-START(98784706676)
            /*Stream */ CreateTempFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._tempFileDirectory, null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._tempFileDirectoryAccessor !== null, "_tempFileDirectoryAccessor != null");
                    this._tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this._tempFileDirectory, null), "_tempFileDirectory != null");
                }
                this._tempFileName = $.$$.System.IO.Path.Combine$3(this._tempFileDirectory, "ASPNETCORE_" + $.$$.System.Guid.ToString.call($.$$.System.Guid.NewGuid()) + ".tmp");
                if (!$.$$.System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform($.$$.System.Runtime.InteropServices.OSPlatform.Windows))
                {
                    /*var*/ let tempTempFileName = $.$$.System.IO.Path.GetTempFileName();
                    $.$$.System.IO.File.Move$1(tempTempFileName, this._tempFileName);
                }
                return new $.$$.System.IO.FileStream().$ctor$12(this._tempFileName, 2/*FileMode.Create*/, 3/*FileAccess.ReadWrite*/, 4/*FileShare.Delete*/, ((1024 * 16) | 0), 1073741824/*FileOptions.Asynchronous*/ | 67108864/*FileOptions.DeleteOnClose*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(98784706676)
            
            //--TRIMMABLE-BOUNDARY-START(206158889076)
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158889076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                {
                    return this._buffer.Read$1(buffer);
                }
                /*var*/ let read = this._inner.Read$1(buffer);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - read < this._buffer.Length)
                {
                    throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                }
                if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                {
                    this._inMemory = false;
                    /*var*/ let oldBuffer = this._buffer;
                    this._buffer = this.CreateTempFile();
                    if (this._rentedBuffer === null)
                    {
                        oldBuffer.Position = 0n;
                        /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.System.Math.Min$4($.$cast(oldBuffer.Length, $.$$.System.Int32), 1048576/*_maxRentedBufferSize*/));
                        try
                        {
                            /*var*/ let copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                            while(copyRead > 0)
                            {
                                this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, rentedBuffer, 0, copyRead)));
                                copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(rentedBuffer, false);
                            }
                        }
                    }
                    else 
                    {
                        this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.System.Int32))));
                        this._bytePool.Return(this._rentedBuffer, false);
                        this._rentedBuffer = null;
                    }
                }
                if (read > 0)
                {
                    this._buffer.Write$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer.Slice(0, read)));
                }
                else if (buffer.Length > 0)
                {
                    this._completelyBuffered = true;
                }
                return read;
            }
            //--TRIMMABLE-BOUNDARY-END(206158889076)
            
            //--TRIMMABLE-BOUNDARY-START(201863921780)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Read$1($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, buffer, offset, count));
            }
            //--TRIMMABLE-BOUNDARY-END(201863921780)
            
            //--TRIMMABLE-BOUNDARY-START(210453856372)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
            }
            //--TRIMMABLE-BOUNDARY-END(210453856372)
            
            //--TRIMMABLE-BOUNDARY-START(214748823668)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748823668);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if (this._buffer.Position < this._buffer.Length || this._completelyBuffered)
                    {
                        return await this._buffer.ReadAsync$2(buffer, cancellationToken);
                    }
                    /*var*/ let read = await this._inner.ReadAsync$2(buffer, cancellationToken);
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - read < this._buffer.Length)
                    {
                        throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    if (this._inMemory && BigInt(this._memoryThreshold - read) < this._buffer.Length)
                    {
                        this._inMemory = false;
                        /*var*/ let oldBuffer = this._buffer;
                        this._buffer = this.CreateTempFile();
                        if (this._rentedBuffer === null)
                        {
                            oldBuffer.Position = 0n;
                            /*var*/ let rentedBuffer = this._bytePool.Rent($.$$.System.Math.Min$4($.$cast(oldBuffer.Length, $.$$.System.Int32), 1048576/*_maxRentedBufferSize*/));
                            try
                            {
                                /*var*/ let copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                                while(copyRead > 0)
                                {
                                    await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, rentedBuffer, 0, copyRead)), cancellationToken);
                                    copyRead = oldBuffer.Read$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedBuffer));
                                }
                            }
                            finally
                            {
                                {
                                    this._bytePool.Return(rentedBuffer, false);
                                }
                            }
                        }
                        else 
                        {
                            await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._rentedBuffer, 0, $.$cast(oldBuffer.Length, $.$$.System.Int32))), cancellationToken);
                            this._bytePool.Return(this._rentedBuffer, false);
                            this._rentedBuffer = null;
                        }
                    }
                    if (read > 0)
                    {
                        await this._buffer.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2(buffer.Slice(0, read)), cancellationToken);
                    }
                    else if (buffer.Length > 0)
                    {
                        this._completelyBuffered = true;
                    }
                    return read;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214748823668)
            
            //--TRIMMABLE-BOUNDARY-START(244813594740)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(244813594740)
            
            //--TRIMMABLE-BOUNDARY-START(253403529332)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(253403529332)
            
            //--TRIMMABLE-BOUNDARY-START(249108562036)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108562036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(249108562036)
            
            //--TRIMMABLE-BOUNDARY-START(231928692852)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(231928692852)
            
            //--TRIMMABLE-BOUNDARY-START(111669608564)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111669608564)
            
            //--TRIMMABLE-BOUNDARY-START(94489739380)
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                if (this._completelyBuffered)
                {
                    return this._buffer.CopyToAsync(destination, bufferSize, cancellationToken);
                }
                /*Task*/ /*async*/  function CopyToAsyncImpl()
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                    {
                        /*byte[]*/ let buffer = this._bytePool.Rent(bufferSize);
                        try
                        {
                            while(true)
                            {
                                /*int*/ let bytesRead = await this.ReadAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$1(buffer), cancellationToken);
                                if (bytesRead === 0)
                                {
                                    break;
                                }
                                await destination.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, 0, bytesRead)), cancellationToken);
                            }
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(buffer, false);
                            }
                        }
                    });
                }
                return CopyToAsyncImpl.call(this);
            }
            //--TRIMMABLE-BOUNDARY-END(94489739380)
            
            //--TRIMMABLE-BOUNDARY-START(103079673972)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    this._disposed = true;
                    if (this._rentedBuffer !== null)
                    {
                        this._bytePool.Return(this._rentedBuffer, false);
                    }
                    if (disposing)
                    {
                        this._buffer.Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673972)
            
            //--TRIMMABLE-BOUNDARY-START(107374641268)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374641268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._disposed)
                    {
                        this._disposed = true;
                        if (this._rentedBuffer !== null)
                        {
                            this._bytePool.Return(this._rentedBuffer, false);
                        }
                        await this._buffer.DisposeAsync();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107374641268)
            
            //--TRIMMABLE-BOUNDARY-START(240518627444)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(240518627444)
            
            static $h = 458868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(193273987188),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209216116,
        "f": 50331649
      },
      "n": "MemoryThreshold",
      "d": 458868,
      "h": 193273987188,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193273987188),
//--TRIMMABLE-BOUNDARY-START(184684052596),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029346932,
        "f": 50331649
      },
      "n": "InMemory",
      "d": 458868,
      "h": 184684052596,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684052596),
//--TRIMMABLE-BOUNDARY-START(236223660148),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389085300,
        "f": 50331649
      },
      "n": "TempFileName",
      "d": 458868,
      "h": 236223660148,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236223660148),
//--TRIMMABLE-BOUNDARY-START(81604837492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543156,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 458868,
      "h": 81604837492,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604837492),
//--TRIMMABLE-BOUNDARY-START(85899804788),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477748,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 458868,
      "h": 85899804788,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899804788),
//--TRIMMABLE-BOUNDARY-START(90194772084),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439412340,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 458868,
      "h": 90194772084,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90194772084),
//--TRIMMABLE-BOUNDARY-START(188979019892),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619281524,
        "f": 50364417
      },
      "n": "Length",
      "d": 458868,
      "h": 188979019892,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979019892),
//--TRIMMABLE-BOUNDARY-START(197568954484),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799150708,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227633725556,
        "f": 83918849
      },
      "n": "Position",
      "d": 458868,
      "h": 197568954484,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(197568954484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(219043790964),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 458868,
      "h": 219043790964,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219043790964),
//--TRIMMABLE-BOUNDARY-START(98784706676),
    {
      "r": 94961665,
      "n": "CreateTempFile",
      "d": 458868,
      "h": 98784706676,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784706676),
//--TRIMMABLE-BOUNDARY-START(206158889076),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 458868,
      "h": 206158889076,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(206158889076),
//--TRIMMABLE-BOUNDARY-START(201863921780),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 458868,
      "h": 201863921780,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201863921780),
//--TRIMMABLE-BOUNDARY-START(210453856372),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 458868,
      "h": 210453856372,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(210453856372),
//--TRIMMABLE-BOUNDARY-START(214748823668),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 458868,
      "h": 214748823668,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(214748823668),
//--TRIMMABLE-BOUNDARY-START(244813594740),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 458868,
      "h": 244813594740,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244813594740),
//--TRIMMABLE-BOUNDARY-START(253403529332),
    {
      "r": 180551681,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 458868,
      "h": 253403529332,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(253403529332),
//--TRIMMABLE-BOUNDARY-START(249108562036),
    {
      "r": 177668097,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 458868,
      "h": 249108562036,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108562036),
//--TRIMMABLE-BOUNDARY-START(231928692852),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 458868,
      "h": 231928692852,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(231928692852),
//--TRIMMABLE-BOUNDARY-START(111669608564),
    {
      "r": 65537,
      "n": "Flush",
      "d": 458868,
      "h": 111669608564,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669608564),
//--TRIMMABLE-BOUNDARY-START(94489739380),
    {
      "r": 177668097,
      "p": [
        {
          "n": "destination",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "CopyToAsync",
      "d": 458868,
      "h": 94489739380,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489739380),
//--TRIMMABLE-BOUNDARY-START(103079673972),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 458868,
      "h": 103079673972,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103079673972),
//--TRIMMABLE-BOUNDARY-START(107374641268),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 458868,
      "h": 107374641268,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(107374641268),
//--TRIMMABLE-BOUNDARY-START(240518627444),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 458868,
      "h": 240518627444,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518627444)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360197236),
    {
      "t": 655361,
      "n": "_maxRentedBufferSize",
      "d": 458868,
      "h": 34360197236,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34360197236),
//--TRIMMABLE-BOUNDARY-START(30065229940),
    {
      "t": 94961665,
      "n": "_inner",
      "d": 458868,
      "h": 30065229940,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065229940),
//--TRIMMABLE-BOUNDARY-START(12885360756),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_bytePool",
      "d": 458868,
      "h": 12885360756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360756),
//--TRIMMABLE-BOUNDARY-START(38655164532),
    {
      "t": 655361,
      "n": "_memoryThreshold",
      "d": 458868,
      "h": 38655164532,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655164532),
//--TRIMMABLE-BOUNDARY-START(8590393460),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_bufferLimit",
      "d": 458868,
      "h": 8590393460,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393460),
//--TRIMMABLE-BOUNDARY-START(47245099124),
    {
      "t": 1310721,
      "n": "_tempFileDirectory",
      "d": 458868,
      "h": 47245099124,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245099124),
//--TRIMMABLE-BOUNDARY-START(51540066420),
    {
      "t": $.$$.System.Func$$($.$$.System.String).$h,
      "n": "_tempFileDirectoryAccessor",
      "d": 458868,
      "h": 51540066420,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540066420),
//--TRIMMABLE-BOUNDARY-START(55835033716),
    {
      "t": 1310721,
      "n": "_tempFileName",
      "d": 458868,
      "h": 55835033716,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55835033716),
//--TRIMMABLE-BOUNDARY-START(4295426164),
    {
      "t": 94961665,
      "n": "_buffer",
      "d": 458868,
      "h": 4295426164,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426164),
//--TRIMMABLE-BOUNDARY-START(42950131828),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_rentedBuffer",
      "d": 458868,
      "h": 42950131828,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950131828),
//--TRIMMABLE-BOUNDARY-START(25770262644),
    {
      "t": 262145,
      "n": "_inMemory",
      "d": 458868,
      "h": 25770262644,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770262644),
//--TRIMMABLE-BOUNDARY-START(17180328052),
    {
      "t": 262145,
      "n": "_completelyBuffered",
      "d": 458868,
      "h": 17180328052,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180328052),
//--TRIMMABLE-BOUNDARY-START(21475295348),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 458868,
      "h": 21475295348,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295348)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77309870196),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 458868,
      "h": 77309870196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309870196),
//--TRIMMABLE-BOUNDARY-START(64424968308),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.System.Func$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458868,
      "h": 64424968308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424968308),
//--TRIMMABLE-BOUNDARY-START(60130001012),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.System.Func$$($.$$.System.String).$h
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458868,
      "h": 60130001012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130001012),
//--TRIMMABLE-BOUNDARY-START(73014902900),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "tempFileDirectory",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458868,
      "h": 73014902900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014902900),
//--TRIMMABLE-BOUNDARY-START(68719935604),
    {
      "p": [
        {
          "n": "inner",
          "p": 94961665
        },
        {
          "n": "memoryThreshold",
          "p": 655361
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.System.Int64).$h
        },
        {
          "n": "tempFileDirectory",
          "p": 1310721
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458868,
      "h": 68719935604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719935604)
  ],
  "i": [90308609,89718785
  ],
  "h": 458868
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `FileBufferingReadStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458868)
        
        
        //--TRIMMABLE-BOUNDARY-START(983156)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter", ($self) => class HttpResponseStreamWriter extends $.$$.System.IO.TextWriter
        {
            //--TRIMMABLE-BOUNDARY-START(77310394484)
            /*int*/ static DefaultBufferSize = 16384;
            //--TRIMMABLE-BOUNDARY-END(77310394484)
            
            //--TRIMMABLE-BOUNDARY-START(38655688820)
            /*Stream*/ _stream = null;
            //--TRIMMABLE-BOUNDARY-END(38655688820)
            
            //--TRIMMABLE-BOUNDARY-START(34360721524)
            /*Encoder*/ _encoder = null;
            //--TRIMMABLE-BOUNDARY-END(34360721524)
            
            //--TRIMMABLE-BOUNDARY-START(8590917748)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(8590917748)
            
            //--TRIMMABLE-BOUNDARY-START(25770786932)
            /*ArrayPool<char>*/ _charPool = null;
            //--TRIMMABLE-BOUNDARY-END(25770786932)
            
            //--TRIMMABLE-BOUNDARY-START(21475819636)
            /*int*/ _charBufferSize = 0;
            //--TRIMMABLE-BOUNDARY-END(21475819636)
            
            //--TRIMMABLE-BOUNDARY-START(4295950452)
            /*byte[]*/ _byteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295950452)
            
            //--TRIMMABLE-BOUNDARY-START(12885885044)
            /*char[]*/ _charBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(12885885044)
            
            //--TRIMMABLE-BOUNDARY-START(17180852340)
            /*int*/ _charBufferCount = 0;
            //--TRIMMABLE-BOUNDARY-END(17180852340)
            
            //--TRIMMABLE-BOUNDARY-START(30065754228)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(30065754228)
            
            //--TRIMMABLE-BOUNDARY-START(55835558004)
            $ctor$6(/*Stream*/ stream, /*Encoding*/ encoding)
            {
                this.$ctor$4(stream, encoding, 16384/*DefaultBufferSize*/, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835558004);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835558004)
            
            //--TRIMMABLE-BOUNDARY-START(51540590708)
            $ctor$5(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize)
            {
                this.$ctor$4(stream, encoding, bufferSize, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared, $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540590708);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590708)
            
            //--TRIMMABLE-BOUNDARY-START(47245623412)
            $ctor$4(/*Stream*/ stream, /*Encoding*/ encoding, /*int*/ bufferSize, /*ArrayPool<byte>*/ bytePool, /*ArrayPool<char>*/ charPool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245623412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stream = $.$firstOf(stream, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("stream") });
                    this.Encoding = $.$firstOf(encoding, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("encoding") });
                    this._bytePool = $.$firstOf(bytePool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("bytePool") });
                    this._charPool = $.$firstOf(charPool, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("charPool") });
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, bufferSize, "bufferSize");
                    if (!this._stream.CanWrite)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$maw.Resources.HttpResponseStreamWriter_StreamNotWritable, "stream");
                    }
                    this._charBufferSize = bufferSize;
                    this._encoder = encoding.GetEncoder();
                    this._charBuffer = charPool.Rent(bufferSize);
                    try
                    {
                        /*var*/ let requiredLength = encoding.GetMaxByteCount(bufferSize);
                        this._byteBuffer = bytePool.Rent(requiredLength);
                    }
                    catch($e)
                    {
                        charPool.Return(this._charBuffer, false);
                        if (this._byteBuffer !== null)
                        {
                            bytePool.Return(this._byteBuffer, false);
                        }
                        throw $e;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623412)
            
            //--TRIMMABLE-BOUNDARY-START(90195296372)
            /*Encoding*/ Encoding = null;
            //--TRIMMABLE-BOUNDARY-END(90195296372)
            
            //--TRIMMABLE-BOUNDARY-START(128850002036)
            /*void */ Write$1(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850002036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (this._charBufferCount === this._charBufferSize)
                {
                    this.FlushInternal(false);
                }
                $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                this._charBufferCount++;
            }
            //--TRIMMABLE-BOUNDARY-END(128850002036)
            
            //--TRIMMABLE-BOUNDARY-START(133144969332)
            /*void */ Write$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if (values === null)
                {
                    return;
                }
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144969332)
            
            //--TRIMMABLE-BOUNDARY-START(137439936628)
            /*void */ Write$9(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439936628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                /*var*/ let remaining = value.Length;
                while(remaining > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    /*var*/ let written = this.CopyToCharBuffer$1(value);
                    remaining -= written;
                    value = value.Slice$1(written);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439936628)
            
            //--TRIMMABLE-BOUNDARY-START(141734903924)
            /*void */ Write$16(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                if ($.$$.System.String.op_Equality(value, null))
                {
                    return;
                }
                /*var*/ let count = value.length;
                /*var*/ let index = 0;
                while(count > 0)
                {
                    if (this._charBufferCount === this._charBufferSize)
                    {
                        this.FlushInternal(false);
                    }
                    this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734903924)
            
            //--TRIMMABLE-BOUNDARY-START(180389609588)
            /*void */ WriteLine$10(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389609588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this.Write$9(value);
                this.Write$16(this.NewLine);
            }
            //--TRIMMABLE-BOUNDARY-END(180389609588)
            
            //--TRIMMABLE-BOUNDARY-START(146029871220)
            /*Task */ WriteAsync(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (this._charBufferCount === this._charBufferSize)
                {
                    return this.WriteAsyncAwaited(value);
                }
                else 
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029871220)
            
            //--TRIMMABLE-BOUNDARY-START(163209740404)
            /*Task *//*async*/  WriteAsyncAwaited(/*char*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209740404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(this._charBufferCount === this._charBufferSize, "_charBufferCount == _charBufferSize");
                    await this.FlushInternalAsync(false);
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                });
            }
            //--TRIMMABLE-BOUNDARY-END(163209740404)
            
            //--TRIMMABLE-BOUNDARY-START(150324838516)
            /*Task */ WriteAsync$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324838516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (values === null || count === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= count)
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$1(values, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324838516)
            
            //--TRIMMABLE-BOUNDARY-START(167504707700)
            /*Task *//*async*/  WriteAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504707700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(count > 0, "count > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504707700)
            
            //--TRIMMABLE-BOUNDARY-START(158914773108)
            /*Task */ WriteAsync$4(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914773108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.length)
                {
                    this.CopyToCharBuffer$3(value);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$3(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914773108)
            
            //--TRIMMABLE-BOUNDARY-START(176094642292)
            /*Task *//*async*/  WriteAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094642292);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let count = value.length;
                    $.$$.System.Diagnostics.Debug.Assert$2(count > 0, "count > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < count, "_charBufferSize - _charBufferCount < count");
                    /*var*/ let index = 0;
                    while(count > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        this.CopyToCharBuffer$2(value, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176094642292)
            
            //--TRIMMABLE-BOUNDARY-START(154619805812)
            /*Task */ WriteAsync$3(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= value.Length)
                {
                    this.CopyToCharBuffer$1(value.Span);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteAsyncAwaited$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619805812)
            
            //--TRIMMABLE-BOUNDARY-START(171799674996)
            /*Task *//*async*/  WriteAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799674996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(value.Length > 0, "value.Length > 0");
                    $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) < value.Length, "_charBufferSize - _charBufferCount < value.Length");
                    /*var*/ let remaining = value.Length;
                    while(remaining > 0)
                    {
                        if (this._charBufferCount === this._charBufferSize)
                        {
                            await this.FlushInternalAsync(false);
                        }
                        /*var*/ let written = this.CopyToCharBuffer$1(value.Span);
                        remaining -= written;
                        value = value.Slice$1(written);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(171799674996)
            
            //--TRIMMABLE-BOUNDARY-START(193274511476)
            /*Task */ WriteLineAsync$4(/*ReadOnlyMemory<char>*/ value, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274511476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if (cancellationToken.IsCancellationRequested)
                {
                    return $.$$.System.Threading.Tasks.Task.FromCanceled$1(cancellationToken);
                }
                if (value.IsEmpty && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.Length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$1(value.Span);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$2(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274511476)
            
            //--TRIMMABLE-BOUNDARY-START(210454380660)
            /*Task *//*async*/  WriteLineAsyncAwaited$2(/*ReadOnlyMemory<char>*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(210454380660);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.WriteAsync$3(value, new $.$$.System.Threading.CancellationToken());
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(210454380660)
            
            //--TRIMMABLE-BOUNDARY-START(188979544180)
            /*Task */ WriteLineAsync$2(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979544180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ((values === null || count === 0) && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                values ??= $.$$.System.Array.Empty($.$$.System.Char);
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((values.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer(values, $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$1(values, index, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979544180)
            
            //--TRIMMABLE-BOUNDARY-START(206159413364)
            /*Task *//*async*/  WriteLineAsyncAwaited$1(/*char[]*/ values, /*int*/ index, /*int*/ count)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159413364);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.WriteAsync$1(values, index, count);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(206159413364)
            
            //--TRIMMABLE-BOUNDARY-START(184684576884)
            /*Task */ WriteLineAsync$1(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684576884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((this.NewLine.length + 1) | 0))
                {
                    $.$$.System.Array.$WriteT1.call(this._charBuffer, value, this._charBufferCount);
                    this._charBufferCount++;
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684576884)
            
            //--TRIMMABLE-BOUNDARY-START(201864446068)
            /*Task *//*async*/  WriteLineAsyncAwaited(/*char*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864446068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.WriteAsync(value);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(201864446068)
            
            //--TRIMMABLE-BOUNDARY-START(197569478772)
            /*Task */ WriteLineAsync$5(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569478772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                if ($.$$.System.String.IsNullOrEmpty(value) && this.NewLine.length === 0)
                {
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                value ??= $.$$.System.String.Empty;
                /*var*/ let remaining = ((this._charBufferSize - this._charBufferCount) | 0);
                if (remaining >= ((value.length + this.NewLine.length) | 0))
                {
                    this.CopyToCharBuffer$3(value);
                    this.CopyToCharBuffer$3(this.NewLine);
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
                else 
                {
                    return this.WriteLineAsyncAwaited$3(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569478772)
            
            //--TRIMMABLE-BOUNDARY-START(214749347956)
            /*Task *//*async*/  WriteLineAsyncAwaited$3(/*string*/ value)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749347956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.WriteAsync$4(value);
                    await this.WriteAsync$4(this.NewLine);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(214749347956)
            
            //--TRIMMABLE-BOUNDARY-START(94490263668)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490263668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfDisposed();
                this.FlushInternal(true);
            }
            //--TRIMMABLE-BOUNDARY-END(94490263668)
            
            //--TRIMMABLE-BOUNDARY-START(98785230964)
            /*Task */ FlushAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return $.$maw.Microsoft.AspNetCore.WebUtilities.HttpResponseStreamWriter.GetObjectDisposedTask();
                }
                return this.FlushInternalAsync(true);
            }
            //--TRIMMABLE-BOUNDARY-END(98785230964)
            
            //--TRIMMABLE-BOUNDARY-START(81605361780)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing && !this._disposed)
                {
                    this._disposed = true;
                    try
                    {
                        this.FlushInternal(true);
                    }
                    finally
                    {
                        {
                            this._bytePool.Return(this._byteBuffer, false);
                            this._charPool.Return(this._charBuffer, false);
                        }
                    }
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(81605361780)
            
            //--TRIMMABLE-BOUNDARY-START(85900329076)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900329076);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this._disposed)
                    {
                        this._disposed = true;
                        try
                        {
                            await this.FlushInternalAsync(true);
                        }
                        finally
                        {
                            {
                                this._bytePool.Return(this._byteBuffer, false);
                                this._charPool.Return(this._charBuffer, false);
                            }
                        }
                    }
                    await super.DisposeAsync();
                });
            }
            //--TRIMMABLE-BOUNDARY-END(85900329076)
            
            //--TRIMMABLE-BOUNDARY-START(103080198260)
            /*void */ FlushInternal(/*bool*/ flushEncoder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080198260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._charBufferCount === 0)
                {
                    return;
                }
                /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                this._charBufferCount = 0;
                if (count > 0)
                {
                    this._stream.Write(this._byteBuffer, 0, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080198260)
            
            //--TRIMMABLE-BOUNDARY-START(107375165556)
            /*Task *//*async*/  FlushInternalAsync(/*bool*/ flushEncoder)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107375165556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._charBufferCount === 0)
                    {
                        return;
                    }
                    /*var*/ let count = this._encoder.GetBytes(this._charBuffer, 0, this._charBufferCount, this._byteBuffer, 0, flushEncoder);
                    this._charBufferCount = 0;
                    if (count > 0)
                    {
                        await this._stream.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, this._byteBuffer, 0, count)), new $.$$.System.Threading.CancellationToken());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(107375165556)
            
            //--TRIMMABLE-BOUNDARY-START(73015427188)
            /*void */ CopyToCharBuffer$3(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(((this._charBufferSize - this._charBufferCount) | 0) >= value.length, "_charBufferSize - _charBufferCount >= value.Length");
                $.$$.System.String.CopyTo.call(value, 0, this._charBuffer, this._charBufferCount, value.length);
                this._charBufferCount += value.length;
            }
            //--TRIMMABLE-BOUNDARY-END(73015427188)
            
            //--TRIMMABLE-BOUNDARY-START(68720459892)
            /*void */ CopyToCharBuffer$2(/*string*/ value, /*ref int*/ index, /*ref int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.System.String.CopyTo.call(value, index.$v, this._charBuffer, this._charBufferCount, remaining);
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459892)
            
            //--TRIMMABLE-BOUNDARY-START(60130525300)
            /*void */ CopyToCharBuffer(/*char[]*/ values, /*ref int*/ index, /*ref int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), count.$v);
                $.$$.System.Buffer.BlockCopy(values, ((index.$v * $.$$.System.Char.$z) | 0), this._charBuffer, ((this._charBufferCount * $.$$.System.Char.$z) | 0), ((remaining * $.$$.System.Char.$z) | 0));
                this._charBufferCount += remaining;
                index.$v += remaining;
                count.$v -= remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(60130525300)
            
            //--TRIMMABLE-BOUNDARY-START(64425492596)
            /*int */ CopyToCharBuffer$1(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let remaining = $.$$.System.Math.Min$4(((this._charBufferSize - this._charBufferCount) | 0), value.Length);
                /*var*/ let source = value.Slice(0, remaining);
                /*var*/ let destination = new ($.$$.System.Span$$($.$$.System.Char))().$ctor$3(this._charBuffer, this._charBufferCount, remaining);
                source.CopyTo(destination);
                this._charBufferCount += remaining;
                return remaining;
            }
            //--TRIMMABLE-BOUNDARY-END(64425492596)
            
            //--TRIMMABLE-BOUNDARY-START(120260067444)
            static /*Task */ GetObjectDisposedTask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Threading.Tasks.Task.FromException(new $.$$.System.ObjectDisposedException().$ctor$17("HttpResponseStreamWriter"));
            }
            //--TRIMMABLE-BOUNDARY-END(120260067444)
            
            //--TRIMMABLE-BOUNDARY-START(124555034740)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034740)
            
            static $h = 983156;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 95813633,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195296372),
    {
      "p": 165937153,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965100148,
        "f": 50364417
      },
      "n": "Encoding",
      "d": 983156,
      "h": 90195296372,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195296372)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(128850002036),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 983156,
      "h": 128850002036,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850002036),
//--TRIMMABLE-BOUNDARY-START(133144969332),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 983156,
      "h": 133144969332,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144969332),
//--TRIMMABLE-BOUNDARY-START(137439936628),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Write",
      "o": "@$9",
      "d": 983156,
      "h": 137439936628,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439936628),
//--TRIMMABLE-BOUNDARY-START(141734903924),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$16",
      "d": 983156,
      "h": 141734903924,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734903924),
//--TRIMMABLE-BOUNDARY-START(180389609588),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteLine",
      "o": "@$10",
      "d": 983156,
      "h": 180389609588,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389609588),
//--TRIMMABLE-BOUNDARY-START(146029871220),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteAsync",
      "d": 983156,
      "h": 146029871220,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029871220),
//--TRIMMABLE-BOUNDARY-START(163209740404),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteAsyncAwaited",
      "d": 983156,
      "h": 163209740404,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(163209740404),
//--TRIMMABLE-BOUNDARY-START(150324838516),
    {
      "r": 177668097,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteAsync",
      "o": "@$1",
      "d": 983156,
      "h": 150324838516,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324838516),
//--TRIMMABLE-BOUNDARY-START(167504707700),
    {
      "r": 177668097,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$1",
      "d": 983156,
      "h": 167504707700,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(167504707700),
//--TRIMMABLE-BOUNDARY-START(158914773108),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteAsync",
      "o": "@$4",
      "d": 983156,
      "h": 158914773108,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914773108),
//--TRIMMABLE-BOUNDARY-START(176094642292),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$3",
      "d": 983156,
      "h": 176094642292,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(176094642292),
//--TRIMMABLE-BOUNDARY-START(154619805812),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$3",
      "d": 983156,
      "h": 154619805812,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619805812),
//--TRIMMABLE-BOUNDARY-START(171799674996),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteAsyncAwaited",
      "o": "@$2",
      "d": 983156,
      "h": 171799674996,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(171799674996),
//--TRIMMABLE-BOUNDARY-START(193274511476),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$4",
      "d": 983156,
      "h": 193274511476,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274511476),
//--TRIMMABLE-BOUNDARY-START(210454380660),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$2",
      "d": 983156,
      "h": 210454380660,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(210454380660),
//--TRIMMABLE-BOUNDARY-START(188979544180),
    {
      "r": 177668097,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$2",
      "d": 983156,
      "h": 188979544180,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188979544180),
//--TRIMMABLE-BOUNDARY-START(206159413364),
    {
      "r": 177668097,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$1",
      "d": 983156,
      "h": 206159413364,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(206159413364),
//--TRIMMABLE-BOUNDARY-START(184684576884),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$1",
      "d": 983156,
      "h": 184684576884,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684576884),
//--TRIMMABLE-BOUNDARY-START(201864446068),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "d": 983156,
      "h": 201864446068,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(201864446068),
//--TRIMMABLE-BOUNDARY-START(197569478772),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteLineAsync",
      "o": "@$5",
      "d": 983156,
      "h": 197569478772,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569478772),
//--TRIMMABLE-BOUNDARY-START(214749347956),
    {
      "r": 177668097,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteLineAsyncAwaited",
      "o": "@$3",
      "d": 983156,
      "h": 214749347956,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(214749347956),
//--TRIMMABLE-BOUNDARY-START(94490263668),
    {
      "r": 65537,
      "n": "Flush",
      "d": 983156,
      "h": 94490263668,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490263668),
//--TRIMMABLE-BOUNDARY-START(98785230964),
    {
      "r": 177668097,
      "n": "FlushAsync",
      "d": 983156,
      "h": 98785230964,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785230964),
//--TRIMMABLE-BOUNDARY-START(81605361780),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 983156,
      "h": 81605361780,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81605361780),
//--TRIMMABLE-BOUNDARY-START(85900329076),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 983156,
      "h": 85900329076,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(85900329076),
//--TRIMMABLE-BOUNDARY-START(103080198260),
    {
      "r": 65537,
      "p": [
        {
          "n": "flushEncoder",
          "p": 262145
        }
      ],
      "n": "FlushInternal",
      "d": 983156,
      "h": 103080198260,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103080198260),
//--TRIMMABLE-BOUNDARY-START(107375165556),
    {
      "r": 177668097,
      "p": [
        {
          "n": "flushEncoder",
          "p": 262145
        }
      ],
      "n": "FlushInternalAsync",
      "d": 983156,
      "h": 107375165556,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(107375165556),
//--TRIMMABLE-BOUNDARY-START(73015427188),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$3",
      "d": 983156,
      "h": 73015427188,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015427188),
//--TRIMMABLE-BOUNDARY-START(68720459892),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "count",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$2",
      "d": 983156,
      "h": 68720459892,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720459892),
//--TRIMMABLE-BOUNDARY-START(60130525300),
    {
      "r": 65537,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361,
          "f": 4
        },
        {
          "n": "count",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "CopyToCharBuffer",
      "d": 983156,
      "h": 60130525300,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130525300),
//--TRIMMABLE-BOUNDARY-START(64425492596),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "CopyToCharBuffer",
      "o": "@$1",
      "d": 983156,
      "h": 64425492596,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425492596),
//--TRIMMABLE-BOUNDARY-START(120260067444),
    {
      "r": 177668097,
      "n": "GetObjectDisposedTask",
      "d": 983156,
      "h": 120260067444,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120260067444),
//--TRIMMABLE-BOUNDARY-START(124555034740),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 983156,
      "h": 124555034740,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555034740)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77310394484),
    {
      "t": 655361,
      "n": "DefaultBufferSize",
      "d": 983156,
      "h": 77310394484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310394484),
//--TRIMMABLE-BOUNDARY-START(38655688820),
    {
      "t": 94961665,
      "n": "_stream",
      "d": 983156,
      "h": 38655688820,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655688820),
//--TRIMMABLE-BOUNDARY-START(34360721524),
    {
      "t": 165216257,
      "n": "_encoder",
      "d": 983156,
      "h": 34360721524,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360721524),
//--TRIMMABLE-BOUNDARY-START(8590917748),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_bytePool",
      "d": 983156,
      "h": 8590917748,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917748),
//--TRIMMABLE-BOUNDARY-START(25770786932),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h,
      "n": "_charPool",
      "d": 983156,
      "h": 25770786932,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786932),
//--TRIMMABLE-BOUNDARY-START(21475819636),
    {
      "t": 655361,
      "n": "_charBufferSize",
      "d": 983156,
      "h": 21475819636,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819636),
//--TRIMMABLE-BOUNDARY-START(4295950452),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_byteBuffer",
      "d": 983156,
      "h": 4295950452,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950452),
//--TRIMMABLE-BOUNDARY-START(12885885044),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_charBuffer",
      "d": 983156,
      "h": 12885885044,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885044),
//--TRIMMABLE-BOUNDARY-START(17180852340),
    {
      "t": 655361,
      "n": "_charBufferCount",
      "d": 983156,
      "h": 17180852340,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852340),
//--TRIMMABLE-BOUNDARY-START(30065754228),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 983156,
      "h": 30065754228,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065754228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835558004),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 983156,
      "h": 55835558004,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835558004),
//--TRIMMABLE-BOUNDARY-START(51540590708),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 983156,
      "h": 51540590708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590708),
//--TRIMMABLE-BOUNDARY-START(47245623412),
    {
      "p": [
        {
          "n": "stream",
          "p": 94961665
        },
        {
          "n": "encoding",
          "p": 165937153
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        },
        {
          "n": "charPool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 983156,
      "h": 47245623412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245623412)
  ],
  "i": [90308609,89718785
  ],
  "h": 983156
}; }
            static get $b() { return $.$$.System.IO.TextWriter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `HttpResponseStreamWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983156)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245300)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream", ($self) => class MultipartReaderStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4296212596)
            /*MultipartBoundary*/ _boundary = null;
            //--TRIMMABLE-BOUNDARY-END(4296212596)
            
            //--TRIMMABLE-BOUNDARY-START(21476081780)
            /*BufferedReadStream*/ _innerStream = null;
            //--TRIMMABLE-BOUNDARY-END(21476081780)
            
            //--TRIMMABLE-BOUNDARY-START(8591179892)
            /*ArrayPool<byte>*/ _bytePool = null;
            //--TRIMMABLE-BOUNDARY-END(8591179892)
            
            //--TRIMMABLE-BOUNDARY-START(17181114484)
            /*long*/ _innerOffset = 0n;
            //--TRIMMABLE-BOUNDARY-END(17181114484)
            
            //--TRIMMABLE-BOUNDARY-START(30066016372)
            /*long*/ _position = 0n;
            //--TRIMMABLE-BOUNDARY-END(30066016372)
            
            //--TRIMMABLE-BOUNDARY-START(25771049076)
            /*long*/ _observedLength = 0n;
            //--TRIMMABLE-BOUNDARY-END(25771049076)
            
            //--TRIMMABLE-BOUNDARY-START(12886147188)
            /*bool*/ _finished = false;
            //--TRIMMABLE-BOUNDARY-END(12886147188)
            
            //--TRIMMABLE-BOUNDARY-START(47245885556)
            $ctor$4(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary)
            {
                this.$ctor$3(stream, boundary, $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245885556);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245885556)
            
            //--TRIMMABLE-BOUNDARY-START(42950918260)
            $ctor$3(/*BufferedReadStream*/ stream, /*MultipartBoundary*/ boundary, /*ArrayPool<byte>*/ bytePool)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950918260);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stream, "stream");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(boundary, "boundary");
                    this._bytePool = bytePool;
                    this._innerStream = stream;
                    this._innerOffset = this._innerStream.CanSeek ? this._innerStream.Position : 0n;
                    this._boundary = boundary;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950918260)
            
            //--TRIMMABLE-BOUNDARY-START(73015689332)
            /*bool*/ FinalBoundaryFound = false;
            //--TRIMMABLE-BOUNDARY-END(73015689332)
            
            //--TRIMMABLE-BOUNDARY-START(146030133364)
            /*long?*/ LengthLimit = null;
            //--TRIMMABLE-BOUNDARY-END(146030133364)
            
            //--TRIMMABLE-BOUNDARY-START(51540852852)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51540852852)
            
            //--TRIMMABLE-BOUNDARY-START(55835820148)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerStream.CanSeek;
            }
            //--TRIMMABLE-BOUNDARY-END(55835820148)
            
            //--TRIMMABLE-BOUNDARY-START(60130787444)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60130787444)
            
            //--TRIMMABLE-BOUNDARY-START(141735166068)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._observedLength;
            }
            //--TRIMMABLE-BOUNDARY-END(141735166068)
            
            //--TRIMMABLE-BOUNDARY-START(150325100660)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._position;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0n)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The Position must be positive.");
                }
                if (value > this._observedLength)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int64), "The Position must be less than length.");
                }
                this._position = value;
                if (this._position < this._observedLength)
                {
                    this._finished = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325100660)
            
            //--TRIMMABLE-BOUNDARY-START(171799937140)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (origin === 0/*SeekOrigin.Begin*/)
                {
                    this.Position = offset;
                }
                else if (origin === 1/*SeekOrigin.Current*/)
                {
                    this.Position = this.Position + offset;
                }
                else 
                {
                    this.Position = this.Length + offset;
                }
                return this.Position;
            }
            //--TRIMMABLE-BOUNDARY-END(171799937140)
            
            //--TRIMMABLE-BOUNDARY-START(201864708212)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864708212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(201864708212)
            
            //--TRIMMABLE-BOUNDARY-START(214749610100)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749610100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(214749610100)
            
            //--TRIMMABLE-BOUNDARY-START(223339544692)
            /*ValueTask */ WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339544692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(223339544692)
            
            //--TRIMMABLE-BOUNDARY-START(219044577396)
            /*Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044577396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(219044577396)
            
            //--TRIMMABLE-BOUNDARY-START(77310656628)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(77310656628)
            
            //--TRIMMABLE-BOUNDARY-START(154620067956)
            /*void */ PositionInnerStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._innerStream.CanSeek && this._innerStream.Position !== (this._innerOffset + this._position))
                {
                    this._innerStream.Position = this._innerOffset + this._position;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620067956)
            
            //--TRIMMABLE-BOUNDARY-START(210454642804)
            /*int */ UpdatePosition(/*int*/ read)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454642804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._position += BigInt(read);
                if (this._observedLength < this._position)
                {
                    this._observedLength = this._position;
                    let lengthLimit;
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this.LengthLimit) && (lengthLimit = $.$$.System.Nullable$$($.$$.System.Int64).GetValueOrDefault.call(this.LengthLimit)) && this._observedLength > lengthLimit)
                    {
                        if (this._boundary.BeforeFirstBoundary())
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart header length limit ${lengthLimit} exceeded. Too much data before the first boundary.`);
                        }
                        else 
                        {
                            throw new $.$$.System.IO.InvalidDataException().$ctor$12(`Multipart body length limit ${lengthLimit} exceeded.`);
                        }
                    }
                }
                return read;
            }
            //--TRIMMABLE-BOUNDARY-END(210454642804)
            
            //--TRIMMABLE-BOUNDARY-START(158915035252)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915035252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._finished)
                {
                    return 0;
                }
                this.PositionInnerStream();
                if (!this._innerStream.EnsureBuffered$1(this._boundary.FinalBoundaryLength))
                {
                    throw new $.$$.System.IO.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                }
                /*var*/ let bufferedData = this._innerStream.BufferedData;
                /*var*/ let index = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$9($.$$.System.Byte, bufferedData)), this._boundary.BoundaryBytes);
                if (index >= 0)
                {
                    if (index !== 0)
                    {
                        /*var*/ let slice = $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, buffer, offset, $.$$.System.Math.Min$4(count, index));
                        /*var*/ let readAmount = this._innerStream.Read$1(slice);
                        return this.UpdatePosition(readAmount);
                    }
                    else 
                    {
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        return ReadBoundary(this, length);
                    }
                }
                /*int*/ let read;
                /*var*/ let matchOffset;
                /*var*/ let matchCount;
                if ($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.System.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.System.Int32)))
                {
                    if (matchOffset > bufferedData.Offset)
                    {
                        read = this._innerStream.Read(buffer, offset, $.$$.System.Math.Min$4(count, ((matchOffset - bufferedData.Offset) | 0)));
                        return this.UpdatePosition(read);
                    }
                    /*var*/ let length = this._boundary.BoundaryBytes.Length;
                    $.$$.System.Diagnostics.Debug.Assert$2(matchCount === length, "matchCount == length");
                    return ReadBoundary(this, length);
                }
                read = this._innerStream.Read(buffer, offset, $.$$.System.Math.Min$4(count, bufferedData.Count));
                return this.UpdatePosition(read);
                /*static int*/  function ReadBoundary(/*MultipartReaderStream*/ stream, /*int*/ length)
                {
                    /*var*/ let boundary = stream._bytePool.Rent(length);
                    /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                    stream._bytePool.Return(boundary, false);
                    $.$$.System.Diagnostics.Debug.Assert$2(read === length, "read == length");
                    /*var*/ let remainder = $.$$.System.MemoryExtensions.AsSpan$4(stream._innerStream.ReadLine(100));
                    remainder = $.$$.System.MemoryExtensions.Trim$4(remainder);
                    if ($.$$.System.MemoryExtensions.Equals$2(remainder, $.$$.System.String.op_Implicit("--"), 4/*StringComparison.Ordinal*/))
                    {
                        stream.FinalBoundaryFound = true;
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(stream.FinalBoundaryFound || remainder.IsEmpty, "Un-expected data found on the boundary line: " + $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(remainder));
                    stream._finished = true;
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915035252)
            
            //--TRIMMABLE-BOUNDARY-START(163210002548)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163210002548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ReadAsync$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count), cancellationToken).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210002548)
            
            //--TRIMMABLE-BOUNDARY-START(167504969844)
            /*ValueTask<int> *//*async*/  ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504969844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._finished)
                    {
                        return 0;
                    }
                    this.PositionInnerStream();
                    if (!await this._innerStream.EnsureBufferedAsync(this._boundary.FinalBoundaryLength, cancellationToken))
                    {
                        throw new $.$$.System.IO.IOException().$ctor$13("Unexpected end of Stream, the content may have already been read by another component. ");
                    }
                    /*var*/ let bufferedData = this._innerStream.BufferedData;
                    /*var*/ let index = $.$$.System.MemoryExtensions.IndexOf$2($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$9($.$$.System.Byte, bufferedData)), this._boundary.BoundaryBytes);
                    if (index >= 0)
                    {
                        if (index !== 0)
                        {
                            let $t1 = buffer;
                            /*var*/ let slice = $t1.Slice(0, $.$$.System.Math.Min$4(buffer.Length, index));
                            /*var*/ let readAmount = this._innerStream.Read$1(slice.Span);
                            return this.UpdatePosition(readAmount);
                        }
                        else 
                        {
                            /*var*/ let length = this._boundary.BoundaryBytes.Length;
                            return await ReadBoundaryAsync(this, length, cancellationToken);
                        }
                    }
                    /*int*/ let matchOffset;
                    /*int*/ let matchCount;
                    /*int*/ let read;
                    if ($.$maw.Microsoft.AspNetCore.WebUtilities.MultipartReaderStream.SubMatch(bufferedData, this._boundary.BoundaryBytes, $.$ref(() => matchOffset, ($v) => matchOffset = $v, $.$$.System.Int32), $.$ref(() => matchCount, ($v) => matchCount = $v, $.$$.System.Int32)))
                    {
                        if (matchOffset > bufferedData.Offset)
                        {
                            let $t3 = buffer;
                            /*var*/ let slice = $t3.Slice(0, $.$$.System.Math.Min$4(buffer.Length, ((matchOffset - bufferedData.Offset) | 0)));
                            read = this._innerStream.Read$1(slice.Span);
                            return this.UpdatePosition(read);
                        }
                        /*var*/ let length = this._boundary.BoundaryBytes.Length;
                        $.$$.System.Diagnostics.Debug.Assert$2(matchCount === length, "matchCount == length");
                        return await ReadBoundaryAsync(this, length, cancellationToken);
                    }
                    let $t3 = buffer.Span;
                    read = this._innerStream.Read$1($t3.Slice(0, $.$$.System.Math.Min$4(buffer.Length, bufferedData.Count)));
                    return this.UpdatePosition(read);
                    /*static Task<int>*/ /*async*/  function ReadBoundaryAsync(/*MultipartReaderStream*/ stream, /*int*/ length, /*CancellationToken*/ cancellationToken)
                    {
                        return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                        {
                            /*var*/ let boundary = stream._bytePool.Rent(length);
                            /*var*/ let read = stream._innerStream.Read(boundary, 0, length);
                            stream._bytePool.Return(boundary, false);
                            $.$$.System.Diagnostics.Debug.Assert$2(read === length, "read == length");
                            /*var*/ let remainder = await stream._innerStream.ReadLineAsync(100, cancellationToken);
                            remainder = $.$$.System.String.Trim.call(remainder);
                            if ($.$$.System.String.Equals$2("--", remainder, 4/*StringComparison.Ordinal*/))
                            {
                                stream.FinalBoundaryFound = true;
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(stream.FinalBoundaryFound || $.$$.System.String.Equals$2($.$$.System.String.Empty, remainder, 4/*StringComparison.Ordinal*/), "Un-expected data found on the boundary line: " + remainder);
                            stream._finished = true;
                            return 0;
                        });
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(167504969844)
            
            //--TRIMMABLE-BOUNDARY-START(206159675508)
            static /*bool */ SubMatch(/*ArraySegment<byte>*/ segment1, /*ReadOnlySpan<byte>*/ matchBytes, /*out int*/ matchOffset, /*out int*/ matchCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159675508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                matchOffset.$v = $.$$.System.Math.Max$4(segment1.Offset, ((((segment1.Offset + segment1.Count) | 0) - matchBytes.Length) | 0));
                /*var*/ let segmentEnd = ((segment1.Offset + segment1.Count) | 0);
                matchCount.$v = 0;
                for(; matchOffset.$v < segmentEnd; matchOffset.$v++)
                {
                    /*var*/ let countLimit = ((segmentEnd - matchOffset.$v) | 0);
                    for(matchCount.$v = 0; matchCount.$v < matchBytes.Length && matchCount.$v < countLimit; matchCount.$v++)
                    {
                        if (matchBytes.get_Item(matchCount.$v).$v !== $.$$.System.Array.$ReadT1.call(segment1.Array, ((matchOffset.$v + matchCount.$v) | 0)))
                        {
                            matchCount.$v = 0;
                            break;
                        }
                    }
                    if (matchCount.$v > 0)
                    {
                        break;
                    }
                }
                return matchCount.$v > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(206159675508)
            
            //--TRIMMABLE-BOUNDARY-START(64425754740)
            /*void */ CopyTo(/*Stream*/ destination, /*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                super.CopyTo(destination, bufferSize);
            }
            //--TRIMMABLE-BOUNDARY-END(64425754740)
            
            //--TRIMMABLE-BOUNDARY-START(68720722036)
            /*Task */ CopyToAsync(/*Stream*/ destination, /*int*/ bufferSize, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720722036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bufferSize = $.$$.System.Math.Max$4(4096, bufferSize);
                return super.CopyToAsync(destination, bufferSize, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(68720722036)
            
            static $h = 1245300;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015689332),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670394996,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389871732,
        "f": 83886082
      },
      "n": "FinalBoundaryFound",
      "d": 1245300,
      "h": 73015689332,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015689332),
//--TRIMMABLE-BOUNDARY-START(146030133364),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850264180,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979806324,
        "f": 83886081
      },
      "n": "LengthLimit",
      "d": 1245300,
      "h": 146030133364,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146030133364),
//--TRIMMABLE-BOUNDARY-START(51540852852),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900591220,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 1245300,
      "h": 51540852852,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540852852),
//--TRIMMABLE-BOUNDARY-START(55835820148),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490525812,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 1245300,
      "h": 55835820148,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835820148),
//--TRIMMABLE-BOUNDARY-START(60130787444),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080460404,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 1245300,
      "h": 60130787444,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130787444),
//--TRIMMABLE-BOUNDARY-START(141735166068),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260329588,
        "f": 50364417
      },
      "n": "Length",
      "d": 1245300,
      "h": 141735166068,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735166068),
//--TRIMMABLE-BOUNDARY-START(150325100660),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440198772,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569740916,
        "f": 83918849
      },
      "n": "Position",
      "d": 1245300,
      "h": 150325100660,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150325100660)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(171799937140),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 1245300,
      "h": 171799937140,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799937140),
//--TRIMMABLE-BOUNDARY-START(201864708212),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1245300,
      "h": 201864708212,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201864708212),
//--TRIMMABLE-BOUNDARY-START(214749610100),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1245300,
      "h": 214749610100,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214749610100),
//--TRIMMABLE-BOUNDARY-START(223339544692),
    {
      "r": 180551681,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 1245300,
      "h": 223339544692,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(223339544692),
//--TRIMMABLE-BOUNDARY-START(219044577396),
    {
      "r": 177668097,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 1245300,
      "h": 219044577396,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(219044577396),
//--TRIMMABLE-BOUNDARY-START(77310656628),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1245300,
      "h": 77310656628,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310656628),
//--TRIMMABLE-BOUNDARY-START(154620067956),
    {
      "r": 65537,
      "n": "PositionInnerStream",
      "d": 1245300,
      "h": 154620067956,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154620067956),
//--TRIMMABLE-BOUNDARY-START(210454642804),
    {
      "r": 655361,
      "p": [
        {
          "n": "read",
          "p": 655361
        }
      ],
      "n": "UpdatePosition",
      "d": 1245300,
      "h": 210454642804,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454642804),
//--TRIMMABLE-BOUNDARY-START(158915035252),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1245300,
      "h": 158915035252,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158915035252),
//--TRIMMABLE-BOUNDARY-START(163210002548),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 1245300,
      "h": 163210002548,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163210002548),
//--TRIMMABLE-BOUNDARY-START(167504969844),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 1245300,
      "h": 167504969844,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(167504969844),
//--TRIMMABLE-BOUNDARY-START(206159675508),
    {
      "r": 262145,
      "p": [
        {
          "n": "segment1",
          "p": $.$$.System.ArraySegment$$($.$$.System.Byte).$h
        },
        {
          "n": "matchBytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "matchOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "matchCount",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "SubMatch",
      "d": 1245300,
      "h": 206159675508,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206159675508),
//--TRIMMABLE-BOUNDARY-START(64425754740),
    {
      "r": 65537,
      "p": [
        {
          "n": "destination",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1245300,
      "h": 64425754740,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425754740),
//--TRIMMABLE-BOUNDARY-START(68720722036),
    {
      "r": 177668097,
      "p": [
        {
          "n": "destination",
          "p": 94961665
        },
        {
          "n": "bufferSize",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "CopyToAsync",
      "d": 1245300,
      "h": 68720722036,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720722036)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212596),
    {
      "t": 1114228,
      "n": "_boundary",
      "d": 1245300,
      "h": 4296212596,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212596),
//--TRIMMABLE-BOUNDARY-START(21476081780),
    {
      "t": 393332,
      "n": "_innerStream",
      "d": 1245300,
      "h": 21476081780,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081780),
//--TRIMMABLE-BOUNDARY-START(8591179892),
    {
      "t": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h,
      "n": "_bytePool",
      "d": 1245300,
      "h": 8591179892,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179892),
//--TRIMMABLE-BOUNDARY-START(17181114484),
    {
      "t": 917505,
      "n": "_innerOffset",
      "d": 1245300,
      "h": 17181114484,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114484),
//--TRIMMABLE-BOUNDARY-START(30066016372),
    {
      "t": 917505,
      "n": "_position",
      "d": 1245300,
      "h": 30066016372,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066016372),
//--TRIMMABLE-BOUNDARY-START(25771049076),
    {
      "t": 917505,
      "n": "_observedLength",
      "d": 1245300,
      "h": 25771049076,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049076),
//--TRIMMABLE-BOUNDARY-START(12886147188),
    {
      "t": 262145,
      "n": "_finished",
      "d": 1245300,
      "h": 12886147188,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147188)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245885556),
    {
      "p": [
        {
          "n": "stream",
          "p": 393332
        },
        {
          "n": "boundary",
          "p": 1114228
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1245300,
      "h": 47245885556,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245885556),
//--TRIMMABLE-BOUNDARY-START(42950918260),
    {
      "p": [
        {
          "n": "stream",
          "p": 393332
        },
        {
          "n": "boundary",
          "p": 1114228
        },
        {
          "n": "bytePool",
          "p": $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1245300,
      "h": 42950918260,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950918260)
  ],
  "i": [90308609,89718785
  ],
  "h": 1245300
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `MultipartReaderStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245300)
        
        
        //--TRIMMABLE-BOUNDARY-START(524404)
        $asm.$cls("$maw.Microsoft.AspNetCore.WebUtilities.FileBufferingWriteStream", ($self) => class FileBufferingWriteStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(47245164660)
            /*int*/ static DefaultMemoryThreshold = 32768;
            //--TRIMMABLE-BOUNDARY-END(47245164660)
            
            //--TRIMMABLE-BOUNDARY-START(8590458996)
            /*int*/ _memoryThreshold = 0;
            //--TRIMMABLE-BOUNDARY-END(8590458996)
            
            //--TRIMMABLE-BOUNDARY-START(4295491700)
            /*long?*/ _bufferLimit = null;
            //--TRIMMABLE-BOUNDARY-END(4295491700)
            
            //--TRIMMABLE-BOUNDARY-START(12885426292)
            /*Func<string>*/ _tempFileDirectoryAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(12885426292)
            
            //--TRIMMABLE-BOUNDARY-START(30065295476)
            $ctor$3(/*int*/ memoryThreshold, /*long?*/ bufferLimit, /*Func<string>?*/ tempFileDirectoryAccessor)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295476);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, memoryThreshold, "memoryThreshold");
                    if (bufferLimit !== null && bufferLimit < memoryThreshold)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("bufferLimit", `${"bufferLimit"} must be larger than ${"memoryThreshold"}.`);
                    }
                    this._memoryThreshold = memoryThreshold;
                    this._bufferLimit = bufferLimit;
                    this._tempFileDirectoryAccessor = tempFileDirectoryAccessor ?? $.$maw.Microsoft.AspNetCore.Internal.AspNetCoreTempDirectory.TempDirectoryFactory;
                    this.PagedByteBuffer = new $.$maw.Microsoft.AspNetCore.WebUtilities.PagedByteBuffer().$ctor$1($.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295476)
            
            //--TRIMMABLE-BOUNDARY-START(171799216244)
            /*int */ get MemoryThreshold()
            {
                return this._memoryThreshold;
            }
            //--TRIMMABLE-BOUNDARY-END(171799216244)
            
            //--TRIMMABLE-BOUNDARY-START(34360262772)
            /*bool */ get CanRead()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262772)
            
            //--TRIMMABLE-BOUNDARY-START(38655230068)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655230068)
            
            //--TRIMMABLE-BOUNDARY-START(42950197364)
            /*bool */ get CanWrite()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197364)
            
            //--TRIMMABLE-BOUNDARY-START(167504248948)
            /*long */ get Length()
            {
                return BigInt(this.PagedByteBuffer.Length) + ((this.FileStream?.Length ?? null) ?? 0n);
            }
            //--TRIMMABLE-BOUNDARY-END(167504248948)
            
            //--TRIMMABLE-BOUNDARY-START(180389150836)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338823796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(180389150836)
            
            //--TRIMMABLE-BOUNDARY-START(176094183540)
            /*PagedByteBuffer*/ PagedByteBuffer = null;
            //--TRIMMABLE-BOUNDARY-END(176094183540)
            
            //--TRIMMABLE-BOUNDARY-START(77309935732)
            /*FileStream?*/ FileStream = null;
            //--TRIMMABLE-BOUNDARY-END(77309935732)
            
            //--TRIMMABLE-BOUNDARY-START(60130066548)
            /*bool*/ Disposed = false;
            //--TRIMMABLE-BOUNDARY-END(60130066548)
            
            //--TRIMMABLE-BOUNDARY-START(197569020020)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569020020);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569020020)
            
            //--TRIMMABLE-BOUNDARY-START(184684118132)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684118132);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684118132)
            
            //--TRIMMABLE-BOUNDARY-START(188979085428)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188979085428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979085428)
            
            //--TRIMMABLE-BOUNDARY-START(193274052724)
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274052724);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274052724)
            
            //--TRIMMABLE-BOUNDARY-START(236223725684)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223725684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                this.ThrowIfDisposed();
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - this.Length < count)
                {
                    this.Dispose();
                    throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                }
                /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - count) | 0)) >= this.PagedByteBuffer.Length;
                if (allowMemoryBuffer)
                {
                    this.PagedByteBuffer.Add(buffer, offset, count);
                    $.$$.System.Diagnostics.Debug.Assert$2(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                }
                else 
                {
                    this.EnsureFileStream();
                    this.PagedByteBuffer.MoveTo(this.FileStream);
                    this.FileStream.Write(buffer, offset, count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223725684)
            
            //--TRIMMABLE-BOUNDARY-START(240518692980)
            /*Task *//*async*/  WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518692980);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    await this.WriteAsync$2($.$$.System.Memory$$($.$$.System.Byte).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9($.$$.System.Byte, buffer, offset, count)), cancellationToken);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(240518692980)
            
            //--TRIMMABLE-BOUNDARY-START(244813660276)
            /*ValueTask *//*async*/  WriteAsync$2(/*ReadOnlyMemory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813660276);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ThrowIfDisposed();
                    if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(this._bufferLimit) && this._bufferLimit - this.Length < buffer.Length)
                    {
                        this.Dispose();
                        throw new $.$$.System.IO.IOException().$ctor$13("Buffer limit exceeded.");
                    }
                    /*var*/ let allowMemoryBuffer = (((this._memoryThreshold - buffer.Length) | 0)) >= this.PagedByteBuffer.Length;
                    if (allowMemoryBuffer)
                    {
                        this.PagedByteBuffer.Add$1(buffer);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.PagedByteBuffer.Length <= this._memoryThreshold, "PagedByteBuffer.Length <= _memoryThreshold");
                    }
                    else 
                    {
                        this.EnsureFileStream();
                        await this.PagedByteBuffer.MoveToAsync(this.FileStream, cancellationToken);
                        await this.FileStream.WriteAsync$2(buffer, cancellationToken);
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(244813660276)
            
            //--TRIMMABLE-BOUNDARY-START(81604903028)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604903028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81604903028)
            
            //--TRIMMABLE-BOUNDARY-START(85899870324)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899870324);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Threading.Tasks.Task.CompletedTask;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899870324)
            
            //--TRIMMABLE-BOUNDARY-START(227633791092)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633791092);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633791092)
            
            //--TRIMMABLE-BOUNDARY-START(64425033844)
            /*Task *//*async*/  DrainBufferAsync(/*Stream*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425033844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.System.IO.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            await readStream.CopyToAsync$2(destination, cancellationToken);
                            await this.FileStream.DisposeAsync();
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.System$IDisposable$Dispose();
                        }
                    }
                    await this.PagedByteBuffer.MoveToAsync(destination, cancellationToken);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64425033844)
            
            //--TRIMMABLE-BOUNDARY-START(68720001140)
            /*Task *//*async*/  DrainBufferAsync$1(/*PipeWriter*/ destination, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720001140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this.FileStream !== null)
                    {
                        /*var*/ let readStream = new $.$$.System.IO.FileStream().$ctor$10(this.FileStream.Name, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, true);
                        try
                        {
                            await $.$sipl.System.IO.Pipelines.StreamPipeExtensions.CopyToAsync(readStream, destination, cancellationToken);
                            await this.FileStream.DisposeAsync();
                            this.FileStream = null;
                        }
                        finally
                        {
                            readStream?.System$IDisposable$Dispose();
                        }
                    }
                    await this.PagedByteBuffer.MoveToAsync$1(destination, cancellationToken);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68720001140)
            
            //--TRIMMABLE-BOUNDARY-START(51540131956)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Disposed)
                {
                    this.Disposed = true;
                    this.PagedByteBuffer.Dispose();
                    this.FileStream?.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131956)
            
            //--TRIMMABLE-BOUNDARY-START(55835099252)
            /*ValueTask *//*async*/  DisposeAsync()
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835099252);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!this.Disposed)
                    {
                        this.Disposed = true;
                        this.PagedByteBuffer.Dispose();
                        await ((this.FileStream?.DisposeAsync() ?? null) ?? new $.$$.System.Threading.Tasks.ValueTask());
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(55835099252)
            
            //--TRIMMABLE-BOUNDARY-START(73014968436)
            /*void */ EnsureFileStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.FileStream === null)
                {
                    /*var*/ let tempFileDirectory = this._tempFileDirectoryAccessor.Invoke();
                    /*var*/ let tempFileName = $.$$.System.IO.Path.Combine$3(tempFileDirectory, "ASPNETCORE_" + $.$$.System.Guid.ToString.call($.$$.System.Guid.NewGuid()) + ".tmp");
                    if (!$.$$.System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform($.$$.System.Runtime.InteropServices.OSPlatform.Windows))
                    {
                        /*var*/ let tempTempFileName = $.$$.System.IO.Path.GetTempFileName();
                        $.$$.System.IO.File.Move$1(tempTempFileName, tempFileName);
                    }
                    this.FileStream = new $.$$.System.IO.FileStream().$ctor$12(tempFileName, 2/*FileMode.Create*/, 2/*FileAccess.Write*/, 4/*FileShare.Delete*/ | 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/ | 67108864/*FileOptions.DeleteOnClose*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014968436)
            
            //--TRIMMABLE-BOUNDARY-START(231928758388)
            /*void */ ThrowIfDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928758388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ObjectDisposedException.ThrowIf(this.Disposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(231928758388)
            
            static $h = 524404;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799216244),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029412468,
        "f": 50331649
      },
      "n": "MemoryThreshold",
      "d": 524404,
      "h": 171799216244,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799216244),
//--TRIMMABLE-BOUNDARY-START(34360262772),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489804916,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 524404,
      "h": 34360262772,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360262772),
//--TRIMMABLE-BOUNDARY-START(38655230068),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079739508,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 524404,
      "h": 38655230068,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655230068),
//--TRIMMABLE-BOUNDARY-START(42950197364),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669674100,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 524404,
      "h": 42950197364,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950197364),
//--TRIMMABLE-BOUNDARY-START(167504248948),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439477876,
        "f": 50364417
      },
      "n": "Length",
      "d": 524404,
      "h": 167504248948,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504248948),
//--TRIMMABLE-BOUNDARY-START(180389150836),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209281652,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338823796,
        "f": 83918849
      },
      "n": "Position",
      "d": 524404,
      "h": 180389150836,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389150836),
//--TRIMMABLE-BOUNDARY-START(176094183540),
    {
      "p": 1507444,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619347060,
        "f": 50331656
      },
      "n": "PagedByteBuffer",
      "d": 524404,
      "h": 176094183540,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(176094183540),
//--TRIMMABLE-BOUNDARY-START(77309935732),
    {
      "p": 93126657,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849543284,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748889204,
        "f": 83886082
      },
      "n": "FileStream",
      "d": 524404,
      "h": 77309935732,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77309935732),
//--TRIMMABLE-BOUNDARY-START(60130066548),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259608692,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158954612,
        "f": 83886082
      },
      "n": "Disposed",
      "d": 524404,
      "h": 60130066548,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60130066548)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(197569020020),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 524404,
      "h": 197569020020,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569020020),
//--TRIMMABLE-BOUNDARY-START(184684118132),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 524404,
      "h": 184684118132,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684118132),
//--TRIMMABLE-BOUNDARY-START(188979085428),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "d": 524404,
      "h": 188979085428,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188979085428),
//--TRIMMABLE-BOUNDARY-START(193274052724),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 524404,
      "h": 193274052724,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274052724),
//--TRIMMABLE-BOUNDARY-START(236223725684),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 524404,
      "h": 236223725684,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(236223725684),
//--TRIMMABLE-BOUNDARY-START(240518692980),
    {
      "r": 177668097,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "WriteAsync",
      "d": 524404,
      "h": 240518692980,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(240518692980),
//--TRIMMABLE-BOUNDARY-START(244813660276),
    {
      "r": 180551681,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 524404,
      "h": 244813660276,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(244813660276),
//--TRIMMABLE-BOUNDARY-START(81604903028),
    {
      "r": 65537,
      "n": "Flush",
      "d": 524404,
      "h": 81604903028,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604903028),
//--TRIMMABLE-BOUNDARY-START(85899870324),
    {
      "r": 177668097,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 524404,
      "h": 85899870324,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899870324),
//--TRIMMABLE-BOUNDARY-START(227633791092),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 524404,
      "h": 227633791092,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(227633791092),
//--TRIMMABLE-BOUNDARY-START(64425033844),
    {
      "r": 177668097,
      "p": [
        {
          "n": "destination",
          "p": 94961665
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "DrainBufferAsync",
      "d": 524404,
      "h": 64425033844,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(64425033844),
//--TRIMMABLE-BOUNDARY-START(68720001140),
    {
      "r": 177668097,
      "p": [
        {
          "n": "destination",
          "p": 1572945
        },
        {
          "n": "cancellationToken",
          "p": 170065921,
          "f": 65
        }
      ],
      "n": "DrainBufferAsync",
      "o": "@$1",
      "d": 524404,
      "h": 68720001140,
      "f": 16781313
    },
//--TRIMMABLE-BOUNDARY-END(68720001140),
//--TRIMMABLE-BOUNDARY-START(51540131956),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 524404,
      "h": 51540131956,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540131956),
//--TRIMMABLE-BOUNDARY-START(55835099252),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 524404,
      "h": 55835099252,
      "f": 16814081
    },
//--TRIMMABLE-BOUNDARY-END(55835099252),
//--TRIMMABLE-BOUNDARY-START(73014968436),
    {
      "r": 65537,
      "n": "EnsureFileStream",
      "d": 524404,
      "h": 73014968436,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014968436),
//--TRIMMABLE-BOUNDARY-START(231928758388),
    {
      "r": 65537,
      "n": "ThrowIfDisposed",
      "d": 524404,
      "h": 231928758388,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(231928758388)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245164660),
    {
      "t": 655361,
      "n": "DefaultMemoryThreshold",
      "d": 524404,
      "h": 47245164660,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245164660),
//--TRIMMABLE-BOUNDARY-START(8590458996),
    {
      "t": 655361,
      "n": "_memoryThreshold",
      "d": 524404,
      "h": 8590458996,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458996),
//--TRIMMABLE-BOUNDARY-START(4295491700),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_bufferLimit",
      "d": 524404,
      "h": 4295491700,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491700),
//--TRIMMABLE-BOUNDARY-START(12885426292),
    {
      "t": $.$$.System.Func$$($.$$.System.String).$h,
      "n": "_tempFileDirectoryAccessor",
      "d": 524404,
      "h": 12885426292,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426292)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065295476),
    {
      "p": [
        {
          "n": "memoryThreshold",
          "p": 655361,
          "f": 65,
          "v": 32768
        },
        {
          "n": "bufferLimit",
          "p": $.$typeNullable($.$$.System.Int64).$h,
          "f": 65
        },
        {
          "n": "tempFileDirectoryAccessor",
          "p": $.$$.System.Func$$($.$$.System.String).$h,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524404,
      "h": 30065295476,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295476)
  ],
  "i": [90308609,89718785
  ],
  "h": 524404
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `FileBufferingWriteStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524404)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.Net.Http.Headers", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web"))
//--TRIMMABLE-BOUNDARY-END(116)
