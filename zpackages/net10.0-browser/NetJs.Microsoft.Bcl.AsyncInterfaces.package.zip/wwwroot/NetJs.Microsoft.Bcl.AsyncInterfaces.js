
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Bcl.AsyncInterfaces", 
    {"h":22,"f":"Microsoft.Bcl.AsyncInterfaces","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Bcl.AsyncInterfaces","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Bcl.AsyncInterfaces","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":96337921,"c":4391305217,"a":[{"v":56950785,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Collections.Generic.IAsyncEnumerable$$().$h,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Collections.Generic.IAsyncEnumerator$$().$h,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":86507521,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":86573057,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":89063425,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Runtime.CompilerServices.ConfiguredCancelableAsyncEnumerable$$().$h,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":90505217,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":134152193,"t":142606337}]},{"t":96337921,"c":4391305217,"a":[{"v":$.$spc.System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore$$().$h,"t":142606337}]}],"m":[]},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))