
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Bcl.AsyncInterfaces", 
    {"h":22,"f":"Microsoft.Bcl.AsyncInterfaces","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":96206849,"c":4391174145,"a":[{"v":56950785,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":$.$$.System.Collections.Generic.IAsyncEnumerable$$().$h,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":$.$$.System.Collections.Generic.IAsyncEnumerator$$().$h,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":86376449,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":86441985,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":88932353,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":$.$$.System.Runtime.CompilerServices.ConfiguredCancelableAsyncEnumerable$$().$h,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":90374145,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":134021121,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":$.$$.System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore$$().$h,"t":142475265}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Bcl.AsyncInterfaces","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Bcl.AsyncInterfaces","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))