
//--TRIMMABLE-BOUNDARY-START(10)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Bcl.AsyncInterfaces", 
    {
  "h": 10,
  "f": "Microsoft.Bcl.AsyncInterfaces",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 89718785,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": $.$$.System.Collections.Generic.IAsyncEnumerable$$().$h,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": $.$$.System.Collections.Generic.IAsyncEnumerator$$().$h,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 123797505,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 123863041,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 126353409,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": $.$$.System.Runtime.CompilerServices.ConfiguredCancelableAsyncEnumerable$$().$h,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 127795201,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 178520065,
          "t": 187760641
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": $.$$.System.Threading.Tasks.Sources.ManualResetValueTaskSourceCore$$().$h,
          "t": 187760641
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Bcl.AsyncInterfaces",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Bcl.AsyncInterfaces",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(10)
