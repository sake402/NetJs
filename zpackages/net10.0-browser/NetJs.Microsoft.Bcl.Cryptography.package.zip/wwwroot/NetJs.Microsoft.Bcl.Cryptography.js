
//--TRIMMABLE-BOUNDARY-START(12)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $snp, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Bcl.Cryptography", 
    {
  "h": 12,
  "f": "Microsoft.Bcl.Cryptography",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 1966110,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 5832734,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 23003166,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 26607646,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 26673182,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 28508190,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 7208990,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 7340062,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 7405598,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 13959198,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 14090270,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 14155806,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 14417950,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 14614558,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 14680094,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 22609950,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 22741022,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 22806558,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 15532062,
          "t": 187629569
        }
      ]
    },
    {
      "t": 133693441,
      "c": 4428660737,
      "a": [
        {
          "v": 15597598,
          "t": 187629569
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Bcl.Cryptography",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Bcl.Cryptography",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196620)
        $asm.$cls("$mbc.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(992137641996)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(992137641996)
            
            //--TRIMMABLE-BOUNDARY-START(974957772812)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(974957772812);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(974957772812)
            
            //--TRIMMABLE-BOUNDARY-START(1005022543884)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1005022543884);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mbc.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1005022543884)
            
            //--TRIMMABLE-BOUNDARY-START(966367838220)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(966367838220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mbc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(966367838220)
            
            //--TRIMMABLE-BOUNDARY-START(970662805516)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(970662805516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mbc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(970662805516)
            
            //--TRIMMABLE-BOUNDARY-START(296352940044)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352940044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(296352940044)
            
            //--TRIMMABLE-BOUNDARY-START(300647907340)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647907340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(300647907340)
            
            //--TRIMMABLE-BOUNDARY-START(304942874636)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942874636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(304942874636)
            
            //--TRIMMABLE-BOUNDARY-START(309237841932)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237841932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mbc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(309237841932)
            
            //--TRIMMABLE-BOUNDARY-START(313532809228)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532809228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(313532809228)
            
            //--TRIMMABLE-BOUNDARY-START(317827776524)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827776524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(317827776524)
            
            //--TRIMMABLE-BOUNDARY-START(322122743820)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122743820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(322122743820)
            
            //--TRIMMABLE-BOUNDARY-START(326417711116)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417711116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mbc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(326417711116)
            
            //--TRIMMABLE-BOUNDARY-START(987842674700)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(987842674700)
            
            //--TRIMMABLE-BOUNDARY-START(979252740108)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(979252740108)
            
            //--TRIMMABLE-BOUNDARY-START(983547707404)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(962072870924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mbc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Bcl.Cryptography", $.$mbc.System.SR.$type.Assembly);
                    $.$mbc.System.SR.s_resourceManager = temp;
                }
                return $.$mbc.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(983547707404)
            
            //--TRIMMABLE-BOUNDARY-START(292057972748)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(953482936332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mbc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1000727576588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mbc.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(292057972748)
            
            //--TRIMMABLE-BOUNDARY-START(8590131212)
            static /*string */ get Arg_CryptographyException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547253260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Error occurred during a cryptographic operation.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590131212)
            
            //--TRIMMABLE-BOUNDARY-START(12885098508)
            static /*string */ get Argument_DestinationImprecise()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137187852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination must be exactly {0} bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885098508)
            
            //--TRIMMABLE-BOUNDARY-START(330712678412)
            static /*string */ FormatArgument_DestinationImprecise(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712678412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Destination must be exactly {0} bytes.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(330712678412)
            
            //--TRIMMABLE-BOUNDARY-START(17180065804)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727122444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180065804)
            
            //--TRIMMABLE-BOUNDARY-START(25770000396)
            static /*string */ get Argument_HashImprecise()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420906991628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Hash must be exactly {0} bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770000396)
            
            //--TRIMMABLE-BOUNDARY-START(335007645708)
            static /*string */ FormatArgument_HashImprecise(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007645708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Hash must be exactly {0} bytes.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(335007645708)
            
            //--TRIMMABLE-BOUNDARY-START(30064967692)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429496926220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(30064967692)
            
            //--TRIMMABLE-BOUNDARY-START(34359934988)
            static /*string */ get Argument_InvalidValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438086860812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Value was invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(34359934988)
            
            //--TRIMMABLE-BOUNDARY-START(38654902284)
            static /*string */ get Argument_KemInvalidCiphertextLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446676795404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified ciphertext is not the correct length for the ML-KEM algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(38654902284)
            
            //--TRIMMABLE-BOUNDARY-START(42949869580)
            static /*string */ get Argument_KemInvalidDecapsulationKeyLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455266729996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified decapsulation key is not the correct length for the ML-KEM algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(42949869580)
            
            //--TRIMMABLE-BOUNDARY-START(47244836876)
            static /*string */ get Argument_KemInvalidEncapsulationKeyLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463856664588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified encapsulation key is not the correct length for the ML-KEM algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(47244836876)
            
            //--TRIMMABLE-BOUNDARY-START(51539804172)
            static /*string */ get Argument_KemInvalidSeedLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446599180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified private seed is not the correct length for the ML-KEM algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(51539804172)
            
            //--TRIMMABLE-BOUNDARY-START(55834771468)
            static /*string */ get Argument_MLDsaMuInvalidLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036533772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified mu value is not the correct length for the ML-DSA algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(55834771468)
            
            //--TRIMMABLE-BOUNDARY-START(64424706060)
            static /*string */ get Argument_PemEncoding_InvalidLabel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216402956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified label is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(64424706060)
            
            //--TRIMMABLE-BOUNDARY-START(60129738764)
            static /*string */ get Argument_PemEncoding_EncodedSizeTooLarge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626468364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The encoded PEM size is too large to represent as a signed 32-bit integer.";
            }
            //--TRIMMABLE-BOUNDARY-END(60129738764)
            
            //--TRIMMABLE-BOUNDARY-START(68719673356)
            static /*string */ get Argument_PemEncoding_NoPemFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806337548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No PEM encoded data found.";
            }
            //--TRIMMABLE-BOUNDARY-END(68719673356)
            
            //--TRIMMABLE-BOUNDARY-START(81604575244)
            static /*string */ get Argument_PemImport_NoPemFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576141324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No supported key formats were found. Check that the input represents the contents of a PEM-encoded key file, not the path to such a file.";
            }
            //--TRIMMABLE-BOUNDARY-END(81604575244)
            
            //--TRIMMABLE-BOUNDARY-START(73014640652)
            static /*string */ get Argument_PemImport_AmbiguousPem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396272140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The input contains multiple keys, but only one key can be imported.";
            }
            //--TRIMMABLE-BOUNDARY-END(73014640652)
            
            //--TRIMMABLE-BOUNDARY-START(77309607948)
            static /*string */ get Argument_PemImport_EncryptedPem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986206732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An encrypted key was found, but no password was provided. Use ImportFromEncryptedPem to import this key.";
            }
            //--TRIMMABLE-BOUNDARY-END(77309607948)
            
            //--TRIMMABLE-BOUNDARY-START(85899542540)
            static /*string */ get Argument_PrivateKeyWrongSizeForAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166075916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The private key is not the correct size for the indicated algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(85899542540)
            
            //--TRIMMABLE-BOUNDARY-START(90194509836)
            static /*string */ get Argument_PrivateSeedWrongSizeForAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756010508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The private seed is not the correct size for the indicated algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(90194509836)
            
            //--TRIMMABLE-BOUNDARY-START(94489477132)
            static /*string */ get Argument_PublicKeyWrongSizeForAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558345945100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The public key is not the correct size for the indicated algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(94489477132)
            
            //--TRIMMABLE-BOUNDARY-START(98784444428)
            static /*string */ get Argument_SignatureContextTooLong255()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566935879692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified signature context exceeds the maximum length of 255 bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(98784444428)
            
            //--TRIMMABLE-BOUNDARY-START(103079411724)
            static /*string */ get ArgumentOutOfRange_Generic_MustBeNonNegativeNonZero()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575525814284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} ('{1}') must be a non-negative and non-zero value.";
            }
            //--TRIMMABLE-BOUNDARY-END(103079411724)
            
            //--TRIMMABLE-BOUNDARY-START(339302613004)
            static /*string */ FormatArgumentOutOfRange_Generic_MustBeNonNegativeNonZero(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302613004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("{0} ('{1}') must be a non-negative and non-zero value.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(339302613004)
            
            //--TRIMMABLE-BOUNDARY-START(115964313612)
            static /*string */ get ArgumentOutOfRange_NeedPositiveNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601295618060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A positive number is required.";
            }
            //--TRIMMABLE-BOUNDARY-END(115964313612)
            
            //--TRIMMABLE-BOUNDARY-START(111669346316)
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592705683468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(111669346316)
            
            //--TRIMMABLE-BOUNDARY-START(107374379020)
            static /*string */ get ArgumentOutOfRange_KOut_Too_Large()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584115748876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The number of bytes requested is too large. The number of bytes produced by SP800108HmacCounterKdf cannot exceed 536,870,911 bytes.";
            }
            //--TRIMMABLE-BOUNDARY-END(107374379020)
            
            //--TRIMMABLE-BOUNDARY-START(21475033100)
            static /*string */ get Argument_EmptyString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317057036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value cannot be an empty string.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475033100)
            
            //--TRIMMABLE-BOUNDARY-START(120259280908)
            static /*string */ get Cryptography_AlgKdfRequiresChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609885552652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The KDF for algorithm '{0}' requires a char-based password input.";
            }
            //--TRIMMABLE-BOUNDARY-END(120259280908)
            
            //--TRIMMABLE-BOUNDARY-START(343597580300)
            static /*string */ FormatCryptography_AlgKdfRequiresChars(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597580300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The KDF for algorithm '{0}' requires a char-based password input.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(343597580300)
            
            //--TRIMMABLE-BOUNDARY-START(124554248204)
            static /*string */ get Cryptography_AlgorithmNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618475487244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Algorithm '{0}' is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(124554248204)
            
            //--TRIMMABLE-BOUNDARY-START(347892547596)
            static /*string */ FormatCryptography_AlgorithmNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892547596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Algorithm '{0}' is not supported on this platform.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(347892547596)
            
            //--TRIMMABLE-BOUNDARY-START(128849215500)
            static /*string */ get Cryptography_ArgMLDsaRequiresMLDsaKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627065421836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keys used with the MLDsaCng algorithm must have an algorithm group of MLDsa.";
            }
            //--TRIMMABLE-BOUNDARY-END(128849215500)
            
            //--TRIMMABLE-BOUNDARY-START(133144182796)
            static /*string */ get Cryptography_ArgMLKemRequiresMLKemKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635655356428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Keys used with the MLKemCng algorithm must have an algorithm group of MLKem.";
            }
            //--TRIMMABLE-BOUNDARY-END(133144182796)
            
            //--TRIMMABLE-BOUNDARY-START(137439150092)
            static /*string */ get Cryptography_AuthTagMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644245291020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The computed authentication tag did not match the input authentication tag.";
            }
            //--TRIMMABLE-BOUNDARY-END(137439150092)
            
            //--TRIMMABLE-BOUNDARY-START(141734117388)
            static /*string */ get Cryptography_Cert_AlreadyHasPrivateKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652835225612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The certificate already has an associated private key.";
            }
            //--TRIMMABLE-BOUNDARY-END(141734117388)
            
            //--TRIMMABLE-BOUNDARY-START(146029084684)
            static /*string */ get Cryptography_CompositeSignDataError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425160204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Composite signature generation failed due to an error in one or both of the components.";
            }
            //--TRIMMABLE-BOUNDARY-END(146029084684)
            
            //--TRIMMABLE-BOUNDARY-START(150324051980)
            static /*string */ get Cryptography_CurveNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670015094796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified curve '{0}' or its parameters are not valid for this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(150324051980)
            
            //--TRIMMABLE-BOUNDARY-START(352187514892)
            static /*string */ FormatCryptography_CurveNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187514892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The specified curve '{0}' or its parameters are not valid for this platform.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(352187514892)
            
            //--TRIMMABLE-BOUNDARY-START(154619019276)
            static /*string */ get Cryptography_Der_Invalid_Encoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678605029388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "ASN1 corrupted data.";
            }
            //--TRIMMABLE-BOUNDARY-END(154619019276)
            
            //--TRIMMABLE-BOUNDARY-START(158913986572)
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687194963980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The hash algorithm name cannot be null or empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(158913986572)
            
            //--TRIMMABLE-BOUNDARY-START(163208953868)
            static /*string */ get Cryptography_HashLengthMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695784898572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified hash is not a valid size for this hash algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(163208953868)
            
            //--TRIMMABLE-BOUNDARY-START(167503921164)
            static /*string */ get Cryptography_HashMLDsaAlgorithmMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704374833164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "HashML-DSA '{0}' cannot be used with hash algorithm '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(167503921164)
            
            //--TRIMMABLE-BOUNDARY-START(356482482188)
            static /*string */ FormatCryptography_HashMLDsaAlgorithmMismatch(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482482188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("HashML-DSA '{0}' cannot be used with hash algorithm '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(356482482188)
            
            //--TRIMMABLE-BOUNDARY-START(171798888460)
            static /*string */ get Cryptography_IncorrectTagLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712964767756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The size of the specified tag does not match the expected size of {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(171798888460)
            
            //--TRIMMABLE-BOUNDARY-START(360777449484)
            static /*string */ FormatCryptography_IncorrectTagLength(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777449484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The size of the specified tag does not match the expected size of {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(360777449484)
            
            //--TRIMMABLE-BOUNDARY-START(176093855756)
            static /*string */ get Cryptography_InvalidECPrivateKeyParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721554702348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified key parameters are not valid. X and Y, or D, must be specified. X, Y must be the same length. If D is specified it must be the same length as X and Y if also specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(176093855756)
            
            //--TRIMMABLE-BOUNDARY-START(180388823052)
            static /*string */ get Cryptography_InvalidKeySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730144636940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified key is not a valid size for this algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(180388823052)
            
            //--TRIMMABLE-BOUNDARY-START(197568692236)
            static /*string */ get Cryptography_InvalidTagLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764504375308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified tag is not a valid size for this algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(197568692236)
            
            //--TRIMMABLE-BOUNDARY-START(184683790348)
            static /*string */ get Cryptography_InvalidNonceLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738734571532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified nonce is not a valid size for this algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(184683790348)
            
            //--TRIMMABLE-BOUNDARY-START(188978757644)
            static /*string */ get Cryptography_InvalidOidFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747324506124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid OID format.";
            }
            //--TRIMMABLE-BOUNDARY-END(188978757644)
            
            //--TRIMMABLE-BOUNDARY-START(193273724940)
            static /*string */ get Cryptography_InvalidRsaParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755914440716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified RSA parameters are not valid. Exponent and Modulus are required. If D is present, it must have the same length as Modulus. If D is present, P, Q, DP, DQ, and InverseQ are required and must have half the length of Modulus, rounded up, otherwise they must be omitted.";
            }
            //--TRIMMABLE-BOUNDARY-END(193273724940)
            
            //--TRIMMABLE-BOUNDARY-START(206158626828)
            static /*string */ get Cryptography_KemPkcs8KeyMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781684244492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified PKCS#8 key contains a seed that does not match the expanded key.";
            }
            //--TRIMMABLE-BOUNDARY-END(206158626828)
            
            //--TRIMMABLE-BOUNDARY-START(201863659532)
            static /*string */ get Cryptography_KemNoDecapsulationKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773094309900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The current instance does not contain a decapsulation key.";
            }
            //--TRIMMABLE-BOUNDARY-END(201863659532)
            
            //--TRIMMABLE-BOUNDARY-START(210453594124)
            static /*string */ get Cryptography_KeyNotExtractable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790274179084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key does not permit being exported.";
            }
            //--TRIMMABLE-BOUNDARY-END(210453594124)
            
            //--TRIMMABLE-BOUNDARY-START(214748561420)
            static /*string */ get Cryptography_KeyWrongSizeForAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798864113676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified key is not the correct size for the indicated algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(214748561420)
            
            //--TRIMMABLE-BOUNDARY-START(219043528716)
            static /*string */ get Cryptography_MLDsaPkcs8KeyMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454048268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified PKCS#8 key contains a seed that does not match the expanded key.";
            }
            //--TRIMMABLE-BOUNDARY-END(219043528716)
            
            //--TRIMMABLE-BOUNDARY-START(223338496012)
            static /*string */ get Cryptography_NoPrivateKeyAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816043982860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The current instance does not contain a private key.";
            }
            //--TRIMMABLE-BOUNDARY-END(223338496012)
            
            //--TRIMMABLE-BOUNDARY-START(227633463308)
            static /*string */ get Cryptography_NotValidPrivateKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824633917452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Key is not a valid private key.";
            }
            //--TRIMMABLE-BOUNDARY-END(227633463308)
            
            //--TRIMMABLE-BOUNDARY-START(231928430604)
            static /*string */ get Cryptography_NotValidPublicOrPrivateKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833223852044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Key is not a valid public or private key.";
            }
            //--TRIMMABLE-BOUNDARY-END(231928430604)
            
            //--TRIMMABLE-BOUNDARY-START(236223397900)
            static /*string */ get Cryptography_OverlappingBuffers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841813786636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "One or more provided buffers overlap.";
            }
            //--TRIMMABLE-BOUNDARY-END(236223397900)
            
            //--TRIMMABLE-BOUNDARY-START(240518365196)
            static /*string */ get Cryptography_Pfx_BadPassword()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850403721228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The certificate data cannot be read with the provided password, the password may be incorrect.";
            }
            //--TRIMMABLE-BOUNDARY-END(240518365196)
            
            //--TRIMMABLE-BOUNDARY-START(244813332492)
            static /*string */ get Cryptography_Pfx_NoCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858993655820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided PFX data contains no certificates.";
            }
            //--TRIMMABLE-BOUNDARY-END(244813332492)
            
            //--TRIMMABLE-BOUNDARY-START(249108299788)
            static /*string */ get Cryptography_Pkcs8_EncryptedReadFailed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(867583590412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The EncryptedPrivateKeyInfo structure was decoded but was not successfully interpreted, the password may be incorrect.";
            }
            //--TRIMMABLE-BOUNDARY-END(249108299788)
            
            //--TRIMMABLE-BOUNDARY-START(253403267084)
            static /*string */ get Cryptography_PlaintextCiphertextLengthMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876173525004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Plaintext and ciphertext must have the same length.";
            }
            //--TRIMMABLE-BOUNDARY-END(253403267084)
            
            //--TRIMMABLE-BOUNDARY-START(257698234380)
            static /*string */ get Cryptography_PqcNoSeed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(884763459596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The current instance does not contain a seed.";
            }
            //--TRIMMABLE-BOUNDARY-END(257698234380)
            
            //--TRIMMABLE-BOUNDARY-START(261993201676)
            static /*string */ get Cryptography_PrivateKey_DoesNotMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(893353394188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided key does not match the public key for this certificate.";
            }
            //--TRIMMABLE-BOUNDARY-END(261993201676)
            
            //--TRIMMABLE-BOUNDARY-START(266288168972)
            static /*string */ get Cryptography_PrivateKey_WrongAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(901943328780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided key does not match the public key algorithm for this certificate.";
            }
            //--TRIMMABLE-BOUNDARY-END(266288168972)
            
            //--TRIMMABLE-BOUNDARY-START(270583136268)
            static /*string */ get Cryptography_RSAPrivateKey_VersionTooNew()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(910533263372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The provided RSAPrivateKey value has version '{0}', but version '{1}' is the maximum supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(270583136268)
            
            //--TRIMMABLE-BOUNDARY-START(365072416780)
            static /*string */ FormatCryptography_RSAPrivateKey_VersionTooNew(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072416780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The provided RSAPrivateKey value has version '{0}', but version '{1}' is the maximum supported.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(365072416780)
            
            //--TRIMMABLE-BOUNDARY-START(274878103564)
            static /*string */ get Cryptography_UnknownAlgorithmIdentifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(919123197964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The algorithm identified by '{0}' is unknown, not valid for the requested usage, or was not handled.";
            }
            //--TRIMMABLE-BOUNDARY-END(274878103564)
            
            //--TRIMMABLE-BOUNDARY-START(369367384076)
            static /*string */ FormatCryptography_UnknownAlgorithmIdentifier(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367384076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The algorithm identified by '{0}' is unknown, not valid for the requested usage, or was not handled.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(369367384076)
            
            //--TRIMMABLE-BOUNDARY-START(279173070860)
            static /*string */ get Cryptography_UnknownHashAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(927713132556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' is not a known hash algorithm.";
            }
            //--TRIMMABLE-BOUNDARY-END(279173070860)
            
            //--TRIMMABLE-BOUNDARY-START(373662351372)
            static /*string */ FormatCryptography_UnknownHashAlgorithm(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662351372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("'{0}' is not a known hash algorithm.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(373662351372)
            
            //--TRIMMABLE-BOUNDARY-START(283468038156)
            static /*string */ get Cryptography_X509_PKCS12_LimitExceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(936303067148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The PKCS#12/PFX violated the '{0}' limit.";
            }
            //--TRIMMABLE-BOUNDARY-END(283468038156)
            
            //--TRIMMABLE-BOUNDARY-START(377957318668)
            static /*string */ FormatCryptography_X509_PKCS12_LimitExceeded(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957318668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The PKCS#12/PFX violated the '{0}' limit.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(377957318668)
            
            //--TRIMMABLE-BOUNDARY-START(287763005452)
            static /*string */ get Cryptography_X509_PKCS12_LimitsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(944893001740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This Pkcs12LoaderLimits object has been made read-only and can no longer be modified.";
            }
            //--TRIMMABLE-BOUNDARY-END(287763005452)
            
            //--TRIMMABLE-BOUNDARY-START(4295163916)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(992137641996)
                    this.s_usingResourceKeys = $.$mbc.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(992137641996)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163916)
            
            static $h = 196620;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 196620
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196620)
        
        
        //--TRIMMABLE-BOUNDARY-START(131084)
        $asm.$cls("$mbc.System.Security.Cryptography.X509Certificates.X509CertificateKeyAccessors", ($self) => class X509CertificateKeyAccessors
        {
            //--TRIMMABLE-BOUNDARY-START(42949804044)
            static /*MLKem? */ GetMLKemPublicKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLKemPublicKey();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804044)
            
            //--TRIMMABLE-BOUNDARY-START(38654836748)
            static /*MLKem? */ GetMLKemPrivateKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLKemPrivateKey();
            }
            //--TRIMMABLE-BOUNDARY-END(38654836748)
            
            //--TRIMMABLE-BOUNDARY-START(4295098380)
            static /*X509Certificate2 */ CopyWithPrivateKey$2(/*this X509Certificate2*/ certificate, /*MLKem*/ privateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$3(privateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098380)
            
            //--TRIMMABLE-BOUNDARY-START(34359869452)
            static /*MLDsa? */ GetMLDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLDsaPublicKey();
            }
            //--TRIMMABLE-BOUNDARY-END(34359869452)
            
            //--TRIMMABLE-BOUNDARY-START(30064902156)
            static /*MLDsa? */ GetMLDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLDsaPrivateKey();
            }
            //--TRIMMABLE-BOUNDARY-END(30064902156)
            
            //--TRIMMABLE-BOUNDARY-START(8590065676)
            static /*X509Certificate2 */ CopyWithPrivateKey$1(/*this X509Certificate2*/ certificate, /*MLDsa*/ privateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$2(privateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065676)
            
            //--TRIMMABLE-BOUNDARY-START(51539738636)
            static /*SlhDsa? */ GetSlhDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetSlhDsaPublicKey();
            }
            //--TRIMMABLE-BOUNDARY-END(51539738636)
            
            //--TRIMMABLE-BOUNDARY-START(47244771340)
            static /*SlhDsa? */ GetSlhDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetSlhDsaPrivateKey();
            }
            //--TRIMMABLE-BOUNDARY-END(47244771340)
            
            //--TRIMMABLE-BOUNDARY-START(12885032972)
            static /*X509Certificate2 */ CopyWithPrivateKey$3(/*this X509Certificate2*/ certificate, /*SlhDsa*/ privateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$4(privateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(12885032972)
            
            //--TRIMMABLE-BOUNDARY-START(25769934860)
            static /*CompositeMLDsa? */ GetCompositeMLDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetCompositeMLDsaPublicKey();
            }
            //--TRIMMABLE-BOUNDARY-END(25769934860)
            
            //--TRIMMABLE-BOUNDARY-START(21474967564)
            static /*CompositeMLDsa? */ GetCompositeMLDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetCompositeMLDsaPrivateKey();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967564)
            
            //--TRIMMABLE-BOUNDARY-START(17180000268)
            static /*X509Certificate2 */ CopyWithPrivateKey(/*this X509Certificate2*/ certificate, /*CompositeMLDsa*/ privateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey(privateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000268)
            
            static $h = 131084;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949804044),
    {
      "r": 14417950,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetMLKemPublicKey",
      "d": 131084,
      "h": 42949804044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804044),
//--TRIMMABLE-BOUNDARY-START(38654836748),
    {
      "r": 14417950,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetMLKemPrivateKey",
      "d": 131084,
      "h": 38654836748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836748),
//--TRIMMABLE-BOUNDARY-START(4295098380),
    {
      "r": 28180510,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        },
        {
          "n": "privateKey",
          "p": 14417950
        }
      ],
      "n": "CopyWithPrivateKey",
      "o": "@$2",
      "d": 131084,
      "h": 4295098380,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098380),
//--TRIMMABLE-BOUNDARY-START(34359869452),
    {
      "r": 13959198,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetMLDsaPublicKey",
      "d": 131084,
      "h": 34359869452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359869452),
//--TRIMMABLE-BOUNDARY-START(30064902156),
    {
      "r": 13959198,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetMLDsaPrivateKey",
      "d": 131084,
      "h": 30064902156,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064902156),
//--TRIMMABLE-BOUNDARY-START(8590065676),
    {
      "r": 28180510,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        },
        {
          "n": "privateKey",
          "p": 13959198
        }
      ],
      "n": "CopyWithPrivateKey",
      "o": "@$1",
      "d": 131084,
      "h": 8590065676,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065676),
//--TRIMMABLE-BOUNDARY-START(51539738636),
    {
      "r": 22609950,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetSlhDsaPublicKey",
      "d": 131084,
      "h": 51539738636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539738636),
//--TRIMMABLE-BOUNDARY-START(47244771340),
    {
      "r": 22609950,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetSlhDsaPrivateKey",
      "d": 131084,
      "h": 47244771340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244771340),
//--TRIMMABLE-BOUNDARY-START(12885032972),
    {
      "r": 28180510,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        },
        {
          "n": "privateKey",
          "p": 22609950
        }
      ],
      "n": "CopyWithPrivateKey",
      "o": "@$3",
      "d": 131084,
      "h": 12885032972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885032972),
//--TRIMMABLE-BOUNDARY-START(25769934860),
    {
      "r": 7208990,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetCompositeMLDsaPublicKey",
      "d": 131084,
      "h": 25769934860,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934860),
//--TRIMMABLE-BOUNDARY-START(21474967564),
    {
      "r": 7208990,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        }
      ],
      "n": "GetCompositeMLDsaPrivateKey",
      "d": 131084,
      "h": 21474967564,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474967564),
//--TRIMMABLE-BOUNDARY-START(17180000268),
    {
      "r": 28180510,
      "p": [
        {
          "n": "certificate",
          "p": 28180510
        },
        {
          "n": "privateKey",
          "p": 7208990
        }
      ],
      "n": "CopyWithPrivateKey",
      "d": 131084,
      "h": 17180000268,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180000268)
  ],
  "h": 131084
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Cryptography.X509Certificates.X509CertificateKeyAccessors`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131084)
        
        
        //--TRIMMABLE-BOUNDARY-START(65548)
        $asm.$cls("$mbc.System.Experimentals", ($self) => class Experimentals
        {
            //--TRIMMABLE-BOUNDARY-START(12884967436)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(12884967436)
            
            //--TRIMMABLE-BOUNDARY-START(21474902028)
            /*string*/ static TensorTDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21474902028)
            
            //--TRIMMABLE-BOUNDARY-START(17179934732)
            /*string*/ static SystemColorsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(17179934732)
            
            //--TRIMMABLE-BOUNDARY-START(4295032844)
            /*string*/ static ArmSveDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295032844)
            
            //--TRIMMABLE-BOUNDARY-START(25769869324)
            /*string*/ static X86BaseDivRemDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(25769869324)
            
            //--TRIMMABLE-BOUNDARY-START(8590000140)
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(8590000140)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967436)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(12884967436)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902028)
                    this.TensorTDiagId = "SYSLIB5001";
                    //--TRIMMABLE-BOUNDARY-END(21474902028)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17179934732)
                    this.SystemColorsDiagId = "SYSLIB5002";
                    //--TRIMMABLE-BOUNDARY-END(17179934732)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032844)
                    this.ArmSveDiagId = "SYSLIB5003";
                    //--TRIMMABLE-BOUNDARY-END(4295032844)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25769869324)
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                    //--TRIMMABLE-BOUNDARY-END(25769869324)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000140)
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                    //--TRIMMABLE-BOUNDARY-END(8590000140)
                    
                }
            }
            static $h = 65548;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967436),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 65548,
      "h": 12884967436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12884967436),
//--TRIMMABLE-BOUNDARY-START(21474902028),
    {
      "t": 1310721,
      "n": "TensorTDiagId",
      "d": 65548,
      "h": 21474902028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902028),
//--TRIMMABLE-BOUNDARY-START(17179934732),
    {
      "t": 1310721,
      "n": "SystemColorsDiagId",
      "d": 65548,
      "h": 17179934732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17179934732),
//--TRIMMABLE-BOUNDARY-START(4295032844),
    {
      "t": 1310721,
      "n": "ArmSveDiagId",
      "d": 65548,
      "h": 4295032844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295032844),
//--TRIMMABLE-BOUNDARY-START(25769869324),
    {
      "t": 1310721,
      "n": "X86BaseDivRemDiagId",
      "d": 65548,
      "h": 25769869324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769869324),
//--TRIMMABLE-BOUNDARY-START(8590000140),
    {
      "t": 1310721,
      "n": "PostQuantumCryptographyDiagId",
      "d": 65548,
      "h": 8590000140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590000140)
  ],
  "h": 65548
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65548)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"))
//--TRIMMABLE-BOUNDARY-END(12)
