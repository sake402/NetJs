
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $snp, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Bcl.Cryptography", 
    {"h":37517,"f":"Microsoft.Bcl.Cryptography","v":"1.0.35.0","a":[{"t":96206849,"c":4391174145,"a":[{"v":2011919,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":5878543,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":23048975,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":26653455,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":26718991,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":28553999,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":7254799,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":7385871,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":7451407,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14005007,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14136079,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14201615,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14463759,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14660367,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":14725903,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":22655759,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":22786831,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":22852367,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":15577871,"t":142475265}]},{"t":96206849,"c":4391174145,"a":[{"v":15643407,"t":142475265}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Bcl.Cryptography","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Bcl.Cryptography","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mbc.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 103053;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":103053,"h":4295070349,"f":4194344},{"t":1310721,"n":"TensorTDiagId","d":103053,"h":8590037645,"f":4194344},{"t":1310721,"n":"SystemColorsDiagId","d":103053,"h":12885004941,"f":4194344},{"t":1310721,"n":"ArmSveDiagId","d":103053,"h":17179972237,"f":4194344},{"t":1310721,"n":"X86BaseDivRemDiagId","d":103053,"h":21474939533,"f":4194344},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":103053,"h":25769906829,"f":4194344}],"h":103053}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$cls("$mbc.System.Security.Cryptography.X509Certificates.X509CertificateKeyAccessors", ($self) => class X509CertificateKeyAccessors
        {
            static /*MLKem? */ GetMLKemPublicKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLKemPublicKey();
            }
            static /*MLKem? */ GetMLKemPrivateKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLKemPrivateKey();
            }
            static /*X509Certificate2 */ CopyWithPrivateKey$2(/*this X509Certificate2*/ certificate, /*MLKem*/ privateKey)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$3(privateKey);
            }
            static /*MLDsa? */ GetMLDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLDsaPublicKey();
            }
            static /*MLDsa? */ GetMLDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetMLDsaPrivateKey();
            }
            static /*X509Certificate2 */ CopyWithPrivateKey$1(/*this X509Certificate2*/ certificate, /*MLDsa*/ privateKey)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$2(privateKey);
            }
            static /*SlhDsa? */ GetSlhDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetSlhDsaPublicKey();
            }
            static /*SlhDsa? */ GetSlhDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetSlhDsaPrivateKey();
            }
            static /*X509Certificate2 */ CopyWithPrivateKey$3(/*this X509Certificate2*/ certificate, /*SlhDsa*/ privateKey)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey$4(privateKey);
            }
            static /*CompositeMLDsa? */ GetCompositeMLDsaPublicKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetCompositeMLDsaPublicKey();
            }
            static /*CompositeMLDsa? */ GetCompositeMLDsaPrivateKey(/*this X509Certificate2*/ certificate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                return certificate.GetCompositeMLDsaPrivateKey();
            }
            static /*X509Certificate2 */ CopyWithPrivateKey(/*this X509Certificate2*/ certificate, /*CompositeMLDsa*/ privateKey)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(certificate, "certificate");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(privateKey, "privateKey");
                return certificate.CopyWithPrivateKey(privateKey);
            }
            static $h = 168589;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":14463759,"p":[{"n":"certificate","p":28226319}],"n":"GetMLKemPublicKey","d":168589,"h":4295135885,"f":16777249},{"r":14463759,"p":[{"n":"certificate","p":28226319}],"n":"GetMLKemPrivateKey","d":168589,"h":8590103181,"f":16777249},{"r":28226319,"p":[{"n":"certificate","p":28226319},{"n":"privateKey","p":14463759}],"n":"CopyWithPrivateKey","o":"@$2","d":168589,"h":12885070477,"f":16777249},{"r":14005007,"p":[{"n":"certificate","p":28226319}],"n":"GetMLDsaPublicKey","d":168589,"h":17180037773,"f":16777249},{"r":14005007,"p":[{"n":"certificate","p":28226319}],"n":"GetMLDsaPrivateKey","d":168589,"h":21475005069,"f":16777249},{"r":28226319,"p":[{"n":"certificate","p":28226319},{"n":"privateKey","p":14005007}],"n":"CopyWithPrivateKey","o":"@$1","d":168589,"h":25769972365,"f":16777249},{"r":22655759,"p":[{"n":"certificate","p":28226319}],"n":"GetSlhDsaPublicKey","d":168589,"h":30064939661,"f":16777249},{"r":22655759,"p":[{"n":"certificate","p":28226319}],"n":"GetSlhDsaPrivateKey","d":168589,"h":34359906957,"f":16777249},{"r":28226319,"p":[{"n":"certificate","p":28226319},{"n":"privateKey","p":22655759}],"n":"CopyWithPrivateKey","o":"@$3","d":168589,"h":38654874253,"f":16777249},{"r":7254799,"p":[{"n":"certificate","p":28226319}],"n":"GetCompositeMLDsaPublicKey","d":168589,"h":42949841549,"f":16777249},{"r":7254799,"p":[{"n":"certificate","p":28226319}],"n":"GetCompositeMLDsaPrivateKey","d":168589,"h":47244808845,"f":16777249},{"r":28226319,"p":[{"n":"certificate","p":28226319},{"n":"privateKey","p":7254799}],"n":"CopyWithPrivateKey","d":168589,"h":51539776141,"f":16777249}],"h":168589}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Security.Cryptography.X509Certificates.X509CertificateKeyAccessors`; }
        });
        
        $asm.$cls("$mbc.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mbc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mbc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mbc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mbc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mbc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mbc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mbc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Bcl.Cryptography", $.$mbc.System.SR.$type.Assembly);
                    $.$mbc.System.SR.s_resourceManager = temp;
                }
                return $.$mbc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mbc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mbc.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_CryptographyException()
            {
                return "Error occurred during a cryptographic operation.";
            }
            static /*string */ get Argument_DestinationImprecise()
            {
                return "Destination must be exactly {0} bytes.";
            }
            static /*string */ FormatArgument_DestinationImprecise(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Destination must be exactly {0} bytes.", arg1);
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get Argument_HashImprecise()
            {
                return "Hash must be exactly {0} bytes.";
            }
            static /*string */ FormatArgument_HashImprecise(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Hash must be exactly {0} bytes.", arg1);
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get Argument_InvalidValue()
            {
                return "Value was invalid.";
            }
            static /*string */ get Argument_KemInvalidCiphertextLength()
            {
                return "The specified ciphertext is not the correct length for the ML-KEM algorithm.";
            }
            static /*string */ get Argument_KemInvalidDecapsulationKeyLength()
            {
                return "The specified decapsulation key is not the correct length for the ML-KEM algorithm.";
            }
            static /*string */ get Argument_KemInvalidEncapsulationKeyLength()
            {
                return "The specified encapsulation key is not the correct length for the ML-KEM algorithm.";
            }
            static /*string */ get Argument_KemInvalidSeedLength()
            {
                return "The specified private seed is not the correct length for the ML-KEM algorithm.";
            }
            static /*string */ get Argument_MLDsaMuInvalidLength()
            {
                return "The specified mu value is not the correct length for the ML-DSA algorithm.";
            }
            static /*string */ get Argument_PemEncoding_InvalidLabel()
            {
                return "The specified label is not valid.";
            }
            static /*string */ get Argument_PemEncoding_EncodedSizeTooLarge()
            {
                return "The encoded PEM size is too large to represent as a signed 32-bit integer.";
            }
            static /*string */ get Argument_PemEncoding_NoPemFound()
            {
                return "No PEM encoded data found.";
            }
            static /*string */ get Argument_PemImport_NoPemFound()
            {
                return "No supported key formats were found. Check that the input represents the contents of a PEM-encoded key file, not the path to such a file.";
            }
            static /*string */ get Argument_PemImport_AmbiguousPem()
            {
                return "The input contains multiple keys, but only one key can be imported.";
            }
            static /*string */ get Argument_PemImport_EncryptedPem()
            {
                return "An encrypted key was found, but no password was provided. Use ImportFromEncryptedPem to import this key.";
            }
            static /*string */ get Argument_PrivateKeyWrongSizeForAlgorithm()
            {
                return "The private key is not the correct size for the indicated algorithm.";
            }
            static /*string */ get Argument_PrivateSeedWrongSizeForAlgorithm()
            {
                return "The private seed is not the correct size for the indicated algorithm.";
            }
            static /*string */ get Argument_PublicKeyWrongSizeForAlgorithm()
            {
                return "The public key is not the correct size for the indicated algorithm.";
            }
            static /*string */ get Argument_SignatureContextTooLong255()
            {
                return "The specified signature context exceeds the maximum length of 255 bytes.";
            }
            static /*string */ get ArgumentOutOfRange_Generic_MustBeNonNegativeNonZero()
            {
                return "{0} ('{1}') must be a non-negative and non-zero value.";
            }
            static /*string */ FormatArgumentOutOfRange_Generic_MustBeNonNegativeNonZero(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("{0} ('{1}') must be a non-negative and non-zero value.", arg1, arg2);
            }
            static /*string */ get ArgumentOutOfRange_NeedPositiveNumber()
            {
                return "A positive number is required.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get ArgumentOutOfRange_KOut_Too_Large()
            {
                return "The number of bytes requested is too large. The number of bytes produced by SP800108HmacCounterKdf cannot exceed 536,870,911 bytes.";
            }
            static /*string */ get Argument_EmptyString()
            {
                return "The value cannot be an empty string.";
            }
            static /*string */ get Cryptography_AlgKdfRequiresChars()
            {
                return "The KDF for algorithm '{0}' requires a char-based password input.";
            }
            static /*string */ FormatCryptography_AlgKdfRequiresChars(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The KDF for algorithm '{0}' requires a char-based password input.", arg1);
            }
            static /*string */ get Cryptography_AlgorithmNotSupported()
            {
                return "Algorithm '{0}' is not supported on this platform.";
            }
            static /*string */ FormatCryptography_AlgorithmNotSupported(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Algorithm '{0}' is not supported on this platform.", arg1);
            }
            static /*string */ get Cryptography_ArgMLDsaRequiresMLDsaKey()
            {
                return "Keys used with the MLDsaCng algorithm must have an algorithm group of MLDsa.";
            }
            static /*string */ get Cryptography_ArgMLKemRequiresMLKemKey()
            {
                return "Keys used with the MLKemCng algorithm must have an algorithm group of MLKem.";
            }
            static /*string */ get Cryptography_AuthTagMismatch()
            {
                return "The computed authentication tag did not match the input authentication tag.";
            }
            static /*string */ get Cryptography_Cert_AlreadyHasPrivateKey()
            {
                return "The certificate already has an associated private key.";
            }
            static /*string */ get Cryptography_CompositeSignDataError()
            {
                return "Composite signature generation failed due to an error in one or both of the components.";
            }
            static /*string */ get Cryptography_CurveNotSupported()
            {
                return "The specified curve '{0}' or its parameters are not valid for this platform.";
            }
            static /*string */ FormatCryptography_CurveNotSupported(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The specified curve '{0}' or its parameters are not valid for this platform.", arg1);
            }
            static /*string */ get Cryptography_Der_Invalid_Encoding()
            {
                return "ASN1 corrupted data.";
            }
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                return "The hash algorithm name cannot be null or empty.";
            }
            static /*string */ get Cryptography_HashLengthMismatch()
            {
                return "The specified hash is not a valid size for this hash algorithm.";
            }
            static /*string */ get Cryptography_HashMLDsaAlgorithmMismatch()
            {
                return "HashML-DSA '{0}' cannot be used with hash algorithm '{1}'.";
            }
            static /*string */ FormatCryptography_HashMLDsaAlgorithmMismatch(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("HashML-DSA '{0}' cannot be used with hash algorithm '{1}'.", arg1, arg2);
            }
            static /*string */ get Cryptography_IncorrectTagLength()
            {
                return "The size of the specified tag does not match the expected size of {0}.";
            }
            static /*string */ FormatCryptography_IncorrectTagLength(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The size of the specified tag does not match the expected size of {0}.", arg1);
            }
            static /*string */ get Cryptography_InvalidECPrivateKeyParameters()
            {
                return "The specified key parameters are not valid. X and Y, or D, must be specified. X, Y must be the same length. If D is specified it must be the same length as X and Y if also specified.";
            }
            static /*string */ get Cryptography_InvalidKeySize()
            {
                return "Specified key is not a valid size for this algorithm.";
            }
            static /*string */ get Cryptography_InvalidTagLength()
            {
                return "The specified tag is not a valid size for this algorithm.";
            }
            static /*string */ get Cryptography_InvalidNonceLength()
            {
                return "The specified nonce is not a valid size for this algorithm.";
            }
            static /*string */ get Cryptography_InvalidOidFormat()
            {
                return "Invalid OID format.";
            }
            static /*string */ get Cryptography_InvalidRsaParameters()
            {
                return "The specified RSA parameters are not valid. Exponent and Modulus are required. If D is present, it must have the same length as Modulus. If D is present, P, Q, DP, DQ, and InverseQ are required and must have half the length of Modulus, rounded up, otherwise they must be omitted.";
            }
            static /*string */ get Cryptography_KemPkcs8KeyMismatch()
            {
                return "The specified PKCS#8 key contains a seed that does not match the expanded key.";
            }
            static /*string */ get Cryptography_KemNoDecapsulationKey()
            {
                return "The current instance does not contain a decapsulation key.";
            }
            static /*string */ get Cryptography_KeyNotExtractable()
            {
                return "The key does not permit being exported.";
            }
            static /*string */ get Cryptography_KeyWrongSizeForAlgorithm()
            {
                return "The specified key is not the correct size for the indicated algorithm.";
            }
            static /*string */ get Cryptography_MLDsaPkcs8KeyMismatch()
            {
                return "The specified PKCS#8 key contains a seed that does not match the expanded key.";
            }
            static /*string */ get Cryptography_NoPrivateKeyAvailable()
            {
                return "The current instance does not contain a private key.";
            }
            static /*string */ get Cryptography_NotValidPrivateKey()
            {
                return "Key is not a valid private key.";
            }
            static /*string */ get Cryptography_NotValidPublicOrPrivateKey()
            {
                return "Key is not a valid public or private key.";
            }
            static /*string */ get Cryptography_OverlappingBuffers()
            {
                return "One or more provided buffers overlap.";
            }
            static /*string */ get Cryptography_Pfx_BadPassword()
            {
                return "The certificate data cannot be read with the provided password, the password may be incorrect.";
            }
            static /*string */ get Cryptography_Pfx_NoCertificates()
            {
                return "The provided PFX data contains no certificates.";
            }
            static /*string */ get Cryptography_Pkcs8_EncryptedReadFailed()
            {
                return "The EncryptedPrivateKeyInfo structure was decoded but was not successfully interpreted, the password may be incorrect.";
            }
            static /*string */ get Cryptography_PlaintextCiphertextLengthMismatch()
            {
                return "Plaintext and ciphertext must have the same length.";
            }
            static /*string */ get Cryptography_PqcNoSeed()
            {
                return "The current instance does not contain a seed.";
            }
            static /*string */ get Cryptography_PrivateKey_DoesNotMatch()
            {
                return "The provided key does not match the public key for this certificate.";
            }
            static /*string */ get Cryptography_PrivateKey_WrongAlgorithm()
            {
                return "The provided key does not match the public key algorithm for this certificate.";
            }
            static /*string */ get Cryptography_RSAPrivateKey_VersionTooNew()
            {
                return "The provided RSAPrivateKey value has version '{0}', but version '{1}' is the maximum supported.";
            }
            static /*string */ FormatCryptography_RSAPrivateKey_VersionTooNew(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The provided RSAPrivateKey value has version '{0}', but version '{1}' is the maximum supported.", arg1, arg2);
            }
            static /*string */ get Cryptography_UnknownAlgorithmIdentifier()
            {
                return "The algorithm identified by '{0}' is unknown, not valid for the requested usage, or was not handled.";
            }
            static /*string */ FormatCryptography_UnknownAlgorithmIdentifier(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The algorithm identified by '{0}' is unknown, not valid for the requested usage, or was not handled.", arg1);
            }
            static /*string */ get Cryptography_UnknownHashAlgorithm()
            {
                return "'{0}' is not a known hash algorithm.";
            }
            static /*string */ FormatCryptography_UnknownHashAlgorithm(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("'{0}' is not a known hash algorithm.", arg1);
            }
            static /*string */ get Cryptography_X509_PKCS12_LimitExceeded()
            {
                return "The PKCS#12/PFX violated the '{0}' limit.";
            }
            static /*string */ FormatCryptography_X509_PKCS12_LimitExceeded(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The PKCS#12/PFX violated the '{0}' limit.", arg1);
            }
            static /*string */ get Cryptography_X509_PKCS12_LimitsReadOnly()
            {
                return "This Pkcs12LoaderLimits object has been made read-only and can no longer be modified.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mbc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 234125;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":234125}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"))