
//--TRIMMABLE-BOUNDARY-START(102)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sl) {
    "use strict";
    let _;
    let $ExTKjk;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Caching.Abstractions", 
    {
  "h": 102,
  "f": "Microsoft.Extensions.Caching.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 130809857,
          "t": 188547073
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Caching.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Caching.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(655462)
        $asm.$cls(`$meca.MECH.IHybridCacheSerializer<>`, (T) => $asm.$gt(`$meca.MECH.IHybridCacheSerializer<>`, [T], ($self) => class IHybridCacheSerializer$$
        {
            static $H = 655462;
            static $h = 655462;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295622758),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "source",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        }
      ],
      "n": "Deserialize",
      "o": `MECH$IHybridCacheSerializer$${T.$getFullName('$')}$Deserialize`,
      "d": this.$h,
      "H": 4295622758,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622758),
//--TRIMMABLE-BOUNDARY-START(8590590054),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1572864
        },
        {
          "n": "target",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        }
      ],
      "n": "Serialize",
      "o": `MECH$IHybridCacheSerializer$${T.$getFullName('$')}$Serialize`,
      "d": this.$h,
      "H": 8590590054,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590590054)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 655462,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.IHybridCacheSerializer<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}IHybridCacheSerializer$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(655462)
        
        

        //--TRIMMABLE-BOUNDARY-START(327782)
        $asm.$cls(`$meca.MECD.IDistributedCache`, ($self) => class IDistributedCache
        {
            static $h = 327782;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295078),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "MECD$IDistributedCache$Get",
      "d": 327782,
      "h": 4295295078,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295078),
//--TRIMMABLE-BOUNDARY-START(8590262374),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetAsync",
      "o": "MECD$IDistributedCache$GetAsync",
      "d": 327782,
      "h": 8590262374,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590262374),
//--TRIMMABLE-BOUNDARY-START(30065098854),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        }
      ],
      "n": "Set",
      "o": "MECD$IDistributedCache$Set",
      "d": 327782,
      "h": 30065098854,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065098854),
//--TRIMMABLE-BOUNDARY-START(34360066150),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetAsync",
      "o": "MECD$IDistributedCache$SetAsync",
      "d": 327782,
      "h": 34360066150,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360066150),
//--TRIMMABLE-BOUNDARY-START(12885229670),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Refresh",
      "o": "MECD$IDistributedCache$Refresh",
      "d": 327782,
      "h": 12885229670,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885229670),
//--TRIMMABLE-BOUNDARY-START(17180196966),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RefreshAsync",
      "o": "MECD$IDistributedCache$RefreshAsync",
      "d": 327782,
      "h": 17180196966,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180196966),
//--TRIMMABLE-BOUNDARY-START(21475164262),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "o": "MECD$IDistributedCache$Remove",
      "d": 327782,
      "h": 21475164262,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475164262),
//--TRIMMABLE-BOUNDARY-START(25770131558),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveAsync",
      "o": "MECD$IDistributedCache$RemoveAsync",
      "d": 327782,
      "h": 25770131558,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770131558)
  ],
  "h": 327782
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.IDistributedCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}IDistributedCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327782)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507430)
        $asm.$cls(`$meca.MEI.ISystemClock`, ($self) => class ISystemClock
        {
            static $h = 1507430;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886409318),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591442022,
        "f": 50331905
      },
      "n": "UtcNow",
      "o": "MEI$ISystemClock$UtcNow",
      "d": 1507430,
      "h": 12886409318,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886409318)
  ],
  "h": 1507430
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.ISystemClock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}ISystemClock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507430)
        
        

        //--TRIMMABLE-BOUNDARY-START(720998)
        $asm.$cls(`$meca.MECH.IHybridCacheSerializerFactory`, ($self) => class IHybridCacheSerializerFactory
        {
            static $h = 720998;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295688294),
    {
      "r": 262145,
      "p": [
        {
          "n": "serializer",
          "p": (T) => $.$meca.MECH.IHybridCacheSerializer$$(T).$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryCreateSerializer",
      "o": "MECH$IHybridCacheSerializerFactory$TryCreateSerializer",
      "d": 720998,
      "h": 4295688294,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295688294)
  ],
  "h": 720998
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.IHybridCacheSerializerFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}IHybridCacheSerializerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720998)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048678)
        $asm.$cls(`$meca.MECM.ICacheEntry`, ($self) => class ICacheEntry
        {
            static $h = 1048678;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490329190),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245688934,
        "f": 50331905
      },
      "n": "Key",
      "o": "MECM$ICacheEntry$Key",
      "d": 1048678,
      "h": 94490329190,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94490329190),
//--TRIMMABLE-BOUNDARY-START(167504773222),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195361894,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619871334,
        "f": 83886337
      },
      "n": "Value",
      "o": "MECM$ICacheEntry$Value",
      "d": 1048678,
      "h": 167504773222,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(167504773222),
//--TRIMMABLE-BOUNDARY-START(4296015974),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475885158,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670198374,
        "f": 83886337
      },
      "n": "AbsoluteExpiration",
      "o": "MECM$ICacheEntry$AbsoluteExpiration",
      "d": 1048678,
      "h": 4296015974,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296015974),
//--TRIMMABLE-BOUNDARY-START(8590983270),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065819750,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260132966,
        "f": 83886337
      },
      "n": "AbsoluteExpirationRelativeToNow",
      "o": "MECM$ICacheEntry$AbsoluteExpirationRelativeToNow",
      "d": 1048678,
      "h": 8590983270,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590983270),
//--TRIMMABLE-BOUNDARY-START(163209805926),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605427302,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029936742,
        "f": 83886337
      },
      "n": "SlidingExpiration",
      "o": "MECM$ICacheEntry$SlidingExpiration",
      "d": 1048678,
      "h": 163209805926,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163209805926),
//--TRIMMABLE-BOUNDARY-START(12885950566),
    {
      "p": $.$$.SCG.IList$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655754342,
        "f": 50331905
      },
      "n": "ExpirationTokens",
      "o": "MECM$ICacheEntry$ExpirationTokens",
      "d": 1048678,
      "h": 12885950566,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885950566),
//--TRIMMABLE-BOUNDARY-START(98785296486),
    {
      "p": $.$$.SCG.IList$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835623526,
        "f": 50331905
      },
      "n": "PostEvictionCallbacks",
      "o": "MECM$ICacheEntry$PostEvictionCallbacks",
      "d": 1048678,
      "h": 98785296486,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98785296486),
//--TRIMMABLE-BOUNDARY-START(103080263782),
    {
      "p": 917606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425558118,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128850067558,
        "f": 83886337
      },
      "n": "Priority",
      "o": "MECM$ICacheEntry$Priority",
      "d": 1048678,
      "h": 103080263782,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103080263782),
//--TRIMMABLE-BOUNDARY-START(158914838630),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015492710,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137440002150,
        "f": 83886337
      },
      "n": "Size",
      "o": "MECM$ICacheEntry$Size",
      "d": 1048678,
      "h": 158914838630,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158914838630)
  ],
  "h": 1048678
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.ICacheEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}ICacheEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048678)
        
        

        //--TRIMMABLE-BOUNDARY-START(262246)
        $asm.$cls(`$meca.MECD.IBufferDistributedCache`, ($self) => class IBufferDistributedCache
        {
            static $h = 262246;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164134),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "destination",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        }
      ],
      "n": "TryGet",
      "o": "MECD$IBufferDistributedCache$TryGet",
      "d": 262246,
      "h": 12885164134,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885164134),
//--TRIMMABLE-BOUNDARY-START(17180131430),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Boolean).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "destination",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "TryGetAsync",
      "o": "MECD$IBufferDistributedCache$TryGetAsync",
      "d": 262246,
      "h": 17180131430,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180131430),
//--TRIMMABLE-BOUNDARY-START(4295229542),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        }
      ],
      "n": "Set",
      "o": "MECD$IBufferDistributedCache$Set",
      "d": 262246,
      "h": 4295229542,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229542),
//--TRIMMABLE-BOUNDARY-START(8590196838),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetAsync",
      "o": "MECD$IBufferDistributedCache$SetAsync",
      "d": 262246,
      "h": 8590196838,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590196838)
  ],
  "h": 262246
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.MECD.IDistributedCache ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.IBufferDistributedCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}IBufferDistributedCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262246)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114214)
        $asm.$cls(`$meca.MECM.IMemoryCache`, ($self) => class IMemoryCache
        {
            //--TRIMMABLE-BOUNDARY-START(8591048806)
            /*MemoryCacheStatistics? */ MECM$IMemoryCache$GetCurrentStatistics()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591048806);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591048806)
            
            static $h = 1114214;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180983398),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "o": "MECM$IMemoryCache$TryGetValue",
      "d": 1114214,
      "h": 17180983398,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180983398),
//--TRIMMABLE-BOUNDARY-START(4296081510),
    {
      "r": 1048678,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "CreateEntry",
      "o": "MECM$IMemoryCache$CreateEntry",
      "d": 1114214,
      "h": 4296081510,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081510),
//--TRIMMABLE-BOUNDARY-START(12886016102),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "o": "MECM$IMemoryCache$Remove",
      "d": 1114214,
      "h": 12886016102,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886016102),
//--TRIMMABLE-BOUNDARY-START(8591048806),
    {
      "r": 1310822,
      "n": "GetCurrentStatistics",
      "o": "MECM$IMemoryCache$GetCurrentStatistics",
      "d": 1114214,
      "h": 8591048806,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591048806)
  ],
  "h": 1114214
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.IMemoryCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}IMemoryCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114214)
        
        

        //--TRIMMABLE-BOUNDARY-START(393318)
        $asm.$cls(`$meca.MECH.HybridCache`, ($self) => class HybridCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180262502)
            /*ValueTask<T> */ GetOrCreateAsync$2(T, /*string*/ key, /*Func<CancellationToken, ValueTask<T>>*/ factory, /*HybridCacheEntryOptions?*/ options, /*IEnumerable<string>?*/ tags, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262502);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateAsync$5($.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)), T, key, factory, $.$meca.MECH.HybridCache.WrappedCallbackCache$$(T).Instance, options, tags, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262502)
            
            //--TRIMMABLE-BOUNDARY-START(12885295206)
            /*ValueTask<T> */ GetOrCreateAsync$1(T, /*ReadOnlySpan<char>*/ key, /*Func<CancellationToken, ValueTask<T>>*/ factory, /*HybridCacheEntryOptions?*/ options, /*IEnumerable<string>?*/ tags, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295206);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateAsync$4($.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)), T, key, factory, $.$meca.MECH.HybridCache.WrappedCallbackCache$$(T).Instance, options, tags, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295206)
            
            //--TRIMMABLE-BOUNDARY-START(25770197094)
            /*ValueTask<T> */ GetOrCreateAsync$4(TState, T, /*ReadOnlySpan<char>*/ key, /*TState*/ state, /*Func<TState, CancellationToken, ValueTask<T>>*/ factory, /*HybridCacheEntryOptions?*/ options, /*IEnumerable<string>?*/ tags, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197094);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetOrCreateAsync$5(TState, T, key.ToString(), state, factory, options, tags, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197094)
            
            //--TRIMMABLE-BOUNDARY-START(8590327910)
            /*ValueTask<T> */ GetOrCreateAsync(T, /*ref DefaultInterpolatedStringHandler*/ key, /*Func<CancellationToken, ValueTask<T>>*/ factory, /*HybridCacheEntryOptions?*/ options, /*IEnumerable<string>?*/ tags, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<T>*/ let result = this.GetOrCreateAsync$4($.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)), T, key.$v.Text, factory, $.$meca.MECH.HybridCache.WrappedCallbackCache$$(T).Instance, options, tags, cancellationToken);
                key.$v.Clear();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327910)
            
            //--TRIMMABLE-BOUNDARY-START(21475229798)
            /*ValueTask<T> */ GetOrCreateAsync$3(TState, T, /*ref DefaultInterpolatedStringHandler*/ key, /*TState*/ state, /*Func<TState, CancellationToken, ValueTask<T>>*/ factory, /*HybridCacheEntryOptions?*/ options, /*IEnumerable<string>?*/ tags, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<T>*/ let result = this.GetOrCreateAsync$4(TState, T, key.$v.Text, state, factory, options, tags, cancellationToken);
                key.$v.Clear();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229798)
            
            //--TRIMMABLE-BOUNDARY-START(458854)
            static $_WrappedCallbackCache$$;
            static WrappedCallbackCache$$(T)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$meca.MECH.HybridCache;
                return ($cls.$_WrappedCallbackCache$$ ??= $asm.$ncls(`$meca.MECH.HybridCache.WrappedCallbackCache<>`, (T) => $asm.$gt(`$meca.MECH.HybridCache.WrappedCallbackCache<>`, [T], ($self) => class WrappedCallbackCache$$
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393446)
                    /*Func<Func<CancellationToken, ValueTask<T>>, CancellationToken, ValueTask<T>>*/ static Instance = null;
                    //--TRIMMABLE-BOUNDARY-END(8590393446)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426150)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295426150);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(8590393446)
                            this.Instance = new ($.$$.S.Func$$$$($.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)), $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)))().$ctor($.$meca.MECH.HybridCache.WrappedCallbackCache$$(T), /*static*/ (/*callback*/ callback, /*ct*/ ct) =>
                            {
                                return callback.Invoke(ct);
                            }, $ExTKjk ??= {"r":$.$$.STT.ValueTask$$(T).$h,"p":[{"n":"callback","p":$.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h},{"n":"ct","p":170852353}],"n":"","d":this.$h,"H":0,"h":0,"f":17825826});
                            //--TRIMMABLE-BOUNDARY-END(8590393446)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295426150)
                    
                    static $H = 458854;
                    static $h = 458854;
                    static $g = 1;
                    static $f = 0b10000000001010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393446),
    {
      "t": $.$$.S.Func$$$$($.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)), $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h,
      "n": "Instance",
      "d": this.$h,
      "H": 8590393446,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590393446)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "d": 393318,
  "H": 458854,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.HybridCache+WrappedCallbackCache<${T?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}HybridCache${separator}WrappedCallbackCache$${T?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_WrappedCallbackCache$$ = $v))(T);
            }
            //--TRIMMABLE-BOUNDARY-END(458854)
            
            //--TRIMMABLE-BOUNDARY-START(34360131686)
            /*ValueTask */ RemoveAsync(/*IEnumerable<string>*/ keys, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if ((keys === null) || ($.$is(keys, $.$$.SCG.ICollection$$($.$$.S.String)) && keys.SCG$ICollection$$$Count === 0))
                    {
                        return new $.$$.STT.ValueTask();
                    }
                    if ($.$is(keys, $.$$.SCG.ICollection$$($.$$.S.String)) && keys.SCG$ICollection$$$Count === 1)
                    {
                        return this.RemoveAsync$1($.$sl.SL.Enumerable.First$1($.$$.S.String, keys), cancellationToken);
                    }
                    return ForEachAsync(this, keys, cancellationToken);
                })();
                /*static ValueTask*/ /*async*/  function ForEachAsync(/*HybridCache*/ $this, /*IEnumerable<string>*/ keys, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $en1 = keys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en1.SCG$IEnumerator$$$Current;
                            {
                                let $t2, $r2;
                                ($t2 = $this.RemoveAsync$1(key, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t2, { set $v($v) { $r2 = $v; } }) ? $r2 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t2)));
                            }
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360131686)
            
            //--TRIMMABLE-BOUNDARY-START(42950066278)
            /*ValueTask */ RemoveByTagAsync(/*IEnumerable<string>*/ tags, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    if ((tags === null) || ($.$is(tags, $.$$.SCG.ICollection$$($.$$.S.String)) && tags.SCG$ICollection$$$Count === 0))
                    {
                        return new $.$$.STT.ValueTask();
                    }
                    if ($.$is(tags, $.$$.SCG.ICollection$$($.$$.S.String)) && tags.SCG$ICollection$$$Count === 1)
                    {
                        return this.RemoveByTagAsync$1($.$sl.SL.Enumerable.Single$1($.$$.S.String, tags), cancellationToken);
                    }
                    return ForEachAsync(this, tags, cancellationToken);
                })();
                /*static ValueTask*/ /*async*/  function ForEachAsync(/*HybridCache*/ $this, /*IEnumerable<string>*/ keys, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.N.AsyncResolver.Async($.$$.STT.ValueTask, $.$$.S.Void, async ($asnycContext) => 
                    {
                        let $en3 = keys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en3.SCG$IEnumerator$$$Current;
                            {
                                let $t4, $r4;
                                ($t4 = $this.RemoveByTagAsync$1(key, cancellationToken).ConfigureAwait(false), ($.$$.N.AsyncResolver.IsCompleted($t4, { set $v($v) { $r4 = $v; } }) ? $r4 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t4)));
                            }
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950066278)
            
            //--TRIMMABLE-BOUNDARY-START(4295360614)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360614)
            
            //--TRIMMABLE-BOUNDARY-START(4295360614)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360614)
            
            static $h = 393318;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164390),
    {
      "r": (TState, T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "state",
          "p": (TState, T) => TState.$h
        },
        {
          "n": "factory",
          "p": (TState, T) => $.$$.S.Func$$$$(TState, $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TState",
        "T"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$5",
      "d": 393318,
      "h": 30065164390,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(30065164390),
//--TRIMMABLE-BOUNDARY-START(17180262502),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "factory",
          "p": (T) => $.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$2",
      "d": 393318,
      "h": 17180262502,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17180262502),
//--TRIMMABLE-BOUNDARY-START(12885295206),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "factory",
          "p": (T) => $.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$1",
      "d": 393318,
      "h": 12885295206,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12885295206),
//--TRIMMABLE-BOUNDARY-START(25770197094),
    {
      "r": (TState, T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "state",
          "p": (TState, T) => TState.$h
        },
        {
          "n": "factory",
          "p": (TState, T) => $.$$.S.Func$$$$(TState, $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TState",
        "T"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$4",
      "d": 393318,
      "h": 25770197094,
      "f": 16908417
    },
//--TRIMMABLE-BOUNDARY-END(25770197094),
//--TRIMMABLE-BOUNDARY-START(8590327910),
    {
      "r": (T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 128188417,
          "f": 4
        },
        {
          "n": "factory",
          "p": (T) => $.$$.S.Func$$$($.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetOrCreateAsync",
      "d": 393318,
      "h": 8590327910,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(8590327910),
//--TRIMMABLE-BOUNDARY-START(21475229798),
    {
      "r": (TState, T) => $.$$.STT.ValueTask$$(T).$h,
      "p": [
        {
          "n": "key",
          "p": 128188417,
          "f": 4
        },
        {
          "n": "state",
          "p": (TState, T) => TState.$h
        },
        {
          "n": "factory",
          "p": (TState, T) => $.$$.S.Func$$$$(TState, $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$(T)).$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "TState",
        "T"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$3",
      "d": 393318,
      "h": 21475229798,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(21475229798),
//--TRIMMABLE-BOUNDARY-START(51540000870),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "options",
          "p": 589926,
          "f": 65
        },
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "SetAsync",
      "d": 393318,
      "h": 51540000870,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(51540000870),
//--TRIMMABLE-BOUNDARY-START(38655098982),
    {
      "r": 181338113,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveAsync",
      "o": "@$1",
      "d": 393318,
      "h": 38655098982,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655098982),
//--TRIMMABLE-BOUNDARY-START(34360131686),
    {
      "r": 181338113,
      "p": [
        {
          "n": "keys",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveAsync",
      "d": 393318,
      "h": 34360131686,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360131686),
//--TRIMMABLE-BOUNDARY-START(42950066278),
    {
      "r": 181338113,
      "p": [
        {
          "n": "tags",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveByTagAsync",
      "d": 393318,
      "h": 42950066278,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950066278),
//--TRIMMABLE-BOUNDARY-START(47245033574),
    {
      "r": 181338113,
      "p": [
        {
          "n": "tag",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveByTagAsync",
      "o": "@$1",
      "d": 393318,
      "h": 47245033574,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245033574)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360614),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393318,
      "h": 4295360614,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295360614)
  ],
  "h": 393318
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$meca.MECH.HybridCache.WrappedCallbackCache$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.HybridCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}HybridCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393318)
        
        

        //--TRIMMABLE-BOUNDARY-START(65638)
        $asm.$cls(`$meca.MECD.DistributedCacheEntryExtensions`, ($self) => class DistributedCacheEntryExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590000230)
            static /*DistributedCacheEntryOptions */ SetAbsoluteExpiration$1(/*this DistributedCacheEntryOptions*/ options, /*TimeSpan*/ relative)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.AbsoluteExpirationRelativeToNow = relative;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000230)
            
            //--TRIMMABLE-BOUNDARY-START(4295032934)
            static /*DistributedCacheEntryOptions */ SetAbsoluteExpiration(/*this DistributedCacheEntryOptions*/ options, /*DateTimeOffset*/ absolute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.AbsoluteExpiration = absolute;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032934)
            
            //--TRIMMABLE-BOUNDARY-START(12884967526)
            static /*DistributedCacheEntryOptions */ SetSlidingExpiration(/*this DistributedCacheEntryOptions*/ options, /*TimeSpan*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.SlidingExpiration = offset;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967526)
            
            static $h = 65638;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000230),
    {
      "r": 131174,
      "p": [
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "relative",
          "p": 186646529
        }
      ],
      "n": "SetAbsoluteExpiration",
      "o": "@$1",
      "d": 65638,
      "h": 8590000230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000230),
//--TRIMMABLE-BOUNDARY-START(4295032934),
    {
      "r": 131174,
      "p": [
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "absolute",
          "p": 66191361
        }
      ],
      "n": "SetAbsoluteExpiration",
      "d": 65638,
      "h": 4295032934,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032934),
//--TRIMMABLE-BOUNDARY-START(12884967526),
    {
      "r": 131174,
      "p": [
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "offset",
          "p": 186646529
        }
      ],
      "n": "SetSlidingExpiration",
      "d": 65638,
      "h": 12884967526,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12884967526)
  ],
  "h": 65638
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}DistributedCacheEntryExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65638)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376358)
        $asm.$cls(`$meca.MECM.PostEvictionCallbackRegistration`, ($self) => class PostEvictionCallbackRegistration extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181245542)
            /*PostEvictionDelegate?*/ EvictionCallback = null;
            //--TRIMMABLE-BOUNDARY-END(17181245542)
            
            //--TRIMMABLE-BOUNDARY-START(55835951206)
            /*object?*/ State = null;
            //--TRIMMABLE-BOUNDARY-END(55835951206)
            
            //--TRIMMABLE-BOUNDARY-START(12886278246)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278246)
            
            //--TRIMMABLE-BOUNDARY-START(12886278246)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886278246)
            
            static $h = 1376358;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181245542),
    {
      "p": 1441894,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771180134,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42951049318,
        "f": 83886081
      },
      "n": "EvictionCallback",
      "d": 1376358,
      "h": 17181245542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181245542),
//--TRIMMABLE-BOUNDARY-START(55835951206),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361114726,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540983910,
        "f": 83886081
      },
      "n": "State",
      "d": 1376358,
      "h": 55835951206,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835951206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886278246),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376358,
      "h": 12886278246,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886278246)
  ],
  "h": 1376358
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.PostEvictionCallbackRegistration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}PostEvictionCallbackRegistration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376358)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310822)
        $asm.$cls(`$meca.MECM.MemoryCacheStatistics`, ($self) => class MemoryCacheStatistics extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476147302)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476147302);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476147302)
            
            //--TRIMMABLE-BOUNDARY-START(25771114598)
            /*long*/ CurrentEntryCount = 0n;
            //--TRIMMABLE-BOUNDARY-END(25771114598)
            
            //--TRIMMABLE-BOUNDARY-START(30066081894)
            /*long?*/ CurrentEstimatedSize = null;
            //--TRIMMABLE-BOUNDARY-END(30066081894)
            
            //--TRIMMABLE-BOUNDARY-START(107375493222)
            /*long*/ TotalMisses = 0n;
            //--TRIMMABLE-BOUNDARY-END(107375493222)
            
            //--TRIMMABLE-BOUNDARY-START(103080525926)
            /*long*/ TotalHits = 0n;
            //--TRIMMABLE-BOUNDARY-END(103080525926)
            
            //--TRIMMABLE-BOUNDARY-START(21476147302)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21476147302)
            
            static $h = 1310822;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771114598),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656016486,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015754854,
        "f": 83886081
      },
      "n": "CurrentEntryCount",
      "d": 1310822,
      "h": 25771114598,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771114598),
//--TRIMMABLE-BOUNDARY-START(30066081894),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245951078,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605689446,
        "f": 83886081
      },
      "n": "CurrentEstimatedSize",
      "d": 1310822,
      "h": 30066081894,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081894),
//--TRIMMABLE-BOUNDARY-START(107375493222),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425820262,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98785558630,
        "f": 83886081
      },
      "n": "TotalMisses",
      "d": 1310822,
      "h": 107375493222,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375493222),
//--TRIMMABLE-BOUNDARY-START(103080525926),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835885670,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195624038,
        "f": 83886081
      },
      "n": "TotalHits",
      "d": 1310822,
      "h": 103080525926,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080525926)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476147302),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310822,
      "h": 21476147302,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476147302)
  ],
  "h": 1310822
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCacheStatistics`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCacheStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310822)
        
        

        //--TRIMMABLE-BOUNDARY-START(589926)
        $asm.$cls(`$meca.MECH.HybridCacheEntryOptions`, ($self) => class HybridCacheEntryOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770393702)
            /*TimeSpan?*/ Expiration = null;
            //--TRIMMABLE-BOUNDARY-END(25770393702)
            
            //--TRIMMABLE-BOUNDARY-START(60130132070)
            /*TimeSpan?*/ LocalCacheExpiration = null;
            //--TRIMMABLE-BOUNDARY-END(60130132070)
            
            //--TRIMMABLE-BOUNDARY-START(30065360998)
            /*HybridCacheEntryFlags?*/ Flags = null;
            //--TRIMMABLE-BOUNDARY-END(30065360998)
            
            //--TRIMMABLE-BOUNDARY-START(4295557222)
            /*DistributedCacheEntryOptions?*/ _dc = null;
            //--TRIMMABLE-BOUNDARY-END(4295557222)
            
            //--TRIMMABLE-BOUNDARY-START(90194903142)
            /*DistributedCacheEntryOptions? */ ToDistributedCacheEntryOptions()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194903142);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Expiration === null ? null : (this._dc ??= (() =>
                    {
                        //new $.$meca.MECD.DistributedCacheEntryOptions()
                        const $t1 = $.$meca.MECD.DistributedCacheEntryOptions;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.AbsoluteExpirationRelativeToNow = $.$clone(this.Expiration);
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903142)
            
            //--TRIMMABLE-BOUNDARY-START(21475426406)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426406)
            
            //--TRIMMABLE-BOUNDARY-START(21475426406)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21475426406)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770393702)
                this.Expiration = null;
                //--TRIMMABLE-BOUNDARY-END(25770393702)
                
                //--TRIMMABLE-BOUNDARY-START(60130132070)
                this.LocalCacheExpiration = null;
                //--TRIMMABLE-BOUNDARY-END(60130132070)
                
            }
            static $h = 589926;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770393702),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655295590,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720066662,
        "f": 83886081
      },
      "n": "Expiration",
      "d": 589926,
      "h": 25770393702,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770393702),
//--TRIMMABLE-BOUNDARY-START(60130132070),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164774,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899935846,
        "f": 83886081
      },
      "n": "LocalCacheExpiration",
      "d": 589926,
      "h": 60130132070,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130132070),
//--TRIMMABLE-BOUNDARY-START(30065360998),
    {
      "p": $.$typeNullable($.$meca.MECH.HybridCacheEntryFlags).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245230182,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310001254,
        "f": 83886081
      },
      "n": "Flags",
      "d": 589926,
      "h": 30065360998,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065360998)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194903142),
    {
      "r": 131174,
      "n": "ToDistributedCacheEntryOptions",
      "d": 589926,
      "h": 90194903142,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194903142)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557222),
    {
      "t": 131174,
      "n": "_dc",
      "d": 589926,
      "h": 4295557222,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557222)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426406),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589926,
      "h": 21475426406,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426406)
  ],
  "h": 589926
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.HybridCacheEntryOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}HybridCacheEntryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589926)
        
        

        //--TRIMMABLE-BOUNDARY-START(131174)
        $asm.$cls(`$meca.MECD.DistributedCacheEntryOptions`, ($self) => class DistributedCacheEntryOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098470)
            /*DateTimeOffset*/ _absoluteExpiration;
            //--TRIMMABLE-BOUNDARY-END(4295098470)
            
            //--TRIMMABLE-BOUNDARY-START(17180000358)
            /*bool*/ _absoluteExpirationSet = false;
            //--TRIMMABLE-BOUNDARY-END(17180000358)
            
            //--TRIMMABLE-BOUNDARY-START(8590065766)
            /*TimeSpan*/ _absoluteExpirationRelativeToNow;
            //--TRIMMABLE-BOUNDARY-END(8590065766)
            
            //--TRIMMABLE-BOUNDARY-START(12885033062)
            /*bool*/ _absoluteExpirationRelativeToNowSet = false;
            //--TRIMMABLE-BOUNDARY-END(12885033062)
            
            //--TRIMMABLE-BOUNDARY-START(25769934950)
            /*TimeSpan*/ _slidingExpiration;
            //--TRIMMABLE-BOUNDARY-END(25769934950)
            
            //--TRIMMABLE-BOUNDARY-START(30064902246)
            /*bool*/ _slidingExpirationSet = false;
            //--TRIMMABLE-BOUNDARY-END(30064902246)
            
            //--TRIMMABLE-BOUNDARY-START(21474967654)
            /*bool*/ _frozen = false;
            //--TRIMMABLE-BOUNDARY-END(21474967654)
            
            //--TRIMMABLE-BOUNDARY-START(38654836838)
            /*DateTimeOffset? */ get AbsoluteExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._absoluteExpirationSet ? this._absoluteExpiration : null;
            }
            /*DateTimeOffset? */ set AbsoluteExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Set($.$$.S.DateTimeOffset, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.DateTimeOffset, () => this._absoluteExpiration, ($v) => this._absoluteExpiration = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._absoluteExpirationSet, ($v) => this._absoluteExpirationSet = $v, null, true), $.$ref(() => $.$clone(value), ));
            }
            //--TRIMMABLE-BOUNDARY-END(38654836838)
            
            //--TRIMMABLE-BOUNDARY-START(42949804134)
            /*TimeSpan? */ get AbsoluteExpirationRelativeToNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._absoluteExpirationRelativeToNowSet ? this._absoluteExpirationRelativeToNow : null;
            }
            /*TimeSpan? */ set AbsoluteExpirationRelativeToNow(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194444390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= $.$$.S.TimeSpan.Zero)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("AbsoluteExpirationRelativeToNow", $.$clone(value), "The relative expiration value must be positive.");
                }
                this.Set($.$$.S.TimeSpan, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeSpan, () => this._absoluteExpirationRelativeToNow, ($v) => this._absoluteExpirationRelativeToNow = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._absoluteExpirationRelativeToNowSet, ($v) => this._absoluteExpirationRelativeToNowSet = $v, null, true), $.$ref(() => $.$clone(value), ));
            }
            //--TRIMMABLE-BOUNDARY-END(42949804134)
            
            //--TRIMMABLE-BOUNDARY-START(107374313574)
            /*TimeSpan? */ get SlidingExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._slidingExpirationSet ? this._slidingExpiration : null;
            }
            /*TimeSpan? */ set SlidingExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784378982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= $.$$.S.TimeSpan.Zero)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("SlidingExpiration", $.$clone(value), "The sliding expiration value must be positive.");
                }
                this.Set($.$$.S.TimeSpan, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.TimeSpan, () => this._slidingExpiration, ($v) => this._slidingExpiration = $v, null, true), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._slidingExpirationSet, ($v) => this._slidingExpirationSet = $v, null, true), $.$ref(() => $.$clone(value), ));
            }
            //--TRIMMABLE-BOUNDARY-END(107374313574)
            
            //--TRIMMABLE-BOUNDARY-START(47244771430)
            /*DistributedCacheEntryOptions */ Freeze()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._frozen = true;
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244771430)
            
            //--TRIMMABLE-BOUNDARY-START(103079346278)
            /*void */ Set(T, /*ref T*/ field, /*ref bool*/ isSet, /*in T?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._frozen)
                {
                    ThrowFrozen();
                }
                field.$v = $.$$.S.Nullable$$(T).GetValueOrDefault.call(value.$v);
                isSet.$v = $.$$.S.Nullable$$(T).HasValue$get.call(value.$v);
                /*static void*/  function ThrowFrozen()
                {
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12("This instance has been frozen and cannot be mutated");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079346278)
            
            //--TRIMMABLE-BOUNDARY-START(34359869542)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869542)
            
            //--TRIMMABLE-BOUNDARY-START(34359869542)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34359869542)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098470)
                this._absoluteExpiration = $.$default($.$$.S.DateTimeOffset);
                //--TRIMMABLE-BOUNDARY-END(4295098470)
                
                //--TRIMMABLE-BOUNDARY-START(8590065766)
                this._absoluteExpirationRelativeToNow = $.$default($.$$.S.TimeSpan);
                //--TRIMMABLE-BOUNDARY-END(8590065766)
                
                //--TRIMMABLE-BOUNDARY-START(25769934950)
                this._slidingExpiration = $.$default($.$$.S.TimeSpan);
                //--TRIMMABLE-BOUNDARY-END(25769934950)
                
            }
            static $h = 131174;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654836838),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706022,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604509798,
        "f": 83886081
      },
      "n": "AbsoluteExpiration",
      "d": 131174,
      "h": 38654836838,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654836838),
//--TRIMMABLE-BOUNDARY-START(42949804134),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424640614,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194444390,
        "f": 83886081
      },
      "n": "AbsoluteExpirationRelativeToNow",
      "d": 131174,
      "h": 42949804134,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949804134),
//--TRIMMABLE-BOUNDARY-START(107374313574),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014575206,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784378982,
        "f": 83886081
      },
      "n": "SlidingExpiration",
      "d": 131174,
      "h": 107374313574,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374313574)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244771430),
    {
      "r": 131174,
      "n": "Freeze",
      "d": 131174,
      "h": 47244771430,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244771430),
//--TRIMMABLE-BOUNDARY-START(103079346278),
    {
      "r": 65537,
      "p": [
        {
          "n": "field",
          "p": (T) => T.$h,
          "f": 4
        },
        {
          "n": "isSet",
          "p": 262145,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => $.$typeNullable(T).$h,
          "f": 8
        }
      ],
      "g": [
        "T"
      ],
      "n": "Set",
      "d": 131174,
      "h": 103079346278,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(103079346278)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098470),
    {
      "t": 66191361,
      "n": "_absoluteExpiration",
      "d": 131174,
      "h": 4295098470,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098470),
//--TRIMMABLE-BOUNDARY-START(17180000358),
    {
      "t": 262145,
      "n": "_absoluteExpirationSet",
      "d": 131174,
      "h": 17180000358,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000358),
//--TRIMMABLE-BOUNDARY-START(8590065766),
    {
      "t": 186646529,
      "n": "_absoluteExpirationRelativeToNow",
      "d": 131174,
      "h": 8590065766,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065766),
//--TRIMMABLE-BOUNDARY-START(12885033062),
    {
      "t": 262145,
      "n": "_absoluteExpirationRelativeToNowSet",
      "d": 131174,
      "h": 12885033062,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033062),
//--TRIMMABLE-BOUNDARY-START(25769934950),
    {
      "t": 186646529,
      "n": "_slidingExpiration",
      "d": 131174,
      "h": 25769934950,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934950),
//--TRIMMABLE-BOUNDARY-START(30064902246),
    {
      "t": 262145,
      "n": "_slidingExpirationSet",
      "d": 131174,
      "h": 30064902246,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902246),
//--TRIMMABLE-BOUNDARY-START(21474967654),
    {
      "t": 262145,
      "n": "_frozen",
      "d": 131174,
      "h": 21474967654,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474967654)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34359869542),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131174,
      "h": 34359869542,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359869542)
  ],
  "h": 131174
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}DistributedCacheEntryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131174)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245286)
        $asm.$cls(`$meca.MECM.MemoryCacheEntryOptions`, ($self) => class MemoryCacheEntryOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296212582)
            /*DateTimeOffset?*/ _absoluteExpiration = null;
            //--TRIMMABLE-BOUNDARY-END(4296212582)
            
            //--TRIMMABLE-BOUNDARY-START(8591179878)
            /*TimeSpan?*/ _absoluteExpirationRelativeToNow = null;
            //--TRIMMABLE-BOUNDARY-END(8591179878)
            
            //--TRIMMABLE-BOUNDARY-START(25771049062)
            /*TimeSpan?*/ _slidingExpiration = null;
            //--TRIMMABLE-BOUNDARY-END(25771049062)
            
            //--TRIMMABLE-BOUNDARY-START(21476081766)
            /*long?*/ _size = null;
            //--TRIMMABLE-BOUNDARY-END(21476081766)
            
            //--TRIMMABLE-BOUNDARY-START(12886147174)
            /*List<IChangeToken>?*/ _expirationTokens = null;
            //--TRIMMABLE-BOUNDARY-END(12886147174)
            
            //--TRIMMABLE-BOUNDARY-START(17181114470)
            /*List<PostEvictionCallbackRegistration>?*/ _postEvictionCallbacks = null;
            //--TRIMMABLE-BOUNDARY-END(17181114470)
            
            //--TRIMMABLE-BOUNDARY-START(38655950950)
            /*DateTimeOffset? */ get AbsoluteExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._absoluteExpiration);
            }
            /*DateTimeOffset? */ set AbsoluteExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325100646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._absoluteExpiration = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(38655950950)
            
            //--TRIMMABLE-BOUNDARY-START(42950918246)
            /*TimeSpan? */ get AbsoluteExpirationRelativeToNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720722022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._absoluteExpirationRelativeToNow);
            }
            /*TimeSpan? */ set AbsoluteExpirationRelativeToNow(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915035238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= $.$$.S.TimeSpan.Zero)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("AbsoluteExpirationRelativeToNow", $.$clone(value), "The relative expiration value must be positive.");
                }
                this._absoluteExpirationRelativeToNow = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(42950918246)
            
            //--TRIMMABLE-BOUNDARY-START(193274773606)
            /*TimeSpan? */ get SlidingExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$clone(this._slidingExpiration);
            }
            /*TimeSpan? */ set SlidingExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684839014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value <= $.$$.S.TimeSpan.Zero)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("SlidingExpiration", $.$clone(value), "The sliding expiration value must be positive.");
                }
                this._slidingExpiration = $.$clone(value);
            }
            //--TRIMMABLE-BOUNDARY-END(193274773606)
            
            //--TRIMMABLE-BOUNDARY-START(47245885542)
            /*IList<IChangeToken> */ get ExpirationTokens()
            {
                return this._expirationTokens ??= (() =>
                {
                    let $t1 = new ($.$$.SCG.List$$($.$mep.MEP.IChangeToken))().$ctor$1();
                    return $t1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(47245885542)
            
            //--TRIMMABLE-BOUNDARY-START(51540852838)
            /*List<IChangeToken>? */ get ExpirationTokensDirect()
            {
                return this._expirationTokens;
            }
            //--TRIMMABLE-BOUNDARY-END(51540852838)
            
            //--TRIMMABLE-BOUNDARY-START(133145231462)
            /*IList<PostEvictionCallbackRegistration> */ get PostEvictionCallbacks()
            {
                return this._postEvictionCallbacks ??= (() =>
                {
                    let $t2 = new ($.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration))().$ctor$1();
                    return $t2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(133145231462)
            
            //--TRIMMABLE-BOUNDARY-START(137440198758)
            /*List<PostEvictionCallbackRegistration>? */ get PostEvictionCallbacksDirect()
            {
                return this._postEvictionCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(137440198758)
            
            //--TRIMMABLE-BOUNDARY-START(141735166054)
            /*CacheItemPriority*/ Priority = 0;
            //--TRIMMABLE-BOUNDARY-END(141735166054)
            
            //--TRIMMABLE-BOUNDARY-START(188979806310)
            /*long? */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            /*long? */ set Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094904422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Int64.op_LessThan(value, 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), `${$.$strNN("value")} must be non-negative.`);
                }
                this._size = value;
            }
            //--TRIMMABLE-BOUNDARY-END(188979806310)
            
            //--TRIMMABLE-BOUNDARY-START(34360983654)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360983654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360983654)
            
            //--TRIMMABLE-BOUNDARY-START(34360983654)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360983654)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296212582)
                this._absoluteExpiration = null;
                //--TRIMMABLE-BOUNDARY-END(4296212582)
                
                //--TRIMMABLE-BOUNDARY-START(8591179878)
                this._absoluteExpirationRelativeToNow = null;
                //--TRIMMABLE-BOUNDARY-END(8591179878)
                
                //--TRIMMABLE-BOUNDARY-START(25771049062)
                this._slidingExpiration = null;
                //--TRIMMABLE-BOUNDARY-END(25771049062)
                
                //--TRIMMABLE-BOUNDARY-START(141735166054)
                this.Priority = 1;
                //--TRIMMABLE-BOUNDARY-END(141735166054)
                
            }
            static $h = 1245286;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655950950),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130787430,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150325100646,
        "f": 83886081
      },
      "n": "AbsoluteExpiration",
      "d": 1245286,
      "h": 38655950950,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655950950),
//--TRIMMABLE-BOUNDARY-START(42950918246),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720722022,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915035238,
        "f": 83886081
      },
      "n": "AbsoluteExpirationRelativeToNow",
      "d": 1245286,
      "h": 42950918246,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950918246),
//--TRIMMABLE-BOUNDARY-START(193274773606),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850264166,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684839014,
        "f": 83886081
      },
      "n": "SlidingExpiration",
      "d": 1245286,
      "h": 193274773606,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274773606),
//--TRIMMABLE-BOUNDARY-START(47245885542),
    {
      "p": $.$$.SCG.IList$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310656614,
        "f": 50331649
      },
      "n": "ExpirationTokens",
      "d": 1245286,
      "h": 47245885542,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245885542),
//--TRIMMABLE-BOUNDARY-START(51540852838),
    {
      "p": $.$$.SCG.List$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900591206,
        "f": 50331656
      },
      "n": "ExpirationTokensDirect",
      "d": 1245286,
      "h": 51540852838,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540852838),
//--TRIMMABLE-BOUNDARY-START(133145231462),
    {
      "p": $.$$.SCG.IList$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490525798,
        "f": 50331649
      },
      "n": "PostEvictionCallbacks",
      "d": 1245286,
      "h": 133145231462,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145231462),
//--TRIMMABLE-BOUNDARY-START(137440198758),
    {
      "p": $.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080460390,
        "f": 50331656
      },
      "n": "PostEvictionCallbacksDirect",
      "d": 1245286,
      "h": 137440198758,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(137440198758),
//--TRIMMABLE-BOUNDARY-START(141735166054),
    {
      "p": 917606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670394982,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504969830,
        "f": 83886081
      },
      "n": "Priority",
      "d": 1245286,
      "h": 141735166054,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141735166054),
//--TRIMMABLE-BOUNDARY-START(188979806310),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260329574,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094904422,
        "f": 83886081
      },
      "n": "Size",
      "d": 1245286,
      "h": 188979806310,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979806310)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212582),
    {
      "t": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "n": "_absoluteExpiration",
      "d": 1245286,
      "h": 4296212582,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212582),
//--TRIMMABLE-BOUNDARY-START(8591179878),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_absoluteExpirationRelativeToNow",
      "d": 1245286,
      "h": 8591179878,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591179878),
//--TRIMMABLE-BOUNDARY-START(25771049062),
    {
      "t": $.$typeNullable($.$$.S.TimeSpan).$h,
      "n": "_slidingExpiration",
      "d": 1245286,
      "h": 25771049062,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771049062),
//--TRIMMABLE-BOUNDARY-START(21476081766),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_size",
      "d": 1245286,
      "h": 21476081766,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476081766),
//--TRIMMABLE-BOUNDARY-START(12886147174),
    {
      "t": $.$$.SCG.List$$($.$mep.MEP.IChangeToken).$h,
      "n": "_expirationTokens",
      "d": 1245286,
      "h": 12886147174,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886147174),
//--TRIMMABLE-BOUNDARY-START(17181114470),
    {
      "t": $.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "n": "_postEvictionCallbacks",
      "d": 1245286,
      "h": 17181114470,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181114470)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360983654),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245286,
      "h": 34360983654,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360983654)
  ],
  "h": 1245286
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCacheEntryOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCacheEntryOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245286)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179750)
        $asm.$cls(`$meca.MECM.MemoryCacheEntryExtensions`, ($self) => class MemoryCacheEntryExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(25770983526)
            static /*MemoryCacheEntryOptions */ SetPriority(/*this MemoryCacheEntryOptions*/ options, /*CacheItemPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.Priority = priority;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983526)
            
            //--TRIMMABLE-BOUNDARY-START(30065950822)
            static /*MemoryCacheEntryOptions */ SetSize(/*this MemoryCacheEntryOptions*/ options, /*long*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (size < 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("size", $.$box(size, $.$$.S.Int64), `${$.$strNN("size")} must be non-negative.`);
                }
                options.Size = size;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(30065950822)
            
            //--TRIMMABLE-BOUNDARY-START(4296147046)
            static /*MemoryCacheEntryOptions */ AddExpirationToken(/*this MemoryCacheEntryOptions*/ options, /*IChangeToken*/ expirationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(expirationToken, "expirationToken");
                options.ExpirationTokens.SCG$ICollection$$$Add(expirationToken);
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(4296147046)
            
            //--TRIMMABLE-BOUNDARY-START(21476016230)
            static /*MemoryCacheEntryOptions */ SetAbsoluteExpiration$1(/*this MemoryCacheEntryOptions*/ options, /*TimeSpan*/ relative)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.AbsoluteExpirationRelativeToNow = relative;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016230)
            
            //--TRIMMABLE-BOUNDARY-START(17181048934)
            static /*MemoryCacheEntryOptions */ SetAbsoluteExpiration(/*this MemoryCacheEntryOptions*/ options, /*DateTimeOffset*/ absolute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.AbsoluteExpiration = absolute;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048934)
            
            //--TRIMMABLE-BOUNDARY-START(34360918118)
            static /*MemoryCacheEntryOptions */ SetSlidingExpiration(/*this MemoryCacheEntryOptions*/ options, /*TimeSpan*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360918118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                options.SlidingExpiration = offset;
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(34360918118)
            
            //--TRIMMABLE-BOUNDARY-START(12886081638)
            static /*MemoryCacheEntryOptions */ RegisterPostEvictionCallback$1(/*this MemoryCacheEntryOptions*/ options, /*PostEvictionDelegate*/ callback)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                return $.$meca.MECM.MemoryCacheEntryExtensions.RegisterPostEvictionCallback(options, callback, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12886081638)
            
            //--TRIMMABLE-BOUNDARY-START(8591114342)
            static /*MemoryCacheEntryOptions */ RegisterPostEvictionCallback(/*this MemoryCacheEntryOptions*/ options, /*PostEvictionDelegate*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591114342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                options.PostEvictionCallbacks.SCG$ICollection$$$Add((() =>
                {
                    //new $.$meca.MECM.PostEvictionCallbackRegistration()
                    const $t1 = $.$meca.MECM.PostEvictionCallbackRegistration;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EvictionCallback = callback;
                    $i1.State = state;
                    return $i1;
                })());
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114342)
            
            static $h = 1179750;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770983526),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "priority",
          "p": 917606
        }
      ],
      "n": "SetPriority",
      "d": 1179750,
      "h": 25770983526,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770983526),
//--TRIMMABLE-BOUNDARY-START(30065950822),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "size",
          "p": 917505
        }
      ],
      "n": "SetSize",
      "d": 1179750,
      "h": 30065950822,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065950822),
//--TRIMMABLE-BOUNDARY-START(4296147046),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "expirationToken",
          "p": 720981
        }
      ],
      "n": "AddExpirationToken",
      "d": 1179750,
      "h": 4296147046,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296147046),
//--TRIMMABLE-BOUNDARY-START(21476016230),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "relative",
          "p": 186646529
        }
      ],
      "n": "SetAbsoluteExpiration",
      "o": "@$1",
      "d": 1179750,
      "h": 21476016230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476016230),
//--TRIMMABLE-BOUNDARY-START(17181048934),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "absolute",
          "p": 66191361
        }
      ],
      "n": "SetAbsoluteExpiration",
      "d": 1179750,
      "h": 17181048934,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181048934),
//--TRIMMABLE-BOUNDARY-START(34360918118),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "offset",
          "p": 186646529
        }
      ],
      "n": "SetSlidingExpiration",
      "d": 1179750,
      "h": 34360918118,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360918118),
//--TRIMMABLE-BOUNDARY-START(12886081638),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "callback",
          "p": 1441894
        }
      ],
      "n": "RegisterPostEvictionCallback",
      "o": "@$1",
      "d": 1179750,
      "h": 12886081638,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886081638),
//--TRIMMABLE-BOUNDARY-START(8591114342),
    {
      "r": 1245286,
      "p": [
        {
          "n": "options",
          "p": 1245286
        },
        {
          "n": "callback",
          "p": 1441894
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterPostEvictionCallback",
      "d": 1179750,
      "h": 8591114342,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591114342)
  ],
  "h": 1179750
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCacheEntryExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCacheEntryExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179750)
        
        

        //--TRIMMABLE-BOUNDARY-START(196710)
        $asm.$cls(`$meca.MECD.DistributedCacheExtensions`, ($self) => class DistributedCacheExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590131302)
            /*DistributedCacheEntryOptions*/ static DefaultOptions = null;
            //--TRIMMABLE-BOUNDARY-END(8590131302)
            
            //--TRIMMABLE-BOUNDARY-START(21475033190)
            static /*void */ Set(/*this IDistributedCache*/ cache, /*string*/ key, /*byte[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                cache.MECD$IDistributedCache$Set(key, value, $.$meca.MECD.DistributedCacheExtensions.DefaultOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033190)
            
            //--TRIMMABLE-BOUNDARY-START(25770000486)
            static /*Task */ SetAsync(/*this IDistributedCache*/ cache, /*string*/ key, /*byte[]*/ value, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return cache.MECD$IDistributedCache$SetAsync(key, value, $.$meca.MECD.DistributedCacheExtensions.DefaultOptions, token);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000486)
            
            //--TRIMMABLE-BOUNDARY-START(34359935078)
            static /*void */ SetString$1(/*this IDistributedCache*/ cache, /*string*/ key, /*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meca.MECD.DistributedCacheExtensions.SetString(cache, key, value, $.$meca.MECD.DistributedCacheExtensions.DefaultOptions);
            }
            //--TRIMMABLE-BOUNDARY-END(34359935078)
            
            //--TRIMMABLE-BOUNDARY-START(30064967782)
            static /*void */ SetString(/*this IDistributedCache*/ cache, /*string*/ key, /*string*/ value, /*DistributedCacheEntryOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                cache.MECD$IDistributedCache$Set(key, $.$$.ST.Encoding.UTF8.GetBytes$8(value), options);
            }
            //--TRIMMABLE-BOUNDARY-END(30064967782)
            
            //--TRIMMABLE-BOUNDARY-START(42949869670)
            static /*Task */ SetStringAsync$1(/*this IDistributedCache*/ cache, /*string*/ key, /*string*/ value, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meca.MECD.DistributedCacheExtensions.SetStringAsync(cache, key, value, $.$meca.MECD.DistributedCacheExtensions.DefaultOptions, token);
            }
            //--TRIMMABLE-BOUNDARY-END(42949869670)
            
            //--TRIMMABLE-BOUNDARY-START(38654902374)
            static /*Task */ SetStringAsync(/*this IDistributedCache*/ cache, /*string*/ key, /*string*/ value, /*DistributedCacheEntryOptions*/ options, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                return cache.MECD$IDistributedCache$SetAsync(key, $.$$.ST.Encoding.UTF8.GetBytes$8(value), options, token);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902374)
            
            //--TRIMMABLE-BOUNDARY-START(12885098598)
            static /*string? */ GetString(/*this IDistributedCache*/ cache, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]?*/ let data = cache.MECD$IDistributedCache$Get(key);
                if (data === null)
                {
                    return null;
                }
                return $.$$.ST.Encoding.UTF8.GetString(data, 0, data.length);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098598)
            
            //--TRIMMABLE-BOUNDARY-START(17180065894)
            static /*Task<string?> *//*async*/  GetStringAsync(/*this IDistributedCache*/ cache, /*string*/ key, /*CancellationToken*/ token)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$($.$$.S.String), $.$$.S.String, async ($asnycContext) => 
                {
                    let $t1, $r1;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065894);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*byte[]?*/ let data = ($t1 = cache.MECD$IDistributedCache$GetAsync(key, token).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t1, { set $v($v) { $r1 = $v; } }) ? $r1 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t1)));
                    if (data === null)
                    {
                        return $.$$.N.AsyncResolver.Result($asnycContext, null);
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$$.ST.Encoding.UTF8.GetString(data, 0, data.length));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(17180065894)
            
            //--TRIMMABLE-BOUNDARY-START(4295164006)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131302)
                    this.DefaultOptions = new $.$meca.MECD.DistributedCacheEntryOptions().$ctor$1().Freeze();
                    //--TRIMMABLE-BOUNDARY-END(8590131302)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295164006)
            
            static $h = 196710;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033190),
    {
      "r": 65537,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Set",
      "d": 196710,
      "h": 21475033190,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475033190),
//--TRIMMABLE-BOUNDARY-START(25770000486),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetAsync",
      "d": 196710,
      "h": 25770000486,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770000486),
//--TRIMMABLE-BOUNDARY-START(34359935078),
    {
      "r": 65537,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetString",
      "o": "@$1",
      "d": 196710,
      "h": 34359935078,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359935078),
//--TRIMMABLE-BOUNDARY-START(30064967782),
    {
      "r": 65537,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 131174
        }
      ],
      "n": "SetString",
      "d": 196710,
      "h": 30064967782,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064967782),
//--TRIMMABLE-BOUNDARY-START(42949869670),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetStringAsync",
      "o": "@$1",
      "d": 196710,
      "h": 42949869670,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949869670),
//--TRIMMABLE-BOUNDARY-START(38654902374),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetStringAsync",
      "d": 196710,
      "h": 38654902374,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654902374),
//--TRIMMABLE-BOUNDARY-START(12885098598),
    {
      "r": 1310721,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetString",
      "d": 196710,
      "h": 12885098598,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885098598),
//--TRIMMABLE-BOUNDARY-START(17180065894),
    {
      "r": $.$$.STT.Task$$($.$$.S.String).$h,
      "p": [
        {
          "n": "cache",
          "p": 327782
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetStringAsync",
      "d": 196710,
      "h": 17180065894,
      "f": 16781345
    },
//--TRIMMABLE-BOUNDARY-END(17180065894)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590131302),
    {
      "t": 131174,
      "n": "DefaultOptions",
      "d": 196710,
      "h": 8590131302,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590131302)
  ],
  "h": 196710
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.DistributedCacheExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}DistributedCacheExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196710)
        
        

        //--TRIMMABLE-BOUNDARY-START(852070)
        $asm.$cls(`$meca.MECM.CacheExtensions`, ($self) => class CacheExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295819366)
            static /*object? */ Get(/*this IMemoryCache*/ cache, /*object*/ key)
            {
                /*object?*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cache.MECM$IMemoryCache$TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object));
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819366)
            
            //--TRIMMABLE-BOUNDARY-START(8590786662)
            static /*TItem? */ Get$1(TItem, /*this IMemoryCache*/ cache, /*object*/ key)
            {
                /*object?*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786662);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                cache.MECM$IMemoryCache$TryGetValue(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object));
                return value === null ? $.$default(TItem) : $.$cast(value, TItem);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786662)
            
            //--TRIMMABLE-BOUNDARY-START(51540459622)
            static /*bool */ TryGetValue(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*out TItem?*/ value)
            {
                /*object?*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (cache.MECM$IMemoryCache$TryGetValue(key, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object)))
                {
                    if (result === null)
                    {
                        value.$v = $.$default(TItem);
                        return true;
                    }
                    let item;
                    if ($.$is(result, TItem, { set $v($v){ item = $v; } }))
                    {
                        value.$v = item;
                        return true;
                    }
                }
                value.$v = $.$default(TItem);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540459622)
            
            //--TRIMMABLE-BOUNDARY-START(47245492326)
            static /*TItem */ Set$4(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*TItem*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492326);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                entry.MECM$ICacheEntry$Value = $.$box(value, TItem);
                entry.S$IDisposable$Dispose();
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245492326)
            
            //--TRIMMABLE-BOUNDARY-START(38655557734)
            static /*TItem */ Set$2(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*TItem*/ value, /*DateTimeOffset*/ absoluteExpiration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                try
                {
                    entry.MECM$ICacheEntry$AbsoluteExpiration = absoluteExpiration;
                    entry.MECM$ICacheEntry$Value = $.$box(value, TItem);
                    return value;
                }
                finally
                {
                    entry?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557734)
            
            //--TRIMMABLE-BOUNDARY-START(42950525030)
            static /*TItem */ Set$3(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*TItem*/ value, /*TimeSpan*/ absoluteExpirationRelativeToNow)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                try
                {
                    entry.MECM$ICacheEntry$AbsoluteExpirationRelativeToNow = absoluteExpirationRelativeToNow;
                    entry.MECM$ICacheEntry$Value = $.$box(value, TItem);
                    return value;
                }
                finally
                {
                    entry?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950525030)
            
            //--TRIMMABLE-BOUNDARY-START(34360590438)
            static /*TItem */ Set$1(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*TItem*/ value, /*IChangeToken*/ expirationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                try
                {
                    $.$meca.MECM.CacheEntryExtensions.AddExpirationToken(entry, expirationToken);
                    entry.MECM$ICacheEntry$Value = $.$box(value, TItem);
                    return value;
                }
                finally
                {
                    entry?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360590438)
            
            //--TRIMMABLE-BOUNDARY-START(30065623142)
            static /*TItem */ Set(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*TItem*/ value, /*MemoryCacheEntryOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                try
                {
                    if (options !== null)
                    {
                        $.$meca.MECM.CacheEntryExtensions.SetOptions(entry, options);
                    }
                    entry.MECM$ICacheEntry$Value = $.$box(value, TItem);
                    return value;
                }
                finally
                {
                    entry?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065623142)
            
            //--TRIMMABLE-BOUNDARY-START(17180721254)
            static /*TItem? */ GetOrCreate$1(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*Func<ICacheEntry, TItem>*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721254);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meca.MECM.CacheExtensions.GetOrCreate(TItem, cache, key, factory, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721254)
            
            //--TRIMMABLE-BOUNDARY-START(12885753958)
            static /*TItem? */ GetOrCreate(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*Func<ICacheEntry, TItem>*/ factory, /*MemoryCacheEntryOptions?*/ createOptions)
            {
                /*object?*/ let result;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753958);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!cache.MECM$IMemoryCache$TryGetValue(key, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object)))
                {
                    /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                    try
                    {
                        if (createOptions !== null)
                        {
                            $.$meca.MECM.CacheEntryExtensions.SetOptions(entry, createOptions);
                        }
                        result = $.$box(factory.Invoke(entry), TItem);
                        entry.MECM$ICacheEntry$Value = result;
                    }
                    finally
                    {
                        entry?.S$IDisposable$Dispose();
                    }
                }
                return $.$cast(result, TItem);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753958)
            
            //--TRIMMABLE-BOUNDARY-START(25770655846)
            static /*Task<TItem?> */ GetOrCreateAsync$1(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*Func<ICacheEntry, Task<TItem>>*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meca.MECM.CacheExtensions.GetOrCreateAsync(TItem, cache, key, factory, null);
            }
            //--TRIMMABLE-BOUNDARY-END(25770655846)
            
            //--TRIMMABLE-BOUNDARY-START(21475688550)
            static /*Task<TItem?> *//*async*/  GetOrCreateAsync(TItem, /*this IMemoryCache*/ cache, /*object*/ key, /*Func<ICacheEntry, Task<TItem>>*/ factory, /*MemoryCacheEntryOptions?*/ createOptions)
            {
                return $.$$.N.AsyncResolver.Async($.$$.STT.Task$$(TItem), TItem, async ($asnycContext) => 
                {
                    /*object?*/ let result;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688550);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!cache.MECM$IMemoryCache$TryGetValue(key, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object)))
                    {
                        /*ICacheEntry*/ let entry = cache.MECM$IMemoryCache$CreateEntry(key);
                        try
                        {
                            let $t6, $r6;
                            if (createOptions !== null)
                            {
                                $.$meca.MECM.CacheEntryExtensions.SetOptions(entry, createOptions);
                            }
                            result = $.$box(($t6 = factory.Invoke(entry).ConfigureAwait$2(false), ($.$$.N.AsyncResolver.IsCompleted($t6, { set $v($v) { $r6 = $v; } }) ? $r6 : await $.$$.N.AsyncResolver.Awaiting($asnycContext, $t6))), TItem);
                            entry.MECM$ICacheEntry$Value = result;
                        }
                        finally
                        {
                            entry?.S$IDisposable$Dispose();
                        }
                    }
                    return $.$$.N.AsyncResolver.Result($asnycContext, $.$cast(result, TItem));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(21475688550)
            
            static $h = 852070;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819366),
    {
      "r": 131073,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Get",
      "d": 852070,
      "h": 4295819366,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295819366),
//--TRIMMABLE-BOUNDARY-START(8590786662),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Get",
      "o": "@$1",
      "d": 852070,
      "h": 8590786662,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590786662),
//--TRIMMABLE-BOUNDARY-START(51540459622),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h,
          "f": 2
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "TryGetValue",
      "d": 852070,
      "h": 51540459622,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(51540459622),
//--TRIMMABLE-BOUNDARY-START(47245492326),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Set",
      "o": "@$4",
      "d": 852070,
      "h": 47245492326,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47245492326),
//--TRIMMABLE-BOUNDARY-START(38655557734),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h
        },
        {
          "n": "absoluteExpiration",
          "p": 66191361
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Set",
      "o": "@$2",
      "d": 852070,
      "h": 38655557734,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38655557734),
//--TRIMMABLE-BOUNDARY-START(42950525030),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h
        },
        {
          "n": "absoluteExpirationRelativeToNow",
          "p": 186646529
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Set",
      "o": "@$3",
      "d": 852070,
      "h": 42950525030,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42950525030),
//--TRIMMABLE-BOUNDARY-START(34360590438),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h
        },
        {
          "n": "expirationToken",
          "p": 720981
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Set",
      "o": "@$1",
      "d": 852070,
      "h": 34360590438,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34360590438),
//--TRIMMABLE-BOUNDARY-START(30065623142),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h
        },
        {
          "n": "options",
          "p": 1245286
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "Set",
      "d": 852070,
      "h": 30065623142,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30065623142),
//--TRIMMABLE-BOUNDARY-START(17180721254),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "factory",
          "p": (TItem) => $.$$.S.Func$$$($.$meca.MECM.ICacheEntry, TItem).$h
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "GetOrCreate",
      "o": "@$1",
      "d": 852070,
      "h": 17180721254,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180721254),
//--TRIMMABLE-BOUNDARY-START(12885753958),
    {
      "r": (TItem) => TItem.$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "factory",
          "p": (TItem) => $.$$.S.Func$$$($.$meca.MECM.ICacheEntry, TItem).$h
        },
        {
          "n": "createOptions",
          "p": 1245286
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "GetOrCreate",
      "d": 852070,
      "h": 12885753958,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885753958),
//--TRIMMABLE-BOUNDARY-START(25770655846),
    {
      "r": (TItem) => $.$$.STT.Task$$(TItem).$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "factory",
          "p": (TItem) => $.$$.S.Func$$$($.$meca.MECM.ICacheEntry, $.$$.STT.Task$$(TItem)).$h
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "GetOrCreateAsync",
      "o": "@$1",
      "d": 852070,
      "h": 25770655846,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770655846),
//--TRIMMABLE-BOUNDARY-START(21475688550),
    {
      "r": (TItem) => $.$$.STT.Task$$(TItem).$h,
      "p": [
        {
          "n": "cache",
          "p": 1114214
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "factory",
          "p": (TItem) => $.$$.S.Func$$$($.$meca.MECM.ICacheEntry, $.$$.STT.Task$$(TItem)).$h
        },
        {
          "n": "createOptions",
          "p": 1245286
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "GetOrCreateAsync",
      "d": 852070,
      "h": 21475688550,
      "f": 16912417
    },
//--TRIMMABLE-BOUNDARY-END(21475688550)
  ],
  "h": 852070
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.CacheExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}CacheExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852070)
        
        

        //--TRIMMABLE-BOUNDARY-START(786534)
        $asm.$cls(`$meca.MECM.CacheEntryExtensions`, ($self) => class CacheEntryExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(30065557606)
            static /*ICacheEntry */ SetPriority(/*this ICacheEntry*/ entry, /*CacheItemPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                entry.MECM$ICacheEntry$Priority = priority;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557606)
            
            //--TRIMMABLE-BOUNDARY-START(4295753830)
            static /*ICacheEntry */ AddExpirationToken(/*this ICacheEntry*/ entry, /*IChangeToken*/ expirationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(expirationToken, "expirationToken");
                entry.MECM$ICacheEntry$ExpirationTokens.SCG$ICollection$$$Add(expirationToken);
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753830)
            
            //--TRIMMABLE-BOUNDARY-START(21475623014)
            static /*ICacheEntry */ SetAbsoluteExpiration$1(/*this ICacheEntry*/ entry, /*TimeSpan*/ relative)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                entry.MECM$ICacheEntry$AbsoluteExpirationRelativeToNow = relative;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623014)
            
            //--TRIMMABLE-BOUNDARY-START(17180655718)
            static /*ICacheEntry */ SetAbsoluteExpiration(/*this ICacheEntry*/ entry, /*DateTimeOffset*/ absolute)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                entry.MECM$ICacheEntry$AbsoluteExpiration = absolute;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655718)
            
            //--TRIMMABLE-BOUNDARY-START(38655492198)
            static /*ICacheEntry */ SetSlidingExpiration(/*this ICacheEntry*/ entry, /*TimeSpan*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                entry.MECM$ICacheEntry$SlidingExpiration = offset;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492198)
            
            //--TRIMMABLE-BOUNDARY-START(12885688422)
            static /*ICacheEntry */ RegisterPostEvictionCallback$1(/*this ICacheEntry*/ entry, /*PostEvictionDelegate*/ callback)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688422);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meca.MECM.CacheEntryExtensions.RegisterPostEvictionCallback(entry, callback, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885688422)
            
            //--TRIMMABLE-BOUNDARY-START(8590721126)
            static /*ICacheEntry */ RegisterPostEvictionCallback(/*this ICacheEntry*/ entry, /*PostEvictionDelegate*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                entry.MECM$ICacheEntry$PostEvictionCallbacks.SCG$ICollection$$$Add((() =>
                {
                    //new $.$meca.MECM.PostEvictionCallbackRegistration()
                    const $t1 = $.$meca.MECM.PostEvictionCallbackRegistration;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.EvictionCallback = callback;
                    $i1.State = state;
                    return $i1;
                })());
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721126)
            
            //--TRIMMABLE-BOUNDARY-START(42950459494)
            static /*ICacheEntry */ SetValue(/*this ICacheEntry*/ entry, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950459494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                entry.MECM$ICacheEntry$Value = value;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(42950459494)
            
            //--TRIMMABLE-BOUNDARY-START(34360524902)
            static /*ICacheEntry */ SetSize(/*this ICacheEntry*/ entry, /*long*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (size < 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("size", $.$box(size, $.$$.S.Int64), `${$.$strNN("size")} must be non-negative.`);
                }
                entry.MECM$ICacheEntry$Size = size;
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524902)
            
            //--TRIMMABLE-BOUNDARY-START(25770590310)
            static /*ICacheEntry */ SetOptions(/*this ICacheEntry*/ entry, /*MemoryCacheEntryOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(options, "options");
                entry.MECM$ICacheEntry$AbsoluteExpiration = options.AbsoluteExpiration;
                entry.MECM$ICacheEntry$AbsoluteExpirationRelativeToNow = options.AbsoluteExpirationRelativeToNow;
                entry.MECM$ICacheEntry$SlidingExpiration = options.SlidingExpiration;
                entry.MECM$ICacheEntry$Priority = options.Priority;
                entry.MECM$ICacheEntry$Size = options.Size;
                let expirationTokens;
                if (options.ExpirationTokensDirect !== null && ((expirationTokens = options.ExpirationTokensDirect, expirationTokens != null && true)))
                {
                    let $en2 = expirationTokens.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let expirationToken = $en2.Current;
                        {
                            $.$meca.MECM.CacheEntryExtensions.AddExpirationToken(entry, expirationToken);
                        }
                    }
                }
                let postEvictionCallbacks;
                if (options.PostEvictionCallbacksDirect !== null && ((postEvictionCallbacks = options.PostEvictionCallbacksDirect, postEvictionCallbacks != null && true)))
                {
                    for(/*int*/ let i = 0; i < postEvictionCallbacks.Count; i++)
                    {
                        /*PostEvictionCallbackRegistration*/ let postEvictionCallback = postEvictionCallbacks.get_Item(i);
                        if (postEvictionCallback.EvictionCallback === null)
                        {
                            $.$meca.MECM.CacheEntryExtensions.ThrowNullCallback(i, "options");
                        }
                        entry.MECM$ICacheEntry$PostEvictionCallbacks.SCG$ICollection$$$Add(postEvictionCallback);
                    }
                }
                return entry;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590310)
            
            //--TRIMMABLE-BOUNDARY-START(47245426790)
            static /*void */ ThrowNullCallback(/*int*/ index, /*string*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let message = `MemoryCacheEntryOptions.PostEvictionCallbacks contains a PostEvictionCallbackRegistration with a null EvictionCallback at index ${$.$strNN(index)}.`;
                throw new $.$$.S.ArgumentException().$ctor$13(message, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(47245426790)
            
            static $h = 786534;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065557606),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "priority",
          "p": 917606
        }
      ],
      "n": "SetPriority",
      "d": 786534,
      "h": 30065557606,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557606),
//--TRIMMABLE-BOUNDARY-START(4295753830),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "expirationToken",
          "p": 720981
        }
      ],
      "n": "AddExpirationToken",
      "d": 786534,
      "h": 4295753830,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295753830),
//--TRIMMABLE-BOUNDARY-START(21475623014),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "relative",
          "p": 186646529
        }
      ],
      "n": "SetAbsoluteExpiration",
      "o": "@$1",
      "d": 786534,
      "h": 21475623014,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475623014),
//--TRIMMABLE-BOUNDARY-START(17180655718),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "absolute",
          "p": 66191361
        }
      ],
      "n": "SetAbsoluteExpiration",
      "d": 786534,
      "h": 17180655718,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180655718),
//--TRIMMABLE-BOUNDARY-START(38655492198),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "offset",
          "p": 186646529
        }
      ],
      "n": "SetSlidingExpiration",
      "d": 786534,
      "h": 38655492198,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655492198),
//--TRIMMABLE-BOUNDARY-START(12885688422),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "callback",
          "p": 1441894
        }
      ],
      "n": "RegisterPostEvictionCallback",
      "o": "@$1",
      "d": 786534,
      "h": 12885688422,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885688422),
//--TRIMMABLE-BOUNDARY-START(8590721126),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "callback",
          "p": 1441894
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterPostEvictionCallback",
      "d": 786534,
      "h": 8590721126,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590721126),
//--TRIMMABLE-BOUNDARY-START(42950459494),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 786534,
      "h": 42950459494,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950459494),
//--TRIMMABLE-BOUNDARY-START(34360524902),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "size",
          "p": 917505
        }
      ],
      "n": "SetSize",
      "d": 786534,
      "h": 34360524902,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360524902),
//--TRIMMABLE-BOUNDARY-START(25770590310),
    {
      "r": 1048678,
      "p": [
        {
          "n": "entry",
          "p": 1048678
        },
        {
          "n": "options",
          "p": 1245286
        }
      ],
      "n": "SetOptions",
      "d": 786534,
      "h": 25770590310,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770590310),
//--TRIMMABLE-BOUNDARY-START(47245426790),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "paramName",
          "p": 1310721
        }
      ],
      "n": "ThrowNullCallback",
      "d": 786534,
      "h": 47245426790,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245426790)
  ],
  "h": 786534
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.CacheEntryExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}CacheEntryExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786534)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572966)
        $asm.$cls(`$meca.MEI.SystemClock`, ($self) => class SystemClock extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181442150)
            /*DateTimeOffset */ get UtcNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.DateTimeOffset.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442150)
            
            //--TRIMMABLE-BOUNDARY-START(8591442022)
            //Generated interface implemetation for Microsoft.Extensions.Internal.ISystemClock.UtcNow.get
            get MEI$ISystemClock$UtcNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442022)
            
            //--TRIMMABLE-BOUNDARY-START(4296540262)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540262)
            
            //--TRIMMABLE-BOUNDARY-START(4296540262)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540262)
            
            static $h = 1572966;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181442150),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886474854,
        "f": 50331649
      },
      "n": "UtcNow",
      "d": 1572966,
      "h": 17181442150,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181442150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540262),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572966,
      "h": 4296540262,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540262)
  ],
  "h": 1572966
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.MEI.ISystemClock ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.SystemClock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}SystemClock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572966)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441894)
        $asm.$cls(`$meca.MECM.PostEvictionDelegate`, ($self) => class PostEvictionDelegate extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Object*/ key, /*$.$$.S.Nullable$$*/ value, /**/ reason, /*$.$$.S.Nullable$$*/ state)
            {
                return this.$nativeFunction.call(this.$target, key, value, reason, state);
            }
            static $h = 1441894;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181311078),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "reason",
          "p": 983142
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Invoke",
      "d": 1441894,
      "h": 17181311078,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181311078),
//--TRIMMABLE-BOUNDARY-START(8591376486),
    {
      "r": 90570753,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "reason",
          "p": 983142
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1441894,
      "h": 8591376486,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591376486),
//--TRIMMABLE-BOUNDARY-START(12886343782),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1441894,
      "h": 12886343782,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886343782)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409190),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1441894,
      "h": 4296409190,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409190)
  ],
  "h": 1441894
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.PostEvictionDelegate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}PostEvictionDelegate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441894)
        
        

        //--TRIMMABLE-BOUNDARY-START(983142)
        $asm.$str(`$meca.MECM.EvictionReason`, ($self) => class EvictionReason extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Removed = 1;
            static Replaced = 2;
            static Expired = 3;
            static TokenExpired = 4;
            static Capacity = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Removed": 1n,
                    "Replaced": 2n,
                    "Expired": 3n,
                    "TokenExpired": 4n,
                    "Capacity": 5n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295950438)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950438)
            
            //--TRIMMABLE-BOUNDARY-START(4295950438)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950438)
            
            static $h = 983142;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180852326),
    {
      "t": 983142,
      "n": "None",
      "d": 983142,
      "h": 17180852326,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180852326),
//--TRIMMABLE-BOUNDARY-START(21475819622),
    {
      "t": 983142,
      "n": "Removed",
      "d": 983142,
      "h": 21475819622,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475819622),
//--TRIMMABLE-BOUNDARY-START(25770786918),
    {
      "t": 983142,
      "n": "Replaced",
      "d": 983142,
      "h": 25770786918,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770786918),
//--TRIMMABLE-BOUNDARY-START(12885885030),
    {
      "t": 983142,
      "n": "Expired",
      "d": 983142,
      "h": 12885885030,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885885030),
//--TRIMMABLE-BOUNDARY-START(30065754214),
    {
      "t": 983142,
      "n": "TokenExpired",
      "d": 983142,
      "h": 30065754214,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065754214),
//--TRIMMABLE-BOUNDARY-START(8590917734),
    {
      "t": 983142,
      "n": "Capacity",
      "d": 983142,
      "h": 8590917734,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590917734)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950438),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983142,
      "h": 4295950438,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950438)
  ],
  "h": 983142
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.EvictionReason`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}EvictionReason`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983142)
        
        

        //--TRIMMABLE-BOUNDARY-START(524390)
        $asm.$str(`$meca.MECH.HybridCacheEntryFlags`, ($self) => class HybridCacheEntryFlags extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static DisableLocalCacheRead = 1;
            static DisableLocalCacheWrite = 2;
            static DisableLocalCache = 3;
            static DisableDistributedCacheRead = 4;
            static DisableDistributedCacheWrite = 8;
            static DisableDistributedCache = 12;
            static DisableUnderlyingData = 16;
            static DisableCompression = 32;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "DisableLocalCacheRead": 1n,
                    "DisableLocalCacheWrite": 2n,
                    "DisableLocalCache": 3n,
                    "DisableDistributedCacheRead": 4n,
                    "DisableDistributedCacheWrite": 8n,
                    "DisableDistributedCache": 12n,
                    "DisableUnderlyingData": 16n,
                    "DisableCompression": 32n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491686)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491686)
            
            //--TRIMMABLE-BOUNDARY-START(4295491686)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491686)
            
            static $h = 524390;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950197350),
    {
      "t": 524390,
      "n": "None",
      "d": 524390,
      "h": 42950197350,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197350),
//--TRIMMABLE-BOUNDARY-START(30065295462),
    {
      "t": 524390,
      "n": "DisableLocalCacheRead",
      "d": 524390,
      "h": 30065295462,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295462),
//--TRIMMABLE-BOUNDARY-START(34360262758),
    {
      "t": 524390,
      "n": "DisableLocalCacheWrite",
      "d": 524390,
      "h": 34360262758,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262758),
//--TRIMMABLE-BOUNDARY-START(25770328166),
    {
      "t": 524390,
      "n": "DisableLocalCache",
      "d": 524390,
      "h": 25770328166,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328166),
//--TRIMMABLE-BOUNDARY-START(17180393574),
    {
      "t": 524390,
      "n": "DisableDistributedCacheRead",
      "d": 524390,
      "h": 17180393574,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393574),
//--TRIMMABLE-BOUNDARY-START(21475360870),
    {
      "t": 524390,
      "n": "DisableDistributedCacheWrite",
      "d": 524390,
      "h": 21475360870,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360870),
//--TRIMMABLE-BOUNDARY-START(12885426278),
    {
      "t": 524390,
      "n": "DisableDistributedCache",
      "d": 524390,
      "h": 12885426278,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426278),
//--TRIMMABLE-BOUNDARY-START(38655230054),
    {
      "t": 524390,
      "n": "DisableUnderlyingData",
      "d": 524390,
      "h": 38655230054,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230054),
//--TRIMMABLE-BOUNDARY-START(8590458982),
    {
      "t": 524390,
      "n": "DisableCompression",
      "d": 524390,
      "h": 8590458982,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458982)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491686),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524390,
      "h": 4295491686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491686)
  ],
  "h": 524390,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Hybrid.HybridCacheEntryFlags`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Hybrid${separator}HybridCacheEntryFlags`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524390)
        
        

        //--TRIMMABLE-BOUNDARY-START(917606)
        $asm.$str(`$meca.MECM.CacheItemPriority`, ($self) => class CacheItemPriority extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Low = 0;
            static Normal = 1;
            static High = 2;
            static NeverRemove = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Low": 0n,
                    "Normal": 1n,
                    "High": 2n,
                    "NeverRemove": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295884902)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884902)
            
            //--TRIMMABLE-BOUNDARY-START(4295884902)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295884902)
            
            static $h = 917606;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819494),
    {
      "t": 917606,
      "n": "Low",
      "d": 917606,
      "h": 12885819494,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819494),
//--TRIMMABLE-BOUNDARY-START(21475754086),
    {
      "t": 917606,
      "n": "Normal",
      "d": 917606,
      "h": 21475754086,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754086),
//--TRIMMABLE-BOUNDARY-START(8590852198),
    {
      "t": 917606,
      "n": "High",
      "d": 917606,
      "h": 8590852198,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852198),
//--TRIMMABLE-BOUNDARY-START(17180786790),
    {
      "t": 917606,
      "n": "NeverRemove",
      "d": 917606,
      "h": 17180786790,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786790)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884902),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917606,
      "h": 4295884902,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884902)
  ],
  "h": 917606
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.CacheItemPriority`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}CacheItemPriority`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917606)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq"));
})();
//--TRIMMABLE-BOUNDARY-END(102)
