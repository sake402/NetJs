
//--TRIMMABLE-BOUNDARY-START(103)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $meca, $scm, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $sttp, $sdd, $mexla, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    let $wRaapc;
    let $bHAQSe;
    let $tYUNZf;
    let $WYFdSg;
    let $jMquIa;
    let $pwdQvk;
    let $qgsoCh;
    let $WhVnta;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Caching.Memory", 
    {
  "h": 103,
  "f": "Microsoft.Extensions.Caching.Memory",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Caching.Memory.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Caching.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Caching.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(655463)
        $asm.$cls(`$mecm.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103079870567)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(103079870567)
            
            //--TRIMMABLE-BOUNDARY-START(94489935975)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(94489935975)
            
            //--TRIMMABLE-BOUNDARY-START(98784903271)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mecm.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Caching.Memory", $.$mecm.S.SR.$type.Assembly);
                    $.$mecm.S.SR.s_resourceManager = temp;
                }
                return $.$mecm.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(98784903271)
            
            //--TRIMMABLE-BOUNDARY-START(12885557351)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecm.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964772455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecm.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557351)
            
            //--TRIMMABLE-BOUNDARY-START(8590590055)
            static /*string */ get CacheEntryHasEmptySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130197607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cache entry must specify a value for {0} when {1} is set.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590590055)
            
            //--TRIMMABLE-BOUNDARY-START(51540263015)
            static /*string */ FormatCacheEntryHasEmptySize(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540263015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Cache entry must specify a value for {0} when {1} is set.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(51540263015)
            
            //--TRIMMABLE-BOUNDARY-START(107374837863)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(107374837863)
            
            //--TRIMMABLE-BOUNDARY-START(90194968679)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194968679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194968679)
            
            //--TRIMMABLE-BOUNDARY-START(120259739751)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259739751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecm.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259739751)
            
            //--TRIMMABLE-BOUNDARY-START(85900001383)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900001383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecm.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85900001383)
            
            //--TRIMMABLE-BOUNDARY-START(81605034087)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605034087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecm.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81605034087)
            
            //--TRIMMABLE-BOUNDARY-START(42950328423)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328423)
            
            //--TRIMMABLE-BOUNDARY-START(38655361127)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655361127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655361127)
            
            //--TRIMMABLE-BOUNDARY-START(34360393831)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360393831)
            
            //--TRIMMABLE-BOUNDARY-START(47245295719)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245295719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecm.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245295719)
            
            //--TRIMMABLE-BOUNDARY-START(25770459239)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770459239)
            
            //--TRIMMABLE-BOUNDARY-START(21475491943)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475491943)
            
            //--TRIMMABLE-BOUNDARY-START(17180524647)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524647)
            
            //--TRIMMABLE-BOUNDARY-START(30065426535)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecm.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065426535)
            
            //--TRIMMABLE-BOUNDARY-START(4295622759)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(107374837863)
                    this.s_usingResourceKeys = $.$mecm.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(107374837863)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295622759)
            
            static $h = 655463;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 655463
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655463)
        
        

        //--TRIMMABLE-BOUNDARY-START(589927)
        $asm.$cls(`$mecm.MED.MemoryCacheServiceCollectionExtensions`, ($self) => class MemoryCacheServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17180459111)
            static /*IServiceCollection */ AddMemoryCache$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$meca.MECM.IMemoryCache, $.$mecm.MECM.MemoryCache));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459111)
            
            //--TRIMMABLE-BOUNDARY-START(12885491815)
            static /*IServiceCollection */ AddMemoryCache(/*this IServiceCollection*/ services, /*Action<MemoryCacheOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(setupAction, "setupAction");
                $.$mecm.MED.MemoryCacheServiceCollectionExtensions.AddMemoryCache$1(services);
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mecm.MECM.MemoryCacheOptions, services, setupAction);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491815)
            
            //--TRIMMABLE-BOUNDARY-START(8590524519)
            static /*IServiceCollection */ AddDistributedMemoryCache$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$meca.MECD.IDistributedCache, $.$mecm.MECD.MemoryDistributedCache));
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524519)
            
            //--TRIMMABLE-BOUNDARY-START(4295557223)
            static /*IServiceCollection */ AddDistributedMemoryCache(/*this IServiceCollection*/ services, /*Action<MemoryDistributedCacheOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(setupAction, "setupAction");
                $.$mecm.MED.MemoryCacheServiceCollectionExtensions.AddDistributedMemoryCache$1(services);
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mecm.MECM.MemoryDistributedCacheOptions, services, setupAction);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557223)
            
            static $h = 589927;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459111),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddMemoryCache",
      "o": "@$1",
      "d": 589927,
      "h": 17180459111,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180459111),
//--TRIMMABLE-BOUNDARY-START(12885491815),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.S.Action$$($.$mecm.MECM.MemoryCacheOptions).$h
        }
      ],
      "n": "AddMemoryCache",
      "d": 589927,
      "h": 12885491815,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885491815),
//--TRIMMABLE-BOUNDARY-START(8590524519),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddDistributedMemoryCache",
      "o": "@$1",
      "d": 589927,
      "h": 8590524519,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590524519),
//--TRIMMABLE-BOUNDARY-START(4295557223),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.S.Action$$($.$mecm.MECM.MemoryDistributedCacheOptions).$h
        }
      ],
      "n": "AddDistributedMemoryCache",
      "d": 589927,
      "h": 4295557223,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295557223)
  ],
  "h": 589927
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.MemoryCacheServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}MemoryCacheServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589927)
        
        

        //--TRIMMABLE-BOUNDARY-START(65639)
        $asm.$cls(`$mecm.MECD.MemoryDistributedCache`, ($self) => class MemoryDistributedCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032935)
            /*MemoryCache*/ _memCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295032935)
            
            //--TRIMMABLE-BOUNDARY-START(12884967527)
            $ctor$2(/*IOptions<MemoryDistributedCacheOptions>*/ optionsAccessor)
            {
                this.$ctor$1(optionsAccessor, $.$mexla.MELA.NullLoggerFactory.Instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967527);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967527)
            
            //--TRIMMABLE-BOUNDARY-START(8590000231)
            $ctor$1(/*IOptions<MemoryDistributedCacheOptions>*/ optionsAccessor, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsAccessor, "optionsAccessor");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(loggerFactory, "loggerFactory");
                    this._memCache = new $.$mecm.MECM.MemoryCache().$ctor$1(optionsAccessor.MEO$IOptions$Microsoft$Extensions$Caching$Memory$MemoryDistributedCacheOptions$Value, loggerFactory);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000231)
            
            //--TRIMMABLE-BOUNDARY-START(17179934823)
            /*byte[]? */ Get(/*string*/ key)
            {
                /*object?*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this._memCache.TryGetValue$1($.$$.S.String.op_Implicit(key), $.$ref(() => value, ($v) => value = $v, $.$$.S.Object));
                return $.$cast(value, $.$typeArray($.$$.S.Byte));
            }
            //--TRIMMABLE-BOUNDARY-END(17179934823)
            
            //--TRIMMABLE-BOUNDARY-START(21474902119)
            /*Task<byte[]?> */ GetAsync(/*string*/ key, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                return $.$$.STT.Task.FromResult($.$typeArray($.$$.S.Byte), this.Get(key));
            }
            //--TRIMMABLE-BOUNDARY-END(21474902119)
            
            //--TRIMMABLE-BOUNDARY-START(42949738599)
            /*void */ Set(/*string*/ key, /*byte[]*/ value, /*DistributedCacheEntryOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(options, "options");
                /*ICacheEntry*/ let entry = this._memCache.CreateEntry(key);
                try
                {
                    entry.MECM$ICacheEntry$AbsoluteExpiration = options.AbsoluteExpiration;
                    entry.MECM$ICacheEntry$AbsoluteExpirationRelativeToNow = options.AbsoluteExpirationRelativeToNow;
                    entry.MECM$ICacheEntry$SlidingExpiration = options.SlidingExpiration;
                    entry.MECM$ICacheEntry$Size = value.length;
                    entry.MECM$ICacheEntry$Value = value;
                }
                finally
                {
                    entry?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949738599)
            
            //--TRIMMABLE-BOUNDARY-START(47244705895)
            /*Task */ SetAsync(/*string*/ key, /*byte[]*/ value, /*DistributedCacheEntryOptions*/ options, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(options, "options");
                this.Set(key, value, options);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705895)
            
            //--TRIMMABLE-BOUNDARY-START(25769869415)
            /*void */ Refresh(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this._memCache.TryGetValue$1($.$$.S.String.op_Implicit(key), $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(25769869415)
            
            //--TRIMMABLE-BOUNDARY-START(30064836711)
            /*Task */ RefreshAsync(/*string*/ key, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.Refresh(key);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836711)
            
            //--TRIMMABLE-BOUNDARY-START(34359804007)
            /*void */ Remove(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359804007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this._memCache.Remove(key);
            }
            //--TRIMMABLE-BOUNDARY-END(34359804007)
            
            //--TRIMMABLE-BOUNDARY-START(38654771303)
            /*Task */ RemoveAsync(/*string*/ key, /*CancellationToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.Remove(key);
                return $.$$.STT.Task.CompletedTask;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771303)
            
            //--TRIMMABLE-BOUNDARY-START(4295295078)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.Get(string)
            MECD$IDistributedCache$Get()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Get(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295078)
            
            //--TRIMMABLE-BOUNDARY-START(8590262374)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.GetAsync(string, System.Threading.CancellationToken)
            MECD$IDistributedCache$GetAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262374)
            
            //--TRIMMABLE-BOUNDARY-START(30065098854)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.Set(string, byte[], Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryOptions)
            MECD$IDistributedCache$Set()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Set(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065098854)
            
            //--TRIMMABLE-BOUNDARY-START(34360066150)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.SetAsync(string, byte[], Microsoft.Extensions.Caching.Distributed.DistributedCacheEntryOptions, System.Threading.CancellationToken)
            MECD$IDistributedCache$SetAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066150)
            
            //--TRIMMABLE-BOUNDARY-START(12885229670)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.Refresh(string)
            MECD$IDistributedCache$Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Refresh(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229670)
            
            //--TRIMMABLE-BOUNDARY-START(17180196966)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.RefreshAsync(string, System.Threading.CancellationToken)
            MECD$IDistributedCache$RefreshAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RefreshAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180196966)
            
            //--TRIMMABLE-BOUNDARY-START(21475164262)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.Remove(string)
            MECD$IDistributedCache$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475164262)
            
            //--TRIMMABLE-BOUNDARY-START(25770131558)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Distributed.IDistributedCache.RemoveAsync(string, System.Threading.CancellationToken)
            MECD$IDistributedCache$RemoveAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25770131558)
            
            static $h = 65639;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934823),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Get",
      "d": 65639,
      "h": 17179934823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934823),
//--TRIMMABLE-BOUNDARY-START(21474902119),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$$.S.Byte)).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetAsync",
      "d": 65639,
      "h": 21474902119,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902119),
//--TRIMMABLE-BOUNDARY-START(42949738599),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        }
      ],
      "n": "Set",
      "d": 65639,
      "h": 42949738599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949738599),
//--TRIMMABLE-BOUNDARY-START(47244705895),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "options",
          "p": 131174
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "SetAsync",
      "d": 65639,
      "h": 47244705895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705895),
//--TRIMMABLE-BOUNDARY-START(25769869415),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Refresh",
      "d": 65639,
      "h": 25769869415,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869415),
//--TRIMMABLE-BOUNDARY-START(30064836711),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RefreshAsync",
      "d": 65639,
      "h": 30064836711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064836711),
//--TRIMMABLE-BOUNDARY-START(34359804007),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "d": 65639,
      "h": 34359804007,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359804007),
//--TRIMMABLE-BOUNDARY-START(38654771303),
    {
      "r": 178454529,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "token",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "RemoveAsync",
      "d": 65639,
      "h": 38654771303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771303)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032935),
    {
      "t": 262247,
      "n": "_memCache",
      "d": 65639,
      "h": 4295032935,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032935)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967527),
    {
      "p": [
        {
          "n": "optionsAccessor",
          "p": $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryDistributedCacheOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65639,
      "h": 12884967527,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967527),
//--TRIMMABLE-BOUNDARY-START(8590000231),
    {
      "p": [
        {
          "n": "optionsAccessor",
          "p": $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryDistributedCacheOptions).$h
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65639,
      "h": 8590000231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000231)
  ],
  "h": 65639
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.MECD.IDistributedCache ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Distributed.MemoryDistributedCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Distributed${separator}MemoryDistributedCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65639)
        
        

        //--TRIMMABLE-BOUNDARY-START(458855)
        $asm.$cls(`$mecm.MECM.MemoryCacheOptions`, ($self) => class MemoryCacheOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590393447)
            /*long*/ _sizeLimit = -1n;
            //--TRIMMABLE-BOUNDARY-END(8590393447)
            
            //--TRIMMABLE-BOUNDARY-START(4295426151)
            /*double*/ _compactionPercentage = 0.05;
            //--TRIMMABLE-BOUNDARY-END(4295426151)
            
            //--TRIMMABLE-BOUNDARY-START(150324314215)
            /*int*/ static NotSet = -1;
            //--TRIMMABLE-BOUNDARY-END(150324314215)
            
            //--TRIMMABLE-BOUNDARY-START(38655164519)
            /*ISystemClock?*/ Clock = null;
            //--TRIMMABLE-BOUNDARY-END(38655164519)
            
            //--TRIMMABLE-BOUNDARY-START(51540066407)
            /*TimeSpan*/ ExpirationScanFrequency;
            //--TRIMMABLE-BOUNDARY-END(51540066407)
            
            //--TRIMMABLE-BOUNDARY-START(133144445031)
            /*bool */ get HasSizeLimit()
            {
                return this._sizeLimit >= 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(133144445031)
            
            //--TRIMMABLE-BOUNDARY-START(219043790951)
            /*long */ get SizeLimitValue()
            {
                return this._sizeLimit;
            }
            //--TRIMMABLE-BOUNDARY-END(219043790951)
            
            //--TRIMMABLE-BOUNDARY-START(214748823655)
            /*long? */ get SizeLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._sizeLimit < 0n ? null : this._sizeLimit;
            }
            /*long? */ set SizeLimit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273987175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Int64.op_LessThan(value, 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), `${$.$strNN("value")} must be non-negative.`);
                }
                this._sizeLimit = value ?? BigInt(-1/*NotSet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(214748823655)
            
            //--TRIMMABLE-BOUNDARY-START(47245099111)
            /*bool*/ CompactOnMemoryPressure = false;
            //--TRIMMABLE-BOUNDARY-END(47245099111)
            
            //--TRIMMABLE-BOUNDARY-START(42950131815)
            /*double */ get CompactionPercentage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._compactionPercentage;
            }
            /*double */ set CompactionPercentage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504183399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((value < 0) || (value > 1))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Double), `${$.$strNN("value")} must be between 0 and 1 inclusive.`);
                }
                this._compactionPercentage = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950131815)
            
            //--TRIMMABLE-BOUNDARY-START(223338758247)
            /*bool*/ TrackLinkedCacheEntries = false;
            //--TRIMMABLE-BOUNDARY-END(223338758247)
            
            //--TRIMMABLE-BOUNDARY-START(227633725543)
            /*bool*/ TrackStatistics = false;
            //--TRIMMABLE-BOUNDARY-END(227633725543)
            
            //--TRIMMABLE-BOUNDARY-START(146029346919)
            /*MemoryCacheOptions */ get MEO$IOptions$Microsoft$Extensions$Caching$Memory$MemoryCacheOptions$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(146029346919)
            
            //--TRIMMABLE-BOUNDARY-START(34360197223)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197223)
            
            //--TRIMMABLE-BOUNDARY-START(34360197223)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360197223)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(51540066407)
                this.ExpirationScanFrequency = $.$$.S.TimeSpan.FromMinutes$2(1n);
                //--TRIMMABLE-BOUNDARY-END(51540066407)
                
            }
            static $h = 458855;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655164519),
    {
      "p": 1507430,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130000999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914248807,
        "f": 83886081
      },
      "n": "Clock",
      "d": 458855,
      "h": 38655164519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655164519),
//--TRIMMABLE-BOUNDARY-START(51540066407),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899804775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684052583,
        "f": 83886081
      },
      "n": "ExpirationScanFrequency",
      "d": 458855,
      "h": 51540066407,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540066407),
//--TRIMMABLE-BOUNDARY-START(133144445031),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489739367,
        "f": 50331656
      },
      "n": "HasSizeLimit",
      "d": 458855,
      "h": 133144445031,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(133144445031),
//--TRIMMABLE-BOUNDARY-START(219043790951),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669608551,
        "f": 50331656
      },
      "n": "SizeLimitValue",
      "d": 458855,
      "h": 219043790951,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(219043790951),
//--TRIMMABLE-BOUNDARY-START(214748823655),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079673959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273987175,
        "f": 83886081
      },
      "n": "SizeLimit",
      "d": 458855,
      "h": 214748823655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748823655),
//--TRIMMABLE-BOUNDARY-START(47245099111),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094117991,
        "f": 83886081
      },
      "n": "CompactOnMemoryPressure",
      "d": 458855,
      "h": 47245099111,
      "f": 2097153,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This property is retained only for compatibility.  Remove use and instead call MemoryCache.Compact as needed.",
              "t": 1310721
            },
            {
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245099111),
//--TRIMMABLE-BOUNDARY-START(42950131815),
    {
      "p": 1179649,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504183399,
        "f": 83886081
      },
      "n": "CompactionPercentage",
      "d": 458855,
      "h": 42950131815,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950131815),
//--TRIMMABLE-BOUNDARY-START(223338758247),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543143,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201863921767,
        "f": 83886081
      },
      "n": "TrackLinkedCacheEntries",
      "d": 458855,
      "h": 223338758247,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(223338758247),
//--TRIMMABLE-BOUNDARY-START(227633725543),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477735,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210453856359,
        "f": 83886081
      },
      "n": "TrackStatistics",
      "d": 458855,
      "h": 227633725543,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(227633725543),
//--TRIMMABLE-BOUNDARY-START(146029346919),
    {
      "p": 458855,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734379623,
        "f": 50331650
      },
      "n": "{$.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryCacheOptions).$h}.Value",
      "o": "MEO$IOptions$Microsoft$Extensions$Caching$Memory$MemoryCacheOptions$Value",
      "d": 458855,
      "h": 146029346919,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(146029346919)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393447),
    {
      "t": 917505,
      "n": "_sizeLimit",
      "d": 458855,
      "h": 8590393447,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393447),
//--TRIMMABLE-BOUNDARY-START(4295426151),
    {
      "t": 1179649,
      "n": "_compactionPercentage",
      "d": 458855,
      "h": 4295426151,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426151),
//--TRIMMABLE-BOUNDARY-START(150324314215),
    {
      "t": 655361,
      "n": "NotSet",
      "d": 458855,
      "h": 150324314215,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150324314215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360197223),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458855,
      "h": 34360197223,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197223)
  ],
  "h": 458855
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryCacheOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCacheOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCacheOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458855)
        
        

        //--TRIMMABLE-BOUNDARY-START(131175)
        $asm.$cls(`$mecm.MECM.CacheEntry`, ($self) => class CacheEntry extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(196711)
            static $_CacheEntryTokens;
            static get CacheEntryTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mecm.MECM.CacheEntry;
                return $cls.$_CacheEntryTokens ??= $asm.$ncls(`$mecm.MECM.CacheEntry.CacheEntryTokens`, ($self) => class CacheEntryTokens extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590131303)
                    /*List<IChangeToken>?*/ _expirationTokens = null;
                    //--TRIMMABLE-BOUNDARY-END(8590131303)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295164007)
                    /*List<IDisposable>?*/ _expirationTokenRegistrations = null;
                    //--TRIMMABLE-BOUNDARY-END(4295164007)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098599)
                    /*List<PostEvictionCallbackRegistration>?*/ _postEvictionCallbacks = null;
                    //--TRIMMABLE-BOUNDARY-END(12885098599)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654902375)
                    /*List<IChangeToken> */ get ExpirationTokens()
                    {
                        return this._expirationTokens ??= new ($.$$.SCG.List$$($.$mep.MEP.IChangeToken))().$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654902375)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719673447)
                    /*List<PostEvictionCallbackRegistration> */ get PostEvictionCallbacks()
                    {
                        return this._postEvictionCallbacks ??= new ($.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration))().$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719673447)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033191)
                    /*void */ AttachTokens(/*CacheEntry*/ cacheEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033191);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*List<IChangeToken>?*/ let expirationTokens = this._expirationTokens;
                        if (!(expirationTokens === null))
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    for(/*int*/ let i = 0; i < expirationTokens.Count; i++)
                                    {
                                        /*IChangeToken*/ let expirationToken = expirationTokens.get_Item(i);
                                        if (expirationToken.MEP$IChangeToken$ActiveChangeCallbacks)
                                        {
                                            this._expirationTokenRegistrations ??= new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$3(1);
                                            /*IDisposable*/ let registration = expirationToken.MEP$IChangeToken$RegisterChangeCallback($.$mecm.MECM.CacheEntry.ExpirationCallback, cacheEntry);
                                            this._expirationTokenRegistrations.Add(registration);
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033191)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064967783)
                    /*bool */ CheckForExpiredTokens(/*CacheEntry*/ cacheEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30064967783);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*List<IChangeToken>?*/ let expirationTokens = this._expirationTokens;
                        if (!(expirationTokens === null))
                        {
                            for(/*int*/ let i = 0; i < expirationTokens.Count; i++)
                            {
                                /*IChangeToken*/ let expiredToken = expirationTokens.get_Item(i);
                                if (expiredToken.MEP$IChangeToken$HasChanged)
                                {
                                    cacheEntry.SetExpired(4/*EvictionReason.TokenExpired*/);
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30064967783)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000487)
                    /*bool */ CanPropagateTokens()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770000487);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._expirationTokens !== null;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000487)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014640743)
                    /*void */ PropagateTokens(/*CacheEntry*/ parentEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640743);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._expirationTokens !== null)
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    /*CacheEntryTokens*/ let parentTokens = parentEntry.GetOrCreateTokens();
                                    //lock(parentTokens)
                                    try
                                    {
                                        $.$$.ST$1.Monitor.Enter$1(parentTokens)
                                        {
                                            parentTokens.ExpirationTokens.AddRange(this._expirationTokens);
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.ST$1.Monitor.Exit(parentTokens)
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014640743)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935079)
                    /*void */ DetachTokens()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359935079);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._expirationTokens !== null)
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    /*List<IDisposable>?*/ let registrations = this._expirationTokenRegistrations;
                                    if (registrations !== null)
                                    {
                                        this._expirationTokenRegistrations = null;
                                        for(/*int*/ let i = 0; i < registrations.Count; i++)
                                        {
                                            /*IDisposable*/ let registration = registrations.get_Item(i);
                                            registration.S$IDisposable$Dispose();
                                        }
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935079)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424706151)
                    /*void */ InvokeEvictionCallbacks(/*CacheEntry*/ cacheEntry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706151);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._postEvictionCallbacks !== null)
                        {
                            $.$$.STT.Task.Factory.StartNew$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                            {
                                return $.$mecm.MECM.CacheEntry.CacheEntryTokens.InvokeCallbacks($.$cast(state, $.$mecm.MECM.CacheEntry));
                            }, $wRaapc ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":196711,"h":0,"f":17825794}), cacheEntry, $.$$.ST$1.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.STT.TaskScheduler.Default);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424706151)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738855)
                    static /*void */ InvokeCallbacks(/*CacheEntry*/ entry)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60129738855);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(entry._tokens !== null, "entry._tokens != null");
                        /*List<PostEvictionCallbackRegistration>?*/ let callbackRegistrations = $.$$.ST$1.Interlocked.Exchange$14($.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration), $.$ref(() => entry._tokens._postEvictionCallbacks, ($v) => entry._tokens._postEvictionCallbacks = $v, $.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration)), null);
                        if (callbackRegistrations === null)
                        {
                            return;
                        }
                        for(/*int*/ let i = 0; i < callbackRegistrations.Count; i++)
                        {
                            /*PostEvictionCallbackRegistration*/ let registration = callbackRegistrations.get_Item(i);
                            try
                            {
                                registration.EvictionCallback?.Invoke(entry.Key, entry.Value, entry.EvictionReason, registration.State);
                            }
                            catch(e)
                            {
                                $.$mexla.MEL.LoggerExtensions.LogError$2(entry._cache._logger, e, "EvictionCallback invoked failed", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738855)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065895)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180065895);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065895)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065895)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065895)
                    
                    static $h = 196711;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38654902375),
    {
      "p": $.$$.SCG.List$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836967,
        "f": 50331656
      },
      "n": "ExpirationTokens",
      "d": 196711,
      "h": 38654902375,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(38654902375),
//--TRIMMABLE-BOUNDARY-START(68719673447),
    {
      "p": $.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834771559,
        "f": 50331656
      },
      "n": "PostEvictionCallbacks",
      "d": 196711,
      "h": 68719673447,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68719673447)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033191),
    {
      "r": 65537,
      "p": [
        {
          "n": "cacheEntry",
          "p": 131175
        }
      ],
      "n": "AttachTokens",
      "d": 196711,
      "h": 21475033191,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475033191),
//--TRIMMABLE-BOUNDARY-START(30064967783),
    {
      "r": 262145,
      "p": [
        {
          "n": "cacheEntry",
          "p": 131175
        }
      ],
      "n": "CheckForExpiredTokens",
      "d": 196711,
      "h": 30064967783,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30064967783),
//--TRIMMABLE-BOUNDARY-START(25770000487),
    {
      "r": 262145,
      "n": "CanPropagateTokens",
      "d": 196711,
      "h": 25770000487,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770000487),
//--TRIMMABLE-BOUNDARY-START(73014640743),
    {
      "r": 65537,
      "p": [
        {
          "n": "parentEntry",
          "p": 131175
        }
      ],
      "n": "PropagateTokens",
      "d": 196711,
      "h": 73014640743,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014640743),
//--TRIMMABLE-BOUNDARY-START(34359935079),
    {
      "r": 65537,
      "n": "DetachTokens",
      "d": 196711,
      "h": 34359935079,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34359935079),
//--TRIMMABLE-BOUNDARY-START(64424706151),
    {
      "r": 65537,
      "p": [
        {
          "n": "cacheEntry",
          "p": 131175
        }
      ],
      "n": "InvokeEvictionCallbacks",
      "d": 196711,
      "h": 64424706151,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64424706151),
//--TRIMMABLE-BOUNDARY-START(60129738855),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 131175
        }
      ],
      "n": "InvokeCallbacks",
      "d": 196711,
      "h": 60129738855,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129738855)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590131303),
    {
      "t": $.$$.SCG.List$$($.$mep.MEP.IChangeToken).$h,
      "n": "_expirationTokens",
      "d": 196711,
      "h": 8590131303,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131303),
//--TRIMMABLE-BOUNDARY-START(4295164007),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_expirationTokenRegistrations",
      "d": 196711,
      "h": 4295164007,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295164007),
//--TRIMMABLE-BOUNDARY-START(12885098599),
    {
      "t": $.$$.SCG.List$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "n": "_postEvictionCallbacks",
      "d": 196711,
      "h": 12885098599,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885098599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065895),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196711,
      "h": 17180065895,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065895)
  ],
  "d": 131175,
  "h": 196711
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.CacheEntry+CacheEntryTokens`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}CacheEntry${separator}CacheEntryTokens`; }
                }, $cls, ($v) => $cls.$_CacheEntryTokens = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196711)
            
            //--TRIMMABLE-BOUNDARY-START(124554182759)
            /*Action<object>*/ static ExpirationCallback = null;
            //--TRIMMABLE-BOUNDARY-END(124554182759)
            
            //--TRIMMABLE-BOUNDARY-START(21474967655)
            /*AsyncLocal<CacheEntry?>*/ static _current = null;
            //--TRIMMABLE-BOUNDARY-END(21474967655)
            
            //--TRIMMABLE-BOUNDARY-START(17180000359)
            /*MemoryCache*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(17180000359)
            
            //--TRIMMABLE-BOUNDARY-START(60129673319)
            /*CacheEntryTokens?*/ _tokens = null;
            //--TRIMMABLE-BOUNDARY-END(60129673319)
            
            //--TRIMMABLE-BOUNDARY-START(8590065767)
            /*TimeSpan*/ _absoluteExpirationRelativeToNow;
            //--TRIMMABLE-BOUNDARY-END(8590065767)
            
            //--TRIMMABLE-BOUNDARY-START(55834706023)
            /*TimeSpan*/ _slidingExpiration;
            //--TRIMMABLE-BOUNDARY-END(55834706023)
            
            //--TRIMMABLE-BOUNDARY-START(51539738727)
            /*long*/ _size = -1n;
            //--TRIMMABLE-BOUNDARY-END(51539738727)
            
            //--TRIMMABLE-BOUNDARY-START(42949804135)
            /*CacheEntry?*/ _previous = null;
            //--TRIMMABLE-BOUNDARY-END(42949804135)
            
            //--TRIMMABLE-BOUNDARY-START(64424640615)
            /*object?*/ _value = null;
            //--TRIMMABLE-BOUNDARY-END(64424640615)
            
            //--TRIMMABLE-BOUNDARY-START(12885033063)
            /*long*/ _absoluteExpirationTicks = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885033063)
            
            //--TRIMMABLE-BOUNDARY-START(4295098471)
            /*short*/ _absoluteExpirationOffsetMinutes = 0;
            //--TRIMMABLE-BOUNDARY-END(4295098471)
            
            //--TRIMMABLE-BOUNDARY-START(30064902247)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(30064902247)
            
            //--TRIMMABLE-BOUNDARY-START(34359869543)
            /*bool*/ _isExpired = false;
            //--TRIMMABLE-BOUNDARY-END(34359869543)
            
            //--TRIMMABLE-BOUNDARY-START(38654836839)
            /*bool*/ _isValueSet = false;
            //--TRIMMABLE-BOUNDARY-END(38654836839)
            
            //--TRIMMABLE-BOUNDARY-START(25769934951)
            /*byte*/ _evictionReason = 0;
            //--TRIMMABLE-BOUNDARY-END(25769934951)
            
            //--TRIMMABLE-BOUNDARY-START(47244771431)
            /*byte*/ _priority = 1;
            //--TRIMMABLE-BOUNDARY-END(47244771431)
            
            //--TRIMMABLE-BOUNDARY-START(322122678375)
            /*int*/ static NotSet = -1;
            //--TRIMMABLE-BOUNDARY-END(322122678375)
            
            //--TRIMMABLE-BOUNDARY-START(81604509799)
            $ctor$1(/*object*/ key, /*MemoryCache*/ memoryCache)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604509799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(memoryCache, "memoryCache");
                    this.Key = key;
                    this._cache = memoryCache;
                    if (memoryCache.TrackLinkedCacheEntries)
                    {
                        /*AsyncLocal<CacheEntry?>*/ let holder = $.$mecm.MECM.CacheEntry._current;
                        this._previous = holder.Value;
                        holder.Value = this;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509799)
            
            //--TRIMMABLE-BOUNDARY-START(111669280871)
            static /*CacheEntry? */ get Current()
            {
                return $.$mecm.MECM.CacheEntry._current.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(111669280871)
            
            //--TRIMMABLE-BOUNDARY-START(90194444391)
            /*long */ get AbsoluteExpirationTicks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323986535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._absoluteExpirationTicks;
            }
            /*long */ set AbsoluteExpirationTicks(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597514855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._absoluteExpirationTicks = value;
                this._absoluteExpirationOffsetMinutes = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(90194444391)
            
            //--TRIMMABLE-BOUNDARY-START(257698168935)
            /*DateTimeOffset? */ get MECM$ICacheEntry$AbsoluteExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583070823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._absoluteExpirationTicks < 0n)
                {
                    return null;
                }
                /*var*/ let offset = new $.$$.S.TimeSpan().$ctor$7(BigInt.asIntN(64, BigInt(this._absoluteExpirationOffsetMinutes) * 600000000n));
                return new $.$$.S.DateTimeOffset().$ctor$12(BigInt.asIntN(64, this._absoluteExpirationTicks + offset.Ticks), offset);
            }
            /*DateTimeOffset? */ set MECM$ICacheEntry$AbsoluteExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352874599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    this._absoluteExpirationTicks = BigInt(-1/*NotSet*/);
                    this._absoluteExpirationOffsetMinutes = 0;
                }
                else 
                {
                    /*DateTimeOffset*/ let expiration = $.$$.S.Nullable$$($.$$.S.DateTimeOffset).GetValueOrDefault.call(value);
                    this._absoluteExpirationTicks = expiration.UtcTicks;
                    this._absoluteExpirationOffsetMinutes = ((expiration.TotalOffsetMinutes & 0xFFFF) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698168935)
            
            //--TRIMMABLE-BOUNDARY-START(85899477095)
            /*TimeSpan */ get AbsoluteExpirationRelativeToNow()
            {
                return this._absoluteExpirationRelativeToNow;
            }
            //--TRIMMABLE-BOUNDARY-END(85899477095)
            
            //--TRIMMABLE-BOUNDARY-START(261993136231)
            /*TimeSpan? */ get MECM$ICacheEntry$AbsoluteExpirationRelativeToNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173005415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._absoluteExpirationRelativeToNow.Ticks === 0n ? null : this._absoluteExpirationRelativeToNow;
            }
            /*TimeSpan? */ set MECM$ICacheEntry$AbsoluteExpirationRelativeToNow(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942809191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Ticks <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("AbsoluteExpirationRelativeToNow", $.$clone(value), "The relative expiration value must be positive.");
                }
                this._absoluteExpirationRelativeToNow = $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(value);
            }
            //--TRIMMABLE-BOUNDARY-END(261993136231)
            
            //--TRIMMABLE-BOUNDARY-START(399432089703)
            /*TimeSpan? */ get SlidingExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633397863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._slidingExpiration.Ticks === 0n ? null : this._slidingExpiration;
            }
            /*TimeSpan? */ set SlidingExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957253223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value.Ticks <= 0n)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("SlidingExpiration", $.$clone(value), "The sliding expiration value must be positive.");
                }
                this._slidingExpiration = $.$$.S.Nullable$$($.$$.S.TimeSpan).GetValueOrDefault.call(value);
            }
            //--TRIMMABLE-BOUNDARY-END(399432089703)
            
            //--TRIMMABLE-BOUNDARY-START(128849150055)
            /*IList<IChangeToken> */ get ExpirationTokens()
            {
                return this.GetOrCreateTokens().ExpirationTokens;
            }
            //--TRIMMABLE-BOUNDARY-END(128849150055)
            
            //--TRIMMABLE-BOUNDARY-START(326417645671)
            /*IList<PostEvictionCallbackRegistration> */ get PostEvictionCallbacks()
            {
                return this.GetOrCreateTokens().PostEvictionCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(326417645671)
            
            //--TRIMMABLE-BOUNDARY-START(330712612967)
            /*CacheItemPriority */ get Priority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453528679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this._priority, $.$meca.MECM.CacheItemPriority);
            }
            /*CacheItemPriority */ set Priority(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367318631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._priority = $.$cast(value, $.$$.S.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(330712612967)
            
            //--TRIMMABLE-BOUNDARY-START(395137122407)
            /*long */ get Size()
            {
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(395137122407)
            
            //--TRIMMABLE-BOUNDARY-START(317827711079)
            /*long? */ get MECM$ICacheEntry$Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287762940007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size < 0n ? null : this._size;
            }
            /*long? */ set MECM$ICacheEntry$Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532743783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Int64.op_LessThan(value, 0))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.S.Int64), `${$.$strNN("value")} must be non-negative.`);
                }
                this._size = value ?? BigInt(-1/*NotSet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(317827711079)
            
            //--TRIMMABLE-BOUNDARY-START(249108234343)
            /*object*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(249108234343)
            
            //--TRIMMABLE-BOUNDARY-START(403727056999)
            /*object? */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223332455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._value;
            }
            /*object? */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547187815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._value = value;
                this._isValueSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(403727056999)
            
            //--TRIMMABLE-BOUNDARY-START(253403201639)
            /*DateTime*/ LastAccessed;
            //--TRIMMABLE-BOUNDARY-END(253403201639)
            
            //--TRIMMABLE-BOUNDARY-START(120259215463)
            /*EvictionReason */ get EvictionReason()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503855719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this._evictionReason, $.$meca.MECM.EvictionReason);
            }
            /*EvictionReason */ set EvictionReason(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187449447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._evictionReason = $.$cast(value, $.$$.S.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(120259215463)
            
            //--TRIMMABLE-BOUNDARY-START(115964248167)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964248167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isDisposed)
                {
                    this._isDisposed = true;
                    if (this._cache.TrackLinkedCacheEntries)
                    {
                        this.CommitWithTracking();
                    }
                    else if (this._isValueSet)
                    {
                        this._cache.SetEntry(this);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964248167)
            
            //--TRIMMABLE-BOUNDARY-START(107374313575)
            /*void */ CommitWithTracking()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374313575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$mecm.MECM.CacheEntry._current.Value === this, "Entries disposed in invalid order");
                $.$mecm.MECM.CacheEntry._current.Value = this._previous;
                if (this._isValueSet)
                {
                    this._cache.SetEntry(this);
                    /*CacheEntry?*/ let parent = this._previous;
                    if (parent !== null)
                    {
                        if ($.$cast(this._absoluteExpirationTicks, $.$$.S.UInt64) < $.$cast(parent._absoluteExpirationTicks, $.$$.S.UInt64))
                        {
                            parent._absoluteExpirationTicks = this._absoluteExpirationTicks;
                            parent._absoluteExpirationOffsetMinutes = this._absoluteExpirationOffsetMinutes;
                        }
                        this._tokens?.PropagateTokens(parent);
                    }
                }
                this._previous = null;
            }
            //--TRIMMABLE-BOUNDARY-END(107374313575)
            
            //--TRIMMABLE-BOUNDARY-START(98784378983)
            /*bool */ CheckExpired(/*DateTime*/ utcNow)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784378983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._isExpired || this.CheckForExpiredTime(utcNow) || (this._tokens !== null && this._tokens.CheckForExpiredTokens(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784378983)
            
            //--TRIMMABLE-BOUNDARY-START(390842155111)
            /*void */ SetExpired(/*EvictionReason*/ reason)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842155111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.EvictionReason === 0/*EvictionReason.None*/)
                {
                    this.EvictionReason = reason;
                }
                this._isExpired = true;
                this._tokens?.DetachTokens();
            }
            //--TRIMMABLE-BOUNDARY-END(390842155111)
            
            //--TRIMMABLE-BOUNDARY-START(103079346279)
            /*bool */ CheckForExpiredTime(/*DateTime*/ utcNow)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079346279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._absoluteExpirationTicks < 0n && this._slidingExpiration.Ticks === 0n)
                {
                    return false;
                }
                return FullCheck.call(this, utcNow);
                /*bool*/  function FullCheck(/*DateTime*/ utcNow)
                {
                    if ($.$cast(this._absoluteExpirationTicks, $.$$.S.UInt64) <= $.$cast(utcNow.Ticks, $.$$.S.UInt64))
                    {
                        this.SetExpired(3/*EvictionReason.Expired*/);
                        return true;
                    }
                    if (this._slidingExpiration.Ticks > 0n && $.$$.S.TimeSpan.op_GreaterThanOrEqual(($.$$.S.DateTime.op_Subtraction$1(utcNow, this.LastAccessed)), this._slidingExpiration))
                    {
                        this.SetExpired(3/*EvictionReason.Expired*/);
                        return true;
                    }
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079346279)
            
            //--TRIMMABLE-BOUNDARY-START(94489411687)
            /*void */ AttachTokens()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489411687);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._tokens?.AttachTokens(this) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489411687)
            
            //--TRIMMABLE-BOUNDARY-START(133144117351)
            static /*void */ ExpirationTokensExpired(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144117351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.STT.Task.Factory.StartNew$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                {
                    /*var*/ let entry = $.$cast(state, $.$mecm.MECM.CacheEntry);
                    entry.SetExpired(4/*EvictionReason.TokenExpired*/);
                    entry._cache.EntryExpired(entry);
                }, $bHAQSe ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":131175,"h":0,"f":17825794}), obj, $.$$.ST$1.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.STT.TaskScheduler.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(133144117351)
            
            //--TRIMMABLE-BOUNDARY-START(244813267047)
            /*void */ InvokeEvictionCallbacks()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813267047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._tokens?.InvokeEvictionCallbacks(this) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813267047)
            
            //--TRIMMABLE-BOUNDARY-START(335007580263)
            /*void */ PropagateOptionsToCurrent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007580263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let parent;
                if ((this._tokens === null || !this._tokens.CanPropagateTokens()) && this._absoluteExpirationTicks < 0n || !$.$is($.$mecm.MECM.CacheEntry._current.Value, $.$mecm.MECM.CacheEntry, { set $v($v){ parent = $v; } }))
                {
                    return;
                }
                if ($.$cast(this._absoluteExpirationTicks, $.$$.S.UInt64) < $.$cast(parent._absoluteExpirationTicks, $.$$.S.UInt64))
                {
                    parent._absoluteExpirationTicks = this._absoluteExpirationTicks;
                    parent._absoluteExpirationOffsetMinutes = this._absoluteExpirationOffsetMinutes;
                }
                this._tokens?.PropagateTokens(parent);
            }
            //--TRIMMABLE-BOUNDARY-END(335007580263)
            
            //--TRIMMABLE-BOUNDARY-START(240518299751)
            /*CacheEntryTokens */ GetOrCreateTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518299751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._tokens !== null)
                {
                    return this._tokens;
                }
                /*CacheEntryTokens*/ let result = new $.$mecm.MECM.CacheEntry.CacheEntryTokens().$ctor$1();
                return $.$$.ST$1.Interlocked.CompareExchange$14($.$mecm.MECM.CacheEntry.CacheEntryTokens, $.$ref(() => this._tokens, ($v) => this._tokens = $v, $.$mecm.MECM.CacheEntry.CacheEntryTokens), result, null) ?? result;
            }
            //--TRIMMABLE-BOUNDARY-END(240518299751)
            
            //--TRIMMABLE-BOUNDARY-START(47245688934)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.Key.get
            get MECM$ICacheEntry$Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490329190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Key;
            }
            //--TRIMMABLE-BOUNDARY-END(47245688934)
            
            //--TRIMMABLE-BOUNDARY-START(90195361894)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.Value.get
            get MECM$ICacheEntry$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504773222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(90195361894)
            
            //--TRIMMABLE-BOUNDARY-START(154619871334)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.Value.set
            set MECM$ICacheEntry$Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504773222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(154619871334)
            
            //--TRIMMABLE-BOUNDARY-START(81605427302)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.SlidingExpiration.get
            get MECM$ICacheEntry$SlidingExpiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209805926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SlidingExpiration;
            }
            //--TRIMMABLE-BOUNDARY-END(81605427302)
            
            //--TRIMMABLE-BOUNDARY-START(146029936742)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.SlidingExpiration.set
            set MECM$ICacheEntry$SlidingExpiration(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209805926);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SlidingExpiration = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146029936742)
            
            //--TRIMMABLE-BOUNDARY-START(38655754342)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.ExpirationTokens.get
            get MECM$ICacheEntry$ExpirationTokens()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ExpirationTokens;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754342)
            
            //--TRIMMABLE-BOUNDARY-START(55835623526)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.PostEvictionCallbacks.get
            get MECM$ICacheEntry$PostEvictionCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PostEvictionCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(55835623526)
            
            //--TRIMMABLE-BOUNDARY-START(64425558118)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.Priority.get
            get MECM$ICacheEntry$Priority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080263782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Priority;
            }
            //--TRIMMABLE-BOUNDARY-END(64425558118)
            
            //--TRIMMABLE-BOUNDARY-START(128850067558)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.ICacheEntry.Priority.set
            set MECM$ICacheEntry$Priority(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080263782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Priority = value;
            }
            //--TRIMMABLE-BOUNDARY-END(128850067558)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590065767)
                this._absoluteExpirationRelativeToNow = $.$default($.$$.S.TimeSpan);
                //--TRIMMABLE-BOUNDARY-END(8590065767)
                
                //--TRIMMABLE-BOUNDARY-START(55834706023)
                this._slidingExpiration = $.$default($.$$.S.TimeSpan);
                //--TRIMMABLE-BOUNDARY-END(55834706023)
                
                //--TRIMMABLE-BOUNDARY-START(253403201639)
                this.LastAccessed = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(253403201639)
                
            }
            //--TRIMMABLE-BOUNDARY-START(77309542503)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309542503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(124554182759)
                    this.ExpirationCallback = new ($.$$.S.Action$$($.$$.S.Object))().$ctor($.$mecm.MECM.CacheEntry, $.$mecm.MECM.CacheEntry.ExpirationTokensExpired);
                    //--TRIMMABLE-BOUNDARY-END(124554182759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967655)
                    this._current = new ($.$$.ST$1.AsyncLocal$$($.$mecm.MECM.CacheEntry))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21474967655)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309542503)
            
            static $h = 131175;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111669280871),
    {
      "p": 131175,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913921127,
        "f": 50331688
      },
      "n": "Current",
      "d": 131175,
      "h": 111669280871,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111669280871),
//--TRIMMABLE-BOUNDARY-START(90194444391),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323986535,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343597514855,
        "f": 83886088
      },
      "n": "AbsoluteExpirationTicks",
      "d": 131175,
      "h": 90194444391,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(90194444391),
//--TRIMMABLE-BOUNDARY-START(257698168935),
    {
      "p": $.$typeNullable($.$$.S.DateTimeOffset).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583070823,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296352874599,
        "f": 83886082
      },
      "n": "{1048678}.AbsoluteExpiration",
      "o": "MECM$ICacheEntry$AbsoluteExpiration",
      "d": 131175,
      "h": 257698168935,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(257698168935),
//--TRIMMABLE-BOUNDARY-START(85899477095),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051943,
        "f": 50331656
      },
      "n": "AbsoluteExpirationRelativeToNow",
      "d": 131175,
      "h": 85899477095,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85899477095),
//--TRIMMABLE-BOUNDARY-START(261993136231),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173005415,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304942809191,
        "f": 83886082
      },
      "n": "{1048678}.AbsoluteExpirationRelativeToNow",
      "o": "MECM$ICacheEntry$AbsoluteExpirationRelativeToNow",
      "d": 131175,
      "h": 261993136231,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(261993136231),
//--TRIMMABLE-BOUNDARY-START(399432089703),
    {
      "p": $.$typeNullable($.$$.S.TimeSpan).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633397863,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957253223,
        "f": 83886081
      },
      "n": "SlidingExpiration",
      "d": 131175,
      "h": 399432089703,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432089703),
//--TRIMMABLE-BOUNDARY-START(128849150055),
    {
      "p": $.$$.SCG.IList$$($.$mep.MEP.IChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093790311,
        "f": 50331649
      },
      "n": "ExpirationTokens",
      "d": 131175,
      "h": 128849150055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849150055),
//--TRIMMABLE-BOUNDARY-START(326417645671),
    {
      "p": $.$$.SCG.IList$$($.$meca.MECM.PostEvictionCallbackRegistration).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863594087,
        "f": 50331649
      },
      "n": "PostEvictionCallbacks",
      "d": 131175,
      "h": 326417645671,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417645671),
//--TRIMMABLE-BOUNDARY-START(330712612967),
    {
      "p": 917606,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453528679,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367318631,
        "f": 83886081
      },
      "n": "Priority",
      "d": 131175,
      "h": 330712612967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(330712612967),
//--TRIMMABLE-BOUNDARY-START(395137122407),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043463271,
        "f": 50331656
      },
      "n": "Size",
      "d": 131175,
      "h": 395137122407,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(395137122407),
//--TRIMMABLE-BOUNDARY-START(317827711079),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287762940007,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313532743783,
        "f": 83886082
      },
      "n": "{1048678}.Size",
      "o": "MECM$ICacheEntry$Size",
      "d": 131175,
      "h": 317827711079,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(317827711079),
//--TRIMMABLE-BOUNDARY-START(249108234343),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683724903,
        "f": 50331649
      },
      "n": "Key",
      "d": 131175,
      "h": 249108234343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249108234343),
//--TRIMMABLE-BOUNDARY-START(403727056999),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223332455,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547187815,
        "f": 83886081
      },
      "n": "Value",
      "d": 131175,
      "h": 403727056999,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727056999),
//--TRIMMABLE-BOUNDARY-START(253403201639),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273659495,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360777384039,
        "f": 83886088
      },
      "n": "LastAccessed",
      "d": 131175,
      "h": 253403201639,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(253403201639),
//--TRIMMABLE-BOUNDARY-START(120259215463),
    {
      "p": 983142,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503855719,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352187449447,
        "f": 83886082
      },
      "n": "EvictionReason",
      "d": 131175,
      "h": 120259215463,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(120259215463)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964248167),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 131175,
      "h": 115964248167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964248167),
//--TRIMMABLE-BOUNDARY-START(107374313575),
    {
      "r": 65537,
      "n": "CommitWithTracking",
      "d": 131175,
      "h": 107374313575,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374313575),
//--TRIMMABLE-BOUNDARY-START(98784378983),
    {
      "r": 262145,
      "p": [
        {
          "n": "utcNow",
          "p": 65994753
        }
      ],
      "n": "CheckExpired",
      "d": 131175,
      "h": 98784378983,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98784378983),
//--TRIMMABLE-BOUNDARY-START(390842155111),
    {
      "r": 65537,
      "p": [
        {
          "n": "reason",
          "p": 983142
        }
      ],
      "n": "SetExpired",
      "d": 131175,
      "h": 390842155111,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(390842155111),
//--TRIMMABLE-BOUNDARY-START(103079346279),
    {
      "r": 262145,
      "p": [
        {
          "n": "utcNow",
          "p": 65994753
        }
      ],
      "n": "CheckForExpiredTime",
      "d": 131175,
      "h": 103079346279,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079346279),
//--TRIMMABLE-BOUNDARY-START(94489411687),
    {
      "r": 65537,
      "n": "AttachTokens",
      "d": 131175,
      "h": 94489411687,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94489411687),
//--TRIMMABLE-BOUNDARY-START(133144117351),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "ExpirationTokensExpired",
      "d": 131175,
      "h": 133144117351,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133144117351),
//--TRIMMABLE-BOUNDARY-START(244813267047),
    {
      "r": 65537,
      "n": "InvokeEvictionCallbacks",
      "d": 131175,
      "h": 244813267047,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(244813267047),
//--TRIMMABLE-BOUNDARY-START(335007580263),
    {
      "r": 65537,
      "n": "PropagateOptionsToCurrent",
      "d": 131175,
      "h": 335007580263,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(335007580263),
//--TRIMMABLE-BOUNDARY-START(240518299751),
    {
      "r": 196711,
      "n": "GetOrCreateTokens",
      "d": 131175,
      "h": 240518299751,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518299751)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554182759),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "ExpirationCallback",
      "d": 131175,
      "h": 124554182759,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554182759),
//--TRIMMABLE-BOUNDARY-START(21474967655),
    {
      "t": $.$$.ST$1.AsyncLocal$$($.$mecm.MECM.CacheEntry).$h,
      "n": "_current",
      "d": 131175,
      "h": 21474967655,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21474967655),
//--TRIMMABLE-BOUNDARY-START(17180000359),
    {
      "t": 262247,
      "n": "_cache",
      "d": 131175,
      "h": 17180000359,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000359),
//--TRIMMABLE-BOUNDARY-START(60129673319),
    {
      "t": 196711,
      "n": "_tokens",
      "d": 131175,
      "h": 60129673319,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(60129673319),
//--TRIMMABLE-BOUNDARY-START(8590065767),
    {
      "t": 186646529,
      "n": "_absoluteExpirationRelativeToNow",
      "d": 131175,
      "h": 8590065767,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065767),
//--TRIMMABLE-BOUNDARY-START(55834706023),
    {
      "t": 186646529,
      "n": "_slidingExpiration",
      "d": 131175,
      "h": 55834706023,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(55834706023),
//--TRIMMABLE-BOUNDARY-START(51539738727),
    {
      "t": 917505,
      "n": "_size",
      "d": 131175,
      "h": 51539738727,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51539738727),
//--TRIMMABLE-BOUNDARY-START(42949804135),
    {
      "t": 131175,
      "n": "_previous",
      "d": 131175,
      "h": 42949804135,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42949804135),
//--TRIMMABLE-BOUNDARY-START(64424640615),
    {
      "t": 131073,
      "n": "_value",
      "d": 131175,
      "h": 64424640615,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(64424640615),
//--TRIMMABLE-BOUNDARY-START(12885033063),
    {
      "t": 917505,
      "n": "_absoluteExpirationTicks",
      "d": 131175,
      "h": 12885033063,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033063),
//--TRIMMABLE-BOUNDARY-START(4295098471),
    {
      "t": 524289,
      "n": "_absoluteExpirationOffsetMinutes",
      "d": 131175,
      "h": 4295098471,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098471),
//--TRIMMABLE-BOUNDARY-START(30064902247),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 131175,
      "h": 30064902247,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064902247),
//--TRIMMABLE-BOUNDARY-START(34359869543),
    {
      "t": 262145,
      "n": "_isExpired",
      "d": 131175,
      "h": 34359869543,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359869543),
//--TRIMMABLE-BOUNDARY-START(38654836839),
    {
      "t": 262145,
      "n": "_isValueSet",
      "d": 131175,
      "h": 38654836839,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654836839),
//--TRIMMABLE-BOUNDARY-START(25769934951),
    {
      "t": 393217,
      "n": "_evictionReason",
      "d": 131175,
      "h": 25769934951,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769934951),
//--TRIMMABLE-BOUNDARY-START(47244771431),
    {
      "t": 393217,
      "n": "_priority",
      "d": 131175,
      "h": 47244771431,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47244771431),
//--TRIMMABLE-BOUNDARY-START(322122678375),
    {
      "t": 655361,
      "n": "NotSet",
      "d": 131175,
      "h": 322122678375,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(322122678375)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81604509799),
    {
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "memoryCache",
          "p": 262247
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131175,
      "h": 81604509799,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81604509799)
  ],
  "h": 131175
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.MECM.ICacheEntry, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mecm.MECM.CacheEntry.CacheEntryTokens ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.CacheEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}CacheEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131175)
        
        

        //--TRIMMABLE-BOUNDARY-START(262247)
        $asm.$cls(`$mecm.MECM.MemoryCache`, ($self) => class MemoryCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065033319)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(30065033319)
            
            //--TRIMMABLE-BOUNDARY-START(34360000615)
            /*MemoryCacheOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(34360000615)
            
            //--TRIMMABLE-BOUNDARY-START(12885164135)
            /*List<WeakReference<Stats>>?*/ _allStats = null;
            //--TRIMMABLE-BOUNDARY-END(12885164135)
            
            //--TRIMMABLE-BOUNDARY-START(4295229543)
            /*long*/ _accumulatedHits = 0n;
            //--TRIMMABLE-BOUNDARY-END(4295229543)
            
            //--TRIMMABLE-BOUNDARY-START(8590196839)
            /*long*/ _accumulatedMisses = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590196839)
            
            //--TRIMMABLE-BOUNDARY-START(38654967911)
            /*ThreadLocal<Stats>?*/ _stats = null;
            //--TRIMMABLE-BOUNDARY-END(38654967911)
            
            //--TRIMMABLE-BOUNDARY-START(17180131431)
            /*CoherentState*/ _coherentState = null;
            //--TRIMMABLE-BOUNDARY-END(17180131431)
            
            //--TRIMMABLE-BOUNDARY-START(21475098727)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(21475098727)
            
            //--TRIMMABLE-BOUNDARY-START(25770066023)
            /*DateTime*/ _lastExpirationScan;
            //--TRIMMABLE-BOUNDARY-END(25770066023)
            
            //--TRIMMABLE-BOUNDARY-START(51539869799)
            $ctor$2(/*IOptions<MemoryCacheOptions>*/ optionsAccessor)
            {
                this.$ctor$1(optionsAccessor, $.$mexla.MELA.NullLoggerFactory.Instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539869799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869799)
            
            //--TRIMMABLE-BOUNDARY-START(47244902503)
            $ctor$1(/*IOptions<MemoryCacheOptions>*/ optionsAccessor, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244902503);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(optionsAccessor, "optionsAccessor");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(loggerFactory, "loggerFactory");
                    this._options = optionsAccessor.MEO$IOptions$Microsoft$Extensions$Caching$Memory$MemoryCacheOptions$Value;
                    this._logger = $.$mexla.MEL.LoggerFactoryExtensions.CreateLogger$1($.$mecm.MECM.MemoryCache, loggerFactory);
                    this._coherentState = new $.$mecm.MECM.MemoryCache.CoherentState().$ctor$1();
                    if (this._options.TrackStatistics)
                    {
                        this._allStats = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$mecm.MECM.MemoryCache.Stats)))().$ctor$1();
                        this._stats = new ($.$$.ST$1.ThreadLocal$$($.$mecm.MECM.MemoryCache.Stats))().$ctor$4(new ($.$$.S.Func$$($.$mecm.MECM.MemoryCache.Stats))().$ctor(this,  () =>
                        {
                            return new $.$mecm.MECM.MemoryCache.Stats().$ctor$1(this);
                        }, $tYUNZf ??= {"r":393319,"n":"","d":262247,"h":0,"f":17825794}));
                    }
                    this._lastExpirationScan = this.UtcNow;
                    this.TrackLinkedCacheEntries = this._options.TrackLinkedCacheEntries;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902503)
            
            //--TRIMMABLE-BOUNDARY-START(227633528935)
            /*DateTime */ get UtcNow()
            {
                return (this._options.Clock?.MEI$ISystemClock$UtcNow.UtcDateTime ?? null) ?? $.$$.S.DateTime.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(227633528935)
            
            $dtor()
            {
                {
                    return this.Dispose$1(false);
                }
            }
            //--TRIMMABLE-BOUNDARY-START(77309673575)
            /*int */ get Count()
            {
                return this._coherentState.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(77309673575)
            
            //--TRIMMABLE-BOUNDARY-START(154619084903)
            /*IEnumerable<object> */ get Keys()
            {
                return this._coherentState.GetAllKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(154619084903)
            
            //--TRIMMABLE-BOUNDARY-START(188978823271)
            /*long */ get Size()
            {
                return this._coherentState.Size;
            }
            //--TRIMMABLE-BOUNDARY-END(188978823271)
            
            //--TRIMMABLE-BOUNDARY-START(201863725159)
            /*bool*/ TrackLinkedCacheEntries = false;
            //--TRIMMABLE-BOUNDARY-END(201863725159)
            
            //--TRIMMABLE-BOUNDARY-START(81604640871)
            /*ICacheEntry */ CreateEntry(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                return new $.$mecm.MECM.CacheEntry().$ctor$1(key, this);
            }
            //--TRIMMABLE-BOUNDARY-END(81604640871)
            
            //--TRIMMABLE-BOUNDARY-START(184683855975)
            /*void */ SetEntry(/*CacheEntry*/ entry)
            {
                /*CacheEntry?*/ let priorEntry;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return;
                }
                if (this._options.HasSizeLimit && entry.Size < 0n)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecm.S.SR.Format$5($.$mecm.S.SR.CacheEntryHasEmptySize, "Size", "SizeLimit"));
                }
                /*DateTime*/ let utcNow = this.UtcNow;
                if (entry.AbsoluteExpirationRelativeToNow.Ticks > 0n)
                {
                    /*long*/ let absoluteExpiration = ($.$$.S.DateTime.op_Addition(utcNow, entry.AbsoluteExpirationRelativeToNow)).Ticks;
                    if ($.$cast(absoluteExpiration, $.$$.S.UInt64) < $.$cast(entry.AbsoluteExpirationTicks, $.$$.S.UInt64))
                    {
                        entry.AbsoluteExpirationTicks = absoluteExpiration;
                    }
                }
                entry.LastAccessed = utcNow;
                /*CoherentState*/ let coherentState = this._coherentState;
                if (coherentState.TryGetValue(entry.Key, $.$ref(() => priorEntry, ($v) => priorEntry = $v, $.$mecm.MECM.CacheEntry)))
                {
                    priorEntry.SetExpired(2/*EvictionReason.Replaced*/);
                }
                if (entry.CheckExpired(utcNow))
                {
                    entry.InvokeEvictionCallbacks();
                    if (priorEntry !== null)
                    {
                        coherentState.RemoveEntry(priorEntry, this._options);
                    }
                }
                else if (!this.UpdateCacheSizeExceedsCapacity(entry, priorEntry, coherentState))
                {
                    /*bool*/ let entryAdded;
                    if (priorEntry === null)
                    {
                        entryAdded = coherentState.TryAdd(entry.Key, entry);
                    }
                    else 
                    {
                        entryAdded = coherentState.TryUpdate(entry.Key, entry, priorEntry);
                        if (!entryAdded)
                        {
                            entryAdded = coherentState.TryAdd(entry.Key, entry);
                        }
                    }
                    if (entryAdded)
                    {
                        entry.AttachTokens();
                    }
                    else 
                    {
                        if (this._options.HasSizeLimit)
                        {
                            $.$$.ST$1.Interlocked.Add$1($.$ref(() => coherentState._cacheSize, ($v) => coherentState._cacheSize = $v, $.$$.S.Int64), BigInt.asIntN(64, -entry.Size + $.$$.S.Nullable$$($.$$.S.Int64).GetValueOrDefault.call(((priorEntry?.Size ?? null)))));
                        }
                        entry.SetExpired(2/*EvictionReason.Replaced*/);
                        entry.InvokeEvictionCallbacks();
                    }
                    priorEntry?.InvokeEvictionCallbacks();
                }
                else 
                {
                    entry.SetExpired(5/*EvictionReason.Capacity*/);
                    this.TriggerOvercapacityCompaction();
                    entry.InvokeEvictionCallbacks();
                    if (priorEntry !== null)
                    {
                        coherentState.RemoveEntry(priorEntry, this._options);
                    }
                }
                this.StartScanForExpiredItemsIfNeeded(utcNow);
            }
            //--TRIMMABLE-BOUNDARY-END(184683855975)
            
            //--TRIMMABLE-BOUNDARY-START(210453659751)
            /*bool */ TryGetValue(/*object*/ key, /*out object?*/ result)
            {
                /*CacheEntry?*/ let entry;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453659751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.CheckDisposed();
                /*CoherentState*/ let coherentState = this._coherentState;
                coherentState.TryGetValue(key, $.$ref(() => entry, ($v) => entry = $v, $.$mecm.MECM.CacheEntry));
                return this.PostProcessTryGetValue(coherentState, entry, result);
            }
            //--TRIMMABLE-BOUNDARY-END(210453659751)
            
            //--TRIMMABLE-BOUNDARY-START(214748627047)
            /*bool */ TryGetValue$1(/*ReadOnlySpan<char>*/ key, /*out object?*/ value)
            {
                /*CacheEntry?*/ let entry;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748627047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                /*CoherentState*/ let coherentState = this._coherentState;
                coherentState.TryGetValue$1(key, $.$ref(() => entry, ($v) => entry = $v, $.$mecm.MECM.CacheEntry));
                return this.PostProcessTryGetValue(coherentState, entry, value);
            }
            //--TRIMMABLE-BOUNDARY-END(214748627047)
            
            //--TRIMMABLE-BOUNDARY-START(219043594343)
            /*bool */ TryGetValue$2(TItem, /*ReadOnlySpan<char>*/ key, /*out TItem?*/ value)
            {
                /*object?*/ let untyped;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043594343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryGetValue$1(key, $.$ref(() => untyped, ($v) => untyped = $v, $.$$.S.Object)))
                {
                    if (untyped === null)
                    {
                        value.$v = $.$default(TItem);
                        return true;
                    }
                    let item;
                    if ($.$is(untyped, TItem, { set $v($v){ item = $v; } }))
                    {
                        value.$v = item;
                        return true;
                    }
                }
                value.$v = $.$default(TItem);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(219043594343)
            
            //--TRIMMABLE-BOUNDARY-START(167503986791)
            /*bool */ PostProcessTryGetValue(/*CoherentState*/ coherentState, /*CacheEntry?*/ entry, /*out object?*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime*/ let utcNow = this.UtcNow;
                if (!(entry === null))
                {
                    if (!entry.CheckExpired(utcNow) || entry.EvictionReason === 2/*EvictionReason.Replaced*/)
                    {
                        entry.LastAccessed = utcNow;
                        result.$v = entry.Value;
                        if (this.TrackLinkedCacheEntries)
                        {
                            entry.PropagateOptionsToCurrent();
                        }
                        this.StartScanForExpiredItemsIfNeeded(utcNow);
                        if (!(this._stats === null))
                        {
                            //if (IntPtr.Size == 4)
                            {
                                $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this.GetStats().Hits, ($v) => this.GetStats().Hits = $v, $.$$.S.Int64));
                            }
                            //else { ... }
                        }
                        return true;
                    }
                    else 
                    {
                        coherentState.RemoveEntry(entry, this._options);
                    }
                }
                this.StartScanForExpiredItemsIfNeeded(utcNow);
                result.$v = null;
                if (!(this._stats === null))
                {
                    //if (IntPtr.Size == 4)
                    {
                        $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this.GetStats().Misses, ($v) => this.GetStats().Misses = $v, $.$$.S.Int64));
                    }
                    //else { ... }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(167503986791)
            
            //--TRIMMABLE-BOUNDARY-START(171798954087)
            /*void */ Remove(/*object*/ key)
            {
                /*CacheEntry?*/ let entry;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.CheckDisposed();
                /*CoherentState*/ let coherentState = this._coherentState;
                if (coherentState.TryRemove(key, $.$ref(() => entry, ($v) => entry = $v, $.$mecm.MECM.CacheEntry)))
                {
                    if (this._options.HasSizeLimit)
                    {
                        $.$$.ST$1.Interlocked.Add$1($.$ref(() => coherentState._cacheSize, ($v) => coherentState._cacheSize = $v, $.$$.S.Int64), -entry.Size);
                    }
                    entry.SetExpired(1/*EvictionReason.Removed*/);
                    entry.InvokeEvictionCallbacks();
                }
                this.StartScanForExpiredItemsIfNeeded(this.UtcNow);
            }
            //--TRIMMABLE-BOUNDARY-END(171798954087)
            
            //--TRIMMABLE-BOUNDARY-START(64424771687)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                /*CoherentState*/ let oldState = $.$$.ST$1.Interlocked.Exchange$14($.$mecm.MECM.MemoryCache.CoherentState, $.$ref(() => this._coherentState, ($v) => this._coherentState = $v, $.$mecm.MECM.MemoryCache.CoherentState), new $.$mecm.MECM.MemoryCache.CoherentState().$ctor$1());
                let $en13 = oldState.GetAllValues().SCG$IEnumerable$$$GetEnumerator();
                while ($en13.SC$1$IEnumerator$MoveNext())
                {
                    let entry = $en13.SCG$IEnumerator$$$Current;
                    {
                        entry.SetExpired(1/*EvictionReason.Removed*/);
                        entry.InvokeEvictionCallbacks();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424771687)
            
            //--TRIMMABLE-BOUNDARY-START(146029150311)
            /*MemoryCacheStatistics? */ GetCurrentStatistics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._allStats === null))
                {
                    /*(long hit, long miss)*/ let sumTotal = this.Sum();
                    return (() =>
                    {
                        //new $.$meca.MECM.MemoryCacheStatistics()
                        const $t14 = $.$meca.MECM.MemoryCacheStatistics;
                        const $i14 = new $t14();
                        $i14.$ctor$1();
                        $i14.TotalMisses = sumTotal.Item2;
                        $i14.TotalHits = sumTotal.Item1;
                        $i14.CurrentEntryCount = BigInt(this.Count);
                        $i14.CurrentEstimatedSize = this._options.HasSizeLimit ? this.Size : null;
                        return $i14;
                    })();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029150311)
            
            //--TRIMMABLE-BOUNDARY-START(94489542759)
            /*void */ EntryExpired(/*CacheEntry*/ entry)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._coherentState.RemoveEntry(entry, this._options);
                this.StartScanForExpiredItemsIfNeeded(this.UtcNow);
            }
            //--TRIMMABLE-BOUNDARY-END(94489542759)
            
            //--TRIMMABLE-BOUNDARY-START(193273790567)
            /*void */ StartScanForExpiredItemsIfNeeded(/*DateTime*/ utcNow)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.TimeSpan.op_LessThan(this._options.ExpirationScanFrequency, $.$$.S.DateTime.op_Subtraction$1(utcNow, this._lastExpirationScan)))
                {
                    ScheduleTask.call(this, utcNow);
                }
                /*void*/  function ScheduleTask(/*DateTime*/ utcNow)
                {
                    this._lastExpirationScan = utcNow;
                    $.$$.STT.Task.Factory.StartNew$4(new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$mecm.MECM.MemoryCache)).ScanForExpiredItems();
                    }, $WYFdSg ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":262247,"h":0,"f":17825794}), this, $.$$.ST$1.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.STT.TaskScheduler.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273790567)
            
            //--TRIMMABLE-BOUNDARY-START(197568757863)
            /*(long, long) */ Sum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_allStats!)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._allStats)
                    {
                        /*long*/ let hits = this._accumulatedHits;
                        /*long*/ let misses = this._accumulatedMisses;
                        let $en15 = this._allStats.GetEnumerator();
                        while ($en15.MoveNext())
                        {
                            let wr = $en15.Current;
                            {
                                /*Stats?*/ let stats;
                                if (wr.TryGetTarget($.$ref(() => stats, ($v) => stats = $v, $.$mecm.MECM.MemoryCache.Stats)))
                                {
                                    hits += $.$ref(() => stats.Hits, ($v) => stats.Hits = $v, $.$$.S.Int64).$v;
                                    misses += $.$ref(() => stats.Misses, ($v) => stats.Misses = $v, $.$$.S.Int64).$v;
                                }
                            }
                        }
                        return new ($.$$.S.ValueTuple$$$($.$$.S.Int64, $.$$.S.Int64))().$ctor$3(hits, misses);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._allStats)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568757863)
            
            //--TRIMMABLE-BOUNDARY-START(150324117607)
            /*Stats */ GetStats()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324117607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._stats.Value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324117607)
            
            //--TRIMMABLE-BOUNDARY-START(393319)
            static $_Stats;
            static get Stats()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mecm.MECM.MemoryCache;
                return $cls.$_Stats ??= $asm.$ncls(`$mecm.MECM.MemoryCache.Stats`, ($self) => class Stats extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295360615)
                    /*MemoryCache*/ _memoryCache = null;
                    //--TRIMMABLE-BOUNDARY-END(4295360615)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262503)
                    /*long*/ Hits = 0n;
                    //--TRIMMABLE-BOUNDARY-END(17180262503)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475229799)
                    /*long*/ Misses = 0n;
                    //--TRIMMABLE-BOUNDARY-END(21475229799)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327911)
                    $ctor$1(/*MemoryCache*/ memoryCache)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590327911);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._memoryCache = memoryCache;
                            this._memoryCache.AddToStats(this);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590327911)
                    
                    $dtor()
                    {
                        {
                            return this._memoryCache.RemoveFromStats(this);
                        }
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        $.$finalizer(this);
                    }
                    static $h = 393319;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360615),
    {
      "t": 262247,
      "n": "_memoryCache",
      "d": 393319,
      "h": 4295360615,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360615),
//--TRIMMABLE-BOUNDARY-START(17180262503),
    {
      "t": 917505,
      "n": "Hits",
      "d": 393319,
      "h": 17180262503,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180262503),
//--TRIMMABLE-BOUNDARY-START(21475229799),
    {
      "t": 917505,
      "n": "Misses",
      "d": 393319,
      "h": 21475229799,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(21475229799)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327911),
    {
      "p": [
        {
          "n": "memoryCache",
          "p": 262247
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393319,
      "h": 8590327911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327911)
  ],
  "d": 262247,
  "h": 393319
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCache+Stats`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCache${separator}Stats`; }
                }, $cls, ($v) => $cls.$_Stats = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393319)
            
            //--TRIMMABLE-BOUNDARY-START(176093921383)
            /*void */ RemoveFromStats(/*Stats*/ current)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_allStats!)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._allStats)
                    {
                        this._accumulatedHits += $.$ref(() => current.Hits, ($v) => current.Hits = $v, $.$$.S.Int64).$v;
                        this._accumulatedMisses += $.$ref(() => current.Misses, ($v) => current.Misses = $v, $.$$.S.Int64).$v;
                        /*List<WeakReference<Stats>>*/ let all = this._allStats;
                        for(/*int*/ let i = ((all.Count - 1) | 0); i >= 0; i--)
                        {
                            if (!all.get_Item(i).TryGetTarget($.$discardRef()))
                            {
                                all.RemoveAt(i);
                            }
                        }
                        all.TrimExcess();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._allStats)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093921383)
            
            //--TRIMMABLE-BOUNDARY-START(55834837095)
            /*void */ AddToStats(/*Stats*/ current)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_allStats!)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._allStats)
                    {
                        this._allStats.Add(new ($.$$.S.WeakReference$$($.$mecm.MECM.MemoryCache.Stats))().$ctor$3(current));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._allStats)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837095)
            
            //--TRIMMABLE-BOUNDARY-START(180388888679)
            /*void */ ScanForExpiredItems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime*/ let utcNow = this._lastExpirationScan = this.UtcNow;
                /*CoherentState*/ let coherentState = this._coherentState;
                let $en21 = coherentState.GetAllValues().SCG$IEnumerable$$$GetEnumerator();
                while ($en21.SC$1$IEnumerator$MoveNext())
                {
                    let entry = $en21.SCG$IEnumerator$$$Current;
                    {
                        if (entry.CheckExpired(utcNow))
                        {
                            coherentState.RemoveEntry(entry, this._options);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180388888679)
            
            //--TRIMMABLE-BOUNDARY-START(223338561639)
            /*bool */ UpdateCacheSizeExceedsCapacity(/*CacheEntry*/ entry, /*CacheEntry?*/ priorEntry, /*CoherentState*/ coherentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338561639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let sizeLimit = this._options.SizeLimitValue;
                if (sizeLimit < 0n)
                {
                    return false;
                }
                /*long*/ let sizeRead = coherentState.Size;
                for(/*int*/ let i = 0; i < 100; i++)
                {
                    /*long*/ let newSize = BigInt.asIntN(64, sizeRead + entry.Size);
                    if (priorEntry !== null)
                    {
                        $.$$.SD.Debug.Assert$4(entry.Key === priorEntry.Key, "entry.Key == priorEntry.Key");
                        newSize -= priorEntry.Size;
                    }
                    if ($.$cast(newSize, $.$$.S.UInt64) > $.$cast(sizeLimit, $.$$.S.UInt64))
                    {
                        return true;
                    }
                    /*long*/ let original = $.$$.ST$1.Interlocked.CompareExchange$4($.$ref(() => coherentState._cacheSize, ($v) => coherentState._cacheSize = $v, $.$$.S.Int64), newSize, sizeRead);
                    if (sizeRead === original)
                    {
                        return false;
                    }
                    sizeRead = original;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(223338561639)
            
            //--TRIMMABLE-BOUNDARY-START(158914052199)
            /*int*/ lockFlag = 0;
            //--TRIMMABLE-BOUNDARY-END(158914052199)
            
            //--TRIMMABLE-BOUNDARY-START(206158692455)
            /*void */ TriggerOvercapacityCompaction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158692455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._logger.MEL$ILogger$IsEnabled(1/*LogLevel.Debug*/))
                {
                    $.$mexla.MEL.LoggerExtensions.LogDebug$3(this._logger, "Overcapacity compaction triggered", $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                if ($.$$.ST$1.Interlocked.CompareExchange$3($.$ref(() => this.lockFlag, ($v) => this.lockFlag = $v, $.$$.S.Int32), 1, 0) === 0)
                {
                    $.$$.ST$1.ThreadPool.UnsafeQueueUserWorkItem$1(new $.$$.ST$1.WaitCallback().$ctor($.$mecm.MECM.MemoryCache, /*static*/ (/*s*/ s) =>
                    {
                        try
                        {
                            ($.$cast(s, $.$mecm.MECM.MemoryCache)).OvercapacityCompaction();
                        }
                        finally
                        {
                            {
                                ($.$cast(s, $.$mecm.MECM.MemoryCache)).lockFlag = 0;
                            }
                        }
                    }, $jMquIa ??= {"r":65537,"p":[{"n":"s","p":131073}],"n":"","d":262247,"h":0,"f":17825826}), this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206158692455)
            
            //--TRIMMABLE-BOUNDARY-START(163209019495)
            /*void */ OvercapacityCompaction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CoherentState*/ let coherentState = this._coherentState;
                /*long*/ let currentSize = coherentState.Size;
                if (this._logger.MEL$ILogger$IsEnabled(1/*LogLevel.Debug*/))
                {
                    $.$mexla.MEL.LoggerExtensions.LogDebug$3(this._logger, `Overcapacity compaction executing. Current size ${$.$strNN(currentSize)}`, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                /*long*/ let sizeLimit = this._options.SizeLimitValue;
                if (sizeLimit >= 0n)
                {
                    /*long*/ let lowWatermark = BigInt.asIntN(64, sizeLimit - $.$cast((Number(sizeLimit) * this._options.CompactionPercentage), $.$$.S.Int64));
                    if (currentSize > lowWatermark)
                    {
                        this.Compact$1(BigInt.asIntN(64, currentSize - lowWatermark), new ($.$$.S.Func$$$($.$mecm.MECM.CacheEntry, $.$$.S.Int64))().$ctor(this,  (/*entry*/ entry) =>
                        {
                            return entry.Size;
                        }, $pwdQvk ??= {"r":917505,"p":[{"n":"entry","p":131175}],"n":"","d":262247,"h":0,"f":17825794}), coherentState);
                    }
                }
                if (this._logger.MEL$ILogger$IsEnabled(1/*LogLevel.Debug*/))
                {
                    $.$mexla.MEL.LoggerExtensions.LogDebug$3(this._logger, `Overcapacity compaction executed. New size ${$.$strNN(coherentState.Size)}`, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209019495)
            
            //--TRIMMABLE-BOUNDARY-START(68719738983)
            /*void */ Compact(/*double*/ percentage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CoherentState*/ let coherentState = this._coherentState;
                /*int*/ let removalCountTarget = $.$cast((coherentState.Count * percentage), $.$$.S.Int32);
                this.Compact$1(BigInt(removalCountTarget), new ($.$$.S.Func$$$($.$mecm.MECM.CacheEntry, $.$$.S.Int64))().$ctor(this,  (/**/ _0) =>
                {
                    return 1n;
                }, $qgsoCh ??= {"r":917505,"p":[{"n":"_","p":131175}],"n":"","d":262247,"h":0,"f":17825794}), coherentState);
            }
            //--TRIMMABLE-BOUNDARY-END(68719738983)
            
            //--TRIMMABLE-BOUNDARY-START(73014706279)
            /*void */ Compact$1(/*long*/ removalSizeTarget, /*Func<CacheEntry, long>*/ computeEntrySize, /*CoherentState*/ coherentState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let entriesToRemove = new ($.$$.SCG.List$$($.$mecm.MECM.CacheEntry))().$ctor$1();
                /*var*/ let lowPriEntries = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime)))().$ctor$1();
                /*var*/ let normalPriEntries = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime)))().$ctor$1();
                /*var*/ let highPriEntries = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime)))().$ctor$1();
                /*long*/ let removedSize = 0n;
                /*DateTime*/ let utcNow = this.UtcNow;
                let $en24 = coherentState.GetAllValues().SCG$IEnumerable$$$GetEnumerator();
                while ($en24.SC$1$IEnumerator$MoveNext())
                {
                    let entry = $en24.SCG$IEnumerator$$$Current;
                    {
                        if (entry.CheckExpired(utcNow))
                        {
                            entriesToRemove.Add(entry);
                            removedSize += computeEntrySize.Invoke(entry);
                        }
                        else 
                        {
                            let $switch25 = entry.Priority;
                            switch($switch25)
                            {
                                case 0/*CacheItemPriority.Low*/:
                                lowPriEntries.Add(new ($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime))().$ctor$3(entry, entry.LastAccessed));
                                break;
                                case 1/*CacheItemPriority.Normal*/:
                                normalPriEntries.Add(new ($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime))().$ctor$3(entry, entry.LastAccessed));
                                break;
                                case 2/*CacheItemPriority.High*/:
                                highPriEntries.Add(new ($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime))().$ctor$3(entry, entry.LastAccessed));
                                break;
                                case 3/*CacheItemPriority.NeverRemove*/:
                                break;
                                default:
                                throw new $.$$.S.NotSupportedException().$ctor$12("Not implemented: " + $.$$.S.Enum.ToStringT($.$meca.MECM.CacheItemPriority, $.$$.S.UInt32, entry.Priority));
                            }
                        }
                    }
                }
                ExpirePriorityBucket($.$ref(() => removedSize, ($v) => removedSize = $v, $.$$.S.Int64), removalSizeTarget, computeEntrySize, entriesToRemove, lowPriEntries);
                ExpirePriorityBucket($.$ref(() => removedSize, ($v) => removedSize = $v, $.$$.S.Int64), removalSizeTarget, computeEntrySize, entriesToRemove, normalPriEntries);
                ExpirePriorityBucket($.$ref(() => removedSize, ($v) => removedSize = $v, $.$$.S.Int64), removalSizeTarget, computeEntrySize, entriesToRemove, highPriEntries);
                let $en29 = entriesToRemove.GetEnumerator();
                while ($en29.MoveNext())
                {
                    let entry = $en29.Current;
                    {
                        coherentState.RemoveEntry(entry, this._options);
                    }
                }
                /*static void*/  function ExpirePriorityBucket(/*ref long*/ removedSize, /*long*/ removalSizeTarget, /*Func<CacheEntry, long>*/ computeEntrySize, /*List<CacheEntry>*/ entriesToRemove, /*List<(CacheEntry Entry, DateTime LastAccessed)>*/ priorityEntries)
                {
                    if (removalSizeTarget <= removedSize.$v)
                    {
                        return;
                    }
                    priorityEntries.Sort$2(new ($.$$.S.Comparison$$($.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime)))().$ctor($.$mecm.MECM.MemoryCache, /*static*/ (/*e1*/ e1, /*e2*/ e2) =>
                    {
                        return e1.Item2.CompareTo$1(e2.Item2);
                    }, $WhVnta ??= {"r":655361,"p":[{"n":"e1","p":$.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime).$h},{"n":"e2","p":$.$$.S.ValueTuple$$$($.$mecm.MECM.CacheEntry, $.$$.S.DateTime).$h}],"n":"","d":262247,"h":0,"f":17825826}));
                    let $en30 = priorityEntries.GetEnumerator();
                    while ($en30.MoveNext())
                    {
                        let $t31 = $en30.Current;
                        /*CacheEntry*/ let entry = $t31.Item1;
                        {
                            entry.SetExpired(5/*EvictionReason.Capacity*/);
                            entriesToRemove.Add(entry);
                            removedSize.$v += computeEntrySize.Invoke(entry);
                            if (removalSizeTarget <= removedSize.$v)
                            {
                                break;
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014706279)
            
            //--TRIMMABLE-BOUNDARY-START(85899608167)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
            }
            //--TRIMMABLE-BOUNDARY-END(85899608167)
            
            //--TRIMMABLE-BOUNDARY-START(90194575463)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._stats?.Dispose();
                        $.$$.S.GC.SuppressFinalize(this);
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194575463)
            
            //--TRIMMABLE-BOUNDARY-START(60129804391)
            /*void */ CheckDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    Throw();
                }
                /*static void*/  function Throw()
                {
                    {
                        throw new $.$$.S.ObjectDisposedException().$ctor$17($.$mecm.MECM.MemoryCache.$type.FullName);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129804391)
            
            //--TRIMMABLE-BOUNDARY-START(327783)
            static $_CoherentState;
            static get CoherentState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mecm.MECM.MemoryCache;
                return $cls.$_CoherentState ??= $asm.$ncls(`$mecm.MECM.MemoryCache.CoherentState`, ($self) => class CoherentState extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17180196967)
                    /*ConcurrentDictionary<string, CacheEntry>*/ _stringEntries = null;
                    //--TRIMMABLE-BOUNDARY-END(17180196967)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590262375)
                    /*ConcurrentDictionary<object, CacheEntry>*/ _nonStringEntries = null;
                    //--TRIMMABLE-BOUNDARY-END(8590262375)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229671)
                    /*ConcurrentDictionary<string, CacheEntry>.AlternateLookup<ReadOnlySpan<char>>*/ _stringAltLookup;
                    //--TRIMMABLE-BOUNDARY-END(12885229671)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475164263)
                    $ctor$1()
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475164263);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._stringAltLookup = this._stringEntries.GetAlternateLookup($.$$.S.ReadOnlySpan$$($.$$.S.Char));
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475164263)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295295079)
                    /*long*/ _cacheSize = 0n;
                    //--TRIMMABLE-BOUNDARY-END(4295295079)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719804519)
                    /*bool */ TryGetValue(/*object*/ key, /*out CacheEntry?*/ entry)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68719804519);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let s;
                            return $.$is(key, $.$$.S.String, { set $v($v){ s = $v; } }) ? this._stringEntries.TryGetValue(s, entry) : this._nonStringEntries.TryGetValue(key, entry);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719804519)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014771815)
                    /*bool */ TryGetValue$1(/*ReadOnlySpan<char>*/ key, /*out CacheEntry?*/ entry)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(73014771815);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._stringAltLookup.TryGetValue$1(key, entry);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014771815)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309739111)
                    /*bool */ TryRemove(/*object*/ key, /*out CacheEntry?*/ entry)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(77309739111);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let s;
                            return $.$is(key, $.$$.S.String, { set $v($v){ s = $v; } }) ? this._stringEntries.TryRemove$1(s, entry) : this._nonStringEntries.TryRemove$1(key, entry);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309739111)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424837223)
                    /*bool */ TryAdd(/*object*/ key, /*CacheEntry*/ entry)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64424837223);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let s;
                            return $.$is(key, $.$$.S.String, { set $v($v){ s = $v; } }) ? this._stringEntries.TryAdd(s, entry) : this._nonStringEntries.TryAdd(key, entry);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424837223)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604706407)
                    /*bool */ TryUpdate(/*object*/ key, /*CacheEntry*/ entry, /*CacheEntry*/ comparison)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81604706407);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let s;
                            return $.$is(key, $.$$.S.String, { set $v($v){ s = $v; } }) ? this._stringEntries.TryUpdate(s, entry, comparison) : this._nonStringEntries.TryUpdate(key, entry, comparison);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604706407)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539935335)
                    /*IEnumerable<CacheEntry> */ GetAllValues()
                    {
                        return new ($.$$.N.YieldToIterator$$($.$mecm.MECM.CacheEntry))().$ctor$1(function*()
                        {
                            let $en37 = this._stringEntries.GetEnumerator();
                            while ($en37.SC$1$IEnumerator$MoveNext())
                            {
                                let entry = $en37.SCG$IEnumerator$$$Current;
                                {
                                    yield entry.Value;
                                }
                            }
                            let $en38 = this._nonStringEntries.GetEnumerator();
                            while ($en38.SC$1$IEnumerator$MoveNext())
                            {
                                let entry = $en38.SCG$IEnumerator$$$Current;
                                {
                                    yield entry.Value;
                                }
                            }
                        }.bind(this));
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539935335)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244968039)
                    /*IEnumerable<object> */ GetAllKeys()
                    {
                        return new ($.$$.N.YieldToIterator$$($.$$.S.Object))().$ctor$1(function*()
                        {
                            let $en39 = this._stringEntries.GetEnumerator();
                            while ($en39.SC$1$IEnumerator$MoveNext())
                            {
                                let pairs = $en39.SCG$IEnumerator$$$Current;
                                {
                                    yield pairs.Key;
                                }
                            }
                            let $en40 = this._nonStringEntries.GetEnumerator();
                            while ($en40.SC$1$IEnumerator$MoveNext())
                            {
                                let pairs = $en40.SCG$IEnumerator$$$Current;
                                {
                                    yield pairs.Key;
                                }
                            }
                        }.bind(this));
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244968039)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131559)
                    /*int */ get Count()
                    {
                        return ((this._stringEntries.Count + this._nonStringEntries.Count) | 0);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131559)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129869927)
                    /*long */ get Size()
                    {
                        return $.$ref(() => this._cacheSize, ($v) => this._cacheSize = $v, $.$$.S.Int64).$v;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129869927)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834902631)
                    /*void */ RemoveEntry(/*CacheEntry*/ entry, /*MemoryCacheOptions*/ options)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834902631);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let s;
                        if ($.$is(entry.Key, $.$$.S.String, { set $v($v){ s = $v; } }) ? this._stringEntries.TryRemove($.$$.SCG.KeyValuePair.Create($.$$.S.String, $.$mecm.MECM.CacheEntry, s, entry)) : this._nonStringEntries.TryRemove($.$$.SCG.KeyValuePair.Create($.$$.S.Object, $.$mecm.MECM.CacheEntry, entry.Key, entry)))
                        {
                            if (options.HasSizeLimit)
                            {
                                $.$$.ST$1.Interlocked.Add$1($.$ref(() => this._cacheSize, ($v) => this._cacheSize = $v, $.$$.S.Int64), -entry.Size);
                            }
                            entry.InvokeEvictionCallbacks();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834902631)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475164263)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475164263)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17180196967)
                        this._stringEntries = (() =>
                        {
                            let $t43 = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mecm.MECM.CacheEntry))().$ctor$1();
                            return $t43;
                        })();
                        //--TRIMMABLE-BOUNDARY-END(17180196967)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590262375)
                        this._nonStringEntries = (() =>
                        {
                            let $t44 = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Object, $.$mecm.MECM.CacheEntry))().$ctor$1();
                            return $t44;
                        })();
                        //--TRIMMABLE-BOUNDARY-END(8590262375)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885229671)
                        this._stringAltLookup = $.$default($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mecm.MECM.CacheEntry).AlternateLookup$$($.$$.S.ReadOnlySpan$$($.$$.S.Char)));
                        //--TRIMMABLE-BOUNDARY-END(12885229671)
                        
                    }
                    static $h = 327783;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770131559),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066151,
        "f": 50331656
      },
      "n": "Count",
      "d": 327783,
      "h": 25770131559,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(25770131559),
//--TRIMMABLE-BOUNDARY-START(60129869927),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950000743,
        "f": 50331656
      },
      "n": "Size",
      "d": 327783,
      "h": 60129869927,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60129869927)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719804519),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "entry",
          "p": 131175,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 327783,
      "h": 68719804519,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719804519),
//--TRIMMABLE-BOUNDARY-START(73014771815),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "entry",
          "p": 131175,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "o": "@$1",
      "d": 327783,
      "h": 73014771815,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73014771815),
//--TRIMMABLE-BOUNDARY-START(77309739111),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "entry",
          "p": 131175,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "d": 327783,
      "h": 77309739111,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77309739111),
//--TRIMMABLE-BOUNDARY-START(64424837223),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "entry",
          "p": 131175
        }
      ],
      "n": "TryAdd",
      "d": 327783,
      "h": 64424837223,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64424837223),
//--TRIMMABLE-BOUNDARY-START(81604706407),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "entry",
          "p": 131175
        },
        {
          "n": "comparison",
          "p": 131175
        }
      ],
      "n": "TryUpdate",
      "d": 327783,
      "h": 81604706407,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81604706407),
//--TRIMMABLE-BOUNDARY-START(51539935335),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecm.MECM.CacheEntry).$h,
      "n": "GetAllValues",
      "d": 327783,
      "h": 51539935335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539935335),
//--TRIMMABLE-BOUNDARY-START(47244968039),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "n": "GetAllKeys",
      "d": 327783,
      "h": 47244968039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244968039),
//--TRIMMABLE-BOUNDARY-START(55834902631),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 131175
        },
        {
          "n": "options",
          "p": 458855
        }
      ],
      "n": "RemoveEntry",
      "d": 327783,
      "h": 55834902631,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55834902631)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180196967),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mecm.MECM.CacheEntry).$h,
      "n": "_stringEntries",
      "d": 327783,
      "h": 17180196967,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180196967),
//--TRIMMABLE-BOUNDARY-START(8590262375),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Object, $.$mecm.MECM.CacheEntry).$h,
      "n": "_nonStringEntries",
      "d": 327783,
      "h": 8590262375,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262375),
//--TRIMMABLE-BOUNDARY-START(12885229671),
    {
      "t": 524302,
      "n": "_stringAltLookup",
      "d": 327783,
      "h": 12885229671,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885229671),
//--TRIMMABLE-BOUNDARY-START(4295295079),
    {
      "t": 917505,
      "n": "_cacheSize",
      "d": 327783,
      "h": 4295295079,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295295079)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475164263),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327783,
      "h": 21475164263,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164263)
  ],
  "d": 262247,
  "h": 327783
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCache+CoherentState`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCache${separator}CoherentState`; }
                }, $cls, ($v) => $cls.$_CoherentState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327783)
            
            //--TRIMMABLE-BOUNDARY-START(17180983398)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.IMemoryCache.TryGetValue(object, out object?)
            MECM$IMemoryCache$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180983398)
            
            //--TRIMMABLE-BOUNDARY-START(4296081510)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.IMemoryCache.CreateEntry(object)
            MECM$IMemoryCache$CreateEntry()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateEntry(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081510)
            
            //--TRIMMABLE-BOUNDARY-START(12886016102)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.IMemoryCache.Remove(object)
            MECM$IMemoryCache$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12886016102)
            
            //--TRIMMABLE-BOUNDARY-START(8591048806)
            //Generated interface implemetation for Microsoft.Extensions.Caching.Memory.IMemoryCache.GetCurrentStatistics()
            MECM$IMemoryCache$GetCurrentStatistics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetCurrentStatistics(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8591048806)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25770066023)
                this._lastExpirationScan = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(25770066023)
                
                $.$finalizer(this);
            }
            static $h = 262247;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(227633528935),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734183015,
        "f": 50331650
      },
      "n": "UtcNow",
      "d": 262247,
      "h": 227633528935,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(227633528935),
//--TRIMMABLE-BOUNDARY-START(77309673575),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444647,
        "f": 50331649
      },
      "n": "Count",
      "d": 262247,
      "h": 77309673575,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309673575),
//--TRIMMABLE-BOUNDARY-START(154619084903),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379239,
        "f": 50331649
      },
      "n": "Keys",
      "d": 262247,
      "h": 154619084903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619084903),
//--TRIMMABLE-BOUNDARY-START(188978823271),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554313831,
        "f": 50331656
      },
      "n": "Size",
      "d": 262247,
      "h": 188978823271,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(188978823271),
//--TRIMMABLE-BOUNDARY-START(201863725159),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144248423,
        "f": 50331656
      },
      "n": "TrackLinkedCacheEntries",
      "d": 262247,
      "h": 201863725159,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(201863725159)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604640871),
    {
      "r": 1048678,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "CreateEntry",
      "d": 262247,
      "h": 81604640871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604640871),
//--TRIMMABLE-BOUNDARY-START(184683855975),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 131175
        }
      ],
      "n": "SetEntry",
      "d": 262247,
      "h": 184683855975,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(184683855975),
//--TRIMMABLE-BOUNDARY-START(210453659751),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "result",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 262247,
      "h": 210453659751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(210453659751),
//--TRIMMABLE-BOUNDARY-START(214748627047),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "o": "@$1",
      "d": 262247,
      "h": 214748627047,
      "f": 16777217,
      "a": [
        {
          "t": 132186113,
          "c": 8722120705,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748627047),
//--TRIMMABLE-BOUNDARY-START(219043594343),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "value",
          "p": (TItem) => TItem.$h,
          "f": 2
        }
      ],
      "g": [
        "TItem"
      ],
      "n": "TryGetValue",
      "o": "@$2",
      "d": 262247,
      "h": 219043594343,
      "f": 16908289,
      "a": [
        {
          "t": 132186113,
          "c": 8722120705,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043594343),
//--TRIMMABLE-BOUNDARY-START(167503986791),
    {
      "r": 262145,
      "p": [
        {
          "n": "coherentState",
          "p": 327783
        },
        {
          "n": "entry",
          "p": 131175
        },
        {
          "n": "result",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "PostProcessTryGetValue",
      "d": 262247,
      "h": 167503986791,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167503986791),
//--TRIMMABLE-BOUNDARY-START(171798954087),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 262247,
      "h": 171798954087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171798954087),
//--TRIMMABLE-BOUNDARY-START(64424771687),
    {
      "r": 65537,
      "n": "Clear",
      "d": 262247,
      "h": 64424771687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424771687),
//--TRIMMABLE-BOUNDARY-START(146029150311),
    {
      "r": 1310822,
      "n": "GetCurrentStatistics",
      "d": 262247,
      "h": 146029150311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029150311),
//--TRIMMABLE-BOUNDARY-START(94489542759),
    {
      "r": 65537,
      "p": [
        {
          "n": "entry",
          "p": 131175
        }
      ],
      "n": "EntryExpired",
      "d": 262247,
      "h": 94489542759,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(94489542759),
//--TRIMMABLE-BOUNDARY-START(193273790567),
    {
      "r": 65537,
      "p": [
        {
          "n": "utcNow",
          "p": 65994753
        }
      ],
      "n": "StartScanForExpiredItemsIfNeeded",
      "d": 262247,
      "h": 193273790567,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193273790567),
//--TRIMMABLE-BOUNDARY-START(197568757863),
    {
      "r": $.$$.S.ValueTuple$$$($.$$.S.Int64, $.$$.S.Int64).$h,
      "n": "Sum",
      "d": 262247,
      "h": 197568757863,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197568757863),
//--TRIMMABLE-BOUNDARY-START(150324117607),
    {
      "r": 393319,
      "n": "GetStats",
      "d": 262247,
      "h": 150324117607,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324117607),
//--TRIMMABLE-BOUNDARY-START(176093921383),
    {
      "r": 65537,
      "p": [
        {
          "n": "current",
          "p": 393319
        }
      ],
      "n": "RemoveFromStats",
      "d": 262247,
      "h": 176093921383,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176093921383),
//--TRIMMABLE-BOUNDARY-START(55834837095),
    {
      "r": 65537,
      "p": [
        {
          "n": "current",
          "p": 393319
        }
      ],
      "n": "AddToStats",
      "d": 262247,
      "h": 55834837095,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834837095),
//--TRIMMABLE-BOUNDARY-START(180388888679),
    {
      "r": 65537,
      "n": "ScanForExpiredItems",
      "d": 262247,
      "h": 180388888679,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180388888679),
//--TRIMMABLE-BOUNDARY-START(223338561639),
    {
      "r": 262145,
      "p": [
        {
          "n": "entry",
          "p": 131175
        },
        {
          "n": "priorEntry",
          "p": 131175
        },
        {
          "n": "coherentState",
          "p": 327783
        }
      ],
      "n": "UpdateCacheSizeExceedsCapacity",
      "d": 262247,
      "h": 223338561639,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338561639),
//--TRIMMABLE-BOUNDARY-START(206158692455),
    {
      "r": 65537,
      "n": "TriggerOvercapacityCompaction",
      "d": 262247,
      "h": 206158692455,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206158692455),
//--TRIMMABLE-BOUNDARY-START(163209019495),
    {
      "r": 65537,
      "n": "OvercapacityCompaction",
      "d": 262247,
      "h": 163209019495,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209019495),
//--TRIMMABLE-BOUNDARY-START(68719738983),
    {
      "r": 65537,
      "p": [
        {
          "n": "percentage",
          "p": 1179649
        }
      ],
      "n": "Compact",
      "d": 262247,
      "h": 68719738983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719738983),
//--TRIMMABLE-BOUNDARY-START(73014706279),
    {
      "r": 65537,
      "p": [
        {
          "n": "removalSizeTarget",
          "p": 917505
        },
        {
          "n": "computeEntrySize",
          "p": $.$$.S.Func$$$($.$mecm.MECM.CacheEntry, $.$$.S.Int64).$h
        },
        {
          "n": "coherentState",
          "p": 327783
        }
      ],
      "n": "Compact",
      "o": "@$1",
      "d": 262247,
      "h": 73014706279,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014706279),
//--TRIMMABLE-BOUNDARY-START(85899608167),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 262247,
      "h": 85899608167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899608167),
//--TRIMMABLE-BOUNDARY-START(90194575463),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 262247,
      "h": 90194575463,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90194575463),
//--TRIMMABLE-BOUNDARY-START(60129804391),
    {
      "r": 65537,
      "n": "CheckDisposed",
      "d": 262247,
      "h": 60129804391,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60129804391)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065033319),
    {
      "t": 917592,
      "n": "_logger",
      "d": 262247,
      "h": 30065033319,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065033319),
//--TRIMMABLE-BOUNDARY-START(34360000615),
    {
      "t": 458855,
      "n": "_options",
      "d": 262247,
      "h": 34360000615,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360000615),
//--TRIMMABLE-BOUNDARY-START(12885164135),
    {
      "t": $.$$.SCG.List$$($.$$.S.WeakReference$$($.$mecm.MECM.MemoryCache.Stats)).$h,
      "n": "_allStats",
      "d": 262247,
      "h": 12885164135,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164135),
//--TRIMMABLE-BOUNDARY-START(4295229543),
    {
      "t": 917505,
      "n": "_accumulatedHits",
      "d": 262247,
      "h": 4295229543,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229543),
//--TRIMMABLE-BOUNDARY-START(8590196839),
    {
      "t": 917505,
      "n": "_accumulatedMisses",
      "d": 262247,
      "h": 8590196839,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196839),
//--TRIMMABLE-BOUNDARY-START(38654967911),
    {
      "t": $.$$.ST$1.ThreadLocal$$($.$mecm.MECM.MemoryCache.Stats).$h,
      "n": "_stats",
      "d": 262247,
      "h": 38654967911,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38654967911),
//--TRIMMABLE-BOUNDARY-START(17180131431),
    {
      "t": 327783,
      "n": "_coherentState",
      "d": 262247,
      "h": 17180131431,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180131431),
//--TRIMMABLE-BOUNDARY-START(21475098727),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 262247,
      "h": 21475098727,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475098727),
//--TRIMMABLE-BOUNDARY-START(25770066023),
    {
      "t": 65994753,
      "n": "_lastExpirationScan",
      "d": 262247,
      "h": 25770066023,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770066023),
//--TRIMMABLE-BOUNDARY-START(158914052199),
    {
      "t": 655361,
      "n": "lockFlag",
      "d": 262247,
      "h": 158914052199,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(158914052199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51539869799),
    {
      "p": [
        {
          "n": "optionsAccessor",
          "p": $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryCacheOptions).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262247,
      "h": 51539869799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539869799),
//--TRIMMABLE-BOUNDARY-START(47244902503),
    {
      "p": [
        {
          "n": "optionsAccessor",
          "p": $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryCacheOptions).$h
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262247,
      "h": 47244902503,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244902503)
  ],
  "h": 262247
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.MECM.IMemoryCache, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mecm.MECM.MemoryCache.Stats, $.$mecm.MECM.MemoryCache.CoherentState ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262247)
        
        

        //--TRIMMABLE-BOUNDARY-START(524391)
        $asm.$cls(`$mecm.MECM.MemoryDistributedCacheOptions`, ($self) => class MemoryDistributedCacheOptions extends $.$mecm.MECM.MemoryCacheOptions
        {
            //--TRIMMABLE-BOUNDARY-START(4295491687)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491687);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SizeLimit = ((((200 * 1024) | 0) * 1024) | 0);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491687)
            
            //--TRIMMABLE-BOUNDARY-START(4295491687)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491687)
            
            static $h = 524391;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mecm.MECM.MemoryCacheOptions; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491687),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524391,
      "h": 4295491687,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491687)
  ],
  "h": 524391
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.MEO.IOptions$$($.$mecm.MECM.MemoryCacheOptions) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Caching.Memory.MemoryDistributedCacheOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Caching${separator}Memory${separator}MemoryDistributedCacheOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524391)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.Microsoft.Extensions.Caching.Abstractions", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"));
})();
//--TRIMMABLE-BOUNDARY-END(103)
