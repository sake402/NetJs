
//--TRIMMABLE-BOUNDARY-START(94)
(function ($global, $, $$, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Abstractions", 
    {
  "h": 94,
  "f": "Microsoft.Extensions.Configuration.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(786526)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationSource", ($self) => class IConfigurationSource
        {
            static $h = 786526;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295753822),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "o": "Microsoft$Extensions$Configuration$IConfigurationSource$Build",
      "d": 786526,
      "h": 4295753822,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295753822)
  ],
  "h": 786526
}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786526)
        
        
        //--TRIMMABLE-BOUNDARY-START(589918)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationProvider", ($self) => class IConfigurationProvider
        {
            static $h = 589918;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475426398),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGet",
      "o": "Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet",
      "d": 589918,
      "h": 21475426398,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475426398),
//--TRIMMABLE-BOUNDARY-START(17180459102),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "o": "Microsoft$Extensions$Configuration$IConfigurationProvider$Set",
      "d": 589918,
      "h": 17180459102,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180459102),
//--TRIMMABLE-BOUNDARY-START(8590524510),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "o": "Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken",
      "d": 589918,
      "h": 8590524510,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590524510),
//--TRIMMABLE-BOUNDARY-START(12885491806),
    {
      "r": 65537,
      "n": "Load",
      "o": "Microsoft$Extensions$Configuration$IConfigurationProvider$Load",
      "d": 589918,
      "h": 12885491806,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885491806),
//--TRIMMABLE-BOUNDARY-START(4295557214),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "earlierKeys",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        },
        {
          "n": "parentPath",
          "p": 1310721
        }
      ],
      "n": "GetChildKeys",
      "o": "Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys",
      "d": 589918,
      "h": 4295557214,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295557214)
  ],
  "h": 589918
}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589918)
        
        
        //--TRIMMABLE-BOUNDARY-START(458846)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder", ($self) => class IConfigurationBuilder
        {
            static $h = 458846;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065229918),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328030,
        "f": 50331905
      },
      "n": "Properties",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties",
      "d": 458846,
      "h": 30065229918,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065229918),
//--TRIMMABLE-BOUNDARY-START(34360197214),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262622,
        "f": 50331905
      },
      "n": "Sources",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources",
      "d": 458846,
      "h": 34360197214,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360197214)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295426142),
    {
      "r": 458846,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Add",
      "d": 458846,
      "h": 4295426142,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295426142),
//--TRIMMABLE-BOUNDARY-START(8590393438),
    {
      "r": 655454,
      "n": "Build",
      "o": "Microsoft$Extensions$Configuration$IConfigurationBuilder$Build",
      "d": 458846,
      "h": 8590393438,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590393438)
  ],
  "h": 458846
}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458846)
        
        
        //--TRIMMABLE-BOUNDARY-START(393310)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfiguration", ($self) => class IConfiguration
        {
            //--TRIMMABLE-BOUNDARY-START(34360131678)
            //--TRIMMABLE-BOUNDARY-END(34360131678)
            
            static $h = 393310;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360131678),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590327902,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065164382,
        "f": 83886337
      },
      "n": "Item",
      "o": "Microsoft$Extensions$Configuration$IConfiguration$Item",
      "d": 393310,
      "h": 34360131678,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360131678)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475229790),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "o": "Microsoft$Extensions$Configuration$IConfiguration$GetSection",
      "d": 393310,
      "h": 21475229790,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475229790),
//--TRIMMABLE-BOUNDARY-START(12885295198),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,
      "n": "GetChildren",
      "o": "Microsoft$Extensions$Configuration$IConfiguration$GetChildren",
      "d": 393310,
      "h": 12885295198,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885295198),
//--TRIMMABLE-BOUNDARY-START(17180262494),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "o": "Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken",
      "d": 393310,
      "h": 17180262494,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180262494)
  ],
  "h": 393310
}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393310)
        
        
        //--TRIMMABLE-BOUNDARY-START(720990)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationSection", ($self) => class IConfigurationSection
        {
            static $h = 720990;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590655582,
        "f": 50331905
      },
      "n": "Key",
      "o": "Microsoft$Extensions$Configuration$IConfigurationSection$Key",
      "d": 720990,
      "h": 30065492062,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065492062),
//--TRIMMABLE-BOUNDARY-START(34360459358),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180590174,
        "f": 50331905
      },
      "n": "Path",
      "o": "Microsoft$Extensions$Configuration$IConfigurationSection$Path",
      "d": 720990,
      "h": 34360459358,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360459358),
//--TRIMMABLE-BOUNDARY-START(47245361246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770524766,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950393950,
        "f": 83886337
      },
      "n": "Value",
      "o": "Microsoft$Extensions$Configuration$IConfigurationSection$Value",
      "d": 720990,
      "h": 47245361246,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47245361246)
  ],
  "i": [393310
  ],
  "h": 720990
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720990)
        
        
        //--TRIMMABLE-BOUNDARY-START(655454)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationRoot", ($self) => class IConfigurationRoot
        {
            static $h = 655454;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885557342),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590590046,
        "f": 50331905
      },
      "n": "Providers",
      "o": "Microsoft$Extensions$Configuration$IConfigurationRoot$Providers",
      "d": 655454,
      "h": 12885557342,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885557342)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524638),
    {
      "r": 65537,
      "n": "Reload",
      "o": "Microsoft$Extensions$Configuration$IConfigurationRoot$Reload",
      "d": 655454,
      "h": 17180524638,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180524638)
  ],
  "i": [393310
  ],
  "h": 655454
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationRoot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655454)
        
        
        //--TRIMMABLE-BOUNDARY-START(524382)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationManager", ($self) => class IConfigurationManager
        {
            static $h = 524382;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "i": [393310,458846
  ],
  "h": 524382
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder ]; }
            static get $fullName() { return `IConfigurationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524382)
        
        
        //--TRIMMABLE-BOUNDARY-START(852062)
        $asm.$cls("$meca.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103080067166)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(103080067166)
            
            //--TRIMMABLE-BOUNDARY-START(94490132574)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(94490132574)
            
            //--TRIMMABLE-BOUNDARY-START(98785099870)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$meca.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Abstractions", $.$meca.System.SR.$type.Assembly);
                    $.$meca.System.SR.s_resourceManager = temp;
                }
                return $.$meca.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099870)
            
            //--TRIMMABLE-BOUNDARY-START(8590786654)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meca.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meca.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786654)
            
            //--TRIMMABLE-BOUNDARY-START(90195165278)
            static /*string */ get InvalidSectionName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Section '{0}' not found in configuration.";
            }
            //--TRIMMABLE-BOUNDARY-END(90195165278)
            
            //--TRIMMABLE-BOUNDARY-START(47245492318)
            static /*string */ FormatInvalidSectionName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Section '{0}' not found in configuration.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47245492318)
            
            //--TRIMMABLE-BOUNDARY-START(107375034462)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(107375034462)
            
            //--TRIMMABLE-BOUNDARY-START(85900197982)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900197982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900197982)
            
            //--TRIMMABLE-BOUNDARY-START(120259936350)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259936350);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meca.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259936350)
            
            //--TRIMMABLE-BOUNDARY-START(81605230686)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meca.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230686)
            
            //--TRIMMABLE-BOUNDARY-START(77310263390)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$meca.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263390)
            
            //--TRIMMABLE-BOUNDARY-START(38655557726)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655557726)
            
            //--TRIMMABLE-BOUNDARY-START(34360590430)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360590430)
            
            //--TRIMMABLE-BOUNDARY-START(30065623134)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065623134)
            
            //--TRIMMABLE-BOUNDARY-START(42950525022)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525022)
            
            //--TRIMMABLE-BOUNDARY-START(21475688542)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475688542)
            
            //--TRIMMABLE-BOUNDARY-START(17180721246)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721246)
            
            //--TRIMMABLE-BOUNDARY-START(12885753950)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753950)
            
            //--TRIMMABLE-BOUNDARY-START(25770655838)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655838)
            
            //--TRIMMABLE-BOUNDARY-START(4295819358)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(107375034462)
                    this.s_usingResourceKeys = $.$meca.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(107375034462)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819358)
            
            static $h = 852062;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 852062
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852062)
        
        
        //--TRIMMABLE-BOUNDARY-START(262238)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationPath", ($self) => class ConfigurationPath
        {
            //--TRIMMABLE-BOUNDARY-START(25770066014)
            /*string*/ static KeyDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(25770066014)
            
            //--TRIMMABLE-BOUNDARY-START(12885164126)
            static /*string */ Combine$1(/*params string[]*/ pathSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(pathSegments, "pathSegments");
                return $.$$.System.String.Join$10($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164126)
            
            //--TRIMMABLE-BOUNDARY-START(8590196830)
            static /*string */ Combine(/*IEnumerable<string>*/ pathSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(pathSegments, "pathSegments");
                return $.$$.System.String.Join$5($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196830)
            
            //--TRIMMABLE-BOUNDARY-START(21475098718)
            static /*string? */ GetSectionKey(/*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(path))
                {
                    return path;
                }
                /*int*/ let lastDelimiterIndex = $.$$.System.String.LastIndexOf$2.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? path : $.$$.System.String.Substring$1.call(path, ((lastDelimiterIndex + 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(21475098718)
            
            //--TRIMMABLE-BOUNDARY-START(17180131422)
            static /*string? */ GetParentPath(/*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(path))
                {
                    return null;
                }
                /*int*/ let lastDelimiterIndex = $.$$.System.String.LastIndexOf$2.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? null : $.$$.System.String.Substring.call(path, 0, lastDelimiterIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131422)
            
            //--TRIMMABLE-BOUNDARY-START(4295229534)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770066014)
                    this.KeyDelimiter = ":";
                    //--TRIMMABLE-BOUNDARY-END(25770066014)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229534)
            
            static $h = 262238;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164126),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pathSegments",
          "p": $.$typeArray($.$$.System.String).$h,
          "f": 16
        }
      ],
      "n": "Combine",
      "o": "@$1",
      "d": 262238,
      "h": 12885164126,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164126),
//--TRIMMABLE-BOUNDARY-START(8590196830),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pathSegments",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Combine",
      "d": 262238,
      "h": 8590196830,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196830),
//--TRIMMABLE-BOUNDARY-START(21475098718),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetSectionKey",
      "d": 262238,
      "h": 21475098718,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098718),
//--TRIMMABLE-BOUNDARY-START(17180131422),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetParentPath",
      "d": 262238,
      "h": 17180131422,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180131422)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770066014),
    {
      "t": 1310721,
      "n": "KeyDelimiter",
      "d": 262238,
      "h": 25770066014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066014)
  ],
  "h": 262238
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationPath`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262238)
        
        
        //--TRIMMABLE-BOUNDARY-START(131166)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions", ($self) => class ConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098462)
            static /*IConfigurationBuilder */ Add(TSource, /*this IConfigurationBuilder*/ builder, /*Action<TSource>?*/ configureSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let source = new TSource().$ctor();
                configureSource?.Invoke(source);
                return builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Add($.$box(source, TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(4295098462)
            
            //--TRIMMABLE-BOUNDARY-START(21474967646)
            static /*string? */ GetConnectionString(/*this IConfiguration*/ configuration, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return configuration?.Microsoft$Extensions$Configuration$IConfiguration$GetSection("ConnectionStrings").Microsoft$Extensions$Configuration$IConfiguration$get_Item(name) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967646)
            
            //--TRIMMABLE-BOUNDARY-START(12885033054)
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable$1(/*this IConfiguration*/ configuration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033054);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.AsEnumerable(configuration, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033054)
            
            //--TRIMMABLE-BOUNDARY-START(8590065758)
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable(/*this IConfiguration*/ configuration, /*bool*/ makePathsRelative)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$meca.Microsoft.Extensions.Configuration.IConfiguration))().$ctor$1();
                    stack.Push(configuration);
                    let rootSection;
                    /*int*/ let prefixLength = (makePathsRelative && $.$is(configuration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, { set $v(v){ rootSection = v; } })) ? ((rootSection.Microsoft$Extensions$Configuration$IConfigurationSection$Path.length + 1) | 0) : 0;
                    while(stack.Count > 0)
                    {
                        /*IConfiguration*/ let config = stack.Pop();
                        let section;
                        if ($.$is(config, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, { set $v(v){ section = v; } }) && (!makePathsRelative || config !== configuration))
                        {
                            yield new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$$.System.String.Substring$1.call(section.Microsoft$Extensions$Configuration$IConfigurationSection$Path, prefixLength), section.Microsoft$Extensions$Configuration$IConfigurationSection$Value);
                        }
                        var $en4 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var child = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                stack.Push(child);
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(8590065758)
            
            //--TRIMMABLE-BOUNDARY-START(17180000350)
            static /*bool */ Exists(/*this IConfigurationSection?*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (section === null)
                {
                    return false;
                }
                return $.$$.System.String.op_Inequality(section.Microsoft$Extensions$Configuration$IConfigurationSection$Value, null) || $.$sl.System.Linq.Enumerable.Any$1($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, section.Microsoft$Extensions$Configuration$IConfiguration$GetChildren());
            }
            //--TRIMMABLE-BOUNDARY-END(17180000350)
            
            //--TRIMMABLE-BOUNDARY-START(25769934942)
            static /*IConfigurationSection */ GetRequiredSection(/*this IConfiguration*/ configuration, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                /*IConfigurationSection*/ let section = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key);
                if ($.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Exists(section))
                {
                    return section;
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$meca.System.SR.Format$6($.$meca.System.SR.InvalidSectionName, key));
            }
            //--TRIMMABLE-BOUNDARY-END(25769934942)
            
            static $h = 131166;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098462),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "configureSource",
          "p": (TSource) => $.$$.System.Action$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Add",
      "d": 131166,
      "h": 4295098462,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098462),
//--TRIMMABLE-BOUNDARY-START(21474967646),
    {
      "r": 1310721,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetConnectionString",
      "d": 131166,
      "h": 21474967646,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474967646),
//--TRIMMABLE-BOUNDARY-START(12885033054),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "n": "AsEnumerable",
      "o": "@$1",
      "d": 131166,
      "h": 12885033054,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885033054),
//--TRIMMABLE-BOUNDARY-START(8590065758),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "makePathsRelative",
          "p": 262145
        }
      ],
      "n": "AsEnumerable",
      "d": 131166,
      "h": 8590065758,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065758),
//--TRIMMABLE-BOUNDARY-START(17180000350),
    {
      "r": 262145,
      "p": [
        {
          "n": "section",
          "p": 720990
        }
      ],
      "n": "Exists",
      "d": 131166,
      "h": 17180000350,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180000350),
//--TRIMMABLE-BOUNDARY-START(25769934942),
    {
      "r": 720990,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetRequiredSection",
      "d": 131166,
      "h": 25769934942,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934942)
  ],
  "h": 131166
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131166)
        
        
        //--TRIMMABLE-BOUNDARY-START(196702)
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute", ($self) => class ConfigurationKeyNameAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590131294)
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131294);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131294)
            
            //--TRIMMABLE-BOUNDARY-START(21475033182)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21475033182)
            
            static $h = 196702;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475033182),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180065886,
        "f": 50331649
      },
      "n": "Name",
      "d": 196702,
      "h": 21475033182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475033182)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131294),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196702,
      "h": 8590131294,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131294)
  ],
  "h": 196702,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 128,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196702)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))
//--TRIMMABLE-BOUNDARY-END(94)
