
//--TRIMMABLE-BOUNDARY-START(94)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Abstractions", 
    {
  "h": 94,
  "f": "Microsoft.Extensions.Configuration.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(393310)
        $asm.$cls(`$mecga.MEC.IConfiguration`, ($self) => class IConfiguration
        {
            //--TRIMMABLE-BOUNDARY-START(34360131678)
            //--TRIMMABLE-BOUNDARY-END(34360131678)
            
            static $h = 393310;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360131678),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590327902,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065164382,
        "f": 83886337
      },
      "n": "Item",
      "o": "MEC$IConfiguration$Item",
      "d": 393310,
      "h": 34360131678,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360131678)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475229790),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "o": "MEC$IConfiguration$GetSection",
      "d": 393310,
      "h": 21475229790,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475229790),
//--TRIMMABLE-BOUNDARY-START(12885295198),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSection).$h,
      "n": "GetChildren",
      "o": "MEC$IConfiguration$GetChildren",
      "d": 393310,
      "h": 12885295198,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885295198),
//--TRIMMABLE-BOUNDARY-START(17180262494),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "o": "MEC$IConfiguration$GetReloadToken",
      "d": 393310,
      "h": 17180262494,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180262494)
  ],
  "h": 393310
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393310)
        
        

        //--TRIMMABLE-BOUNDARY-START(458846)
        $asm.$cls(`$mecga.MEC.IConfigurationBuilder`, ($self) => class IConfigurationBuilder
        {
            static $h = 458846;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065229918),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328030,
        "f": 50331905
      },
      "n": "Properties",
      "o": "MEC$IConfigurationBuilder$Properties",
      "d": 458846,
      "h": 30065229918,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065229918),
//--TRIMMABLE-BOUNDARY-START(34360197214),
    {
      "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262622,
        "f": 50331905
      },
      "n": "Sources",
      "o": "MEC$IConfigurationBuilder$Sources",
      "d": 458846,
      "h": 34360197214,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360197214)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295426142),
    {
      "r": 458846,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "o": "MEC$IConfigurationBuilder$Add",
      "d": 458846,
      "h": 4295426142,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295426142),
//--TRIMMABLE-BOUNDARY-START(8590393438),
    {
      "r": 655454,
      "n": "Build",
      "o": "MEC$IConfigurationBuilder$Build",
      "d": 458846,
      "h": 8590393438,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590393438)
  ],
  "h": 458846
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458846)
        
        

        //--TRIMMABLE-BOUNDARY-START(786526)
        $asm.$cls(`$mecga.MEC.IConfigurationSource`, ($self) => class IConfigurationSource
        {
            static $h = 786526;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295753822),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "o": "MEC$IConfigurationSource$Build",
      "d": 786526,
      "h": 4295753822,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295753822)
  ],
  "h": 786526
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786526)
        
        

        //--TRIMMABLE-BOUNDARY-START(589918)
        $asm.$cls(`$mecga.MEC.IConfigurationProvider`, ($self) => class IConfigurationProvider
        {
            static $h = 589918;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475426398),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGet",
      "o": "MEC$IConfigurationProvider$TryGet",
      "d": 589918,
      "h": 21475426398,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475426398),
//--TRIMMABLE-BOUNDARY-START(17180459102),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "o": "MEC$IConfigurationProvider$Set",
      "d": 589918,
      "h": 17180459102,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180459102),
//--TRIMMABLE-BOUNDARY-START(8590524510),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "o": "MEC$IConfigurationProvider$GetReloadToken",
      "d": 589918,
      "h": 8590524510,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590524510),
//--TRIMMABLE-BOUNDARY-START(12885491806),
    {
      "r": 65537,
      "n": "Load",
      "o": "MEC$IConfigurationProvider$Load",
      "d": 589918,
      "h": 12885491806,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885491806),
//--TRIMMABLE-BOUNDARY-START(4295557214),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "earlierKeys",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "parentPath",
          "p": 1310721
        }
      ],
      "n": "GetChildKeys",
      "o": "MEC$IConfigurationProvider$GetChildKeys",
      "d": 589918,
      "h": 4295557214,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295557214)
  ],
  "h": 589918
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589918)
        
        

        //--TRIMMABLE-BOUNDARY-START(720990)
        $asm.$cls(`$mecga.MEC.IConfigurationSection`, ($self) => class IConfigurationSection
        {
            static $h = 720990;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065492062),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590655582,
        "f": 50331905
      },
      "n": "Key",
      "o": "MEC$IConfigurationSection$Key",
      "d": 720990,
      "h": 30065492062,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065492062),
//--TRIMMABLE-BOUNDARY-START(34360459358),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180590174,
        "f": 50331905
      },
      "n": "Path",
      "o": "MEC$IConfigurationSection$Path",
      "d": 720990,
      "h": 34360459358,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360459358),
//--TRIMMABLE-BOUNDARY-START(47245361246),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770524766,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950393950,
        "f": 83886337
      },
      "n": "Value",
      "o": "MEC$IConfigurationSection$Value",
      "d": 720990,
      "h": 47245361246,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47245361246)
  ],
  "h": 720990
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfiguration ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720990)
        
        

        //--TRIMMABLE-BOUNDARY-START(655454)
        $asm.$cls(`$mecga.MEC.IConfigurationRoot`, ($self) => class IConfigurationRoot
        {
            static $h = 655454;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885557342),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590590046,
        "f": 50331905
      },
      "n": "Providers",
      "o": "MEC$IConfigurationRoot$Providers",
      "d": 655454,
      "h": 12885557342,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885557342)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524638),
    {
      "r": 65537,
      "n": "Reload",
      "o": "MEC$IConfigurationRoot$Reload",
      "d": 655454,
      "h": 17180524638,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180524638)
  ],
  "h": 655454
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfiguration ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationRoot`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationRoot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655454)
        
        

        //--TRIMMABLE-BOUNDARY-START(524382)
        $asm.$cls(`$mecga.MEC.IConfigurationManager`, ($self) => class IConfigurationManager
        {
            static $h = 524382;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 524382
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfiguration, $.$mecga.MEC.IConfigurationBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.IConfigurationManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}IConfigurationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524382)
        
        

        //--TRIMMABLE-BOUNDARY-START(852062)
        $asm.$cls(`$mecga.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103080067166)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(103080067166)
            
            //--TRIMMABLE-BOUNDARY-START(94490132574)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(94490132574)
            
            //--TRIMMABLE-BOUNDARY-START(98785099870)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mecga.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Abstractions", $.$mecga.S.SR.$type.Assembly);
                    $.$mecga.S.SR.s_resourceManager = temp;
                }
                return $.$mecga.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099870)
            
            //--TRIMMABLE-BOUNDARY-START(8590786654)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecga.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecga.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786654)
            
            //--TRIMMABLE-BOUNDARY-START(90195165278)
            static /*string */ get InvalidSectionName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Section '{0}' not found in configuration.";
            }
            //--TRIMMABLE-BOUNDARY-END(90195165278)
            
            //--TRIMMABLE-BOUNDARY-START(47245492318)
            static /*string */ FormatInvalidSectionName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Section '{0}' not found in configuration.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(47245492318)
            
            //--TRIMMABLE-BOUNDARY-START(107375034462)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(107375034462)
            
            //--TRIMMABLE-BOUNDARY-START(85900197982)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900197982);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900197982)
            
            //--TRIMMABLE-BOUNDARY-START(120259936350)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259936350);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecga.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259936350)
            
            //--TRIMMABLE-BOUNDARY-START(81605230686)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecga.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230686)
            
            //--TRIMMABLE-BOUNDARY-START(77310263390)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecga.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263390)
            
            //--TRIMMABLE-BOUNDARY-START(38655557726)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655557726)
            
            //--TRIMMABLE-BOUNDARY-START(34360590430)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360590430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360590430)
            
            //--TRIMMABLE-BOUNDARY-START(30065623134)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065623134)
            
            //--TRIMMABLE-BOUNDARY-START(42950525022)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecga.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525022)
            
            //--TRIMMABLE-BOUNDARY-START(21475688542)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475688542)
            
            //--TRIMMABLE-BOUNDARY-START(17180721246)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721246)
            
            //--TRIMMABLE-BOUNDARY-START(12885753950)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecga.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753950)
            
            //--TRIMMABLE-BOUNDARY-START(25770655838)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecga.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655838)
            
            //--TRIMMABLE-BOUNDARY-START(4295819358)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(107375034462)
                    this.s_usingResourceKeys = $.$mecga.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(107375034462)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819358)
            
            static $h = 852062;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 852062
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852062)
        
        

        //--TRIMMABLE-BOUNDARY-START(262238)
        $asm.$cls(`$mecga.MEC.ConfigurationPath`, ($self) => class ConfigurationPath
        {
            //--TRIMMABLE-BOUNDARY-START(25770066014)
            /*string*/ static KeyDelimiter = null;
            //--TRIMMABLE-BOUNDARY-END(25770066014)
            
            //--TRIMMABLE-BOUNDARY-START(12885164126)
            static /*string */ Combine$1(/*params string[]*/ pathSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(pathSegments, "pathSegments");
                return $.$$.S.String.Join$10($.$mecga.MEC.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164126)
            
            //--TRIMMABLE-BOUNDARY-START(8590196830)
            static /*string */ Combine(/*IEnumerable<string>*/ pathSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(pathSegments, "pathSegments");
                return $.$$.S.String.Join$5($.$mecga.MEC.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196830)
            
            //--TRIMMABLE-BOUNDARY-START(21475098718)
            static /*string? */ GetSectionKey(/*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(path))
                {
                    return path;
                }
                /*int*/ let lastDelimiterIndex = $.$$.S.String.LastIndexOf$2.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? path : path.slice(((lastDelimiterIndex + 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(21475098718)
            
            //--TRIMMABLE-BOUNDARY-START(17180131422)
            static /*string? */ GetParentPath(/*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(path))
                {
                    return null;
                }
                /*int*/ let lastDelimiterIndex = $.$$.S.String.LastIndexOf$2.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? null : path.substr(0, lastDelimiterIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131422)
            
            //--TRIMMABLE-BOUNDARY-START(4295229534)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(25770066014)
                    this.KeyDelimiter = ":";
                    //--TRIMMABLE-BOUNDARY-END(25770066014)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229534)
            
            static $h = 262238;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164126),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pathSegments",
          "p": $.$typeArray($.$$.S.String).$h,
          "f": 16
        }
      ],
      "n": "Combine",
      "o": "@$1",
      "d": 262238,
      "h": 12885164126,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164126),
//--TRIMMABLE-BOUNDARY-START(8590196830),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pathSegments",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        }
      ],
      "n": "Combine",
      "d": 262238,
      "h": 8590196830,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196830),
//--TRIMMABLE-BOUNDARY-START(21475098718),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetSectionKey",
      "d": 262238,
      "h": 21475098718,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098718),
//--TRIMMABLE-BOUNDARY-START(17180131422),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetParentPath",
      "d": 262238,
      "h": 17180131422,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180131422)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770066014),
    {
      "t": 1310721,
      "n": "KeyDelimiter",
      "d": 262238,
      "h": 25770066014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066014)
  ],
  "h": 262238
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationPath`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationPath`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262238)
        
        

        //--TRIMMABLE-BOUNDARY-START(131166)
        $asm.$cls(`$mecga.MEC.ConfigurationExtensions`, ($self) => class ConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098462)
            static /*IConfigurationBuilder */ Add(TSource, /*this IConfigurationBuilder*/ builder, /*Action<TSource>?*/ configureSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let source = new TSource().$gctor();
                configureSource?.Invoke(source);
                return builder.MEC$IConfigurationBuilder$Add($.$box(source, TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(4295098462)
            
            //--TRIMMABLE-BOUNDARY-START(21474967646)
            static /*string? */ GetConnectionString(/*this IConfiguration*/ configuration, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return configuration?.MEC$IConfiguration$GetSection("ConnectionStrings").MEC$IConfiguration$get_Item(name) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967646)
            
            //--TRIMMABLE-BOUNDARY-START(12885033054)
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable$1(/*this IConfiguration*/ configuration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033054);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecga.MEC.ConfigurationExtensions.AsEnumerable(configuration, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885033054)
            
            //--TRIMMABLE-BOUNDARY-START(8590065758)
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable(/*this IConfiguration*/ configuration, /*bool*/ makePathsRelative)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)))().$ctor$1(function*()
                {
                    /*var*/ let stack = new ($.$sc.SCG.Stack$$($.$mecga.MEC.IConfiguration))().$ctor$1();
                    stack.Push(configuration);
                    let rootSection;
                    /*int*/ let prefixLength = (makePathsRelative && $.$is(configuration, $.$mecga.MEC.IConfigurationSection, { set $v($v){ rootSection = $v; } })) ? ((rootSection.MEC$IConfigurationSection$Path.length + 1) | 0) : 0;
                    while(stack.Count > 0)
                    {
                        /*IConfiguration*/ let config = stack.Pop();
                        let section;
                        if ($.$is(config, $.$mecga.MEC.IConfigurationSection, { set $v($v){ section = $v; } }) && (!makePathsRelative || config !== configuration))
                        {
                            yield new ($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String))().$ctor$3(section.MEC$IConfigurationSection$Path.slice(prefixLength), section.MEC$IConfigurationSection$Value);
                        }
                        let $en1 = config.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let child = $en1.SCG$IEnumerator$$$Current;
                            {
                                stack.Push(child);
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(8590065758)
            
            //--TRIMMABLE-BOUNDARY-START(17180000350)
            static /*bool */ Exists(/*this IConfigurationSection?*/ section)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (section === null)
                {
                    return false;
                }
                return section.MEC$IConfigurationSection$Value !== null || $.$sl.SL.Enumerable.Any$1($.$mecga.MEC.IConfigurationSection, section.MEC$IConfiguration$GetChildren());
            }
            //--TRIMMABLE-BOUNDARY-END(17180000350)
            
            //--TRIMMABLE-BOUNDARY-START(25769934942)
            static /*IConfigurationSection */ GetRequiredSection(/*this IConfiguration*/ configuration, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                /*IConfigurationSection*/ let section = configuration.MEC$IConfiguration$GetSection(key);
                if ($.$mecga.MEC.ConfigurationExtensions.Exists(section))
                {
                    return section;
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecga.S.SR.Format$6($.$mecga.S.SR.InvalidSectionName, key));
            }
            //--TRIMMABLE-BOUNDARY-END(25769934942)
            
            static $h = 131166;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098462),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "configureSource",
          "p": (TSource) => $.$$.S.Action$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Add",
      "d": 131166,
      "h": 4295098462,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295098462),
//--TRIMMABLE-BOUNDARY-START(21474967646),
    {
      "r": 1310721,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetConnectionString",
      "d": 131166,
      "h": 21474967646,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474967646),
//--TRIMMABLE-BOUNDARY-START(12885033054),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "n": "AsEnumerable",
      "o": "@$1",
      "d": 131166,
      "h": 12885033054,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885033054),
//--TRIMMABLE-BOUNDARY-START(8590065758),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "makePathsRelative",
          "p": 262145
        }
      ],
      "n": "AsEnumerable",
      "d": 131166,
      "h": 8590065758,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065758),
//--TRIMMABLE-BOUNDARY-START(17180000350),
    {
      "r": 262145,
      "p": [
        {
          "n": "section",
          "p": 720990
        }
      ],
      "n": "Exists",
      "d": 131166,
      "h": 17180000350,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180000350),
//--TRIMMABLE-BOUNDARY-START(25769934942),
    {
      "r": 720990,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetRequiredSection",
      "d": 131166,
      "h": 25769934942,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934942)
  ],
  "h": 131166
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131166)
        
        

        //--TRIMMABLE-BOUNDARY-START(196702)
        $asm.$cls(`$mecga.MEC.ConfigurationKeyNameAttribute`, ($self) => class ConfigurationKeyNameAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590131294)
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131294);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131294)
            
            //--TRIMMABLE-BOUNDARY-START(21475033182)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21475033182)
            
            static $h = 196702;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475033182),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180065886,
        "f": 50331649
      },
      "n": "Name",
      "d": 196702,
      "h": 21475033182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475033182)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131294),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196702,
      "h": 8590131294,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131294)
  ],
  "h": 196702,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 128,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationKeyNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196702)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"));
})();
//--TRIMMABLE-BOUNDARY-END(94)
