
(function ($global, $, $spc, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Abstractions", 
    {"h":14,"f":"Microsoft.Extensions.Configuration.Abstractions","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Abstractions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder", ($self) => class IConfigurationBuilder
        {
            static $h = 327694;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":8590262286,"f":257},"n":"Properties","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties","d":327694,"h":4295294990,"f":257},{"p":$.$spc.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"g":{"r":0,"d":0,"h":17180196878,"f":257},"n":"Sources","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources","d":327694,"h":12885229582,"f":257}],"m":[{"r":327694,"p":[{"n":"source","p":655374}],"n":"Add","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Add","d":327694,"h":21475164174,"f":257},{"r":524302,"n":"Build","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Build","d":327694,"h":25770131470,"f":257}],"h":327694}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationBuilder`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfiguration", ($self) => class IConfiguration
        {
            static $h = 262158;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":8590196750,"f":257},"s":{"r":0,"d":0,"h":12885164046,"f":257},"n":"Item","o":"Microsoft$Extensions$Configuration$IConfiguration$Item","d":262158,"h":4295229454,"f":257}],"m":[{"r":589838,"p":[{"n":"key","p":1310721}],"n":"GetSection","o":"Microsoft$Extensions$Configuration$IConfiguration$GetSection","d":262158,"h":17180131342,"f":257},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,"n":"GetChildren","o":"Microsoft$Extensions$Configuration$IConfiguration$GetChildren","d":262158,"h":21475098638,"f":257},{"r":720898,"n":"GetReloadToken","o":"Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken","d":262158,"h":25770065934,"f":257}],"h":262158}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfiguration`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationSource", ($self) => class IConfigurationSource
        {
            static $h = 655374;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","o":"Microsoft$Extensions$Configuration$IConfigurationSource$Build","d":655374,"h":4295622670,"f":257}],"h":655374}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationSource`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationProvider", ($self) => class IConfigurationProvider
        {
            static $h = 458766;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721,"f":2}],"n":"TryGet","o":"Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet","d":458766,"h":4295426062,"f":257},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Set","o":"Microsoft$Extensions$Configuration$IConfigurationProvider$Set","d":458766,"h":8590393358,"f":257},{"r":720898,"n":"GetReloadToken","o":"Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken","d":458766,"h":12885360654,"f":257},{"r":65537,"n":"Load","o":"Microsoft$Extensions$Configuration$IConfigurationProvider$Load","d":458766,"h":17180327950,"f":257},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"earlierKeys","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h},{"n":"parentPath","p":1310721}],"n":"GetChildKeys","o":"Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys","d":458766,"h":21475295246,"f":257}],"h":458766}; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationProvider`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationRoot", ($self) => class IConfigurationRoot
        {
            static $h = 524302;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":12885426190,"f":257},"n":"Providers","o":"Microsoft$Extensions$Configuration$IConfigurationRoot$Providers","d":524302,"h":8590458894,"f":257}],"m":[{"r":65537,"n":"Reload","o":"Microsoft$Extensions$Configuration$IConfigurationRoot$Reload","d":524302,"h":4295491598,"f":257}],"i":[262158],"h":524302}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationRoot`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationSection", ($self) => class IConfigurationSection
        {
            static $h = 589838;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590524430,"f":257},"n":"Key","o":"Microsoft$Extensions$Configuration$IConfigurationSection$Key","d":589838,"h":4295557134,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":17180459022,"f":257},"n":"Path","o":"Microsoft$Extensions$Configuration$IConfigurationSection$Path","d":589838,"h":12885491726,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":25770393614,"f":257},"s":{"r":0,"d":0,"h":30065360910,"f":257},"n":"Value","o":"Microsoft$Extensions$Configuration$IConfigurationSection$Value","d":589838,"h":21475426318,"f":257}],"i":[262158],"h":589838}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.IConfigurationSection`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.IConfigurationManager", ($self) => class IConfigurationManager
        {
            static $h = 393230;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"i":[262158,327694],"h":393230}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder ]; }
            static get $fullName() { return `IConfigurationManager`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationPath", ($self) => class ConfigurationPath
        {
            /*string*/ static KeyDelimiter = null;
            static /*string */ Combine(/*params string[]*/ pathSegments)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(pathSegments, "pathSegments");
                return $.$spc.System.String.Join$2($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            static /*string */ Combine$1(/*IEnumerable<string>*/ pathSegments)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(pathSegments, "pathSegments");
                return $.$spc.System.String.Join$6($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, pathSegments);
            }
            static /*string? */ GetSectionKey(/*string?*/ path)
            {
                if ($.$spc.System.String.IsNullOrEmpty(path))
                {
                    return path;
                }
                /*int*/ let lastDelimiterIndex = $.$spc.System.String.LastIndexOf.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? path : $.$spc.System.String.Substring.call(path, ((lastDelimiterIndex + 1) | 0));
            }
            static /*string? */ GetParentPath(/*string?*/ path)
            {
                if ($.$spc.System.String.IsNullOrEmpty(path))
                {
                    return null;
                }
                /*int*/ let lastDelimiterIndex = $.$spc.System.String.LastIndexOf.call(path, /*:*/ 58);
                return lastDelimiterIndex < 0 ? null : $.$spc.System.String.Substring$1.call(path, 0, lastDelimiterIndex);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.KeyDelimiter = ":";
                }
            }
            static $h = 196622;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"pathSegments","p":0,"f":16}],"n":"Combine","d":196622,"h":8590131214,"f":33},{"r":1310721,"p":[{"n":"pathSegments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Combine","o":"@$1","d":196622,"h":12885098510,"f":33},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetSectionKey","d":196622,"h":17180065806,"f":33},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetParentPath","d":196622,"h":21475033102,"f":33}],"l":[{"t":1310721,"n":"KeyDelimiter","d":196622,"h":4295163918,"f":33}],"h":196622}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationPath`; }
        });
        
        $asm.$cls("$meca.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$meca.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meca.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$meca.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$meca.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Abstractions", $.$meca.System.SR.$type.Assembly);
                    $.$meca.System.SR.s_resourceManager = temp;
                }
                return $.$meca.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$meca.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$meca.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidSectionName()
            {
                return "Section '{0}' not found in configuration.";
            }
            static /*string */ FormatInvalidSectionName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Section '{0}' not found in configuration.", arg1);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$meca.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 720910;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":720910}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions", ($self) => class ConfigurationExtensions
        {
            static /*IConfigurationBuilder */ Add(TSource, /*this IConfigurationBuilder*/ builder, /*Action<TSource>?*/ configureSource)
            {
                /*var*/ let source = new TSource().$ctor();
                configureSource?.Invoke(source);
                return builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Add($.$box(source, TSource));
            }
            static /*string? */ GetConnectionString(/*this IConfiguration*/ configuration, /*string*/ name)
            {
                return configuration?.Microsoft$Extensions$Configuration$IConfiguration$GetSection("ConnectionStrings").Microsoft$Extensions$Configuration$IConfiguration$get_Item(name);
            }
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable(/*this IConfiguration*/ configuration)
            {
                return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.AsEnumerable$1(configuration, false);
            }
            static /*IEnumerable<KeyValuePair<string, string?>> */ AsEnumerable$1(/*this IConfiguration*/ configuration, /*bool*/ makePathsRelative)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$meca.Microsoft.Extensions.Configuration.IConfiguration))().$ctor$1();
                    stack.Push(configuration);
                    let rootSection;
                    /*int*/ let prefixLength = (makePathsRelative && $.$is(configuration, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, { set $v(v){ rootSection = v; } })) ? ((rootSection.Microsoft$Extensions$Configuration$IConfigurationSection$Path.length + 1) | 0) : 0;
                    while(stack.Count > 0)
                    {
                        /*IConfiguration*/ let config = stack.Pop();
                        let section;
                        if ($.$is(config, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, { set $v(v){ section = v; } }) && (!makePathsRelative || config !== configuration))
                        {
                            yield new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2($.$spc.System.String.Substring.call(section.Microsoft$Extensions$Configuration$IConfigurationSection$Path, prefixLength), section.Microsoft$Extensions$Configuration$IConfigurationSection$Value);
                        }
                        var $en4 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var child = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                stack.Push(child);
                            }
                        }
                    }
                }.bind(this));
            }
            static /*bool */ Exists(/*this IConfigurationSection?*/ section)
            {
                if (section === null)
                {
                    return false;
                }
                return $.$spc.System.String.op_Inequality(section.Microsoft$Extensions$Configuration$IConfigurationSection$Value, null) || $.$sl.System.Linq.Enumerable.Any($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, section.Microsoft$Extensions$Configuration$IConfiguration$GetChildren());
            }
            static /*IConfigurationSection */ GetRequiredSection(/*this IConfiguration*/ configuration, /*string*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(configuration, "configuration");
                /*IConfigurationSection*/ let section = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key);
                if ($.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Exists(section))
                {
                    return section;
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$meca.System.SR.Format($.$meca.System.SR.InvalidSectionName, key));
            }
            static $h = 65550;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"builder","p":327694},{"n":"configureSource","p":(TSource) => $.$spc.System.Action$$(TSource).$h}],"g":["TSource"],"n":"Add","d":65550,"h":4295032846,"f":131105},{"r":1310721,"p":[{"n":"configuration","p":262158},{"n":"name","p":1310721}],"n":"GetConnectionString","d":65550,"h":8590000142,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h,"p":[{"n":"configuration","p":262158}],"n":"AsEnumerable","d":65550,"h":12884967438,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)).$h,"p":[{"n":"configuration","p":262158},{"n":"makePathsRelative","p":262145}],"n":"AsEnumerable","o":"@$1","d":65550,"h":17179934734,"f":33},{"r":262145,"p":[{"n":"section","p":589838}],"n":"Exists","d":65550,"h":21474902030,"f":33},{"r":589838,"p":[{"n":"configuration","p":262158},{"n":"key","p":1310721}],"n":"GetRequiredSection","d":65550,"h":25769869326,"f":33}],"h":65550}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationExtensions`; }
        });
        
        $asm.$cls("$meca.Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute", ($self) => class ConfigurationKeyNameAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                this.Name = name;
                return this;
            }
            /*string*/ Name = null;
            static $h = 131086;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180000270,"f":1},"n":"Name","d":131086,"h":12885032974,"f":1}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":131086,"h":4295098382,"f":1}],"h":131086,"a":[{"t":14680065,"c":21489516545,"a":[{"v":128,"t":14614529}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))