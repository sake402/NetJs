
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mwp, $scn, $scm, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Binder", 
    {"h":15,"f":"Microsoft.Extensions.Configuration.Binder","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Binder","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Binder","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$$.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$$.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.System.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            static $h = 262159;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"tryToGetDefaultValue","p":262145,"f":2}],"n":"CheckHasDefaultValue","d":262159,"h":4295229455,"f":16777249},{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"defaultValue","p":131073,"f":2}],"n":"TryGetDefaultValue","d":262159,"h":8590196751,"f":16777249}],"h":262159}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.BinderOptions", ($self) => class BinderOptions extends $.$$.System.Object
        {
            /*bool*/ BindNonPublicProperties = false;
            /*bool*/ ErrorOnUnknownConfiguration = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.BindNonPublicProperties = false;
                this.ErrorOnUnknownConfiguration = false;
            }
            static $h = 65551;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12884967439,"f":50331649},"s":{"r":0,"d":0,"h":17179934735,"f":83886081},"n":"BindNonPublicProperties","d":65551,"h":8590000143,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30064836623,"f":50331649},"s":{"r":0,"d":0,"h":34359803919,"f":83886081},"n":"ErrorOnUnknownConfiguration","d":65551,"h":25769869327,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":65551,"h":38654771215,"f":16777217}],"h":65551}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.BinderOptions`; }
        });
        
        $asm.$cls("$mecb.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mecb.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecb.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mecb.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecb.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecb.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mecb.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Binder", $.$mecb.System.SR.$type.Assembly);
                    $.$mecb.System.SR.s_resourceManager = temp;
                }
                return $.$mecb.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mecb.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mecb.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            static /*string */ get Error_CannotBindToConstructorParameter()
            {
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'";
            }
            static /*string */ FormatError_CannotBindToConstructorParameter(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'", arg1, arg2);
            }
            static /*string */ get Error_ConstructorParametersDoNotMatchProperties()
            {
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'";
            }
            static /*string */ FormatError_ConstructorParametersDoNotMatchProperties(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'", arg1, arg2);
            }
            static /*string */ get Error_FailedBinding()
            {
                return "Failed to convert configuration value '{0}' at '{1}' to type '{2}'.";
            }
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("Failed to convert configuration value '{0}' at '{1}' to type '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get Error_FailedToActivate()
            {
                return "Failed to create instance of type '{0}'.";
            }
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            static /*string */ get Error_GeneralErrorWhenBinding()
            {
                return "'{0}' was set and binding has failed. The likely cause is an invalid configuration value.";
            }
            static /*string */ FormatError_GeneralErrorWhenBinding(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("'{0}' was set and binding has failed. The likely cause is an invalid configuration value.", arg1);
            }
            static /*string */ get Error_MissingConfig()
            {
                return "'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}";
            }
            static /*string */ FormatError_MissingConfig(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$$.System.String.Format$11("'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get Error_MissingPublicInstanceConstructor()
            {
                return "Cannot create instance of type '{0}' because it is missing a public instance constructor.";
            }
            static /*string */ FormatError_MissingPublicInstanceConstructor(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is missing a public instance constructor.", arg1);
            }
            static /*string */ get Error_MultipleParameterizedConstructors()
            {
                return "Cannot create instance of type '{0}' because it has multiple public parameterized constructors.";
            }
            static /*string */ FormatError_MultipleParameterizedConstructors(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it has multiple public parameterized constructors.", arg1);
            }
            static /*string */ get Error_ParameterBeingBoundToIsUnnamed()
            {
                return "Cannot create instance of type '{0}' because one or more parameters are unnamed.";
            }
            static /*string */ FormatError_ParameterBeingBoundToIsUnnamed(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because one or more parameters are unnamed.", arg1);
            }
            static /*string */ get Error_ParameterHasNoMatchingConfig()
            {
                return "Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.";
            }
            static /*string */ FormatError_ParameterHasNoMatchingConfig(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.", arg1, arg2);
            }
            static /*string */ get Error_UnsupportedMultidimensionalArray()
            {
                return "Cannot create instance of type '{0}' because multidimensional arrays are not supported.";
            }
            static /*string */ FormatError_UnsupportedMultidimensionalArray(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because multidimensional arrays are not supported.", arg1);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mecb.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 327695;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":327695}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.BindingPoint", ($self) => class BindingPoint extends $.$$.System.Object
        {
            /*Func<object?>?*/ _initialValueProvider = null;
            /*object?*/ _initialValue = null;
            /*object?*/ _setValue = null;
            /*bool*/ _valueSet = false;
            $ctor$2(/*object?*/ initialValue, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    this._initialValue = initialValue;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            $ctor$1(/*Func<object?>*/ initialValueProvider, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    this._initialValueProvider = initialValueProvider;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            /*bool*/ IsReadOnly = false;
            /*bool */ get HasNewValue()
            {
                if (this.IsReadOnly)
                {
                    return false;
                }
                if (this._valueSet)
                {
                    return true;
                }
                const $t1 = this._initialValue;
                let initialValueType;
                const $t2 = this._initialValue;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t)) !== null && ((initialValueType = $.$ifnn($t2, ($t) => $.$$.System.Object.GetType.call($t)), initialValueType != null && true)) && initialValueType.IsValueType && !initialValueType.IsPrimitive;
            }
            /*object? */ get Value()
            {
                return this._valueSet ? this._setValue : this._initialValue ??= (this._initialValueProvider?.Invoke() ?? null);
            }
            /*void */ SetValue(/*object?*/ newValue)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsReadOnly, "!IsReadOnly");
                $.$$.System.Diagnostics.Debug.Assert$2(!this._valueSet, "!_valueSet");
                this._setValue = newValue;
                this._valueSet = true;
            }
            /*void */ TrySetValue(/*object?*/ newValue)
            {
                if (!this.IsReadOnly)
                {
                    this.SetValue(newValue);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsReadOnly = false;
            }
            static $h = 131087;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":38654836751,"f":50331649},"n":"IsReadOnly","d":131087,"h":34359869455,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47244771343,"f":50331649},"n":"HasNewValue","d":131087,"h":42949804047,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":55834705935,"f":50331649},"n":"Value","d":131087,"h":51539738639,"f":2097153}],"m":[{"r":65537,"p":[{"n":"newValue","p":131073}],"n":"SetValue","d":131087,"h":60129673231,"f":16777217},{"r":65537,"p":[{"n":"newValue","p":131073}],"n":"TrySetValue","d":131087,"h":64424640527,"f":16777217}],"l":[{"t":$.$$.System.Func$$($.$$.System.Object).$h,"n":"_initialValueProvider","d":131087,"h":4295098383,"f":4194306},{"t":131073,"n":"_initialValue","d":131087,"h":8590065679,"f":4194306},{"t":131073,"n":"_setValue","d":131087,"h":12885032975,"f":4194306},{"t":262145,"n":"_valueSet","d":131087,"h":17180000271,"f":4194306}],"c":[{"p":[{"n":"initialValue","p":131073,"f":65},{"n":"isReadOnly","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$2","d":131087,"h":21474967567,"f":16777217},{"p":[{"n":"initialValueProvider","p":$.$$.System.Func$$($.$$.System.Object).$h},{"n":"isReadOnly","p":262145}],"n":".ctor","o":"$ctor$1","d":131087,"h":25769934863,"f":16777217}],"h":131087}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.BindingPoint`; }
        });
        
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder", ($self) => class ConfigurationBinder
        {
            /*BindingFlags*/ static DeclaredOnlyLookup = 62;
            /*string*/ static DynamicCodeWarningMessage = null;
            /*string*/ static TrimmingWarningMessage = null;
            /*string*/ static InstanceGetTypeTrimmingWarningMessage = null;
            /*string*/ static PropertyTrimmingWarningMessage = null;
            static /*T? */ Get$3(T, /*this IConfiguration*/ configuration)
            {
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get$2(T, configuration, null);
            }
            static /*T? */ Get$2(T, /*this IConfiguration*/ configuration, /*Action<BinderOptions>?*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                /*object?*/ let result = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get(configuration, T.$type, configureOptions);
                if (result === null)
                {
                    return $.$default(T);
                }
                return $.$cast(result, T);
            }
            static /*object? */ Get$1(/*this IConfiguration*/ configuration, /*Type*/ type)
            {
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get(configuration, type, null);
            }
            static /*object? */ Get(/*this IConfiguration*/ configuration, /*Type*/ type, /*Action<BinderOptions>?*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let options = new $.$mecb.Microsoft.Extensions.Configuration.BinderOptions().$ctor$1();
                configureOptions?.Invoke(options);
                /*var*/ let bindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(type, bindingPoint, configuration, options, false);
                return bindingPoint.Value;
            }
            static /*void */ Bind$2(/*this IConfiguration*/ configuration, /*string*/ key, /*object?*/ instance)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$1(configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key), instance);
            }
            static /*void */ Bind$1(/*this IConfiguration*/ configuration, /*object?*/ instance)
            {
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind(configuration, instance, null);
            }
            static /*void */ Bind(/*this IConfiguration*/ configuration, /*object?*/ instance, /*Action<BinderOptions>?*/ configureOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                if (instance !== null)
                {
                    /*var*/ let options = new $.$mecb.Microsoft.Extensions.Configuration.BinderOptions().$ctor$1();
                    configureOptions?.Invoke(options);
                    /*var*/ let bindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, true);
                    $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance($.$$.System.Object.GetType.call(instance), bindingPoint, configuration, options, false);
                }
            }
            static /*T? */ GetValue$3(T, /*this IConfiguration*/ configuration, /*string*/ key)
            {
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue$2(T, configuration, key, $.$default(T));
            }
            static /*T? */ GetValue$2(T, /*this IConfiguration*/ configuration, /*string*/ key, /*T*/ defaultValue)
            {
                return $.$cast($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue(configuration, T.$type, key, $.$box(defaultValue, T)), T);
            }
            static /*object? */ GetValue$1(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key)
            {
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue(configuration, type, key, null);
            }
            static /*object? */ GetValue(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key, /*object?*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*IConfigurationSection*/ let section = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key);
                /*string?*/ let value = section.Microsoft$Extensions$Configuration$IConfigurationSection$Value;
                if ($.$$.System.String.op_Inequality(value, null))
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.ConvertValue(type, value, section.Microsoft$Extensions$Configuration$IConfigurationSection$Path);
                }
                return defaultValue;
            }
            static /*void */ BindProperties(/*object*/ instance, /*IConfiguration*/ configuration, /*BinderOptions*/ options, /*ParameterInfo[]?*/ constructorParameters)
            {
                /*List<PropertyInfo>*/ let modelProperties = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetAllProperties($.$$.System.Object.GetType.call(instance));
                if (options.ErrorOnUnknownConfiguration)
                {
                    /*HashSet<string>*/ let propertyNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$2($.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.PropertyInfo, $.$$.System.String, modelProperties, new ($.$$.System.Func$$$($.$$.System.Reflection.PropertyInfo, $.$$.System.String))().$ctor(this,  (/*mp*/ mp) =>
                    {
                        return mp.Name;
                    }, {"r":1310721,"p":[{"n":"mp","p":81657857}],"n":"","d":196623,"h":0,"f":17825794})), $.$$.System.StringComparer.OrdinalIgnoreCase);
                    /*List<string>?*/ let missingPropertyNames = null;
                    var $en3 = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var cs = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!propertyNames.Contains(cs.Microsoft$Extensions$Configuration$IConfigurationSection$Key))
                            {
                                (missingPropertyNames ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1()).Add(`'${cs.Microsoft$Extensions$Configuration$IConfigurationSection$Key}'`);
                            }
                        }
                    }
                    if (missingPropertyNames !== null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$7($.$mecb.System.SR.Error_MissingConfig, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "ErrorOnUnknownConfiguration", "BinderOptions", $.$$.System.Object.GetType.call(instance), $.$$.System.String.Join$5(", ", missingPropertyNames) ], null, null)));
                    }
                }
                var $en2 = modelProperties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (constructorParameters === null || !$.$sl.System.Linq.Enumerable.Any($.$$.System.Reflection.ParameterInfo, constructorParameters, new ($.$$.System.Func$$$($.$$.System.Reflection.ParameterInfo, $.$$.System.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return $.$$.System.String.op_Equality(p.Name, property.Name);
                        }, {"r":262145,"p":[{"n":"p","p":81133569}],"n":"","d":196623,"h":0,"f":17825794})))
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindProperty(property, instance, configuration, options);
                        }
                        else 
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.ResetPropertyValue(property, instance, options);
                        }
                    }
                }
            }
            static /*void */ ResetPropertyValue(/*PropertyInfo*/ property, /*object*/ instance, /*BinderOptions*/ options)
            {
                if (property.GetMethod === null || property.SetMethod === null || (!options.BindNonPublicProperties && (!property.GetMethod.IsPublic$1 || !property.SetMethod.IsPublic$1)) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                property.SetValue$2(instance, property.GetValue$2(instance));
            }
            static /*void */ BindProperty(/*PropertyInfo*/ property, /*object*/ instance, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                if ($.$$.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, null) || (!options.BindNonPublicProperties && !property.GetMethod.IsPublic$1) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$1(new ($.$$.System.Func$$($.$$.System.Object))().$ctor(this,  () =>
                {
                    return property.GetValue$2(instance);
                }, {"r":131073,"n":"","d":196623,"h":0,"f":17825794}), property.SetMethod === null || (!property.SetMethod.IsPublic$1 && !options.BindNonPublicProperties));
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(property.PropertyType, propertyBindingPoint, config.Microsoft$Extensions$Configuration$IConfiguration$GetSection($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetPropertyName(property)), options, false);
                if (!propertyBindingPoint.IsReadOnly && (!(propertyBindingPoint.Value === null) || propertyBindingPoint.HasNewValue))
                {
                    property.SetValue$2(instance, propertyBindingPoint.Value);
                }
            }
            static /*void */ BindInstance(/*Type*/ type, /*BindingPoint*/ bindingPoint, /*IConfiguration*/ config, /*BinderOptions*/ options, /*bool*/ isParentCollection)
            {
                if ($.$$.System.Type.op_Equality$1(type, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection.$type))
                {
                    bindingPoint.TrySetValue(config);
                    return;
                }
                if (config === null)
                {
                    return;
                }
                /*IConfigurationSection?*/ let section;
                /*string?*/ let configValue;
                /*bool*/ let isConfigurationExist;
                let configSection;
                if ($.$is(config, $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection, { set $v(v){ configSection = v; } }))
                {
                    section = configSection;
                    isConfigurationExist = configSection.TryGetValue(null, $.$ref(() => configValue, ($v) => configValue = $v, $.$$.System.String));
                }
                else 
                {
                    section = $.$as(config, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection);
                    configValue = (section?.Microsoft$Extensions$Configuration$IConfigurationSection$Value ?? null);
                    isConfigurationExist = $.$$.System.String.op_Inequality(configValue, null);
                }
                /*object?*/ let convertedValue;
                /*Exception?*/ let error;
                if (isConfigurationExist && $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue(type, configValue, (section?.Microsoft$Extensions$Configuration$IConfigurationSection$Path ?? null), $.$ref(() => convertedValue, ($v) => convertedValue = $v, $.$$.System.Object), $.$ref(() => error, ($v) => error = $v, $.$$.System.Exception)))
                {
                    if (error !== null)
                    {
                        throw error;
                    }
                    let byteArray;
                    if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type) && $.$is(bindingPoint.Value, $.$typeArray($.$$.System.Byte), { set $v(v){ byteArray = v; } }) && byteArray.length > 0)
                    {
                        let convertedByteArray;
                        if ($.$is(convertedValue, $.$typeArray($.$$.System.Byte), { set $v(v){ convertedByteArray = v; } }) && convertedByteArray.length > 0)
                        {
                            /*Array*/ let a = $.$$.System.Array.CreateInstance$2(type.GetElementType(), ((byteArray.length + convertedByteArray.length) | 0));
                            $.$$.System.Array.Copy(byteArray, a, byteArray.length);
                            $.$$.System.Array.Copy$2(convertedByteArray, 0, a, byteArray.length, convertedByteArray.length);
                            bindingPoint.TrySetValue(a);
                        }
                        return;
                    }
                    bindingPoint.TrySetValue(convertedValue);
                    return;
                }
                if ($.$sl.System.Linq.Enumerable.Any$1($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren()))
                {
                    if (type.IsArray || $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.IsImmutableArrayCompatibleInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly)
                        {
                            bindingPoint.SetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindArray(type, $.$cast(bindingPoint.Value, $.$$.System.Collections.IEnumerable), config, options));
                        }
                        return;
                    }
                    if ($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TypeIsASetInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindSet(type, $.$cast(bindingPoint.Value, $.$$.System.Collections.IEnumerable), config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    if ($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TypeIsADictionaryInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionaryInterface(bindingPoint.Value, type, config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    /*ParameterInfo[]?*/ let constructorParameters = null;
                    if (bindingPoint.Value === null)
                    {
                        if (bindingPoint.IsReadOnly)
                        {
                            return;
                        }
                        /*Type?*/ let interfaceGenericType = type.IsInterface && type.IsConstructedGenericType ? type.GetGenericTypeDefinition() : null;
                        if (!(interfaceGenericType === null) && ($.$$.System.Type.op_Equality$1(interfaceGenericType, $.$$.System.Collections.Generic.ICollection$$().$type) || $.$$.System.Type.op_Equality$1(interfaceGenericType, $.$$.System.Collections.Generic.IList$$().$type)))
                        {
                            /*Type*/ let genericType = $.$$.System.Collections.Generic.List$$().$type.MakeGenericType(type.GenericTypeArguments);
                            bindingPoint.SetValue($.$$.System.Activator.CreateInstance$9(genericType));
                        }
                        else 
                        {
                            bindingPoint.SetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CreateInstance(type, config, options, $.$ref(() => constructorParameters, ($v) => constructorParameters = $v, $.$typeArray($.$$.System.Reflection.ParameterInfo))));
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!(bindingPoint.Value === null), "bindingPoint.Value is not null");
                    /*Type?*/ let dictionaryInterface = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.FindOpenGenericInterface($.$$.System.Collections.Generic.IDictionary$$$().$type, type);
                    if ($.$$.System.Type.op_Inequality$1(dictionaryInterface, null))
                    {
                        $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionary(bindingPoint.Value, dictionaryInterface, config, options);
                    }
                    else 
                    {
                        /*Type?*/ let collectionInterface = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.FindOpenGenericInterface($.$$.System.Collections.Generic.ICollection$$().$type, type);
                        if ($.$$.System.Type.op_Inequality$1(collectionInterface, null))
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindCollection(bindingPoint.Value, collectionInterface, config, options);
                        }
                        else 
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindProperties(bindingPoint.Value, config, options, constructorParameters);
                        }
                    }
                }
                else 
                {
                    if (!$.$$.System.String.IsNullOrEmpty(configValue))
                    {
                        if (options.ErrorOnUnknownConfiguration)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(section === null), "section is not null");
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, configValue, section.Microsoft$Extensions$Configuration$IConfigurationSection$Path, type));
                        }
                    }
                    else if (!bindingPoint.IsReadOnly && bindingPoint.Value === null)
                    {
                        if (isParentCollection)
                        {
                            bindingPoint.TrySetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CreateInstance(type, config, options, $.$discardRef()));
                        }
                        else if (isConfigurationExist)
                        {
                            if (type.IsArray || $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.IsIEnumerableInterface(type))
                            {
                                bindingPoint.TrySetValue(configValue === null ? null : $.$$.System.Array.CreateInstance$2(type.IsArray ? type.GetElementType() : $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0), 0));
                            }
                            else 
                            {
                                bindingPoint.TrySetValue(bindingPoint.Value);
                            }
                        }
                    }
                }
            }
            static /*object */ CreateInstance(/*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options, /*out ParameterInfo[]?*/ constructorParameters)
            {
                constructorParameters.$v = null;
                if (type.IsInterface || type.IsAbstract$1)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_CannotActivateAbstractOrInterface, type));
                }
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors$1(16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/);
                /*bool*/ let hasParameterlessConstructor = type.IsValueType || $.$sl.System.Linq.Enumerable.Any($.$$.System.Reflection.ConstructorInfo, constructors, new ($.$$.System.Func$$$($.$$.System.Reflection.ConstructorInfo, $.$$.System.Boolean))().$ctor(this,  (/*ctor*/ ctor) =>
                {
                    return ctor.GetParameters().length === 0;
                }, {"r":262145,"p":[{"n":"ctor","p":75628545}],"n":"","d":196623,"h":0,"f":17825794}));
                if (!type.IsValueType && constructors.length === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_MissingPublicInstanceConstructor, type));
                }
                if (constructors.length > 1 && !hasParameterlessConstructor)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_MultipleParameterizedConstructors, type));
                }
                if (constructors.length === 1 && !hasParameterlessConstructor)
                {
                    /*ConstructorInfo*/ let $constructor = $.$$.System.Array.$ReadT1.call(constructors, 0);
                    /*ParameterInfo[]*/ let parameters = $constructor.GetParameters();
                    /*string*/ let nameOfInvalidParameter;
                    if (!$.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CanBindToTheseConstructorParameters(parameters, $.$ref(() => nameOfInvalidParameter, ($v) => nameOfInvalidParameter = $v, $.$$.System.String)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_CannotBindToConstructorParameter, type, nameOfInvalidParameter));
                    }
                    /*List<PropertyInfo>*/ let properties = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetAllProperties(type);
                    /*string*/ let nameOfInvalidParameters;
                    if (!$.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.DoAllParametersHaveEquivalentProperties(parameters, properties, $.$ref(() => nameOfInvalidParameters, ($v) => nameOfInvalidParameters = $v, $.$$.System.String)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_ConstructorParametersDoNotMatchProperties, type, nameOfInvalidParameters));
                    }
                    /*object?[]*/ let parameterValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [parameters.length], null);
                    for(/*int*/ let index = 0; index < parameters.length; index++)
                    {
                        $.$$.System.Array.$WriteT1.call(parameterValues, $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindParameter($.$$.System.Array.$ReadT1.call(parameters, index), type, config, options), index);
                    }
                    constructorParameters.$v = parameters;
                    return $constructor.Invoke$2(parameterValues);
                }
                /*object?*/ let instance;
                try
                {
                    instance = $.$$.System.Activator.CreateInstance$9($.$$.System.Nullable.GetUnderlyingType(type) ?? type);
                }
                catch(ex)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_FailedToActivate, type), ex);
                }
                return $.$firstOf(instance, () => { throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_FailedToActivate, type)) });
            }
            static /*bool */ DoAllParametersHaveEquivalentProperties(/*ParameterInfo[]*/ parameters, /*List<PropertyInfo>*/ properties, /*out string*/ missing)
            {
                /*HashSet<string>*/ let propertyNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                var $en2 = properties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prop = $en2.Current;
                    {
                        propertyNames.Add(prop.Name);
                    }
                }
                /*List<string>*/ let missingParameters = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                let $i1 = 0;
                let $arr1 = parameters;
                while ($i1 < $arr1.length)
                {
                    let parameter = $arr1[$i1++];
                    /*string*/ let name = parameter.Name;
                    if (!propertyNames.Contains(name))
                    {
                        missingParameters.Add(name);
                    }
                }
                missing.$v = $.$$.System.String.Join$5(",", missingParameters);
                return missing.$v.length === 0;
            }
            static /*bool */ CanBindToTheseConstructorParameters(/*ParameterInfo[]*/ constructorParameters, /*out string*/ nameOfInvalidParameter)
            {
                nameOfInvalidParameter.$v = $.$$.System.String.Empty;
                let $i1 = 0;
                let $arr1 = constructorParameters;
                while ($i1 < $arr1.length)
                {
                    let p = $arr1[$i1++];
                    if (p.IsOut || p.IsIn || p.ParameterType.IsByRef)
                    {
                        nameOfInvalidParameter.$v = p.Name;
                        return false;
                    }
                }
                return true;
            }
            static /*object? */ BindDictionaryInterface(/*object?*/ source, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = $.$$.System.Type.op_Equality$1(keyType, $.$$.System.SByte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt64.$type);
                if ($.$$.System.Type.op_Inequality$1(keyType, $.$$.System.String.$type) && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return null;
                }
                /*MethodInfo?*/ let addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    dictionaryType = $.$$.System.Collections.Generic.Dictionary$$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ keyType, valueType ], null, null));
                    /*object?*/ let dictionary = $.$$.System.Activator.CreateInstance$9(dictionaryType);
                    addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    /*var*/ let orig = $.$as(source, $.$$.System.Collections.IEnumerable);
                    if (!(orig === null))
                    {
                        /*Type*/ let kvpType = $.$$.System.Collections.Generic.KeyValuePair$$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ keyType, valueType ], null, null));
                        /*PropertyInfo*/ let keyMethod = kvpType.GetProperty$1("Key", 62/*DeclaredOnlyLookup*/);
                        /*PropertyInfo*/ let valueMethod = kvpType.GetProperty$1("Value", 62/*DeclaredOnlyLookup*/);
                        /*object?[]*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [2], null);
                        var $en4 = orig.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                /*object?*/ let k = keyMethod.GetMethod.Invoke(item, null);
                                /*object?*/ let v = valueMethod.GetMethod.Invoke(item, null);
                                $.$$.System.Array.$WriteT1.call($arguments, k, 0);
                                $.$$.System.Array.$WriteT1.call($arguments, v, 1);
                                addMethod.Invoke(dictionary, $arguments);
                            }
                        }
                    }
                    source = dictionary;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(source === null), "source is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(!(addMethod === null), "addMethod is not null");
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionary(source, dictionaryType, config, options);
                return source;
            }
            static /*void */ BindDictionary(/*object*/ dictionary, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(dictionaryType.IsGenericType && ($.$$.System.Type.op_Equality$1(dictionaryType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IDictionary$$$().$type) || $.$$.System.Type.op_Equality$1(dictionaryType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.Dictionary$$$().$type)), "dictionaryType.IsGenericType &&\r\n                         (dictionaryType.GetGenericTypeDefinition() == typeof(IDictionary<,>) || dictionaryType.GetGenericTypeDefinition() == typeof(Dictionary<,>))");
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = $.$$.System.Type.op_Equality$1(keyType, $.$$.System.SByte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt64.$type);
                if ($.$$.System.Type.op_Inequality$1(keyType, $.$$.System.String.$type) && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return;
                }
                /*MethodInfo*/ let tryGetValue = dictionaryType.GetMethod$9("TryGetValue", 62/*DeclaredOnlyLookup*/);
                /*PropertyInfo*/ let indexerProperty = dictionaryType.GetProperty$1("Item", 62/*DeclaredOnlyLookup*/);
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var child = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*object*/ let key = keyTypeIsEnum ? $.$$.System.Enum.Parse$2(keyType, child.Microsoft$Extensions$Configuration$IConfigurationSection$Key, true) : keyTypeIsInteger ? $.$$.System.Convert.ChangeType$1(child.Microsoft$Extensions$Configuration$IConfigurationSection$Key, keyType) : child.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            /*var*/ let valueBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$1(new ($.$$.System.Func$$($.$$.System.Object))().$ctor(this,  () =>
                            {
                                /*object?[]*/ let tryGetValueArgs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [key, null], null, null);
                                return $.$cast(tryGetValue.Invoke(dictionary, tryGetValueArgs), $.$$.System.Boolean) ? $.$$.System.Array.$ReadT1.call(tryGetValueArgs, 1) : null;
                            }, {"r":131073,"n":"","d":196623,"h":0,"f":17825794}), false);
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(valueType, valueBindingPoint, child, options, true);
                            if (valueBindingPoint.HasNewValue)
                            {
                                indexerProperty.SetValue(dictionary, valueBindingPoint.Value, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [key], [-1], null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            static /*void */ BindCollection(/*object*/ collection, /*Type*/ collectionType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                /*Type*/ let itemType = $.$$.System.Array.$ReadT1.call(collectionType.GenericTypeArguments, 0);
                /*MethodInfo?*/ let addMethod = collectionType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*BindingPoint*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(itemType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                addMethod?.Invoke(collection, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [itemBindingPoint.Value], null, null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            static /*Array */ BindArray(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                /*Type*/ let elementType;
                if (type.IsArray)
                {
                    if (type.GetArrayRank() > 1)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_UnsupportedMultidimensionalArray, type));
                    }
                    elementType = type.GetElementType();
                }
                else 
                {
                    elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                }
                /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                if (source !== null)
                {
                    var $en3 = source.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$IEnumerator$Current;
                        {
                            list.Add(item);
                        }
                    }
                }
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                list.Add(itemBindingPoint.Value);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                /*Array*/ let result = $.$$.System.Array.CreateInstance$2(elementType, list.Count);
                (list).System$Collections$ICollection$CopyTo(result, 0);
                return result;
            }
            static /*object? */ BindSet(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                /*Type*/ let elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                /*bool*/ let elementTypeIsEnum = elementType.IsEnum;
                if ($.$$.System.Type.op_Inequality$1(elementType, $.$$.System.String.$type) && !elementTypeIsEnum)
                {
                    return null;
                }
                /*object?[]*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [1], null);
                /*MethodInfo?*/ let addMethod = type.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    /*Type*/ let genericType = $.$$.System.Collections.Generic.HashSet$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                    /*object*/ let instance = $.$$.System.Activator.CreateInstance$9(genericType);
                    addMethod = genericType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    if (source !== null)
                    {
                        var $en4 = source.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, item, 0);
                                addMethod.Invoke(instance, $arguments);
                            }
                        }
                    }
                    source = $.$cast(instance, $.$$.System.Collections.IEnumerable);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(source === null), "source is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(!(addMethod === null), "addMethod is not null");
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, itemBindingPoint.Value, 0);
                                addMethod.Invoke(source, $arguments);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                return source;
            }
            static /*bool */ TryConvertValue(/*Type*/ type, /*string?*/ value, /*string?*/ path, /*out object?*/ result, /*out Exception?*/ error)
            {
                error.$v = null;
                result.$v = null;
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Object.$type))
                {
                    result.$v = value;
                    return true;
                }
                if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type))
                {
                    if ($.$$.System.String.IsNullOrEmpty(value))
                    {
                        return true;
                    }
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue($.$$.System.Nullable.GetUnderlyingType(type), value, path, result, error);
                }
                /*TypeConverter*/ let converter = $.$sct.System.ComponentModel.TypeDescriptor.GetConverter$2(type);
                if (converter.CanConvertFrom($.$$.System.String.$type))
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = converter.ConvertFromInvariantString(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type))
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = $.$$.System.String.op_Equality(value, $.$$.System.String.Empty) ? $.$$.System.Array.Empty($.$$.System.Byte) : $.$$.System.Convert.FromBase64String(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                return false;
            }
            static /*object? */ ConvertValue(/*Type*/ type, /*string*/ value, /*string?*/ path)
            {
                /*object?*/ let result;
                /*Exception?*/ let error;
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue(type, value, path, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object), $.$ref(() => error, ($v) => error = $v, $.$$.System.Exception));
                if (error !== null)
                {
                    throw error;
                }
                return result;
            }
            static /*bool */ TypeIsADictionaryInterface(/*Type*/ type)
            {
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IDictionary$$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$().$type);
            }
            static /*bool */ IsImmutableArrayCompatibleInterface(/*Type*/ type)
            {
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IEnumerable$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyCollection$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyList$$().$type);
            }
            static /*bool */ IsIEnumerableInterface(/*Type*/ type)
            {
                return type.IsInterface && type.IsConstructedGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type);
            }
            static /*bool */ TypeIsASetInterface(/*Type*/ type)
            {
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.ISet$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlySet$$().$type);
            }
            static /*Type? */ FindOpenGenericInterface(/*Type*/ expected, /*Type*/ actual)
            {
                if (actual.IsGenericType && $.$$.System.Type.op_Equality$1(actual.GetGenericTypeDefinition(), expected))
                {
                    return actual;
                }
                /*Type[]*/ let interfaces = actual.GetInterfaces();
                let $i1 = 0;
                let $arr1 = interfaces;
                while ($i1 < $arr1.length)
                {
                    let interfaceType = $arr1[$i1++];
                    if (interfaceType.IsGenericType && $.$$.System.Type.op_Equality$1(interfaceType.GetGenericTypeDefinition(), expected))
                    {
                        return interfaceType;
                    }
                }
                return null;
            }
            static /*List<PropertyInfo> */ GetAllProperties(/*Type*/ type)
            {
                /*var*/ let allProperties = new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo))().$ctor$1();
                /*Type*/ let baseType = type;
                while($.$$.System.Type.op_Inequality$1(baseType, $.$$.System.Object.$type))
                {
                    /*PropertyInfo[]*/ let properties = baseType.GetProperties$1(62/*DeclaredOnlyLookup*/);
                    let $i1 = 0;
                    let $arr1 = properties;
                    while ($i1 < $arr1.length)
                    {
                        let property = $arr1[$i1++];
                        /*MethodInfo?*/ let setMethod = property.GetSetMethod$1(true);
                        if (setMethod === null || !setMethod.IsVirtual$1 || $.$$.System.Reflection.MethodInfo.op_Equality$2(setMethod, setMethod.GetBaseDefinition()))
                        {
                            allProperties.Add(property);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                return allProperties;
            }
            static /*object? */ BindParameter(/*ParameterInfo*/ parameter, /*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                /*string?*/ let parameterName = parameter.Name;
                if (parameterName === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_ParameterBeingBoundToIsUnnamed, type));
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(parameterName).Microsoft$Extensions$Configuration$IConfigurationSection$Value, false);
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(parameter.ParameterType, propertyBindingPoint, config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(parameterName), options, false);
                if (propertyBindingPoint.Value === null)
                {
                    /*object?*/ let defaultValue;
                    if ($.$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(parameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object)))
                    {
                        propertyBindingPoint.SetValue(defaultValue);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_ParameterHasNoMatchingConfig, type, parameterName));
                    }
                }
                return propertyBindingPoint.Value;
            }
            static /*string */ GetPropertyName(/*PropertyInfo*/ property)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(property, "property");
                var $en2 = property.GetCustomAttributesData().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attributeData = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.Type.op_Inequality$1(attributeData.AttributeType, $.$meca.Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute.$type))
                        {
                            continue;
                        }
                        if (attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count !== 1)
                        {
                            break;
                        }
                        const $t1 = () => attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$$.System.Reflection.CustomAttributeTypedArgument]).Value;
                        /*string?*/ let name = $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                        return !$.$$.System.String.IsNullOrWhiteSpace(name) ? name : property.Name;
                    }
                }
                return property.Name;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DynamicCodeWarningMessage = "Binding strongly typed objects to configuration values requires generating dynamic code at runtime, for example instantiating generic types.";
                }
                {
                    this.TrimmingWarningMessage = "In case the type is non-primitive, the trimmer cannot statically analyze the object's type so its members may be trimmed.";
                }
                {
                    this.InstanceGetTypeTrimmingWarningMessage = "Cannot statically analyze the type of instance so its members may be trimmed";
                }
                {
                    this.PropertyTrimmingWarningMessage = "Cannot statically analyze property.PropertyType so its members may be trimmed.";
                }
            }
            static $h = 196623;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(T) => T.$h,"p":[{"n":"configuration","p":262158}],"g":["T"],"n":"Get","o":"@$3","d":196623,"h":25770000399,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"configuration","p":262158},{"n":"configureOptions","p":$.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"g":["T"],"n":"Get","o":"@$2","d":196623,"h":30064967695,"f":16908321},{"r":131073,"p":[{"n":"configuration","p":262158},{"n":"type","p":142475265}],"n":"Get","o":"@$1","d":196623,"h":34359934991,"f":16777249},{"r":131073,"p":[{"n":"configuration","p":262158},{"n":"type","p":142475265},{"n":"configureOptions","p":$.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"n":"Get","d":196623,"h":38654902287,"f":16777249},{"r":65537,"p":[{"n":"configuration","p":262158},{"n":"key","p":1310721},{"n":"instance","p":131073}],"n":"Bind","o":"@$2","d":196623,"h":42949869583,"f":16777249},{"r":65537,"p":[{"n":"configuration","p":262158},{"n":"instance","p":131073}],"n":"Bind","o":"@$1","d":196623,"h":47244836879,"f":16777249},{"r":65537,"p":[{"n":"configuration","p":262158},{"n":"instance","p":131073},{"n":"configureOptions","p":$.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h}],"n":"Bind","d":196623,"h":51539804175,"f":16777249},{"r":(T) => T.$h,"p":[{"n":"configuration","p":262158},{"n":"key","p":1310721}],"g":["T"],"n":"GetValue","o":"@$3","d":196623,"h":55834771471,"f":16908321},{"r":(T) => T.$h,"p":[{"n":"configuration","p":262158},{"n":"key","p":1310721},{"n":"defaultValue","p":(T) => T.$h}],"g":["T"],"n":"GetValue","o":"@$2","d":196623,"h":60129738767,"f":16908321},{"r":131073,"p":[{"n":"configuration","p":262158},{"n":"type","p":142475265},{"n":"key","p":1310721}],"n":"GetValue","o":"@$1","d":196623,"h":64424706063,"f":16777249},{"r":131073,"p":[{"n":"configuration","p":262158},{"n":"type","p":142475265},{"n":"key","p":1310721},{"n":"defaultValue","p":131073}],"n":"GetValue","d":196623,"h":68719673359,"f":16777249},{"r":65537,"p":[{"n":"instance","p":131073},{"n":"configuration","p":262158},{"n":"options","p":65551},{"n":"constructorParameters","p":$.$typeArray($.$$.System.Reflection.ParameterInfo).$h}],"n":"BindProperties","d":196623,"h":73014640655,"f":16777250},{"r":65537,"p":[{"n":"property","p":81657857},{"n":"instance","p":131073},{"n":"options","p":65551}],"n":"ResetPropertyValue","d":196623,"h":77309607951,"f":16777250},{"r":65537,"p":[{"n":"property","p":81657857},{"n":"instance","p":131073},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindProperty","d":196623,"h":81604575247,"f":16777250},{"r":65537,"p":[{"n":"type","p":142475265},{"n":"bindingPoint","p":131087},{"n":"config","p":262158},{"n":"options","p":65551},{"n":"isParentCollection","p":262145}],"n":"BindInstance","d":196623,"h":85899542543,"f":16777250},{"r":131073,"p":[{"n":"type","p":142475265},{"n":"config","p":262158},{"n":"options","p":65551},{"n":"constructorParameters","p":$.$typeArray($.$$.System.Reflection.ParameterInfo).$h,"f":2}],"n":"CreateInstance","d":196623,"h":90194509839,"f":16777250},{"r":262145,"p":[{"n":"parameters","p":$.$typeArray($.$$.System.Reflection.ParameterInfo).$h},{"n":"properties","p":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo).$h},{"n":"missing","p":1310721,"f":2}],"n":"DoAllParametersHaveEquivalentProperties","d":196623,"h":94489477135,"f":16777250},{"r":262145,"p":[{"n":"constructorParameters","p":$.$typeArray($.$$.System.Reflection.ParameterInfo).$h},{"n":"nameOfInvalidParameter","p":1310721,"f":2}],"n":"CanBindToTheseConstructorParameters","d":196623,"h":98784444431,"f":16777250},{"r":131073,"p":[{"n":"source","p":131073},{"n":"dictionaryType","p":142475265},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindDictionaryInterface","d":196623,"h":103079411727,"f":16777250},{"r":65537,"p":[{"n":"dictionary","p":131073},{"n":"dictionaryType","p":142475265},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindDictionary","d":196623,"h":107374379023,"f":16777250},{"r":65537,"p":[{"n":"collection","p":131073},{"n":"collectionType","p":142475265},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindCollection","d":196623,"h":111669346319,"f":16777250},{"r":1245185,"p":[{"n":"type","p":142475265},{"n":"source","p":31719425},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindArray","d":196623,"h":115964313615,"f":16777250},{"r":131073,"p":[{"n":"type","p":142475265},{"n":"source","p":31719425},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindSet","d":196623,"h":120259280911,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265},{"n":"value","p":1310721},{"n":"path","p":1310721},{"n":"result","p":131073,"f":2},{"n":"error","p":47251457,"f":2}],"n":"TryConvertValue","d":196623,"h":124554248207,"f":16777250},{"r":131073,"p":[{"n":"type","p":142475265},{"n":"value","p":1310721},{"n":"path","p":1310721}],"n":"ConvertValue","d":196623,"h":128849215503,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"TypeIsADictionaryInterface","d":196623,"h":133144182799,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsImmutableArrayCompatibleInterface","d":196623,"h":137439150095,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"IsIEnumerableInterface","d":196623,"h":141734117391,"f":16777250},{"r":262145,"p":[{"n":"type","p":142475265}],"n":"TypeIsASetInterface","d":196623,"h":146029084687,"f":16777250},{"r":142475265,"p":[{"n":"expected","p":142475265},{"n":"actual","p":142475265}],"n":"FindOpenGenericInterface","d":196623,"h":150324051983,"f":16777250},{"r":$.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo).$h,"p":[{"n":"type","p":142475265}],"n":"GetAllProperties","d":196623,"h":154619019279,"f":16777250},{"r":131073,"p":[{"n":"parameter","p":81133569},{"n":"type","p":142475265},{"n":"config","p":262158},{"n":"options","p":65551}],"n":"BindParameter","d":196623,"h":158913986575,"f":16777250},{"r":1310721,"p":[{"n":"property","p":81657857}],"n":"GetPropertyName","d":196623,"h":163208953871,"f":16777250}],"l":[{"t":75497473,"n":"DeclaredOnlyLookup","d":196623,"h":4295163919,"f":4194338},{"t":1310721,"n":"DynamicCodeWarningMessage","d":196623,"h":8590131215,"f":4194338},{"t":1310721,"n":"TrimmingWarningMessage","d":196623,"h":12885098511,"f":4194338},{"t":1310721,"n":"InstanceGetTypeTrimmingWarningMessage","d":196623,"h":17180065807,"f":4194338},{"t":1310721,"n":"PropertyTrimmingWarningMessage","d":196623,"h":21475033103,"f":4194338}],"h":196623}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationBinder`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter"))