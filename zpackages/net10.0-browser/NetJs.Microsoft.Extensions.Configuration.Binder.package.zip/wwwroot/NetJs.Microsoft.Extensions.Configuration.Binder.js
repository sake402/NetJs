
//--TRIMMABLE-BOUNDARY-START(96)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mecga, $mec, $mwp, $scn, $scm, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct) {
    "use strict";
    let _;
    let $SVjQTe;
    let $SeIYIg;
    let $OQNhRf;
    let $xSZftj;
    let $FmZWQf;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Binder", 
    {
  "h": 96,
  "f": "Microsoft.Extensions.Configuration.Binder",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Binder",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Binder",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262240)
        $asm.$cls(`$mecb.MEI.ParameterDefaultValue`, ($self) => class ParameterDefaultValue
        {
            //--TRIMMABLE-BOUNDARY-START(4295229536)
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229536)
            
            //--TRIMMABLE-BOUNDARY-START(8590196832)
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                /*bool*/ let tryToGetDefaultValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let hasDefaultValue = $.$mecb.MEI.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.S.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && parameter.ParameterType.GetGenericTypeDefinition() === $.$$.S.Nullable$$().$type;
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        {
                            return $.$$.SRC.RuntimeHelpers.GetUninitializedObject(t);
                        }
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.S.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if (underlyingType !== null && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.S.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196832)
            
            static $h = 262240;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229536),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 119078913
        },
        {
          "n": "tryToGetDefaultValue",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "CheckHasDefaultValue",
      "d": 262240,
      "h": 4295229536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229536),
//--TRIMMABLE-BOUNDARY-START(8590196832),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 119078913
        },
        {
          "n": "defaultValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetDefaultValue",
      "d": 262240,
      "h": 8590196832,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196832)
  ],
  "h": 262240
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}ParameterDefaultValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262240)
        
        

        //--TRIMMABLE-BOUNDARY-START(65632)
        $asm.$cls(`$mecb.MEC.BinderOptions`, ($self) => class BinderOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179934816)
            /*bool*/ BindNonPublicProperties = false;
            //--TRIMMABLE-BOUNDARY-END(17179934816)
            
            //--TRIMMABLE-BOUNDARY-START(21474902112)
            /*bool*/ ErrorOnUnknownConfiguration = false;
            //--TRIMMABLE-BOUNDARY-END(21474902112)
            
            //--TRIMMABLE-BOUNDARY-START(12884967520)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967520)
            
            //--TRIMMABLE-BOUNDARY-START(12884967520)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967520)
            
            static $h = 65632;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934816),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064836704,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244705888,
        "f": 83886081
      },
      "n": "BindNonPublicProperties",
      "d": 65632,
      "h": 17179934816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934816),
//--TRIMMABLE-BOUNDARY-START(21474902112),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771296,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834640480,
        "f": 83886081
      },
      "n": "ErrorOnUnknownConfiguration",
      "d": 65632,
      "h": 21474902112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474902112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967520),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65632,
      "h": 12884967520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967520)
  ],
  "h": 65632
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.BinderOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}BinderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65632)
        
        

        //--TRIMMABLE-BOUNDARY-START(131168)
        $asm.$cls(`$mecb.MEC.BindingPoint`, ($self) => class BindingPoint extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065760)
            /*Func<object?>?*/ _initialValueProvider = null;
            //--TRIMMABLE-BOUNDARY-END(8590065760)
            
            //--TRIMMABLE-BOUNDARY-START(4295098464)
            /*object?*/ _initialValue = null;
            //--TRIMMABLE-BOUNDARY-END(4295098464)
            
            //--TRIMMABLE-BOUNDARY-START(12885033056)
            /*object?*/ _setValue = null;
            //--TRIMMABLE-BOUNDARY-END(12885033056)
            
            //--TRIMMABLE-BOUNDARY-START(17180000352)
            /*bool*/ _valueSet = false;
            //--TRIMMABLE-BOUNDARY-END(17180000352)
            
            //--TRIMMABLE-BOUNDARY-START(30064902240)
            $ctor$2(/*object?*/ initialValue, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064902240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._initialValue = initialValue;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902240)
            
            //--TRIMMABLE-BOUNDARY-START(25769934944)
            $ctor$1(/*Func<object?>*/ initialValueProvider, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._initialValueProvider = initialValueProvider;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934944)
            
            //--TRIMMABLE-BOUNDARY-START(64424640608)
            /*bool*/ IsReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(64424640608)
            
            //--TRIMMABLE-BOUNDARY-START(60129673312)
            /*bool */ get HasNewValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return false;
                }
                if (this._valueSet)
                {
                    return true;
                }
                /*object?*/ let __ca1__;
                let initialValueType;
                return ((__ca1__ = this._initialValue) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null) !== null && ((initialValueType = ((__ca1__ = this._initialValue) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null), initialValueType != null && true)) && initialValueType.IsValueType && !initialValueType.IsPrimitive;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673312)
            
            //--TRIMMABLE-BOUNDARY-START(77309542496)
            /*object? */ get Value()
            {
                return this._valueSet ? this._setValue : this._initialValue ??= (this._initialValueProvider?.Invoke() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(77309542496)
            
            //--TRIMMABLE-BOUNDARY-START(68719607904)
            /*void */ SetValue(/*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!this.IsReadOnly, "!IsReadOnly");
                $.$$.SD.Debug.Assert$4(!this._valueSet, "!_valueSet");
                this._setValue = newValue;
                this._valueSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607904)
            
            //--TRIMMABLE-BOUNDARY-START(73014575200)
            /*void */ TrySetValue(/*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsReadOnly)
                {
                    this.SetValue(newValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014575200)
            
            static $h = 131168;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424640608),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771424,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 131168,
      "h": 64424640608,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424640608),
//--TRIMMABLE-BOUNDARY-START(60129673312),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836832,
        "f": 50331649
      },
      "n": "HasNewValue",
      "d": 131168,
      "h": 60129673312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129673312),
//--TRIMMABLE-BOUNDARY-START(77309542496),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706016,
        "f": 50331649
      },
      "n": "Value",
      "d": 131168,
      "h": 77309542496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309542496)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719607904),
    {
      "r": 65537,
      "p": [
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 131168,
      "h": 68719607904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719607904),
//--TRIMMABLE-BOUNDARY-START(73014575200),
    {
      "r": 65537,
      "p": [
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "TrySetValue",
      "d": 131168,
      "h": 73014575200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014575200)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065760),
    {
      "t": $.$$.S.Func$$($.$$.S.Object).$h,
      "n": "_initialValueProvider",
      "d": 131168,
      "h": 8590065760,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065760),
//--TRIMMABLE-BOUNDARY-START(4295098464),
    {
      "t": 131073,
      "n": "_initialValue",
      "d": 131168,
      "h": 4295098464,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098464),
//--TRIMMABLE-BOUNDARY-START(12885033056),
    {
      "t": 131073,
      "n": "_setValue",
      "d": 131168,
      "h": 12885033056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033056),
//--TRIMMABLE-BOUNDARY-START(17180000352),
    {
      "t": 262145,
      "n": "_valueSet",
      "d": 131168,
      "h": 17180000352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064902240),
    {
      "p": [
        {
          "n": "initialValue",
          "p": 131073,
          "f": 65
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131168,
      "h": 30064902240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064902240),
//--TRIMMABLE-BOUNDARY-START(25769934944),
    {
      "p": [
        {
          "n": "initialValueProvider",
          "p": $.$$.S.Func$$($.$$.S.Object).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131168,
      "h": 25769934944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934944)
  ],
  "h": 131168
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.BindingPoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}BindingPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131168)
        
        

        //--TRIMMABLE-BOUNDARY-START(327776)
        $asm.$cls(`$mecb.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(296353071200)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(296353071200)
            
            //--TRIMMABLE-BOUNDARY-START(279173202016)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(279173202016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173202016)
            
            //--TRIMMABLE-BOUNDARY-START(309237973088)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309237973088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237973088)
            
            //--TRIMMABLE-BOUNDARY-START(274878234720)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878234720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecb.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(274878234720)
            
            //--TRIMMABLE-BOUNDARY-START(270583267424)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583267424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecb.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(270583267424)
            
            //--TRIMMABLE-BOUNDARY-START(90194640992)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194640992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(90194640992)
            
            //--TRIMMABLE-BOUNDARY-START(85899673696)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(85899673696)
            
            //--TRIMMABLE-BOUNDARY-START(81604706400)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706400)
            
            //--TRIMMABLE-BOUNDARY-START(94489608288)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecb.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(94489608288)
            
            //--TRIMMABLE-BOUNDARY-START(73014771808)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014771808)
            
            //--TRIMMABLE-BOUNDARY-START(68719804512)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68719804512)
            
            //--TRIMMABLE-BOUNDARY-START(64424837216)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837216)
            
            //--TRIMMABLE-BOUNDARY-START(77309739104)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecb.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77309739104)
            
            //--TRIMMABLE-BOUNDARY-START(292058103904)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(292058103904)
            
            //--TRIMMABLE-BOUNDARY-START(283468169312)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(283468169312)
            
            //--TRIMMABLE-BOUNDARY-START(287763136608)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288300128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mecb.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Binder", $.$mecb.S.SR.$type.Assembly);
                    $.$mecb.S.SR.s_resourceManager = temp;
                }
                return $.$mecb.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(287763136608)
            
            //--TRIMMABLE-BOUNDARY-START(8590262368)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943005792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecb.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262368)
            
            //--TRIMMABLE-BOUNDARY-START(12885229664)
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885229664)
            
            //--TRIMMABLE-BOUNDARY-START(98784575584)
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98784575584)
            
            //--TRIMMABLE-BOUNDARY-START(17180196960)
            static /*string */ get Error_CannotBindToConstructorParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(17180196960)
            
            //--TRIMMABLE-BOUNDARY-START(103079542880)
            static /*string */ FormatError_CannotBindToConstructorParameter(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542880)
            
            //--TRIMMABLE-BOUNDARY-START(21475164256)
            static /*string */ get Error_ConstructorParametersDoNotMatchProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(21475164256)
            
            //--TRIMMABLE-BOUNDARY-START(107374510176)
            static /*string */ FormatError_ConstructorParametersDoNotMatchProperties(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(107374510176)
            
            //--TRIMMABLE-BOUNDARY-START(25770131552)
            static /*string */ get Error_FailedBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to convert configuration value '{0}' at '{1}' to type '{2}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770131552)
            
            //--TRIMMABLE-BOUNDARY-START(111669477472)
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$7("Failed to convert configuration value '{0}' at '{1}' to type '{2}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(111669477472)
            
            //--TRIMMABLE-BOUNDARY-START(30065098848)
            static /*string */ get Error_FailedToActivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568823392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to create instance of type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(30065098848)
            
            //--TRIMMABLE-BOUNDARY-START(115964444768)
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115964444768)
            
            //--TRIMMABLE-BOUNDARY-START(34360066144)
            static /*string */ get Error_GeneralErrorWhenBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158757984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' was set and binding has failed. The likely cause is an invalid configuration value.";
            }
            //--TRIMMABLE-BOUNDARY-END(34360066144)
            
            //--TRIMMABLE-BOUNDARY-START(120259412064)
            static /*string */ FormatError_GeneralErrorWhenBinding(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("'{0}' was set and binding has failed. The likely cause is an invalid configuration value.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120259412064)
            
            //--TRIMMABLE-BOUNDARY-START(38655033440)
            static /*string */ get Error_MissingConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}";
            }
            //--TRIMMABLE-BOUNDARY-END(38655033440)
            
            //--TRIMMABLE-BOUNDARY-START(124554379360)
            static /*string */ FormatError_MissingConfig(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$11("'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(124554379360)
            
            //--TRIMMABLE-BOUNDARY-START(42950000736)
            static /*string */ get Error_MissingPublicInstanceConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is missing a public instance constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(42950000736)
            
            //--TRIMMABLE-BOUNDARY-START(128849346656)
            static /*string */ FormatError_MissingPublicInstanceConstructor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because it is missing a public instance constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346656)
            
            //--TRIMMABLE-BOUNDARY-START(47244968032)
            static /*string */ get Error_MultipleParameterizedConstructors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it has multiple public parameterized constructors.";
            }
            //--TRIMMABLE-BOUNDARY-END(47244968032)
            
            //--TRIMMABLE-BOUNDARY-START(133144313952)
            static /*string */ FormatError_MultipleParameterizedConstructors(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because it has multiple public parameterized constructors.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133144313952)
            
            //--TRIMMABLE-BOUNDARY-START(51539935328)
            static /*string */ get Error_ParameterBeingBoundToIsUnnamed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters are unnamed.";
            }
            //--TRIMMABLE-BOUNDARY-END(51539935328)
            
            //--TRIMMABLE-BOUNDARY-START(137439281248)
            static /*string */ FormatError_ParameterBeingBoundToIsUnnamed(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because one or more parameters are unnamed.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281248)
            
            //--TRIMMABLE-BOUNDARY-START(55834902624)
            static /*string */ get Error_ParameterHasNoMatchingConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.";
            }
            //--TRIMMABLE-BOUNDARY-END(55834902624)
            
            //--TRIMMABLE-BOUNDARY-START(141734248544)
            static /*string */ FormatError_ParameterHasNoMatchingConfig(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248544)
            
            //--TRIMMABLE-BOUNDARY-START(60129869920)
            static /*string */ get Error_UnsupportedMultidimensionalArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because multidimensional arrays are not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(60129869920)
            
            //--TRIMMABLE-BOUNDARY-START(146029215840)
            static /*string */ FormatError_UnsupportedMultidimensionalArray(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot create instance of type '{0}' because multidimensional arrays are not supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146029215840)
            
            //--TRIMMABLE-BOUNDARY-START(4295295072)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(296353071200)
                    this.s_usingResourceKeys = $.$mecb.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(296353071200)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295072)
            
            static $h = 327776;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 327776
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327776)
        
        

        //--TRIMMABLE-BOUNDARY-START(196704)
        $asm.$cls(`$mecb.MEC.ConfigurationBinder`, ($self) => class ConfigurationBinder
        {
            //--TRIMMABLE-BOUNDARY-START(68719673440)
            /*BindingFlags*/ static DeclaredOnlyLookup = 62;
            //--TRIMMABLE-BOUNDARY-END(68719673440)
            
            //--TRIMMABLE-BOUNDARY-START(77309608032)
            /*string*/ static DynamicCodeWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309608032)
            
            //--TRIMMABLE-BOUNDARY-START(150324052064)
            /*string*/ static TrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(150324052064)
            
            //--TRIMMABLE-BOUNDARY-START(128849215584)
            /*string*/ static InstanceGetTypeTrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849215584)
            
            //--TRIMMABLE-BOUNDARY-START(141734117472)
            /*string*/ static PropertyTrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(141734117472)
            
            //--TRIMMABLE-BOUNDARY-START(98784444512)
            static /*T? */ Get$3(T, /*this IConfiguration*/ configuration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784444512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.MEC.ConfigurationBinder.Get$2(T, configuration, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784444512)
            
            //--TRIMMABLE-BOUNDARY-START(94489477216)
            static /*T? */ Get$2(T, /*this IConfiguration*/ configuration, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489477216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                /*object?*/ let result = $.$mecb.MEC.ConfigurationBinder.Get(configuration, T.$type, configureOptions);
                if (result === null)
                {
                    return $.$default(T);
                }
                return $.$cast(result, T);
            }
            //--TRIMMABLE-BOUNDARY-END(94489477216)
            
            //--TRIMMABLE-BOUNDARY-START(90194509920)
            static /*object? */ Get$1(/*this IConfiguration*/ configuration, /*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194509920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.MEC.ConfigurationBinder.Get(configuration, type, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194509920)
            
            //--TRIMMABLE-BOUNDARY-START(85899542624)
            static /*object? */ Get(/*this IConfiguration*/ configuration, /*Type*/ type, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let options = new $.$mecb.MEC.BinderOptions().$ctor$1();
                configureOptions?.Invoke(options);
                /*var*/ let bindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(null, false);
                $.$mecb.MEC.ConfigurationBinder.BindInstance(type, bindingPoint, configuration, options, false);
                return bindingPoint.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(85899542624)
            
            //--TRIMMABLE-BOUNDARY-START(12885098592)
            static /*void */ Bind$2(/*this IConfiguration*/ configuration, /*string*/ key, /*object?*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$mecb.MEC.ConfigurationBinder.Bind$1(configuration.MEC$IConfiguration$GetSection(key), instance);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098592)
            
            //--TRIMMABLE-BOUNDARY-START(8590131296)
            static /*void */ Bind$1(/*this IConfiguration*/ configuration, /*object?*/ instance)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.MEC.ConfigurationBinder.Bind(configuration, instance, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590131296)
            
            //--TRIMMABLE-BOUNDARY-START(4295164000)
            static /*void */ Bind(/*this IConfiguration*/ configuration, /*object?*/ instance, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                if (instance !== null)
                {
                    /*var*/ let options = new $.$mecb.MEC.BinderOptions().$ctor$1();
                    configureOptions?.Invoke(options);
                    /*var*/ let bindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(instance, true);
                    $.$mecb.MEC.ConfigurationBinder.BindInstance($.$$.S.Object.GetType.call(instance), bindingPoint, configuration, options, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295164000)
            
            //--TRIMMABLE-BOUNDARY-START(124554248288)
            static /*T? */ GetValue$3(T, /*this IConfiguration*/ configuration, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554248288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.MEC.ConfigurationBinder.GetValue$2(T, configuration, key, $.$default(T));
            }
            //--TRIMMABLE-BOUNDARY-END(124554248288)
            
            //--TRIMMABLE-BOUNDARY-START(120259280992)
            static /*T? */ GetValue$2(T, /*this IConfiguration*/ configuration, /*string*/ key, /*T*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259280992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mecb.MEC.ConfigurationBinder.GetValue(configuration, T.$type, key, $.$box(defaultValue, T)), T);
            }
            //--TRIMMABLE-BOUNDARY-END(120259280992)
            
            //--TRIMMABLE-BOUNDARY-START(115964313696)
            static /*object? */ GetValue$1(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.MEC.ConfigurationBinder.GetValue(configuration, type, key, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115964313696)
            
            //--TRIMMABLE-BOUNDARY-START(111669346400)
            static /*object? */ GetValue(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key, /*object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*IConfigurationSection*/ let section = configuration.MEC$IConfiguration$GetSection(key);
                /*string?*/ let value = section.MEC$IConfigurationSection$Value;
                if (value !== null)
                {
                    return $.$mecb.MEC.ConfigurationBinder.ConvertValue(type, value, section.MEC$IConfigurationSection$Path);
                }
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(111669346400)
            
            //--TRIMMABLE-BOUNDARY-START(42949869664)
            static /*void */ BindProperties(/*object*/ instance, /*IConfiguration*/ configuration, /*BinderOptions*/ options, /*ParameterInfo[]?*/ constructorParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<PropertyInfo>*/ let modelProperties = $.$mecb.MEC.ConfigurationBinder.GetAllProperties($.$$.S.Object.GetType.call(instance));
                if (options.ErrorOnUnknownConfiguration)
                {
                    /*HashSet<string>*/ let propertyNames = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$2($.$sl.SL.Enumerable.Select$1($.$$.SR.PropertyInfo, $.$$.S.String, modelProperties, new ($.$$.S.Func$$$($.$$.SR.PropertyInfo, $.$$.S.String))().$ctor(this,  (/*mp*/ mp) =>
                    {
                        return mp.Name;
                    }, $SVjQTe ??= {"r":1310721,"p":[{"n":"mp","p":119603201}],"n":"","d":196704,"h":0,"f":17825794})), $.$$.S.StringComparer.OrdinalIgnoreCase);
                    /*List<string>?*/ let missingPropertyNames = null;
                    let $en1 = configuration.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let cs = $en1.SCG$IEnumerator$$$Current;
                        {
                            if (!propertyNames.Contains(cs.MEC$IConfigurationSection$Key))
                            {
                                (missingPropertyNames ??= new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1()).Add(`'${$.$strNN(cs.MEC$IConfigurationSection$Key)}'`);
                            }
                        }
                    }
                    if (missingPropertyNames !== null)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$7($.$mecb.S.SR.Error_MissingConfig, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "ErrorOnUnknownConfiguration", "BinderOptions", $.$$.S.Object.GetType.call(instance), $.$$.S.String.Join$5(", ", missingPropertyNames) ], null, null)));
                    }
                }
                let $en2 = modelProperties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    let property = $en2.Current;
                    {
                        if (constructorParameters === null || !$.$sl.SL.Enumerable.Any($.$$.SR.ParameterInfo, constructorParameters, new ($.$$.S.Func$$$($.$$.SR.ParameterInfo, $.$$.S.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Name === property.Name;
                        }, $SeIYIg ??= {"r":262145,"p":[{"n":"p","p":119078913}],"n":"","d":196704,"h":0,"f":17825794})))
                        {
                            $.$mecb.MEC.ConfigurationBinder.BindProperty(property, instance, configuration, options);
                        }
                        else 
                        {
                            $.$mecb.MEC.ConfigurationBinder.ResetPropertyValue(property, instance, options);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869664)
            
            //--TRIMMABLE-BOUNDARY-START(146029084768)
            static /*void */ ResetPropertyValue(/*PropertyInfo*/ property, /*object*/ instance, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (property.GetMethod === null || property.SetMethod === null || (!options.BindNonPublicProperties && (!property.GetMethod.IsPublic$1 || !property.SetMethod.IsPublic$1)) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                property.SetValue$2(instance, property.GetValue$2(instance));
            }
            //--TRIMMABLE-BOUNDARY-END(146029084768)
            
            //--TRIMMABLE-BOUNDARY-START(47244836960)
            static /*void */ BindProperty(/*PropertyInfo*/ property, /*object*/ instance, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.SR.MethodInfo.op_Equality$2(property.GetMethod, null) || (!options.BindNonPublicProperties && !property.GetMethod.IsPublic$1) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$1(new ($.$$.S.Func$$($.$$.S.Object))().$ctor(this,  () =>
                {
                    return property.GetValue$2(instance);
                }, $OQNhRf ??= {"r":131073,"n":"","d":196704,"h":0,"f":17825794}), property.SetMethod === null || (!property.SetMethod.IsPublic$1 && !options.BindNonPublicProperties));
                $.$mecb.MEC.ConfigurationBinder.BindInstance(property.PropertyType, propertyBindingPoint, config.MEC$IConfiguration$GetSection($.$mecb.MEC.ConfigurationBinder.GetPropertyName(property)), options, false);
                if (!propertyBindingPoint.IsReadOnly && (!(propertyBindingPoint.Value === null) || propertyBindingPoint.HasNewValue))
                {
                    property.SetValue$2(instance, propertyBindingPoint.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244836960)
            
            //--TRIMMABLE-BOUNDARY-START(34359935072)
            static /*void */ BindInstance(/*Type*/ type, /*BindingPoint*/ bindingPoint, /*IConfiguration*/ config, /*BinderOptions*/ options, /*bool*/ isParentCollection)
            {
                /*object?*/ let convertedValue;
                /*Exception?*/ let error;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type === $.$mecga.MEC.IConfigurationSection.$type)
                {
                    bindingPoint.TrySetValue(config);
                    return;
                }
                if (config === null)
                {
                    return;
                }
                /*IConfigurationSection?*/ let section;
                /*string?*/ let configValue;
                /*bool*/ let isConfigurationExist;
                let configSection;
                if ($.$is(config, $.$mec.MEC.ConfigurationSection, { set $v($v){ configSection = $v; } }))
                {
                    section = configSection;
                    isConfigurationExist = configSection.TryGetValue(null, $.$ref(() => configValue, ($v) => configValue = $v, $.$$.S.String));
                }
                else 
                {
                    section = $.$as(config, $.$mecga.MEC.IConfigurationSection);
                    configValue = (section?.MEC$IConfigurationSection$Value ?? null);
                    isConfigurationExist = configValue !== null;
                }
                if (isConfigurationExist && $.$mecb.MEC.ConfigurationBinder.TryConvertValue(type, configValue, (section?.MEC$IConfigurationSection$Path ?? null), $.$ref(() => convertedValue, ($v) => convertedValue = $v, $.$$.S.Object), $.$ref(() => error, ($v) => error = $v, $.$$.S.Exception)))
                {
                    if (error !== null)
                    {
                        throw error;
                    }
                    let byteArray;
                    if (type === $.$typeArray($.$$.S.Byte).$type && $.$is(bindingPoint.Value, $.$typeArray($.$$.S.Byte), { set $v($v){ byteArray = $v; } }) && byteArray.length > 0)
                    {
                        let convertedByteArray;
                        if ($.$is(convertedValue, $.$typeArray($.$$.S.Byte), { set $v($v){ convertedByteArray = $v; } }) && convertedByteArray.length > 0)
                        {
                            /*Array*/ let a = $.$$.S.Array.CreateInstance$2(type.GetElementType(), ((byteArray.length + convertedByteArray.length) | 0));
                            $.$$.S.Array.Copy$2(byteArray, a, byteArray.length);
                            $.$$.S.Array.Copy(convertedByteArray, 0, a, byteArray.length, convertedByteArray.length);
                            bindingPoint.TrySetValue(a);
                        }
                        return;
                    }
                    bindingPoint.TrySetValue(convertedValue);
                    return;
                }
                if ($.$sl.SL.Enumerable.Any$1($.$mecga.MEC.IConfigurationSection, config.MEC$IConfiguration$GetChildren()))
                {
                    if (type.IsArray || $.$mecb.MEC.ConfigurationBinder.IsImmutableArrayCompatibleInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly)
                        {
                            bindingPoint.SetValue($.$mecb.MEC.ConfigurationBinder.BindArray(type, $.$cast(bindingPoint.Value, $.$$.SC$1.IEnumerable), config, options));
                        }
                        return;
                    }
                    if ($.$mecb.MEC.ConfigurationBinder.TypeIsASetInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.MEC.ConfigurationBinder.BindSet(type, $.$cast(bindingPoint.Value, $.$$.SC$1.IEnumerable), config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    if ($.$mecb.MEC.ConfigurationBinder.TypeIsADictionaryInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.MEC.ConfigurationBinder.BindDictionaryInterface(bindingPoint.Value, type, config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    /*ParameterInfo[]?*/ let constructorParameters = null;
                    if (bindingPoint.Value === null)
                    {
                        if (bindingPoint.IsReadOnly)
                        {
                            return;
                        }
                        /*Type?*/ let interfaceGenericType = type.IsInterface && type.IsConstructedGenericType ? type.GetGenericTypeDefinition() : null;
                        if (!(interfaceGenericType === null) && (interfaceGenericType === $.$$.SCG.ICollection$$().$type || interfaceGenericType === $.$$.SCG.IList$$().$type))
                        {
                            /*Type*/ let genericType = $.$$.SCG.List$$().$type.MakeGenericType(type.GenericTypeArguments);
                            bindingPoint.SetValue($.$$.S.Activator.CreateInstance$9(genericType));
                        }
                        else 
                        {
                            bindingPoint.SetValue($.$mecb.MEC.ConfigurationBinder.CreateInstance(type, config, options, $.$ref(() => constructorParameters, ($v) => constructorParameters = $v, $.$typeArray($.$$.SR.ParameterInfo))));
                        }
                    }
                    $.$$.SD.Debug.Assert$4(!(bindingPoint.Value === null), "bindingPoint.Value is not null");
                    /*Type?*/ let dictionaryInterface = $.$mecb.MEC.ConfigurationBinder.FindOpenGenericInterface($.$$.SCG.IDictionary$$$().$type, type);
                    if (dictionaryInterface !== null)
                    {
                        $.$mecb.MEC.ConfigurationBinder.BindDictionary(bindingPoint.Value, dictionaryInterface, config, options);
                    }
                    else 
                    {
                        /*Type?*/ let collectionInterface = $.$mecb.MEC.ConfigurationBinder.FindOpenGenericInterface($.$$.SCG.ICollection$$().$type, type);
                        if (collectionInterface !== null)
                        {
                            $.$mecb.MEC.ConfigurationBinder.BindCollection(bindingPoint.Value, collectionInterface, config, options);
                        }
                        else 
                        {
                            $.$mecb.MEC.ConfigurationBinder.BindProperties(bindingPoint.Value, config, options, constructorParameters);
                        }
                    }
                }
                else 
                {
                    if (!$.$$.S.String.IsNullOrEmpty(configValue))
                    {
                        if (options.ErrorOnUnknownConfiguration)
                        {
                            $.$$.SD.Debug.Assert$4(!(section === null), "section is not null");
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$4($.$mecb.S.SR.Error_FailedBinding, configValue, section.MEC$IConfigurationSection$Path, type));
                        }
                    }
                    else if (!bindingPoint.IsReadOnly && bindingPoint.Value === null)
                    {
                        if (isParentCollection)
                        {
                            bindingPoint.TrySetValue($.$mecb.MEC.ConfigurationBinder.CreateInstance(type, config, options, $.$discardRef()));
                        }
                        else if (isConfigurationExist)
                        {
                            if (type.IsArray || $.$mecb.MEC.ConfigurationBinder.IsIEnumerableInterface(type))
                            {
                                bindingPoint.TrySetValue(configValue === null ? null : $.$$.S.Array.CreateInstance$2(type.IsArray ? type.GetElementType() : $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0), 0));
                            }
                            else 
                            {
                                bindingPoint.TrySetValue(bindingPoint.Value);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359935072)
            
            //--TRIMMABLE-BOUNDARY-START(64424706144)
            static /*object */ CreateInstance(/*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options, /*out ParameterInfo[]?*/ constructorParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                constructorParameters.$v = null;
                if (type.IsInterface || type.IsAbstract$1)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_CannotActivateAbstractOrInterface, type));
                }
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors$1(16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/);
                /*bool*/ let hasParameterlessConstructor = type.IsValueType || $.$sl.SL.Enumerable.Any($.$$.SR.ConstructorInfo, constructors, new ($.$$.S.Func$$$($.$$.SR.ConstructorInfo, $.$$.S.Boolean))().$ctor(this,  (/*ctor*/ ctor) =>
                {
                    return ctor.GetParameters().length === 0;
                }, $xSZftj ??= {"r":262145,"p":[{"n":"ctor","p":109182977}],"n":"","d":196704,"h":0,"f":17825794}));
                if (!type.IsValueType && constructors.length === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_MissingPublicInstanceConstructor, type));
                }
                if (constructors.length > 1 && !hasParameterlessConstructor)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_MultipleParameterizedConstructors, type));
                }
                if (constructors.length === 1 && !hasParameterlessConstructor)
                {
                    /*string*/ let nameOfInvalidParameter;
                    /*string*/ let nameOfInvalidParameters;
                    /*ConstructorInfo*/ let $constructor = $.$$.System.Array.$ReadT1.call(constructors, 0);
                    /*ParameterInfo[]*/ let parameters = $constructor.GetParameters();
                    if (!$.$mecb.MEC.ConfigurationBinder.CanBindToTheseConstructorParameters(parameters, $.$ref(() => nameOfInvalidParameter, ($v) => nameOfInvalidParameter = $v, $.$$.S.String)))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$5($.$mecb.S.SR.Error_CannotBindToConstructorParameter, type, nameOfInvalidParameter));
                    }
                    /*List<PropertyInfo>*/ let properties = $.$mecb.MEC.ConfigurationBinder.GetAllProperties(type);
                    if (!$.$mecb.MEC.ConfigurationBinder.DoAllParametersHaveEquivalentProperties(parameters, properties, $.$ref(() => nameOfInvalidParameters, ($v) => nameOfInvalidParameters = $v, $.$$.S.String)))
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$5($.$mecb.S.SR.Error_ConstructorParametersDoNotMatchProperties, type, nameOfInvalidParameters));
                    }
                    /*object?[]*/ let parameterValues = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [parameters.length], null);
                    for(/*int*/ let index = 0; index < parameters.length; index++)
                    {
                        $.$$.System.Array.$WriteT1.call(parameterValues, $.$mecb.MEC.ConfigurationBinder.BindParameter($.$$.System.Array.$ReadT1.call(parameters, index), type, config, options), index);
                    }
                    constructorParameters.$v = parameters;
                    return $constructor.Invoke$2(parameterValues);
                }
                /*object?*/ let instance;
                try
                {
                    instance = $.$$.S.Activator.CreateInstance$9($.$$.S.Nullable.GetUnderlyingType(type) ?? type);
                }
                catch(ex)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_FailedToActivate, type), ex);
                }
                return $.$firstOf(instance, () => { throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_FailedToActivate, type)) });
            }
            //--TRIMMABLE-BOUNDARY-END(64424706144)
            
            //--TRIMMABLE-BOUNDARY-START(73014640736)
            static /*bool */ DoAllParametersHaveEquivalentProperties(/*ParameterInfo[]*/ parameters, /*List<PropertyInfo>*/ properties, /*out string*/ missing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*HashSet<string>*/ let propertyNames = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$4($.$$.S.StringComparer.OrdinalIgnoreCase);
                let $en9 = properties.GetEnumerator();
                while ($en9.MoveNext())
                {
                    let prop = $en9.Current;
                    {
                        propertyNames.Add(prop.Name);
                    }
                }
                /*List<string>*/ let missingParameters = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                let $i10 = 0;
                let $arr10 = parameters;
                while ($i10 < $arr10.length)
                {
                    let parameter = $arr10[$i10++];
                    /*string*/ let name = parameter.Name;
                    if (!propertyNames.Contains(name))
                    {
                        missingParameters.Add(name);
                    }
                }
                missing.$v = $.$$.S.String.Join$5(",", missingParameters);
                return missing.$v.length === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640736)
            
            //--TRIMMABLE-BOUNDARY-START(55834771552)
            static /*bool */ CanBindToTheseConstructorParameters(/*ParameterInfo[]*/ constructorParameters, /*out string*/ nameOfInvalidParameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                nameOfInvalidParameter.$v = $.$$.S.String.Empty;
                let $i11 = 0;
                let $arr11 = constructorParameters;
                while ($i11 < $arr11.length)
                {
                    let p = $arr11[$i11++];
                    if (p.IsOut || p.IsIn || p.ParameterType.IsByRef)
                    {
                        nameOfInvalidParameter.$v = p.Name;
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771552)
            
            //--TRIMMABLE-BOUNDARY-START(30064967776)
            static /*object? */ BindDictionaryInterface(/*object?*/ source, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = keyType === $.$$.S.SByte.$type || keyType === $.$$.S.Byte.$type || keyType === $.$$.S.Int16.$type || keyType === $.$$.S.UInt16.$type || keyType === $.$$.S.Int32.$type || keyType === $.$$.S.UInt32.$type || keyType === $.$$.S.Int64.$type || keyType === $.$$.S.UInt64.$type;
                if (keyType !== $.$$.S.String.$type && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return null;
                }
                /*MethodInfo?*/ let addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    dictionaryType = $.$$.SCG.Dictionary$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ keyType, valueType ], null, null));
                    /*object?*/ let dictionary = $.$$.S.Activator.CreateInstance$9(dictionaryType);
                    addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    /*var*/ let orig = $.$as(source, $.$$.SC$1.IEnumerable);
                    if (!(orig === null))
                    {
                        /*Type*/ let kvpType = $.$$.SCG.KeyValuePair$$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ keyType, valueType ], null, null));
                        /*PropertyInfo*/ let keyMethod = kvpType.GetProperty$1("Key", 62/*DeclaredOnlyLookup*/);
                        /*PropertyInfo*/ let valueMethod = kvpType.GetProperty$1("Value", 62/*DeclaredOnlyLookup*/);
                        /*object?[]*/ let $arguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [2], null);
                        let $en12 = orig.SC$1$IEnumerable$GetEnumerator();
                        while ($en12.SC$1$IEnumerator$MoveNext())
                        {
                            let item = $en12.SC$1$IEnumerator$Current;
                            {
                                /*object?*/ let k = keyMethod.GetMethod.Invoke(item, null);
                                /*object?*/ let v = valueMethod.GetMethod.Invoke(item, null);
                                $.$$.System.Array.$WriteT1.call($arguments, k, 0);
                                $.$$.System.Array.$WriteT1.call($arguments, v, 1);
                                addMethod.Invoke(dictionary, $arguments);
                            }
                        }
                    }
                    source = dictionary;
                }
                $.$$.SD.Debug.Assert$4(!(source === null), "source is not null");
                $.$$.SD.Debug.Assert$4(!(addMethod === null), "addMethod is not null");
                $.$mecb.MEC.ConfigurationBinder.BindDictionary(source, dictionaryType, config, options);
                return source;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967776)
            
            //--TRIMMABLE-BOUNDARY-START(25770000480)
            static /*void */ BindDictionary(/*object*/ dictionary, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(dictionaryType.IsGenericType && (dictionaryType.GetGenericTypeDefinition() === $.$$.SCG.IDictionary$$$().$type || dictionaryType.GetGenericTypeDefinition() === $.$$.SCG.Dictionary$$$().$type), "dictionaryType.IsGenericType &&\r\n                         (dictionaryType.GetGenericTypeDefinition() == typeof(IDictionary<,>) || dictionaryType.GetGenericTypeDefinition() == typeof(Dictionary<,>))");
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = keyType === $.$$.S.SByte.$type || keyType === $.$$.S.Byte.$type || keyType === $.$$.S.Int16.$type || keyType === $.$$.S.UInt16.$type || keyType === $.$$.S.Int32.$type || keyType === $.$$.S.UInt32.$type || keyType === $.$$.S.Int64.$type || keyType === $.$$.S.UInt64.$type;
                if (keyType !== $.$$.S.String.$type && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return;
                }
                /*MethodInfo*/ let tryGetValue = dictionaryType.GetMethod$9("TryGetValue", 62/*DeclaredOnlyLookup*/);
                /*PropertyInfo*/ let indexerProperty = dictionaryType.GetProperty$1("Item", 62/*DeclaredOnlyLookup*/);
                let $en13 = config.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                while ($en13.SC$1$IEnumerator$MoveNext())
                {
                    let child = $en13.SCG$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*object*/ let key = keyTypeIsEnum ? $.$$.S.Enum.Parse$2(keyType, child.MEC$IConfigurationSection$Key, true) : keyTypeIsInteger ? $.$$.S.Convert.ChangeType$1(child.MEC$IConfigurationSection$Key, keyType) : child.MEC$IConfigurationSection$Key;
                            /*var*/ let valueBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$1(new ($.$$.S.Func$$($.$$.S.Object))().$ctor(this,  () =>
                            {
                                /*object?[]*/ let tryGetValueArgs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [key, null], null, null);
                                return $.$cast(tryGetValue.Invoke(dictionary, tryGetValueArgs), $.$$.S.Boolean) ? $.$$.System.Array.$ReadT1.call(tryGetValueArgs, 1) : null;
                            }, $FmZWQf ??= {"r":131073,"n":"","d":196704,"h":0,"f":17825794}), false);
                            $.$mecb.MEC.ConfigurationBinder.BindInstance(valueType, valueBindingPoint, child, options, true);
                            if (valueBindingPoint.HasNewValue)
                            {
                                indexerProperty.SetValue(dictionary, valueBindingPoint.Value, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [key], [-1], null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000480)
            
            //--TRIMMABLE-BOUNDARY-START(21475033184)
            static /*void */ BindCollection(/*object*/ collection, /*Type*/ collectionType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let itemType = $.$$.System.Array.$ReadT1.call(collectionType.GenericTypeArguments, 0);
                /*MethodInfo?*/ let addMethod = collectionType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                let $en14 = config.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                while ($en14.SC$1$IEnumerator$MoveNext())
                {
                    let section = $en14.SCG$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*BindingPoint*/ let itemBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(null, false);
                            $.$mecb.MEC.ConfigurationBinder.BindInstance(itemType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                addMethod?.Invoke(collection, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [itemBindingPoint.Value], null, null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033184)
            
            //--TRIMMABLE-BOUNDARY-START(17180065888)
            static /*Array */ BindArray(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let elementType;
                if (type.IsArray)
                {
                    if (type.GetArrayRank() > 1)
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_UnsupportedMultidimensionalArray, type));
                    }
                    elementType = type.GetElementType();
                }
                else 
                {
                    elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                }
                /*var*/ let list = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                if (source !== null)
                {
                    let $en15 = source.SC$1$IEnumerable$GetEnumerator();
                    while ($en15.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en15.SC$1$IEnumerator$Current;
                        {
                            list.Add(item);
                        }
                    }
                }
                let $en16 = config.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                while ($en16.SC$1$IEnumerator$MoveNext())
                {
                    let section = $en16.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.MEC.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                list.Add(itemBindingPoint.Value);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                /*Array*/ let result = $.$$.S.Array.CreateInstance$2(elementType, list.Count);
                (list).SC$1$ICollection$CopyTo(result, 0);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065888)
            
            //--TRIMMABLE-BOUNDARY-START(51539804256)
            static /*object? */ BindSet(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                /*bool*/ let elementTypeIsEnum = elementType.IsEnum;
                if (elementType !== $.$$.S.String.$type && !elementTypeIsEnum)
                {
                    return null;
                }
                /*object?[]*/ let $arguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [1], null);
                /*MethodInfo?*/ let addMethod = type.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    /*Type*/ let genericType = $.$$.SCG.HashSet$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ elementType ], null, null));
                    /*object*/ let instance = $.$$.S.Activator.CreateInstance$9(genericType);
                    addMethod = genericType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    if (source !== null)
                    {
                        let $en17 = source.SC$1$IEnumerable$GetEnumerator();
                        while ($en17.SC$1$IEnumerator$MoveNext())
                        {
                            let item = $en17.SC$1$IEnumerator$Current;
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, item, 0);
                                addMethod.Invoke(instance, $arguments);
                            }
                        }
                    }
                    source = $.$cast(instance, $.$$.SC$1.IEnumerable);
                }
                $.$$.SD.Debug.Assert$4(!(source === null), "source is not null");
                $.$$.SD.Debug.Assert$4(!(addMethod === null), "addMethod is not null");
                let $en18 = config.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                while ($en18.SC$1$IEnumerator$MoveNext())
                {
                    let section = $en18.SCG$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.MEC.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, itemBindingPoint.Value, 0);
                                addMethod.Invoke(source, $arguments);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                return source;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804256)
            
            //--TRIMMABLE-BOUNDARY-START(154619019360)
            static /*bool */ TryConvertValue(/*Type*/ type, /*string?*/ value, /*string?*/ path, /*out object?*/ result, /*out Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619019360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                error.$v = null;
                result.$v = null;
                if (type === $.$$.S.Object.$type)
                {
                    result.$v = value;
                    return true;
                }
                if (type.IsGenericType && type.GetGenericTypeDefinition() === $.$$.S.Nullable$$().$type)
                {
                    if ($.$$.S.String.IsNullOrEmpty(value))
                    {
                        return true;
                    }
                    return $.$mecb.MEC.ConfigurationBinder.TryConvertValue($.$$.S.Nullable.GetUnderlyingType(type), value, path, result, error);
                }
                /*TypeConverter*/ let converter = $.$sct.SC.TypeDescriptor.GetConverter$2(type);
                if (converter.CanConvertFrom$1($.$$.S.String.$type))
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = converter.ConvertFromInvariantString$1(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$4($.$mecb.S.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                if (type === $.$typeArray($.$$.S.Byte).$type)
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = value === $.$$.S.String.Empty ? $.$$.S.Array.Empty($.$$.S.Byte) : $.$$.S.Convert.FromBase64String(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.S.InvalidOperationException().$ctor$11($.$mecb.S.SR.Format$4($.$mecb.S.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154619019360)
            
            //--TRIMMABLE-BOUNDARY-START(60129738848)
            static /*object? */ ConvertValue(/*Type*/ type, /*string*/ value, /*string?*/ path)
            {
                /*object?*/ let result;
                /*Exception?*/ let error;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecb.MEC.ConfigurationBinder.TryConvertValue(type, value, path, $.$ref(() => result, ($v) => result = $v, $.$$.S.Object), $.$ref(() => error, ($v) => error = $v, $.$$.S.Exception));
                if (error !== null)
                {
                    throw error;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738848)
            
            //--TRIMMABLE-BOUNDARY-START(158913986656)
            static /*bool */ TypeIsADictionaryInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return genericTypeDefinition === $.$$.SCG.IDictionary$$$().$type || genericTypeDefinition === $.$$.SCG.IReadOnlyDictionary$$$().$type;
            }
            //--TRIMMABLE-BOUNDARY-END(158913986656)
            
            //--TRIMMABLE-BOUNDARY-START(137439150176)
            static /*bool */ IsImmutableArrayCompatibleInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439150176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return genericTypeDefinition === $.$$.SCG.IEnumerable$$().$type || genericTypeDefinition === $.$$.SCG.IReadOnlyCollection$$().$type || genericTypeDefinition === $.$$.SCG.IReadOnlyList$$().$type;
            }
            //--TRIMMABLE-BOUNDARY-END(137439150176)
            
            //--TRIMMABLE-BOUNDARY-START(133144182880)
            static /*bool */ IsIEnumerableInterface(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144182880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return type.IsInterface && type.IsConstructedGenericType && type.GetGenericTypeDefinition() === $.$$.SCG.IEnumerable$$().$type;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144182880)
            
            //--TRIMMABLE-BOUNDARY-START(163208953952)
            static /*bool */ TypeIsASetInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208953952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return genericTypeDefinition === $.$$.SCG.ISet$$().$type || genericTypeDefinition === $.$$.SCG.IReadOnlySet$$().$type;
            }
            //--TRIMMABLE-BOUNDARY-END(163208953952)
            
            //--TRIMMABLE-BOUNDARY-START(81604575328)
            static /*Type? */ FindOpenGenericInterface(/*Type*/ expected, /*Type*/ actual)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (actual.IsGenericType && actual.GetGenericTypeDefinition() === expected)
                {
                    return actual;
                }
                /*Type[]*/ let interfaces = actual.GetInterfaces();
                let $i23 = 0;
                let $arr23 = interfaces;
                while ($i23 < $arr23.length)
                {
                    let interfaceType = $arr23[$i23++];
                    if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() === expected)
                    {
                        return interfaceType;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604575328)
            
            //--TRIMMABLE-BOUNDARY-START(103079411808)
            static /*List<PropertyInfo> */ GetAllProperties(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let allProperties = new ($.$$.SCG.List$$($.$$.SR.PropertyInfo))().$ctor$1();
                /*Type*/ let baseType = type;
                while(baseType !== $.$$.S.Object.$type)
                {
                    /*PropertyInfo[]*/ let properties = baseType.GetProperties$1(62/*DeclaredOnlyLookup*/);
                    let $i24 = 0;
                    let $arr24 = properties;
                    while ($i24 < $arr24.length)
                    {
                        let property = $arr24[$i24++];
                        /*MethodInfo?*/ let setMethod = property.GetSetMethod$1(true);
                        if (setMethod === null || !setMethod.IsVirtual$1 || $.$$.SR.MethodInfo.op_Equality$2(setMethod, setMethod.GetBaseDefinition()))
                        {
                            allProperties.Add(property);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                return allProperties;
            }
            //--TRIMMABLE-BOUNDARY-END(103079411808)
            
            //--TRIMMABLE-BOUNDARY-START(38654902368)
            static /*object? */ BindParameter(/*ParameterInfo*/ parameter, /*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let parameterName = parameter.Name;
                if (parameterName === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$6($.$mecb.S.SR.Error_ParameterBeingBoundToIsUnnamed, type));
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.MEC.BindingPoint().$ctor$2(config.MEC$IConfiguration$GetSection(parameterName).MEC$IConfigurationSection$Value, false);
                $.$mecb.MEC.ConfigurationBinder.BindInstance(parameter.ParameterType, propertyBindingPoint, config.MEC$IConfiguration$GetSection(parameterName), options, false);
                if (propertyBindingPoint.Value === null)
                {
                    /*object?*/ let defaultValue;
                    if ($.$mecb.MEI.ParameterDefaultValue.TryGetDefaultValue(parameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.S.Object)))
                    {
                        propertyBindingPoint.SetValue(defaultValue);
                    }
                    else 
                    {
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mecb.S.SR.Format$5($.$mecb.S.SR.Error_ParameterHasNoMatchingConfig, type, parameterName));
                    }
                }
                return propertyBindingPoint.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902368)
            
            //--TRIMMABLE-BOUNDARY-START(107374379104)
            static /*string */ GetPropertyName(/*PropertyInfo*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(property, "property");
                let $en26 = property.GetCustomAttributesData().SCG$IEnumerable$$$GetEnumerator();
                while ($en26.SC$1$IEnumerator$MoveNext())
                {
                    let attributeData = $en26.SCG$IEnumerator$$$Current;
                    {
                        if (attributeData.AttributeType !== $.$mecga.MEC.ConfigurationKeyNameAttribute.$type)
                        {
                            continue;
                        }
                        if (attributeData.ConstructorArguments.SCG$ICollection$$$Count !== 1)
                        {
                            break;
                        }
                        /*object?*/ let __ca1__;
                        /*string?*/ let name = ((__ca1__ = attributeData.ConstructorArguments.SCG$IList$$$get_Item(0).Value) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.ToString) : null);
                        return !$.$$.S.String.IsNullOrWhiteSpace(name) ? name : property.Name;
                    }
                }
                return property.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(107374379104)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77309608032)
                    this.DynamicCodeWarningMessage = "Binding strongly typed objects to configuration values requires generating dynamic code at runtime, for example instantiating generic types.";
                    //--TRIMMABLE-BOUNDARY-END(77309608032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324052064)
                    this.TrimmingWarningMessage = "In case the type is non-primitive, the trimmer cannot statically analyze the object's type so its members may be trimmed.";
                    //--TRIMMABLE-BOUNDARY-END(150324052064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849215584)
                    this.InstanceGetTypeTrimmingWarningMessage = "Cannot statically analyze the type of instance so its members may be trimmed";
                    //--TRIMMABLE-BOUNDARY-END(128849215584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734117472)
                    this.PropertyTrimmingWarningMessage = "Cannot statically analyze property.PropertyType so its members may be trimmed.";
                    //--TRIMMABLE-BOUNDARY-END(141734117472)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 196704;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784444512),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "o": "@$3",
      "d": 196704,
      "h": 98784444512,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784444512),
//--TRIMMABLE-BOUNDARY-START(94489477216),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "o": "@$2",
      "d": 196704,
      "h": 94489477216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489477216),
//--TRIMMABLE-BOUNDARY-START(90194509920),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 196704,
      "h": 90194509920,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194509920),
//--TRIMMABLE-BOUNDARY-START(85899542624),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "n": "Get",
      "d": 196704,
      "h": 85899542624,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899542624),
//--TRIMMABLE-BOUNDARY-START(12885098592),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": "Bind",
      "o": "@$2",
      "d": 196704,
      "h": 12885098592,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885098592),
//--TRIMMABLE-BOUNDARY-START(8590131296),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": "Bind",
      "o": "@$1",
      "d": 196704,
      "h": 8590131296,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131296),
//--TRIMMABLE-BOUNDARY-START(4295164000),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$mecb.MEC.BinderOptions).$h
        }
      ],
      "n": "Bind",
      "d": 196704,
      "h": 4295164000,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164000),
//--TRIMMABLE-BOUNDARY-START(124554248288),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$3",
      "d": 196704,
      "h": 124554248288,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554248288),
//--TRIMMABLE-BOUNDARY-START(120259280992),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$2",
      "d": 196704,
      "h": 120259280992,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259280992),
//--TRIMMABLE-BOUNDARY-START(115964313696),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetValue",
      "o": "@$1",
      "d": 196704,
      "h": 115964313696,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964313696),
//--TRIMMABLE-BOUNDARY-START(111669346400),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "d": 196704,
      "h": 111669346400,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669346400),
//--TRIMMABLE-BOUNDARY-START(42949869664),
    {
      "r": 65537,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.SR.ParameterInfo).$h
        }
      ],
      "n": "BindProperties",
      "d": 196704,
      "h": 42949869664,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949869664),
//--TRIMMABLE-BOUNDARY-START(146029084768),
    {
      "r": 65537,
      "p": [
        {
          "n": "property",
          "p": 119603201
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "ResetPropertyValue",
      "d": 196704,
      "h": 146029084768,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146029084768),
//--TRIMMABLE-BOUNDARY-START(47244836960),
    {
      "r": 65537,
      "p": [
        {
          "n": "property",
          "p": 119603201
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindProperty",
      "d": 196704,
      "h": 47244836960,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244836960),
//--TRIMMABLE-BOUNDARY-START(34359935072),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "bindingPoint",
          "p": 131168
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "isParentCollection",
          "p": 262145
        }
      ],
      "n": "BindInstance",
      "d": 196704,
      "h": 34359935072,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359935072),
//--TRIMMABLE-BOUNDARY-START(64424706144),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.SR.ParameterInfo).$h,
          "f": 2
        }
      ],
      "n": "CreateInstance",
      "d": 196704,
      "h": 64424706144,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424706144),
//--TRIMMABLE-BOUNDARY-START(73014640736),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.SR.ParameterInfo).$h
        },
        {
          "n": "properties",
          "p": $.$$.SCG.List$$($.$$.SR.PropertyInfo).$h
        },
        {
          "n": "missing",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "DoAllParametersHaveEquivalentProperties",
      "d": 196704,
      "h": 73014640736,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014640736),
//--TRIMMABLE-BOUNDARY-START(55834771552),
    {
      "r": 262145,
      "p": [
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.SR.ParameterInfo).$h
        },
        {
          "n": "nameOfInvalidParameter",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "CanBindToTheseConstructorParameters",
      "d": 196704,
      "h": 55834771552,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834771552),
//--TRIMMABLE-BOUNDARY-START(30064967776),
    {
      "r": 131073,
      "p": [
        {
          "n": "source",
          "p": 131073
        },
        {
          "n": "dictionaryType",
          "p": 188547073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindDictionaryInterface",
      "d": 196704,
      "h": 30064967776,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064967776),
//--TRIMMABLE-BOUNDARY-START(25770000480),
    {
      "r": 65537,
      "p": [
        {
          "n": "dictionary",
          "p": 131073
        },
        {
          "n": "dictionaryType",
          "p": 188547073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindDictionary",
      "d": 196704,
      "h": 25770000480,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770000480),
//--TRIMMABLE-BOUNDARY-START(21475033184),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 131073
        },
        {
          "n": "collectionType",
          "p": 188547073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindCollection",
      "d": 196704,
      "h": 21475033184,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475033184),
//--TRIMMABLE-BOUNDARY-START(17180065888),
    {
      "r": 1245185,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "source",
          "p": 63373313
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindArray",
      "d": 196704,
      "h": 17180065888,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180065888),
//--TRIMMABLE-BOUNDARY-START(51539804256),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "source",
          "p": 63373313
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindSet",
      "d": 196704,
      "h": 51539804256,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539804256),
//--TRIMMABLE-BOUNDARY-START(154619019360),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 131073,
          "f": 2
        },
        {
          "n": "error",
          "p": 80805889,
          "f": 2
        }
      ],
      "n": "TryConvertValue",
      "d": 196704,
      "h": 154619019360,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154619019360),
//--TRIMMABLE-BOUNDARY-START(60129738848),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "ConvertValue",
      "d": 196704,
      "h": 60129738848,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129738848),
//--TRIMMABLE-BOUNDARY-START(158913986656),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "TypeIsADictionaryInterface",
      "d": 196704,
      "h": 158913986656,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158913986656),
//--TRIMMABLE-BOUNDARY-START(137439150176),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "IsImmutableArrayCompatibleInterface",
      "d": 196704,
      "h": 137439150176,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137439150176),
//--TRIMMABLE-BOUNDARY-START(133144182880),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "IsIEnumerableInterface",
      "d": 196704,
      "h": 133144182880,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133144182880),
//--TRIMMABLE-BOUNDARY-START(163208953952),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "TypeIsASetInterface",
      "d": 196704,
      "h": 163208953952,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(163208953952),
//--TRIMMABLE-BOUNDARY-START(81604575328),
    {
      "r": 188547073,
      "p": [
        {
          "n": "expected",
          "p": 188547073
        },
        {
          "n": "actual",
          "p": 188547073
        }
      ],
      "n": "FindOpenGenericInterface",
      "d": 196704,
      "h": 81604575328,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604575328),
//--TRIMMABLE-BOUNDARY-START(103079411808),
    {
      "r": $.$$.SCG.List$$($.$$.SR.PropertyInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetAllProperties",
      "d": 196704,
      "h": 103079411808,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079411808),
//--TRIMMABLE-BOUNDARY-START(38654902368),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameter",
          "p": 119078913
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindParameter",
      "d": 196704,
      "h": 38654902368,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654902368),
//--TRIMMABLE-BOUNDARY-START(107374379104),
    {
      "r": 1310721,
      "p": [
        {
          "n": "property",
          "p": 119603201
        }
      ],
      "n": "GetPropertyName",
      "d": 196704,
      "h": 107374379104,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374379104)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719673440),
    {
      "t": 109051905,
      "n": "DeclaredOnlyLookup",
      "d": 196704,
      "h": 68719673440,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719673440),
//--TRIMMABLE-BOUNDARY-START(77309608032),
    {
      "t": 1310721,
      "n": "DynamicCodeWarningMessage",
      "d": 196704,
      "h": 77309608032,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309608032),
//--TRIMMABLE-BOUNDARY-START(150324052064),
    {
      "t": 1310721,
      "n": "TrimmingWarningMessage",
      "d": 196704,
      "h": 150324052064,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150324052064),
//--TRIMMABLE-BOUNDARY-START(128849215584),
    {
      "t": 1310721,
      "n": "InstanceGetTypeTrimmingWarningMessage",
      "d": 196704,
      "h": 128849215584,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849215584),
//--TRIMMABLE-BOUNDARY-START(141734117472),
    {
      "t": 1310721,
      "n": "PropertyTrimmingWarningMessage",
      "d": 196704,
      "h": 141734117472,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141734117472)
  ],
  "h": 196704
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196704)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter"));
})();
//--TRIMMABLE-BOUNDARY-END(96)
