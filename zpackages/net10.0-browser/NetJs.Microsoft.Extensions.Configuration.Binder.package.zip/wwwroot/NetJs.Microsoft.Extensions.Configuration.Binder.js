
//--TRIMMABLE-BOUNDARY-START(96)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mwp, $scn, $scm, $scp, $scs, $sdp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Binder", 
    {
  "h": 96,
  "f": "Microsoft.Extensions.Configuration.Binder",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Binder",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Binder",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327776)
        $asm.$cls("$mecb.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(296353071200)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(296353071200)
            
            //--TRIMMABLE-BOUNDARY-START(279173202016)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(279173202016);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173202016)
            
            //--TRIMMABLE-BOUNDARY-START(309237973088)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(309237973088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(309237973088)
            
            //--TRIMMABLE-BOUNDARY-START(274878234720)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878234720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecb.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(274878234720)
            
            //--TRIMMABLE-BOUNDARY-START(270583267424)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583267424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecb.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(270583267424)
            
            //--TRIMMABLE-BOUNDARY-START(90194640992)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194640992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(90194640992)
            
            //--TRIMMABLE-BOUNDARY-START(85899673696)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(85899673696)
            
            //--TRIMMABLE-BOUNDARY-START(81604706400)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706400)
            
            //--TRIMMABLE-BOUNDARY-START(94489608288)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecb.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(94489608288)
            
            //--TRIMMABLE-BOUNDARY-START(73014771808)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014771808)
            
            //--TRIMMABLE-BOUNDARY-START(68719804512)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68719804512)
            
            //--TRIMMABLE-BOUNDARY-START(64424837216)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecb.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837216)
            
            //--TRIMMABLE-BOUNDARY-START(77309739104)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecb.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77309739104)
            
            //--TRIMMABLE-BOUNDARY-START(292058103904)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(292058103904)
            
            //--TRIMMABLE-BOUNDARY-START(283468169312)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(283468169312)
            
            //--TRIMMABLE-BOUNDARY-START(287763136608)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288300128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mecb.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Binder", $.$mecb.System.SR.$type.Assembly);
                    $.$mecb.System.SR.s_resourceManager = temp;
                }
                return $.$mecb.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(287763136608)
            
            //--TRIMMABLE-BOUNDARY-START(8590262368)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619150432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943005792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecb.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262368)
            
            //--TRIMMABLE-BOUNDARY-START(12885229664)
            static /*string */ get Error_CannotActivateAbstractOrInterface()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209085024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is either abstract or an interface.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885229664)
            
            //--TRIMMABLE-BOUNDARY-START(98784575584)
            static /*string */ FormatError_CannotActivateAbstractOrInterface(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is either abstract or an interface.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98784575584)
            
            //--TRIMMABLE-BOUNDARY-START(17180196960)
            static /*string */ get Error_CannotBindToConstructorParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(17180196960)
            
            //--TRIMMABLE-BOUNDARY-START(103079542880)
            static /*string */ FormatError_CannotBindToConstructorParameter(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters cannot be declared as in, out, or ref. Invalid parameters are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(103079542880)
            
            //--TRIMMABLE-BOUNDARY-START(21475164256)
            static /*string */ get Error_ConstructorParametersDoNotMatchProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388954208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(21475164256)
            
            //--TRIMMABLE-BOUNDARY-START(107374510176)
            static /*string */ FormatError_ConstructorParametersDoNotMatchProperties(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because one or more parameters cannot be bound to. Constructor parameters must have corresponding properties. Fields are not supported. Missing properties are: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(107374510176)
            
            //--TRIMMABLE-BOUNDARY-START(25770131552)
            static /*string */ get Error_FailedBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to convert configuration value '{0}' at '{1}' to type '{2}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770131552)
            
            //--TRIMMABLE-BOUNDARY-START(111669477472)
            static /*string */ FormatError_FailedBinding(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Failed to convert configuration value '{0}' at '{1}' to type '{2}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(111669477472)
            
            //--TRIMMABLE-BOUNDARY-START(30065098848)
            static /*string */ get Error_FailedToActivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568823392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to create instance of type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(30065098848)
            
            //--TRIMMABLE-BOUNDARY-START(115964444768)
            static /*string */ FormatError_FailedToActivate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Failed to create instance of type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(115964444768)
            
            //--TRIMMABLE-BOUNDARY-START(34360066144)
            static /*string */ get Error_GeneralErrorWhenBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158757984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' was set and binding has failed. The likely cause is an invalid configuration value.";
            }
            //--TRIMMABLE-BOUNDARY-END(34360066144)
            
            //--TRIMMABLE-BOUNDARY-START(120259412064)
            static /*string */ FormatError_GeneralErrorWhenBinding(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("'{0}' was set and binding has failed. The likely cause is an invalid configuration value.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120259412064)
            
            //--TRIMMABLE-BOUNDARY-START(38655033440)
            static /*string */ get Error_MissingConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}";
            }
            //--TRIMMABLE-BOUNDARY-END(38655033440)
            
            //--TRIMMABLE-BOUNDARY-START(124554379360)
            static /*string */ FormatError_MissingConfig(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$11("'{0}' was set on the provided {1}, but the following properties were not found on the instance of {2}: {3}", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(124554379360)
            
            //--TRIMMABLE-BOUNDARY-START(42950000736)
            static /*string */ get Error_MissingPublicInstanceConstructor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it is missing a public instance constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(42950000736)
            
            //--TRIMMABLE-BOUNDARY-START(128849346656)
            static /*string */ FormatError_MissingPublicInstanceConstructor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it is missing a public instance constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346656)
            
            //--TRIMMABLE-BOUNDARY-START(47244968032)
            static /*string */ get Error_MultipleParameterizedConstructors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because it has multiple public parameterized constructors.";
            }
            //--TRIMMABLE-BOUNDARY-END(47244968032)
            
            //--TRIMMABLE-BOUNDARY-START(133144313952)
            static /*string */ FormatError_MultipleParameterizedConstructors(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because it has multiple public parameterized constructors.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(133144313952)
            
            //--TRIMMABLE-BOUNDARY-START(51539935328)
            static /*string */ get Error_ParameterBeingBoundToIsUnnamed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because one or more parameters are unnamed.";
            }
            //--TRIMMABLE-BOUNDARY-END(51539935328)
            
            //--TRIMMABLE-BOUNDARY-START(137439281248)
            static /*string */ FormatError_ParameterBeingBoundToIsUnnamed(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439281248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because one or more parameters are unnamed.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281248)
            
            //--TRIMMABLE-BOUNDARY-START(55834902624)
            static /*string */ get Error_ParameterHasNoMatchingConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.";
            }
            //--TRIMMABLE-BOUNDARY-END(55834902624)
            
            //--TRIMMABLE-BOUNDARY-START(141734248544)
            static /*string */ FormatError_ParameterHasNoMatchingConfig(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Cannot create instance of type '{0}' because parameter '{1}' has no matching config. Each parameter in the constructor that does not have a default value must have a corresponding config entry.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248544)
            
            //--TRIMMABLE-BOUNDARY-START(60129869920)
            static /*string */ get Error_UnsupportedMultidimensionalArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create instance of type '{0}' because multidimensional arrays are not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(60129869920)
            
            //--TRIMMABLE-BOUNDARY-START(146029215840)
            static /*string */ FormatError_UnsupportedMultidimensionalArray(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create instance of type '{0}' because multidimensional arrays are not supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146029215840)
            
            //--TRIMMABLE-BOUNDARY-START(4295295072)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(296353071200)
                    this.s_usingResourceKeys = $.$mecb.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(296353071200)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295072)
            
            static $h = 327776;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 327776
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327776)
        
        
        //--TRIMMABLE-BOUNDARY-START(262240)
        $asm.$cls("$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            //--TRIMMABLE-BOUNDARY-START(4295229536)
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229536)
            
            //--TRIMMABLE-BOUNDARY-START(8590196832)
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$$.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        {
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                        }
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$$.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.System.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196832)
            
            static $h = 262240;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229536),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "tryToGetDefaultValue",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "CheckHasDefaultValue",
      "d": 262240,
      "h": 4295229536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295229536),
//--TRIMMABLE-BOUNDARY-START(8590196832),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "defaultValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetDefaultValue",
      "d": 262240,
      "h": 8590196832,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590196832)
  ],
  "h": 262240
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262240)
        
        
        //--TRIMMABLE-BOUNDARY-START(65632)
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.BinderOptions", ($self) => class BinderOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17179934816)
            /*bool*/ BindNonPublicProperties = false;
            //--TRIMMABLE-BOUNDARY-END(17179934816)
            
            //--TRIMMABLE-BOUNDARY-START(21474902112)
            /*bool*/ ErrorOnUnknownConfiguration = false;
            //--TRIMMABLE-BOUNDARY-END(21474902112)
            
            //--TRIMMABLE-BOUNDARY-START(12884967520)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967520)
            
            static $h = 65632;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934816),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064836704,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244705888,
        "f": 83886081
      },
      "n": "BindNonPublicProperties",
      "d": 65632,
      "h": 17179934816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934816),
//--TRIMMABLE-BOUNDARY-START(21474902112),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771296,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834640480,
        "f": 83886081
      },
      "n": "ErrorOnUnknownConfiguration",
      "d": 65632,
      "h": 21474902112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474902112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967520),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65632,
      "h": 12884967520,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967520)
  ],
  "h": 65632
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.BinderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65632)
        
        
        //--TRIMMABLE-BOUNDARY-START(131168)
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.BindingPoint", ($self) => class BindingPoint extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590065760)
            /*Func<object?>?*/ _initialValueProvider = null;
            //--TRIMMABLE-BOUNDARY-END(8590065760)
            
            //--TRIMMABLE-BOUNDARY-START(4295098464)
            /*object?*/ _initialValue = null;
            //--TRIMMABLE-BOUNDARY-END(4295098464)
            
            //--TRIMMABLE-BOUNDARY-START(12885033056)
            /*object?*/ _setValue = null;
            //--TRIMMABLE-BOUNDARY-END(12885033056)
            
            //--TRIMMABLE-BOUNDARY-START(17180000352)
            /*bool*/ _valueSet = false;
            //--TRIMMABLE-BOUNDARY-END(17180000352)
            
            //--TRIMMABLE-BOUNDARY-START(30064902240)
            $ctor$2(/*object?*/ initialValue, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064902240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._initialValue = initialValue;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064902240)
            
            //--TRIMMABLE-BOUNDARY-START(25769934944)
            $ctor$1(/*Func<object?>*/ initialValueProvider, /*bool*/ isReadOnly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769934944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._initialValueProvider = initialValueProvider;
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934944)
            
            //--TRIMMABLE-BOUNDARY-START(64424640608)
            /*bool*/ IsReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(64424640608)
            
            //--TRIMMABLE-BOUNDARY-START(60129673312)
            /*bool */ get HasNewValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    return false;
                }
                if (this._valueSet)
                {
                    return true;
                }
                const $t1 = this._initialValue;
                let initialValueType;
                const $t2 = this._initialValue;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t)) !== null && ((initialValueType = $.$ifnn($t2, ($t) => $.$$.System.Object.GetType.call($t)), initialValueType != null && true)) && initialValueType.IsValueType && !initialValueType.IsPrimitive;
            }
            //--TRIMMABLE-BOUNDARY-END(60129673312)
            
            //--TRIMMABLE-BOUNDARY-START(77309542496)
            /*object? */ get Value()
            {
                return this._valueSet ? this._setValue : this._initialValue ??= (this._initialValueProvider?.Invoke() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(77309542496)
            
            //--TRIMMABLE-BOUNDARY-START(68719607904)
            /*void */ SetValue(/*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this.IsReadOnly, "!IsReadOnly");
                $.$$.System.Diagnostics.Debug.Assert$2(!this._valueSet, "!_valueSet");
                this._setValue = newValue;
                this._valueSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(68719607904)
            
            //--TRIMMABLE-BOUNDARY-START(73014575200)
            /*void */ TrySetValue(/*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014575200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsReadOnly)
                {
                    this.SetValue(newValue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014575200)
            
            static $h = 131168;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424640608),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771424,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 131168,
      "h": 64424640608,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424640608),
//--TRIMMABLE-BOUNDARY-START(60129673312),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836832,
        "f": 50331649
      },
      "n": "HasNewValue",
      "d": 131168,
      "h": 60129673312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129673312),
//--TRIMMABLE-BOUNDARY-START(77309542496),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706016,
        "f": 50331649
      },
      "n": "Value",
      "d": 131168,
      "h": 77309542496,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309542496)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719607904),
    {
      "r": 65537,
      "p": [
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 131168,
      "h": 68719607904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719607904),
//--TRIMMABLE-BOUNDARY-START(73014575200),
    {
      "r": 65537,
      "p": [
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "TrySetValue",
      "d": 131168,
      "h": 73014575200,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014575200)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065760),
    {
      "t": $.$$.System.Func$$($.$$.System.Object).$h,
      "n": "_initialValueProvider",
      "d": 131168,
      "h": 8590065760,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065760),
//--TRIMMABLE-BOUNDARY-START(4295098464),
    {
      "t": 131073,
      "n": "_initialValue",
      "d": 131168,
      "h": 4295098464,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098464),
//--TRIMMABLE-BOUNDARY-START(12885033056),
    {
      "t": 131073,
      "n": "_setValue",
      "d": 131168,
      "h": 12885033056,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033056),
//--TRIMMABLE-BOUNDARY-START(17180000352),
    {
      "t": 262145,
      "n": "_valueSet",
      "d": 131168,
      "h": 17180000352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180000352)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064902240),
    {
      "p": [
        {
          "n": "initialValue",
          "p": 131073,
          "f": 65
        },
        {
          "n": "isReadOnly",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131168,
      "h": 30064902240,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064902240),
//--TRIMMABLE-BOUNDARY-START(25769934944),
    {
      "p": [
        {
          "n": "initialValueProvider",
          "p": $.$$.System.Func$$($.$$.System.Object).$h
        },
        {
          "n": "isReadOnly",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131168,
      "h": 25769934944,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934944)
  ],
  "h": 131168
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.BindingPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131168)
        
        
        //--TRIMMABLE-BOUNDARY-START(196704)
        $asm.$cls("$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder", ($self) => class ConfigurationBinder
        {
            //--TRIMMABLE-BOUNDARY-START(68719673440)
            /*BindingFlags*/ static DeclaredOnlyLookup = 62;
            //--TRIMMABLE-BOUNDARY-END(68719673440)
            
            //--TRIMMABLE-BOUNDARY-START(77309608032)
            /*string*/ static DynamicCodeWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77309608032)
            
            //--TRIMMABLE-BOUNDARY-START(150324052064)
            /*string*/ static TrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(150324052064)
            
            //--TRIMMABLE-BOUNDARY-START(128849215584)
            /*string*/ static InstanceGetTypeTrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849215584)
            
            //--TRIMMABLE-BOUNDARY-START(141734117472)
            /*string*/ static PropertyTrimmingWarningMessage = null;
            //--TRIMMABLE-BOUNDARY-END(141734117472)
            
            //--TRIMMABLE-BOUNDARY-START(98784444512)
            static /*T? */ Get$3(T, /*this IConfiguration*/ configuration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784444512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get$2(T, configuration, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784444512)
            
            //--TRIMMABLE-BOUNDARY-START(94489477216)
            static /*T? */ Get$2(T, /*this IConfiguration*/ configuration, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489477216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                /*object?*/ let result = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get(configuration, T.$type, configureOptions);
                if (result === null)
                {
                    return $.$default(T);
                }
                return $.$cast(result, T);
            }
            //--TRIMMABLE-BOUNDARY-END(94489477216)
            
            //--TRIMMABLE-BOUNDARY-START(90194509920)
            static /*object? */ Get$1(/*this IConfiguration*/ configuration, /*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194509920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Get(configuration, type, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194509920)
            
            //--TRIMMABLE-BOUNDARY-START(85899542624)
            static /*object? */ Get(/*this IConfiguration*/ configuration, /*Type*/ type, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*var*/ let options = new $.$mecb.Microsoft.Extensions.Configuration.BinderOptions().$ctor$1();
                configureOptions?.Invoke(options);
                /*var*/ let bindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(type, bindingPoint, configuration, options, false);
                return bindingPoint.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(85899542624)
            
            //--TRIMMABLE-BOUNDARY-START(12885098592)
            static /*void */ Bind$2(/*this IConfiguration*/ configuration, /*string*/ key, /*object?*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind$1(configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key), instance);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098592)
            
            //--TRIMMABLE-BOUNDARY-START(8590131296)
            static /*void */ Bind$1(/*this IConfiguration*/ configuration, /*object?*/ instance)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131296);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.Bind(configuration, instance, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590131296)
            
            //--TRIMMABLE-BOUNDARY-START(4295164000)
            static /*void */ Bind(/*this IConfiguration*/ configuration, /*object?*/ instance, /*Action<BinderOptions>?*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                if (instance !== null)
                {
                    /*var*/ let options = new $.$mecb.Microsoft.Extensions.Configuration.BinderOptions().$ctor$1();
                    configureOptions?.Invoke(options);
                    /*var*/ let bindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, true);
                    $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance($.$$.System.Object.GetType.call(instance), bindingPoint, configuration, options, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295164000)
            
            //--TRIMMABLE-BOUNDARY-START(124554248288)
            static /*T? */ GetValue$3(T, /*this IConfiguration*/ configuration, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554248288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue$2(T, configuration, key, $.$default(T));
            }
            //--TRIMMABLE-BOUNDARY-END(124554248288)
            
            //--TRIMMABLE-BOUNDARY-START(120259280992)
            static /*T? */ GetValue$2(T, /*this IConfiguration*/ configuration, /*string*/ key, /*T*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259280992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue(configuration, T.$type, key, $.$box(defaultValue, T)), T);
            }
            //--TRIMMABLE-BOUNDARY-END(120259280992)
            
            //--TRIMMABLE-BOUNDARY-START(115964313696)
            static /*object? */ GetValue$1(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetValue(configuration, type, key, null);
            }
            //--TRIMMABLE-BOUNDARY-END(115964313696)
            
            //--TRIMMABLE-BOUNDARY-START(111669346400)
            static /*object? */ GetValue(/*this IConfiguration*/ configuration, /*Type*/ type, /*string*/ key, /*object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*IConfigurationSection*/ let section = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(key);
                /*string?*/ let value = section.Microsoft$Extensions$Configuration$IConfigurationSection$Value;
                if ($.$$.System.String.op_Inequality(value, null))
                {
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.ConvertValue(type, value, section.Microsoft$Extensions$Configuration$IConfigurationSection$Path);
                }
                return defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(111669346400)
            
            //--TRIMMABLE-BOUNDARY-START(42949869664)
            static /*void */ BindProperties(/*object*/ instance, /*IConfiguration*/ configuration, /*BinderOptions*/ options, /*ParameterInfo[]?*/ constructorParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<PropertyInfo>*/ let modelProperties = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetAllProperties($.$$.System.Object.GetType.call(instance));
                if (options.ErrorOnUnknownConfiguration)
                {
                    /*HashSet<string>*/ let propertyNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$2($.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.PropertyInfo, $.$$.System.String, modelProperties, new ($.$$.System.Func$$$($.$$.System.Reflection.PropertyInfo, $.$$.System.String))().$ctor(this,  (/**/ mp) =>
                    {
                        return mp.Name;
                    }, {
  "r": 1310721,
  "p": [
    {
      "n": "mp",
      "p": 118882305
    }
  ],
  "n": "",
  "d": 196704,
  "h": 0,
  "f": 17825794
})), $.$$.System.StringComparer.OrdinalIgnoreCase);
                    /*List<string>?*/ let missingPropertyNames = null;
                    var $en3 = configuration.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var cs = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!propertyNames.Contains(cs.Microsoft$Extensions$Configuration$IConfigurationSection$Key))
                            {
                                (missingPropertyNames ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1()).Add(`'${cs.Microsoft$Extensions$Configuration$IConfigurationSection$Key}'`);
                            }
                        }
                    }
                    if (missingPropertyNames !== null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$7($.$mecb.System.SR.Error_MissingConfig, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "ErrorOnUnknownConfiguration", "BinderOptions", $.$$.System.Object.GetType.call(instance), $.$$.System.String.Join$5(", ", missingPropertyNames) ], null, null)));
                    }
                }
                var $en2 = modelProperties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        if (constructorParameters === null || !$.$sl.System.Linq.Enumerable.Any($.$$.System.Reflection.ParameterInfo, constructorParameters, new ($.$$.System.Func$$$($.$$.System.Reflection.ParameterInfo, $.$$.System.Boolean))().$ctor(this,  (/*p*/ p) =>
                        {
                            return $.$$.System.String.op_Equality(p.Name, property.Name);
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "p",
      "p": 118358017
    }
  ],
  "n": "",
  "d": 196704,
  "h": 0,
  "f": 17825794
})))
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindProperty(property, instance, configuration, options);
                        }
                        else 
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.ResetPropertyValue(property, instance, options);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949869664)
            
            //--TRIMMABLE-BOUNDARY-START(146029084768)
            static /*void */ ResetPropertyValue(/*PropertyInfo*/ property, /*object*/ instance, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (property.GetMethod === null || property.SetMethod === null || (!options.BindNonPublicProperties && (!property.GetMethod.IsPublic$1 || !property.SetMethod.IsPublic$1)) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                property.SetValue$2(instance, property.GetValue$2(instance));
            }
            //--TRIMMABLE-BOUNDARY-END(146029084768)
            
            //--TRIMMABLE-BOUNDARY-START(47244836960)
            static /*void */ BindProperty(/*PropertyInfo*/ property, /*object*/ instance, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, null) || (!options.BindNonPublicProperties && !property.GetMethod.IsPublic$1) || property.GetMethod.GetParameters().length > 0)
                {
                    return;
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$1(new ($.$$.System.Func$$($.$$.System.Object))().$ctor(this,  () =>
                {
                    return property.GetValue$2(instance);
                }, {
  "r": 131073,
  "n": "",
  "d": 196704,
  "h": 0,
  "f": 17825794
}), property.SetMethod === null || (!property.SetMethod.IsPublic$1 && !options.BindNonPublicProperties));
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(property.PropertyType, propertyBindingPoint, config.Microsoft$Extensions$Configuration$IConfiguration$GetSection($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetPropertyName(property)), options, false);
                if (!propertyBindingPoint.IsReadOnly && (!(propertyBindingPoint.Value === null) || propertyBindingPoint.HasNewValue))
                {
                    property.SetValue$2(instance, propertyBindingPoint.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244836960)
            
            //--TRIMMABLE-BOUNDARY-START(34359935072)
            static /*void */ BindInstance(/*Type*/ type, /*BindingPoint*/ bindingPoint, /*IConfiguration*/ config, /*BinderOptions*/ options, /*bool*/ isParentCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(type, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection.$type))
                {
                    bindingPoint.TrySetValue(config);
                    return;
                }
                if (config === null)
                {
                    return;
                }
                /*IConfigurationSection?*/ let section;
                /*string?*/ let configValue;
                /*bool*/ let isConfigurationExist;
                let configSection;
                if ($.$is(config, $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection, { set $v(v){ configSection = v; } }))
                {
                    section = configSection;
                    isConfigurationExist = configSection.TryGetValue(null, $.$ref(() => configValue, ($v) => configValue = $v, $.$$.System.String));
                }
                else 
                {
                    section = $.$as(config, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection);
                    configValue = (section?.Microsoft$Extensions$Configuration$IConfigurationSection$Value ?? null);
                    isConfigurationExist = $.$$.System.String.op_Inequality(configValue, null);
                }
                /*object?*/ let convertedValue;
                /*Exception?*/ let error;
                if (isConfigurationExist && $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue(type, configValue, (section?.Microsoft$Extensions$Configuration$IConfigurationSection$Path ?? null), $.$ref(() => convertedValue, ($v) => convertedValue = $v, $.$$.System.Object), $.$ref(() => error, ($v) => error = $v, $.$$.System.Exception)))
                {
                    if (error !== null)
                    {
                        throw error;
                    }
                    let byteArray;
                    if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type) && $.$is(bindingPoint.Value, $.$typeArray($.$$.System.Byte), { set $v(v){ byteArray = v; } }) && byteArray.length > 0)
                    {
                        let convertedByteArray;
                        if ($.$is(convertedValue, $.$typeArray($.$$.System.Byte), { set $v(v){ convertedByteArray = v; } }) && convertedByteArray.length > 0)
                        {
                            /*Array*/ let a = $.$$.System.Array.CreateInstance$2(type.GetElementType(), ((byteArray.length + convertedByteArray.length) | 0));
                            $.$$.System.Array.Copy(byteArray, a, byteArray.length);
                            $.$$.System.Array.Copy$2(convertedByteArray, 0, a, byteArray.length, convertedByteArray.length);
                            bindingPoint.TrySetValue(a);
                        }
                        return;
                    }
                    bindingPoint.TrySetValue(convertedValue);
                    return;
                }
                if ($.$sl.System.Linq.Enumerable.Any$1($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren()))
                {
                    if (type.IsArray || $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.IsImmutableArrayCompatibleInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly)
                        {
                            bindingPoint.SetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindArray(type, $.$cast(bindingPoint.Value, $.$$.System.Collections.IEnumerable), config, options));
                        }
                        return;
                    }
                    if ($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TypeIsASetInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindSet(type, $.$cast(bindingPoint.Value, $.$$.System.Collections.IEnumerable), config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    if ($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TypeIsADictionaryInterface(type))
                    {
                        if (!bindingPoint.IsReadOnly || !(bindingPoint.Value === null))
                        {
                            /*object?*/ let newValue = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionaryInterface(bindingPoint.Value, type, config, options);
                            if (!bindingPoint.IsReadOnly && newValue !== null)
                            {
                                bindingPoint.SetValue(newValue);
                            }
                        }
                        return;
                    }
                    /*ParameterInfo[]?*/ let constructorParameters = null;
                    if (bindingPoint.Value === null)
                    {
                        if (bindingPoint.IsReadOnly)
                        {
                            return;
                        }
                        /*Type?*/ let interfaceGenericType = type.IsInterface && type.IsConstructedGenericType ? type.GetGenericTypeDefinition() : null;
                        if (!(interfaceGenericType === null) && ($.$$.System.Type.op_Equality$1(interfaceGenericType, $.$$.System.Collections.Generic.ICollection$$().$type) || $.$$.System.Type.op_Equality$1(interfaceGenericType, $.$$.System.Collections.Generic.IList$$().$type)))
                        {
                            /*Type*/ let genericType = $.$$.System.Collections.Generic.List$$().$type.MakeGenericType(type.GenericTypeArguments);
                            bindingPoint.SetValue($.$$.System.Activator.CreateInstance$9(genericType));
                        }
                        else 
                        {
                            bindingPoint.SetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CreateInstance(type, config, options, $.$ref(() => constructorParameters, ($v) => constructorParameters = $v, $.$typeArray($.$$.System.Reflection.ParameterInfo))));
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(!(bindingPoint.Value === null), "bindingPoint.Value is not null");
                    /*Type?*/ let dictionaryInterface = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.FindOpenGenericInterface($.$$.System.Collections.Generic.IDictionary$$$().$type, type);
                    if ($.$$.System.Type.op_Inequality$1(dictionaryInterface, null))
                    {
                        $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionary(bindingPoint.Value, dictionaryInterface, config, options);
                    }
                    else 
                    {
                        /*Type?*/ let collectionInterface = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.FindOpenGenericInterface($.$$.System.Collections.Generic.ICollection$$().$type, type);
                        if ($.$$.System.Type.op_Inequality$1(collectionInterface, null))
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindCollection(bindingPoint.Value, collectionInterface, config, options);
                        }
                        else 
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindProperties(bindingPoint.Value, config, options, constructorParameters);
                        }
                    }
                }
                else 
                {
                    if (!$.$$.System.String.IsNullOrEmpty(configValue))
                    {
                        if (options.ErrorOnUnknownConfiguration)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(section === null), "section is not null");
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, configValue, section.Microsoft$Extensions$Configuration$IConfigurationSection$Path, type));
                        }
                    }
                    else if (!bindingPoint.IsReadOnly && bindingPoint.Value === null)
                    {
                        if (isParentCollection)
                        {
                            bindingPoint.TrySetValue($.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CreateInstance(type, config, options, $.$discardRef()));
                        }
                        else if (isConfigurationExist)
                        {
                            if (type.IsArray || $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.IsIEnumerableInterface(type))
                            {
                                bindingPoint.TrySetValue(configValue === null ? null : $.$$.System.Array.CreateInstance$2(type.IsArray ? type.GetElementType() : $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0), 0));
                            }
                            else 
                            {
                                bindingPoint.TrySetValue(bindingPoint.Value);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359935072)
            
            //--TRIMMABLE-BOUNDARY-START(64424706144)
            static /*object */ CreateInstance(/*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options, /*out ParameterInfo[]?*/ constructorParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                constructorParameters.$v = null;
                if (type.IsInterface || type.IsAbstract$1)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_CannotActivateAbstractOrInterface, type));
                }
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors$1(16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/);
                /*bool*/ let hasParameterlessConstructor = type.IsValueType || $.$sl.System.Linq.Enumerable.Any($.$$.System.Reflection.ConstructorInfo, constructors, new ($.$$.System.Func$$$($.$$.System.Reflection.ConstructorInfo, $.$$.System.Boolean))().$ctor(this,  (/*ctor*/ ctor) =>
                {
                    return ctor.GetParameters().length === 0;
                }, {
  "r": 262145,
  "p": [
    {
      "n": "ctor",
      "p": 108462081
    }
  ],
  "n": "",
  "d": 196704,
  "h": 0,
  "f": 17825794
}));
                if (!type.IsValueType && constructors.length === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_MissingPublicInstanceConstructor, type));
                }
                if (constructors.length > 1 && !hasParameterlessConstructor)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_MultipleParameterizedConstructors, type));
                }
                if (constructors.length === 1 && !hasParameterlessConstructor)
                {
                    /*ConstructorInfo*/ let $constructor = $.$$.System.Array.$ReadT1.call(constructors, 0);
                    /*ParameterInfo[]*/ let parameters = $constructor.GetParameters();
                    /*string*/ let nameOfInvalidParameter;
                    if (!$.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.CanBindToTheseConstructorParameters(parameters, $.$ref(() => nameOfInvalidParameter, ($v) => nameOfInvalidParameter = $v, $.$$.System.String)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_CannotBindToConstructorParameter, type, nameOfInvalidParameter));
                    }
                    /*List<PropertyInfo>*/ let properties = $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.GetAllProperties(type);
                    /*string*/ let nameOfInvalidParameters;
                    if (!$.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.DoAllParametersHaveEquivalentProperties(parameters, properties, $.$ref(() => nameOfInvalidParameters, ($v) => nameOfInvalidParameters = $v, $.$$.System.String)))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_ConstructorParametersDoNotMatchProperties, type, nameOfInvalidParameters));
                    }
                    /*object?[]*/ let parameterValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [parameters.length], null);
                    for(/*int*/ let index = 0; index < parameters.length; index++)
                    {
                        $.$$.System.Array.$WriteT1.call(parameterValues, $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindParameter($.$$.System.Array.$ReadT1.call(parameters, index), type, config, options), index);
                    }
                    constructorParameters.$v = parameters;
                    return $constructor.Invoke$2(parameterValues);
                }
                /*object?*/ let instance;
                try
                {
                    instance = $.$$.System.Activator.CreateInstance$9($.$$.System.Nullable.GetUnderlyingType(type) ?? type);
                }
                catch(ex)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_FailedToActivate, type), ex);
                }
                return $.$firstOf(instance, () => { throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_FailedToActivate, type)) });
            }
            //--TRIMMABLE-BOUNDARY-END(64424706144)
            
            //--TRIMMABLE-BOUNDARY-START(73014640736)
            static /*bool */ DoAllParametersHaveEquivalentProperties(/*ParameterInfo[]*/ parameters, /*List<PropertyInfo>*/ properties, /*out string*/ missing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*HashSet<string>*/ let propertyNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                var $en2 = properties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prop = $en2.Current;
                    {
                        propertyNames.Add(prop.Name);
                    }
                }
                /*List<string>*/ let missingParameters = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                let $i1 = 0;
                let $arr1 = parameters;
                while ($i1 < $arr1.length)
                {
                    let parameter = $arr1[$i1++];
                    /*string*/ let name = parameter.Name;
                    if (!propertyNames.Contains(name))
                    {
                        missingParameters.Add(name);
                    }
                }
                missing.$v = $.$$.System.String.Join$5(",", missingParameters);
                return missing.$v.length === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640736)
            
            //--TRIMMABLE-BOUNDARY-START(55834771552)
            static /*bool */ CanBindToTheseConstructorParameters(/*ParameterInfo[]*/ constructorParameters, /*out string*/ nameOfInvalidParameter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                nameOfInvalidParameter.$v = $.$$.System.String.Empty;
                let $i1 = 0;
                let $arr1 = constructorParameters;
                while ($i1 < $arr1.length)
                {
                    let p = $arr1[$i1++];
                    if (p.IsOut || p.IsIn || p.ParameterType.IsByRef)
                    {
                        nameOfInvalidParameter.$v = p.Name;
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771552)
            
            //--TRIMMABLE-BOUNDARY-START(30064967776)
            static /*object? */ BindDictionaryInterface(/*object?*/ source, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = $.$$.System.Type.op_Equality$1(keyType, $.$$.System.SByte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt64.$type);
                if ($.$$.System.Type.op_Inequality$1(keyType, $.$$.System.String.$type) && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return null;
                }
                /*MethodInfo?*/ let addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    dictionaryType = $.$$.System.Collections.Generic.Dictionary$$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ keyType, valueType ], null, null));
                    /*object?*/ let dictionary = $.$$.System.Activator.CreateInstance$9(dictionaryType);
                    addMethod = dictionaryType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    /*var*/ let orig = $.$as(source, $.$$.System.Collections.IEnumerable);
                    if (!(orig === null))
                    {
                        /*Type*/ let kvpType = $.$$.System.Collections.Generic.KeyValuePair$$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ keyType, valueType ], null, null));
                        /*PropertyInfo*/ let keyMethod = kvpType.GetProperty$1("Key", 62/*DeclaredOnlyLookup*/);
                        /*PropertyInfo*/ let valueMethod = kvpType.GetProperty$1("Value", 62/*DeclaredOnlyLookup*/);
                        /*object?[]*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [2], null);
                        var $en4 = orig.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                /*object?*/ let k = keyMethod.GetMethod.Invoke(item, null);
                                /*object?*/ let v = valueMethod.GetMethod.Invoke(item, null);
                                $.$$.System.Array.$WriteT1.call($arguments, k, 0);
                                $.$$.System.Array.$WriteT1.call($arguments, v, 1);
                                addMethod.Invoke(dictionary, $arguments);
                            }
                        }
                    }
                    source = dictionary;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(source === null), "source is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(!(addMethod === null), "addMethod is not null");
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindDictionary(source, dictionaryType, config, options);
                return source;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967776)
            
            //--TRIMMABLE-BOUNDARY-START(25770000480)
            static /*void */ BindDictionary(/*object*/ dictionary, /*Type*/ dictionaryType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(dictionaryType.IsGenericType && ($.$$.System.Type.op_Equality$1(dictionaryType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IDictionary$$$().$type) || $.$$.System.Type.op_Equality$1(dictionaryType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.Dictionary$$$().$type)), "dictionaryType.IsGenericType &&\r\n                         (dictionaryType.GetGenericTypeDefinition() == typeof(IDictionary<,>) || dictionaryType.GetGenericTypeDefinition() == typeof(Dictionary<,>))");
                /*Type*/ let keyType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 0);
                /*Type*/ let valueType = $.$$.System.Array.$ReadT1.call(dictionaryType.GenericTypeArguments, 1);
                /*bool*/ let keyTypeIsEnum = keyType.IsEnum;
                /*bool*/ let keyTypeIsInteger = $.$$.System.Type.op_Equality$1(keyType, $.$$.System.SByte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt16.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt32.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.Int64.$type) || $.$$.System.Type.op_Equality$1(keyType, $.$$.System.UInt64.$type);
                if ($.$$.System.Type.op_Inequality$1(keyType, $.$$.System.String.$type) && !keyTypeIsEnum && !keyTypeIsInteger)
                {
                    return;
                }
                /*MethodInfo*/ let tryGetValue = dictionaryType.GetMethod$9("TryGetValue", 62/*DeclaredOnlyLookup*/);
                /*PropertyInfo*/ let indexerProperty = dictionaryType.GetProperty$1("Item", 62/*DeclaredOnlyLookup*/);
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var child = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*object*/ let key = keyTypeIsEnum ? $.$$.System.Enum.Parse$2(keyType, child.Microsoft$Extensions$Configuration$IConfigurationSection$Key, true) : keyTypeIsInteger ? $.$$.System.Convert.ChangeType$1(child.Microsoft$Extensions$Configuration$IConfigurationSection$Key, keyType) : child.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            /*var*/ let valueBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$1(new ($.$$.System.Func$$($.$$.System.Object))().$ctor(this,  () =>
                            {
                                /*object?[]*/ let tryGetValueArgs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [key, null], null, null);
                                return $.$cast(tryGetValue.Invoke(dictionary, tryGetValueArgs), $.$$.System.Boolean) ? $.$$.System.Array.$ReadT1.call(tryGetValueArgs, 1) : null;
                            }, {
  "r": 131073,
  "n": "",
  "d": 196704,
  "h": 0,
  "f": 17825794
}), false);
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(valueType, valueBindingPoint, child, options, true);
                            if (valueBindingPoint.HasNewValue)
                            {
                                indexerProperty.SetValue(dictionary, valueBindingPoint.Value, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [key], [-1], null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770000480)
            
            //--TRIMMABLE-BOUNDARY-START(21475033184)
            static /*void */ BindCollection(/*object*/ collection, /*Type*/ collectionType, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let itemType = $.$$.System.Array.$ReadT1.call(collectionType.GenericTypeArguments, 0);
                /*MethodInfo?*/ let addMethod = collectionType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            /*BindingPoint*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(itemType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                addMethod?.Invoke(collection, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [itemBindingPoint.Value], null, null));
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033184)
            
            //--TRIMMABLE-BOUNDARY-START(17180065888)
            static /*Array */ BindArray(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let elementType;
                if (type.IsArray)
                {
                    if (type.GetArrayRank() > 1)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_UnsupportedMultidimensionalArray, type));
                    }
                    elementType = type.GetElementType();
                }
                else 
                {
                    elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                }
                /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                if (source !== null)
                {
                    var $en3 = source.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$IEnumerator$Current;
                        {
                            list.Add(item);
                        }
                    }
                }
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                list.Add(itemBindingPoint.Value);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                /*Array*/ let result = $.$$.System.Array.CreateInstance$2(elementType, list.Count);
                (list).System$Collections$ICollection$CopyTo(result, 0);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065888)
            
            //--TRIMMABLE-BOUNDARY-START(51539804256)
            static /*object? */ BindSet(/*Type*/ type, /*IEnumerable?*/ source, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let elementType = $.$$.System.Array.$ReadT1.call(type.GetGenericArguments(), 0);
                /*bool*/ let elementTypeIsEnum = elementType.IsEnum;
                if ($.$$.System.Type.op_Inequality$1(elementType, $.$$.System.String.$type) && !elementTypeIsEnum)
                {
                    return null;
                }
                /*object?[]*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [1], null);
                /*MethodInfo?*/ let addMethod = type.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                if (addMethod === null || source === null)
                {
                    /*Type*/ let genericType = $.$$.System.Collections.Generic.HashSet$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                    /*object*/ let instance = $.$$.System.Activator.CreateInstance$9(genericType);
                    addMethod = genericType.GetMethod$9("Add", 62/*DeclaredOnlyLookup*/);
                    if (source !== null)
                    {
                        var $en4 = source.System$Collections$IEnumerable$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, item, 0);
                                addMethod.Invoke(instance, $arguments);
                            }
                        }
                    }
                    source = $.$cast(instance, $.$$.System.Collections.IEnumerable);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(source === null), "source is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(!(addMethod === null), "addMethod is not null");
                var $en2 = config.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var section = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let itemBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(null, false);
                        try
                        {
                            $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(elementType, itemBindingPoint, section, options, true);
                            if (itemBindingPoint.HasNewValue)
                            {
                                $.$$.System.Array.$WriteT1.call($arguments, itemBindingPoint.Value, 0);
                                addMethod.Invoke(source, $arguments);
                            }
                        }
                        catch(ex)
                        {
                            if (options.ErrorOnUnknownConfiguration)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_GeneralErrorWhenBinding, "ErrorOnUnknownConfiguration"), ex);
                            }
                        }
                    }
                }
                return source;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804256)
            
            //--TRIMMABLE-BOUNDARY-START(154619019360)
            static /*bool */ TryConvertValue(/*Type*/ type, /*string?*/ value, /*string?*/ path, /*out object?*/ result, /*out Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619019360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                error.$v = null;
                result.$v = null;
                if ($.$$.System.Type.op_Equality$1(type, $.$$.System.Object.$type))
                {
                    result.$v = value;
                    return true;
                }
                if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type))
                {
                    if ($.$$.System.String.IsNullOrEmpty(value))
                    {
                        return true;
                    }
                    return $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue($.$$.System.Nullable.GetUnderlyingType(type), value, path, result, error);
                }
                /*TypeConverter*/ let converter = $.$sct.System.ComponentModel.TypeDescriptor.GetConverter$2(type);
                if (converter.CanConvertFrom($.$$.System.String.$type))
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = converter.ConvertFromInvariantString(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                if ($.$$.System.Type.op_Equality$1(type, $.$typeArray($.$$.System.Byte).$type))
                {
                    try
                    {
                        if (!(value === null))
                        {
                            result.$v = $.$$.System.String.op_Equality(value, $.$$.System.String.Empty) ? $.$$.System.Array.Empty($.$$.System.Byte) : $.$$.System.Convert.FromBase64String(value);
                        }
                    }
                    catch(ex)
                    {
                        error.$v = new $.$$.System.InvalidOperationException().$ctor$11($.$mecb.System.SR.Format$4($.$mecb.System.SR.Error_FailedBinding, value, path, type), ex);
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154619019360)
            
            //--TRIMMABLE-BOUNDARY-START(60129738848)
            static /*object? */ ConvertValue(/*Type*/ type, /*string*/ value, /*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let result;
                /*Exception?*/ let error;
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.TryConvertValue(type, value, path, $.$ref(() => result, ($v) => result = $v, $.$$.System.Object), $.$ref(() => error, ($v) => error = $v, $.$$.System.Exception));
                if (error !== null)
                {
                    throw error;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738848)
            
            //--TRIMMABLE-BOUNDARY-START(158913986656)
            static /*bool */ TypeIsADictionaryInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IDictionary$$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(158913986656)
            
            //--TRIMMABLE-BOUNDARY-START(137439150176)
            static /*bool */ IsImmutableArrayCompatibleInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439150176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IEnumerable$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyCollection$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlyList$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(137439150176)
            
            //--TRIMMABLE-BOUNDARY-START(133144182880)
            static /*bool */ IsIEnumerableInterface(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144182880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return type.IsInterface && type.IsConstructedGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144182880)
            
            //--TRIMMABLE-BOUNDARY-START(163208953952)
            static /*bool */ TypeIsASetInterface(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208953952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.IsInterface || !type.IsConstructedGenericType)
                {
                    return false;
                }
                /*Type*/ let genericTypeDefinition = type.GetGenericTypeDefinition();
                return $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.ISet$$().$type) || $.$$.System.Type.op_Equality$1(genericTypeDefinition, $.$$.System.Collections.Generic.IReadOnlySet$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(163208953952)
            
            //--TRIMMABLE-BOUNDARY-START(81604575328)
            static /*Type? */ FindOpenGenericInterface(/*Type*/ expected, /*Type*/ actual)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (actual.IsGenericType && $.$$.System.Type.op_Equality$1(actual.GetGenericTypeDefinition(), expected))
                {
                    return actual;
                }
                /*Type[]*/ let interfaces = actual.GetInterfaces();
                let $i1 = 0;
                let $arr1 = interfaces;
                while ($i1 < $arr1.length)
                {
                    let interfaceType = $arr1[$i1++];
                    if (interfaceType.IsGenericType && $.$$.System.Type.op_Equality$1(interfaceType.GetGenericTypeDefinition(), expected))
                    {
                        return interfaceType;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604575328)
            
            //--TRIMMABLE-BOUNDARY-START(103079411808)
            static /*List<PropertyInfo> */ GetAllProperties(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let allProperties = new ($.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo))().$ctor$1();
                /*Type*/ let baseType = type;
                while($.$$.System.Type.op_Inequality$1(baseType, $.$$.System.Object.$type))
                {
                    /*PropertyInfo[]*/ let properties = baseType.GetProperties$1(62/*DeclaredOnlyLookup*/);
                    let $i1 = 0;
                    let $arr1 = properties;
                    while ($i1 < $arr1.length)
                    {
                        let property = $arr1[$i1++];
                        /*MethodInfo?*/ let setMethod = property.GetSetMethod$1(true);
                        if (setMethod === null || !setMethod.IsVirtual$1 || $.$$.System.Reflection.MethodInfo.op_Equality$2(setMethod, setMethod.GetBaseDefinition()))
                        {
                            allProperties.Add(property);
                        }
                    }
                    baseType = baseType.BaseType;
                }
                return allProperties;
            }
            //--TRIMMABLE-BOUNDARY-END(103079411808)
            
            //--TRIMMABLE-BOUNDARY-START(38654902368)
            static /*object? */ BindParameter(/*ParameterInfo*/ parameter, /*Type*/ type, /*IConfiguration*/ config, /*BinderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let parameterName = parameter.Name;
                if (parameterName === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$6($.$mecb.System.SR.Error_ParameterBeingBoundToIsUnnamed, type));
                }
                /*var*/ let propertyBindingPoint = new $.$mecb.Microsoft.Extensions.Configuration.BindingPoint().$ctor$2(config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(parameterName).Microsoft$Extensions$Configuration$IConfigurationSection$Value, false);
                $.$mecb.Microsoft.Extensions.Configuration.ConfigurationBinder.BindInstance(parameter.ParameterType, propertyBindingPoint, config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(parameterName), options, false);
                if (propertyBindingPoint.Value === null)
                {
                    /*object?*/ let defaultValue;
                    if ($.$mecb.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(parameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object)))
                    {
                        propertyBindingPoint.SetValue(defaultValue);
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mecb.System.SR.Format$5($.$mecb.System.SR.Error_ParameterHasNoMatchingConfig, type, parameterName));
                    }
                }
                return propertyBindingPoint.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902368)
            
            //--TRIMMABLE-BOUNDARY-START(107374379104)
            static /*string */ GetPropertyName(/*PropertyInfo*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(property, "property");
                var $en2 = property.GetCustomAttributesData().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attributeData = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.Type.op_Inequality$1(attributeData.AttributeType, $.$meca.Microsoft.Extensions.Configuration.ConfigurationKeyNameAttribute.$type))
                        {
                            continue;
                        }
                        if (attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count !== 1)
                        {
                            break;
                        }
                        const $t1 = () => attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$$.System.Reflection.CustomAttributeTypedArgument]).Value;
                        /*string?*/ let name = $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                        return !$.$$.System.String.IsNullOrWhiteSpace(name) ? name : property.Name;
                    }
                }
                return property.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(107374379104)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77309608032)
                    this.DynamicCodeWarningMessage = "Binding strongly typed objects to configuration values requires generating dynamic code at runtime, for example instantiating generic types.";
                    //--TRIMMABLE-BOUNDARY-END(77309608032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324052064)
                    this.TrimmingWarningMessage = "In case the type is non-primitive, the trimmer cannot statically analyze the object's type so its members may be trimmed.";
                    //--TRIMMABLE-BOUNDARY-END(150324052064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849215584)
                    this.InstanceGetTypeTrimmingWarningMessage = "Cannot statically analyze the type of instance so its members may be trimmed";
                    //--TRIMMABLE-BOUNDARY-END(128849215584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734117472)
                    this.PropertyTrimmingWarningMessage = "Cannot statically analyze property.PropertyType so its members may be trimmed.";
                    //--TRIMMABLE-BOUNDARY-END(141734117472)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 196704;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784444512),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "o": "@$3",
      "d": 196704,
      "h": 98784444512,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784444512),
//--TRIMMABLE-BOUNDARY-START(94489477216),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Get",
      "o": "@$2",
      "d": 196704,
      "h": 94489477216,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489477216),
//--TRIMMABLE-BOUNDARY-START(90194509920),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 196704,
      "h": 90194509920,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194509920),
//--TRIMMABLE-BOUNDARY-START(85899542624),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "n": "Get",
      "d": 196704,
      "h": 85899542624,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899542624),
//--TRIMMABLE-BOUNDARY-START(12885098592),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": "Bind",
      "o": "@$2",
      "d": 196704,
      "h": 12885098592,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885098592),
//--TRIMMABLE-BOUNDARY-START(8590131296),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": "Bind",
      "o": "@$1",
      "d": 196704,
      "h": 8590131296,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131296),
//--TRIMMABLE-BOUNDARY-START(4295164000),
    {
      "r": 65537,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "configureOptions",
          "p": $.$$.System.Action$$($.$mecb.Microsoft.Extensions.Configuration.BinderOptions).$h
        }
      ],
      "n": "Bind",
      "d": 196704,
      "h": 4295164000,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164000),
//--TRIMMABLE-BOUNDARY-START(124554248288),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$3",
      "d": 196704,
      "h": 124554248288,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554248288),
//--TRIMMABLE-BOUNDARY-START(120259280992),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetValue",
      "o": "@$2",
      "d": 196704,
      "h": 120259280992,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259280992),
//--TRIMMABLE-BOUNDARY-START(115964313696),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetValue",
      "o": "@$1",
      "d": 196704,
      "h": 115964313696,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964313696),
//--TRIMMABLE-BOUNDARY-START(111669346400),
    {
      "r": 131073,
      "p": [
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "defaultValue",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "d": 196704,
      "h": 111669346400,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669346400),
//--TRIMMABLE-BOUNDARY-START(42949869664),
    {
      "r": 65537,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "configuration",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h
        }
      ],
      "n": "BindProperties",
      "d": 196704,
      "h": 42949869664,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949869664),
//--TRIMMABLE-BOUNDARY-START(146029084768),
    {
      "r": 65537,
      "p": [
        {
          "n": "property",
          "p": 118882305
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "ResetPropertyValue",
      "d": 196704,
      "h": 146029084768,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146029084768),
//--TRIMMABLE-BOUNDARY-START(47244836960),
    {
      "r": 65537,
      "p": [
        {
          "n": "property",
          "p": 118882305
        },
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindProperty",
      "d": 196704,
      "h": 47244836960,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244836960),
//--TRIMMABLE-BOUNDARY-START(34359935072),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "bindingPoint",
          "p": 131168
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "isParentCollection",
          "p": 262145
        }
      ],
      "n": "BindInstance",
      "d": 196704,
      "h": 34359935072,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359935072),
//--TRIMMABLE-BOUNDARY-START(64424706144),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        },
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h,
          "f": 2
        }
      ],
      "n": "CreateInstance",
      "d": 196704,
      "h": 64424706144,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424706144),
//--TRIMMABLE-BOUNDARY-START(73014640736),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h
        },
        {
          "n": "properties",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo).$h
        },
        {
          "n": "missing",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "DoAllParametersHaveEquivalentProperties",
      "d": 196704,
      "h": 73014640736,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014640736),
//--TRIMMABLE-BOUNDARY-START(55834771552),
    {
      "r": 262145,
      "p": [
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h
        },
        {
          "n": "nameOfInvalidParameter",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "CanBindToTheseConstructorParameters",
      "d": 196704,
      "h": 55834771552,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834771552),
//--TRIMMABLE-BOUNDARY-START(30064967776),
    {
      "r": 131073,
      "p": [
        {
          "n": "source",
          "p": 131073
        },
        {
          "n": "dictionaryType",
          "p": 187760641
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindDictionaryInterface",
      "d": 196704,
      "h": 30064967776,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064967776),
//--TRIMMABLE-BOUNDARY-START(25770000480),
    {
      "r": 65537,
      "p": [
        {
          "n": "dictionary",
          "p": 131073
        },
        {
          "n": "dictionaryType",
          "p": 187760641
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindDictionary",
      "d": 196704,
      "h": 25770000480,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770000480),
//--TRIMMABLE-BOUNDARY-START(21475033184),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 131073
        },
        {
          "n": "collectionType",
          "p": 187760641
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindCollection",
      "d": 196704,
      "h": 21475033184,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475033184),
//--TRIMMABLE-BOUNDARY-START(17180065888),
    {
      "r": 1245185,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "source",
          "p": 62652417
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindArray",
      "d": 196704,
      "h": 17180065888,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180065888),
//--TRIMMABLE-BOUNDARY-START(51539804256),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "source",
          "p": 62652417
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindSet",
      "d": 196704,
      "h": 51539804256,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539804256),
//--TRIMMABLE-BOUNDARY-START(154619019360),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 131073,
          "f": 2
        },
        {
          "n": "error",
          "p": 80019457,
          "f": 2
        }
      ],
      "n": "TryConvertValue",
      "d": 196704,
      "h": 154619019360,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154619019360),
//--TRIMMABLE-BOUNDARY-START(60129738848),
    {
      "r": 131073,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "ConvertValue",
      "d": 196704,
      "h": 60129738848,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129738848),
//--TRIMMABLE-BOUNDARY-START(158913986656),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "TypeIsADictionaryInterface",
      "d": 196704,
      "h": 158913986656,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158913986656),
//--TRIMMABLE-BOUNDARY-START(137439150176),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsImmutableArrayCompatibleInterface",
      "d": 196704,
      "h": 137439150176,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137439150176),
//--TRIMMABLE-BOUNDARY-START(133144182880),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "IsIEnumerableInterface",
      "d": 196704,
      "h": 133144182880,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133144182880),
//--TRIMMABLE-BOUNDARY-START(163208953952),
    {
      "r": 262145,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "TypeIsASetInterface",
      "d": 196704,
      "h": 163208953952,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(163208953952),
//--TRIMMABLE-BOUNDARY-START(81604575328),
    {
      "r": 187760641,
      "p": [
        {
          "n": "expected",
          "p": 187760641
        },
        {
          "n": "actual",
          "p": 187760641
        }
      ],
      "n": "FindOpenGenericInterface",
      "d": 196704,
      "h": 81604575328,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604575328),
//--TRIMMABLE-BOUNDARY-START(103079411808),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.Reflection.PropertyInfo).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetAllProperties",
      "d": 196704,
      "h": 103079411808,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079411808),
//--TRIMMABLE-BOUNDARY-START(38654902368),
    {
      "r": 131073,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "options",
          "p": 65632
        }
      ],
      "n": "BindParameter",
      "d": 196704,
      "h": 38654902368,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654902368),
//--TRIMMABLE-BOUNDARY-START(107374379104),
    {
      "r": 1310721,
      "p": [
        {
          "n": "property",
          "p": 118882305
        }
      ],
      "n": "GetPropertyName",
      "d": 196704,
      "h": 107374379104,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374379104)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(68719673440),
    {
      "t": 108331009,
      "n": "DeclaredOnlyLookup",
      "d": 196704,
      "h": 68719673440,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719673440),
//--TRIMMABLE-BOUNDARY-START(77309608032),
    {
      "t": 1310721,
      "n": "DynamicCodeWarningMessage",
      "d": 196704,
      "h": 77309608032,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309608032),
//--TRIMMABLE-BOUNDARY-START(150324052064),
    {
      "t": 1310721,
      "n": "TrimmingWarningMessage",
      "d": 196704,
      "h": 150324052064,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150324052064),
//--TRIMMABLE-BOUNDARY-START(128849215584),
    {
      "t": 1310721,
      "n": "InstanceGetTypeTrimmingWarningMessage",
      "d": 196704,
      "h": 128849215584,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849215584),
//--TRIMMABLE-BOUNDARY-START(141734117472),
    {
      "t": 1310721,
      "n": "PropertyTrimmingWarningMessage",
      "d": 196704,
      "h": 141734117472,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141734117472)
  ],
  "h": 196704
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196704)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter"))
//--TRIMMABLE-BOUNDARY-END(96)
