
//--TRIMMABLE-BOUNDARY-START(98)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mefa, $mef, $mwp, $scm, $scn, $scp, $sto, $sifw, $sds, $srn, $sfa, $snp, $sscr, $mefp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.FileExtensions", 
    {
  "h": 98,
  "f": "Microsoft.Extensions.Configuration.FileExtensions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.Configuration.FileExtensions.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.FileExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.FileExtensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196706)
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource", ($self) => class FileConfigurationSource extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42949869666)
            /*IFileProvider?*/ FileProvider = null;
            //--TRIMMABLE-BOUNDARY-END(42949869666)
            
            //--TRIMMABLE-BOUNDARY-START(107374379106)
            /*string?*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(107374379106)
            
            //--TRIMMABLE-BOUNDARY-START(103079411810)
            /*bool*/ Optional = false;
            //--TRIMMABLE-BOUNDARY-END(103079411810)
            
            //--TRIMMABLE-BOUNDARY-START(115964313698)
            /*bool*/ ReloadOnChange = false;
            //--TRIMMABLE-BOUNDARY-END(115964313698)
            
            //--TRIMMABLE-BOUNDARY-START(111669346402)
            /*int*/ ReloadDelay = 0;
            //--TRIMMABLE-BOUNDARY-END(111669346402)
            
            //--TRIMMABLE-BOUNDARY-START(98784444514)
            /*Action<FileLoadExceptionContext>?*/ OnLoadException = null;
            //--TRIMMABLE-BOUNDARY-END(98784444514)
            
            //--TRIMMABLE-BOUNDARY-START(38654902370)
            /*void */ EnsureDefaults(/*IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.FileProvider ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileProvider(builder);
                this.OnLoadException ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileLoadExceptionHandler(builder);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902370)
            
            //--TRIMMABLE-BOUNDARY-START(120259280994)
            /*void */ ResolveFileProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259280994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.FileProvider === null && !$.$$.System.String.IsNullOrEmpty(this.Path) && $.$$.System.IO.Path.IsPathRooted$1(this.Path))
                {
                    /*string?*/ let directory = $.$$.System.IO.Path.GetDirectoryName$1(this.Path);
                    /*string?*/ let pathToFile = $.$$.System.IO.Path.GetFileName$1(this.Path);
                    while(!$.$$.System.String.IsNullOrEmpty(directory) && !$.$$.System.IO.Directory.Exists(directory))
                    {
                        pathToFile = $.$$.System.IO.Path.Combine$3($.$$.System.IO.Path.GetFileName$1(directory), pathToFile);
                        directory = $.$$.System.IO.Path.GetDirectoryName$1(directory);
                    }
                    if ($.$$.System.IO.Directory.Exists(directory))
                    {
                        this.FileProvider = new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2(directory);
                        this.Path = pathToFile;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259280994)
            
            //--TRIMMABLE-BOUNDARY-START(4295753822)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295753822)
            
            //--TRIMMABLE-BOUNDARY-START(30064967778)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967778)
            
            //default member initializer
            constructor()
            {
                super();
                this.ReloadDelay = 250;
            }
            static $h = 196706;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949869666),
    {
      "p": 262243,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804258,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849215586,
        "f": 83886081
      },
      "n": "FileProvider",
      "d": 196706,
      "h": 42949869666,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949869666),
//--TRIMMABLE-BOUNDARY-START(107374379106),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309608034,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619019362,
        "f": 83886081
      },
      "n": "Path",
      "d": 196706,
      "h": 107374379106,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374379106),
//--TRIMMABLE-BOUNDARY-START(103079411810),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719673442,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029084770,
        "f": 83886081
      },
      "n": "Optional",
      "d": 196706,
      "h": 103079411810,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079411810),
//--TRIMMABLE-BOUNDARY-START(115964313698),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489477218,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171798888546,
        "f": 83886081
      },
      "n": "ReloadOnChange",
      "d": 196706,
      "h": 115964313698,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964313698),
//--TRIMMABLE-BOUNDARY-START(111669346402),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899542626,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163208953954,
        "f": 83886081
      },
      "n": "ReloadDelay",
      "d": 196706,
      "h": 111669346402,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669346402),
//--TRIMMABLE-BOUNDARY-START(98784444514),
    {
      "p": $.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738850,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439150178,
        "f": 83886081
      },
      "n": "OnLoadException",
      "d": 196706,
      "h": 98784444514,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784444514)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359935074),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 196706,
      "h": 34359935074,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34359935074),
//--TRIMMABLE-BOUNDARY-START(38654902370),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "EnsureDefaults",
      "d": 196706,
      "h": 38654902370,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654902370),
//--TRIMMABLE-BOUNDARY-START(120259280994),
    {
      "r": 65537,
      "n": "ResolveFileProvider",
      "d": 196706,
      "h": 120259280994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120259280994)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30064967778),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196706,
      "h": 30064967778,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30064967778)
  ],
  "i": [786526
  ],
  "h": 196706
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196706)
        
        
        //--TRIMMABLE-BOUNDARY-START(131170)
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider", ($self) => class FileConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295098466)
            /*IDisposable?*/ _changeTokenRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(4295098466)
            
            //--TRIMMABLE-BOUNDARY-START(12885033058)
            $ctor$2(/*FileConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033058);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this.Source = source;
                    if (this.Source.ReloadOnChange && this.Source.FileProvider !== null)
                    {
                        this._changeTokenRegistration = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(this,  () =>
                        {
                            return this.Source.FileProvider.Microsoft$Extensions$FileProviders$IFileProvider$Watch(this.Source.Path);
                        }, {
  "r": 720981,
  "n": "",
  "d": 131170,
  "h": 0,
  "f": 17825794
}), new $.$$.System.Action().$ctor(this,  () =>
                        {
                            $.$$.System.Threading.Thread.Sleep(this.Source.ReloadDelay);
                            this.Load$1(true);
                        }, {
  "r": 65537,
  "n": "",
  "d": 131170,
  "h": 0,
  "f": 17825794
}));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033058)
            
            //--TRIMMABLE-BOUNDARY-START(51539738722)
            /*FileConfigurationSource*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(51539738722)
            
            //--TRIMMABLE-BOUNDARY-START(55834706018)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834706018);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `${$.$$.System.Object.GetType.call(this).Name} for '${this.Source.Path}' (${(this.Source.Optional ? "Optional" : "Required")})`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(55834706018)
            
            //--TRIMMABLE-BOUNDARY-START(42949804130)
            /*void */ Load$1(/*bool*/ reload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IFileInfo?*/ let file = (this.Source.FileProvider?.Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo(this.Source.Path ?? $.$$.System.String.Empty) ?? null);
                if (file === null || !file.Microsoft$Extensions$FileProviders$IFileInfo$Exists)
                {
                    if (this.Source.Optional || reload)
                    {
                        this.Data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                    }
                    else 
                    {
                        /*var*/ let error = new $.$$.System.Text.StringBuilder().$ctor$8($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_FileNotFound, this.Source.Path));
                        if (!$.$$.System.String.IsNullOrEmpty((file?.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath ?? null)))
                        {
                            error.Append$19($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_ExpectedPhysicalPath, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath));
                        }
                        this.HandleException($.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(new $.$$.System.IO.FileNotFoundException().$ctor$19($.$$.System.Text.StringBuilder.ToString.call(error))));
                    }
                }
                else 
                {
                    /*static Stream*/  function OpenRead(/*IFileInfo*/ fileInfo)
                    {
                        if ($.$$.System.String.op_Inequality(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, null))
                        {
                            return new $.$$.System.IO.FileStream().$ctor$12(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/);
                        }
                        return fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream();
                    }
                    /*Stream*/ let stream = OpenRead(file);
                    try
                    {
                        try
                        {
                            this.Load$2(stream);
                        }
                        catch(ex)
                        {
                            if (reload)
                            {
                                this.Data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                            }
                            /*var*/ let exception = new $.$$.System.IO.InvalidDataException().$ctor$11($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_FailedToLoad, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath), ex);
                            this.HandleException($.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception));
                        }
                    }
                    finally
                    {
                        stream?.System$IDisposable$Dispose();
                    }
                }
                this.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804130)
            
            //--TRIMMABLE-BOUNDARY-START(38654836834)
            /*void */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Load$1(false);
            }
            //--TRIMMABLE-BOUNDARY-END(38654836834)
            
            //--TRIMMABLE-BOUNDARY-START(34359869538)
            /*void */ HandleException(/*ExceptionDispatchInfo*/ info)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ignoreException = false;
                if (this.Source.OnLoadException !== null)
                {
                    /*var*/ let exceptionContext = (() =>
                    {
                        //new $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext()
                        const $t1 = $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext;
                        const $i1 = new $t1();
                        $i1.Provider = this;
                        $i1.Exception = info.SourceException;
                        return $i1;
                    })();
                    this.Source.OnLoadException.Invoke(exceptionContext);
                    ignoreException = exceptionContext.Ignore;
                }
                if (!ignoreException)
                {
                    info.Throw();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869538)
            
            //--TRIMMABLE-BOUNDARY-START(17180000354)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Dispose$1(true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000354)
            
            //--TRIMMABLE-BOUNDARY-START(21474967650)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._changeTokenRegistration?.System$IDisposable$Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967650)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            static $h = 131170;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655455,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539738722),
    {
      "p": 196706,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902242,
        "f": 50331649
      },
      "n": "Source",
      "d": 131170,
      "h": 51539738722,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539738722)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834706018),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131170,
      "h": 55834706018,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834706018),
//--TRIMMABLE-BOUNDARY-START(42949804130),
    {
      "r": 65537,
      "p": [
        {
          "n": "reload",
          "p": 262145
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 131170,
      "h": 42949804130,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949804130),
//--TRIMMABLE-BOUNDARY-START(38654836834),
    {
      "r": 65537,
      "n": "Load",
      "d": 131170,
      "h": 38654836834,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654836834),
//--TRIMMABLE-BOUNDARY-START(47244771426),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94961665
        }
      ],
      "n": "Load",
      "o": "@$2",
      "d": 131170,
      "h": 47244771426,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47244771426),
//--TRIMMABLE-BOUNDARY-START(34359869538),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 135004161
        }
      ],
      "n": "HandleException",
      "d": 131170,
      "h": 34359869538,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359869538),
//--TRIMMABLE-BOUNDARY-START(17180000354),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 131170,
      "h": 17180000354,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180000354),
//--TRIMMABLE-BOUNDARY-START(21474967650),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 131170,
      "h": 21474967650,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(21474967650)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098466),
    {
      "t": 90308609,
      "n": "_changeTokenRegistration",
      "d": 131170,
      "h": 4295098466,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098466)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033058),
    {
      "p": [
        {
          "n": "source",
          "p": 196706
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131170,
      "h": 12885033058,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033058)
  ],
  "i": [589918,90308609
  ],
  "h": 131170
}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131170)
        
        
        //--TRIMMABLE-BOUNDARY-START(65634)
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions", ($self) => class FileConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590000226)
            /*string*/ static FileProviderKey = null;
            //--TRIMMABLE-BOUNDARY-END(8590000226)
            
            //--TRIMMABLE-BOUNDARY-START(4295032930)
            /*string*/ static FileLoadExceptionHandlerKey = null;
            //--TRIMMABLE-BOUNDARY-END(4295032930)
            
            //--TRIMMABLE-BOUNDARY-START(30064836706)
            static /*IConfigurationBuilder */ SetFileProvider(/*this IConfigurationBuilder*/ builder, /*IFileProvider*/ fileProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileProvider, "fileProvider");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileProvider"/*FileProviderKey*/, fileProvider, [$.$$.System.String, $.$$.System.Object]);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836706)
            
            //--TRIMMABLE-BOUNDARY-START(17179934818)
            static /*IFileProvider */ GetFileProvider(/*this IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                /*object?*/ let provider;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileProvider"/*FileProviderKey*/, $.$ref(() => provider, ($v) => provider = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return $.$cast(provider, $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2($.$$.System.AppContext.BaseDirectory ?? $.$$.System.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(17179934818)
            
            //--TRIMMABLE-BOUNDARY-START(21474902114)
            static /*IConfigurationBuilder */ SetBasePath(/*this IConfigurationBuilder*/ builder, /*string*/ basePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(basePath, "basePath");
                return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.SetFileProvider(builder, new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2(basePath));
            }
            //--TRIMMABLE-BOUNDARY-END(21474902114)
            
            //--TRIMMABLE-BOUNDARY-START(25769869410)
            static /*IConfigurationBuilder */ SetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder, /*Action<FileLoadExceptionContext>*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, handler, [$.$$.System.String, $.$$.System.Object]);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869410)
            
            //--TRIMMABLE-BOUNDARY-START(12884967522)
            static /*Action<FileLoadExceptionContext>? */ GetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                /*object?*/ let handler;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, $.$ref(() => handler, ($v) => handler = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return $.$as(handler, $.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967522)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000226)
                    this.FileProviderKey = "FileProvider";
                    //--TRIMMABLE-BOUNDARY-END(8590000226)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032930)
                    this.FileLoadExceptionHandlerKey = "FileLoadExceptionHandler";
                    //--TRIMMABLE-BOUNDARY-END(4295032930)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65634;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064836706),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "fileProvider",
          "p": 262243
        }
      ],
      "n": "SetFileProvider",
      "d": 65634,
      "h": 30064836706,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064836706),
//--TRIMMABLE-BOUNDARY-START(17179934818),
    {
      "r": 262243,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "GetFileProvider",
      "d": 65634,
      "h": 17179934818,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934818),
//--TRIMMABLE-BOUNDARY-START(21474902114),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "basePath",
          "p": 1310721
        }
      ],
      "n": "SetBasePath",
      "d": 65634,
      "h": 21474902114,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902114),
//--TRIMMABLE-BOUNDARY-START(25769869410),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "handler",
          "p": $.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h
        }
      ],
      "n": "SetFileLoadExceptionHandler",
      "d": 65634,
      "h": 25769869410,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869410),
//--TRIMMABLE-BOUNDARY-START(12884967522),
    {
      "r": $.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "GetFileLoadExceptionHandler",
      "d": 65634,
      "h": 12884967522,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12884967522)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000226),
    {
      "t": 1310721,
      "n": "FileProviderKey",
      "d": 65634,
      "h": 8590000226,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590000226),
//--TRIMMABLE-BOUNDARY-START(4295032930),
    {
      "t": 1310721,
      "n": "FileLoadExceptionHandlerKey",
      "d": 65634,
      "h": 4295032930,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032930)
  ],
  "h": 65634
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65634)
        
        
        //--TRIMMABLE-BOUNDARY-START(327778)
        $asm.$cls("$mecf.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(137439281250)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(137439281250)
            
            //--TRIMMABLE-BOUNDARY-START(128849346658)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(128849346658)
            
            //--TRIMMABLE-BOUNDARY-START(133144313954)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mecf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.FileExtensions", $.$mecf.System.SR.$type.Assembly);
                    $.$mecf.System.SR.s_resourceManager = temp;
                }
                return $.$mecf.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(133144313954)
            
            //--TRIMMABLE-BOUNDARY-START(8590262370)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecf.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262370)
            
            //--TRIMMABLE-BOUNDARY-START(12885229666)
            static /*string */ get Error_ExpectedPhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return " The expected physical path was '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885229666)
            
            //--TRIMMABLE-BOUNDARY-START(60129869922)
            static /*string */ FormatError_ExpectedPhysicalPath(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9(" The expected physical path was '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(60129869922)
            
            //--TRIMMABLE-BOUNDARY-START(21475164258)
            static /*string */ get Error_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The configuration file '{0}' was not found and is not optional.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475164258)
            
            //--TRIMMABLE-BOUNDARY-START(68719804514)
            static /*string */ FormatError_FileNotFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The configuration file '{0}' was not found and is not optional.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68719804514)
            
            //--TRIMMABLE-BOUNDARY-START(17180196962)
            static /*string */ get Error_FailedToLoad()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Failed to load configuration from file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180196962)
            
            //--TRIMMABLE-BOUNDARY-START(64424837218)
            static /*string */ FormatError_FailedToLoad(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Failed to load configuration from file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64424837218)
            
            //--TRIMMABLE-BOUNDARY-START(141734248546)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(141734248546)
            
            //--TRIMMABLE-BOUNDARY-START(124554379362)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554379362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379362)
            
            //--TRIMMABLE-BOUNDARY-START(154619150434)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619150434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecf.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619150434)
            
            //--TRIMMABLE-BOUNDARY-START(120259412066)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecf.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(120259412066)
            
            //--TRIMMABLE-BOUNDARY-START(115964444770)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecf.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(115964444770)
            
            //--TRIMMABLE-BOUNDARY-START(51539935330)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51539935330)
            
            //--TRIMMABLE-BOUNDARY-START(47244968034)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47244968034)
            
            //--TRIMMABLE-BOUNDARY-START(42950000738)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950000738)
            
            //--TRIMMABLE-BOUNDARY-START(55834902626)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55834902626)
            
            //--TRIMMABLE-BOUNDARY-START(34360066146)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(34360066146)
            
            //--TRIMMABLE-BOUNDARY-START(30065098850)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(30065098850)
            
            //--TRIMMABLE-BOUNDARY-START(25770131554)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(25770131554)
            
            //--TRIMMABLE-BOUNDARY-START(38655033442)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(38655033442)
            
            //--TRIMMABLE-BOUNDARY-START(4295295074)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(141734248546)
                    this.s_usingResourceKeys = $.$mecf.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(141734248546)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295074)
            
            static $h = 327778;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 327778
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327778)
        
        
        //--TRIMMABLE-BOUNDARY-START(262242)
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext", ($self) => class FileLoadExceptionContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55834837090)
            /*FileConfigurationProvider*/ Provider = null;
            //--TRIMMABLE-BOUNDARY-END(55834837090)
            
            //--TRIMMABLE-BOUNDARY-START(21475098722)
            /*Exception*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(21475098722)
            
            //--TRIMMABLE-BOUNDARY-START(51539869794)
            /*bool*/ Ignore = false;
            //--TRIMMABLE-BOUNDARY-END(51539869794)
            
            //--TRIMMABLE-BOUNDARY-START(17180131426)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131426)
            
            //default member initializer
            constructor()
            {
                super();
                this.Provider = null;
                this.Exception = null;
            }
            static $h = 262242;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834837090),
    {
      "p": 131170,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902498,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604640866,
        "f": 83886081
      },
      "n": "Provider",
      "d": 262242,
      "h": 55834837090,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834837090),
//--TRIMMABLE-BOUNDARY-START(21475098722),
    {
      "p": 80019457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033314,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424771682,
        "f": 83886081
      },
      "n": "Exception",
      "d": 262242,
      "h": 21475098722,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098722),
//--TRIMMABLE-BOUNDARY-START(51539869794),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967906,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014706274,
        "f": 83886081
      },
      "n": "Ignore",
      "d": 262242,
      "h": 51539869794,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539869794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131426),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262242,
      "h": 17180131426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131426)
  ],
  "h": 262242
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileLoadExceptionContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262242)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.ComponentModel", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Physical"))
//--TRIMMABLE-BOUNDARY-END(98)
