
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mefa, $mef, $mwp, $scm, $scn, $scp, $sto, $sifw, $sds, $srn, $sfa, $snp, $sscr, $mefp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.FileExtensions", 
    {"h":16,"f":"Microsoft.Extensions.Configuration.FileExtensions","v":"1.0.35.0","a":[{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.Configuration.FileExtensions.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.FileExtensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.FileExtensions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource", ($self) => class FileConfigurationSource extends $.$$.System.Object
        {
            /*IFileProvider?*/ FileProvider = null;
            /*string?*/ Path = null;
            /*bool*/ Optional = false;
            /*bool*/ ReloadOnChange = false;
            /*int*/ ReloadDelay = 0;
            /*Action<FileLoadExceptionContext>?*/ OnLoadException = null;
            /*void */ EnsureDefaults(/*IConfigurationBuilder*/ builder)
            {
                this.FileProvider ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileProvider(builder);
                this.OnLoadException ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileLoadExceptionHandler(builder);
            }
            /*void */ ResolveFileProvider()
            {
                if (this.FileProvider === null && !$.$$.System.String.IsNullOrEmpty(this.Path) && $.$$.System.IO.Path.IsPathRooted$1(this.Path))
                {
                    /*string?*/ let directory = $.$$.System.IO.Path.GetDirectoryName$1(this.Path);
                    /*string?*/ let pathToFile = $.$$.System.IO.Path.GetFileName$1(this.Path);
                    while(!$.$$.System.String.IsNullOrEmpty(directory) && !$.$$.System.IO.Directory.Exists(directory))
                    {
                        pathToFile = $.$$.System.IO.Path.Combine$3($.$$.System.IO.Path.GetFileName$1(directory), pathToFile);
                        directory = $.$$.System.IO.Path.GetDirectoryName$1(directory);
                    }
                    if ($.$$.System.IO.Directory.Exists(directory))
                    {
                        this.FileProvider = new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2(directory);
                        this.Path = pathToFile;
                    }
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Optional = false;
                this.ReloadOnChange = false;
                this.ReloadDelay = 250;
            }
            static $h = 196624;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262170,"g":{"r":0,"d":0,"h":12885098512,"f":50331649},"s":{"r":0,"d":0,"h":17180065808,"f":83886081},"n":"FileProvider","d":196624,"h":8590131216,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30064967696,"f":50331649},"s":{"r":0,"d":0,"h":34359934992,"f":83886081},"n":"Path","d":196624,"h":25770000400,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47244836880,"f":50331649},"s":{"r":0,"d":0,"h":51539804176,"f":83886081},"n":"Optional","d":196624,"h":42949869584,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64424706064,"f":50331649},"s":{"r":0,"d":0,"h":68719673360,"f":83886081},"n":"ReloadOnChange","d":196624,"h":60129738768,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":81604575248,"f":50331649},"s":{"r":0,"d":0,"h":85899542544,"f":83886081},"n":"ReloadDelay","d":196624,"h":77309607952,"f":2097153},{"p":$.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,"g":{"r":0,"d":0,"h":98784444432,"f":50331649},"s":{"r":0,"d":0,"h":103079411728,"f":83886081},"n":"OnLoadException","d":196624,"h":94489477136,"f":2097153}],"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":196624,"h":107374379024,"f":16777473},{"r":65537,"p":[{"n":"builder","p":327694}],"n":"EnsureDefaults","d":196624,"h":111669346320,"f":16777217},{"r":65537,"n":"ResolveFileProvider","d":196624,"h":115964313616,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":196624,"h":120259280912,"f":16777220}],"i":[655374],"h":196624}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationSource`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider", ($self) => class FileConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider
        {
            /*IDisposable?*/ _changeTokenRegistration = null;
            $ctor$2(/*FileConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this.Source = source;
                    if (this.Source.ReloadOnChange && this.Source.FileProvider !== null)
                    {
                        this._changeTokenRegistration = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(this,  () =>
                        {
                            return this.Source.FileProvider.Microsoft$Extensions$FileProviders$IFileProvider$Watch(this.Source.Path);
                        }, {"r":720898,"n":"","d":131088,"h":0,"f":17825794}), new $.$$.System.Action().$ctor(this,  () =>
                        {
                            $.$$.System.Threading.Thread.Sleep(this.Source.ReloadDelay);
                            this.Load$1(true);
                        }, {"r":65537,"n":"","d":131088,"h":0,"f":17825794}));
                    }
                }
                return this;
            }
            /*FileConfigurationSource*/ Source = null;
            static/*conventional*/ /*string */ ToString()
            {
                return `${$.$$.System.Object.GetType.call(this).Name} for '${this.Source.Path}' (${(this.Source.Optional ? "Optional" : "Required")})`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider.ToString.apply(this, arguments); }
            /*void */ Load$1(/*bool*/ reload)
            {
                /*IFileInfo?*/ let file = (this.Source.FileProvider?.Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo(this.Source.Path ?? $.$$.System.String.Empty) ?? null);
                if (file === null || !file.Microsoft$Extensions$FileProviders$IFileInfo$Exists)
                {
                    if (this.Source.Optional || reload)
                    {
                        this.Data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                    }
                    else 
                    {
                        /*var*/ let error = new $.$$.System.Text.StringBuilder().$ctor$8($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_FileNotFound, this.Source.Path));
                        if (!$.$$.System.String.IsNullOrEmpty((file?.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath ?? null)))
                        {
                            error.Append$19($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_ExpectedPhysicalPath, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath));
                        }
                        this.HandleException($.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(new $.$$.System.IO.FileNotFoundException().$ctor$19($.$$.System.Text.StringBuilder.ToString.call(error))));
                    }
                }
                else 
                {
                    /*static Stream*/  function OpenRead(/*IFileInfo*/ fileInfo)
                    {
                        if ($.$$.System.String.op_Inequality(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, null))
                        {
                            return new $.$$.System.IO.FileStream().$ctor$12(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/);
                        }
                        return fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream();
                    }
                    /*Stream*/ let stream = OpenRead(file);
                    try
                    {
                        try
                        {
                            this.Load$2(stream);
                        }
                        catch(ex)
                        {
                            if (reload)
                            {
                                this.Data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                            }
                            /*var*/ let exception = new $.$$.System.IO.InvalidDataException().$ctor$11($.$mecf.System.SR.Format$6($.$mecf.System.SR.Error_FailedToLoad, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath), ex);
                            this.HandleException($.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception));
                        }
                    }
                    finally
                    {
                        stream?.System$IDisposable$Dispose();
                    }
                }
                this.OnReload();
            }
            /*void */ Load()
            {
                this.Load$1(false);
            }
            /*void */ HandleException(/*ExceptionDispatchInfo*/ info)
            {
                /*bool*/ let ignoreException = false;
                if (this.Source.OnLoadException !== null)
                {
                    /*var*/ let exceptionContext = (() =>
                    {
                        //new $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext()
                        const $t1 = $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext;
                        const $i1 = new $t1();
                        $i1.Provider = this;
                        $i1.Exception = info.SourceException;
                        return $i1;
                    })();
                    this.Source.OnLoadException.Invoke(exceptionContext);
                    ignoreException = exceptionContext.Ignore;
                }
                if (!ignoreException)
                {
                    info.Throw();
                }
            }
            /*void */ Dispose()
            {
                return this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                this._changeTokenRegistration?.System$IDisposable$Dispose();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 131088;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589837,"p":[{"p":196624,"g":{"r":0,"d":0,"h":21474967568,"f":50331649},"n":"Source","d":131088,"h":17180000272,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":131088,"h":25769934864,"f":16809985},{"r":65537,"p":[{"n":"reload","p":262145}],"n":"Load","o":"@$1","d":131088,"h":30064902160,"f":16777218},{"r":65537,"n":"Load","d":131088,"h":34359869456,"f":16809985},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$2","d":131088,"h":38654836752,"f":16777473},{"r":65537,"p":[{"n":"info","p":97386497}],"n":"HandleException","d":131088,"h":42949804048,"f":16777218},{"r":65537,"n":"Dispose","d":131088,"h":47244771344,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":131088,"h":51539738640,"f":16777348}],"l":[{"t":57540609,"n":"_changeTokenRegistration","d":131088,"h":4295098384,"f":4194306}],"c":[{"p":[{"n":"source","p":196624}],"n":".ctor","o":"$ctor$2","d":131088,"h":8590065680,"f":16777217}],"i":[458766,57540609],"h":131088}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationProvider`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext", ($self) => class FileLoadExceptionContext extends $.$$.System.Object
        {
            /*FileConfigurationProvider*/ Provider = null;
            /*Exception*/ Exception = null;
            /*bool*/ Ignore = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Provider = null;
                this.Exception = null;
                this.Ignore = false;
            }
            static $h = 262160;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131088,"g":{"r":0,"d":0,"h":12885164048,"f":50331649},"s":{"r":0,"d":0,"h":17180131344,"f":83886081},"n":"Provider","d":262160,"h":8590196752,"f":2097153},{"p":47251457,"g":{"r":0,"d":0,"h":30065033232,"f":50331649},"s":{"r":0,"d":0,"h":34360000528,"f":83886081},"n":"Exception","d":262160,"h":25770065936,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47244902416,"f":50331649},"s":{"r":0,"d":0,"h":51539869712,"f":83886081},"n":"Ignore","d":262160,"h":42949935120,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":262160,"h":55834837008,"f":16777217}],"h":262160}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileLoadExceptionContext`; }
        });
        
        $asm.$cls("$mecf.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mecf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.FileExtensions", $.$mecf.System.SR.$type.Assembly);
                    $.$mecf.System.SR.s_resourceManager = temp;
                }
                return $.$mecf.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mecf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mecf.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_ExpectedPhysicalPath()
            {
                return " The expected physical path was '{0}'.";
            }
            static /*string */ FormatError_ExpectedPhysicalPath(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9(" The expected physical path was '{0}'.", arg1);
            }
            static /*string */ get Error_FileNotFound()
            {
                return "The configuration file '{0}' was not found and is not optional.";
            }
            static /*string */ FormatError_FileNotFound(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The configuration file '{0}' was not found and is not optional.", arg1);
            }
            static /*string */ get Error_FailedToLoad()
            {
                return "Failed to load configuration from file '{0}'.";
            }
            static /*string */ FormatError_FailedToLoad(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Failed to load configuration from file '{0}'.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mecf.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecf.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mecf.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mecf.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 327696;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":327696}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions", ($self) => class FileConfigurationExtensions
        {
            /*string*/ static FileProviderKey = null;
            /*string*/ static FileLoadExceptionHandlerKey = null;
            static /*IConfigurationBuilder */ SetFileProvider(/*this IConfigurationBuilder*/ builder, /*IFileProvider*/ fileProvider)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(fileProvider, "fileProvider");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileProvider"/*FileProviderKey*/, fileProvider, [$.$$.System.String, $.$$.System.Object]);
                return builder;
            }
            static /*IFileProvider */ GetFileProvider(/*this IConfigurationBuilder*/ builder)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                /*object?*/ let provider;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileProvider"/*FileProviderKey*/, $.$ref(() => provider, ($v) => provider = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return $.$cast(provider, $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2($.$$.System.AppContext.BaseDirectory ?? $.$$.System.String.Empty);
            }
            static /*IConfigurationBuilder */ SetBasePath(/*this IConfigurationBuilder*/ builder, /*string*/ basePath)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(basePath, "basePath");
                return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.SetFileProvider(builder, new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$2(basePath));
            }
            static /*IConfigurationBuilder */ SetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder, /*Action<FileLoadExceptionContext>*/ handler)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, handler, [$.$$.System.String, $.$$.System.Object]);
                return builder;
            }
            static /*Action<FileLoadExceptionContext>? */ GetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                /*object?*/ let handler;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, $.$ref(() => handler, ($v) => handler = $v, $.$$.System.Object), [$.$$.System.String, $.$$.System.Object]))
                {
                    return $.$as(handler, $.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext));
                }
                return null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.FileProviderKey = "FileProvider";
                }
                {
                    this.FileLoadExceptionHandlerKey = "FileLoadExceptionHandler";
                }
            }
            static $h = 65552;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"builder","p":327694},{"n":"fileProvider","p":262170}],"n":"SetFileProvider","d":65552,"h":12884967440,"f":16777249},{"r":262170,"p":[{"n":"builder","p":327694}],"n":"GetFileProvider","d":65552,"h":17179934736,"f":16777249},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"basePath","p":1310721}],"n":"SetBasePath","d":65552,"h":21474902032,"f":16777249},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"handler","p":$.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h}],"n":"SetFileLoadExceptionHandler","d":65552,"h":25769869328,"f":16777249},{"r":$.$$.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,"p":[{"n":"builder","p":327694}],"n":"GetFileLoadExceptionHandler","d":65552,"h":30064836624,"f":16777249}],"l":[{"t":1310721,"n":"FileProviderKey","d":65552,"h":4295032848,"f":4194338},{"t":1310721,"n":"FileLoadExceptionHandlerKey","d":65552,"h":8590000144,"f":4194338}],"h":65552}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationExtensions`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.ComponentModel", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Physical"))