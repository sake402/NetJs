
(function ($global, $, $spc, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mefa, $mef, $mwp, $scm, $scn, $scp, $sto, $sifw, $sds, $srn, $sfa, $snp, $sscr, $mefp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.FileExtensions", 
    {"h":16,"f":"Microsoft.Extensions.Configuration.FileExtensions","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.Configuration.FileExtensions.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.FileExtensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.FileExtensions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource", ($self) => class FileConfigurationSource extends $.$spc.System.Object
        {
            /*IFileProvider?*/ FileProvider = null;
            /*string?*/ Path = null;
            /*bool*/ Optional = false;
            /*bool*/ ReloadOnChange = false;
            /*int*/ ReloadDelay = 0;
            /*Action<FileLoadExceptionContext>?*/ OnLoadException = null;
            /*void */ EnsureDefaults(/*IConfigurationBuilder*/ builder)
            {
                this.FileProvider ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileProvider(builder);
                this.OnLoadException ??= $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.GetFileLoadExceptionHandler(builder);
            }
            /*void */ ResolveFileProvider()
            {
                if (this.FileProvider === null && !$.$spc.System.String.IsNullOrEmpty(this.Path) && $.$spc.System.IO.Path.IsPathRooted(this.Path))
                {
                    /*string?*/ let directory = $.$spc.System.IO.Path.GetDirectoryName(this.Path);
                    /*string?*/ let pathToFile = $.$spc.System.IO.Path.GetFileName(this.Path);
                    while(!$.$spc.System.String.IsNullOrEmpty(directory) && !$.$spc.System.IO.Directory.Exists(directory))
                    {
                        pathToFile = $.$spc.System.IO.Path.Combine($.$spc.System.IO.Path.GetFileName(directory), pathToFile);
                        directory = $.$spc.System.IO.Path.GetDirectoryName(directory);
                    }
                    if ($.$spc.System.IO.Directory.Exists(directory))
                    {
                        this.FileProvider = new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$1(directory);
                        this.Path = pathToFile;
                    }
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Optional = false;
                this.ReloadOnChange = false;
                this.ReloadDelay = 250;
            }
            static $h = 196624;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262170,"g":{"r":0,"d":0,"h":12885098512,"f":1},"s":{"r":0,"d":0,"h":17180065808,"f":1},"n":"FileProvider","d":196624,"h":8590131216,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064967696,"f":1},"s":{"r":0,"d":0,"h":34359934992,"f":1},"n":"Path","d":196624,"h":25770000400,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47244836880,"f":1},"s":{"r":0,"d":0,"h":51539804176,"f":1},"n":"Optional","d":196624,"h":42949869584,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":64424706064,"f":1},"s":{"r":0,"d":0,"h":68719673360,"f":1},"n":"ReloadOnChange","d":196624,"h":60129738768,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81604575248,"f":1},"s":{"r":0,"d":0,"h":85899542544,"f":1},"n":"ReloadDelay","d":196624,"h":77309607952,"f":1},{"p":$.$spc.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,"g":{"r":0,"d":0,"h":98784444432,"f":1},"s":{"r":0,"d":0,"h":103079411728,"f":1},"n":"OnLoadException","d":196624,"h":94489477136,"f":1}],"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":196624,"h":107374379024,"f":257},{"r":65537,"p":[{"n":"builder","p":327694}],"n":"EnsureDefaults","d":196624,"h":111669346320,"f":1},{"r":65537,"n":"ResolveFileProvider","d":196624,"h":115964313616,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":196624,"h":120259280912,"f":4}],"i":[655374],"h":196624}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationSource`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider", ($self) => class FileConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider
        {
            /*IDisposable?*/ _changeTokenRegistration = null;
            $ctor$2(/*FileConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                    this.Source = source;
                    if (this.Source.ReloadOnChange && this.Source.FileProvider !== null)
                    {
                        this._changeTokenRegistration = $.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$spc.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(this,  () =>
                        {
                            return this.Source.FileProvider.Microsoft$Extensions$FileProviders$IFileProvider$Watch(this.Source.Path);
                        }, {"r":720898,"n":"","d":131088,"h":0,"f":1048578}), new $.$spc.System.Action().$ctor(this,  () =>
                        {
                            $.$spc.System.Threading.Thread.Sleep(this.Source.ReloadDelay);
                            this.Load$1(true);
                        }, {"r":65537,"n":"","d":131088,"h":0,"f":1048578}));
                    }
                }
                return this;
            }
            /*FileConfigurationSource*/ Source = null;
            static/*conventional*/ /*string */ ToString()
            {
                return `${$.$spc.System.Object.GetType.call(this).Name} for '${this.Source.Path}' (${(this.Source.Optional ? "Optional" : "Required")})`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider.ToString.apply(this, arguments); }
            /*void */ Load$1(/*bool*/ reload)
            {
                /*IFileInfo?*/ let file = (this.Source.FileProvider?.Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo(this.Source.Path ?? $.$spc.System.String.Empty) ?? null);
                if (file === null || !file.Microsoft$Extensions$FileProviders$IFileInfo$Exists)
                {
                    if (this.Source.Optional || reload)
                    {
                        this.Data = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                    }
                    else 
                    {
                        /*var*/ let error = new $.$spc.System.Text.StringBuilder().$ctor$3($.$mecf.System.SR.Format($.$mecf.System.SR.Error_FileNotFound, this.Source.Path));
                        if (!$.$spc.System.String.IsNullOrEmpty((file?.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath ?? null)))
                        {
                            error.Append$2($.$mecf.System.SR.Format($.$mecf.System.SR.Error_ExpectedPhysicalPath, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath));
                        }
                        this.HandleException($.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(new $.$spc.System.IO.FileNotFoundException().$ctor$15($.$spc.System.Text.StringBuilder.ToString.call(error))));
                    }
                }
                else 
                {
                    /*static Stream*/  function OpenRead(/*IFileInfo*/ fileInfo)
                    {
                        if ($.$spc.System.String.op_Inequality(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, null))
                        {
                            return new $.$spc.System.IO.FileStream().$ctor$15(fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, 1, 134217728/*FileOptions.SequentialScan*/);
                        }
                        return fileInfo.Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream();
                    }
                    /*Stream*/ let stream = OpenRead(file);
                    try
                    {
                        try
                        {
                            this.Load$2(stream);
                        }
                        catch(ex)
                        {
                            if (reload)
                            {
                                this.Data = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                            }
                            /*var*/ let exception = new $.$spc.System.IO.InvalidDataException().$ctor$11($.$mecf.System.SR.Format($.$mecf.System.SR.Error_FailedToLoad, file.Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath), ex);
                            this.HandleException($.$spc.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception));
                        }
                    }
                    finally
                    {
                        stream?.System$IDisposable$Dispose();
                    }
                }
                this.OnReload();
            }
            /*void */ Load()
            {
                this.Load$1(false);
            }
            /*void */ HandleException(/*ExceptionDispatchInfo*/ info)
            {
                /*bool*/ let ignoreException = false;
                if (this.Source.OnLoadException !== null)
                {
                    /*var*/ let exceptionContext = (() =>
                    {
                        //new $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext()
                        const $t1 = $.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext;
                        const $i1 = new $t1();
                        $i1.Provider = this;
                        $i1.Exception = info.SourceException;
                        return $i1;
                    })();
                    this.Source.OnLoadException.Invoke(exceptionContext);
                    ignoreException = exceptionContext.Ignore;
                }
                if (!ignoreException)
                {
                    info.Throw();
                }
            }
            /*void */ Dispose()
            {
                return this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                this._changeTokenRegistration?.System$IDisposable$Dispose();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 131088;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589837,"p":[{"p":196624,"g":{"r":0,"d":0,"h":21474967568,"f":1},"n":"Source","d":131088,"h":17180000272,"f":1}],"m":[{"r":1310721,"n":"ToString","d":131088,"h":25769934864,"f":32769},{"r":65537,"p":[{"n":"reload","p":262145}],"n":"Load","o":"@$1","d":131088,"h":30064902160,"f":2},{"r":65537,"n":"Load","d":131088,"h":34359869456,"f":32769},{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$2","d":131088,"h":38654836752,"f":257},{"r":65537,"p":[{"n":"info","p":97517569}],"n":"HandleException","d":131088,"h":42949804048,"f":2},{"r":65537,"n":"Dispose","d":131088,"h":47244771344,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":131088,"h":51539738640,"f":132}],"l":[{"t":57540609,"n":"_changeTokenRegistration","d":131088,"h":4295098384,"f":2}],"c":[{"p":[{"n":"source","p":196624}],"n":".ctor","o":"$ctor$2","d":131088,"h":8590065680,"f":1}],"i":[458766,57540609],"h":131088}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationProvider`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext", ($self) => class FileLoadExceptionContext extends $.$spc.System.Object
        {
            /*FileConfigurationProvider*/ Provider = null;
            /*Exception*/ Exception = null;
            /*bool*/ Ignore = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Provider = null;
                this.Exception = null;
                this.Ignore = false;
            }
            static $h = 262160;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131088,"g":{"r":0,"d":0,"h":12885164048,"f":1},"s":{"r":0,"d":0,"h":17180131344,"f":1},"n":"Provider","d":262160,"h":8590196752,"f":1},{"p":47251457,"g":{"r":0,"d":0,"h":30065033232,"f":1},"s":{"r":0,"d":0,"h":34360000528,"f":1},"n":"Exception","d":262160,"h":25770065936,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47244902416,"f":1},"s":{"r":0,"d":0,"h":51539869712,"f":1},"n":"Ignore","d":262160,"h":42949935120,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":262160,"h":55834837008,"f":1}],"h":262160}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileLoadExceptionContext`; }
        });
        
        $asm.$cls("$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions", ($self) => class FileConfigurationExtensions
        {
            /*string*/ static FileProviderKey = null;
            /*string*/ static FileLoadExceptionHandlerKey = null;
            static /*IConfigurationBuilder */ SetFileProvider(/*this IConfigurationBuilder*/ builder, /*IFileProvider*/ fileProvider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$spc.System.ArgumentNullException.ThrowIfNull(fileProvider, "fileProvider");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileProvider"/*FileProviderKey*/, fileProvider, [$.$spc.System.String, $.$spc.System.Object]);
                return builder;
            }
            static /*IFileProvider */ GetFileProvider(/*this IConfigurationBuilder*/ builder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                /*object?*/ let provider;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileProvider"/*FileProviderKey*/, $.$ref(() => provider, ($v) => provider = $v, $.$spc.System.Object), [$.$spc.System.String, $.$spc.System.Object]))
                {
                    return $.$cast(provider, $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$1($.$spc.System.AppContext.BaseDirectory ?? $.$spc.System.String.Empty);
            }
            static /*IConfigurationBuilder */ SetBasePath(/*this IConfigurationBuilder*/ builder, /*string*/ basePath)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$spc.System.ArgumentNullException.ThrowIfNull(basePath, "basePath");
                return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationExtensions.SetFileProvider(builder, new $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider().$ctor$1(basePath));
            }
            static /*IConfigurationBuilder */ SetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder, /*Action<FileLoadExceptionContext>*/ handler)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$set_Item("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, handler, [$.$spc.System.String, $.$spc.System.Object]);
                return builder;
            }
            static /*Action<FileLoadExceptionContext>? */ GetFileLoadExceptionHandler(/*this IConfigurationBuilder*/ builder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                /*object?*/ let handler;
                if (builder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties.System$Collections$Generic$IDictionary$$$$TryGetValue("FileLoadExceptionHandler"/*FileLoadExceptionHandlerKey*/, $.$ref(() => handler, ($v) => handler = $v, $.$spc.System.Object), [$.$spc.System.String, $.$spc.System.Object]))
                {
                    return $.$as(handler, $.$spc.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext));
                }
                return null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.FileProviderKey = "FileProvider";
                }
                {
                    this.FileLoadExceptionHandlerKey = "FileLoadExceptionHandler";
                }
            }
            static $h = 65552;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"builder","p":327694},{"n":"fileProvider","p":262170}],"n":"SetFileProvider","d":65552,"h":12884967440,"f":33},{"r":262170,"p":[{"n":"builder","p":327694}],"n":"GetFileProvider","d":65552,"h":17179934736,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"basePath","p":1310721}],"n":"SetBasePath","d":65552,"h":21474902032,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"handler","p":$.$spc.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h}],"n":"SetFileLoadExceptionHandler","d":65552,"h":25769869328,"f":33},{"r":$.$spc.System.Action$$($.$mecf.Microsoft.Extensions.Configuration.FileLoadExceptionContext).$h,"p":[{"n":"builder","p":327694}],"n":"GetFileLoadExceptionHandler","d":65552,"h":30064836624,"f":33}],"l":[{"t":1310721,"n":"FileProviderKey","d":65552,"h":4295032848,"f":34},{"t":1310721,"n":"FileLoadExceptionHandlerKey","d":65552,"h":8590000144,"f":34}],"h":65552}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.FileConfigurationExtensions`; }
        });
        
        $asm.$cls("$mecf.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mecf.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.FileExtensions", $.$mecf.System.SR.$type.Assembly);
                    $.$mecf.System.SR.s_resourceManager = temp;
                }
                return $.$mecf.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mecf.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mecf.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_ExpectedPhysicalPath()
            {
                return " The expected physical path was '{0}'.";
            }
            static /*string */ FormatError_ExpectedPhysicalPath(/*object*/ arg1)
            {
                return $.$spc.System.String.Format(" The expected physical path was '{0}'.", arg1);
            }
            static /*string */ get Error_FileNotFound()
            {
                return "The configuration file '{0}' was not found and is not optional.";
            }
            static /*string */ FormatError_FileNotFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The configuration file '{0}' was not found and is not optional.", arg1);
            }
            static /*string */ get Error_FailedToLoad()
            {
                return "Failed to load configuration from file '{0}'.";
            }
            static /*string */ FormatError_FailedToLoad(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Failed to load configuration from file '{0}'.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mecf.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecf.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mecf.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecf.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecf.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mecf.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 327696;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":327696}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.ComponentModel", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Physical"))