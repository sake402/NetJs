
//--TRIMMABLE-BOUNDARY-START(97)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mecga, $mec, $mefa, $mef, $mwp, $scm, $scn, $scp, $sto, $sifw, $sds, $srn, $sfa, $snp, $sscr, $mefp, $mecf, $sttp, $sipl, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    let $WZPiwe;
    let $DMxCOe;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Json", 
    {
  "h": 97,
  "f": "Microsoft.Extensions.Configuration.Json",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Configuration.Json.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(393313)
        $asm.$cls(`$mecj.MEC.JsonConfigurationExtensions`, ($self) => class JsonConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(21475229793)
            static /*IConfigurationBuilder */ AddJsonFile$4(/*this IConfigurationBuilder*/ builder, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.MEC.JsonConfigurationExtensions.AddJsonFile(builder, null, path, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229793)
            
            //--TRIMMABLE-BOUNDARY-START(17180262497)
            static /*IConfigurationBuilder */ AddJsonFile$3(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.MEC.JsonConfigurationExtensions.AddJsonFile(builder, null, path, optional, false);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262497)
            
            //--TRIMMABLE-BOUNDARY-START(12885295201)
            static /*IConfigurationBuilder */ AddJsonFile$2(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.MEC.JsonConfigurationExtensions.AddJsonFile(builder, null, path, optional, reloadOnChange);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295201)
            
            //--TRIMMABLE-BOUNDARY-START(4295360609)
            static /*IConfigurationBuilder */ AddJsonFile(/*this IConfigurationBuilder*/ builder, /*IFileProvider?*/ provider, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                if ($.$$.S.String.IsNullOrEmpty(path))
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$mecj.S.SR.Error_InvalidFilePath, "path");
                }
                return $.$mecj.MEC.JsonConfigurationExtensions.AddJsonFile$1(builder, new ($.$$.S.Action$$($.$mecj.MECJ.JsonConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    s.FileProvider = provider;
                    s.Path = path;
                    s.Optional = optional;
                    s.ReloadOnChange = reloadOnChange;
                    s.ResolveFileProvider();
                }, $WZPiwe ??= {"r":65537,"p":[{"n":"s","p":196705}],"n":"","d":393313,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(4295360609)
            
            //--TRIMMABLE-BOUNDARY-START(8590327905)
            static /*IConfigurationBuilder */ AddJsonFile$1(/*this IConfigurationBuilder*/ builder, /*Action<JsonConfigurationSource>?*/ configureSource)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecga.MEC.ConfigurationExtensions.Add($.$mecj.MECJ.JsonConfigurationSource, builder, configureSource);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327905)
            
            //--TRIMMABLE-BOUNDARY-START(25770197089)
            static /*IConfigurationBuilder */ AddJsonStream(/*this IConfigurationBuilder*/ builder, /*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                return $.$mecga.MEC.ConfigurationExtensions.Add($.$mecj.MECJ.JsonStreamConfigurationSource, builder, new ($.$$.S.Action$$($.$mecj.MECJ.JsonStreamConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Stream = stream;
                }, $DMxCOe ??= {"r":65537,"p":[{"n":"s","p":327777}],"n":"","d":393313,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770197089)
            
            static $h = 393313;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475229793),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "AddJsonFile",
      "o": "@$4",
      "d": 393313,
      "h": 21475229793,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475229793),
//--TRIMMABLE-BOUNDARY-START(17180262497),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "o": "@$3",
      "d": 393313,
      "h": 17180262497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180262497),
//--TRIMMABLE-BOUNDARY-START(12885295201),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        },
        {
          "n": "reloadOnChange",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "o": "@$2",
      "d": 393313,
      "h": 12885295201,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295201),
//--TRIMMABLE-BOUNDARY-START(4295360609),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "provider",
          "p": 262243
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        },
        {
          "n": "reloadOnChange",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "d": 393313,
      "h": 4295360609,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360609),
//--TRIMMABLE-BOUNDARY-START(8590327905),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "configureSource",
          "p": $.$$.S.Action$$($.$mecj.MECJ.JsonConfigurationSource).$h
        }
      ],
      "n": "AddJsonFile",
      "o": "@$1",
      "d": 393313,
      "h": 8590327905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327905),
//--TRIMMABLE-BOUNDARY-START(25770197089),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "AddJsonStream",
      "d": 393313,
      "h": 25770197089,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770197089)
  ],
  "h": 393313
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.JsonConfigurationExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}JsonConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393313)
        
        

        //--TRIMMABLE-BOUNDARY-START(458849)
        $asm.$cls(`$mecj.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(163209216097)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(163209216097)
            
            //--TRIMMABLE-BOUNDARY-START(154619281505)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(154619281505)
            
            //--TRIMMABLE-BOUNDARY-START(158914248801)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mecj.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Json", $.$mecj.S.SR.$type.Assembly);
                    $.$mecj.S.SR.s_resourceManager = temp;
                }
                return $.$mecj.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(158914248801)
            
            //--TRIMMABLE-BOUNDARY-START(8590393441)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094117985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecj.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393441)
            
            //--TRIMMABLE-BOUNDARY-START(12885360737)
            static /*string */ get Error_InvalidFilePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "File path must be a non-empty string.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360737)
            
            //--TRIMMABLE-BOUNDARY-START(17180328033)
            static /*string */ get Error_InvalidTopLevelJSONElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Top-level JSON element must be an object. Instead, '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180328033)
            
            //--TRIMMABLE-BOUNDARY-START(68719935585)
            static /*string */ FormatError_InvalidTopLevelJSONElement(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Top-level JSON element must be an object. Instead, '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68719935585)
            
            //--TRIMMABLE-BOUNDARY-START(21475295329)
            static /*string */ get Error_JSONParseError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not parse the JSON file.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475295329)
            
            //--TRIMMABLE-BOUNDARY-START(25770262625)
            static /*string */ get Error_KeyIsDuplicated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A duplicate key '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770262625)
            
            //--TRIMMABLE-BOUNDARY-START(73014902881)
            static /*string */ FormatError_KeyIsDuplicated(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("A duplicate key '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014902881)
            
            //--TRIMMABLE-BOUNDARY-START(30065229921)
            static /*string */ get Error_UnsupportedJSONToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported JSON token '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(30065229921)
            
            //--TRIMMABLE-BOUNDARY-START(77309870177)
            static /*string */ FormatError_UnsupportedJSONToken(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Unsupported JSON token '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77309870177)
            
            //--TRIMMABLE-BOUNDARY-START(167504183393)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(167504183393)
            
            //--TRIMMABLE-BOUNDARY-START(150324314209)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324314209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324314209)
            
            //--TRIMMABLE-BOUNDARY-START(180389085281)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389085281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecj.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389085281)
            
            //--TRIMMABLE-BOUNDARY-START(146029346913)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecj.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(146029346913)
            
            //--TRIMMABLE-BOUNDARY-START(141734379617)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecj.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(141734379617)
            
            //--TRIMMABLE-BOUNDARY-START(60130000993)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130000993)
            
            //--TRIMMABLE-BOUNDARY-START(55835033697)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(55835033697)
            
            //--TRIMMABLE-BOUNDARY-START(51540066401)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066401)
            
            //--TRIMMABLE-BOUNDARY-START(64424968289)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecj.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968289)
            
            //--TRIMMABLE-BOUNDARY-START(42950131809)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131809)
            
            //--TRIMMABLE-BOUNDARY-START(38655164513)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164513)
            
            //--TRIMMABLE-BOUNDARY-START(34360197217)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197217)
            
            //--TRIMMABLE-BOUNDARY-START(47245099105)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecj.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099105)
            
            //--TRIMMABLE-BOUNDARY-START(4295426145)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(167504183393)
                    this.s_usingResourceKeys = $.$mecj.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(167504183393)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426145)
            
            static $h = 458849;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 458849
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458849)
        
        

        //--TRIMMABLE-BOUNDARY-START(65633)
        $asm.$cls(`$mecj.MECJ.JsonConfigurationFileParser`, ($self) => class JsonConfigurationFileParser extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12884967521)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967521)
            
            //--TRIMMABLE-BOUNDARY-START(4295032929)
            /*Dictionary<string, string?>*/ _data = null;
            //--TRIMMABLE-BOUNDARY-END(4295032929)
            
            //--TRIMMABLE-BOUNDARY-START(8590000225)
            /*Stack<string>*/ _paths = null;
            //--TRIMMABLE-BOUNDARY-END(8590000225)
            
            //--TRIMMABLE-BOUNDARY-START(25769869409)
            static /*IDictionary<string, string?> */ Parse(/*Stream*/ input)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mecj.MECJ.JsonConfigurationFileParser().$ctor$1().ParseStream(input);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869409)
            
            //--TRIMMABLE-BOUNDARY-START(30064836705)
            /*Dictionary<string, string?> */ ParseStream(/*Stream*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsonDocumentOptions = (() =>
                {
                    //new $.$stj.STJ.JsonDocumentOptions()
                    const $t1 = $.$stj.STJ.JsonDocumentOptions;
                    const $i1 = new $t1();
                    $i1.$ctor$2();
                    $i1.CommentHandling = 1/*JsonCommentHandling.Skip*/;
                    $i1.AllowTrailingCommas = true;
                    return $i1;
                })();
                let reader = null;
                try
                {
                    reader = new $.$$.SI.StreamReader().$ctor$9(input);
                    let doc = null;
                    try
                    {
                        doc = $.$stj.STJ.JsonDocument.Parse$6(reader.ReadToEnd(), $.$clone(jsonDocumentOptions));
                        if (doc.RootElement.ValueKind !== 1/*JsonValueKind.Object*/)
                        {
                            throw new $.$$.S.FormatException().$ctor$12($.$mecj.S.SR.Format$6($.$mecj.S.SR.Error_InvalidTopLevelJSONElement, $.$box(doc.RootElement.ValueKind, $.$stj.STJ.JsonValueKind)));
                        }
                        this.VisitObjectElement(doc.RootElement);
                    }
                    finally
                    {
                        doc?.S$IDisposable$Dispose();
                    }
                }
                finally
                {
                    reader?.S$IDisposable$Dispose();
                }
                return this._data;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836705)
            
            //--TRIMMABLE-BOUNDARY-START(47244705889)
            /*void */ VisitObjectElement(/*JsonElement*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let isEmpty = true;
                let $en2 = element.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    let property = $en2.Current;
                    {
                        isEmpty = false;
                        this.EnterContext(property.Name);
                        this.VisitValue(property.Value);
                        this.ExitContext();
                    }
                }
                this.SetNullIfElementIsEmpty(isEmpty);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705889)
            
            //--TRIMMABLE-BOUNDARY-START(42949738593)
            /*void */ VisitArrayElement(/*JsonElement*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = 0;
                let $en3 = element.EnumerateArray().GetEnumerator();
                while ($en3.MoveNext())
                {
                    let arrayElement = $en3.Current;
                    {
                        this.EnterContext($.$$.S.Int32.ToString.call(index));
                        this.VisitValue(arrayElement);
                        this.ExitContext();
                        index++;
                    }
                }
                this.SetEmptyIfElementIsEmpty(index === 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42949738593)
            
            //--TRIMMABLE-BOUNDARY-START(38654771297)
            /*void */ SetNullIfElementIsEmpty(/*bool*/ isEmpty)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654771297)
            
            //--TRIMMABLE-BOUNDARY-START(34359804001)
            /*void */ SetEmptyIfElementIsEmpty(/*bool*/ isEmpty)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359804001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), $.$$.S.String.Empty);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359804001)
            
            //--TRIMMABLE-BOUNDARY-START(51539673185)
            /*void */ VisitValue(/*JsonElement*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._paths.Count > 0, "_paths.Count > 0");
                var key;
                let $switch4 = value.ValueKind;
                switch($switch4)
                {
                    case 1/*JsonValueKind.Object*/:
                    this.VisitObjectElement(value);
                    break;
                    case 2/*JsonValueKind.Array*/:
                    this.VisitArrayElement(value);
                    break;
                    case 4/*JsonValueKind.Number*/:
                    case 3/*JsonValueKind.String*/:
                    case 5/*JsonValueKind.True*/:
                    case 6/*JsonValueKind.False*/:
                    case 7/*JsonValueKind.Null*/:
                    key = this._paths.Peek();
                    if (this._data.ContainsKey(key))
                    {
                        throw new $.$$.S.FormatException().$ctor$12($.$mecj.S.SR.Format$6($.$mecj.S.SR.Error_KeyIsDuplicated, key));
                    }
                    this._data.set_Item(key, value.ValueKind === 7/*JsonValueKind.Null*/ ? null : value.ToString());
                    break;
                    default:
                    throw new $.$$.S.FormatException().$ctor$12($.$mecj.S.SR.Format$6($.$mecj.S.SR.Error_UnsupportedJSONToken, $.$box(value.ValueKind, $.$stj.STJ.JsonValueKind)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539673185)
            
            //--TRIMMABLE-BOUNDARY-START(17179934817)
            /*void */ EnterContext(/*string*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._paths.Push(this._paths.Count > 0 ? $.$strNN($.$strNN(this._paths.Peek()) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(context) : context);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17179934817)
            
            //--TRIMMABLE-BOUNDARY-START(21474902113)
            /*void */ ExitContext()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._paths.Pop();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902113)
            
            //--TRIMMABLE-BOUNDARY-START(12884967521)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967521)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295032929)
                this._data = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(4295032929)
                
                //--TRIMMABLE-BOUNDARY-START(8590000225)
                this._paths = new ($.$sc.SCG.Stack$$($.$$.S.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590000225)
                
            }
            static $h = 65633;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869409),
    {
      "r": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "input",
          "p": 95748097
        }
      ],
      "n": "Parse",
      "d": 65633,
      "h": 25769869409,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869409),
//--TRIMMABLE-BOUNDARY-START(30064836705),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "p": [
        {
          "n": "input",
          "p": 95748097
        }
      ],
      "n": "ParseStream",
      "d": 65633,
      "h": 30064836705,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30064836705),
//--TRIMMABLE-BOUNDARY-START(47244705889),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 2097236
        }
      ],
      "n": "VisitObjectElement",
      "d": 65633,
      "h": 47244705889,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244705889),
//--TRIMMABLE-BOUNDARY-START(42949738593),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 2097236
        }
      ],
      "n": "VisitArrayElement",
      "d": 65633,
      "h": 42949738593,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949738593),
//--TRIMMABLE-BOUNDARY-START(38654771297),
    {
      "r": 65537,
      "p": [
        {
          "n": "isEmpty",
          "p": 262145
        }
      ],
      "n": "SetNullIfElementIsEmpty",
      "d": 65633,
      "h": 38654771297,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38654771297),
//--TRIMMABLE-BOUNDARY-START(34359804001),
    {
      "r": 65537,
      "p": [
        {
          "n": "isEmpty",
          "p": 262145
        }
      ],
      "n": "SetEmptyIfElementIsEmpty",
      "d": 65633,
      "h": 34359804001,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359804001),
//--TRIMMABLE-BOUNDARY-START(51539673185),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2097236
        }
      ],
      "n": "VisitValue",
      "d": 65633,
      "h": 51539673185,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539673185),
//--TRIMMABLE-BOUNDARY-START(17179934817),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1310721
        }
      ],
      "n": "EnterContext",
      "d": 65633,
      "h": 17179934817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17179934817),
//--TRIMMABLE-BOUNDARY-START(21474902113),
    {
      "r": 65537,
      "n": "ExitContext",
      "d": 65633,
      "h": 21474902113,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21474902113)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032929),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_data",
      "d": 65633,
      "h": 4295032929,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032929),
//--TRIMMABLE-BOUNDARY-START(8590000225),
    {
      "t": $.$sc.SCG.Stack$$($.$$.S.String).$h,
      "n": "_paths",
      "d": 65633,
      "h": 8590000225,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967521),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65633,
      "h": 12884967521,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967521)
  ],
  "h": 65633
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Json${separator}JsonConfigurationFileParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65633)
        
        

        //--TRIMMABLE-BOUNDARY-START(196705)
        $asm.$cls(`$mecj.MECJ.JsonConfigurationSource`, ($self) => class JsonConfigurationSource extends $.$mecf.MEC.FileConfigurationSource
        {
            //--TRIMMABLE-BOUNDARY-START(8590131297)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureDefaults(builder);
                return new $.$mecj.MECJ.JsonConfigurationProvider().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131297)
            
            //--TRIMMABLE-BOUNDARY-START(4295164001)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295164001)
            
            //--TRIMMABLE-BOUNDARY-START(4295164001)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295164001)
            
            static $h = 196705;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mecf.MEC.FileConfigurationSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131297),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 196705,
      "h": 8590131297,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590131297)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164001),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196705,
      "h": 4295164001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164001)
  ],
  "h": 196705
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Json.JsonConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Json${separator}JsonConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196705)
        
        

        //--TRIMMABLE-BOUNDARY-START(327777)
        $asm.$cls(`$mecj.MECJ.JsonStreamConfigurationSource`, ($self) => class JsonStreamConfigurationSource extends $.$mec.MEC.StreamConfigurationSource
        {
            //--TRIMMABLE-BOUNDARY-START(8590262369)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mecj.MECJ.JsonStreamConfigurationProvider().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262369)
            
            //--TRIMMABLE-BOUNDARY-START(4295295073)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295073)
            
            //--TRIMMABLE-BOUNDARY-START(4295295073)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295073)
            
            static $h = 327777;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mec.MEC.StreamConfigurationSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590262369),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 327777,
      "h": 8590262369,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590262369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295073),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327777,
      "h": 4295295073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295073)
  ],
  "h": 327777
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Json${separator}JsonStreamConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327777)
        
        

        //--TRIMMABLE-BOUNDARY-START(262241)
        $asm.$cls(`$mecj.MECJ.JsonStreamConfigurationProvider`, ($self) => class JsonStreamConfigurationProvider extends $.$mec.MEC.StreamConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295229537)
            $ctor$3(/*JsonStreamConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229537)
            
            //--TRIMMABLE-BOUNDARY-START(8590196833)
            /*void */ Load$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Data = $.$mecj.MECJ.JsonConfigurationFileParser.Parse(stream);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196833)
            
            static $h = 262241;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mec.MEC.StreamConfigurationProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196833),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 262241,
      "h": 8590196833,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590196833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229537),
    {
      "p": [
        {
          "n": "source",
          "p": 327777
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262241,
      "h": 4295229537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229537)
  ],
  "h": 262241
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Json${separator}JsonStreamConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262241)
        
        

        //--TRIMMABLE-BOUNDARY-START(131169)
        $asm.$cls(`$mecj.MECJ.JsonConfigurationProvider`, ($self) => class JsonConfigurationProvider extends $.$mecf.MEC.FileConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295098465)
            $ctor$3(/*JsonConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098465)
            
            //--TRIMMABLE-BOUNDARY-START(8590065761)
            /*void */ Load$2(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Data = $.$mecj.MECJ.JsonConfigurationFileParser.Parse(stream);
                }
                catch(e)
                {
                    throw new $.$$.S.FormatException().$ctor$11($.$mecj.S.SR.Error_JSONParseError, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065761)
            
            static $h = 131169;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mecf.MEC.FileConfigurationProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590065761),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "Load",
      "o": "@$2",
      "d": 131169,
      "h": 8590065761,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590065761)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098465),
    {
      "p": [
        {
          "n": "source",
          "p": 196705
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131169,
      "h": 4295098465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098465)
  ],
  "h": 131169
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Json${separator}JsonConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131169)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.ComponentModel", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.Threading.ThreadPool", "NetJs.System.IO.Pipelines", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"));
})();
//--TRIMMABLE-BOUNDARY-END(97)
