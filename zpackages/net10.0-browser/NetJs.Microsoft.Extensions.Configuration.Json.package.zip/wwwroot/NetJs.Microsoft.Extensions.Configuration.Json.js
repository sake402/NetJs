
//--TRIMMABLE-BOUNDARY-START(97)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $mefa, $mef, $mwp, $scm, $scn, $scp, $sto, $sifw, $sds, $srn, $sfa, $snp, $sscr, $mefp, $mecf, $sttp, $sipl, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Json", 
    {
  "h": 97,
  "f": "Microsoft.Extensions.Configuration.Json",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.Extensions.Configuration.Json.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(393313)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions", ($self) => class JsonConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295360609)
            static /*IConfigurationBuilder */ AddJsonFile$3(/*this IConfigurationBuilder*/ builder, /*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$4(builder, null, path, false, false);
            }
            //--TRIMMABLE-BOUNDARY-END(4295360609)
            
            //--TRIMMABLE-BOUNDARY-START(8590327905)
            static /*IConfigurationBuilder */ AddJsonFile$2(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$4(builder, null, path, optional, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327905)
            
            //--TRIMMABLE-BOUNDARY-START(12885295201)
            static /*IConfigurationBuilder */ AddJsonFile$1(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$4(builder, null, path, optional, reloadOnChange);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295201)
            
            //--TRIMMABLE-BOUNDARY-START(17180262497)
            static /*IConfigurationBuilder */ AddJsonFile$4(/*this IConfigurationBuilder*/ builder, /*IFileProvider?*/ provider, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                if ($.$$.System.String.IsNullOrEmpty(path))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$mecj.System.SR.Error_InvalidFilePath, "path");
                }
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile(builder, new ($.$$.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    s.FileProvider = provider;
                    s.Path = path;
                    s.Optional = optional;
                    s.ReloadOnChange = reloadOnChange;
                    s.ResolveFileProvider();
                }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 196705
    }
  ],
  "n": "",
  "d": 393313,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(17180262497)
            
            //--TRIMMABLE-BOUNDARY-START(21475229793)
            static /*IConfigurationBuilder */ AddJsonFile(/*this IConfigurationBuilder*/ builder, /*Action<JsonConfigurationSource>?*/ configureSource)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229793);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource, builder, configureSource);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475229793)
            
            //--TRIMMABLE-BOUNDARY-START(25770197089)
            static /*IConfigurationBuilder */ AddJsonStream(/*this IConfigurationBuilder*/ builder, /*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource, builder, new ($.$$.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Stream = stream;
                }, {
  "r": 65537,
  "p": [
    {
      "n": "s",
      "p": 327777
    }
  ],
  "n": "",
  "d": 393313,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770197089)
            
            static $h = 393313;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360609),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "AddJsonFile",
      "o": "@$3",
      "d": 393313,
      "h": 4295360609,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360609),
//--TRIMMABLE-BOUNDARY-START(8590327905),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "o": "@$2",
      "d": 393313,
      "h": 8590327905,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327905),
//--TRIMMABLE-BOUNDARY-START(12885295201),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        },
        {
          "n": "reloadOnChange",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "o": "@$1",
      "d": 393313,
      "h": 12885295201,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295201),
//--TRIMMABLE-BOUNDARY-START(17180262497),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "provider",
          "p": 262243
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "optional",
          "p": 262145
        },
        {
          "n": "reloadOnChange",
          "p": 262145
        }
      ],
      "n": "AddJsonFile",
      "o": "@$4",
      "d": 393313,
      "h": 17180262497,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180262497),
//--TRIMMABLE-BOUNDARY-START(21475229793),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "configureSource",
          "p": $.$$.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource).$h
        }
      ],
      "n": "AddJsonFile",
      "d": 393313,
      "h": 21475229793,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475229793),
//--TRIMMABLE-BOUNDARY-START(25770197089),
    {
      "r": 458846,
      "p": [
        {
          "n": "builder",
          "p": 458846
        },
        {
          "n": "stream",
          "p": 94830593
        }
      ],
      "n": "AddJsonStream",
      "d": 393313,
      "h": 25770197089,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770197089)
  ],
  "h": 393313
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.JsonConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393313)
        
        
        //--TRIMMABLE-BOUNDARY-START(458849)
        $asm.$cls("$mecj.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(163209216097)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(163209216097)
            
            //--TRIMMABLE-BOUNDARY-START(154619281505)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(154619281505)
            
            //--TRIMMABLE-BOUNDARY-START(158914248801)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mecj.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Json", $.$mecj.System.SR.$type.Assembly);
                    $.$mecj.System.SR.s_resourceManager = temp;
                }
                return $.$mecj.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(158914248801)
            
            //--TRIMMABLE-BOUNDARY-START(8590393441)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mecj.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094117985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mecj.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393441)
            
            //--TRIMMABLE-BOUNDARY-START(12885360737)
            static /*string */ get Error_InvalidFilePath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "File path must be a non-empty string.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885360737)
            
            //--TRIMMABLE-BOUNDARY-START(17180328033)
            static /*string */ get Error_InvalidTopLevelJSONElement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Top-level JSON element must be an object. Instead, '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180328033)
            
            //--TRIMMABLE-BOUNDARY-START(68719935585)
            static /*string */ FormatError_InvalidTopLevelJSONElement(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Top-level JSON element must be an object. Instead, '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(68719935585)
            
            //--TRIMMABLE-BOUNDARY-START(21475295329)
            static /*string */ get Error_JSONParseError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not parse the JSON file.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475295329)
            
            //--TRIMMABLE-BOUNDARY-START(25770262625)
            static /*string */ get Error_KeyIsDuplicated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A duplicate key '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770262625)
            
            //--TRIMMABLE-BOUNDARY-START(73014902881)
            static /*string */ FormatError_KeyIsDuplicated(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A duplicate key '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73014902881)
            
            //--TRIMMABLE-BOUNDARY-START(30065229921)
            static /*string */ get Error_UnsupportedJSONToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unsupported JSON token '{0}' was found.";
            }
            //--TRIMMABLE-BOUNDARY-END(30065229921)
            
            //--TRIMMABLE-BOUNDARY-START(77309870177)
            static /*string */ FormatError_UnsupportedJSONToken(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unsupported JSON token '{0}' was found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77309870177)
            
            //--TRIMMABLE-BOUNDARY-START(167504183393)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(167504183393)
            
            //--TRIMMABLE-BOUNDARY-START(150324314209)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324314209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324314209)
            
            //--TRIMMABLE-BOUNDARY-START(180389085281)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389085281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mecj.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389085281)
            
            //--TRIMMABLE-BOUNDARY-START(141734379617)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecj.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(141734379617)
            
            //--TRIMMABLE-BOUNDARY-START(146029346913)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mecj.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(146029346913)
            
            //--TRIMMABLE-BOUNDARY-START(34360197217)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(34360197217)
            
            //--TRIMMABLE-BOUNDARY-START(38655164513)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655164513)
            
            //--TRIMMABLE-BOUNDARY-START(42950131809)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131809)
            
            //--TRIMMABLE-BOUNDARY-START(47245099105)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099105)
            
            //--TRIMMABLE-BOUNDARY-START(51540066401)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066401)
            
            //--TRIMMABLE-BOUNDARY-START(55835033697)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(55835033697)
            
            //--TRIMMABLE-BOUNDARY-START(60130000993)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(60130000993)
            
            //--TRIMMABLE-BOUNDARY-START(64424968289)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mecj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968289)
            
            //--TRIMMABLE-BOUNDARY-START(4295426145)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(167504183393)
                    this.s_usingResourceKeys = $.$mecj.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(167504183393)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426145)
            
            static $h = 458849;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 458849
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458849)
        
        
        //--TRIMMABLE-BOUNDARY-START(65633)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser", ($self) => class JsonConfigurationFileParser extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12884967521)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967521);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967521)
            
            //--TRIMMABLE-BOUNDARY-START(4295032929)
            /*Dictionary<string, string?>*/ _data = null;
            //--TRIMMABLE-BOUNDARY-END(4295032929)
            
            //--TRIMMABLE-BOUNDARY-START(8590000225)
            /*Stack<string>*/ _paths = null;
            //--TRIMMABLE-BOUNDARY-END(8590000225)
            
            //--TRIMMABLE-BOUNDARY-START(25769869409)
            static /*IDictionary<string, string?> */ Parse(/*Stream*/ input)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869409);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser().$ctor$1().ParseStream(input);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869409)
            
            //--TRIMMABLE-BOUNDARY-START(30064836705)
            /*Dictionary<string, string?> */ ParseStream(/*Stream*/ input)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsonDocumentOptions = (() =>
                {
                    //new $.$stj.System.Text.Json.JsonDocumentOptions()
                    const $t1 = $.$stj.System.Text.Json.JsonDocumentOptions;
                    const $i1 = new $t1();
                    $i1.CommentHandling = 1/*JsonCommentHandling.Skip*/;
                    $i1.AllowTrailingCommas = true;
                    return $i1;
                })();
                let reader = null;
                try
                {
                    reader = new $.$$.System.IO.StreamReader().$ctor$9(input);
                    let doc = null;
                    try
                    {
                        doc = $.$stj.System.Text.Json.JsonDocument.Parse$5(reader.ReadToEnd(), jsonDocumentOptions.Clone());
                        if (doc.RootElement.ValueKind !== 1/*JsonValueKind.Object*/)
                        {
                            throw new $.$$.System.FormatException().$ctor$12($.$mecj.System.SR.Format$6($.$mecj.System.SR.Error_InvalidTopLevelJSONElement, $.$box(doc.RootElement.ValueKind, $.$stj.System.Text.Json.JsonValueKind)));
                        }
                        this.VisitObjectElement(doc.RootElement);
                    }
                    finally
                    {
                        doc?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    reader?.System$IDisposable$Dispose();
                }
                return this._data;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836705)
            
            //--TRIMMABLE-BOUNDARY-START(47244705889)
            /*void */ VisitObjectElement(/*JsonElement*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let isEmpty = true;
                var $en2 = element.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        isEmpty = false;
                        this.EnterContext(property.Name);
                        this.VisitValue(property.Value);
                        this.ExitContext();
                    }
                }
                this.SetNullIfElementIsEmpty(isEmpty);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705889)
            
            //--TRIMMABLE-BOUNDARY-START(42949738593)
            /*void */ VisitArrayElement(/*JsonElement*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = 0;
                var $en2 = element.EnumerateArray().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var arrayElement = $en2.Current;
                    {
                        this.EnterContext($.$$.System.Int32.ToString.call(index));
                        this.VisitValue(arrayElement);
                        this.ExitContext();
                        index++;
                    }
                }
                this.SetEmptyIfElementIsEmpty(index === 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42949738593)
            
            //--TRIMMABLE-BOUNDARY-START(38654771297)
            /*void */ SetNullIfElementIsEmpty(/*bool*/ isEmpty)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654771297)
            
            //--TRIMMABLE-BOUNDARY-START(34359804001)
            /*void */ SetEmptyIfElementIsEmpty(/*bool*/ isEmpty)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359804001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), $.$$.System.String.Empty);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359804001)
            
            //--TRIMMABLE-BOUNDARY-START(51539673185)
            /*void */ VisitValue(/*JsonElement*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._paths.Count > 0, "_paths.Count > 0");
                let $switch1 = value.ValueKind;
                switch($switch1)
                {
                    case 1/*JsonValueKind.Object*/:
                    this.VisitObjectElement(value);
                    break;
                    case 2/*JsonValueKind.Array*/:
                    this.VisitArrayElement(value);
                    break;
                    case 4/*JsonValueKind.Number*/:
                    case 3/*JsonValueKind.String*/:
                    case 5/*JsonValueKind.True*/:
                    case 6/*JsonValueKind.False*/:
                    case 7/*JsonValueKind.Null*/:
                    /*string*/ let key = this._paths.Peek();
                    if (this._data.ContainsKey(key))
                    {
                        throw new $.$$.System.FormatException().$ctor$12($.$mecj.System.SR.Format$6($.$mecj.System.SR.Error_KeyIsDuplicated, key));
                    }
                    this._data.set_Item(key, value.ValueKind === 7/*JsonValueKind.Null*/ ? null : $.$stj.System.Text.Json.JsonElement.ToString.call(value));
                    break;
                    default:
                    throw new $.$$.System.FormatException().$ctor$12($.$mecj.System.SR.Format$6($.$mecj.System.SR.Error_UnsupportedJSONToken, $.$box(value.ValueKind, $.$stj.System.Text.Json.JsonValueKind)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539673185)
            
            //--TRIMMABLE-BOUNDARY-START(17179934817)
            /*void */ EnterContext(/*string*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934817);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._paths.Push(this._paths.Count > 0 ? this._paths.Peek() + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + context : context);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17179934817)
            
            //--TRIMMABLE-BOUNDARY-START(21474902113)
            /*void */ ExitContext()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._paths.Pop();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902113)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295032929)
                this._data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(4295032929)
                
                //--TRIMMABLE-BOUNDARY-START(8590000225)
                this._paths = new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590000225)
                
            }
            static $h = 65633;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869409),
    {
      "r": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "p": [
        {
          "n": "input",
          "p": 94830593
        }
      ],
      "n": "Parse",
      "d": 65633,
      "h": 25769869409,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869409),
//--TRIMMABLE-BOUNDARY-START(30064836705),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "p": [
        {
          "n": "input",
          "p": 94830593
        }
      ],
      "n": "ParseStream",
      "d": 65633,
      "h": 30064836705,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30064836705),
//--TRIMMABLE-BOUNDARY-START(47244705889),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 2097236
        }
      ],
      "n": "VisitObjectElement",
      "d": 65633,
      "h": 47244705889,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244705889),
//--TRIMMABLE-BOUNDARY-START(42949738593),
    {
      "r": 65537,
      "p": [
        {
          "n": "element",
          "p": 2097236
        }
      ],
      "n": "VisitArrayElement",
      "d": 65633,
      "h": 42949738593,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42949738593),
//--TRIMMABLE-BOUNDARY-START(38654771297),
    {
      "r": 65537,
      "p": [
        {
          "n": "isEmpty",
          "p": 262145
        }
      ],
      "n": "SetNullIfElementIsEmpty",
      "d": 65633,
      "h": 38654771297,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38654771297),
//--TRIMMABLE-BOUNDARY-START(34359804001),
    {
      "r": 65537,
      "p": [
        {
          "n": "isEmpty",
          "p": 262145
        }
      ],
      "n": "SetEmptyIfElementIsEmpty",
      "d": 65633,
      "h": 34359804001,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359804001),
//--TRIMMABLE-BOUNDARY-START(51539673185),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 2097236
        }
      ],
      "n": "VisitValue",
      "d": 65633,
      "h": 51539673185,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539673185),
//--TRIMMABLE-BOUNDARY-START(17179934817),
    {
      "r": 65537,
      "p": [
        {
          "n": "context",
          "p": 1310721
        }
      ],
      "n": "EnterContext",
      "d": 65633,
      "h": 17179934817,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17179934817),
//--TRIMMABLE-BOUNDARY-START(21474902113),
    {
      "r": 65537,
      "n": "ExitContext",
      "d": 65633,
      "h": 21474902113,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21474902113)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032929),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_data",
      "d": 65633,
      "h": 4295032929,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032929),
//--TRIMMABLE-BOUNDARY-START(8590000225),
    {
      "t": $.$sc.System.Collections.Generic.Stack$$($.$$.System.String).$h,
      "n": "_paths",
      "d": 65633,
      "h": 8590000225,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000225)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967521),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65633,
      "h": 12884967521,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967521)
  ],
  "h": 65633
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65633)
        
        
        //--TRIMMABLE-BOUNDARY-START(196705)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource", ($self) => class JsonConfigurationSource extends $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource
        {
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590131297, 34359935074)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureDefaults(builder);
                return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590131297, 34359935074)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 196705;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196706,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590131297, 34359935074),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 196705,
      "h": 8590131297,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590131297, 34359935074)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164001),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196705,
      "h": 4295164001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164001)
  ],
  "i": [786526
  ],
  "h": 196705
}; }
            static get $b() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196705)
        
        
        //--TRIMMABLE-BOUNDARY-START(327777)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource", ($self) => class JsonStreamConfigurationSource extends $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationSource
        {
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590262369, 12886605919)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262369);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590262369, 12886605919)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 327777;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1704031,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590262369, 12886605919),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 327777,
      "h": 8590262369,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590262369, 12886605919)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295073),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327777,
      "h": 4295295073,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295073)
  ],
  "i": [786526
  ],
  "h": 327777
}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327777)
        
        
        //--TRIMMABLE-BOUNDARY-START(262241)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider", ($self) => class JsonStreamConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295229537)
            $ctor$3(/*JsonStreamConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229537)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590196833, 25771442271)
            /*void */ Load$1(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Data = $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser.Parse(stream);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590196833, 25771442271)
            
            static $h = 262241;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1638495,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590196833, 25771442271),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94830593
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 262241,
      "h": 8590196833,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590196833, 25771442271)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229537),
    {
      "p": [
        {
          "n": "source",
          "p": 327777
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262241,
      "h": 4295229537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229537)
  ],
  "i": [589918
  ],
  "h": 262241
}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262241)
        
        
        //--TRIMMABLE-BOUNDARY-START(131169)
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider", ($self) => class JsonConfigurationProvider extends $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4295098465)
            $ctor$3(/*JsonConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098465)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590065761, 47244771426)
            /*void */ Load$2(/*Stream*/ stream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Data = $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser.Parse(stream);
                }
                catch(e)
                {
                    throw new $.$$.System.FormatException().$ctor$11($.$mecj.System.SR.Error_JSONParseError, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590065761, 47244771426)
            
            static $h = 131169;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131170,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590065761, 47244771426),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94830593
        }
      ],
      "n": "Load",
      "o": "@$2",
      "d": 131169,
      "h": 8590065761,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590065761, 47244771426)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098465),
    {
      "p": [
        {
          "n": "source",
          "p": 196705
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131169,
      "h": 4295098465,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098465)
  ],
  "i": [589918,90177537
  ],
  "h": 131169
}; }
            static get $b() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131169)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.ComponentModel", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.FileExtensions", "NetJs.System.Threading.ThreadPool", "NetJs.System.IO.Pipelines", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"))
//--TRIMMABLE-BOUNDARY-END(97)
