
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $mep, $sr, $scc, $scn, $scm, $sipl, $so, $srn, $stew, $sris, $scp, $sfa, $sic, $sim, $sl, $snp, $sifw, $mefa, $mef, $sci, $srm, $sds, $sre, $sscr, $sle, $str, $mefp, $meca, $stj, $mec, $mecf) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration.Json", 
    {"h":17,"f":"Microsoft.Extensions.Configuration.Json","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.Configuration.Json.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Json","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration.Json","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser", ($self) => class JsonConfigurationFileParser extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Dictionary<string, string?>*/ _data = null;
            /*Stack<string>*/ _paths = null;
            static /*IDictionary<string, string?> */ Parse(/*Stream*/ input)
            {
                return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser().$ctor$1().ParseStream(input);
            }
            /*Dictionary<string, string?> */ ParseStream(/*Stream*/ input)
            {
                /*var*/ let jsonDocumentOptions = (() =>
                {
                    //new $.$stj.System.Text.Json.JsonDocumentOptions()
                    const $t1 = $.$stj.System.Text.Json.JsonDocumentOptions;
                    const $i1 = new $t1();
                    $i1.CommentHandling = 1/*JsonCommentHandling.Skip*/;
                    $i1.AllowTrailingCommas = true;
                    return $i1;
                })();
                let reader = null;
                try
                {
                    reader = new $.$spc.System.IO.StreamReader().$ctor$4(input);
                    let doc = null;
                    try
                    {
                        doc = $.$stj.System.Text.Json.JsonDocument.Parse$5(reader.ReadToEnd(), jsonDocumentOptions.Clone());
                        if (doc.RootElement.ValueKind !== 1/*JsonValueKind.Object*/)
                        {
                            throw new $.$spc.System.FormatException().$ctor$10($.$mecj.System.SR.Format($.$mecj.System.SR.Error_InvalidTopLevelJSONElement, $.$box(doc.RootElement.ValueKind, $.$stj.System.Text.Json.JsonValueKind)));
                        }
                        this.VisitObjectElement(doc.RootElement);
                    }
                    finally
                    {
                        doc?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    reader?.System$IDisposable$Dispose();
                }
                return this._data;
            }
            /*void */ VisitObjectElement(/*JsonElement*/ element)
            {
                /*var*/ let isEmpty = true;
                var $en2 = element.EnumerateObject().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        isEmpty = false;
                        this.EnterContext(property.Name);
                        this.VisitValue(property.Value);
                        this.ExitContext();
                    }
                }
                this.SetNullIfElementIsEmpty(isEmpty);
            }
            /*void */ VisitArrayElement(/*JsonElement*/ element)
            {
                /*int*/ let index = 0;
                var $en2 = element.EnumerateArray().GetEnumerator();
                while ($en2.MoveNext())
                {
                    var arrayElement = $en2.Current;
                    {
                        this.EnterContext($.$spc.System.Int32.ToString.call(index));
                        this.VisitValue(arrayElement);
                        this.ExitContext();
                        index++;
                    }
                }
                this.SetEmptyIfElementIsEmpty(index === 0);
            }
            /*void */ SetNullIfElementIsEmpty(/*bool*/ isEmpty)
            {
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), null);
                }
            }
            /*void */ SetEmptyIfElementIsEmpty(/*bool*/ isEmpty)
            {
                if (isEmpty && this._paths.Count > 0)
                {
                    this._data.set_Item(this._paths.Peek(), $.$spc.System.String.Empty);
                }
            }
            /*void */ VisitValue(/*JsonElement*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._paths.Count > 0, "_paths.Count > 0");
                let $switch1 = value.ValueKind;
                switch($switch1)
                {
                    case 1/*JsonValueKind.Object*/:
                    this.VisitObjectElement(value);
                    break;
                    case 2/*JsonValueKind.Array*/:
                    this.VisitArrayElement(value);
                    break;
                    case 4/*JsonValueKind.Number*/:
                    case 3/*JsonValueKind.String*/:
                    case 5/*JsonValueKind.True*/:
                    case 6/*JsonValueKind.False*/:
                    case 7/*JsonValueKind.Null*/:
                    /*string*/ let key = this._paths.Peek();
                    if (this._data.ContainsKey(key))
                    {
                        throw new $.$spc.System.FormatException().$ctor$10($.$mecj.System.SR.Format($.$mecj.System.SR.Error_KeyIsDuplicated, key));
                    }
                    this._data.set_Item(key, value.ValueKind === 7/*JsonValueKind.Null*/ ? null : $.$stj.System.Text.Json.JsonElement.ToString.call(value));
                    break;
                    default:
                    throw new $.$spc.System.FormatException().$ctor$10($.$mecj.System.SR.Format($.$mecj.System.SR.Error_UnsupportedJSONToken, $.$box(value.ValueKind, $.$stj.System.Text.Json.JsonValueKind)));
                }
            }
            /*void */ EnterContext(/*string*/ context)
            {
                return this._paths.Push(this._paths.Count > 0 ? this._paths.Peek() + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + context : context);
            }
            /*void */ ExitContext()
            {
                return this._paths.Pop();
            }
            //default member initializer
            constructor()
            {
                super();
                this._data = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                this._paths = new ($.$sc.System.Collections.Generic.Stack$$($.$spc.System.String))().$ctor$1();
            }
            static $h = 65553;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"p":[{"n":"input","p":62128129}],"n":"Parse","d":65553,"h":17179934737,"f":33},{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"p":[{"n":"input","p":62128129}],"n":"ParseStream","d":65553,"h":21474902033,"f":2},{"r":65537,"p":[{"n":"element","p":2156999}],"n":"VisitObjectElement","d":65553,"h":25769869329,"f":2},{"r":65537,"p":[{"n":"element","p":2156999}],"n":"VisitArrayElement","d":65553,"h":30064836625,"f":2},{"r":65537,"p":[{"n":"isEmpty","p":262145}],"n":"SetNullIfElementIsEmpty","d":65553,"h":34359803921,"f":2},{"r":65537,"p":[{"n":"isEmpty","p":262145}],"n":"SetEmptyIfElementIsEmpty","d":65553,"h":38654771217,"f":2},{"r":65537,"p":[{"n":"value","p":2156999}],"n":"VisitValue","d":65553,"h":42949738513,"f":2},{"r":65537,"p":[{"n":"context","p":1310721}],"n":"EnterContext","d":65553,"h":47244705809,"f":2},{"r":65537,"n":"ExitContext","d":65553,"h":51539673105,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"n":"_data","d":65553,"h":8590000145,"f":2},{"t":$.$sc.System.Collections.Generic.Stack$$($.$spc.System.String).$h,"n":"_paths","d":65553,"h":12884967441,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":65553,"h":4295032849,"f":2}],"h":65553}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser`; }
        });
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions", ($self) => class JsonConfigurationExtensions
        {
            static /*IConfigurationBuilder */ AddJsonFile(/*this IConfigurationBuilder*/ builder, /*string*/ path)
            {
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$3(builder, null, path, false, false);
            }
            static /*IConfigurationBuilder */ AddJsonFile$1(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional)
            {
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$3(builder, null, path, optional, false);
            }
            static /*IConfigurationBuilder */ AddJsonFile$2(/*this IConfigurationBuilder*/ builder, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$3(builder, null, path, optional, reloadOnChange);
            }
            static /*IConfigurationBuilder */ AddJsonFile$3(/*this IConfigurationBuilder*/ builder, /*IFileProvider?*/ provider, /*string*/ path, /*bool*/ optional, /*bool*/ reloadOnChange)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                if ($.$spc.System.String.IsNullOrEmpty(path))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$mecj.System.SR.Error_InvalidFilePath, "path");
                }
                return $.$mecj.Microsoft.Extensions.Configuration.JsonConfigurationExtensions.AddJsonFile$4(builder, new ($.$spc.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    s.FileProvider = provider;
                    s.Path = path;
                    s.Optional = optional;
                    s.ReloadOnChange = reloadOnChange;
                    s.ResolveFileProvider();
                }));
            }
            static /*IConfigurationBuilder */ AddJsonFile$4(/*this IConfigurationBuilder*/ builder, /*Action<JsonConfigurationSource>?*/ configureSource)
            {
                return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource, builder, configureSource);
            }
            static /*IConfigurationBuilder */ AddJsonStream(/*this IConfigurationBuilder*/ builder, /*Stream*/ stream)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                return $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.Add($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource, builder, new ($.$spc.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource))().$ctor(this,  (/*s*/ s) =>
                {
                    return s.Stream = stream;
                }));
            }
            static $h = 393233;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"builder","p":327694},{"n":"path","p":1310721}],"n":"AddJsonFile","d":393233,"h":4295360529,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"path","p":1310721},{"n":"optional","p":262145}],"n":"AddJsonFile","o":"@$1","d":393233,"h":8590327825,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"path","p":1310721},{"n":"optional","p":262145},{"n":"reloadOnChange","p":262145}],"n":"AddJsonFile","o":"@$2","d":393233,"h":12885295121,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"provider","p":262170},{"n":"path","p":1310721},{"n":"optional","p":262145},{"n":"reloadOnChange","p":262145}],"n":"AddJsonFile","o":"@$3","d":393233,"h":17180262417,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"configureSource","p":$.$spc.System.Action$$($.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource).$h}],"n":"AddJsonFile","o":"@$4","d":393233,"h":21475229713,"f":33},{"r":327694,"p":[{"n":"builder","p":327694},{"n":"stream","p":62128129}],"n":"AddJsonStream","d":393233,"h":25770197009,"f":33}],"h":393233}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.JsonConfigurationExtensions`; }
        });
        
        $asm.$cls("$mecj.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mecj.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration.Json", $.$mecj.System.SR.$type.Assembly);
                    $.$mecj.System.SR.s_resourceManager = temp;
                }
                return $.$mecj.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mecj.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mecj.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_InvalidFilePath()
            {
                return "File path must be a non-empty string.";
            }
            static /*string */ get Error_InvalidTopLevelJSONElement()
            {
                return "Top-level JSON element must be an object. Instead, '{0}' was found.";
            }
            static /*string */ FormatError_InvalidTopLevelJSONElement(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Top-level JSON element must be an object. Instead, '{0}' was found.", arg1);
            }
            static /*string */ get Error_JSONParseError()
            {
                return "Could not parse the JSON file.";
            }
            static /*string */ get Error_KeyIsDuplicated()
            {
                return "A duplicate key '{0}' was found.";
            }
            static /*string */ FormatError_KeyIsDuplicated(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A duplicate key '{0}' was found.", arg1);
            }
            static /*string */ get Error_UnsupportedJSONToken()
            {
                return "Unsupported JSON token '{0}' was found.";
            }
            static /*string */ FormatError_UnsupportedJSONToken(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unsupported JSON token '{0}' was found.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mecj.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mecj.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mecj.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mecj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mecj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mecj.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 458769;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":458769}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource", ($self) => class JsonStreamConfigurationSource extends $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationSource
        {
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider().$ctor$3(this);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 327697;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1441805,"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":327697,"h":4295294993,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":327697,"h":8590262289,"f":1}],"i":[655374],"h":327697}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationSource`; }
        });
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationSource", ($self) => class JsonConfigurationSource extends $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource
        {
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                this.EnsureDefaults(builder);
                return new $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider().$ctor$3(this);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 196625;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196624,"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":196625,"h":4295163921,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":196625,"h":8590131217,"f":1}],"i":[655374],"h":196625}; }
            static get $b() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationSource`; }
        });
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider", ($self) => class JsonStreamConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationProvider
        {
            $ctor$3(/*JsonStreamConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                }
                return this;
            }
            /*void */ Load$1(/*Stream*/ stream)
            {
                this.Data = $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser.Parse(stream);
            }
            static $h = 262161;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1376269,"m":[{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"Load","o":"@$1","d":262161,"h":8590196753,"f":32769}],"c":[{"p":[{"n":"source","p":327697}],"n":".ctor","o":"$ctor$3","d":262161,"h":4295229457,"f":1}],"i":[458766],"h":262161}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.StreamConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonStreamConfigurationProvider`; }
        });
        
        $asm.$cls("$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider", ($self) => class JsonConfigurationProvider extends $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider
        {
            $ctor$3(/*JsonConfigurationSource*/ source)
            {
                super.$ctor$2(source);
                {
                }
                return this;
            }
            /*void */ Load$2(/*Stream*/ stream)
            {
                try
                {
                    this.Data = $.$mecj.Microsoft.Extensions.Configuration.Json.JsonConfigurationFileParser.Parse(stream);
                }
                catch(e)
                {
                    throw new $.$spc.System.FormatException().$ctor$11($.$mecj.System.SR.Error_JSONParseError, e);
                }
            }
            static $h = 131089;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131088,"m":[{"r":65537,"p":[{"n":"stream","p":62128129}],"n":"Load","o":"@$2","d":131089,"h":8590065681,"f":32769}],"c":[{"p":[{"n":"source","p":196625}],"n":".ctor","o":"$ctor$3","d":131089,"h":4295098385,"f":1}],"i":[458766,57475073],"h":131089}; }
            static get $b() { return $.$mecf.Microsoft.Extensions.Configuration.FileConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Json.JsonConfigurationProvider`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.IO.Pipelines", "NetJs.System.ObjectModel", "NetJs.System.Runtime.Numerics", "NetJs.System.Text.Encodings.Web", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.Microsoft.Extensions.FileProviders.Physical", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.System.Text.Json", "NetJs.Microsoft.Extensions.Configuration", "NetJs.Microsoft.Extensions.Configuration.FileExtensions"))