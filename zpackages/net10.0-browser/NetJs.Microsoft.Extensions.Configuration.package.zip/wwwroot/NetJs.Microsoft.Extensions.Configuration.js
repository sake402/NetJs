
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration", 
    {"h":13,"f":"Microsoft.Extensions.Configuration","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Configuration","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.Configuration.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationProvider", ($self) => class ConfigurationProvider extends $.$$.System.Object
        {
            /*ConfigurationReloadToken*/ _reloadToken = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.Data = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            /*IDictionary<string, string?>*/ Data = null;
            /*bool */ TryGet(/*string*/ key, /*out string?*/ value)
            {
                return this.Data.System$Collections$Generic$IDictionary$$$$TryGetValue(key, value, [$.$$.System.String, $.$$.System.String]);
            }
            /*void */ Set(/*string*/ key, /*string?*/ value)
            {
                let $t1;
                return this.Data.System$Collections$Generic$IDictionary$$$$set_Item(key, $t1 = (value), [$.$$.System.String, $.$$.System.String]), $t1;
            }
            /*void */ Load()
            {
            }
            /*IEnumerable<string> */ GetChildKeys(/*IEnumerable<string>*/ earlierKeys, /*string?*/ parentPath)
            {
                /*var*/ let results = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                if (parentPath === null)
                {
                    var $en3 = this.Data.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kv = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            results.Add($.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider.Segment(kv.Key, 0));
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Equality($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, ":"), "ConfigurationPath.KeyDelimiter == \":\"");
                    var $en3 = this.Data.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kv = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (kv.Key.length > parentPath.length && $.$$.System.String.StartsWith$2.call(kv.Key, parentPath, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.String.get_Chars.call(kv.Key, parentPath.length) === /*:*/ 58)
                            {
                                results.Add($.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider.Segment(kv.Key, ((parentPath.length + 1) | 0)));
                            }
                        }
                    }
                }
                results.AddRange(earlierKeys);
                results.Sort$2($.$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer.Comparison);
                return results;
            }
            static /*string */ Segment(/*string*/ key, /*int*/ prefixLength)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Equality($.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter, ":"), "ConfigurationPath.KeyDelimiter == \":\"");
                /*int*/ let indexOf = $.$$.System.String.IndexOf$1.call(key, /*:*/ 58, prefixLength);
                return indexOf < 0 ? $.$$.System.String.Substring$1.call(key, prefixLength) : $.$$.System.String.Substring.call(key, prefixLength, ((indexOf - prefixLength) | 0));
            }
            /*IChangeToken */ GetReloadToken()
            {
                return this._reloadToken;
            }
            /*void */ OnReload()
            {
                /*ConfigurationReloadToken*/ let previousToken = $.$$.System.Threading.Interlocked.Exchange$14($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, $.$ref(() => this._reloadToken, ($v) => this._reloadToken = $v, $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken), new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$$.System.Object.GetType.call(this).Name;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider.ToString.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.TryGet(string, out string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet()
            {
                return this.TryGet(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Set(string, string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$Set()
            {
                return this.Set(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken()
            {
                return this.GetReloadToken(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Load()
            Microsoft$Extensions$Configuration$IConfigurationProvider$Load()
            {
                return this.Load(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetChildKeys(System.Collections.Generic.IEnumerable<string>, string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys()
            {
                return this.GetChildKeys(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._reloadToken = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1();
            }
            static $h = 589837;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":21475426317,"f":50331652},"s":{"r":0,"d":0,"h":25770393613,"f":83886084},"n":"Data","d":589837,"h":17180459021,"f":2097156}],"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721,"f":2}],"n":"TryGet","d":589837,"h":30065360909,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Set","d":589837,"h":34360328205,"f":16777345},{"r":65537,"n":"Load","d":589837,"h":38655295501,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"p":[{"n":"earlierKeys","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h},{"n":"parentPath","p":1310721}],"n":"GetChildKeys","d":589837,"h":42950262797,"f":16777345},{"r":1310721,"p":[{"n":"key","p":1310721},{"n":"prefixLength","p":655361}],"n":"Segment","d":589837,"h":47245230093,"f":16777250},{"r":720898,"n":"GetReloadToken","d":589837,"h":51540197389,"f":16777217},{"r":65537,"n":"OnReload","d":589837,"h":55835164685,"f":16777220},{"r":1310721,"n":"ToString","d":589837,"h":60130131981,"f":16809985}],"l":[{"t":655373,"n":"_reloadToken","d":589837,"h":4295557133,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":589837,"h":8590524429,"f":16777220}],"i":[458766],"h":589837}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationProvider`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders", ($self) => class ReferenceCountedProviders extends $.$$.System.Object
        {
            static /*ReferenceCountedProviders */ Create(/*List<IConfigurationProvider>*/ providers)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.ActiveReferenceCountedProviders().$ctor$2(providers);
            }
            static /*ReferenceCountedProviders */ CreateDisposed(/*List<IConfigurationProvider>*/ providers)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.DisposedReferenceCountedProviders().$ctor$2(providers);
            }
            static $_ActiveReferenceCountedProviders;
            static get ActiveReferenceCountedProviders()
            {
                let $cls = $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders;
                return $cls.$_ActiveReferenceCountedProviders ??= $asm.$ncls("$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.ActiveReferenceCountedProviders", ($self) => class ActiveReferenceCountedProviders extends $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders
                {
                    /*long*/ _refCount = 1n;
                    /*List<IConfigurationProvider>*/ _providers = null;
                    $ctor$2(/*List<IConfigurationProvider>*/ providers)
                    {
                        super.$ctor$1();
                        {
                            this._providers = providers;
                        }
                        return this;
                    }
                    /*List<IConfigurationProvider> */ get Providers()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._refCount > 0n, "_refCount > 0");
                        return this._providers;
                    }
                    /*List<IConfigurationProvider> */ set Providers(value)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._refCount > 0n, "_refCount > 0");
                        this._providers = value;
                    }
                    /*List<IConfigurationProvider> */ get NonReferenceCountedProviders()
                    {
                        return this._providers;
                    }
                    /*void */ AddReference()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._refCount > 0n, "_refCount > 0");
                        $.$$.System.Threading.Interlocked.Increment$1($.$ref(() => this._refCount, ($v) => this._refCount = $v, $.$$.System.Int64));
                    }
                    /*void */ Dispose()
                    {
                        if ($.$$.System.Threading.Interlocked.Decrement$1($.$ref(() => this._refCount, ($v) => this._refCount = $v, $.$$.System.Int64)) === 0n)
                        {
                            var $en5 = this._providers.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var provider = $en5.Current;
                                {
                                    ($.$as(provider, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                                }
                            }
                        }
                    }
                    static $h = 1245197;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1179661,"p":[{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":21476081677,"f":50364417},"s":{"r":0,"d":0,"h":25771048973,"f":83918849},"n":"Providers","d":1245197,"h":17181114381,"f":2129921},{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":34360983565,"f":50364417},"n":"NonReferenceCountedProviders","d":1245197,"h":30066016269,"f":2129921}],"m":[{"r":65537,"n":"AddReference","d":1245197,"h":38655950861,"f":16809985},{"r":65537,"n":"Dispose","d":1245197,"h":42950918157,"f":16809985}],"l":[{"t":917505,"n":"_refCount","d":1245197,"h":4296212493,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"n":"_providers","d":1245197,"h":8591179789,"f":4194306}],"c":[{"p":[{"n":"providers","p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":".ctor","o":"$ctor$2","d":1245197,"h":12886147085,"f":16777217}],"i":[57540609],"d":1179661,"h":1245197}; }
                    static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Configuration.ReferenceCountedProviders.ActiveReferenceCountedProviders`; }
                }, $cls, ($v) => $cls.$_ActiveReferenceCountedProviders = $v);
            }
            static $_DisposedReferenceCountedProviders;
            static get DisposedReferenceCountedProviders()
            {
                let $cls = $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders;
                return $cls.$_DisposedReferenceCountedProviders ??= $asm.$ncls("$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.DisposedReferenceCountedProviders", ($self) => class DisposedReferenceCountedProviders extends $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders
                {
                    $ctor$2(/*List<IConfigurationProvider>*/ providers)
                    {
                        super.$ctor$1();
                        {
                            this.Providers = providers;
                        }
                        return this;
                    }
                    /*List<IConfigurationProvider>*/ Providers = null;
                    /*List<IConfigurationProvider> */ get NonReferenceCountedProviders()
                    {
                        return this.Providers;
                    }
                    /*void */ AddReference()
                    {
                    }
                    /*void */ Dispose()
                    {
                    }
                    static $h = 1310733;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1179661,"p":[{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":17181179917,"f":50364417},"s":{"r":0,"d":0,"h":21476147213,"f":83918849},"n":"Providers","d":1310733,"h":12886212621,"f":2129921},{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":30066081805,"f":50364417},"n":"NonReferenceCountedProviders","d":1310733,"h":25771114509,"f":2129921}],"m":[{"r":65537,"n":"AddReference","d":1310733,"h":34361049101,"f":16809985},{"r":65537,"n":"Dispose","d":1310733,"h":38656016397,"f":16809985}],"c":[{"p":[{"n":"providers","p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":".ctor","o":"$ctor$2","d":1310733,"h":4296278029,"f":16777217}],"i":[57540609],"d":1179661,"h":1310733}; }
                    static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Configuration.ReferenceCountedProviders.DisposedReferenceCountedProviders`; }
                }, $cls, ($v) => $cls.$_DisposedReferenceCountedProviders = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1179661;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":17181048845,"f":50331905},"s":{"r":0,"d":0,"h":21476016141,"f":83886337},"n":"Providers","d":1179661,"h":12886081549,"f":2097409},{"p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":30065950733,"f":50331905},"n":"NonReferenceCountedProviders","d":1179661,"h":25770983437,"f":2097409}],"m":[{"r":1179661,"p":[{"n":"providers","p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":"Create","d":1179661,"h":4296146957,"f":16777249},{"r":1179661,"p":[{"n":"providers","p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":"CreateDisposed","d":1179661,"h":8591114253,"f":16777249},{"r":65537,"n":"AddReference","d":1179661,"h":34360918029,"f":16777473},{"r":65537,"n":"Dispose","d":1179661,"h":38655885325,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":1179661,"h":51540787213,"f":16777220}],"i":[57540609],"j":[1245197,1310733],"h":1179661}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ReferenceCountedProviders`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.StreamConfigurationSource", ($self) => class StreamConfigurationSource extends $.$$.System.Object
        {
            /*Stream?*/ Stream = null;
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1441805;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":12886343693,"f":50331649},"s":{"r":0,"d":0,"h":17181310989,"f":83886081},"n":"Stream","d":1441805,"h":8591376397,"f":2097153}],"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":1441805,"h":21476278285,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":1441805,"h":25771245581,"f":16777220}],"i":[655374],"h":1441805}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.StreamConfigurationSource`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.StreamConfigurationProvider", ($self) => class StreamConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider
        {
            /*StreamConfigurationSource*/ Source = null;
            /*bool*/ _loaded = false;
            $ctor$2(/*StreamConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this.Source = source;
                }
                return this;
            }
            /*void */ Load()
            {
                if (this._loaded)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mec.System.SR.StreamConfigurationProvidersAlreadyLoaded);
                }
                if (this.Source.Stream === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mec.System.SR.StreamConfigurationSourceStreamCannotBeNull);
                }
                this.Load$1(this.Source.Stream);
                this._loaded = true;
            }
            static $h = 1376269;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589837,"p":[{"p":1441805,"g":{"r":0,"d":0,"h":12886278157,"f":50331649},"n":"Source","d":1376269,"h":8591310861,"f":2097153}],"m":[{"r":65537,"p":[{"n":"stream","p":62193665}],"n":"Load","o":"@$1","d":1376269,"h":25771180045,"f":16777473},{"r":65537,"n":"Load","d":1376269,"h":30066147341,"f":16809985}],"l":[{"t":262145,"n":"_loaded","d":1376269,"h":17181245453,"f":4194306}],"c":[{"p":[{"n":"source","p":1441805}],"n":".ctor","o":"$ctor$2","d":1376269,"h":21476212749,"f":16777217}],"i":[458766],"h":1376269}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.StreamConfigurationProvider`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ChainedBuilderExtensions", ($self) => class ChainedBuilderExtensions
        {
            static /*IConfigurationBuilder */ AddConfiguration$1(/*this IConfigurationBuilder*/ configurationBuilder, /*IConfiguration*/ config)
            {
                return $.$mec.Microsoft.Extensions.Configuration.ChainedBuilderExtensions.AddConfiguration(configurationBuilder, config, false);
            }
            static /*IConfigurationBuilder */ AddConfiguration(/*this IConfigurationBuilder*/ configurationBuilder, /*IConfiguration*/ config, /*bool*/ shouldDisposeConfiguration)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(config, "config");
                configurationBuilder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Add((() =>
                {
                    //new $.$mec.Microsoft.Extensions.Configuration.ChainedConfigurationSource()
                    const $t1 = $.$mec.Microsoft.Extensions.Configuration.ChainedConfigurationSource;
                    const $i1 = new $t1();
                    $i1.Configuration = config;
                    $i1.ShouldDisposeConfiguration = shouldDisposeConfiguration;
                    return $i1;
                })());
                return configurationBuilder;
            }
            static $h = 65549;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"configurationBuilder","p":327694},{"n":"config","p":262158}],"n":"AddConfiguration","o":"@$1","d":65549,"h":4295032845,"f":16777249},{"r":327694,"p":[{"n":"configurationBuilder","p":327694},{"n":"config","p":262158},{"n":"shouldDisposeConfiguration","p":262145}],"n":"AddConfiguration","d":65549,"h":8590000141,"f":16777249}],"h":65549}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ChainedBuilderExtensions`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Internal.ChangeCallbackRegistrar", ($self) => class ChangeCallbackRegistrar
        {
            static /*IDisposable */ UnsafeRegisterChangeCallback(T, /*Action<object?>*/ callback, /*object?*/ state, /*CancellationToken*/ token, /*Action<T>*/ onFailure, /*T*/ onFailureState)
            {
                try
                {
                    return token.UnsafeRegister$1(callback, state);
                }
                catch($e)
                {
                    onFailure.Invoke(onFailureState);
                }
                return $.$mec.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
            }
            static $h = 1572877;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57540609,"p":[{"n":"callback","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073},{"n":"token","p":125829121},{"n":"onFailure","p":(T) => $.$$.System.Action$$(T).$h},{"n":"onFailureState","p":(T) => T.$h}],"g":["T"],"n":"UnsafeRegisterChangeCallback","d":1572877,"h":4296540173,"f":16908328}],"h":1572877}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ChangeCallbackRegistrar`; }
        });
        
        $asm.$cls("$mec.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mec.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration", $.$mec.System.SR.$type.Assembly);
                    $.$mec.System.SR.s_resourceManager = temp;
                }
                return $.$mec.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mec.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mec.System.SR.resourceCulture = value;
            }
            static /*string */ get Error_NoSources()
            {
                return "A configuration source is not registered. Please register one before setting a value.";
            }
            static /*string */ get InvalidNullArgument()
            {
                return "Null is not a valid value for '{0}'.";
            }
            static /*string */ FormatInvalidNullArgument(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Null is not a valid value for '{0}'.", arg1);
            }
            static /*string */ get StreamConfigurationProvidersAlreadyLoaded()
            {
                return "StreamConfigurationProviders cannot be loaded more than once.";
            }
            static /*string */ get StreamConfigurationSourceStreamCannotBeNull()
            {
                return "Source.Stream cannot be null.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mec.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mec.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mec.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mec.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mec.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mec.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mec.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1638413;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1638413}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.MemoryConfigurationBuilderExtensions", ($self) => class MemoryConfigurationBuilderExtensions
        {
            static /*IConfigurationBuilder */ AddInMemoryCollection$1(/*this IConfigurationBuilder*/ configurationBuilder)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                configurationBuilder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Add(new $.$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource().$ctor$1());
                return configurationBuilder;
            }
            static /*IConfigurationBuilder */ AddInMemoryCollection(/*this IConfigurationBuilder*/ configurationBuilder, /*IEnumerable<KeyValuePair<string, string?>>?*/ initialData)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                configurationBuilder.Microsoft$Extensions$Configuration$IConfigurationBuilder$Add((() =>
                {
                    //new $.$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource()
                    const $t1 = $.$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource;
                    const $i1 = new $t1();
                    $i1.InitialData = initialData;
                    return $i1;
                })());
                return configurationBuilder;
            }
            static $h = 1048589;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":327694,"p":[{"n":"configurationBuilder","p":327694}],"n":"AddInMemoryCollection","o":"@$1","d":1048589,"h":4296015885,"f":16777249},{"r":327694,"p":[{"n":"configurationBuilder","p":327694},{"n":"initialData","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h}],"n":"AddInMemoryCollection","d":1048589,"h":8590983181,"f":16777249}],"h":1048589}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.MemoryConfigurationBuilderExtensions`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions", ($self) => class InternalConfigurationRootExtensions
        {
            static /*IEnumerable<IConfigurationSection> */ GetChildrenImplementation(/*this IConfigurationRoot*/ root, /*string?*/ path)
            {
                /*ReferenceCountedProviders?*/ let reference = (($.$as(root, $.$mec.Microsoft.Extensions.Configuration.ConfigurationManager))?.GetProvidersReference() ?? null);
                try
                {
                    /*IEnumerable<IConfigurationProvider>*/ let providers = (reference?.Providers ?? null) ?? root.Microsoft$Extensions$Configuration$IConfigurationRoot$Providers;
                    /*IEnumerable<IConfigurationSection>*/ let children = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.String, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, $.$sl.System.Linq.Enumerable.Distinct($.$$.System.String, $.$sl.System.Linq.Enumerable.Aggregate$1($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String), providers, $.$sl.System.Linq.Enumerable.Empty($.$$.System.String), new ($.$$.System.Func$$$$($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String), $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String)))().$ctor(this,  (/*seed*/ seed, /*source*/ source) =>
                    {
                        return source.Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys(seed, path);
                    }, {"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"p":[{"n":"seed","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h},{"n":"source","p":458766}],"n":"","d":851981,"h":0,"f":17825794})), $.$$.System.StringComparer.OrdinalIgnoreCase), new ($.$$.System.Func$$$($.$$.System.String, $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection))().$ctor(this,  (/*key*/ key) =>
                    {
                        return root.Microsoft$Extensions$Configuration$IConfiguration$GetSection($.$$.System.String.op_Equality(path, null) ? key : path + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + key);
                    }, {"r":589838,"p":[{"n":"key","p":1310721}],"n":"","d":851981,"h":0,"f":17825794}));
                    if (reference === null)
                    {
                        return children;
                    }
                    else 
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, children);
                    }
                }
                finally
                {
                    reference?.System$IDisposable$Dispose();
                }
            }
            static /*bool */ TryGetConfiguration(/*this IConfigurationRoot*/ root, /*string*/ key, /*out string?*/ value)
            {
                let list;
                /*IList<IConfigurationProvider>*/ let providers = $.$is(root.Microsoft$Extensions$Configuration$IConfigurationRoot$Providers, $.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider), { set $v(v){ list = v; } }) ? list : $.$sl.System.Linq.Enumerable.ToList($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, root.Microsoft$Extensions$Configuration$IConfigurationRoot$Providers);
                for(/*int*/ let i = ((providers.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*IConfigurationProvider*/ let provider = providers.System$Collections$Generic$IList$$$get_Item(i, [$.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider]);
                    try
                    {
                        if (provider.Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet(key, value))
                        {
                            return true;
                        }
                    }
                    catch($e)
                    {
                    }
                }
                value.$v = null;
                return false;
            }
            static $h = 851981;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,"p":[{"n":"root","p":524302},{"n":"path","p":1310721}],"n":"GetChildrenImplementation","d":851981,"h":4295819277,"f":16777256},{"r":262145,"p":[{"n":"root","p":524302},{"n":"key","p":1310721},{"n":"value","p":1310721,"f":2}],"n":"TryGetConfiguration","d":851981,"h":8590786573,"f":16777256}],"h":851981}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ChainedConfigurationSource", ($self) => class ChainedConfigurationSource extends $.$$.System.Object
        {
            /*IConfiguration?*/ Configuration = null;
            /*bool*/ ShouldDisposeConfiguration = false;
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ChainedConfigurationProvider().$ctor$1(this);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ShouldDisposeConfiguration = false;
            }
            static $h = 196621;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262158,"g":{"r":0,"d":0,"h":12885098509,"f":50331649},"s":{"r":0,"d":0,"h":17180065805,"f":83886081},"n":"Configuration","d":196621,"h":8590131213,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30064967693,"f":50331649},"s":{"r":0,"d":0,"h":34359934989,"f":83886081},"n":"ShouldDisposeConfiguration","d":196621,"h":25770000397,"f":2097153}],"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":196621,"h":38654902285,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":196621,"h":42949869581,"f":16777217}],"i":[655374],"h":196621}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ChainedConfigurationSource`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$$.System.Object
        {
            /*EmptyDisposable*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mec.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            static $h = 1507341;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1507341,"g":{"r":0,"d":0,"h":12886409229,"f":50331681},"n":"Instance","d":1507341,"h":8591441933,"f":2097185}],"m":[{"r":65537,"n":"Dispose","d":1507341,"h":21476343821,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":1507341,"h":17181376525,"f":16777218}],"i":[57540609],"h":1507341}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource", ($self) => class MemoryConfigurationSource extends $.$$.System.Object
        {
            /*IEnumerable<KeyValuePair<string, string?>>?*/ InitialData = null;
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationProvider().$ctor$2(this);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            Microsoft$Extensions$Configuration$IConfigurationSource$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 983053;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,"g":{"r":0,"d":0,"h":12885884941,"f":50331649},"s":{"r":0,"d":0,"h":17180852237,"f":83886081},"n":"InitialData","d":983053,"h":8590917645,"f":2097153}],"m":[{"r":458766,"p":[{"n":"builder","p":327694}],"n":"Build","d":983053,"h":21475819533,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":983053,"h":25770786829,"f":16777217}],"i":[655374],"h":983053}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSource ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviderManager", ($self) => class ReferenceCountedProviderManager extends $.$$.System.Object
        {
            /*object*/ _replaceProvidersLock = null;
            /*ReferenceCountedProviders*/ _refCountedProviders = null;
            /*bool*/ _disposed = false;
            /*IEnumerable<IConfigurationProvider> */ get NonReferenceCountedProviders()
            {
                return this._refCountedProviders.NonReferenceCountedProviders;
            }
            /*ReferenceCountedProviders */ GetReference()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            return $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.CreateDisposed(this._refCountedProviders.NonReferenceCountedProviders);
                        }
                        this._refCountedProviders.AddReference();
                        return this._refCountedProviders;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._replaceProvidersLock)
                }
            }
            /*void */ ReplaceProviders(/*List<IConfigurationProvider>*/ providers)
            {
                /*ReferenceCountedProviders*/ let oldRefCountedProviders = this._refCountedProviders;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            throw new $.$$.System.ObjectDisposedException().$ctor$17("ConfigurationManager");
                        }
                        this._refCountedProviders = $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.Create(providers);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._replaceProvidersLock)
                }
                oldRefCountedProviders.Dispose();
            }
            /*void */ AddProvider(/*IConfigurationProvider*/ provider)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            throw new $.$$.System.ObjectDisposedException().$ctor$17("ConfigurationManager");
                        }
                        this._refCountedProviders.Providers = (() =>
                        {
                            //new $.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider)()
                            const $t1 = $.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider);
                            const $i1 = new $t1();
                            $i1.$ctor$2(this._refCountedProviders.Providers);
                            $i1.Add(provider);
                            return $i1;
                        })();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._replaceProvidersLock)
                }
            }
            /*void */ Dispose()
            {
                /*ReferenceCountedProviders*/ let oldRefCountedProviders = this._refCountedProviders;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        this._disposed = true;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._replaceProvidersLock)
                }
                oldRefCountedProviders.Dispose();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._replaceProvidersLock = new $.$$.System.Object().$ctor();
                this._refCountedProviders = $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviders.Create(new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1());
            }
            static $h = 1114125;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":21475950605,"f":50331649},"n":"NonReferenceCountedProviders","d":1114125,"h":17180983309,"f":2097153}],"m":[{"r":1179661,"n":"GetReference","d":1114125,"h":25770917901,"f":16777217},{"r":65537,"p":[{"n":"providers","p":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":"ReplaceProviders","d":1114125,"h":30065885197,"f":16777217},{"r":65537,"p":[{"n":"provider","p":458766}],"n":"AddProvider","d":1114125,"h":34360852493,"f":16777217},{"r":65537,"n":"Dispose","d":1114125,"h":38655819789,"f":16777217}],"l":[{"t":131073,"n":"_replaceProvidersLock","d":1114125,"h":4296081421,"f":4194306},{"t":1179661,"n":"_refCountedProviders","d":1114125,"h":8591048717,"f":4194306},{"t":262145,"n":"_disposed","d":1114125,"h":12886016013,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1114125,"h":42950787085,"f":16777217}],"i":[57540609],"h":1114125}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ReferenceCountedProviderManager`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationBuilder", ($self) => class ConfigurationBuilder extends $.$$.System.Object
        {
            /*List<IConfigurationSource>*/ _sources = null;
            /*IList<IConfigurationSource> */ get Sources()
            {
                return this._sources;
            }
            /*IDictionary<string, object>*/ Properties = null;
            /*IConfigurationBuilder */ Add(/*IConfigurationSource*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                return this;
            }
            /*IConfigurationRoot */ Build()
            {
                /*var*/ let providers = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1();
                var $en2 = this._sources.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var source = $en2.Current;
                    {
                        /*IConfigurationProvider*/ let provider = source.Microsoft$Extensions$Configuration$IConfigurationSource$Build(this);
                        providers.Add(provider);
                    }
                }
                return new $.$mec.Microsoft.Extensions.Configuration.ConfigurationRoot().$ctor$1(providers);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Properties.get
            get Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties()
            {
                return this.Properties;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Sources.get
            get Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources()
            {
                return this.Sources;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Build()
            Microsoft$Extensions$Configuration$IConfigurationBuilder$Build()
            {
                return this.Build(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._sources = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1();
                this.Properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
            }
            static $h = 262157;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"g":{"r":0,"d":0,"h":12885164045,"f":50331649},"n":"Sources","d":262157,"h":8590196749,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":25770065933,"f":50331649},"n":"Properties","d":262157,"h":21475098637,"f":2097153}],"m":[{"r":327694,"p":[{"n":"source","p":655374}],"n":"Add","d":262157,"h":30065033229,"f":16777217},{"r":524302,"n":"Build","d":262157,"h":34360000525,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"n":"_sources","d":262157,"h":4295229453,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":262157,"h":38654967821,"f":16777217}],"i":[327694],"h":262157}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationBuilder`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken", ($self) => class ConfigurationReloadToken extends $.$$.System.Object
        {
            /*CancellationTokenSource*/ _cts = null;
            /*bool*/ ActiveChangeCallbacks = false;
            /*bool */ get HasChanged()
            {
                return this._cts.IsCancellationRequested;
            }
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                return $.$mec.Microsoft.Extensions.Internal.ChangeCallbackRegistrar.UnsafeRegisterChangeCallback($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, callback, state, this._cts.Token, new ($.$$.System.Action$$($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken))().$ctor($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, /*static*/ (/**/ s) =>
                {
                    return s.ActiveChangeCallbacks = false;
                }, {"r":65537,"p":[{"n":"s","p":655373}],"n":"","d":655373,"h":0,"f":17825826}), this);
            }
            /*void */ OnReload()
            {
                return this._cts.Cancel();
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._cts = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                this.ActiveChangeCallbacks = true;
            }
            static $h = 655373;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180524557,"f":50331649},"s":{"r":0,"d":0,"h":21475491853,"f":83886082},"n":"ActiveChangeCallbacks","d":655373,"h":12885557261,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30065426445,"f":50331649},"n":"HasChanged","d":655373,"h":25770459149,"f":2097153}],"m":[{"r":57540609,"p":[{"n":"callback","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":655373,"h":34360393741,"f":16777217},{"r":65537,"n":"OnReload","d":655373,"h":38655361037,"f":16777217}],"l":[{"t":125960193,"n":"_cts","d":655373,"h":4295622669,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":655373,"h":42950328333,"f":16777217}],"i":[720898],"h":655373}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationReloadToken`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationSection", ($self) => class ConfigurationSection extends $.$$.System.Object
        {
            /*IConfigurationRoot*/ _root = null;
            /*string*/ _path = null;
            /*string?*/ _key = null;
            $ctor$1(/*IConfigurationRoot*/ root, /*string*/ path)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(root, "root");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(path, "path");
                    this._root = root;
                    this._path = path;
                }
                return this;
            }
            /*string */ get Path()
            {
                return this._path;
            }
            /*string */ get Key()
            {
                return this._key ??= $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.GetSectionKey(this._path);
            }
            /*string? */ get Value()
            {
                return this._root.Microsoft$Extensions$Configuration$IConfiguration$get_Item(this.Path);
            }
            /*string? */ set Value(value)
            {
                this._root.Microsoft$Extensions$Configuration$IConfiguration$set_Item(this.Path, value);
            }
            /*bool */ TryGetValue(/*string?*/ key, /*out string?*/ value)
            {
                /*string*/ let path = key === null ? this.Path : this.Path + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + key;
                if ($.$mec.Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions.TryGetConfiguration(this._root, path, value))
                {
                    return true;
                }
                value.$v = null;
                return false;
            }
            /*string?*/ get_Item(/*string*/ key)
            {
                return this._root.Microsoft$Extensions$Configuration$IConfiguration$get_Item(this.Path + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + key);
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                this._root.Microsoft$Extensions$Configuration$IConfiguration$set_Item(this.Path + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + key, value);
            }
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                return this._root.Microsoft$Extensions$Configuration$IConfiguration$GetSection(this.Path + $.$meca.Microsoft.Extensions.Configuration.ConfigurationPath.KeyDelimiter + key);
            }
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                return $.$mec.Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions.GetChildrenImplementation(this._root, this.Path);
            }
            /*IChangeToken */ GetReloadToken()
            {
                return this._root.Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken();
            }
            /*string */ DebuggerToString()
            {
                /*var*/ let s = `Path = ${this.Path}`;
                /*var*/ let childCount = /*$.$mec.Microsoft.Extensions.Configuration.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this._root).Count;
                if (childCount > 0)
                {
                    s += `, Sections = ${childCount}`;
                }
                if (!(this.Value === null))
                {
                    s += `, Value = ${this.Value}`;
                    /*IConfigurationProvider?*/ let provider = /*$.$mec.Microsoft.Extensions.Configuration.ConfigurationSectionDebugView*/$.$$.DeletedObject.GetValueProvider(this._root, this.Path);
                    if (provider !== null)
                    {
                        s += `, Provider = ${$.$$.System.Object.ToString.call(provider)}`;
                    }
                }
                return s;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Key.get
            get Microsoft$Extensions$Configuration$IConfigurationSection$Key()
            {
                return this.Key;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Path.get
            get Microsoft$Extensions$Configuration$IConfigurationSection$Path()
            {
                return this.Path;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Value.get
            get Microsoft$Extensions$Configuration$IConfigurationSection$Value()
            {
                return this.Value;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Value.set
            set Microsoft$Extensions$Configuration$IConfigurationSection$Value(value)
            {
                this.Value = value;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            Microsoft$Extensions$Configuration$IConfiguration$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            Microsoft$Extensions$Configuration$IConfiguration$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            Microsoft$Extensions$Configuration$IConfiguration$GetSection()
            {
                return this.GetSection(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            Microsoft$Extensions$Configuration$IConfiguration$GetChildren()
            {
                return this.GetChildren(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken()
            {
                return this.GetReloadToken(...arguments);
            }
            static $h = 786445;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770590221,"f":50331649},"n":"Path","d":786445,"h":21475622925,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360524813,"f":50331649},"n":"Key","d":786445,"h":30065557517,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950459405,"f":50331649},"s":{"r":0,"d":0,"h":47245426701,"f":83886081},"n":"Value","d":786445,"h":38655492109,"f":2097153},{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":60130328589,"f":50331649},"s":{"r":0,"d":0,"h":64425295885,"f":83886081},"n":"Item","o":"@$2","d":786445,"h":55835361293,"f":2097153}],"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721,"f":2}],"n":"TryGetValue","d":786445,"h":51540393997,"f":16777217},{"r":589838,"p":[{"n":"key","p":1310721}],"n":"GetSection","d":786445,"h":68720263181,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,"n":"GetChildren","d":786445,"h":73015230477,"f":16777217},{"r":720898,"n":"GetReloadToken","d":786445,"h":77310197773,"f":16777217},{"r":1310721,"n":"DebuggerToString","d":786445,"h":81605165069,"f":16777218}],"l":[{"t":524302,"n":"_root","d":786445,"h":4295753741,"f":4194306},{"t":1310721,"n":"_path","d":786445,"h":8590721037,"f":4194306},{"t":1310721,"n":"_key","d":786445,"h":12885688333,"f":4194306}],"c":[{"p":[{"n":"root","p":524302},{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$1","d":786445,"h":17180655629,"f":16777217}],"i":[589838,262158],"h":786445,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, $.$meca.Microsoft.Extensions.Configuration.IConfiguration ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationSection`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ChainedConfigurationProvider", ($self) => class ChainedConfigurationProvider extends $.$$.System.Object
        {
            /*IConfiguration*/ _config = null;
            /*bool*/ _shouldDisposeConfig = false;
            $ctor$1(/*ChainedConfigurationSource*/ source)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this._config = $.$firstOf(source.Configuration, () => { throw new $.$$.System.ArgumentException().$ctor$13($.$mec.System.SR.Format$6($.$mec.System.SR.InvalidNullArgument, "source.Configuration"), "source") });
                    this._shouldDisposeConfig = source.ShouldDisposeConfiguration;
                }
                return this;
            }
            /*IConfiguration */ get Configuration()
            {
                return this._config;
            }
            /*bool */ TryGet(/*string*/ key, /*out string?*/ value)
            {
                value.$v = this._config.Microsoft$Extensions$Configuration$IConfiguration$get_Item(key);
                return !$.$$.System.String.IsNullOrEmpty(value.$v);
            }
            /*void */ Set(/*string*/ key, /*string?*/ value)
            {
                let $t1;
                return this._config.Microsoft$Extensions$Configuration$IConfiguration$set_Item(key, $t1 = (value)), $t1;
            }
            /*IChangeToken */ GetReloadToken()
            {
                return this._config.Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken();
            }
            /*void */ Load()
            {
            }
            /*IEnumerable<string> */ GetChildKeys(/*IEnumerable<string>*/ earlierKeys, /*string?*/ parentPath)
            {
                /*IConfiguration*/ let section = $.$$.System.String.op_Equality(parentPath, null) ? this._config : this._config.Microsoft$Extensions$Configuration$IConfiguration$GetSection(parentPath);
                /*var*/ let keys = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                var $en2 = section.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var child = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        keys.Add(child.Microsoft$Extensions$Configuration$IConfigurationSection$Key);
                    }
                }
                keys.AddRange(earlierKeys);
                keys.Sort$2($.$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer.Comparison);
                return keys;
            }
            /*void */ Dispose()
            {
                if (this._shouldDisposeConfig)
                {
                    ($.$as(this._config, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.TryGet(string, out string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet()
            {
                return this.TryGet(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Set(string, string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$Set()
            {
                return this.Set(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken()
            {
                return this.GetReloadToken(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Load()
            Microsoft$Extensions$Configuration$IConfigurationProvider$Load()
            {
                return this.Load(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetChildKeys(System.Collections.Generic.IEnumerable<string>, string?)
            Microsoft$Extensions$Configuration$IConfigurationProvider$GetChildKeys()
            {
                return this.GetChildKeys(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 131085;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262158,"g":{"r":0,"d":0,"h":21474967565,"f":50331649},"n":"Configuration","d":131085,"h":17180000269,"f":2097153}],"m":[{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721,"f":2}],"n":"TryGet","d":131085,"h":25769934861,"f":16777217},{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Set","d":131085,"h":30064902157,"f":16777217},{"r":720898,"n":"GetReloadToken","d":131085,"h":34359869453,"f":16777217},{"r":65537,"n":"Load","d":131085,"h":38654836749,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"p":[{"n":"earlierKeys","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h},{"n":"parentPath","p":1310721}],"n":"GetChildKeys","d":131085,"h":42949804045,"f":16777217},{"r":65537,"n":"Dispose","d":131085,"h":47244771341,"f":16777217}],"l":[{"t":262158,"n":"_config","d":131085,"h":4295098381,"f":4194306},{"t":262145,"n":"_shouldDisposeConfig","d":131085,"h":8590065677,"f":4194306}],"c":[{"p":[{"n":"source","p":196621}],"n":".ctor","o":"$ctor$1","d":131085,"h":12885032973,"f":16777217}],"i":[458766,57540609],"h":131085}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ChainedConfigurationProvider`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationRoot", ($self) => class ConfigurationRoot extends $.$$.System.Object
        {
            /*IList<IConfigurationProvider>*/ _providers = null;
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            /*ConfigurationReloadToken*/ _changeToken = null;
            $ctor$1(/*IList<IConfigurationProvider>*/ providers)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(providers, "providers");
                    this._providers = providers;
                    this._changeTokenRegistrations = new ($.$$.System.Collections.Generic.List$$($.$$.System.IDisposable))().$ctor$3(providers.System$Collections$Generic$ICollection$$$Count);
                    var $en3 = providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var p = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            p.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                            this._changeTokenRegistrations.Add($.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(p, p.Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken), new $.$$.System.Action().$ctor(this, this.RaiseChanged)));
                        }
                    }
                }
                return this;
            }
            /*IEnumerable<IConfigurationProvider> */ get Providers()
            {
                return this._providers;
            }
            /*string?*/ get_Item(/*string*/ key)
            {
                return $.$mec.Microsoft.Extensions.Configuration.ConfigurationRoot.GetConfiguration(this._providers, key);
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                $.$mec.Microsoft.Extensions.Configuration.ConfigurationRoot.SetConfiguration(this._providers, key, value);
            }
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                return $.$mec.Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions.GetChildrenImplementation(this, null);
            }
            /*IChangeToken */ GetReloadToken()
            {
                return this._changeToken;
            }
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection().$ctor$1(this, key);
            }
            /*void */ Reload()
            {
                var $en2 = this._providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var provider = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                    }
                }
                this.RaiseChanged();
            }
            /*void */ RaiseChanged()
            {
                /*ConfigurationReloadToken*/ let previousToken = $.$$.System.Threading.Interlocked.Exchange$14($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken), new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            /*void */ Dispose()
            {
                var $en2 = this._changeTokenRegistrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
                var $en2 = this._providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var provider = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        ($.$as(provider, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                    }
                }
            }
            static /*string? */ GetConfiguration(/*IList<IConfigurationProvider>*/ providers, /*string*/ key)
            {
                for(/*int*/ let i = ((providers.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*IConfigurationProvider*/ let provider = providers.System$Collections$Generic$IList$$$get_Item(i, [$.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider]);
                    /*string?*/ let value;
                    if (provider.Microsoft$Extensions$Configuration$IConfigurationProvider$TryGet(key, $.$ref(() => value, ($v) => value = $v, $.$$.System.String)))
                    {
                        return value;
                    }
                }
                return null;
            }
            static /*void */ SetConfiguration(/*IList<IConfigurationProvider>*/ providers, /*string*/ key, /*string?*/ value)
            {
                if (providers.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mec.System.SR.Error_NoSources);
                }
                var $en2 = providers.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var provider = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Set(key, value);
                    }
                }
            }
            /*string */ DebuggerToString()
            {
                return `Sections = ${/*$.$mec.Microsoft.Extensions.Configuration.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this).Count}`;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Reload()
            Microsoft$Extensions$Configuration$IConfigurationRoot$Reload()
            {
                return this.Reload(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Providers.get
            get Microsoft$Extensions$Configuration$IConfigurationRoot$Providers()
            {
                return this.Providers;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            Microsoft$Extensions$Configuration$IConfiguration$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            Microsoft$Extensions$Configuration$IConfiguration$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            Microsoft$Extensions$Configuration$IConfiguration$GetSection()
            {
                return this.GetSection(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            Microsoft$Extensions$Configuration$IConfiguration$GetChildren()
            {
                return this.GetChildren(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken()
            {
                return this.GetReloadToken(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._changeToken = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1();
            }
            static $h = 720909;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":25770524685,"f":50331649},"n":"Providers","d":720909,"h":21475557389,"f":2097153},{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":34360459277,"f":50331649},"s":{"r":0,"d":0,"h":38655426573,"f":83886081},"n":"Item","o":"@$2","d":720909,"h":30065491981,"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,"n":"GetChildren","d":720909,"h":42950393869,"f":16777217},{"r":720898,"n":"GetReloadToken","d":720909,"h":47245361165,"f":16777217},{"r":589838,"p":[{"n":"key","p":1310721}],"n":"GetSection","d":720909,"h":51540328461,"f":16777217},{"r":65537,"n":"Reload","d":720909,"h":55835295757,"f":16777217},{"r":65537,"n":"RaiseChanged","d":720909,"h":60130263053,"f":16777218},{"r":65537,"n":"Dispose","d":720909,"h":64425230349,"f":16777217},{"r":1310721,"p":[{"n":"providers","p":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h},{"n":"key","p":1310721}],"n":"GetConfiguration","d":720909,"h":68720197645,"f":16777256},{"r":65537,"p":[{"n":"providers","p":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h},{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"SetConfiguration","d":720909,"h":73015164941,"f":16777256},{"r":1310721,"n":"DebuggerToString","d":720909,"h":77310132237,"f":16777218}],"l":[{"t":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"n":"_providers","d":720909,"h":4295688205,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.IDisposable).$h,"n":"_changeTokenRegistrations","d":720909,"h":8590655501,"f":4194306},{"t":655373,"n":"_changeToken","d":720909,"h":12885622797,"f":4194306}],"c":[{"p":[{"n":"providers","p":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h}],"n":".ctor","o":"$ctor$1","d":720909,"h":17180590093,"f":16777217}],"i":[524302,262158,57540609],"h":720909,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationRoot, $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationRoot`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationManager", ($self) => class ConfigurationManager extends $.$$.System.Object
        {
            /*ConfigurationSources*/ _sources = null;
            /*ConfigurationBuilderProperties*/ _properties = null;
            /*ReferenceCountedProviderManager*/ _providerManager = null;
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            /*ConfigurationReloadToken*/ _changeToken = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._sources = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationSources().$ctor$1(this);
                    this._properties = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationBuilderProperties().$ctor$1(this);
                    this._sources.Add(new $.$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource().$ctor$1());
                }
                return this;
            }
            /*string?*/ get_Item(/*string*/ key)
            {
                /*ReferenceCountedProviders*/ let reference = this._providerManager.GetReference();
                try
                {
                    return $.$mec.Microsoft.Extensions.Configuration.ConfigurationRoot.GetConfiguration(reference.Providers, key);
                }
                finally
                {
                    reference?.System$IDisposable$Dispose();
                }
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                /*ReferenceCountedProviders*/ let reference = this._providerManager.GetReference();
                try
                {
                    $.$mec.Microsoft.Extensions.Configuration.ConfigurationRoot.SetConfiguration(reference.Providers, key, value);
                }
                finally
                {
                    reference?.System$IDisposable$Dispose();
                }
            }
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                return new $.$mec.Microsoft.Extensions.Configuration.ConfigurationSection().$ctor$1(this, key);
            }
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                return $.$mec.Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions.GetChildrenImplementation(this, null);
            }
            /*IDictionary<string, object> */ get Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties()
            {
                return this._properties;
            }
            /*IList<IConfigurationSource> */ get Sources()
            {
                return this._sources;
            }
            /*IEnumerable<IConfigurationProvider> */ get Microsoft$Extensions$Configuration$IConfigurationRoot$Providers()
            {
                return this._providerManager.NonReferenceCountedProviders;
            }
            /*void */ Dispose()
            {
                this.DisposeRegistrations();
                this._providerManager.Dispose();
            }
            /*IConfigurationBuilder */ Microsoft$Extensions$Configuration$IConfigurationBuilder$Add(/*IConfigurationSource*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                return this;
            }
            /*IConfigurationRoot */ Microsoft$Extensions$Configuration$IConfigurationBuilder$Build()
            {
                return this;
            }
            /*IChangeToken */ Microsoft$Extensions$Configuration$IConfiguration$GetReloadToken()
            {
                return this._changeToken;
            }
            /*void */ Microsoft$Extensions$Configuration$IConfigurationRoot$Reload()
            {
                let reference = null;
                try
                {
                    reference = this._providerManager.GetReference();
                    var $en3 = reference.Providers.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var provider = $en3.Current;
                        {
                            provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                        }
                    }
                }
                finally
                {
                    reference?.System$IDisposable$Dispose();
                }
                this.RaiseChanged();
            }
            /*ReferenceCountedProviders */ GetProvidersReference()
            {
                return this._providerManager.GetReference();
            }
            /*void */ RaiseChanged()
            {
                /*var*/ let previousToken = $.$$.System.Threading.Interlocked.Exchange$14($.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken), new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            /*void */ AddSource(/*IConfigurationSource*/ source)
            {
                /*IConfigurationProvider*/ let provider = source.Microsoft$Extensions$Configuration$IConfigurationSource$Build(this);
                provider.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                this._changeTokenRegistrations.Add($.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(provider, provider.Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken), new $.$$.System.Action().$ctor(this, this.RaiseChanged)));
                this._providerManager.AddProvider(provider);
                this.RaiseChanged();
            }
            /*void */ ReloadSources()
            {
                this.DisposeRegistrations();
                this._changeTokenRegistrations.Clear();
                /*var*/ let newProvidersList = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider))().$ctor$1();
                var $en2 = this._sources.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var source = $en2.Current;
                    {
                        newProvidersList.Add(source.Microsoft$Extensions$Configuration$IConfigurationSource$Build(this));
                    }
                }
                var $en2 = newProvidersList.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var p = $en2.Current;
                    {
                        p.Microsoft$Extensions$Configuration$IConfigurationProvider$Load();
                        this._changeTokenRegistrations.Add($.$mep.Microsoft.Extensions.Primitives.ChangeToken.OnChange(new ($.$$.System.Func$$($.$mep.Microsoft.Extensions.Primitives.IChangeToken))().$ctor(p, p.Microsoft$Extensions$Configuration$IConfigurationProvider$GetReloadToken), new $.$$.System.Action().$ctor(this, this.RaiseChanged)));
                    }
                }
                this._providerManager.ReplaceProviders(newProvidersList);
                this.RaiseChanged();
            }
            /*void */ DisposeRegistrations()
            {
                var $en2 = this._changeTokenRegistrations.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var registration = $en2.Current;
                    {
                        registration.System$IDisposable$Dispose();
                    }
                }
            }
            /*string */ DebuggerToString()
            {
                return `Sections = ${/*$.$mec.Microsoft.Extensions.Configuration.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this).Count}`;
            }
            static $_ConfigurationSources;
            static get ConfigurationSources()
            {
                let $cls = $.$mec.Microsoft.Extensions.Configuration.ConfigurationManager;
                return $cls.$_ConfigurationSources ??= $asm.$ncls("$mec.Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationSources", ($self) => class ConfigurationSources extends $.$$.System.Object
                {
                    /*List<IConfigurationSource>*/ _sources = null;
                    /*ConfigurationManager*/ _config = null;
                    $ctor$1(/*ConfigurationManager*/ config)
                    {
                        super.$ctor();
                        {
                            this._config = config;
                        }
                        return this;
                    }
                    /*IConfigurationSource*/ get_Item(/*int*/ index)
                    {
                        return this._sources.get_Item(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*IConfigurationSource*/ value)
                    {
                        this._sources.set_Item(index, value);
                        this._config.ReloadSources();
                    }
                    /*int */ get Count()
                    {
                        return this._sources.Count;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return false;
                    }
                    /*void */ Add(/*IConfigurationSource*/ source)
                    {
                        this._sources.Add(source);
                        this._config.AddSource(source);
                    }
                    /*void */ Clear()
                    {
                        this._sources.Clear();
                        this._config.ReloadSources();
                    }
                    /*bool */ Contains(/*IConfigurationSource*/ source)
                    {
                        return this._sources.Contains(source);
                    }
                    /*void */ CopyTo(/*IConfigurationSource[]*/ array, /*int*/ arrayIndex)
                    {
                        this._sources.CopyTo(array, arrayIndex);
                    }
                    /*List<IConfigurationSource>.Enumerator */ GetEnumerator()
                    {
                        return this._sources.GetEnumerator();
                    }
                    /*int */ IndexOf(/*IConfigurationSource*/ source)
                    {
                        return this._sources.IndexOf$2(source);
                    }
                    /*void */ Insert(/*int*/ index, /*IConfigurationSource*/ source)
                    {
                        this._sources.Insert(index, source);
                        this._config.ReloadSources();
                    }
                    /*bool */ Remove(/*IConfigurationSource*/ source)
                    {
                        /*var*/ let removed = this._sources.Remove(source);
                        this._config.ReloadSources();
                        return removed;
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        this._sources.RemoveAt(index);
                        this._config.ReloadSources();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*IEnumerator<IConfigurationSource> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.IndexOf(Microsoft.Extensions.Configuration.IConfigurationSource)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.Insert(int, Microsoft.Extensions.Configuration.IConfigurationSource)
                    System$Collections$Generic$IList$$$Insert()
                    {
                        return this.Insert(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.RemoveAt(int)
                    System$Collections$Generic$IList$$$RemoveAt()
                    {
                        return this.RemoveAt(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Contains(Microsoft.Extensions.Configuration.IConfigurationSource)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.CopyTo(Microsoft.Extensions.Configuration.IConfigurationSource[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Remove(Microsoft.Extensions.Configuration.IConfigurationSource)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._sources = new ($.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource))().$ctor$1();
                    }
                    static $h = 524301;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655374,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":21475360781,"f":50331649},"s":{"r":0,"d":0,"h":25770328077,"f":83886081},"n":"Item","o":"@$2","d":524301,"h":17180393485,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":34360262669,"f":50331649},"n":"Count","d":524301,"h":30065295373,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42950197261,"f":50331649},"n":"IsReadOnly","d":524301,"h":38655229965,"f":2097153}],"m":[{"r":65537,"p":[{"n":"source","p":655374}],"n":"Add","d":524301,"h":47245164557,"f":16777217},{"r":65537,"n":"Clear","d":524301,"h":51540131853,"f":16777217},{"r":262145,"p":[{"n":"source","p":655374}],"n":"Contains","d":524301,"h":55835099149,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":524301,"h":60130066445,"f":16777217},{"r":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).Enumerator.$h,"n":"GetEnumerator","d":524301,"h":64425033741,"f":16777217},{"r":655361,"p":[{"n":"source","p":655374}],"n":"IndexOf","d":524301,"h":68720001037,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"source","p":655374}],"n":"Insert","d":524301,"h":73014968333,"f":16777217},{"r":262145,"p":[{"n":"source","p":655374}],"n":"Remove","d":524301,"h":77309935629,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":524301,"h":81604902925,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"n":"_sources","d":524301,"h":4295491597,"f":4194306},{"t":393229,"n":"_config","d":524301,"h":8590458893,"f":4194306}],"c":[{"p":[{"n":"config","p":393229}],"n":".ctor","o":"$ctor$1","d":524301,"h":12885426189,"f":16777217}],"i":[$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,$.$$.System.Collections.Generic.ICollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,31719425],"d":393229,"h":524301}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource), $.$$.System.Collections.Generic.ICollection$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource), $.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationSources`; }
                }, $cls, ($v) => $cls.$_ConfigurationSources = $v);
            }
            static $_ConfigurationBuilderProperties;
            static get ConfigurationBuilderProperties()
            {
                let $cls = $.$mec.Microsoft.Extensions.Configuration.ConfigurationManager;
                return $cls.$_ConfigurationBuilderProperties ??= $asm.$ncls("$mec.Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationBuilderProperties", ($self) => class ConfigurationBuilderProperties extends $.$$.System.Object
                {
                    /*Dictionary<string, object>*/ _properties = null;
                    /*ConfigurationManager*/ _config = null;
                    $ctor$1(/*ConfigurationManager*/ config)
                    {
                        super.$ctor();
                        {
                            this._config = config;
                        }
                        return this;
                    }
                    /*object*/ get_Item(/*string*/ key)
                    {
                        return this._properties.get_Item(key);
                    }
                    /*void*/ set_Item(/*string*/ key, /*object*/ value)
                    {
                        this._properties.set_Item(key, value);
                        this._config.ReloadSources();
                    }
                    /*ICollection<string> */ get Keys$1()
                    {
                        return this._properties.Keys;
                    }
                    /*ICollection<object> */ get Values()
                    {
                        return this._properties.Values;
                    }
                    /*int */ get Count()
                    {
                        return this._properties.Count;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return false;
                    }
                    /*void */ Add$1(/*string*/ key, /*object*/ value)
                    {
                        this._properties.Add(key, value);
                        this._config.ReloadSources();
                    }
                    /*void */ Add(/*KeyValuePair<string, object>*/ item)
                    {
                        (this._properties).System$Collections$Generic$ICollection$$$Add(item, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                        this._config.ReloadSources();
                    }
                    /*void */ Clear()
                    {
                        this._properties.Clear();
                        this._config.ReloadSources();
                    }
                    /*bool */ Contains(/*KeyValuePair<string, object>*/ item)
                    {
                        return $.$sl.System.Linq.Enumerable.Contains$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), this._properties, item);
                    }
                    /*bool */ ContainsKey(/*string*/ key)
                    {
                        return this._properties.ContainsKey(key);
                    }
                    /*void */ CopyTo(/*KeyValuePair<string, object>[]*/ array, /*int*/ arrayIndex)
                    {
                        (this._properties).System$Collections$Generic$ICollection$$$CopyTo(array, arrayIndex, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                    }
                    /*IEnumerator<KeyValuePair<string, object>> */ GetEnumerator()
                    {
                        return this._properties.GetEnumerator();
                    }
                    /*bool */ Remove$1(/*string*/ key)
                    {
                        /*var*/ let wasRemoved = this._properties.Remove$1(key);
                        this._config.ReloadSources();
                        return wasRemoved;
                    }
                    /*bool */ Remove(/*KeyValuePair<string, object>*/ item)
                    {
                        /*var*/ let wasRemoved = (this._properties).System$Collections$Generic$ICollection$$$Remove(item, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                        this._config.ReloadSources();
                        return wasRemoved;
                    }
                    /*bool */ TryGetValue(/*string*/ key, /*out object?*/ value)
                    {
                        return this._properties.TryGetValue(key, value);
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this._properties.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.this[string].get
                    System$Collections$Generic$IDictionary$$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.this[string].set
                    System$Collections$Generic$IDictionary$$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Keys.get
                    get System$Collections$Generic$IDictionary$$$$Keys()
                    {
                        return this.Keys$1;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Values.get
                    get System$Collections$Generic$IDictionary$$$$Values()
                    {
                        return this.Values;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.ContainsKey(string)
                    System$Collections$Generic$IDictionary$$$$ContainsKey()
                    {
                        return this.ContainsKey(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Add(string, object)
                    System$Collections$Generic$IDictionary$$$$Add()
                    {
                        return this.Add$1(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Remove(string)
                    System$Collections$Generic$IDictionary$$$$Remove()
                    {
                        return this.Remove$1(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.TryGetValue(string, out object)
                    System$Collections$Generic$IDictionary$$$$TryGetValue()
                    {
                        return this.TryGetValue(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Add(System.Collections.Generic.KeyValuePair<string, object>)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Contains(System.Collections.Generic.KeyValuePair<string, object>)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.CopyTo(System.Collections.Generic.KeyValuePair<string, object>[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Remove(System.Collections.Generic.KeyValuePair<string, object>)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._properties = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                    }
                    static $h = 458765;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":21475295245,"f":50331649},"s":{"r":0,"d":0,"h":25770262541,"f":83886081},"n":"Item","o":"@$2","d":458765,"h":17180327949,"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":34360197133,"f":50331649},"n":"Keys","o":"@$1","d":458765,"h":30065229837,"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$($.$$.System.Object).$h,"g":{"r":0,"d":0,"h":42950131725,"f":50331649},"n":"Values","d":458765,"h":38655164429,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51540066317,"f":50331649},"n":"Count","d":458765,"h":47245099021,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60130000909,"f":50331649},"n":"IsReadOnly","d":458765,"h":55835033613,"f":2097153}],"m":[{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":131073}],"n":"Add","o":"@$1","d":458765,"h":64424968205,"f":16777217},{"r":65537,"p":[{"n":"item","p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"Add","d":458765,"h":68719935501,"f":16777217},{"r":65537,"n":"Clear","d":458765,"h":73014902797,"f":16777217},{"r":262145,"p":[{"n":"item","p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"Contains","d":458765,"h":77309870093,"f":16777217},{"r":262145,"p":[{"n":"key","p":1310721}],"n":"ContainsKey","d":458765,"h":81604837389,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":458765,"h":85899804685,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,"n":"GetEnumerator","d":458765,"h":90194771981,"f":16777217},{"r":262145,"p":[{"n":"key","p":1310721}],"n":"Remove","o":"@$1","d":458765,"h":94489739277,"f":16777217},{"r":262145,"p":[{"n":"item","p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h}],"n":"Remove","d":458765,"h":98784706573,"f":16777217},{"r":262145,"p":[{"n":"key","p":1310721},{"n":"value","p":131073,"f":2}],"n":"TryGetValue","d":458765,"h":103079673869,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,"n":"_properties","d":458765,"h":4295426061,"f":4194306},{"t":393229,"n":"_config","d":458765,"h":8590393357,"f":4194306}],"c":[{"p":[{"n":"config","p":393229}],"n":".ctor","o":"$ctor$1","d":458765,"h":12885360653,"f":16777217}],"i":[$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,31719425],"d":393229,"h":458765}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationManager.ConfigurationBuilderProperties`; }
                }, $cls, ($v) => $cls.$_ConfigurationBuilderProperties = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Sources.get
            get Microsoft$Extensions$Configuration$IConfigurationBuilder$Sources()
            {
                return this.Sources;
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            Microsoft$Extensions$Configuration$IConfiguration$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            Microsoft$Extensions$Configuration$IConfiguration$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            Microsoft$Extensions$Configuration$IConfiguration$GetSection()
            {
                return this.GetSection(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            Microsoft$Extensions$Configuration$IConfiguration$GetChildren()
            {
                return this.GetChildren(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._providerManager = new $.$mec.Microsoft.Extensions.Configuration.ReferenceCountedProviderManager().$ctor$1();
                this._changeTokenRegistrations = new ($.$$.System.Collections.Generic.List$$($.$$.System.IDisposable))().$ctor$1();
                this._changeToken = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationReloadToken().$ctor$1();
            }
            static $h = 393229;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":34360131597,"f":50331649},"s":{"r":0,"d":0,"h":38655098893,"f":83886081},"n":"Item","o":"@$2","d":393229,"h":30065164301,"f":2097153},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"g":{"r":0,"d":0,"h":55834968077,"f":50331650},"n":"{327694}.Properties","o":"Microsoft$Extensions$Configuration$IConfigurationBuilder$Properties","d":393229,"h":51540000781,"f":2097154},{"p":$.$$.System.Collections.Generic.IList$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSource).$h,"g":{"r":0,"d":0,"h":64424902669,"f":50331649},"n":"Sources","d":393229,"h":60129935373,"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider).$h,"g":{"r":0,"d":0,"h":73014837261,"f":50331650},"n":"{524302}.Providers","o":"Microsoft$Extensions$Configuration$IConfigurationRoot$Providers","d":393229,"h":68719869965,"f":2097154}],"m":[{"r":589838,"p":[{"n":"key","p":1310721}],"n":"GetSection","d":393229,"h":42950066189,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection).$h,"n":"GetChildren","d":393229,"h":47245033485,"f":16777217},{"r":65537,"n":"Dispose","d":393229,"h":77309804557,"f":16777217},{"r":1179661,"n":"GetProvidersReference","d":393229,"h":98784641037,"f":16777224},{"r":65537,"n":"RaiseChanged","d":393229,"h":103079608333,"f":16777218},{"r":65537,"p":[{"n":"source","p":655374}],"n":"AddSource","d":393229,"h":107374575629,"f":16777218},{"r":65537,"n":"ReloadSources","d":393229,"h":111669542925,"f":16777218},{"r":65537,"n":"DisposeRegistrations","d":393229,"h":115964510221,"f":16777218},{"r":1310721,"n":"DebuggerToString","d":393229,"h":120259477517,"f":16777218}],"l":[{"t":524301,"n":"_sources","d":393229,"h":4295360525,"f":4194306},{"t":458765,"n":"_properties","d":393229,"h":8590327821,"f":4194306},{"t":1114125,"n":"_providerManager","d":393229,"h":12885295117,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.IDisposable).$h,"n":"_changeTokenRegistrations","d":393229,"h":17180262413,"f":4194306},{"t":655373,"n":"_changeToken","d":393229,"h":21475229709,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":393229,"h":25770197005,"f":16777217}],"i":[393230,327694,524302,262158,57540609],"j":[524301,458765],"h":393229,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":null,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationManager, $.$meca.Microsoft.Extensions.Configuration.IConfigurationBuilder, $.$meca.Microsoft.Extensions.Configuration.IConfigurationRoot, $.$meca.Microsoft.Extensions.Configuration.IConfiguration, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationManager`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer", ($self) => class ConfigurationKeyComparer extends $.$$.System.Object
        {
            /*char*/ static KeyDelimiter = /*:*/ 58;
            /*ConfigurationKeyComparer*/ static Instance = null;
            /*Comparison<string>*/ static Comparison = null;
            /*int */ Compare$1(/*string?*/ x, /*string?*/ y)
            {
                /*ReadOnlySpan<char>*/ let xSpan = $.$$.System.MemoryExtensions.AsSpan$4(x);
                /*ReadOnlySpan<char>*/ let ySpan = $.$$.System.MemoryExtensions.AsSpan$4(y);
                xSpan = SkipAheadOnDelimiter(xSpan);
                ySpan = SkipAheadOnDelimiter(ySpan);
                while(!xSpan.IsEmpty && !ySpan.IsEmpty)
                {
                    /*int*/ let xDelimiterIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, xSpan, /*:*/ 58);
                    /*int*/ let yDelimiterIndex = $.$$.System.MemoryExtensions.IndexOf$4($.$$.System.Char, ySpan, /*:*/ 58);
                    /*int*/ let compareResult = Compare(xDelimiterIndex === -1 ? xSpan : xSpan.Slice(0, xDelimiterIndex), yDelimiterIndex === -1 ? ySpan : ySpan.Slice(0, yDelimiterIndex));
                    if (compareResult !== 0)
                    {
                        return compareResult;
                    }
                    xSpan = xDelimiterIndex === -1 ? new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))() : SkipAheadOnDelimiter(xSpan.Slice$1(((xDelimiterIndex + 1) | 0)));
                    ySpan = yDelimiterIndex === -1 ? new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))() : SkipAheadOnDelimiter(ySpan.Slice$1(((yDelimiterIndex + 1) | 0)));
                }
                return xSpan.IsEmpty ? (ySpan.IsEmpty ? 0 : -1) : 1;
                /*static ReadOnlySpan<char>*/  function SkipAheadOnDelimiter(/*ReadOnlySpan<char>*/ a)
                {
                    while(!a.IsEmpty && a.get_Item(0).$v === /*:*/ 58)
                    {
                        a = a.Slice$1(1);
                    }
                    return a;
                }
                /*static int*/  function Compare(/*ReadOnlySpan<char>*/ a, /*ReadOnlySpan<char>*/ b)
                {
                    /*int*/ let value1;
                    /*bool*/ let aIsInt = $.$$.System.Int32.TryParse$5(a, $.$ref(() => value1, ($v) => value1 = $v, $.$$.System.Int32));
                    /*int*/ let value2;
                    /*bool*/ let bIsInt = $.$$.System.Int32.TryParse$5(b, $.$ref(() => value2, ($v) => value2 = $v, $.$$.System.Int32));
                    /*int*/ let result;
                    if (!aIsInt && !bIsInt)
                    {
                        result = $.$$.System.MemoryExtensions.CompareTo(a, b, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                    else if (aIsInt && bIsInt)
                    {
                        result = ((value1 - value2) | 0);
                    }
                    else 
                    {
                        result = aIsInt ? -1 : 1;
                    }
                    return result;
                }
            }
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            System$Collections$Generic$IComparer$$$Compare()
            {
                return this.Compare$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer().$ctor$1();
                }
                {
                    this.Comparison = new ($.$$.System.Comparison$$($.$$.System.String))().$ctor($.$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer.Instance, $.$mec.Microsoft.Extensions.Configuration.ConfigurationKeyComparer.Instance.Compare$1);
                }
            }
            static $h = 327693;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":327693,"g":{"r":0,"d":0,"h":17180196877,"f":50331681},"n":"Instance","d":327693,"h":12885229581,"f":2097185},{"p":$.$$.System.Comparison$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":30065098765,"f":50331688},"n":"Comparison","d":327693,"h":25770131469,"f":2097192}],"m":[{"r":655361,"p":[{"n":"x","p":1310721},{"n":"y","p":1310721}],"n":"Compare","o":"@$1","d":327693,"h":34360066061,"f":16777217}],"l":[{"t":458753,"n":"KeyDelimiter","d":327693,"h":4295294989,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":327693,"h":38655033357,"f":16777217}],"i":[$.$$.System.Collections.Generic.IComparer$$($.$$.System.String).$h],"h":327693}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IComparer$$($.$$.System.String) ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.ConfigurationKeyComparer`; }
        });
        
        $asm.$cls("$mec.Microsoft.Extensions.Configuration.Memory.MemoryConfigurationProvider", ($self) => class MemoryConfigurationProvider extends $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider
        {
            /*MemoryConfigurationSource*/ _source = null;
            $ctor$2(/*MemoryConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this._source = source;
                    if (this._source.InitialData !== null)
                    {
                        var $en4 = this._source.InitialData.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var pair = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                this.Data.System$Collections$Generic$IDictionary$$$$Add(pair.Key, pair.Value, [$.$$.System.String, $.$$.System.String]);
                            }
                        }
                    }
                }
                return this;
            }
            /*void */ Add(/*string*/ key, /*string?*/ value)
            {
                this.Data.System$Collections$Generic$IDictionary$$$$Add(key, value, [$.$$.System.String, $.$$.System.String]);
            }
            /*IEnumerator<KeyValuePair<string, string?>> */ GetEnumerator()
            {
                return this.Data.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, string?>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 917517;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589837,"m":[{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Add","d":917517,"h":12885819405,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,"n":"GetEnumerator","d":917517,"h":17180786701,"f":16777217}],"l":[{"t":983053,"n":"_source","d":917517,"h":4295884813,"f":4194306}],"c":[{"p":[{"n":"source","p":983053}],"n":".ctor","o":"$ctor$2","d":917517,"h":8590852109,"f":16777217}],"i":[458766,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)).$h,31719425],"h":917517}; }
            static get $b() { return $.$mec.Microsoft.Extensions.Configuration.ConfigurationProvider; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meca.Microsoft.Extensions.Configuration.IConfigurationProvider, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.String)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.Configuration.Memory.MemoryConfigurationProvider`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions"))