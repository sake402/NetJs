
//--TRIMMABLE-BOUNDARY-START(95)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mecga) {
    "use strict";
    let _;
    let $kXZzzf;
    let $JvzOVi;
    let $SLApLe;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Configuration", 
    {
  "h": 95,
  "f": "Microsoft.Extensions.Configuration",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Configuration.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Configuration",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1704031)
        $asm.$cls(`$mec.MEC.StreamConfigurationSource`, ($self) => class StreamConfigurationSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34361442399)
            /*Stream?*/ Stream = null;
            //--TRIMMABLE-BOUNDARY-END(34361442399)
            
            //--TRIMMABLE-BOUNDARY-START(4295753822)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            MEC$IConfigurationSource$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295753822)
            
            //--TRIMMABLE-BOUNDARY-START(8591638623)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591638623)
            
            //--TRIMMABLE-BOUNDARY-START(8591638623)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591638623)
            
            static $h = 1704031;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361442399),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476540511,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30066475103,
        "f": 83886081
      },
      "n": "Stream",
      "d": 1704031,
      "h": 34361442399,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361442399)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886605919),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 1704031,
      "h": 12886605919,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12886605919)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591638623),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704031,
      "h": 8591638623,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591638623)
  ],
  "h": 1704031
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.StreamConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}StreamConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704031)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441887)
        $asm.$cls(`$mec.MEC.ReferenceCountedProviders`, ($self) => class ReferenceCountedProviders extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886343775)
            static /*ReferenceCountedProviders */ Create(/*List<IConfigurationProvider>*/ providers)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343775);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ReferenceCountedProviders.ActiveReferenceCountedProviders().$ctor$2(providers);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886343775)
            
            //--TRIMMABLE-BOUNDARY-START(17181311071)
            static /*ReferenceCountedProviders */ CreateDisposed(/*List<IConfigurationProvider>*/ providers)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ReferenceCountedProviders.DisposedReferenceCountedProviders().$ctor$2(providers);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181311071)
            
            //--TRIMMABLE-BOUNDARY-START(1507423)
            static $_ActiveReferenceCountedProviders;
            static get ActiveReferenceCountedProviders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1507423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mec.MEC.ReferenceCountedProviders;
                return $cls.$_ActiveReferenceCountedProviders ??= $asm.$ncls(`$mec.MEC.ReferenceCountedProviders.ActiveReferenceCountedProviders`, ($self) => class ActiveReferenceCountedProviders extends $.$mec.MEC.ReferenceCountedProviders
                {
                    //--TRIMMABLE-BOUNDARY-START(8591442015)
                    /*long*/ _refCount = 1n;
                    //--TRIMMABLE-BOUNDARY-END(8591442015)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296474719)
                    /*List<IConfigurationProvider>*/ _providers = null;
                    //--TRIMMABLE-BOUNDARY-END(4296474719)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886409311)
                    $ctor$2(/*List<IConfigurationProvider>*/ providers)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886409311);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._providers = providers;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886409311)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246147679)
                    /*List<IConfigurationProvider> */ get Providers()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656213087);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(this._refCount > 0n, "_refCount > 0");
                        return this._providers;
                    }
                    /*List<IConfigurationProvider> */ set Providers(value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836082271);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(this._refCount > 0n, "_refCount > 0");
                        this._providers = value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246147679)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951180383)
                    /*List<IConfigurationProvider> */ get NonReferenceCountedProviders()
                    {
                        return this._providers;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951180383)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181376607)
                    /*void */ AddReference()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181376607);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(this._refCount > 0n, "_refCount > 0");
                        $.$$.ST$1.Interlocked.Increment$1($.$ref(() => this._refCount, ($v) => this._refCount = $v, $.$$.S.Int64));
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181376607)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476343903)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476343903);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.ST$1.Interlocked.Decrement$1($.$ref(() => this._refCount, ($v) => this._refCount = $v, $.$$.S.Int64)) === 0n)
                        {
                            let $en3 = this._providers.GetEnumerator();
                            while ($en3.MoveNext())
                            {
                                let provider = $en3.Current;
                                {
                                    ($.$as(provider, $.$$.S.IDisposable))?.S$IDisposable$Dispose();
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476343903)
                    
                    static $h = 1507423;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mec.MEC.ReferenceCountedProviders; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246147679),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656213087,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836082271,
        "f": 83918849
      },
      "n": "Providers",
      "d": 1507423,
      "h": 47246147679,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47246147679),
//--TRIMMABLE-BOUNDARY-START(42951180383),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066278495,
        "f": 50364417
      },
      "n": "NonReferenceCountedProviders",
      "d": 1507423,
      "h": 42951180383,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951180383)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376607),
    {
      "r": 65537,
      "n": "AddReference",
      "d": 1507423,
      "h": 17181376607,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181376607),
//--TRIMMABLE-BOUNDARY-START(21476343903),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507423,
      "h": 21476343903,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476343903)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591442015),
    {
      "t": 917505,
      "n": "_refCount",
      "d": 1507423,
      "h": 8591442015,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442015),
//--TRIMMABLE-BOUNDARY-START(4296474719),
    {
      "t": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "n": "_providers",
      "d": 1507423,
      "h": 4296474719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474719)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886409311),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507423,
      "h": 12886409311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409311)
  ],
  "d": 1441887,
  "h": 1507423
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ReferenceCountedProviders+ActiveReferenceCountedProviders`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ReferenceCountedProviders${separator}ActiveReferenceCountedProviders`; }
                }, $cls, ($v) => $cls.$_ActiveReferenceCountedProviders = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1507423)
            
            //--TRIMMABLE-BOUNDARY-START(1572959)
            static $_DisposedReferenceCountedProviders;
            static get DisposedReferenceCountedProviders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mec.MEC.ReferenceCountedProviders;
                return $cls.$_DisposedReferenceCountedProviders ??= $asm.$ncls(`$mec.MEC.ReferenceCountedProviders.DisposedReferenceCountedProviders`, ($self) => class DisposedReferenceCountedProviders extends $.$mec.MEC.ReferenceCountedProviders
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507551)
                    $ctor$2(/*List<IConfigurationProvider>*/ providers)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591507551);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Providers = providers;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591507551)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951245919)
                    /*List<IConfigurationProvider>*/ Providers = null;
                    //--TRIMMABLE-BOUNDARY-END(42951245919)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656278623)
                    /*List<IConfigurationProvider> */ get NonReferenceCountedProviders()
                    {
                        return this.Providers;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656278623)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886474847)
                    /*void */ AddReference()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886474847);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886474847)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181442143)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181442143);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181442143)
                    
                    static $h = 1572959;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$mec.MEC.ReferenceCountedProviders; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951245919),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361311327,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51541180511,
        "f": 83918849
      },
      "n": "Providers",
      "d": 1572959,
      "h": 42951245919,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42951245919),
//--TRIMMABLE-BOUNDARY-START(38656278623),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771376735,
        "f": 50364417
      },
      "n": "NonReferenceCountedProviders",
      "d": 1572959,
      "h": 38656278623,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38656278623)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474847),
    {
      "r": 65537,
      "n": "AddReference",
      "d": 1572959,
      "h": 12886474847,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886474847),
//--TRIMMABLE-BOUNDARY-START(17181442143),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1572959,
      "h": 17181442143,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181442143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591507551),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572959,
      "h": 8591507551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591507551)
  ],
  "d": 1441887,
  "h": 1572959
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ReferenceCountedProviders+DisposedReferenceCountedProviders`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ReferenceCountedProviders${separator}DisposedReferenceCountedProviders`; }
                }, $cls, ($v) => $cls.$_DisposedReferenceCountedProviders = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1572959)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4296409183)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409183)
            
            //--TRIMMABLE-BOUNDARY-START(4296409183)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409183)
            
            static $h = 1441887;
            static $f = 0b110000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246082143),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147551,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836016735,
        "f": 83886337
      },
      "n": "Providers",
      "d": 1441887,
      "h": 47246082143,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47246082143),
//--TRIMMABLE-BOUNDARY-START(42951114847),
    {
      "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066212959,
        "f": 50331905
      },
      "n": "NonReferenceCountedProviders",
      "d": 1441887,
      "h": 42951114847,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42951114847)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886343775),
    {
      "r": 1441887,
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": "Create",
      "d": 1441887,
      "h": 12886343775,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886343775),
//--TRIMMABLE-BOUNDARY-START(17181311071),
    {
      "r": 1441887,
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": "CreateDisposed",
      "d": 1441887,
      "h": 17181311071,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181311071),
//--TRIMMABLE-BOUNDARY-START(8591376479),
    {
      "r": 65537,
      "n": "AddReference",
      "d": 1441887,
      "h": 8591376479,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591376479),
//--TRIMMABLE-BOUNDARY-START(21476278367),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1441887,
      "h": 21476278367,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476278367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409183),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441887,
      "h": 4296409183,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296409183)
  ],
  "h": 1441887
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mec.MEC.ReferenceCountedProviders.ActiveReferenceCountedProviders, $.$mec.MEC.ReferenceCountedProviders.DisposedReferenceCountedProviders ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ReferenceCountedProviders`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ReferenceCountedProviders`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441887)
        
        

        //--TRIMMABLE-BOUNDARY-START(655455)
        $asm.$cls(`$mec.MEC.ConfigurationProvider`, ($self) => class ConfigurationProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622751)
            /*ConfigurationReloadToken*/ _reloadToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295622751)
            
            //--TRIMMABLE-BOUNDARY-START(12885557343)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557343);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Data = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$6($.$$.S.StringComparer.OrdinalIgnoreCase);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557343)
            
            //--TRIMMABLE-BOUNDARY-START(17180524639)
            /*IDictionary<string, string?>*/ Data = null;
            //--TRIMMABLE-BOUNDARY-END(17180524639)
            
            //--TRIMMABLE-BOUNDARY-START(68720132191)
            /*bool */ TryGet(/*string*/ key, /*out string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720132191);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Data.SCG$IDictionary$$$$TryGetValue(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720132191)
            
            //--TRIMMABLE-BOUNDARY-START(60130197599)
            /*void */ Set(/*string*/ key, /*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130197599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $t2;
                    return this.Data.SCG$IDictionary$$$$set_Item(key, $t2 = (value)), $t2;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130197599)
            
            //--TRIMMABLE-BOUNDARY-START(38655361119)
            /*void */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655361119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655361119)
            
            //--TRIMMABLE-BOUNDARY-START(30065426527)
            /*IEnumerable<string> */ GetChildKeys(/*IEnumerable<string>*/ earlierKeys, /*string?*/ parentPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let results = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                if (parentPath === null)
                {
                    let $en3 = this.Data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en3.SC$1$IEnumerator$MoveNext())
                    {
                        let kv = $en3.SCG$IEnumerator$$$Current;
                        {
                            results.Add($.$mec.MEC.ConfigurationProvider.Segment(kv.Key, 0));
                        }
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4($.$mecga.MEC.ConfigurationPath.KeyDelimiter === ":", "ConfigurationPath.KeyDelimiter == \":\"");
                    let $en4 = this.Data.SCG$IEnumerable$$$GetEnumerator();
                    while ($en4.SC$1$IEnumerator$MoveNext())
                    {
                        let kv = $en4.SCG$IEnumerator$$$Current;
                        {
                            if (kv.Key.length > parentPath.length && $.$$.S.String.StartsWith$2.call(kv.Key, parentPath, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.S.String.get_Chars.call(kv.Key, parentPath.length) === /*:*/ 58)
                            {
                                results.Add($.$mec.MEC.ConfigurationProvider.Segment(kv.Key, ((parentPath.length + 1) | 0)));
                            }
                        }
                    }
                }
                results.AddRange(earlierKeys);
                results.Sort$2($.$mec.MEC.ConfigurationKeyComparer.Comparison);
                return results;
            }
            //--TRIMMABLE-BOUNDARY-END(30065426527)
            
            //--TRIMMABLE-BOUNDARY-START(47245295711)
            static /*string */ Segment(/*string*/ key, /*int*/ prefixLength)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245295711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$mecga.MEC.ConfigurationPath.KeyDelimiter === ":", "ConfigurationPath.KeyDelimiter == \":\"");
                /*int*/ let indexOf = $.$$.S.String.IndexOf$1.call(key, /*:*/ 58, prefixLength);
                return indexOf < 0 ? key.slice(prefixLength) : key.substr(prefixLength, ((indexOf - prefixLength) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(47245295711)
            
            //--TRIMMABLE-BOUNDARY-START(34360393823)
            /*IChangeToken */ GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._reloadToken;
            }
            //--TRIMMABLE-BOUNDARY-END(34360393823)
            
            //--TRIMMABLE-BOUNDARY-START(42950328415)
            /*void */ OnReload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConfigurationReloadToken*/ let previousToken = $.$$.ST$1.Interlocked.Exchange$14($.$mec.MEC.ConfigurationReloadToken, $.$ref(() => this._reloadToken, ($v) => this._reloadToken = $v, $.$mec.MEC.ConfigurationReloadToken), new $.$mec.MEC.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(42950328415)
            
            //--TRIMMABLE-BOUNDARY-START(64425164895)
            /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425164895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.Object.GetType.call(this).Name;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425164895)
            
            //--TRIMMABLE-BOUNDARY-START(21475426398)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.TryGet(string, out string?)
            MEC$IConfigurationProvider$TryGet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGet(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426398)
            
            //--TRIMMABLE-BOUNDARY-START(17180459102)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Set(string, string?)
            MEC$IConfigurationProvider$Set()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Set(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459102)
            
            //--TRIMMABLE-BOUNDARY-START(8590524510)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetReloadToken()
            MEC$IConfigurationProvider$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590524510)
            
            //--TRIMMABLE-BOUNDARY-START(12885491806)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Load()
            MEC$IConfigurationProvider$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885491806)
            
            //--TRIMMABLE-BOUNDARY-START(4295557214)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetChildKeys(System.Collections.Generic.IEnumerable<string>, string?)
            MEC$IConfigurationProvider$GetChildKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildKeys(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295557214)
            
            //--TRIMMABLE-BOUNDARY-START(12885557343)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885557343)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295622751)
                this._reloadToken = new $.$mec.MEC.ConfigurationReloadToken().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295622751)
                
            }
            static $h = 655455;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524639),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459231,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835230303,
        "f": 83886084
      },
      "n": "Data",
      "d": 655455,
      "h": 17180524639,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(17180524639)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720132191),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGet",
      "d": 655455,
      "h": 68720132191,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720132191),
//--TRIMMABLE-BOUNDARY-START(60130197599),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "d": 655455,
      "h": 60130197599,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60130197599),
//--TRIMMABLE-BOUNDARY-START(38655361119),
    {
      "r": 65537,
      "n": "Load",
      "d": 655455,
      "h": 38655361119,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38655361119),
//--TRIMMABLE-BOUNDARY-START(30065426527),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "earlierKeys",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "parentPath",
          "p": 1310721
        }
      ],
      "n": "GetChildKeys",
      "d": 655455,
      "h": 30065426527,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065426527),
//--TRIMMABLE-BOUNDARY-START(47245295711),
    {
      "r": 1310721,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "prefixLength",
          "p": 655361
        }
      ],
      "n": "Segment",
      "d": 655455,
      "h": 47245295711,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245295711),
//--TRIMMABLE-BOUNDARY-START(34360393823),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 655455,
      "h": 34360393823,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393823),
//--TRIMMABLE-BOUNDARY-START(42950328415),
    {
      "r": 65537,
      "n": "OnReload",
      "d": 655455,
      "h": 42950328415,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42950328415),
//--TRIMMABLE-BOUNDARY-START(64425164895),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 655455,
      "h": 64425164895,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425164895)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622751),
    {
      "t": 720991,
      "n": "_reloadToken",
      "d": 655455,
      "h": 4295622751,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557343),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655455,
      "h": 12885557343,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885557343)
  ],
  "h": 655455
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655455)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638495)
        $asm.$cls(`$mec.MEC.StreamConfigurationProvider`, ($self) => class StreamConfigurationProvider extends $.$mec.MEC.ConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(34361376863)
            /*StreamConfigurationSource*/ Source = null;
            //--TRIMMABLE-BOUNDARY-END(34361376863)
            
            //--TRIMMABLE-BOUNDARY-START(4296605791)
            /*bool*/ _loaded = false;
            //--TRIMMABLE-BOUNDARY-END(4296605791)
            
            //--TRIMMABLE-BOUNDARY-START(12886540383)
            $ctor$2(/*StreamConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540383);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this.Source = source;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540383)
            
            //--TRIMMABLE-BOUNDARY-START(25771442271)
            /*void */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._loaded)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mec.S.SR.StreamConfigurationProvidersAlreadyLoaded);
                }
                if (this.Source.Stream === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mec.S.SR.StreamConfigurationSourceStreamCannotBeNull);
                }
                this.Load$1(this.Source.Stream);
                this._loaded = true;
            }
            //--TRIMMABLE-BOUNDARY-END(25771442271)
            
            static $h = 1638495;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mec.MEC.ConfigurationProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361376863),
    {
      "p": 1704031,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476474975,
        "f": 50331649
      },
      "n": "Source",
      "d": 1638495,
      "h": 34361376863,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361376863)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066409567),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 95748097
        }
      ],
      "n": "Load",
      "o": "@$1",
      "d": 1638495,
      "h": 30066409567,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30066409567),
//--TRIMMABLE-BOUNDARY-START(25771442271),
    {
      "r": 65537,
      "n": "Load",
      "d": 1638495,
      "h": 25771442271,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771442271)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605791),
    {
      "t": 262145,
      "n": "_loaded",
      "d": 1638495,
      "h": 4296605791,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605791)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540383),
    {
      "p": [
        {
          "n": "source",
          "p": 1704031
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638495,
      "h": 12886540383,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540383)
  ],
  "h": 1638495
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.StreamConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}StreamConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638495)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900639)
        $asm.$cls(`$mec.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(133145886815)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(133145886815)
            
            //--TRIMMABLE-BOUNDARY-START(124555952223)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(124555952223)
            
            //--TRIMMABLE-BOUNDARY-START(128850919519)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901246559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mec.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Configuration", $.$mec.S.SR.$type.Assembly);
                    $.$mec.S.SR.s_resourceManager = temp;
                }
                return $.$mec.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(128850919519)
            
            //--TRIMMABLE-BOUNDARY-START(8591835231)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131442783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mec.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030788703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mec.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835231)
            
            //--TRIMMABLE-BOUNDARY-START(12886802527)
            static /*string */ get Error_NoSources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721377375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A configuration source is not registered. Please register one before setting a value.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886802527)
            
            //--TRIMMABLE-BOUNDARY-START(120260984927)
            static /*string */ get InvalidNullArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311311967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Null is not a valid value for '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(120260984927)
            
            //--TRIMMABLE-BOUNDARY-START(51541508191)
            static /*string */ FormatInvalidNullArgument(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541508191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Null is not a valid value for '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(51541508191)
            
            //--TRIMMABLE-BOUNDARY-START(150325755999)
            static /*string */ get StreamConfigurationProvidersAlreadyLoaded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491181151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "StreamConfigurationProviders cannot be loaded more than once.";
            }
            //--TRIMMABLE-BOUNDARY-END(150325755999)
            
            //--TRIMMABLE-BOUNDARY-START(154620723295)
            static /*string */ get StreamConfigurationSourceStreamCannotBeNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081115743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Source.Stream cannot be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(154620723295)
            
            //--TRIMMABLE-BOUNDARY-START(137440854111)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(137440854111)
            
            //--TRIMMABLE-BOUNDARY-START(115966017631)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115966017631);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115966017631)
            
            //--TRIMMABLE-BOUNDARY-START(158915690591)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915690591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mec.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915690591)
            
            //--TRIMMABLE-BOUNDARY-START(111671050335)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671050335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mec.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(111671050335)
            
            //--TRIMMABLE-BOUNDARY-START(107376083039)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376083039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mec.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(107376083039)
            
            //--TRIMMABLE-BOUNDARY-START(42951573599)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951573599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951573599)
            
            //--TRIMMABLE-BOUNDARY-START(38656606303)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656606303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38656606303)
            
            //--TRIMMABLE-BOUNDARY-START(34361639007)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361639007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34361639007)
            
            //--TRIMMABLE-BOUNDARY-START(47246540895)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mec.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47246540895)
            
            //--TRIMMABLE-BOUNDARY-START(25771704415)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771704415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25771704415)
            
            //--TRIMMABLE-BOUNDARY-START(21476737119)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476737119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21476737119)
            
            //--TRIMMABLE-BOUNDARY-START(17181769823)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mec.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17181769823)
            
            //--TRIMMABLE-BOUNDARY-START(30066671711)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066671711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mec.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30066671711)
            
            //--TRIMMABLE-BOUNDARY-START(4296867935)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(137440854111)
                    this.s_usingResourceKeys = $.$mec.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(137440854111)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867935)
            
            static $h = 1900639;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1900639
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900639)
        
        

        //--TRIMMABLE-BOUNDARY-START(65631)
        $asm.$cls(`$mec.MEC.ChainedBuilderExtensions`, ($self) => class ChainedBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590000223)
            static /*IConfigurationBuilder */ AddConfiguration$1(/*this IConfigurationBuilder*/ configurationBuilder, /*IConfiguration*/ config)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000223);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mec.MEC.ChainedBuilderExtensions.AddConfiguration(configurationBuilder, config, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000223)
            
            //--TRIMMABLE-BOUNDARY-START(4295032927)
            static /*IConfigurationBuilder */ AddConfiguration(/*this IConfigurationBuilder*/ configurationBuilder, /*IConfiguration*/ config, /*bool*/ shouldDisposeConfiguration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(config, "config");
                configurationBuilder.MEC$IConfigurationBuilder$Add((() =>
                {
                    //new $.$mec.MEC.ChainedConfigurationSource()
                    const $t1 = $.$mec.MEC.ChainedConfigurationSource;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Configuration = config;
                    $i1.ShouldDisposeConfiguration = shouldDisposeConfiguration;
                    return $i1;
                })());
                return configurationBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032927)
            
            static $h = 65631;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000223),
    {
      "r": 458846,
      "p": [
        {
          "n": "configurationBuilder",
          "p": 458846
        },
        {
          "n": "config",
          "p": 393310
        }
      ],
      "n": "AddConfiguration",
      "o": "@$1",
      "d": 65631,
      "h": 8590000223,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000223),
//--TRIMMABLE-BOUNDARY-START(4295032927),
    {
      "r": 458846,
      "p": [
        {
          "n": "configurationBuilder",
          "p": 458846
        },
        {
          "n": "config",
          "p": 393310
        },
        {
          "n": "shouldDisposeConfiguration",
          "p": 262145
        }
      ],
      "n": "AddConfiguration",
      "d": 65631,
      "h": 4295032927,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032927)
  ],
  "h": 65631
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ChainedBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ChainedBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65631)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310815)
        $asm.$cls(`$mec.MEC.MemoryConfigurationBuilderExtensions`, ($self) => class MemoryConfigurationBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591245407)
            static /*IConfigurationBuilder */ AddInMemoryCollection$1(/*this IConfigurationBuilder*/ configurationBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                configurationBuilder.MEC$IConfigurationBuilder$Add(new $.$mec.MECM.MemoryConfigurationSource().$ctor$1());
                return configurationBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245407)
            
            //--TRIMMABLE-BOUNDARY-START(4296278111)
            static /*IConfigurationBuilder */ AddInMemoryCollection(/*this IConfigurationBuilder*/ configurationBuilder, /*IEnumerable<KeyValuePair<string, string?>>?*/ initialData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(configurationBuilder, "configurationBuilder");
                configurationBuilder.MEC$IConfigurationBuilder$Add((() =>
                {
                    //new $.$mec.MECM.MemoryConfigurationSource()
                    const $t1 = $.$mec.MECM.MemoryConfigurationSource;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.InitialData = initialData;
                    return $i1;
                })());
                return configurationBuilder;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278111)
            
            static $h = 1310815;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245407),
    {
      "r": 458846,
      "p": [
        {
          "n": "configurationBuilder",
          "p": 458846
        }
      ],
      "n": "AddInMemoryCollection",
      "o": "@$1",
      "d": 1310815,
      "h": 8591245407,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591245407),
//--TRIMMABLE-BOUNDARY-START(4296278111),
    {
      "r": 458846,
      "p": [
        {
          "n": "configurationBuilder",
          "p": 458846
        },
        {
          "n": "initialData",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h
        }
      ],
      "n": "AddInMemoryCollection",
      "d": 1310815,
      "h": 4296278111,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296278111)
  ],
  "h": 1310815
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.MemoryConfigurationBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}MemoryConfigurationBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310815)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835103)
        $asm.$cls(`$mec.MEI.ChangeCallbackRegistrar`, ($self) => class ChangeCallbackRegistrar
        {
            //--TRIMMABLE-BOUNDARY-START(4296802399)
            static /*IDisposable */ UnsafeRegisterChangeCallback(T, /*Action<object?>*/ callback, /*object?*/ state, /*CancellationToken*/ token, /*Action<T>*/ onFailure, /*T*/ onFailureState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    return token.UnsafeRegister$1(callback, state);
                }
                catch($e)
                {
                    onFailure.Invoke(onFailureState);
                }
                return $.$mec.MEF.EmptyDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802399)
            
            static $h = 1835103;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802399),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "token",
          "p": 170852353
        },
        {
          "n": "onFailure",
          "p": (T) => $.$$.S.Action$$(T).$h
        },
        {
          "n": "onFailureState",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "UnsafeRegisterChangeCallback",
      "d": 1835103,
      "h": 4296802399,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4296802399)
  ],
  "h": 1835103
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.ChangeCallbackRegistrar`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}ChangeCallbackRegistrar`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835103)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114207)
        $asm.$cls(`$mec.MEC.InternalConfigurationRootExtensions`, ($self) => class InternalConfigurationRootExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296081503)
            static /*IEnumerable<IConfigurationSection> */ GetChildrenImplementation(/*this IConfigurationRoot*/ root, /*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReferenceCountedProviders?*/ let reference = (($.$as(root, $.$mec.MEC.ConfigurationManager))?.GetProvidersReference() ?? null);
                try
                {
                    /*IEnumerable<IConfigurationProvider>*/ let providers = (reference?.Providers ?? null) ?? root.MEC$IConfigurationRoot$Providers;
                    /*IEnumerable<IConfigurationSection>*/ let children = $.$sl.SL.Enumerable.Select$1($.$$.S.String, $.$mecga.MEC.IConfigurationSection, $.$sl.SL.Enumerable.Distinct($.$$.S.String, $.$sl.SL.Enumerable.Aggregate$1($.$mecga.MEC.IConfigurationProvider, $.$$.SCG.IEnumerable$$($.$$.S.String), providers, $.$sl.SL.Enumerable.Empty($.$$.S.String), new ($.$$.S.Func$$$$($.$$.SCG.IEnumerable$$($.$$.S.String), $.$mecga.MEC.IConfigurationProvider, $.$$.SCG.IEnumerable$$($.$$.S.String)))().$ctor(this,  (/**/ seed, /**/ source) =>
                    {
                        return source.MEC$IConfigurationProvider$GetChildKeys(seed, path);
                    }, $JvzOVi ??= {"r":$.$$.SCG.IEnumerable$$($.$$.S.String).$h,"p":[{"n":"seed","p":$.$$.SCG.IEnumerable$$($.$$.S.String).$h},{"n":"source","p":589918}],"n":"","d":1114207,"h":0,"f":17825794})), $.$$.S.StringComparer.OrdinalIgnoreCase), new ($.$$.S.Func$$$($.$$.S.String, $.$mecga.MEC.IConfigurationSection))().$ctor(this,  (/**/ key) =>
                    {
                        return root.MEC$IConfiguration$GetSection(path === null ? key : $.$strNN($.$strNN(path) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(key));
                    }, $SLApLe ??= {"r":720990,"p":[{"n":"key","p":1310721}],"n":"","d":1114207,"h":0,"f":17825794}));
                    if (reference === null)
                    {
                        return children;
                    }
                    else 
                    {
                        return $.$sl.SL.Enumerable.ToList($.$mecga.MEC.IConfigurationSection, children);
                    }
                }
                finally
                {
                    reference?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081503)
            
            //--TRIMMABLE-BOUNDARY-START(8591048799)
            static /*bool */ TryGetConfiguration(/*this IConfigurationRoot*/ root, /*string*/ key, /*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let list;
                /*IList<IConfigurationProvider>*/ let providers = $.$is(root.MEC$IConfigurationRoot$Providers, $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationProvider), { set $v($v){ list = $v; } }) ? list : $.$sl.SL.Enumerable.ToList($.$mecga.MEC.IConfigurationProvider, root.MEC$IConfigurationRoot$Providers);
                for(/*int*/ let i = ((providers.SCG$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*IConfigurationProvider*/ let provider = providers.SCG$IList$$$get_Item(i);
                    try
                    {
                        if (provider.MEC$IConfigurationProvider$TryGet(key, value))
                        {
                            return true;
                        }
                    }
                    catch($e)
                    {
                    }
                }
                value.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048799)
            
            static $h = 1114207;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081503),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSection).$h,
      "p": [
        {
          "n": "root",
          "p": 655454
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetChildrenImplementation",
      "d": 1114207,
      "h": 4296081503,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296081503),
//--TRIMMABLE-BOUNDARY-START(8591048799),
    {
      "r": 262145,
      "p": [
        {
          "n": "root",
          "p": 655454
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGetConfiguration",
      "d": 1114207,
      "h": 8591048799,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591048799)
  ],
  "h": 1114207
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.InternalConfigurationRootExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}InternalConfigurationRootExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114207)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245279)
        $asm.$cls(`$mec.MECM.MemoryConfigurationSource`, ($self) => class MemoryConfigurationSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771049055)
            /*IEnumerable<KeyValuePair<string, string?>>?*/ InitialData = null;
            //--TRIMMABLE-BOUNDARY-END(25771049055)
            
            //--TRIMMABLE-BOUNDARY-START(12886147167)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886147167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mec.MECM.MemoryConfigurationProvider().$ctor$2(this);
            }
            //--TRIMMABLE-BOUNDARY-END(12886147167)
            
            //--TRIMMABLE-BOUNDARY-START(4295753822)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            MEC$IConfigurationSource$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295753822)
            
            //--TRIMMABLE-BOUNDARY-START(8591179871)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179871)
            
            //--TRIMMABLE-BOUNDARY-START(8591179871)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591179871)
            
            static $h = 1245279;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771049055),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476081759,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360983647,
        "f": 83886081
      },
      "n": "InitialData",
      "d": 1245279,
      "h": 25771049055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771049055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886147167),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 1245279,
      "h": 12886147167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179871),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245279,
      "h": 8591179871,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179871)
  ],
  "h": 1245279
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Memory.MemoryConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Memory${separator}MemoryConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245279)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769567)
        $asm.$cls(`$mec.MEF.EmptyDisposable`, ($self) => class EmptyDisposable extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066540639)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30066540639)
            
            //--TRIMMABLE-BOUNDARY-START(12886671455)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671455);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671455)
            
            //--TRIMMABLE-BOUNDARY-START(17181638751)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181638751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181638751)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12886671455)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886671455)
            
            //--TRIMMABLE-BOUNDARY-START(8591704159)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591704159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30066540639)
                    this.Instance = new $.$mec.MEF.EmptyDisposable().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30066540639)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591704159)
            
            static $h = 1769567;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066540639),
    {
      "p": 1769567,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771573343,
        "f": 50331681
      },
      "n": "Instance",
      "d": 1769567,
      "h": 30066540639,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066540639)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181638751),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1769567,
      "h": 17181638751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638751)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671455),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769567,
      "h": 12886671455,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886671455)
  ],
  "h": 1769567
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769567)
        
        

        //--TRIMMABLE-BOUNDARY-START(262239)
        $asm.$cls(`$mec.MEC.ConfigurationBuilder`, ($self) => class ConfigurationBuilder extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229535)
            /*List<IConfigurationSource>*/ _sources = null;
            //--TRIMMABLE-BOUNDARY-END(4295229535)
            
            //--TRIMMABLE-BOUNDARY-START(47244902495)
            /*IList<IConfigurationSource> */ get Sources()
            {
                return this._sources;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902495)
            
            //--TRIMMABLE-BOUNDARY-START(42949935199)
            /*IDictionary<string, object>*/ Properties = null;
            //--TRIMMABLE-BOUNDARY-END(42949935199)
            
            //--TRIMMABLE-BOUNDARY-START(17180131423)
            /*IConfigurationBuilder */ Add(/*IConfigurationSource*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131423)
            
            //--TRIMMABLE-BOUNDARY-START(21475098719)
            /*IConfigurationRoot */ Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let providers = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider))().$ctor$1();
                let $en1 = this._sources.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let source = $en1.Current;
                    {
                        /*IConfigurationProvider*/ let provider = source.MEC$IConfigurationSource$Build(this);
                        providers.Add(provider);
                    }
                }
                return new $.$mec.MEC.ConfigurationRoot().$ctor$1(providers);
            }
            //--TRIMMABLE-BOUNDARY-END(21475098719)
            
            //--TRIMMABLE-BOUNDARY-START(17180328030)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Properties.get
            get MEC$IConfigurationBuilder$Properties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Properties;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328030)
            
            //--TRIMMABLE-BOUNDARY-START(25770262622)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Sources.get
            get MEC$IConfigurationBuilder$Sources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sources;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262622)
            
            //--TRIMMABLE-BOUNDARY-START(4295426142)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
            MEC$IConfigurationBuilder$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426142)
            
            //--TRIMMABLE-BOUNDARY-START(8590393438)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Build()
            MEC$IConfigurationBuilder$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393438)
            
            //--TRIMMABLE-BOUNDARY-START(12885164127)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164127)
            
            //--TRIMMABLE-BOUNDARY-START(12885164127)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885164127)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295229535)
                this._sources = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295229535)
                
                //--TRIMMABLE-BOUNDARY-START(42949935199)
                this.Properties = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(42949935199)
                
            }
            static $h = 262239;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244902495),
    {
      "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967903,
        "f": 50331649
      },
      "n": "Sources",
      "d": 262239,
      "h": 47244902495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244902495),
//--TRIMMABLE-BOUNDARY-START(42949935199),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033311,
        "f": 50331649
      },
      "n": "Properties",
      "d": 262239,
      "h": 42949935199,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949935199)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131423),
    {
      "r": 458846,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "d": 262239,
      "h": 17180131423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131423),
//--TRIMMABLE-BOUNDARY-START(21475098719),
    {
      "r": 655454,
      "n": "Build",
      "d": 262239,
      "h": 21475098719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098719)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229535),
    {
      "t": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource).$h,
      "n": "_sources",
      "d": 262239,
      "h": 4295229535,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885164127),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262239,
      "h": 12885164127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164127)
  ],
  "h": 262239
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationBuilder ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262239)
        
        

        //--TRIMMABLE-BOUNDARY-START(196703)
        $asm.$cls(`$mec.MEC.ChainedConfigurationSource`, ($self) => class ChainedConfigurationSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475033183)
            /*IConfiguration?*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(21475033183)
            
            //--TRIMMABLE-BOUNDARY-START(60129738847)
            /*bool*/ ShouldDisposeConfiguration = false;
            //--TRIMMABLE-BOUNDARY-END(60129738847)
            
            //--TRIMMABLE-BOUNDARY-START(17180065887)
            /*IConfigurationProvider */ Build(/*IConfigurationBuilder*/ builder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ChainedConfigurationProvider().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180065887)
            
            //--TRIMMABLE-BOUNDARY-START(4295753822)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSource.Build(Microsoft.Extensions.Configuration.IConfigurationBuilder)
            MEC$IConfigurationSource$Build()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295753822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Build(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295753822)
            
            //--TRIMMABLE-BOUNDARY-START(12885098591)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098591)
            
            //--TRIMMABLE-BOUNDARY-START(12885098591)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098591)
            
            static $h = 196703;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475033183),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47244836959,
        "f": 83886081
      },
      "n": "Configuration",
      "d": 196703,
      "h": 21475033183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475033183),
//--TRIMMABLE-BOUNDARY-START(60129738847),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902367,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55834771551,
        "f": 83886081
      },
      "n": "ShouldDisposeConfiguration",
      "d": 196703,
      "h": 60129738847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129738847)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065887),
    {
      "r": 589918,
      "p": [
        {
          "n": "builder",
          "p": 458846
        }
      ],
      "n": "Build",
      "d": 196703,
      "h": 17180065887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065887)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098591),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196703,
      "h": 12885098591,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098591)
  ],
  "h": 196703
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSource ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ChainedConfigurationSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ChainedConfigurationSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196703)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376351)
        $asm.$cls(`$mec.MEC.ReferenceCountedProviderManager`, ($self) => class ReferenceCountedProviderManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12886278239)
            /*object*/ _replaceProvidersLock = null;
            //--TRIMMABLE-BOUNDARY-END(12886278239)
            
            //--TRIMMABLE-BOUNDARY-START(8591310943)
            /*ReferenceCountedProviders*/ _refCountedProviders = null;
            //--TRIMMABLE-BOUNDARY-END(8591310943)
            
            //--TRIMMABLE-BOUNDARY-START(4296343647)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(4296343647)
            
            //--TRIMMABLE-BOUNDARY-START(42951049311)
            /*IEnumerable<IConfigurationProvider> */ get NonReferenceCountedProviders()
            {
                return this._refCountedProviders.NonReferenceCountedProviders;
            }
            //--TRIMMABLE-BOUNDARY-END(42951049311)
            
            //--TRIMMABLE-BOUNDARY-START(38656082015)
            /*ReferenceCountedProviders */ GetReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656082015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_replaceProvidersLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            return $.$mec.MEC.ReferenceCountedProviders.CreateDisposed(this._refCountedProviders.NonReferenceCountedProviders);
                        }
                        this._refCountedProviders.AddReference();
                        return this._refCountedProviders;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._replaceProvidersLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656082015)
            
            //--TRIMMABLE-BOUNDARY-START(47246016607)
            /*void */ ReplaceProviders(/*List<IConfigurationProvider>*/ providers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246016607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReferenceCountedProviders*/ let oldRefCountedProviders = this._refCountedProviders;
                //lock(_replaceProvidersLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            throw new $.$$.S.ObjectDisposedException().$ctor$17("ConfigurationManager");
                        }
                        this._refCountedProviders = $.$mec.MEC.ReferenceCountedProviders.Create(providers);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._replaceProvidersLock)
                }
                oldRefCountedProviders.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(47246016607)
            
            //--TRIMMABLE-BOUNDARY-START(21476212831)
            /*void */ AddProvider(/*IConfigurationProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(_replaceProvidersLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        if (this._disposed)
                        {
                            throw new $.$$.S.ObjectDisposedException().$ctor$17("ConfigurationManager");
                        }
                        this._refCountedProviders.Providers = (() =>
                        {
                            //new $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider)()
                            const $t1 = $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider);
                            const $i1 = new $t1();
                            $i1.$ctor$2(this._refCountedProviders.Providers);
                            $i1.Add(provider);
                            return $i1;
                        })();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._replaceProvidersLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476212831)
            
            //--TRIMMABLE-BOUNDARY-START(25771180127)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReferenceCountedProviders*/ let oldRefCountedProviders = this._refCountedProviders;
                //lock(_replaceProvidersLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this._replaceProvidersLock)
                    {
                        this._disposed = true;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this._replaceProvidersLock)
                }
                oldRefCountedProviders.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(25771180127)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(17181245535)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181245535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181245535)
            
            //--TRIMMABLE-BOUNDARY-START(17181245535)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17181245535)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12886278239)
                this._replaceProvidersLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(12886278239)
                
                //--TRIMMABLE-BOUNDARY-START(8591310943)
                this._refCountedProviders = $.$mec.MEC.ReferenceCountedProviders.Create(new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider))().$ctor$1());
                //--TRIMMABLE-BOUNDARY-END(8591310943)
                
            }
            static $h = 1376351;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951049311),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361114719,
        "f": 50331649
      },
      "n": "NonReferenceCountedProviders",
      "d": 1376351,
      "h": 42951049311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951049311)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38656082015),
    {
      "r": 1441887,
      "n": "GetReference",
      "d": 1376351,
      "h": 38656082015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656082015),
//--TRIMMABLE-BOUNDARY-START(47246016607),
    {
      "r": 65537,
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": "ReplaceProviders",
      "d": 1376351,
      "h": 47246016607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246016607),
//--TRIMMABLE-BOUNDARY-START(21476212831),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 589918
        }
      ],
      "n": "AddProvider",
      "d": 1376351,
      "h": 21476212831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476212831),
//--TRIMMABLE-BOUNDARY-START(25771180127),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1376351,
      "h": 25771180127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180127)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886278239),
    {
      "t": 131073,
      "n": "_replaceProvidersLock",
      "d": 1376351,
      "h": 12886278239,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886278239),
//--TRIMMABLE-BOUNDARY-START(8591310943),
    {
      "t": 1441887,
      "n": "_refCountedProviders",
      "d": 1376351,
      "h": 8591310943,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591310943),
//--TRIMMABLE-BOUNDARY-START(4296343647),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1376351,
      "h": 4296343647,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343647)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181245535),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376351,
      "h": 17181245535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245535)
  ],
  "h": 1376351
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ReferenceCountedProviderManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ReferenceCountedProviderManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376351)
        
        

        //--TRIMMABLE-BOUNDARY-START(720991)
        $asm.$cls(`$mec.MEC.ConfigurationReloadToken`, ($self) => class ConfigurationReloadToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688287)
            /*CancellationTokenSource*/ _cts = null;
            //--TRIMMABLE-BOUNDARY-END(4295688287)
            
            //--TRIMMABLE-BOUNDARY-START(17180590175)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(17180590175)
            
            //--TRIMMABLE-BOUNDARY-START(38655426655)
            /*bool */ get HasChanged()
            {
                return this._cts.IsCancellationRequested;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426655)
            
            //--TRIMMABLE-BOUNDARY-START(47245361247)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mec.MEI.ChangeCallbackRegistrar.UnsafeRegisterChangeCallback($.$mec.MEC.ConfigurationReloadToken, callback, state, this._cts.Token, new ($.$$.S.Action$$($.$mec.MEC.ConfigurationReloadToken))().$ctor($.$mec.MEC.ConfigurationReloadToken, /*static*/ (/*s*/ s) =>
                {
                    return s.ActiveChangeCallbacks = false;
                }, $kXZzzf ??= {"r":65537,"p":[{"n":"s","p":720991}],"n":"","d":720991,"h":0,"f":17825826}), this);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361247)
            
            //--TRIMMABLE-BOUNDARY-START(42950393951)
            /*void */ OnReload()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._cts.Cancel();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393951)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            MEP$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //--TRIMMABLE-BOUNDARY-START(12885622879)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622879)
            
            //--TRIMMABLE-BOUNDARY-START(12885622879)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885622879)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688287)
                this._cts = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295688287)
                
                //--TRIMMABLE-BOUNDARY-START(17180590175)
                this.ActiveChangeCallbacks = true;
                //--TRIMMABLE-BOUNDARY-END(17180590175)
                
            }
            static $h = 720991;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180590175),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770524767,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55835295839,
        "f": 83886082
      },
      "n": "ActiveChangeCallbacks",
      "d": 720991,
      "h": 17180590175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180590175),
//--TRIMMABLE-BOUNDARY-START(38655426655),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360459359,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 720991,
      "h": 38655426655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655426655)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245361247),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 720991,
      "h": 47245361247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361247),
//--TRIMMABLE-BOUNDARY-START(42950393951),
    {
      "r": 65537,
      "n": "OnReload",
      "d": 720991,
      "h": 42950393951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393951)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688287),
    {
      "t": 170983425,
      "n": "_cts",
      "d": 720991,
      "h": 4295688287,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688287)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622879),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720991,
      "h": 12885622879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622879)
  ],
  "h": 720991
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationReloadToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationReloadToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720991)
        
        

        //--TRIMMABLE-BOUNDARY-START(131167)
        $asm.$cls(`$mec.MEC.ChainedConfigurationProvider`, ($self) => class ChainedConfigurationProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098463)
            /*IConfiguration*/ _config = null;
            //--TRIMMABLE-BOUNDARY-END(4295098463)
            
            //--TRIMMABLE-BOUNDARY-START(8590065759)
            /*bool*/ _shouldDisposeConfig = false;
            //--TRIMMABLE-BOUNDARY-END(8590065759)
            
            //--TRIMMABLE-BOUNDARY-START(12885033055)
            $ctor$1(/*ChainedConfigurationSource*/ source)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033055);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this._config = $.$firstOf(source.Configuration, () => { throw new $.$$.S.ArgumentException().$ctor$13($.$mec.S.SR.Format$6($.$mec.S.SR.InvalidNullArgument, "source.Configuration"), "source") });
                    this._shouldDisposeConfig = source.ShouldDisposeConfiguration;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033055)
            
            //--TRIMMABLE-BOUNDARY-START(17180000351)
            /*IConfiguration */ get Configuration()
            {
                return this._config;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000351)
            
            //--TRIMMABLE-BOUNDARY-START(51539738719)
            /*bool */ TryGet(/*string*/ key, /*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                value.$v = this._config.MEC$IConfiguration$get_Item(key);
                return !$.$$.S.String.IsNullOrEmpty(value.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(51539738719)
            
            //--TRIMMABLE-BOUNDARY-START(47244771423)
            /*void */ Set(/*string*/ key, /*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771423);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let $t1;
                    return this._config.MEC$IConfiguration$set_Item(key, $t1 = (value)), $t1;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244771423)
            
            //--TRIMMABLE-BOUNDARY-START(38654836831)
            /*IChangeToken */ GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654836831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._config.MEC$IConfiguration$GetReloadToken();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654836831)
            
            //--TRIMMABLE-BOUNDARY-START(42949804127)
            /*void */ Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42949804127)
            
            //--TRIMMABLE-BOUNDARY-START(34359869535)
            /*IEnumerable<string> */ GetChildKeys(/*IEnumerable<string>*/ earlierKeys, /*string?*/ parentPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IConfiguration*/ let section = parentPath === null ? this._config : this._config.MEC$IConfiguration$GetSection(parentPath);
                /*var*/ let keys = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                let $en2 = section.MEC$IConfiguration$GetChildren().SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let child = $en2.SCG$IEnumerator$$$Current;
                    {
                        keys.Add(child.MEC$IConfigurationSection$Key);
                    }
                }
                keys.AddRange(earlierKeys);
                keys.Sort$2($.$mec.MEC.ConfigurationKeyComparer.Comparison);
                return keys;
            }
            //--TRIMMABLE-BOUNDARY-END(34359869535)
            
            //--TRIMMABLE-BOUNDARY-START(21474967647)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._shouldDisposeConfig)
                {
                    ($.$as(this._config, $.$$.S.IDisposable))?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474967647)
            
            //--TRIMMABLE-BOUNDARY-START(21475426398)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.TryGet(string, out string?)
            MEC$IConfigurationProvider$TryGet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGet(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426398)
            
            //--TRIMMABLE-BOUNDARY-START(17180459102)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Set(string, string?)
            MEC$IConfigurationProvider$Set()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Set(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459102)
            
            //--TRIMMABLE-BOUNDARY-START(8590524510)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetReloadToken()
            MEC$IConfigurationProvider$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590524510)
            
            //--TRIMMABLE-BOUNDARY-START(12885491806)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.Load()
            MEC$IConfigurationProvider$Load()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Load(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885491806)
            
            //--TRIMMABLE-BOUNDARY-START(4295557214)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationProvider.GetChildKeys(System.Collections.Generic.IEnumerable<string>, string?)
            MEC$IConfigurationProvider$GetChildKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildKeys(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295557214)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 131167;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000351),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902239,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 131167,
      "h": 17180000351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000351)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539738719),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGet",
      "d": 131167,
      "h": 51539738719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539738719),
//--TRIMMABLE-BOUNDARY-START(47244771423),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "d": 131167,
      "h": 47244771423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244771423),
//--TRIMMABLE-BOUNDARY-START(38654836831),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 131167,
      "h": 38654836831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654836831),
//--TRIMMABLE-BOUNDARY-START(42949804127),
    {
      "r": 65537,
      "n": "Load",
      "d": 131167,
      "h": 42949804127,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949804127),
//--TRIMMABLE-BOUNDARY-START(34359869535),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "earlierKeys",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "parentPath",
          "p": 1310721
        }
      ],
      "n": "GetChildKeys",
      "d": 131167,
      "h": 34359869535,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359869535),
//--TRIMMABLE-BOUNDARY-START(21474967647),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 131167,
      "h": 21474967647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474967647)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098463),
    {
      "t": 393310,
      "n": "_config",
      "d": 131167,
      "h": 4295098463,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098463),
//--TRIMMABLE-BOUNDARY-START(8590065759),
    {
      "t": 262145,
      "n": "_shouldDisposeConfig",
      "d": 131167,
      "h": 8590065759,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065759)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033055),
    {
      "p": [
        {
          "n": "source",
          "p": 196703
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131167,
      "h": 12885033055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033055)
  ],
  "h": 131167
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ChainedConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ChainedConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131167)
        
        

        //--TRIMMABLE-BOUNDARY-START(917599)
        $asm.$cls(`$mec.MEC.ConfigurationSection`, ($self) => class ConfigurationSection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885819487)
            /*IConfigurationRoot*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(12885819487)
            
            //--TRIMMABLE-BOUNDARY-START(8590852191)
            /*string*/ _path = null;
            //--TRIMMABLE-BOUNDARY-END(8590852191)
            
            //--TRIMMABLE-BOUNDARY-START(4295884895)
            /*string?*/ _key = null;
            //--TRIMMABLE-BOUNDARY-END(4295884895)
            
            //--TRIMMABLE-BOUNDARY-START(17180786783)
            $ctor$1(/*IConfigurationRoot*/ root, /*string*/ path)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(root, "root");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(path, "path");
                    this._root = root;
                    this._path = path;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786783)
            
            //--TRIMMABLE-BOUNDARY-START(77310328927)
            /*string */ get Path()
            {
                return this._path;
            }
            //--TRIMMABLE-BOUNDARY-END(77310328927)
            
            //--TRIMMABLE-BOUNDARY-START(73015361631)
            /*string */ get Key()
            {
                return this._key ??= $.$mecga.MEC.ConfigurationPath.GetSectionKey(this._path);
            }
            //--TRIMMABLE-BOUNDARY-END(73015361631)
            
            //--TRIMMABLE-BOUNDARY-START(107375099999)
            /*string? */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._root.MEC$IConfiguration$get_Item(this.Path);
            }
            /*string? */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._root.MEC$IConfiguration$set_Item(this.Path, value);
            }
            //--TRIMMABLE-BOUNDARY-END(107375099999)
            
            //--TRIMMABLE-BOUNDARY-START(103080132703)
            /*bool */ TryGetValue(/*string?*/ key, /*out string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080132703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let path = key === null ? this.Path : $.$strNN($.$strNN(this.Path) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(key);
                if ($.$mec.MEC.InternalConfigurationRootExtensions.TryGetConfiguration(this._root, path, value))
                {
                    return true;
                }
                value.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(103080132703)
            
            //--TRIMMABLE-BOUNDARY-START(98785165407)
            /*string?*/ get_Item$1(/*string*/ key)
            {
                return this._root.MEC$IConfiguration$get_Item($.$strNN($.$strNN(this.Path) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(key));
            }
            /*void*/ set_Item$1(/*string*/ key, /*string?*/ value)
            {
                this._root.MEC$IConfiguration$set_Item($.$strNN($.$strNN(this.Path) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(key), value);
            }
            //--TRIMMABLE-BOUNDARY-END(98785165407)
            
            //--TRIMMABLE-BOUNDARY-START(68720394335)
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720394335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._root.MEC$IConfiguration$GetSection($.$strNN($.$strNN(this.Path) + $.$strNN($.$mecga.MEC.ConfigurationPath.KeyDelimiter)) + $.$strNN(key));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720394335)
            
            //--TRIMMABLE-BOUNDARY-START(60130459743)
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130459743);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mec.MEC.InternalConfigurationRootExtensions.GetChildrenImplementation(this._root, this.Path);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130459743)
            
            //--TRIMMABLE-BOUNDARY-START(64425427039)
            /*IChangeToken */ GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425427039);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._root.MEC$IConfiguration$GetReloadToken();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425427039)
            
            //--TRIMMABLE-BOUNDARY-START(21475754079)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let s = `Path = ${$.$strNN(this.Path)}`;
                /*var*/ let childCount = /*$.$mec.MEC.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this._root).Count;
                if (childCount > 0)
                {
                    s += `, Sections = ${$.$strNN(childCount)}`;
                }
                if (!(this.Value === null))
                {
                    s += `, Value = ${$.$strNN(this.Value)}`;
                    /*IConfigurationProvider?*/ let provider = /*$.$mec.MEC.ConfigurationSectionDebugView*/$.$$.DeletedObject.GetValueProvider(this._root, this.Path);
                    if (provider !== null)
                    {
                        s += `, Provider = ${$.$strNN($.$dspc(provider, $.$$.S.Object, ($t) => $t.ToString))}`;
                    }
                }
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754079)
            
            //--TRIMMABLE-BOUNDARY-START(8590655582)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Key.get
            get MEC$IConfigurationSection$Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Key;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655582)
            
            //--TRIMMABLE-BOUNDARY-START(17180590174)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Path.get
            get MEC$IConfigurationSection$Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Path;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590174)
            
            //--TRIMMABLE-BOUNDARY-START(25770524766)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Value.get
            get MEC$IConfigurationSection$Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524766)
            
            //--TRIMMABLE-BOUNDARY-START(42950393950)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationSection.Value.set
            set MEC$IConfigurationSection$Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393950)
            
            //--TRIMMABLE-BOUNDARY-START(8590327902)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            MEC$IConfiguration$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327902)
            
            //--TRIMMABLE-BOUNDARY-START(30065164382)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            MEC$IConfiguration$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164382)
            
            //--TRIMMABLE-BOUNDARY-START(21475229790)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            MEC$IConfiguration$GetSection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSection(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229790)
            
            //--TRIMMABLE-BOUNDARY-START(12885295198)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            MEC$IConfiguration$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295198)
            
            //--TRIMMABLE-BOUNDARY-START(17180262494)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            MEC$IConfiguration$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262494)
            
            static $h = 917599;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310328927),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557855,
        "f": 50331649
      },
      "n": "Path",
      "d": 917599,
      "h": 77310328927,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310328927),
//--TRIMMABLE-BOUNDARY-START(73015361631),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655623263,
        "f": 50331649
      },
      "n": "Key",
      "d": 917599,
      "h": 73015361631,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015361631),
//--TRIMMABLE-BOUNDARY-START(107375099999),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835492447,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94490198111,
        "f": 83886081
      },
      "n": "Value",
      "d": 917599,
      "h": 107375099999,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375099999),
//--TRIMMABLE-BOUNDARY-START(98785165407),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065688671,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85900263519,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 917599,
      "h": 98785165407,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(98785165407)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(103080132703),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 917599,
      "h": 103080132703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080132703),
//--TRIMMABLE-BOUNDARY-START(68720394335),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "d": 917599,
      "h": 68720394335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720394335),
//--TRIMMABLE-BOUNDARY-START(60130459743),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSection).$h,
      "n": "GetChildren",
      "d": 917599,
      "h": 60130459743,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459743),
//--TRIMMABLE-BOUNDARY-START(64425427039),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 917599,
      "h": 64425427039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425427039),
//--TRIMMABLE-BOUNDARY-START(21475754079),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 917599,
      "h": 21475754079,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475754079)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885819487),
    {
      "t": 655454,
      "n": "_root",
      "d": 917599,
      "h": 12885819487,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819487),
//--TRIMMABLE-BOUNDARY-START(8590852191),
    {
      "t": 1310721,
      "n": "_path",
      "d": 917599,
      "h": 8590852191,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852191),
//--TRIMMABLE-BOUNDARY-START(4295884895),
    {
      "t": 1310721,
      "n": "_key",
      "d": 917599,
      "h": 4295884895,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884895)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786783),
    {
      "p": [
        {
          "n": "root",
          "p": 655454
        },
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917599,
      "h": 17180786783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786783)
  ],
  "h": 917599,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationSection, $.$mecga.MEC.IConfiguration ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$mec.MEC.ConfigurationSection.ConfigurationSectionDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationSection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationSection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917599)
        
        

        //--TRIMMABLE-BOUNDARY-START(786527)
        $asm.$cls(`$mec.MEC.ConfigurationRoot`, ($self) => class ConfigurationRoot extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885688415)
            /*IList<IConfigurationProvider>*/ _providers = null;
            //--TRIMMABLE-BOUNDARY-END(12885688415)
            
            //--TRIMMABLE-BOUNDARY-START(8590721119)
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(8590721119)
            
            //--TRIMMABLE-BOUNDARY-START(4295753823)
            /*ConfigurationReloadToken*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295753823)
            
            //--TRIMMABLE-BOUNDARY-START(17180655711)
            $ctor$1(/*IList<IConfigurationProvider>*/ providers)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(providers, "providers");
                    this._providers = providers;
                    this._changeTokenRegistrations = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$3(providers.SCG$ICollection$$$Count);
                    let $en1 = providers.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let p = $en1.SCG$IEnumerator$$$Current;
                        {
                            p.MEC$IConfigurationProvider$Load();
                            this._changeTokenRegistrations.Add($.$mep.MEP.ChangeToken.OnChange(new ($.$$.S.Func$$($.$mep.MEP.IChangeToken))().$ctor(p, p.MEC$IConfigurationProvider$GetReloadToken), new $.$$.S.Action().$ctor(this, this.RaiseChanged)));
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655711)
            
            //--TRIMMABLE-BOUNDARY-START(64425295967)
            /*IEnumerable<IConfigurationProvider> */ get Providers()
            {
                return this._providers;
            }
            //--TRIMMABLE-BOUNDARY-END(64425295967)
            
            //--TRIMMABLE-BOUNDARY-START(90195099743)
            /*string?*/ get_Item$1(/*string*/ key)
            {
                return $.$mec.MEC.ConfigurationRoot.GetConfiguration(this._providers, key);
            }
            /*void*/ set_Item$1(/*string*/ key, /*string?*/ value)
            {
                $.$mec.MEC.ConfigurationRoot.SetConfiguration(this._providers, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(90195099743)
            
            //--TRIMMABLE-BOUNDARY-START(47245426783)
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245426783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mec.MEC.InternalConfigurationRootExtensions.GetChildrenImplementation(this, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245426783)
            
            //--TRIMMABLE-BOUNDARY-START(55835361375)
            /*IChangeToken */ GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835361375);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._changeToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835361375)
            
            //--TRIMMABLE-BOUNDARY-START(60130328671)
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130328671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ConfigurationSection().$ctor$1(this, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130328671)
            
            //--TRIMMABLE-BOUNDARY-START(73015230559)
            /*void */ Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015230559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en2 = this._providers.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let provider = $en2.SCG$IEnumerator$$$Current;
                    {
                        provider.MEC$IConfigurationProvider$Load();
                    }
                }
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(73015230559)
            
            //--TRIMMABLE-BOUNDARY-START(68720263263)
            /*void */ RaiseChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConfigurationReloadToken*/ let previousToken = $.$$.ST$1.Interlocked.Exchange$14($.$mec.MEC.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.MEC.ConfigurationReloadToken), new $.$mec.MEC.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(68720263263)
            
            //--TRIMMABLE-BOUNDARY-START(25770590303)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en4 = this._changeTokenRegistrations.GetEnumerator();
                while ($en4.MoveNext())
                {
                    let registration = $en4.Current;
                    {
                        registration.S$IDisposable$Dispose();
                    }
                }
                let $en5 = this._providers.SCG$IEnumerable$$$GetEnumerator();
                while ($en5.SC$1$IEnumerator$MoveNext())
                {
                    let provider = $en5.SCG$IEnumerator$$$Current;
                    {
                        ($.$as(provider, $.$$.S.IDisposable))?.S$IDisposable$Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590303)
            
            //--TRIMMABLE-BOUNDARY-START(51540394079)
            static /*string? */ GetConfiguration(/*IList<IConfigurationProvider>*/ providers, /*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = ((providers.SCG$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*string?*/ let value;
                    /*IConfigurationProvider*/ let provider = providers.SCG$IList$$$get_Item(i);
                    if (provider.MEC$IConfigurationProvider$TryGet(key, $.$ref(() => value, ($v) => value = $v, $.$$.S.String)))
                    {
                        return value;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(51540394079)
            
            //--TRIMMABLE-BOUNDARY-START(85900132447)
            static /*void */ SetConfiguration(/*IList<IConfigurationProvider>*/ providers, /*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900132447);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (providers.SCG$ICollection$$$Count === 0)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mec.S.SR.Error_NoSources);
                }
                let $en7 = providers.SCG$IEnumerable$$$GetEnumerator();
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let provider = $en7.SCG$IEnumerator$$$Current;
                    {
                        provider.MEC$IConfigurationProvider$Set(key, value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900132447)
            
            //--TRIMMABLE-BOUNDARY-START(21475623007)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475623007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Sections = ${$.$strNN(/*$.$mec.MEC.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this).Count)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623007)
            
            //--TRIMMABLE-BOUNDARY-START(17180524638)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Reload()
            MEC$IConfigurationRoot$Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Reload(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524638)
            
            //--TRIMMABLE-BOUNDARY-START(8590590046)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationRoot.Providers.get
            get MEC$IConfigurationRoot$Providers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Providers;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590046)
            
            //--TRIMMABLE-BOUNDARY-START(8590327902)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            MEC$IConfiguration$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327902)
            
            //--TRIMMABLE-BOUNDARY-START(30065164382)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            MEC$IConfiguration$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164382)
            
            //--TRIMMABLE-BOUNDARY-START(21475229790)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            MEC$IConfiguration$GetSection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSection(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229790)
            
            //--TRIMMABLE-BOUNDARY-START(12885295198)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            MEC$IConfiguration$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295198)
            
            //--TRIMMABLE-BOUNDARY-START(17180262494)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetReloadToken()
            MEC$IConfiguration$GetReloadToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetReloadToken(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180262494)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295753823)
                this._changeToken = new $.$mec.MEC.ConfigurationReloadToken().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295753823)
                
            }
            static $h = 786527;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425295967),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950459487,
        "f": 50331649
      },
      "n": "Providers",
      "d": 786527,
      "h": 64425295967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425295967),
//--TRIMMABLE-BOUNDARY-START(90195099743),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360524895,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605165151,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 786527,
      "h": 90195099743,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(90195099743)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245426783),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSection).$h,
      "n": "GetChildren",
      "d": 786527,
      "h": 47245426783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245426783),
//--TRIMMABLE-BOUNDARY-START(55835361375),
    {
      "r": 720981,
      "n": "GetReloadToken",
      "d": 786527,
      "h": 55835361375,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835361375),
//--TRIMMABLE-BOUNDARY-START(60130328671),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "d": 786527,
      "h": 60130328671,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130328671),
//--TRIMMABLE-BOUNDARY-START(73015230559),
    {
      "r": 65537,
      "n": "Reload",
      "d": 786527,
      "h": 73015230559,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015230559),
//--TRIMMABLE-BOUNDARY-START(68720263263),
    {
      "r": 65537,
      "n": "RaiseChanged",
      "d": 786527,
      "h": 68720263263,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720263263),
//--TRIMMABLE-BOUNDARY-START(25770590303),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 786527,
      "h": 25770590303,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590303),
//--TRIMMABLE-BOUNDARY-START(51540394079),
    {
      "r": 1310721,
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationProvider).$h
        },
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetConfiguration",
      "d": 786527,
      "h": 51540394079,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540394079),
//--TRIMMABLE-BOUNDARY-START(85900132447),
    {
      "r": 65537,
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationProvider).$h
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "SetConfiguration",
      "d": 786527,
      "h": 85900132447,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(85900132447),
//--TRIMMABLE-BOUNDARY-START(21475623007),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 786527,
      "h": 21475623007,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475623007)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885688415),
    {
      "t": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationProvider).$h,
      "n": "_providers",
      "d": 786527,
      "h": 12885688415,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688415),
//--TRIMMABLE-BOUNDARY-START(8590721119),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_changeTokenRegistrations",
      "d": 786527,
      "h": 8590721119,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721119),
//--TRIMMABLE-BOUNDARY-START(4295753823),
    {
      "t": 720991,
      "n": "_changeToken",
      "d": 786527,
      "h": 4295753823,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753823)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180655711),
    {
      "p": [
        {
          "n": "providers",
          "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationProvider).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786527,
      "h": 17180655711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655711)
  ],
  "h": 786527,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationRoot, $.$mecga.MEC.IConfiguration, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$mec.MEC.ConfigurationRoot.ConfigurationRootDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationRoot`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationRoot`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786527)
        
        

        //--TRIMMABLE-BOUNDARY-START(393311)
        $asm.$cls(`$mec.MEC.ConfigurationManager`, ($self) => class ConfigurationManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475229791)
            /*ConfigurationSources*/ _sources = null;
            //--TRIMMABLE-BOUNDARY-END(21475229791)
            
            //--TRIMMABLE-BOUNDARY-START(12885295199)
            /*ConfigurationBuilderProperties*/ _properties = null;
            //--TRIMMABLE-BOUNDARY-END(12885295199)
            
            //--TRIMMABLE-BOUNDARY-START(17180262495)
            /*ReferenceCountedProviderManager*/ _providerManager = null;
            //--TRIMMABLE-BOUNDARY-END(17180262495)
            
            //--TRIMMABLE-BOUNDARY-START(8590327903)
            /*List<IDisposable>*/ _changeTokenRegistrations = null;
            //--TRIMMABLE-BOUNDARY-END(8590327903)
            
            //--TRIMMABLE-BOUNDARY-START(4295360607)
            /*ConfigurationReloadToken*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295360607)
            
            //--TRIMMABLE-BOUNDARY-START(25770197087)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197087);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._sources = new $.$mec.MEC.ConfigurationManager.ConfigurationSources().$ctor$1(this);
                    this._properties = new $.$mec.MEC.ConfigurationManager.ConfigurationBuilderProperties().$ctor$1(this);
                    this._sources.Add(new $.$mec.MECM.MemoryConfigurationSource().$ctor$1());
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770197087)
            
            //--TRIMMABLE-BOUNDARY-START(141734314079)
            /*string?*/ get_Item$1(/*string*/ key)
            {
                /*ReferenceCountedProviders*/ let reference = this._providerManager.GetReference();
                try
                {
                    return $.$mec.MEC.ConfigurationRoot.GetConfiguration(reference.Providers, key);
                }
                finally
                {
                    reference?.S$IDisposable$Dispose();
                }
            }
            /*void*/ set_Item$1(/*string*/ key, /*string?*/ value)
            {
                /*ReferenceCountedProviders*/ let reference = this._providerManager.GetReference();
                try
                {
                    $.$mec.MEC.ConfigurationRoot.SetConfiguration(reference.Providers, key, value);
                }
                finally
                {
                    reference?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734314079)
            
            //--TRIMMABLE-BOUNDARY-START(73014837343)
            /*IConfigurationSection */ GetSection(/*string*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014837343);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mec.MEC.ConfigurationSection().$ctor$1(this, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837343)
            
            //--TRIMMABLE-BOUNDARY-START(64424902751)
            /*IEnumerable<IConfigurationSection> */ GetChildren()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424902751);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mec.MEC.InternalConfigurationRootExtensions.GetChildrenImplementation(this, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424902751)
            
            //--TRIMMABLE-BOUNDARY-START(98784641119)
            /*IDictionary<string, object> */ get MEC$IConfigurationBuilder$Properties()
            {
                return this._properties;
            }
            //--TRIMMABLE-BOUNDARY-END(98784641119)
            
            //--TRIMMABLE-BOUNDARY-START(137439346783)
            /*IList<IConfigurationSource> */ get Sources()
            {
                return this._sources;
            }
            //--TRIMMABLE-BOUNDARY-END(137439346783)
            
            //--TRIMMABLE-BOUNDARY-START(111669543007)
            /*IEnumerable<IConfigurationProvider> */ get MEC$IConfigurationRoot$Providers()
            {
                return this._providerManager.NonReferenceCountedProviders;
            }
            //--TRIMMABLE-BOUNDARY-END(111669543007)
            
            //--TRIMMABLE-BOUNDARY-START(38655098975)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeRegistrations();
                this._providerManager.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(38655098975)
            
            //--TRIMMABLE-BOUNDARY-START(81604771935)
            /*IConfigurationBuilder */ MEC$IConfigurationBuilder$Add(/*IConfigurationSource*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                this._sources.Add(source);
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771935)
            
            //--TRIMMABLE-BOUNDARY-START(85899739231)
            /*IConfigurationRoot */ MEC$IConfigurationBuilder$Build()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899739231);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899739231)
            
            //--TRIMMABLE-BOUNDARY-START(77309804639)
            /*IChangeToken */ MEC$IConfiguration$GetReloadToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309804639);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._changeToken;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309804639)
            
            //--TRIMMABLE-BOUNDARY-START(115964510303)
            /*void */ MEC$IConfigurationRoot$Reload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let reference = null;
                try
                {
                    reference = this._providerManager.GetReference();
                    let $en1 = reference.Providers.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let provider = $en1.Current;
                        {
                            provider.MEC$IConfigurationProvider$Load();
                        }
                    }
                }
                finally
                {
                    reference?.S$IDisposable$Dispose();
                }
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(115964510303)
            
            //--TRIMMABLE-BOUNDARY-START(68719870047)
            /*ReferenceCountedProviders */ GetProvidersReference()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719870047);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._providerManager.GetReference();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719870047)
            
            //--TRIMMABLE-BOUNDARY-START(120259477599)
            /*void */ RaiseChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259477599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let previousToken = $.$$.ST$1.Interlocked.Exchange$14($.$mec.MEC.ConfigurationReloadToken, $.$ref(() => this._changeToken, ($v) => this._changeToken = $v, $.$mec.MEC.ConfigurationReloadToken), new $.$mec.MEC.ConfigurationReloadToken().$ctor$1());
                previousToken.OnReload();
            }
            //--TRIMMABLE-BOUNDARY-END(120259477599)
            
            //--TRIMMABLE-BOUNDARY-START(30065164383)
            /*void */ AddSource(/*IConfigurationSource*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IConfigurationProvider*/ let provider = source.MEC$IConfigurationSource$Build(this);
                provider.MEC$IConfigurationProvider$Load();
                this._changeTokenRegistrations.Add($.$mep.MEP.ChangeToken.OnChange(new ($.$$.S.Func$$($.$mep.MEP.IChangeToken))().$ctor(provider, provider.MEC$IConfigurationProvider$GetReloadToken), new $.$$.S.Action().$ctor(this, this.RaiseChanged)));
                this._providerManager.AddProvider(provider);
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(30065164383)
            
            //--TRIMMABLE-BOUNDARY-START(124554444895)
            /*void */ ReloadSources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554444895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeRegistrations();
                this._changeTokenRegistrations.Clear();
                /*var*/ let newProvidersList = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationProvider))().$ctor$1();
                let $en3 = this._sources.GetEnumerator();
                while ($en3.MoveNext())
                {
                    let source = $en3.Current;
                    {
                        newProvidersList.Add(source.MEC$IConfigurationSource$Build(this));
                    }
                }
                let $en4 = newProvidersList.GetEnumerator();
                while ($en4.MoveNext())
                {
                    let p = $en4.Current;
                    {
                        p.MEC$IConfigurationProvider$Load();
                        this._changeTokenRegistrations.Add($.$mep.MEP.ChangeToken.OnChange(new ($.$$.S.Func$$($.$mep.MEP.IChangeToken))().$ctor(p, p.MEC$IConfigurationProvider$GetReloadToken), new $.$$.S.Action().$ctor(this, this.RaiseChanged)));
                    }
                }
                this._providerManager.ReplaceProviders(newProvidersList);
                this.RaiseChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(124554444895)
            
            //--TRIMMABLE-BOUNDARY-START(42950066271)
            /*void */ DisposeRegistrations()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en5 = this._changeTokenRegistrations.GetEnumerator();
                while ($en5.MoveNext())
                {
                    let registration = $en5.Current;
                    {
                        registration.S$IDisposable$Dispose();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950066271)
            
            //--TRIMMABLE-BOUNDARY-START(34360131679)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return `Sections = ${$.$strNN(/*$.$mec.MEC.ConfigurationSectionDebugView*/$.$$.DeletedObject.FromConfiguration(this, this).Count)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131679)
            
            //--TRIMMABLE-BOUNDARY-START(589919)
            static $_ConfigurationSources;
            static get ConfigurationSources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mec.MEC.ConfigurationManager;
                return $cls.$_ConfigurationSources ??= $asm.$ncls(`$mec.MEC.ConfigurationManager.ConfigurationSources`, ($self) => class ConfigurationSources extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590524511)
                    /*List<IConfigurationSource>*/ _sources = null;
                    //--TRIMMABLE-BOUNDARY-END(8590524511)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557215)
                    /*ConfigurationManager*/ _config = null;
                    //--TRIMMABLE-BOUNDARY-END(4295557215)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491807)
                    $ctor$1(/*ConfigurationManager*/ config)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885491807);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._config = config;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885491807)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374772319)
                    /*IConfigurationSource*/ get_Item$1(/*int*/ index)
                    {
                        return this._sources.get_Item(index);
                    }
                    /*void*/ set_Item$1(/*int*/ index, /*IConfigurationSource*/ value)
                    {
                        this._sources.set_Item(index, value);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374772319)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360328287)
                    /*int */ get Count()
                    {
                        return this._sources.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360328287)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310001247)
                    /*bool */ get IsReadOnly()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310001247)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459103)
                    /*void */ Add(/*IConfigurationSource*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180459103);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._sources.Add(source);
                        this._config.AddSource(source);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459103)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475426399)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475426399);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._sources.Clear();
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475426399)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393695)
                    /*bool */ Contains(/*IConfigurationSource*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770393695);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._sources.Contains(source);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770393695)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065360991)
                    /*void */ CopyTo(/*IConfigurationSource[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065360991);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._sources.CopyTo$1(array, arrayIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065360991)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425099359)
                    /*List<IConfigurationSource>.Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425099359);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._sources.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425099359)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720066655)
                    /*int */ IndexOf(/*IConfigurationSource*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720066655);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._sources.IndexOf$2(source);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720066655)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015033951)
                    /*void */ Insert(/*int*/ index, /*IConfigurationSource*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015033951);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._sources.Insert(index, source);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015033951)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604968543)
                    /*bool */ Remove(/*IConfigurationSource*/ source)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604968543);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let removed = this._sources.Remove(source);
                        this._config.ReloadSources();
                        return removed;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604968543)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899935839)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85899935839);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._sources.RemoveAt(index);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899935839)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079805023)
                    /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(103079805023);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079805023)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784837727)
                    /*IEnumerator<IConfigurationSource> */ SCG$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(98784837727);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784837727)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650555393)
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.this[int].get
                    SCG$IList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650555393);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650555393)
                    
                    //--TRIMMABLE-BOUNDARY-START(30125391873)
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.this[int].set
                    SCG$IList$$$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30125391873);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30125391873)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945522689)
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.IndexOf(Microsoft.Extensions.Configuration.IConfigurationSource)
                    SCG$IList$$$IndexOf()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12945522689);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IndexOf(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945522689)
                    
                    //--TRIMMABLE-BOUNDARY-START(17240489985)
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.Insert(int, Microsoft.Extensions.Configuration.IConfigurationSource)
                    SCG$IList$$$Insert()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17240489985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Insert(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17240489985)
                    
                    //--TRIMMABLE-BOUNDARY-START(21535457281)
                    //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.Configuration.IConfigurationSource>.RemoveAt(int)
                    SCG$IList$$$RemoveAt()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21535457281);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveAt(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21535457281)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124802049)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Count.get
                    get SCG$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534867457);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124802049)
                    
                    //--TRIMMABLE-BOUNDARY-START(38714736641)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.IsReadOnly.get
                    get SCG$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43009703937);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38714736641)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354998273)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Add(Microsoft.Extensions.Configuration.IConfigurationSource)
                    SCG$ICollection$$$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354998273)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649965569)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Clear()
                    SCG$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649965569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649965569)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Contains(Microsoft.Extensions.Configuration.IConfigurationSource)
                    SCG$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944932865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239900161)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.CopyTo(Microsoft.Extensions.Configuration.IConfigurationSource[], int)
                    SCG$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239900161);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239900161)
                    
                    //--TRIMMABLE-BOUNDARY-START(47304671233)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.Configuration.IConfigurationSource>.Remove(Microsoft.Extensions.Configuration.IConfigurationSource)
                    SCG$ICollection$$$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47304671233);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47304671233)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590524511)
                        this._sources = new ($.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(8590524511)
                        
                    }
                    static $h = 589919;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374772319),
    {
      "p": 786526,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132063,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489870431,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 589919,
      "h": 107374772319,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(107374772319),
//--TRIMMABLE-BOUNDARY-START(34360328287),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262879,
        "f": 50331649
      },
      "n": "Count",
      "d": 589919,
      "h": 34360328287,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328287),
//--TRIMMABLE-BOUNDARY-START(77310001247),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197471,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 589919,
      "h": 77310001247,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310001247)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459103),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Add",
      "d": 589919,
      "h": 17180459103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459103),
//--TRIMMABLE-BOUNDARY-START(21475426399),
    {
      "r": 65537,
      "n": "Clear",
      "d": 589919,
      "h": 21475426399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426399),
//--TRIMMABLE-BOUNDARY-START(25770393695),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Contains",
      "d": 589919,
      "h": 25770393695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393695),
//--TRIMMABLE-BOUNDARY-START(30065360991),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$mecga.MEC.IConfigurationSource).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 589919,
      "h": 30065360991,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065360991),
//--TRIMMABLE-BOUNDARY-START(64425099359),
    {
      "r": 61341697,
      "n": "GetEnumerator",
      "d": 589919,
      "h": 64425099359,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425099359),
//--TRIMMABLE-BOUNDARY-START(68720066655),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "IndexOf",
      "d": 589919,
      "h": 68720066655,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720066655),
//--TRIMMABLE-BOUNDARY-START(73015033951),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Insert",
      "d": 589919,
      "h": 73015033951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015033951),
//--TRIMMABLE-BOUNDARY-START(81604968543),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "Remove",
      "d": 589919,
      "h": 81604968543,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604968543),
//--TRIMMABLE-BOUNDARY-START(85899935839),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 589919,
      "h": 85899935839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899935839)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524511),
    {
      "t": $.$$.SCG.List$$($.$mecga.MEC.IConfigurationSource).$h,
      "n": "_sources",
      "d": 589919,
      "h": 8590524511,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524511),
//--TRIMMABLE-BOUNDARY-START(4295557215),
    {
      "t": 393311,
      "n": "_config",
      "d": 589919,
      "h": 4295557215,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557215)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491807),
    {
      "p": [
        {
          "n": "config",
          "p": 393311
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589919,
      "h": 12885491807,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491807)
  ],
  "d": 393311,
  "h": 589919
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationSource), $.$$.SCG.ICollection$$($.$mecga.MEC.IConfigurationSource), $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSource), $.$$.SC$1.IEnumerable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationManager+ConfigurationSources`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationManager${separator}ConfigurationSources`; }
                }, $cls, ($v) => $cls.$_ConfigurationSources = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589919)
            
            //--TRIMMABLE-BOUNDARY-START(458847)
            static $_ConfigurationBuilderProperties;
            static get ConfigurationBuilderProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(458847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mec.MEC.ConfigurationManager;
                return $cls.$_ConfigurationBuilderProperties ??= $asm.$ncls(`$mec.MEC.ConfigurationManager.ConfigurationBuilderProperties`, ($self) => class ConfigurationBuilderProperties extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393439)
                    /*Dictionary<string, object>*/ _properties = null;
                    //--TRIMMABLE-BOUNDARY-END(8590393439)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295426143)
                    /*ConfigurationManager*/ _config = null;
                    //--TRIMMABLE-BOUNDARY-END(4295426143)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885360735)
                    $ctor$1(/*ConfigurationManager*/ config)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885360735);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._config = config;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885360735)
                    
                    //--TRIMMABLE-BOUNDARY-START(124554510431)
                    /*object*/ get_Item$1(/*string*/ key)
                    {
                        return this._properties.get_Item(key);
                    }
                    /*void*/ set_Item$1(/*string*/ key, /*object*/ value)
                    {
                        this._properties.set_Item(key, value);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(124554510431)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784706655)
                    /*ICollection<string> */ get Keys()
                    {
                        return this._properties.Keys;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784706655)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144445023)
                    /*ICollection<object> */ get Values()
                    {
                        return this._properties.Values;
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144445023)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950131807)
                    /*int */ get Count()
                    {
                        return this._properties.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950131807)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489739359)
                    /*bool */ get IsReadOnly()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94489739359)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475295327)
                    /*void */ Add$1(/*string*/ key, /*object*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475295327);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._properties.Add(key, value);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475295327)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180328031)
                    /*void */ Add(/*KeyValuePair<string, object>*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180328031);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        (this._properties).SCG$ICollection$$$Add(item);
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180328031)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770262623)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770262623);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._properties.Clear();
                        this._config.ReloadSources();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770262623)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065229919)
                    /*bool */ Contains(/*KeyValuePair<string, object>*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065229919);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$sl.SL.Enumerable.Contains$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), this._properties, item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065229919)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360197215)
                    /*bool */ ContainsKey(/*string*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360197215);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._properties.ContainsKey(key);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360197215)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655164511)
                    /*void */ CopyTo(/*KeyValuePair<string, object>[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655164511);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        (this._properties).SCG$ICollection$$$CopyTo(array, arrayIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655164511)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194772063)
                    /*IEnumerator<KeyValuePair<string, object>> */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90194772063);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._properties.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194772063)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374641247)
                    /*bool */ Remove$1(/*string*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374641247);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let wasRemoved = this._properties.Remove$1(key);
                        this._config.ReloadSources();
                        return wasRemoved;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374641247)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079673951)
                    /*bool */ Remove(/*KeyValuePair<string, object>*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103079673951);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let wasRemoved = (this._properties).SCG$ICollection$$$Remove(item);
                        this._config.ReloadSources();
                        return wasRemoved;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079673951)
                    
                    //--TRIMMABLE-BOUNDARY-START(128849477727)
                    /*bool */ TryGetValue(/*string*/ key, /*out object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128849477727);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._properties.TryGetValue(key, value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(128849477727)
                    
                    //--TRIMMABLE-BOUNDARY-START(120259543135)
                    /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120259543135);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._properties.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(120259543135)
                    
                    //--TRIMMABLE-BOUNDARY-START(17240096769)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.this[string].get
                    SCG$IDictionary$$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17240096769);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17240096769)
                    
                    //--TRIMMABLE-BOUNDARY-START(51599835137)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.this[string].set
                    SCG$IDictionary$$$$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51599835137);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(51599835137)
                    
                    //--TRIMMABLE-BOUNDARY-START(25830031361)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Keys.get
                    get SCG$IDictionary$$$$Keys()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38714933249);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Keys;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25830031361)
                    
                    //--TRIMMABLE-BOUNDARY-START(34419965953)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Values.get
                    get SCG$IDictionary$$$$Values()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64484737025);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Values;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34419965953)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650162177)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.ContainsKey(string)
                    SCG$IDictionary$$$$ContainsKey()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650162177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.ContainsKey(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650162177)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355194881)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Add(string, object)
                    SCG$IDictionary$$$$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355194881);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355194881)
                    
                    //--TRIMMABLE-BOUNDARY-START(43009900545)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.Remove(string)
                    SCG$IDictionary$$$$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43009900545);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(43009900545)
                    
                    //--TRIMMABLE-BOUNDARY-START(60189769729)
                    //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object>.TryGetValue(string, out object)
                    SCG$IDictionary$$$$TryGetValue()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60189769729);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.TryGetValue(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60189769729)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124802049)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Count.get
                    get SCG$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534867457);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124802049)
                    
                    //--TRIMMABLE-BOUNDARY-START(38714736641)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.IsReadOnly.get
                    get SCG$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43009703937);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38714736641)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354998273)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Add(System.Collections.Generic.KeyValuePair<string, object>)
                    SCG$ICollection$$$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354998273)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649965569)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Clear()
                    SCG$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649965569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649965569)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Contains(System.Collections.Generic.KeyValuePair<string, object>)
                    SCG$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944932865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239900161)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.CopyTo(System.Collections.Generic.KeyValuePair<string, object>[], int)
                    SCG$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239900161);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239900161)
                    
                    //--TRIMMABLE-BOUNDARY-START(47304671233)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object>>.Remove(System.Collections.Generic.KeyValuePair<string, object>)
                    SCG$ICollection$$$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47304671233);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47304671233)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355325953)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object>>.GetEnumerator()
                    SCG$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355325953);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355325953)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590393439)
                        this._properties = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                        //--TRIMMABLE-BOUNDARY-END(8590393439)
                        
                    }
                    static $h = 458847;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554510431),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935583,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964575839,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 458847,
      "h": 124554510431,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(124554510431),
//--TRIMMABLE-BOUNDARY-START(98784706655),
    {
      "p": $.$$.SCG.ICollection$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870175,
        "f": 50331649
      },
      "n": "Keys",
      "d": 458847,
      "h": 98784706655,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784706655),
//--TRIMMABLE-BOUNDARY-START(133144445023),
    {
      "p": $.$$.SCG.ICollection$$($.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899804767,
        "f": 50331649
      },
      "n": "Values",
      "d": 458847,
      "h": 133144445023,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144445023),
//--TRIMMABLE-BOUNDARY-START(42950131807),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540066399,
        "f": 50331649
      },
      "n": "Count",
      "d": 458847,
      "h": 42950131807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950131807),
//--TRIMMABLE-BOUNDARY-START(94489739359),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130000991,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 458847,
      "h": 94489739359,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489739359)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475295327),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 458847,
      "h": 21475295327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295327),
//--TRIMMABLE-BOUNDARY-START(17180328031),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "Add",
      "d": 458847,
      "h": 17180328031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180328031),
//--TRIMMABLE-BOUNDARY-START(25770262623),
    {
      "r": 65537,
      "n": "Clear",
      "d": 458847,
      "h": 25770262623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262623),
//--TRIMMABLE-BOUNDARY-START(30065229919),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "Contains",
      "d": 458847,
      "h": 30065229919,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229919),
//--TRIMMABLE-BOUNDARY-START(34360197215),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "ContainsKey",
      "d": 458847,
      "h": 34360197215,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197215),
//--TRIMMABLE-BOUNDARY-START(38655164511),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 458847,
      "h": 38655164511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164511),
//--TRIMMABLE-BOUNDARY-START(90194772063),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)).$h,
      "n": "GetEnumerator",
      "d": 458847,
      "h": 90194772063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194772063),
//--TRIMMABLE-BOUNDARY-START(107374641247),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "o": "@$1",
      "d": 458847,
      "h": 107374641247,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374641247),
//--TRIMMABLE-BOUNDARY-START(103079673951),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": $.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "Remove",
      "d": 458847,
      "h": 103079673951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079673951),
//--TRIMMABLE-BOUNDARY-START(128849477727),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": 458847,
      "h": 128849477727,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128849477727)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393439),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_properties",
      "d": 458847,
      "h": 8590393439,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393439),
//--TRIMMABLE-BOUNDARY-START(4295426143),
    {
      "t": 393311,
      "n": "_config",
      "d": 458847,
      "h": 4295426143,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426143)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360735),
    {
      "p": [
        {
          "n": "config",
          "p": 393311
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458847,
      "h": 12885360735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360735)
  ],
  "d": 393311,
  "h": 458847
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IEnumerable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationManager+ConfigurationBuilderProperties`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationManager${separator}ConfigurationBuilderProperties`; }
                }, $cls, ($v) => $cls.$_ConfigurationBuilderProperties = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458847)
            
            //--TRIMMABLE-BOUNDARY-START(25770262622)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfigurationBuilder.Sources.get
            get MEC$IConfigurationBuilder$Sources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Sources;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262622)
            
            //--TRIMMABLE-BOUNDARY-START(8590327902)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].get
            MEC$IConfiguration$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590327902)
            
            //--TRIMMABLE-BOUNDARY-START(30065164382)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.this[string].set
            MEC$IConfiguration$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164382)
            
            //--TRIMMABLE-BOUNDARY-START(21475229790)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetSection(string)
            MEC$IConfiguration$GetSection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSection(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229790)
            
            //--TRIMMABLE-BOUNDARY-START(12885295198)
            //Generated interface implemetation for Microsoft.Extensions.Configuration.IConfiguration.GetChildren()
            MEC$IConfiguration$GetChildren()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetChildren(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295198)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(25770197087)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770197087)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180262495)
                this._providerManager = new $.$mec.MEC.ReferenceCountedProviderManager().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(17180262495)
                
                //--TRIMMABLE-BOUNDARY-START(8590327903)
                this._changeTokenRegistrations = new ($.$$.SCG.List$$($.$$.S.IDisposable))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590327903)
                
                //--TRIMMABLE-BOUNDARY-START(4295360607)
                this._changeToken = new $.$mec.MEC.ConfigurationReloadToken().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295360607)
                
            }
            static $h = 393311;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(141734314079),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000863,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144379487,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 393311,
      "h": 141734314079,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(141734314079),
//--TRIMMABLE-BOUNDARY-START(98784641119),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489673823,
        "f": 50331650
      },
      "n": "{458846}.Properties",
      "o": "MEC$IConfigurationBuilder$Properties",
      "d": 393311,
      "h": 98784641119,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98784641119),
//--TRIMMABLE-BOUNDARY-START(137439346783),
    {
      "p": $.$$.SCG.IList$$($.$mecga.MEC.IConfigurationSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129935455,
        "f": 50331649
      },
      "n": "Sources",
      "d": 393311,
      "h": 137439346783,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439346783),
//--TRIMMABLE-BOUNDARY-START(111669543007),
    {
      "p": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationProvider).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374575711,
        "f": 50331650
      },
      "n": "{655454}.Providers",
      "o": "MEC$IConfigurationRoot$Providers",
      "d": 393311,
      "h": 111669543007,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(111669543007)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014837343),
    {
      "r": 720990,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetSection",
      "d": 393311,
      "h": 73014837343,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014837343),
//--TRIMMABLE-BOUNDARY-START(64424902751),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mecga.MEC.IConfigurationSection).$h,
      "n": "GetChildren",
      "d": 393311,
      "h": 64424902751,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424902751),
//--TRIMMABLE-BOUNDARY-START(38655098975),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 393311,
      "h": 38655098975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655098975),
//--TRIMMABLE-BOUNDARY-START(68719870047),
    {
      "r": 1441887,
      "n": "GetProvidersReference",
      "d": 393311,
      "h": 68719870047,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719870047),
//--TRIMMABLE-BOUNDARY-START(120259477599),
    {
      "r": 65537,
      "n": "RaiseChanged",
      "d": 393311,
      "h": 120259477599,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259477599),
//--TRIMMABLE-BOUNDARY-START(30065164383),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 786526
        }
      ],
      "n": "AddSource",
      "d": 393311,
      "h": 30065164383,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065164383),
//--TRIMMABLE-BOUNDARY-START(124554444895),
    {
      "r": 65537,
      "n": "ReloadSources",
      "d": 393311,
      "h": 124554444895,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554444895),
//--TRIMMABLE-BOUNDARY-START(42950066271),
    {
      "r": 65537,
      "n": "DisposeRegistrations",
      "d": 393311,
      "h": 42950066271,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950066271),
//--TRIMMABLE-BOUNDARY-START(34360131679),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 393311,
      "h": 34360131679,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360131679)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475229791),
    {
      "t": 589919,
      "n": "_sources",
      "d": 393311,
      "h": 21475229791,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229791),
//--TRIMMABLE-BOUNDARY-START(12885295199),
    {
      "t": 458847,
      "n": "_properties",
      "d": 393311,
      "h": 12885295199,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885295199),
//--TRIMMABLE-BOUNDARY-START(17180262495),
    {
      "t": 1376351,
      "n": "_providerManager",
      "d": 393311,
      "h": 17180262495,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180262495),
//--TRIMMABLE-BOUNDARY-START(8590327903),
    {
      "t": $.$$.SCG.List$$($.$$.S.IDisposable).$h,
      "n": "_changeTokenRegistrations",
      "d": 393311,
      "h": 8590327903,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327903),
//--TRIMMABLE-BOUNDARY-START(4295360607),
    {
      "t": 720991,
      "n": "_changeToken",
      "d": 393311,
      "h": 4295360607,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770197087),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393311,
      "h": 25770197087,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770197087)
  ],
  "h": 393311,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationManager, $.$mecga.MEC.IConfigurationBuilder, $.$mecga.MEC.IConfigurationRoot, $.$mecga.MEC.IConfiguration, $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$mec.MEC.ConfigurationManager.ConfigurationManagerDebugView*/$.$$.DeletedObject, $.$mec.MEC.ConfigurationManager.ConfigurationSources, $.$mec.MEC.ConfigurationManager.ConfigurationBuilderProperties ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393311)
        
        

        //--TRIMMABLE-BOUNDARY-START(327775)
        $asm.$cls(`$mec.MEC.ConfigurationKeyComparer`, ($self) => class ConfigurationKeyComparer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51539935327)
            /*char*/ static KeyDelimiter = /*:*/ 58;
            //--TRIMMABLE-BOUNDARY-END(51539935327)
            
            //--TRIMMABLE-BOUNDARY-START(47244968031)
            /*ConfigurationKeyComparer*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(47244968031)
            
            //--TRIMMABLE-BOUNDARY-START(25770131551)
            /*Comparison<string>*/ static Comparison = null;
            //--TRIMMABLE-BOUNDARY-END(25770131551)
            
            //--TRIMMABLE-BOUNDARY-START(21475164255)
            /*int */ Compare$1(/*string?*/ x, /*string?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<char>*/ let xSpan = $.$$.S.MemoryExtensions.AsSpan$4(x);
                /*ReadOnlySpan<char>*/ let ySpan = $.$$.S.MemoryExtensions.AsSpan$4(y);
                xSpan = SkipAheadOnDelimiter(xSpan);
                ySpan = SkipAheadOnDelimiter(ySpan);
                while(!xSpan.IsEmpty && !ySpan.IsEmpty)
                {
                    /*int*/ let xDelimiterIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, xSpan, /*:*/ 58);
                    /*int*/ let yDelimiterIndex = $.$$.S.MemoryExtensions.IndexOf$4($.$$.S.Char, ySpan, /*:*/ 58);
                    /*int*/ let compareResult = Compare(xDelimiterIndex === -1 ? xSpan : xSpan.Slice(0, xDelimiterIndex), yDelimiterIndex === -1 ? ySpan : ySpan.Slice(0, yDelimiterIndex));
                    if (compareResult !== 0)
                    {
                        return compareResult;
                    }
                    xSpan = xDelimiterIndex === -1 ? new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))() : SkipAheadOnDelimiter(xSpan.Slice$1(((xDelimiterIndex + 1) | 0)));
                    ySpan = yDelimiterIndex === -1 ? new ($.$$.S.ReadOnlySpan$$($.$$.S.Char))() : SkipAheadOnDelimiter(ySpan.Slice$1(((yDelimiterIndex + 1) | 0)));
                }
                return xSpan.IsEmpty ? (ySpan.IsEmpty ? 0 : -1) : 1;
                /*static ReadOnlySpan<char>*/  function SkipAheadOnDelimiter(/*ReadOnlySpan<char>*/ a)
                {
                    while(!a.IsEmpty && a._reference.GetAt(0) === /*:*/ 58)
                    {
                        a = a.Slice$1(1);
                    }
                    return a;
                }
                /*static int*/  function Compare(/*ReadOnlySpan<char>*/ a, /*ReadOnlySpan<char>*/ b)
                {
                    /*int*/ let value1;
                    /*int*/ let value2;
                    /*bool*/ let aIsInt = $.$$.S.Int32.TryParse$3(a, $.$ref(() => value1, ($v) => value1 = $v, $.$$.S.Int32));
                    /*bool*/ let bIsInt = $.$$.S.Int32.TryParse$3(b, $.$ref(() => value2, ($v) => value2 = $v, $.$$.S.Int32));
                    /*int*/ let result;
                    if (!aIsInt && !bIsInt)
                    {
                        result = $.$$.S.MemoryExtensions.CompareTo(a, b, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                    else if (aIsInt && bIsInt)
                    {
                        result = ((value1 - value2) | 0);
                    }
                    else 
                    {
                        result = aIsInt ? -1 : 1;
                    }
                    return result;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164255)
            
            //--TRIMMABLE-BOUNDARY-START(4355129345)
            //Generated interface implemetation for System.Collections.Generic.IComparer<string>.Compare(string?, string?)
            SCG$IComparer$System$String$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355129345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355129345)
            
            //--TRIMMABLE-BOUNDARY-START(17180196959)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196959)
            
            //--TRIMMABLE-BOUNDARY-START(17180196959)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180196959)
            
            //--TRIMMABLE-BOUNDARY-START(12885229663)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47244968031)
                    this.Instance = new $.$mec.MEC.ConfigurationKeyComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(47244968031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770131551)
                    this.Comparison = new ($.$$.S.Comparison$$($.$$.S.String))().$ctor($.$mec.MEC.ConfigurationKeyComparer.Instance, $.$mec.MEC.ConfigurationKeyComparer.Instance.Compare$1);
                    //--TRIMMABLE-BOUNDARY-END(25770131551)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885229663)
            
            static $h = 327775;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47244968031),
    {
      "p": 327775,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950000735,
        "f": 50331681
      },
      "n": "Instance",
      "d": 327775,
      "h": 47244968031,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47244968031),
//--TRIMMABLE-BOUNDARY-START(25770131551),
    {
      "p": $.$$.S.Comparison$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066143,
        "f": 50331688
      },
      "n": "Comparison",
      "d": 327775,
      "h": 25770131551,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(25770131551)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475164255),
    {
      "r": 655361,
      "p": [
        {
          "n": "x",
          "p": 1310721
        },
        {
          "n": "y",
          "p": 1310721
        }
      ],
      "n": "Compare",
      "o": "@$1",
      "d": 327775,
      "h": 21475164255,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164255)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539935327),
    {
      "t": 458753,
      "n": "KeyDelimiter",
      "d": 327775,
      "h": 51539935327,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539935327)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180196959),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327775,
      "h": 17180196959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196959)
  ],
  "h": 327775
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IComparer$$($.$$.S.String) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.ConfigurationKeyComparer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}ConfigurationKeyComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327775)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179743)
        $asm.$cls(`$mec.MECM.MemoryConfigurationProvider`, ($self) => class MemoryConfigurationProvider extends $.$mec.MEC.ConfigurationProvider
        {
            //--TRIMMABLE-BOUNDARY-START(4296147039)
            /*MemoryConfigurationSource*/ _source = null;
            //--TRIMMABLE-BOUNDARY-END(4296147039)
            
            //--TRIMMABLE-BOUNDARY-START(8591114335)
            $ctor$2(/*MemoryConfigurationSource*/ source)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114335);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                    this._source = source;
                    if (this._source.InitialData !== null)
                    {
                        let $en1 = this._source.InitialData.SCG$IEnumerable$$$GetEnumerator();
                        while ($en1.SC$1$IEnumerator$MoveNext())
                        {
                            let pair = $en1.SCG$IEnumerator$$$Current;
                            {
                                this.Data.SCG$IDictionary$$$$Add(pair.Key, pair.Value);
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114335)
            
            //--TRIMMABLE-BOUNDARY-START(12886081631)
            /*void */ Add(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Data.SCG$IDictionary$$$$Add(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12886081631)
            
            //--TRIMMABLE-BOUNDARY-START(17181048927)
            /*IEnumerator<KeyValuePair<string, string?>> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Data.SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(17181048927)
            
            //--TRIMMABLE-BOUNDARY-START(21476016223)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476016223);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016223)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, string?>>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            static $h = 1179743;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mec.MEC.ConfigurationProvider; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886081631),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "d": 1179743,
      "h": 12886081631,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081631),
//--TRIMMABLE-BOUNDARY-START(17181048927),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)).$h,
      "n": "GetEnumerator",
      "d": 1179743,
      "h": 17181048927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048927)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147039),
    {
      "t": 1245279,
      "n": "_source",
      "d": 1179743,
      "h": 4296147039,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114335),
    {
      "p": [
        {
          "n": "source",
          "p": 1245279
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179743,
      "h": 8591114335,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114335)
  ],
  "h": 1179743
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mecga.MEC.IConfigurationProvider, $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.String)), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Configuration.Memory.MemoryConfigurationProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Configuration${separator}Memory${separator}MemoryConfigurationProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179743)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions"));
})();
//--TRIMMABLE-BOUNDARY-END(95)
