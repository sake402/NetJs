
//--TRIMMABLE-BOUNDARY-START(90)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scm, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    let $jbDeCk;
    let $jytXVh;
    let $Ukzyti;
    let $WsfNJe;
    let $FUJPpi;
    let $pgJnbc;
    let $GHzdtf;
    let $bqIEZk;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", 
    {
  "h": 90,
  "f": "Microsoft.Extensions.DependencyInjection.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.DependencyInjection.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 116457473,
      "c": 8706392065,
      "a": [
        {
          "v": 131162,
          "t": 188547073
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983130)
        $asm.$cls(`$mxdi.MED.IServiceProviderIsService`, ($self) => class IServiceProviderIsService
        {
            static $h = 983130;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950426),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "IsService",
      "o": "MED$IServiceProviderIsService$IsService",
      "d": 983130,
      "h": 4295950426,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295950426)
  ],
  "h": 983130
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceProviderIsService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceProviderIsService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983130)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114202)
        $asm.$cls(`$mxdi.MED.IServiceScopeFactory`, ($self) => class IServiceScopeFactory
        {
            static $h = 1114202;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081498),
    {
      "r": 1048666,
      "n": "CreateScope",
      "o": "MED$IServiceScopeFactory$CreateScope",
      "d": 1114202,
      "h": 4296081498,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081498)
  ],
  "h": 1114202
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceScopeFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114202)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179738)
        $asm.$cls(`$mxdi.MED.ISupportRequiredService`, ($self) => class ISupportRequiredService
        {
            static $h = 1179738;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147034),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetRequiredService",
      "o": "MED$ISupportRequiredService$GetRequiredService",
      "d": 1179738,
      "h": 4296147034,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296147034)
  ],
  "h": 1179738
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ISupportRequiredService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ISupportRequiredService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179738)
        
        

        //--TRIMMABLE-BOUNDARY-START(852058)
        $asm.$cls(`$mxdi.MED.IServiceProviderFactory<>`, (TContainerBuilder) => $asm.$gt(`$mxdi.MED.IServiceProviderFactory<>`, [TContainerBuilder], ($self) => class IServiceProviderFactory$$
        {
            static $H = 852058;
            static $h = 852058;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819354),
    {
      "r": TContainerBuilder?.$h??1572864,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "CreateBuilder",
      "o": `MED$IServiceProviderFactory$${TContainerBuilder.$getFullName('$')}$CreateBuilder`,
      "d": this.$h,
      "H": 4295819354,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295819354),
//--TRIMMABLE-BOUNDARY-START(8590786650),
    {
      "r": 327718,
      "p": [
        {
          "n": "containerBuilder",
          "p": TContainerBuilder?.$h??1572864
        }
      ],
      "n": "CreateServiceProvider",
      "o": `MED$IServiceProviderFactory$${TContainerBuilder.$getFullName('$')}$CreateServiceProvider`,
      "d": this.$h,
      "H": 8590786650,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590786650)
  ],
  "s": [
    {
      "h": TContainerBuilder?.$h??1572864,
      "n": "TContainerBuilder",
      "f": 64
    }
  ],
  "r": 1,
  "H": 852058,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<${TContainerBuilder?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceProviderFactory$${TContainerBuilder?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852058)
        
        

        //--TRIMMABLE-BOUNDARY-START(917594)
        $asm.$cls(`$mxdi.MED.IServiceProviderIsKeyedService`, ($self) => class IServiceProviderIsKeyedService
        {
            static $h = 917594;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295884890),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "IsKeyedService",
      "o": "MED$IServiceProviderIsKeyedService$IsKeyedService",
      "d": 917594,
      "h": 4295884890,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295884890)
  ],
  "h": 917594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.MED.IServiceProviderIsService ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceProviderIsKeyedService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917594)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048666)
        $asm.$cls(`$mxdi.MED.IServiceScope`, ($self) => class IServiceScope
        {
            static $h = 1048666;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885950554),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590983258,
        "f": 50331905
      },
      "n": "ServiceProvider",
      "o": "MED$IServiceScope$ServiceProvider",
      "d": 1048666,
      "h": 12885950554,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885950554)
  ],
  "h": 1048666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048666)
        
        

        //--TRIMMABLE-BOUNDARY-START(720986)
        $asm.$cls(`$mxdi.MED.IKeyedServiceProvider`, ($self) => class IKeyedServiceProvider
        {
            static $h = 720986;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295688282),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "o": "MED$IKeyedServiceProvider$GetKeyedService",
      "d": 720986,
      "h": 4295688282,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295688282),
//--TRIMMABLE-BOUNDARY-START(8590655578),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "o": "MED$IKeyedServiceProvider$GetRequiredKeyedService",
      "d": 720986,
      "h": 8590655578,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590655578)
  ],
  "h": 720986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.S.IServiceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IKeyedServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720986)
        
        

        //--TRIMMABLE-BOUNDARY-START(2097242)
        $asm.$cls(`$mxdi.MEI.ParameterDefaultValue`, ($self) => class ParameterDefaultValue
        {
            //--TRIMMABLE-BOUNDARY-START(4297064538)
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064538)
            
            //--TRIMMABLE-BOUNDARY-START(8592031834)
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                /*bool*/ let tryToGetDefaultValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let hasDefaultValue = $.$mxdi.MEI.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.S.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && parameter.ParameterType.GetGenericTypeDefinition() === $.$$.S.Nullable$$().$type;
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        {
                            return $.$$.SRC.RuntimeHelpers.GetUninitializedObject(t);
                        }
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.S.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if (underlyingType !== null && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.S.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031834)
            
            static $h = 2097242;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297064538),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 119078913
        },
        {
          "n": "tryToGetDefaultValue",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "CheckHasDefaultValue",
      "d": 2097242,
      "h": 4297064538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297064538),
//--TRIMMABLE-BOUNDARY-START(8592031834),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 119078913
        },
        {
          "n": "defaultValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetDefaultValue",
      "d": 2097242,
      "h": 8592031834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592031834)
  ],
  "h": 2097242
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}ParameterDefaultValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097242)
        
        

        //--TRIMMABLE-BOUNDARY-START(2162778)
        $asm.$cls(`$mxdi.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(313534775386)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(313534775386)
            
            //--TRIMMABLE-BOUNDARY-START(304944840794)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(304944840794)
            
            //--TRIMMABLE-BOUNDARY-START(309239808090)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635429466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mxdi.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.DependencyInjection.Abstractions", $.$mxdi.S.SR.$type.Assembly);
                    $.$mxdi.S.SR.s_resourceManager = temp;
                }
                return $.$mxdi.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(309239808090)
            
            //--TRIMMABLE-BOUNDARY-START(25771966554)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326018138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714644570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966554)
            
            //--TRIMMABLE-BOUNDARY-START(8592097370)
            static /*string */ get AmbiguousConstructorMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966279770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592097370)
            
            //--TRIMMABLE-BOUNDARY-START(64426672218)
            static /*string */ FormatAmbiguousConstructorMatch(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64426672218)
            
            //--TRIMMABLE-BOUNDARY-START(17182031962)
            static /*string */ get CannotResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182031962)
            
            //--TRIMMABLE-BOUNDARY-START(68721639514)
            static /*string */ FormatCannotResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721639514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68721639514)
            
            //--TRIMMABLE-BOUNDARY-START(292059938906)
            static /*string */ get NoConstructorMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865625690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(292059938906)
            
            //--TRIMMABLE-BOUNDARY-START(94491443290)
            static /*string */ FormatNoConstructorMatch(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491443290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94491443290)
            
            //--TRIMMABLE-BOUNDARY-START(300649873498)
            static /*string */ get NoServiceRegistered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045494874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No service for type '{0}' has been registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(300649873498)
            
            //--TRIMMABLE-BOUNDARY-START(98786410586)
            static /*string */ FormatNoServiceRegistered(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786410586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("No service for type '{0}' has been registered.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98786410586)
            
            //--TRIMMABLE-BOUNDARY-START(322124709978)
            static /*string */ get ServiceCollectionReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225364058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The service collection cannot be modified because it is read-only.";
            }
            //--TRIMMABLE-BOUNDARY-END(322124709978)
            
            //--TRIMMABLE-BOUNDARY-START(335009611866)
            static /*string */ get TryAddIndistinguishableTypeToEnumerable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815298650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(335009611866)
            
            //--TRIMMABLE-BOUNDARY-START(103081377882)
            static /*string */ FormatTryAddIndistinguishableTypeToEnumerable(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081377882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(103081377882)
            
            //--TRIMMABLE-BOUNDARY-START(287764971610)
            static /*string */ get MultipleCtorsMarkedWithAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275691098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors were marked with {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(287764971610)
            
            //--TRIMMABLE-BOUNDARY-START(90196475994)
            static /*string */ FormatMultipleCtorsMarkedWithAttribute(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Multiple constructors were marked with {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90196475994)
            
            //--TRIMMABLE-BOUNDARY-START(274880069722)
            static /*string */ get MarkedCtorMissingArgumentTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505887322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor marked with {0} does not accept all given argument types.";
            }
            //--TRIMMABLE-BOUNDARY-END(274880069722)
            
            //--TRIMMABLE-BOUNDARY-START(77311574106)
            static /*string */ FormatMarkedCtorMissingArgumentTypes(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311574106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Constructor marked with {0} does not accept all given argument types.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77311574106)
            
            //--TRIMMABLE-BOUNDARY-START(12887064666)
            static /*string */ get CannotCreateAbstractClasses()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556214362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Instances of abstract classes cannot be created.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887064666)
            
            //--TRIMMABLE-BOUNDARY-START(283470004314)
            static /*string */ get MultipleCtorsFoundWithBestLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685756506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors for type '{0}' were found with length {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(283470004314)
            
            //--TRIMMABLE-BOUNDARY-START(85901508698)
            static /*string */ FormatMultipleCtorsFoundWithBestLength(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901508698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Multiple constructors for type '{0}' were found with length {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(85901508698)
            
            //--TRIMMABLE-BOUNDARY-START(339304579162)
            static /*string */ get UnableToResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405233242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(339304579162)
            
            //--TRIMMABLE-BOUNDARY-START(107376345178)
            static /*string */ FormatUnableToResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(107376345178)
            
            //--TRIMMABLE-BOUNDARY-START(21476999258)
            static /*string */ get CtorNotLocated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736083546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476999258)
            
            //--TRIMMABLE-BOUNDARY-START(73016606810)
            static /*string */ FormatCtorNotLocated(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73016606810)
            
            //--TRIMMABLE-BOUNDARY-START(279175037018)
            static /*string */ get MultipleCtorsFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095821914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(279175037018)
            
            //--TRIMMABLE-BOUNDARY-START(81606541402)
            static /*string */ FormatMultipleCtorsFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81606541402)
            
            //--TRIMMABLE-BOUNDARY-START(270585102426)
            static /*string */ get KeyedServicesNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915952730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This service provider doesn't support keyed services.";
            }
            //--TRIMMABLE-BOUNDARY-END(270585102426)
            
            //--TRIMMABLE-BOUNDARY-START(296354906202)
            static /*string */ get NonKeyedDescriptorMisuse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455560282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This service descriptor is not keyed.";
            }
            //--TRIMMABLE-BOUNDARY-END(296354906202)
            
            //--TRIMMABLE-BOUNDARY-START(317829742682)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(317829742682)
            
            //--TRIMMABLE-BOUNDARY-START(266290135130)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266290135130);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266290135130)
            
            //--TRIMMABLE-BOUNDARY-START(343599546458)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343599546458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mxdi.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343599546458)
            
            //--TRIMMABLE-BOUNDARY-START(261995167834)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995167834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mxdi.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(261995167834)
            
            //--TRIMMABLE-BOUNDARY-START(257700200538)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700200538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mxdi.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(257700200538)
            
            //--TRIMMABLE-BOUNDARY-START(55836737626)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836737626)
            
            //--TRIMMABLE-BOUNDARY-START(51541770330)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541770330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51541770330)
            
            //--TRIMMABLE-BOUNDARY-START(47246803034)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246803034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246803034)
            
            //--TRIMMABLE-BOUNDARY-START(60131704922)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdi.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60131704922)
            
            //--TRIMMABLE-BOUNDARY-START(38656868442)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656868442)
            
            //--TRIMMABLE-BOUNDARY-START(34361901146)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361901146)
            
            //--TRIMMABLE-BOUNDARY-START(30066933850)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30066933850)
            
            //--TRIMMABLE-BOUNDARY-START(42951835738)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdi.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951835738)
            
            //--TRIMMABLE-BOUNDARY-START(4297130074)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297130074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(317829742682)
                    this.s_usingResourceKeys = $.$mxdi.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(317829742682)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297130074)
            
            static $h = 2162778;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 2162778
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162778)
        
        

        //--TRIMMABLE-BOUNDARY-START(2031706)
        $asm.$cls(`$mxdi.MED.ServiceProviderServiceExtensions`, ($self) => class ServiceProviderServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(25771835482)
            static /*T? */ GetService(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771835482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast(provider.S$IServiceProvider$GetService(T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(25771835482)
            
            //--TRIMMABLE-BOUNDARY-START(17181900890)
            static /*object */ GetRequiredService(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.MED.ISupportRequiredService, { set $v($v){ requiredServiceSupportingProvider = $v; } }))
                {
                    return requiredServiceSupportingProvider.MED$ISupportRequiredService$GetRequiredService(serviceType);
                }
                /*object?*/ let service = provider.S$IServiceProvider$GetService(serviceType);
                if (service === null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$6($.$mxdi.S.SR.NoServiceRegistered, serviceType));
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(17181900890)
            
            //--TRIMMABLE-BOUNDARY-START(21476868186)
            static /*T */ GetRequiredService$1(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService(provider, T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(21476868186)
            
            //--TRIMMABLE-BOUNDARY-START(34361770074)
            static /*IEnumerable<T> */ GetServices$1(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.SCG.IEnumerable$$(T), provider);
            }
            //--TRIMMABLE-BOUNDARY-END(34361770074)
            
            //--TRIMMABLE-BOUNDARY-START(30066802778)
            static /*IEnumerable<object?> */ GetServices(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066802778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$$.SCG.IEnumerable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService(provider, genericEnumerable), $.$$.SCG.IEnumerable$$($.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(30066802778)
            
            //--TRIMMABLE-BOUNDARY-START(12886933594)
            static /*IServiceScope */ CreateScope(/*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.MED.IServiceScopeFactory, provider).MED$IServiceScopeFactory$CreateScope();
            }
            //--TRIMMABLE-BOUNDARY-END(12886933594)
            
            //--TRIMMABLE-BOUNDARY-START(8591966298)
            static /*AsyncServiceScope */ CreateAsyncScope$1(/*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.AsyncServiceScope().$ctor$3($.$mxdi.MED.ServiceProviderServiceExtensions.CreateScope(provider));
            }
            //--TRIMMABLE-BOUNDARY-END(8591966298)
            
            //--TRIMMABLE-BOUNDARY-START(4296999002)
            static /*AsyncServiceScope */ CreateAsyncScope(/*this IServiceScopeFactory*/ serviceScopeFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296999002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.AsyncServiceScope().$ctor$3(serviceScopeFactory.MED$IServiceScopeFactory$CreateScope());
            }
            //--TRIMMABLE-BOUNDARY-END(4296999002)
            
            static $h = 2031706;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771835482),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetService",
      "d": 2031706,
      "h": 25771835482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771835482),
//--TRIMMABLE-BOUNDARY-START(17181900890),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetRequiredService",
      "d": 2031706,
      "h": 17181900890,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181900890),
//--TRIMMABLE-BOUNDARY-START(21476868186),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetRequiredService",
      "o": "@$1",
      "d": 2031706,
      "h": 21476868186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21476868186),
//--TRIMMABLE-BOUNDARY-START(34361770074),
    {
      "r": (T) => $.$$.SCG.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetServices",
      "o": "@$1",
      "d": 2031706,
      "h": 34361770074,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361770074),
//--TRIMMABLE-BOUNDARY-START(30066802778),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetServices",
      "d": 2031706,
      "h": 30066802778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066802778),
//--TRIMMABLE-BOUNDARY-START(12886933594),
    {
      "r": 1048666,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateScope",
      "d": 2031706,
      "h": 12886933594,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886933594),
//--TRIMMABLE-BOUNDARY-START(8591966298),
    {
      "r": 524378,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateAsyncScope",
      "o": "@$1",
      "d": 2031706,
      "h": 8591966298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591966298),
//--TRIMMABLE-BOUNDARY-START(4296999002),
    {
      "r": 524378,
      "p": [
        {
          "n": "serviceScopeFactory",
          "p": 1114202
        }
      ],
      "n": "CreateAsyncScope",
      "d": 2031706,
      "h": 4296999002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296999002)
  ],
  "h": 2031706
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceProviderServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031706)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966170)
        $asm.$cls(`$mxdi.MED.ServiceProviderKeyedServiceExtensions`, ($self) => class ServiceProviderKeyedServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591900762)
            static /*T? */ GetKeyedService$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.MED.IKeyedServiceProvider, { set $v($v){ keyedServiceProvider = $v; } }))
                {
                    return $.$cast(keyedServiceProvider.MED$IKeyedServiceProvider$GetKeyedService(T.$type, serviceKey), T);
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(8591900762)
            
            //--TRIMMABLE-BOUNDARY-START(4296933466)
            static /*object? */ GetKeyedService(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.MED.IKeyedServiceProvider, { set $v($v){ keyedServiceProvider = $v; } }))
                {
                    return keyedServiceProvider.MED$IKeyedServiceProvider$GetKeyedService(serviceType, serviceKey);
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(4296933466)
            
            //--TRIMMABLE-BOUNDARY-START(21476802650)
            static /*object */ GetRequiredKeyedService(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.MED.IKeyedServiceProvider, { set $v($v){ requiredServiceSupportingProvider = $v; } }))
                {
                    return requiredServiceSupportingProvider.MED$IKeyedServiceProvider$GetRequiredKeyedService(serviceType, serviceKey);
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(21476802650)
            
            //--TRIMMABLE-BOUNDARY-START(25771769946)
            static /*T */ GetRequiredKeyedService$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast($.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, T.$type, serviceKey), T);
            }
            //--TRIMMABLE-BOUNDARY-END(25771769946)
            
            //--TRIMMABLE-BOUNDARY-START(17181835354)
            static /*IEnumerable<T> */ GetKeyedServices$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$$.SCG.IEnumerable$$(T), provider, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(17181835354)
            
            //--TRIMMABLE-BOUNDARY-START(12886868058)
            static /*IEnumerable<object?> */ GetKeyedServices(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$$.SCG.IEnumerable$$().$type.MakeGenericType($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.MED.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, genericEnumerable, serviceKey), $.$$.SCG.IEnumerable$$($.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(12886868058)
            
            static $h = 1966170;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900762),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetKeyedService",
      "o": "@$1",
      "d": 1966170,
      "h": 8591900762,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591900762),
//--TRIMMABLE-BOUNDARY-START(4296933466),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 1966170,
      "h": 4296933466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296933466),
//--TRIMMABLE-BOUNDARY-START(21476802650),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 1966170,
      "h": 21476802650,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802650),
//--TRIMMABLE-BOUNDARY-START(25771769946),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetRequiredKeyedService",
      "o": "@$1",
      "d": 1966170,
      "h": 25771769946,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771769946),
//--TRIMMABLE-BOUNDARY-START(17181835354),
    {
      "r": (T) => $.$$.SCG.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetKeyedServices",
      "o": "@$1",
      "d": 1966170,
      "h": 17181835354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181835354),
//--TRIMMABLE-BOUNDARY-START(12886868058),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedServices",
      "d": 1966170,
      "h": 12886868058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886868058)
  ],
  "h": 1966170
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceProviderKeyedServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966170)
        
        

        //--TRIMMABLE-BOUNDARY-START(589914)
        $asm.$cls(`$mxdi.MEDE.ServiceCollectionDescriptorExtensions`, ($self) => class ServiceCollectionDescriptorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(115964706906)
            static /*void */ TryAddKeyedTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedTransient$1(service, serviceKey, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706906)
            
            //--TRIMMABLE-BOUNDARY-START(111669739610)
            static /*void */ TryAddKeyedTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedTransient$1(service, serviceKey, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(111669739610)
            
            //--TRIMMABLE-BOUNDARY-START(107374772314)
            static /*void */ TryAddKeyedTransient(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedTransient(service, serviceKey, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(107374772314)
            
            //--TRIMMABLE-BOUNDARY-START(128849608794)
            static /*void */ TryAddKeyedTransient$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(128849608794)
            
            //--TRIMMABLE-BOUNDARY-START(120259674202)
            static /*void */ TryAddKeyedTransient$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674202)
            
            //--TRIMMABLE-BOUNDARY-START(124554641498)
            static /*void */ TryAddKeyedTransient$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.KeyedTransient$4(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(124554641498)
            
            //--TRIMMABLE-BOUNDARY-START(60130132058)
            static /*void */ TryAddKeyedScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedScoped$1(service, serviceKey, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(60130132058)
            
            //--TRIMMABLE-BOUNDARY-START(55835164762)
            static /*void */ TryAddKeyedScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedScoped$1(service, serviceKey, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164762)
            
            //--TRIMMABLE-BOUNDARY-START(51540197466)
            static /*void */ TryAddKeyedScoped(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedScoped(service, serviceKey, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197466)
            
            //--TRIMMABLE-BOUNDARY-START(73015033946)
            static /*void */ TryAddKeyedScoped$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033946)
            
            //--TRIMMABLE-BOUNDARY-START(64425099354)
            static /*void */ TryAddKeyedScoped$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(64425099354)
            
            //--TRIMMABLE-BOUNDARY-START(68720066650)
            static /*void */ TryAddKeyedScoped$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.KeyedScoped$4(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(68720066650)
            
            //--TRIMMABLE-BOUNDARY-START(85899935834)
            static /*void */ TryAddKeyedSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedSingleton$2(service, serviceKey, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(85899935834)
            
            //--TRIMMABLE-BOUNDARY-START(81604968538)
            static /*void */ TryAddKeyedSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedSingleton$2(service, serviceKey, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(81604968538)
            
            //--TRIMMABLE-BOUNDARY-START(77310001242)
            static /*void */ TryAddKeyedSingleton(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedSingleton(service, serviceKey, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001242)
            
            //--TRIMMABLE-BOUNDARY-START(103079805018)
            static /*void */ TryAddKeyedSingleton$6(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079805018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(103079805018)
            
            //--TRIMMABLE-BOUNDARY-START(90194903130)
            static /*void */ TryAddKeyedSingleton$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(90194903130)
            
            //--TRIMMABLE-BOUNDARY-START(98784837722)
            static /*void */ TryAddKeyedSingleton$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey, /*TService*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.KeyedSingleton$1(TService.$type, serviceKey, $.$box(instance, TService));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837722)
            
            //--TRIMMABLE-BOUNDARY-START(94489870426)
            static /*void */ TryAddKeyedSingleton$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.KeyedSingleton$5(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(94489870426)
            
            //--TRIMMABLE-BOUNDARY-START(25770393690)
            static /*IServiceCollection */ RemoveAllKeyed$1(T, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.RemoveAllKeyed(collection, T.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393690)
            
            //--TRIMMABLE-BOUNDARY-START(21475426394)
            static /*IServiceCollection */ RemoveAllKeyed(/*this IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.SCG$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.SCG$IList$$$get_Item(i);
                    if (descriptor.ServiceType === serviceType && $.$$.S.Object.Equals(descriptor.ServiceKey, serviceKey))
                    {
                        collection.SCG$IList$$$RemoveAt(i);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426394)
            
            //--TRIMMABLE-BOUNDARY-START(4295557210)
            static /*IServiceCollection */ Add(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557210)
            
            //--TRIMMABLE-BOUNDARY-START(8590524506)
            static /*IServiceCollection */ Add$1(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                let $en1 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let descriptor = $en1.SCG$IEnumerator$$$Current;
                    {
                        collection.SCG$ICollection$$$Add(descriptor);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524506)
            
            //--TRIMMABLE-BOUNDARY-START(34360328282)
            static /*void */ TryAdd(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*int*/ let count = collection.SCG$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if (collection.SCG$IList$$$get_Item(i).ServiceType === descriptor.ServiceType && $.$$.S.Object.Equals(collection.SCG$IList$$$get_Item(i).ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                collection.SCG$ICollection$$$Add(descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(34360328282)
            
            //--TRIMMABLE-BOUNDARY-START(38655295578)
            static /*void */ TryAdd$1(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                let $en2 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                while ($en2.SC$1$IEnumerator$MoveNext())
                {
                    let d = $en2.SCG$IEnumerator$$$Current;
                    {
                        $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, d);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655295578)
            
            //--TRIMMABLE-BOUNDARY-START(197569085530)
            static /*void */ TryAddTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Transient$1(service, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(197569085530)
            
            //--TRIMMABLE-BOUNDARY-START(193274118234)
            static /*void */ TryAddTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Transient$1(service, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(193274118234)
            
            //--TRIMMABLE-BOUNDARY-START(188979150938)
            static /*void */ TryAddTransient(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Transient(service, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(188979150938)
            
            //--TRIMMABLE-BOUNDARY-START(210453987418)
            static /*void */ TryAddTransient$5(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(210453987418)
            
            //--TRIMMABLE-BOUNDARY-START(201864052826)
            static /*void */ TryAddTransient$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(201864052826)
            
            //--TRIMMABLE-BOUNDARY-START(206159020122)
            static /*void */ TryAddTransient$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Transient$4(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(206159020122)
            
            //--TRIMMABLE-BOUNDARY-START(141734510682)
            static /*void */ TryAddScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Scoped$1(service, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(141734510682)
            
            //--TRIMMABLE-BOUNDARY-START(137439543386)
            static /*void */ TryAddScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Scoped$1(service, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(137439543386)
            
            //--TRIMMABLE-BOUNDARY-START(133144576090)
            static /*void */ TryAddScoped(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Scoped(service, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(133144576090)
            
            //--TRIMMABLE-BOUNDARY-START(154619412570)
            static /*void */ TryAddScoped$5(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(154619412570)
            
            //--TRIMMABLE-BOUNDARY-START(146029477978)
            static /*void */ TryAddScoped$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(146029477978)
            
            //--TRIMMABLE-BOUNDARY-START(150324445274)
            static /*void */ TryAddScoped$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Scoped$4(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(150324445274)
            
            //--TRIMMABLE-BOUNDARY-START(167504314458)
            static /*void */ TryAddSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Singleton$2(service, service);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314458)
            
            //--TRIMMABLE-BOUNDARY-START(163209347162)
            static /*void */ TryAddSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Singleton$2(service, implementationType);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(163209347162)
            
            //--TRIMMABLE-BOUNDARY-START(158914379866)
            static /*void */ TryAddSingleton(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Singleton(service, implementationFactory);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(158914379866)
            
            //--TRIMMABLE-BOUNDARY-START(184684183642)
            static /*void */ TryAddSingleton$6(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(184684183642)
            
            //--TRIMMABLE-BOUNDARY-START(171799281754)
            static /*void */ TryAddSingleton$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(171799281754)
            
            //--TRIMMABLE-BOUNDARY-START(180389216346)
            static /*void */ TryAddSingleton$5(TService, /*this IServiceCollection*/ collection, /*TService*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.MED.ServiceDescriptor.Singleton$1(TService.$type, $.$box(instance, TService));
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(180389216346)
            
            //--TRIMMABLE-BOUNDARY-START(176094249050)
            static /*void */ TryAddSingleton$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.MED.ServiceDescriptor.Singleton$5(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(176094249050)
            
            //--TRIMMABLE-BOUNDARY-START(42950262874)
            static /*void */ TryAddEnumerable(/*this IServiceCollection*/ services, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*Type?*/ let implementationType = descriptor.GetImplementationType();
                if (implementationType === $.$$.S.Object.$type || implementationType === descriptor.ServiceType)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$mxdi.S.SR.Format$5($.$mxdi.S.SR.TryAddIndistinguishableTypeToEnumerable, implementationType, descriptor.ServiceType), "descriptor");
                }
                /*int*/ let count = services.SCG$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*ServiceDescriptor*/ let service = services.SCG$IList$$$get_Item(i);
                    if (service.ServiceType === descriptor.ServiceType && service.GetImplementationType() === implementationType && $.$$.S.Object.Equals(service.ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                services.SCG$ICollection$$$Add(descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262874)
            
            //--TRIMMABLE-BOUNDARY-START(47245230170)
            static /*void */ TryAddEnumerable$1(/*this IServiceCollection*/ services, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                let $en3 = descriptors.SCG$IEnumerable$$$GetEnumerator();
                while ($en3.SC$1$IEnumerator$MoveNext())
                {
                    let d = $en3.SCG$IEnumerator$$$Current;
                    {
                        $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, d);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245230170)
            
            //--TRIMMABLE-BOUNDARY-START(30065360986)
            static /*IServiceCollection */ Replace(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*int*/ let count = collection.SCG$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if (collection.SCG$IList$$$get_Item(i).ServiceType === descriptor.ServiceType && $.$$.S.Object.Equals(collection.SCG$IList$$$get_Item(i).ServiceKey, descriptor.ServiceKey))
                    {
                        collection.SCG$IList$$$RemoveAt(i);
                        break;
                    }
                }
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360986)
            
            //--TRIMMABLE-BOUNDARY-START(17180459098)
            static /*IServiceCollection */ RemoveAll$1(T, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.RemoveAll(collection, T.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459098)
            
            //--TRIMMABLE-BOUNDARY-START(12885491802)
            static /*IServiceCollection */ RemoveAll(/*this IServiceCollection*/ collection, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.SCG$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.SCG$IList$$$get_Item(i);
                    if (descriptor.ServiceType === serviceType && descriptor.ServiceKey === null)
                    {
                        collection.SCG$IList$$$RemoveAt(i);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491802)
            
            static $h = 589914;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964706906),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$2",
      "d": 589914,
      "h": 115964706906,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964706906),
//--TRIMMABLE-BOUNDARY-START(111669739610),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$1",
      "d": 589914,
      "h": 111669739610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669739610),
//--TRIMMABLE-BOUNDARY-START(107374772314),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddKeyedTransient",
      "d": 589914,
      "h": 107374772314,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374772314),
//--TRIMMABLE-BOUNDARY-START(128849608794),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$5",
      "d": 589914,
      "h": 128849608794,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849608794),
//--TRIMMABLE-BOUNDARY-START(120259674202),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$3",
      "d": 589914,
      "h": 120259674202,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259674202),
//--TRIMMABLE-BOUNDARY-START(124554641498),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$4",
      "d": 589914,
      "h": 124554641498,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554641498),
//--TRIMMABLE-BOUNDARY-START(60130132058),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$2",
      "d": 589914,
      "h": 60130132058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130132058),
//--TRIMMABLE-BOUNDARY-START(55835164762),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$1",
      "d": 589914,
      "h": 55835164762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835164762),
//--TRIMMABLE-BOUNDARY-START(51540197466),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddKeyedScoped",
      "d": 589914,
      "h": 51540197466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540197466),
//--TRIMMABLE-BOUNDARY-START(73015033946),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$5",
      "d": 589914,
      "h": 73015033946,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73015033946),
//--TRIMMABLE-BOUNDARY-START(64425099354),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$3",
      "d": 589914,
      "h": 64425099354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64425099354),
//--TRIMMABLE-BOUNDARY-START(68720066650),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$4",
      "d": 589914,
      "h": 68720066650,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68720066650),
//--TRIMMABLE-BOUNDARY-START(85899935834),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$2",
      "d": 589914,
      "h": 85899935834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899935834),
//--TRIMMABLE-BOUNDARY-START(81604968538),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$1",
      "d": 589914,
      "h": 81604968538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604968538),
//--TRIMMABLE-BOUNDARY-START(77310001242),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddKeyedSingleton",
      "d": 589914,
      "h": 77310001242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310001242),
//--TRIMMABLE-BOUNDARY-START(103079805018),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$6",
      "d": 589914,
      "h": 103079805018,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079805018),
//--TRIMMABLE-BOUNDARY-START(90194903130),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$3",
      "d": 589914,
      "h": 90194903130,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90194903130),
//--TRIMMABLE-BOUNDARY-START(98784837722),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "instance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$5",
      "d": 589914,
      "h": 98784837722,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784837722),
//--TRIMMABLE-BOUNDARY-START(94489870426),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$4",
      "d": 589914,
      "h": 94489870426,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489870426),
//--TRIMMABLE-BOUNDARY-START(25770393690),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveAllKeyed",
      "o": "@$1",
      "d": 589914,
      "h": 25770393690,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770393690),
//--TRIMMABLE-BOUNDARY-START(21475426394),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "RemoveAllKeyed",
      "d": 589914,
      "h": 21475426394,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475426394),
//--TRIMMABLE-BOUNDARY-START(4295557210),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "Add",
      "d": 589914,
      "h": 4295557210,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295557210),
//--TRIMMABLE-BOUNDARY-START(8590524506),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor).$h
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 589914,
      "h": 8590524506,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590524506),
//--TRIMMABLE-BOUNDARY-START(34360328282),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "TryAdd",
      "d": 589914,
      "h": 34360328282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360328282),
//--TRIMMABLE-BOUNDARY-START(38655295578),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor).$h
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": 589914,
      "h": 38655295578,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655295578),
//--TRIMMABLE-BOUNDARY-START(197569085530),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        }
      ],
      "n": "TryAddTransient",
      "o": "@$2",
      "d": 589914,
      "h": 197569085530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197569085530),
//--TRIMMABLE-BOUNDARY-START(193274118234),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddTransient",
      "o": "@$1",
      "d": 589914,
      "h": 193274118234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193274118234),
//--TRIMMABLE-BOUNDARY-START(188979150938),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddTransient",
      "d": 589914,
      "h": 188979150938,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188979150938),
//--TRIMMABLE-BOUNDARY-START(210453987418),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddTransient",
      "o": "@$5",
      "d": 589914,
      "h": 210453987418,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210453987418),
//--TRIMMABLE-BOUNDARY-START(201864052826),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddTransient",
      "o": "@$3",
      "d": 589914,
      "h": 201864052826,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201864052826),
//--TRIMMABLE-BOUNDARY-START(206159020122),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddTransient",
      "o": "@$4",
      "d": 589914,
      "h": 206159020122,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206159020122),
//--TRIMMABLE-BOUNDARY-START(141734510682),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        }
      ],
      "n": "TryAddScoped",
      "o": "@$2",
      "d": 589914,
      "h": 141734510682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734510682),
//--TRIMMABLE-BOUNDARY-START(137439543386),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddScoped",
      "o": "@$1",
      "d": 589914,
      "h": 137439543386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137439543386),
//--TRIMMABLE-BOUNDARY-START(133144576090),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddScoped",
      "d": 589914,
      "h": 133144576090,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133144576090),
//--TRIMMABLE-BOUNDARY-START(154619412570),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddScoped",
      "o": "@$5",
      "d": 589914,
      "h": 154619412570,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(154619412570),
//--TRIMMABLE-BOUNDARY-START(146029477978),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddScoped",
      "o": "@$3",
      "d": 589914,
      "h": 146029477978,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146029477978),
//--TRIMMABLE-BOUNDARY-START(150324445274),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddScoped",
      "o": "@$4",
      "d": 589914,
      "h": 150324445274,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(150324445274),
//--TRIMMABLE-BOUNDARY-START(167504314458),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        }
      ],
      "n": "TryAddSingleton",
      "o": "@$2",
      "d": 589914,
      "h": 167504314458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504314458),
//--TRIMMABLE-BOUNDARY-START(163209347162),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "TryAddSingleton",
      "o": "@$1",
      "d": 589914,
      "h": 163209347162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209347162),
//--TRIMMABLE-BOUNDARY-START(158914379866),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "TryAddSingleton",
      "d": 589914,
      "h": 158914379866,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158914379866),
//--TRIMMABLE-BOUNDARY-START(184684183642),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$6",
      "d": 589914,
      "h": 184684183642,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184684183642),
//--TRIMMABLE-BOUNDARY-START(171799281754),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddSingleton",
      "o": "@$3",
      "d": 589914,
      "h": 171799281754,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(171799281754),
//--TRIMMABLE-BOUNDARY-START(180389216346),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "instance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$5",
      "d": 589914,
      "h": 180389216346,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180389216346),
//--TRIMMABLE-BOUNDARY-START(176094249050),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$4",
      "d": 589914,
      "h": 176094249050,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176094249050),
//--TRIMMABLE-BOUNDARY-START(42950262874),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "TryAddEnumerable",
      "d": 589914,
      "h": 42950262874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950262874),
//--TRIMMABLE-BOUNDARY-START(47245230170),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor).$h
        }
      ],
      "n": "TryAddEnumerable",
      "o": "@$1",
      "d": 589914,
      "h": 47245230170,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245230170),
//--TRIMMABLE-BOUNDARY-START(30065360986),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "Replace",
      "d": 589914,
      "h": 30065360986,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065360986),
//--TRIMMABLE-BOUNDARY-START(17180459098),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveAll",
      "o": "@$1",
      "d": 589914,
      "h": 17180459098,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180459098),
//--TRIMMABLE-BOUNDARY-START(12885491802),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "RemoveAll",
      "d": 589914,
      "h": 12885491802,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885491802)
  ],
  "h": 589914
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}Extensions${separator}ServiceCollectionDescriptorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704026)
        $asm.$cls(`$mxdi.MED.ServiceDescriptor`, ($self) => class ServiceDescriptor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836278874)
            $ctor$7(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$5(serviceType, null, implementationType, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836278874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836278874)
            
            //--TRIMMABLE-BOUNDARY-START(47246344282)
            $ctor$5(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$2(serviceType, serviceKey, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246344282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                    this._implementationType = implementationType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246344282)
            
            //--TRIMMABLE-BOUNDARY-START(51541311578)
            $ctor$6(/*Type*/ serviceType, /*object*/ instance)
            {
                this.$ctor$4(serviceType, null, instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541311578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311578)
            
            //--TRIMMABLE-BOUNDARY-START(42951376986)
            $ctor$4(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ instance)
            {
                this.$ctor$2(serviceType, serviceKey, 0/*ServiceLifetime.Singleton*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951376986);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                    this._implementationInstance = instance;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951376986)
            
            //--TRIMMABLE-BOUNDARY-START(30066475098)
            $ctor$1(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$2(serviceType, null, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066475098);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                    this._implementationFactory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066475098)
            
            //--TRIMMABLE-BOUNDARY-START(38656409690)
            $ctor$3(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$2(serviceType, serviceKey, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656409690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                    if (serviceKey === null)
                    {
                        /*Func<IServiceProvider, object>*/ let nullKeyedFactory = new ($.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object))().$ctor(this,  (/**/ sp) =>
                        {
                            return factory.Invoke(sp, null);
                        }, $jbDeCk ??= {"r":131073,"p":[{"n":"sp","p":327718}],"n":"","d":1704026,"h":0,"f":17825794});
                        this._implementationFactory = nullKeyedFactory;
                    }
                    else 
                    {
                        this._implementationFactory = factory;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656409690)
            
            //--TRIMMABLE-BOUNDARY-START(34361442394)
            $ctor$2(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361442394);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Lifetime = lifetime;
                    this.ServiceType = serviceType;
                    this.ServiceKey = serviceKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361442394)
            
            //--TRIMMABLE-BOUNDARY-START(279174578266)
            /*ServiceLifetime*/ Lifetime = 0;
            //--TRIMMABLE-BOUNDARY-END(279174578266)
            
            //--TRIMMABLE-BOUNDARY-START(304944382042)
            /*object?*/ ServiceKey = null;
            //--TRIMMABLE-BOUNDARY-END(304944382042)
            
            //--TRIMMABLE-BOUNDARY-START(309239349338)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(309239349338)
            
            //--TRIMMABLE-BOUNDARY-START(12886605914)
            /*Type?*/ _implementationType = null;
            //--TRIMMABLE-BOUNDARY-END(12886605914)
            
            //--TRIMMABLE-BOUNDARY-START(184685297754)
            /*Type? */ get ImplementationType()
            {
                return this.IsKeyedService ? null : this._implementationType;
            }
            //--TRIMMABLE-BOUNDARY-END(184685297754)
            
            //--TRIMMABLE-BOUNDARY-START(201865166938)
            /*Type? */ get KeyedImplementationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.MED.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationType;
            }
            //--TRIMMABLE-BOUNDARY-END(201865166938)
            
            //--TRIMMABLE-BOUNDARY-START(8591638618)
            /*object?*/ _implementationInstance = null;
            //--TRIMMABLE-BOUNDARY-END(8591638618)
            
            //--TRIMMABLE-BOUNDARY-START(180390330458)
            /*object? */ get ImplementationInstance()
            {
                return this.IsKeyedService ? null : this._implementationInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(180390330458)
            
            //--TRIMMABLE-BOUNDARY-START(197570199642)
            /*object? */ get KeyedImplementationInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145690202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.MED.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(197570199642)
            
            //--TRIMMABLE-BOUNDARY-START(4296671322)
            /*object?*/ _implementationFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4296671322)
            
            //--TRIMMABLE-BOUNDARY-START(176095363162)
            /*Func<IServiceProvider, object>? */ get ImplementationFactory()
            {
                return this.IsKeyedService ? null : $.$cast(this._implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(176095363162)
            
            //--TRIMMABLE-BOUNDARY-START(193275232346)
            /*Func<IServiceProvider, object?, object>? */ get KeyedImplementationFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555755610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.MED.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return $.$cast(this._implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(193275232346)
            
            //--TRIMMABLE-BOUNDARY-START(188980265050)
            /*bool */ get IsKeyedService()
            {
                return this.ServiceKey !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(188980265050)
            
            //--TRIMMABLE-BOUNDARY-START(347894055002)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894055002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let lifetime = `${$.$strNN("ServiceType")}: ${$.$strNN(this.ServiceType.ToString())} ${$.$strNN("Lifetime")}: ${$.$strNN($.$$.S.Enum.ToStringT($.$mxdi.MED.ServiceLifetime, $.$$.S.UInt32, this.Lifetime))} `;
                if (this.IsKeyedService)
                {
                    lifetime += `${$.$strNN("ServiceKey")}: ${$.$strNN($.$dspc(this.ServiceKey, $.$$.S.Object, ($t) => $t.ToString))} `;
                    if (this.KeyedImplementationType !== null)
                    {
                        return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("KeyedImplementationType")}: ${$.$strNN(this.KeyedImplementationType.ToString())}`);
                    }
                    if (this.KeyedImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$$.SD.DiagnosticMethodInfo.Create(this.KeyedImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("KeyedImplementationFactory")}: ${$.$strNN(declaringTypeName)}.${$.$strNN(methodName)}`);
                    }
                    return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("KeyedImplementationInstance")}: ${$.$strNN($.$dspc(this.KeyedImplementationInstance, $.$$.S.Object, ($t) => $t.ToString))}`);
                }
                else 
                {
                    if (this.ImplementationType !== null)
                    {
                        return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("ImplementationType")}: ${$.$strNN(this.ImplementationType.ToString())}`);
                    }
                    if (this.ImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$$.SD.DiagnosticMethodInfo.Create(this.ImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("ImplementationFactory")}: ${$.$strNN(declaringTypeName)}.${$.$strNN(methodName)}`);
                    }
                    return $.$strNN(lifetime) + $.$strNN(`${$.$strNN("ImplementationInstance")}: ${$.$strNN($.$dspc(this.ImplementationInstance, $.$$.S.Object, ($t) => $t.ToString))}`);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347894055002)
            
            //--TRIMMABLE-BOUNDARY-START(171800395866)
            /*Type */ GetImplementationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800395866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceKey === null)
                {
                    if (this.ImplementationType !== null)
                    {
                        return this.ImplementationType;
                    }
                    else if (this.ImplementationInstance !== null)
                    {
                        return $.$$.S.Object.GetType.call(this.ImplementationInstance);
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$$.S.Object.GetType.call(this.ImplementationFactory).GenericTypeArguments;
                        $.$$.SD.Debug.Assert$4(typeArguments.length === 2, "typeArguments.Length == 2");
                        return $.$$.System.Array.$ReadT1.call(typeArguments, 1);
                    }
                }
                else 
                {
                    if (this.KeyedImplementationType !== null)
                    {
                        return this.KeyedImplementationType;
                    }
                    else if (this.KeyedImplementationInstance !== null)
                    {
                        return $.$$.S.Object.GetType.call(this.KeyedImplementationInstance);
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$$.S.Object.GetType.call(this.KeyedImplementationFactory).GenericTypeArguments;
                        $.$$.SD.Debug.Assert$4(typeArguments.length === 3, "typeArguments.Length == 3");
                        return $.$$.System.Array.$ReadT1.call(typeArguments, 2);
                    }
                }
                $.$$.SD.Debug.Fail$1("ImplementationType, ImplementationInstance, ImplementationFactory or KeyedImplementationFactory must be non null");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171800395866)
            
            //--TRIMMABLE-BOUNDARY-START(360778956890)
            static /*ServiceDescriptor */ Transient$2(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778956890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(360778956890)
            
            //--TRIMMABLE-BOUNDARY-START(270584643674)
            static /*ServiceDescriptor */ KeyedTransient$3(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584643674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(270584643674)
            
            //--TRIMMABLE-BOUNDARY-START(356483989594)
            static /*ServiceDescriptor */ Transient$1(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483989594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceDescriptor.Describe$1(service, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(356483989594)
            
            //--TRIMMABLE-BOUNDARY-START(261994709082)
            static /*ServiceDescriptor */ KeyedTransient$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994709082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(261994709082)
            
            //--TRIMMABLE-BOUNDARY-START(365073924186)
            static /*ServiceDescriptor */ Transient$3(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073924186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(365073924186)
            
            //--TRIMMABLE-BOUNDARY-START(266289676378)
            static /*ServiceDescriptor */ KeyedTransient$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289676378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(266289676378)
            
            //--TRIMMABLE-BOUNDARY-START(369368891482)
            static /*ServiceDescriptor */ Transient$4(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368891482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(369368891482)
            
            //--TRIMMABLE-BOUNDARY-START(274879610970)
            static /*ServiceDescriptor */ KeyedTransient$4(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879610970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(274879610970)
            
            //--TRIMMABLE-BOUNDARY-START(352189022298)
            static /*ServiceDescriptor */ Transient(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189022298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(service, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(352189022298)
            
            //--TRIMMABLE-BOUNDARY-START(257699741786)
            static /*ServiceDescriptor */ KeyedTransient(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699741786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(service, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(257699741786)
            
            //--TRIMMABLE-BOUNDARY-START(292059480154)
            static /*ServiceDescriptor */ Scoped$2(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059480154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292059480154)
            
            //--TRIMMABLE-BOUNDARY-START(219045036122)
            static /*ServiceDescriptor */ KeyedScoped$3(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045036122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(219045036122)
            
            //--TRIMMABLE-BOUNDARY-START(287764512858)
            static /*ServiceDescriptor */ Scoped$1(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764512858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.Describe$1(service, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287764512858)
            
            //--TRIMMABLE-BOUNDARY-START(210455101530)
            static /*ServiceDescriptor */ KeyedScoped$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(210455101530)
            
            //--TRIMMABLE-BOUNDARY-START(296354447450)
            static /*ServiceDescriptor */ Scoped$3(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354447450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296354447450)
            
            //--TRIMMABLE-BOUNDARY-START(214750068826)
            static /*ServiceDescriptor */ KeyedScoped$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750068826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(214750068826)
            
            //--TRIMMABLE-BOUNDARY-START(300649414746)
            static /*ServiceDescriptor */ Scoped$4(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649414746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(300649414746)
            
            //--TRIMMABLE-BOUNDARY-START(223340003418)
            static /*ServiceDescriptor */ KeyedScoped$4(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340003418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(223340003418)
            
            //--TRIMMABLE-BOUNDARY-START(283469545562)
            static /*ServiceDescriptor */ Scoped(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469545562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(service, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(283469545562)
            
            //--TRIMMABLE-BOUNDARY-START(206160134234)
            static /*ServiceDescriptor */ KeyedScoped(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(service, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206160134234)
            
            //--TRIMMABLE-BOUNDARY-START(326419218522)
            static /*ServiceDescriptor */ Singleton$3(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419218522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(326419218522)
            
            //--TRIMMABLE-BOUNDARY-START(244814839898)
            static /*ServiceDescriptor */ KeyedSingleton$4(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814839898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(244814839898)
            
            //--TRIMMABLE-BOUNDARY-START(322124251226)
            static /*ServiceDescriptor */ Singleton$2(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124251226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceDescriptor.Describe$1(service, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(322124251226)
            
            //--TRIMMABLE-BOUNDARY-START(236224905306)
            static /*ServiceDescriptor */ KeyedSingleton$2(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224905306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236224905306)
            
            //--TRIMMABLE-BOUNDARY-START(330714185818)
            static /*ServiceDescriptor */ Singleton$4(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714185818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(330714185818)
            
            //--TRIMMABLE-BOUNDARY-START(240519872602)
            static /*ServiceDescriptor */ KeyedSingleton$3(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519872602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519872602)
            
            //--TRIMMABLE-BOUNDARY-START(335009153114)
            static /*ServiceDescriptor */ Singleton$5(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009153114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)), 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(335009153114)
            
            //--TRIMMABLE-BOUNDARY-START(249109807194)
            static /*ServiceDescriptor */ KeyedSingleton$5(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109807194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)), 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(249109807194)
            
            //--TRIMMABLE-BOUNDARY-START(313534316634)
            static /*ServiceDescriptor */ Singleton(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534316634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.Describe(serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(313534316634)
            
            //--TRIMMABLE-BOUNDARY-START(227634970714)
            static /*ServiceDescriptor */ KeyedSingleton(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634970714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed(serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(227634970714)
            
            //--TRIMMABLE-BOUNDARY-START(339304120410)
            static /*ServiceDescriptor */ Singleton$6(TService, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304120410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.MED.ServiceDescriptor.Singleton$1(TService.$type, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(339304120410)
            
            //--TRIMMABLE-BOUNDARY-START(253404774490)
            static /*ServiceDescriptor */ KeyedSingleton$6(TService, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404774490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.MED.ServiceDescriptor.KeyedSingleton$1(TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(253404774490)
            
            //--TRIMMABLE-BOUNDARY-START(317829283930)
            static /*ServiceDescriptor */ Singleton$1(/*Type*/ serviceType, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829283930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$6(serviceType, implementationInstance);
            }
            //--TRIMMABLE-BOUNDARY-END(317829283930)
            
            //--TRIMMABLE-BOUNDARY-START(231929938010)
            static /*ServiceDescriptor */ KeyedSingleton$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929938010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationInstance);
            }
            //--TRIMMABLE-BOUNDARY-END(231929938010)
            
            //--TRIMMABLE-BOUNDARY-START(81606082650)
            static /*ServiceDescriptor */ DescribeKeyed$2(TService, TImplementation, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606082650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.MED.ServiceDescriptor.DescribeKeyed$1(TService.$type, serviceKey, TImplementation.$type, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(81606082650)
            
            //--TRIMMABLE-BOUNDARY-START(68721180762)
            static /*ServiceDescriptor */ Describe$1(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$7(serviceType, implementationType, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(68721180762)
            
            //--TRIMMABLE-BOUNDARY-START(77311115354)
            static /*ServiceDescriptor */ DescribeKeyed$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$5(serviceType, serviceKey, implementationType, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(77311115354)
            
            //--TRIMMABLE-BOUNDARY-START(64426213466)
            static /*ServiceDescriptor */ Describe(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$1(serviceType, implementationFactory, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(64426213466)
            
            //--TRIMMABLE-BOUNDARY-START(73016148058)
            static /*ServiceDescriptor */ DescribeKeyed(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.MED.ServiceDescriptor().$ctor$3(serviceType, serviceKey, implementationFactory, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(73016148058)
            
            //--TRIMMABLE-BOUNDARY-START(60131246170)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText = `Lifetime = ${$.$strNN($.$$.S.Enum.ToStringT($.$mxdi.MED.ServiceLifetime, $.$$.S.UInt32, this.Lifetime))}, ServiceType = \"${$.$strNN(this.ServiceType.FullName)}\"`;
                if (this.IsKeyedService)
                {
                    debugText += `, ServiceKey = \"${$.$strNN($.$dspc(this.ServiceKey, $.$$.S.Object, ($t) => $t.ToString))}\"`;
                    if (this.KeyedImplementationType !== null)
                    {
                        debugText += `, KeyedImplementationType = \"${$.$strNN(this.KeyedImplementationType.FullName)}\"`;
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        debugText += `, KeyedImplementationFactory = ${$.$strNN($.$dsp(this.KeyedImplementationFactory.Method, $.$$.S.Object, ($t) => $t.ToString))}`;
                    }
                    else 
                    {
                        debugText += `, KeyedImplementationInstance = ${$.$strNN($.$dspc(this.KeyedImplementationInstance, $.$$.S.Object, ($t) => $t.ToString))}`;
                    }
                }
                else 
                {
                    if (this.ImplementationType !== null)
                    {
                        debugText += `, ImplementationType = \"${$.$strNN(this.ImplementationType.FullName)}\"`;
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        debugText += `, ImplementationFactory = ${$.$strNN($.$dsp(this.ImplementationFactory.Method, $.$$.S.Object, ($t) => $t.ToString))}`;
                    }
                    else 
                    {
                        debugText += `, ImplementationInstance = ${$.$strNN($.$dspc(this.ImplementationInstance, $.$$.S.Object, ($t) => $t.ToString))}`;
                    }
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(60131246170)
            
            //--TRIMMABLE-BOUNDARY-START(343599087706)
            static /*void */ ThrowNonKeyedDescriptor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343599087706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.NonKeyedDescriptorMisuse);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343599087706)
            
            static $h = 1704026;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(279174578266),
    {
      "p": 1900634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325559386,
        "f": 50331649
      },
      "n": "Lifetime",
      "d": 1704026,
      "h": 279174578266,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279174578266),
//--TRIMMABLE-BOUNDARY-START(304944382042),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915493978,
        "f": 50331649
      },
      "n": "ServiceKey",
      "d": 1704026,
      "h": 304944382042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304944382042),
//--TRIMMABLE-BOUNDARY-START(309239349338),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505428570,
        "f": 50331649
      },
      "n": "ServiceType",
      "d": 1704026,
      "h": 309239349338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309239349338),
//--TRIMMABLE-BOUNDARY-START(184685297754),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375886426,
        "f": 50331649
      },
      "n": "ImplementationType",
      "d": 1704026,
      "h": 184685297754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685297754),
//--TRIMMABLE-BOUNDARY-START(201865166938),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735624794,
        "f": 50331649
      },
      "n": "KeyedImplementationType",
      "d": 1704026,
      "h": 201865166938,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865166938),
//--TRIMMABLE-BOUNDARY-START(180390330458),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785951834,
        "f": 50331649
      },
      "n": "ImplementationInstance",
      "d": 1704026,
      "h": 180390330458,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390330458),
//--TRIMMABLE-BOUNDARY-START(197570199642),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145690202,
        "f": 50331649
      },
      "n": "KeyedImplementationInstance",
      "d": 1704026,
      "h": 197570199642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570199642),
//--TRIMMABLE-BOUNDARY-START(176095363162),
    {
      "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196017242,
        "f": 50331649
      },
      "n": "ImplementationFactory",
      "d": 1704026,
      "h": 176095363162,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095363162),
//--TRIMMABLE-BOUNDARY-START(193275232346),
    {
      "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555755610,
        "f": 50331649
      },
      "n": "KeyedImplementationFactory",
      "d": 1704026,
      "h": 193275232346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275232346),
//--TRIMMABLE-BOUNDARY-START(188980265050),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965821018,
        "f": 50331649
      },
      "n": "IsKeyedService",
      "d": 1704026,
      "h": 188980265050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980265050)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(347894055002),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1704026,
      "h": 347894055002,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(347894055002),
//--TRIMMABLE-BOUNDARY-START(171800395866),
    {
      "r": 188547073,
      "n": "GetImplementationType",
      "d": 1704026,
      "h": 171800395866,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171800395866),
//--TRIMMABLE-BOUNDARY-START(360778956890),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Transient",
      "o": "@$2",
      "d": 1704026,
      "h": 360778956890,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(360778956890),
//--TRIMMABLE-BOUNDARY-START(270584643674),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedTransient",
      "o": "@$3",
      "d": 1704026,
      "h": 270584643674,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(270584643674),
//--TRIMMABLE-BOUNDARY-START(356483989594),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "Transient",
      "o": "@$1",
      "d": 1704026,
      "h": 356483989594,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(356483989594),
//--TRIMMABLE-BOUNDARY-START(261994709082),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "KeyedTransient",
      "o": "@$1",
      "d": 1704026,
      "h": 261994709082,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261994709082),
//--TRIMMABLE-BOUNDARY-START(365073924186),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Transient",
      "o": "@$3",
      "d": 1704026,
      "h": 365073924186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(365073924186),
//--TRIMMABLE-BOUNDARY-START(266289676378),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedTransient",
      "o": "@$2",
      "d": 1704026,
      "h": 266289676378,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(266289676378),
//--TRIMMABLE-BOUNDARY-START(369368891482),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Transient",
      "o": "@$4",
      "d": 1704026,
      "h": 369368891482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(369368891482),
//--TRIMMABLE-BOUNDARY-START(274879610970),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedTransient",
      "o": "@$4",
      "d": 1704026,
      "h": 274879610970,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(274879610970),
//--TRIMMABLE-BOUNDARY-START(352189022298),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "Transient",
      "d": 1704026,
      "h": 352189022298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(352189022298),
//--TRIMMABLE-BOUNDARY-START(257699741786),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "KeyedTransient",
      "d": 1704026,
      "h": 257699741786,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257699741786),
//--TRIMMABLE-BOUNDARY-START(292059480154),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Scoped",
      "o": "@$2",
      "d": 1704026,
      "h": 292059480154,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(292059480154),
//--TRIMMABLE-BOUNDARY-START(219045036122),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedScoped",
      "o": "@$3",
      "d": 1704026,
      "h": 219045036122,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(219045036122),
//--TRIMMABLE-BOUNDARY-START(287764512858),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "Scoped",
      "o": "@$1",
      "d": 1704026,
      "h": 287764512858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(287764512858),
//--TRIMMABLE-BOUNDARY-START(210455101530),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "KeyedScoped",
      "o": "@$1",
      "d": 1704026,
      "h": 210455101530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210455101530),
//--TRIMMABLE-BOUNDARY-START(296354447450),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Scoped",
      "o": "@$3",
      "d": 1704026,
      "h": 296354447450,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(296354447450),
//--TRIMMABLE-BOUNDARY-START(214750068826),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedScoped",
      "o": "@$2",
      "d": 1704026,
      "h": 214750068826,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214750068826),
//--TRIMMABLE-BOUNDARY-START(300649414746),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Scoped",
      "o": "@$4",
      "d": 1704026,
      "h": 300649414746,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(300649414746),
//--TRIMMABLE-BOUNDARY-START(223340003418),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedScoped",
      "o": "@$4",
      "d": 1704026,
      "h": 223340003418,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(223340003418),
//--TRIMMABLE-BOUNDARY-START(283469545562),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "Scoped",
      "d": 1704026,
      "h": 283469545562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(283469545562),
//--TRIMMABLE-BOUNDARY-START(206160134234),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "KeyedScoped",
      "d": 1704026,
      "h": 206160134234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206160134234),
//--TRIMMABLE-BOUNDARY-START(326419218522),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Singleton",
      "o": "@$3",
      "d": 1704026,
      "h": 326419218522,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(326419218522),
//--TRIMMABLE-BOUNDARY-START(244814839898),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedSingleton",
      "o": "@$4",
      "d": 1704026,
      "h": 244814839898,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(244814839898),
//--TRIMMABLE-BOUNDARY-START(322124251226),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "Singleton",
      "o": "@$2",
      "d": 1704026,
      "h": 322124251226,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(322124251226),
//--TRIMMABLE-BOUNDARY-START(236224905306),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "KeyedSingleton",
      "o": "@$2",
      "d": 1704026,
      "h": 236224905306,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(236224905306),
//--TRIMMABLE-BOUNDARY-START(330714185818),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Singleton",
      "o": "@$4",
      "d": 1704026,
      "h": 330714185818,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(330714185818),
//--TRIMMABLE-BOUNDARY-START(240519872602),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedSingleton",
      "o": "@$3",
      "d": 1704026,
      "h": 240519872602,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(240519872602),
//--TRIMMABLE-BOUNDARY-START(335009153114),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Singleton",
      "o": "@$5",
      "d": 1704026,
      "h": 335009153114,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(335009153114),
//--TRIMMABLE-BOUNDARY-START(249109807194),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedSingleton",
      "o": "@$5",
      "d": 1704026,
      "h": 249109807194,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(249109807194),
//--TRIMMABLE-BOUNDARY-START(313534316634),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "Singleton",
      "d": 1704026,
      "h": 313534316634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313534316634),
//--TRIMMABLE-BOUNDARY-START(227634970714),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "KeyedSingleton",
      "d": 1704026,
      "h": 227634970714,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227634970714),
//--TRIMMABLE-BOUNDARY-START(339304120410),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Singleton",
      "o": "@$6",
      "d": 1704026,
      "h": 339304120410,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(339304120410),
//--TRIMMABLE-BOUNDARY-START(253404774490),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedSingleton",
      "o": "@$6",
      "d": 1704026,
      "h": 253404774490,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(253404774490),
//--TRIMMABLE-BOUNDARY-START(317829283930),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "Singleton",
      "o": "@$1",
      "d": 1704026,
      "h": 317829283930,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317829283930),
//--TRIMMABLE-BOUNDARY-START(231929938010),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "KeyedSingleton",
      "o": "@$1",
      "d": 1704026,
      "h": 231929938010,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231929938010),
//--TRIMMABLE-BOUNDARY-START(81606082650),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "DescribeKeyed",
      "o": "@$2",
      "d": 1704026,
      "h": 81606082650,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(81606082650),
//--TRIMMABLE-BOUNDARY-START(68721180762),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Describe",
      "o": "@$1",
      "d": 1704026,
      "h": 68721180762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721180762),
//--TRIMMABLE-BOUNDARY-START(77311115354),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "DescribeKeyed",
      "o": "@$1",
      "d": 1704026,
      "h": 77311115354,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77311115354),
//--TRIMMABLE-BOUNDARY-START(64426213466),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Describe",
      "d": 1704026,
      "h": 64426213466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426213466),
//--TRIMMABLE-BOUNDARY-START(73016148058),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "DescribeKeyed",
      "d": 1704026,
      "h": 73016148058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016148058),
//--TRIMMABLE-BOUNDARY-START(60131246170),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1704026,
      "h": 60131246170,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60131246170),
//--TRIMMABLE-BOUNDARY-START(343599087706),
    {
      "r": 65537,
      "n": "ThrowNonKeyedDescriptor",
      "d": 1704026,
      "h": 343599087706,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343599087706)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886605914),
    {
      "t": 188547073,
      "n": "_implementationType",
      "d": 1704026,
      "h": 12886605914,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605914),
//--TRIMMABLE-BOUNDARY-START(8591638618),
    {
      "t": 131073,
      "n": "_implementationInstance",
      "d": 1704026,
      "h": 8591638618,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638618),
//--TRIMMABLE-BOUNDARY-START(4296671322),
    {
      "t": 131073,
      "n": "_implementationFactory",
      "d": 1704026,
      "h": 4296671322,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671322)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55836278874),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1704026,
      "h": 55836278874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836278874),
//--TRIMMABLE-BOUNDARY-START(47246344282),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1704026,
      "h": 47246344282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246344282),
//--TRIMMABLE-BOUNDARY-START(51541311578),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1704026,
      "h": 51541311578,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541311578),
//--TRIMMABLE-BOUNDARY-START(42951376986),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1704026,
      "h": 42951376986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951376986),
//--TRIMMABLE-BOUNDARY-START(30066475098),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "factory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704026,
      "h": 30066475098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475098),
//--TRIMMABLE-BOUNDARY-START(38656409690),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "factory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704026,
      "h": 38656409690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656409690),
//--TRIMMABLE-BOUNDARY-START(34361442394),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704026,
      "h": 34361442394,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34361442394)
  ],
  "h": 1704026,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceDescriptor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704026)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638490)
        $asm.$cls(`$mxdi.MED.ServiceCollectionServiceExtensions`, ($self) => class ServiceCollectionServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(193275166810)
            static /*IServiceCollection */ AddTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275166810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193275166810)
            
            //--TRIMMABLE-BOUNDARY-START(188980199514)
            static /*IServiceCollection */ AddTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980199514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(188980199514)
            
            //--TRIMMABLE-BOUNDARY-START(206160068698)
            static /*IServiceCollection */ AddTransient$4(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160068698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$1(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(206160068698)
            
            //--TRIMMABLE-BOUNDARY-START(197570134106)
            static /*IServiceCollection */ AddTransient$2(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570134106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$1(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(197570134106)
            
            //--TRIMMABLE-BOUNDARY-START(214750003290)
            static /*IServiceCollection */ AddTransient$6(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750003290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient$2(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(214750003290)
            
            //--TRIMMABLE-BOUNDARY-START(210455035994)
            static /*IServiceCollection */ AddTransient$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455035994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(210455035994)
            
            //--TRIMMABLE-BOUNDARY-START(201865101402)
            static /*IServiceCollection */ AddTransient$3(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865101402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddTransient(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(201865101402)
            
            //--TRIMMABLE-BOUNDARY-START(124555690074)
            static /*IServiceCollection */ AddScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555690074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124555690074)
            
            //--TRIMMABLE-BOUNDARY-START(120260722778)
            static /*IServiceCollection */ AddScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260722778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120260722778)
            
            //--TRIMMABLE-BOUNDARY-START(137440591962)
            static /*IServiceCollection */ AddScoped$4(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440591962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$1(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(137440591962)
            
            //--TRIMMABLE-BOUNDARY-START(128850657370)
            static /*IServiceCollection */ AddScoped$2(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850657370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$1(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(128850657370)
            
            //--TRIMMABLE-BOUNDARY-START(146030526554)
            static /*IServiceCollection */ AddScoped$6(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030526554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped$2(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(146030526554)
            
            //--TRIMMABLE-BOUNDARY-START(141735559258)
            static /*IServiceCollection */ AddScoped$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735559258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(141735559258)
            
            //--TRIMMABLE-BOUNDARY-START(133145624666)
            static /*IServiceCollection */ AddScoped$3(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145624666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddScoped(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(133145624666)
            
            //--TRIMMABLE-BOUNDARY-START(158915428442)
            static /*IServiceCollection */ AddSingleton$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915428442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158915428442)
            
            //--TRIMMABLE-BOUNDARY-START(150325493850)
            static /*IServiceCollection */ AddSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325493850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150325493850)
            
            //--TRIMMABLE-BOUNDARY-START(171800330330)
            static /*IServiceCollection */ AddSingleton$5(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800330330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$2(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(171800330330)
            
            //--TRIMMABLE-BOUNDARY-START(163210395738)
            static /*IServiceCollection */ AddSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210395738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$2(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(163210395738)
            
            //--TRIMMABLE-BOUNDARY-START(184685232218)
            static /*IServiceCollection */ AddSingleton$8(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685232218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$3(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(184685232218)
            
            //--TRIMMABLE-BOUNDARY-START(176095297626)
            static /*IServiceCollection */ AddSingleton$6(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095297626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(176095297626)
            
            //--TRIMMABLE-BOUNDARY-START(167505363034)
            static /*IServiceCollection */ AddSingleton$4(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505363034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton(services, TService.$type, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation), $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(167505363034)
            
            //--TRIMMABLE-BOUNDARY-START(154620461146)
            static /*IServiceCollection */ AddSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620461146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$6(serviceType, implementationInstance);
                services.SCG$ICollection$$$Add(serviceDescriptor);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(154620461146)
            
            //--TRIMMABLE-BOUNDARY-START(180390264922)
            static /*IServiceCollection */ AddSingleton$7(TService, /*this IServiceCollection*/ services, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390264922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddSingleton$1(services, TService.$type, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(180390264922)
            
            //--TRIMMABLE-BOUNDARY-START(8591573082)
            static /*IServiceCollection */ Add$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$7(serviceType, implementationType, lifetime);
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573082)
            
            //--TRIMMABLE-BOUNDARY-START(4296605786)
            static /*IServiceCollection */ Add(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$1(serviceType, implementationFactory, lifetime);
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605786)
            
            //--TRIMMABLE-BOUNDARY-START(94490919002)
            static /*IServiceCollection */ AddKeyedTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490919002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94490919002)
            
            //--TRIMMABLE-BOUNDARY-START(90195951706)
            static /*IServiceCollection */ AddKeyedTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195951706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90195951706)
            
            //--TRIMMABLE-BOUNDARY-START(107375820890)
            static /*IServiceCollection */ AddKeyedTransient$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375820890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(107375820890)
            
            //--TRIMMABLE-BOUNDARY-START(98785886298)
            static /*IServiceCollection */ AddKeyedTransient$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785886298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(98785886298)
            
            //--TRIMMABLE-BOUNDARY-START(115965755482)
            static /*IServiceCollection */ AddKeyedTransient$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965755482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient$2(services, TService.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(115965755482)
            
            //--TRIMMABLE-BOUNDARY-START(111670788186)
            static /*IServiceCollection */ AddKeyedTransient$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670788186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(111670788186)
            
            //--TRIMMABLE-BOUNDARY-START(103080853594)
            static /*IServiceCollection */ AddKeyedTransient$3(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080853594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedTransient(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(103080853594)
            
            //--TRIMMABLE-BOUNDARY-START(25771442266)
            static /*IServiceCollection */ AddKeyedScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25771442266)
            
            //--TRIMMABLE-BOUNDARY-START(21476474970)
            static /*IServiceCollection */ AddKeyedScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476474970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21476474970)
            
            //--TRIMMABLE-BOUNDARY-START(38656344154)
            static /*IServiceCollection */ AddKeyedScoped$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656344154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(38656344154)
            
            //--TRIMMABLE-BOUNDARY-START(30066409562)
            static /*IServiceCollection */ AddKeyedScoped$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066409562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(30066409562)
            
            //--TRIMMABLE-BOUNDARY-START(47246278746)
            static /*IServiceCollection */ AddKeyedScoped$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246278746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedScoped$2(services, TService.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(47246278746)
            
            //--TRIMMABLE-BOUNDARY-START(42951311450)
            static /*IServiceCollection */ AddKeyedScoped$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951311450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedScoped(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(42951311450)
            
            //--TRIMMABLE-BOUNDARY-START(34361376858)
            static /*IServiceCollection */ AddKeyedScoped$3(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361376858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedScoped(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(34361376858)
            
            //--TRIMMABLE-BOUNDARY-START(60131180634)
            static /*IServiceCollection */ AddKeyedSingleton$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131180634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60131180634)
            
            //--TRIMMABLE-BOUNDARY-START(51541246042)
            static /*IServiceCollection */ AddKeyedSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541246042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51541246042)
            
            //--TRIMMABLE-BOUNDARY-START(73016082522)
            static /*IServiceCollection */ AddKeyedSingleton$5(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016082522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(73016082522)
            
            //--TRIMMABLE-BOUNDARY-START(64426147930)
            static /*IServiceCollection */ AddKeyedSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426147930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(64426147930)
            
            //--TRIMMABLE-BOUNDARY-START(85900984410)
            static /*IServiceCollection */ AddKeyedSingleton$8(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900984410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(85900984410)
            
            //--TRIMMABLE-BOUNDARY-START(77311049818)
            static /*IServiceCollection */ AddKeyedSingleton$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311049818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(77311049818)
            
            //--TRIMMABLE-BOUNDARY-START(68721115226)
            static /*IServiceCollection */ AddKeyedSingleton$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721115226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, $.$$.N.InterfaceVarianceStubHandler.Create(implementationFactory, $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation), $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object)));
            }
            //--TRIMMABLE-BOUNDARY-END(68721115226)
            
            //--TRIMMABLE-BOUNDARY-START(55836213338)
            static /*IServiceCollection */ AddKeyedSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836213338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationInstance);
                services.SCG$ICollection$$$Add(serviceDescriptor);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(55836213338)
            
            //--TRIMMABLE-BOUNDARY-START(81606017114)
            static /*IServiceCollection */ AddKeyedSingleton$7(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606017114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.S.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.MED.ServiceCollectionServiceExtensions.AddKeyedSingleton$1(services, TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(81606017114)
            
            //--TRIMMABLE-BOUNDARY-START(17181507674)
            static /*IServiceCollection */ AddKeyed$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$5(serviceType, serviceKey, implementationType, lifetime);
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507674)
            
            //--TRIMMABLE-BOUNDARY-START(12886540378)
            static /*IServiceCollection */ AddKeyed(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.MED.ServiceDescriptor().$ctor$3(serviceType, serviceKey, implementationFactory, lifetime);
                collection.SCG$ICollection$$$Add(descriptor);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540378)
            
            static $h = 1638490;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(193275166810),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddTransient",
      "o": "@$1",
      "d": 1638490,
      "h": 193275166810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193275166810),
//--TRIMMABLE-BOUNDARY-START(188980199514),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "AddTransient",
      "d": 1638490,
      "h": 188980199514,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188980199514),
//--TRIMMABLE-BOUNDARY-START(206160068698),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddTransient",
      "o": "@$4",
      "d": 1638490,
      "h": 206160068698,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206160068698),
//--TRIMMABLE-BOUNDARY-START(197570134106),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "AddTransient",
      "o": "@$2",
      "d": 1638490,
      "h": 197570134106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197570134106),
//--TRIMMABLE-BOUNDARY-START(214750003290),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddTransient",
      "o": "@$6",
      "d": 1638490,
      "h": 214750003290,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214750003290),
//--TRIMMABLE-BOUNDARY-START(210455035994),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddTransient",
      "o": "@$5",
      "d": 1638490,
      "h": 210455035994,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210455035994),
//--TRIMMABLE-BOUNDARY-START(201865101402),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddTransient",
      "o": "@$3",
      "d": 1638490,
      "h": 201865101402,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201865101402),
//--TRIMMABLE-BOUNDARY-START(124555690074),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddScoped",
      "o": "@$1",
      "d": 1638490,
      "h": 124555690074,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555690074),
//--TRIMMABLE-BOUNDARY-START(120260722778),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "AddScoped",
      "d": 1638490,
      "h": 120260722778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260722778),
//--TRIMMABLE-BOUNDARY-START(137440591962),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddScoped",
      "o": "@$4",
      "d": 1638490,
      "h": 137440591962,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(137440591962),
//--TRIMMABLE-BOUNDARY-START(128850657370),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "AddScoped",
      "o": "@$2",
      "d": 1638490,
      "h": 128850657370,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850657370),
//--TRIMMABLE-BOUNDARY-START(146030526554),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddScoped",
      "o": "@$6",
      "d": 1638490,
      "h": 146030526554,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146030526554),
//--TRIMMABLE-BOUNDARY-START(141735559258),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddScoped",
      "o": "@$5",
      "d": 1638490,
      "h": 141735559258,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(141735559258),
//--TRIMMABLE-BOUNDARY-START(133145624666),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddScoped",
      "o": "@$3",
      "d": 1638490,
      "h": 133145624666,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133145624666),
//--TRIMMABLE-BOUNDARY-START(158915428442),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddSingleton",
      "o": "@$2",
      "d": 1638490,
      "h": 158915428442,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158915428442),
//--TRIMMABLE-BOUNDARY-START(150325493850),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        }
      ],
      "n": "AddSingleton",
      "d": 1638490,
      "h": 150325493850,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150325493850),
//--TRIMMABLE-BOUNDARY-START(171800330330),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddSingleton",
      "o": "@$5",
      "d": 1638490,
      "h": 171800330330,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(171800330330),
//--TRIMMABLE-BOUNDARY-START(163210395738),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "AddSingleton",
      "o": "@$3",
      "d": 1638490,
      "h": 163210395738,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163210395738),
//--TRIMMABLE-BOUNDARY-START(184685232218),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$8",
      "d": 1638490,
      "h": 184685232218,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184685232218),
//--TRIMMABLE-BOUNDARY-START(176095297626),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$6",
      "d": 1638490,
      "h": 176095297626,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176095297626),
//--TRIMMABLE-BOUNDARY-START(167505363034),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$($.$scm.S.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddSingleton",
      "o": "@$4",
      "d": 1638490,
      "h": 167505363034,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(167505363034),
//--TRIMMABLE-BOUNDARY-START(154620461146),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "AddSingleton",
      "o": "@$1",
      "d": 1638490,
      "h": 154620461146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154620461146),
//--TRIMMABLE-BOUNDARY-START(180390264922),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$7",
      "d": 1638490,
      "h": 180390264922,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180390264922),
//--TRIMMABLE-BOUNDARY-START(8591573082),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1638490,
      "h": 8591573082,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591573082),
//--TRIMMABLE-BOUNDARY-START(4296605786),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$($.$scm.S.IServiceProvider, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Add",
      "d": 1638490,
      "h": 4296605786,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296605786),
//--TRIMMABLE-BOUNDARY-START(94490919002),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddKeyedTransient",
      "o": "@$1",
      "d": 1638490,
      "h": 94490919002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490919002),
//--TRIMMABLE-BOUNDARY-START(90195951706),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "AddKeyedTransient",
      "d": 1638490,
      "h": 90195951706,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90195951706),
//--TRIMMABLE-BOUNDARY-START(107375820890),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedTransient",
      "o": "@$4",
      "d": 1638490,
      "h": 107375820890,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107375820890),
//--TRIMMABLE-BOUNDARY-START(98785886298),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedTransient",
      "o": "@$2",
      "d": 1638490,
      "h": 98785886298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785886298),
//--TRIMMABLE-BOUNDARY-START(115965755482),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedTransient",
      "o": "@$6",
      "d": 1638490,
      "h": 115965755482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115965755482),
//--TRIMMABLE-BOUNDARY-START(111670788186),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedTransient",
      "o": "@$5",
      "d": 1638490,
      "h": 111670788186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111670788186),
//--TRIMMABLE-BOUNDARY-START(103080853594),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedTransient",
      "o": "@$3",
      "d": 1638490,
      "h": 103080853594,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103080853594),
//--TRIMMABLE-BOUNDARY-START(25771442266),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddKeyedScoped",
      "o": "@$1",
      "d": 1638490,
      "h": 25771442266,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771442266),
//--TRIMMABLE-BOUNDARY-START(21476474970),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "AddKeyedScoped",
      "d": 1638490,
      "h": 21476474970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476474970),
//--TRIMMABLE-BOUNDARY-START(38656344154),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedScoped",
      "o": "@$4",
      "d": 1638490,
      "h": 38656344154,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38656344154),
//--TRIMMABLE-BOUNDARY-START(30066409562),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedScoped",
      "o": "@$2",
      "d": 1638490,
      "h": 30066409562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066409562),
//--TRIMMABLE-BOUNDARY-START(47246278746),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedScoped",
      "o": "@$6",
      "d": 1638490,
      "h": 47246278746,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47246278746),
//--TRIMMABLE-BOUNDARY-START(42951311450),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedScoped",
      "o": "@$5",
      "d": 1638490,
      "h": 42951311450,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42951311450),
//--TRIMMABLE-BOUNDARY-START(34361376858),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedScoped",
      "o": "@$3",
      "d": 1638490,
      "h": 34361376858,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361376858),
//--TRIMMABLE-BOUNDARY-START(60131180634),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$2",
      "d": 1638490,
      "h": 60131180634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131180634),
//--TRIMMABLE-BOUNDARY-START(51541246042),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        }
      ],
      "n": "AddKeyedSingleton",
      "d": 1638490,
      "h": 51541246042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541246042),
//--TRIMMABLE-BOUNDARY-START(73016082522),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$5",
      "d": 1638490,
      "h": 73016082522,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73016082522),
//--TRIMMABLE-BOUNDARY-START(64426147930),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$3",
      "d": 1638490,
      "h": 64426147930,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426147930),
//--TRIMMABLE-BOUNDARY-START(85900984410),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$8",
      "d": 1638490,
      "h": 85900984410,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85900984410),
//--TRIMMABLE-BOUNDARY-START(77311049818),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$6",
      "d": 1638490,
      "h": 77311049818,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77311049818),
//--TRIMMABLE-BOUNDARY-START(68721115226),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$4",
      "d": 1638490,
      "h": 68721115226,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68721115226),
//--TRIMMABLE-BOUNDARY-START(55836213338),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$1",
      "d": 1638490,
      "h": 55836213338,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836213338),
//--TRIMMABLE-BOUNDARY-START(81606017114),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$7",
      "d": 1638490,
      "h": 81606017114,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81606017114),
//--TRIMMABLE-BOUNDARY-START(17181507674),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 188547073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "AddKeyed",
      "o": "@$1",
      "d": 1638490,
      "h": 17181507674,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181507674),
//--TRIMMABLE-BOUNDARY-START(12886540378),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.S.Func$$$$($.$scm.S.IServiceProvider, $.$$.S.Object, $.$$.S.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "AddKeyed",
      "d": 1638490,
      "h": 12886540378,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886540378)
  ],
  "h": 1638490
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceCollectionServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638490)
        
        

        //--TRIMMABLE-BOUNDARY-START(65626)
        $asm.$cls(`$mxdi.MED.ActivatorUtilities`, ($self) => class ActivatorUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(107374248026)
            /*ConcurrentDictionary<Type, ConstructorInfoEx[]>*/ static s_constructorInfos = null;
            //--TRIMMABLE-BOUNDARY-END(107374248026)
            
            //--TRIMMABLE-BOUNDARY-START(103079280730)
            /*Lazy<ConditionalWeakTable<Type, ConstructorInfoEx[]>>*/ static s_collectibleConstructorInfos = null;
            //--TRIMMABLE-BOUNDARY-END(103079280730)
            
            //--TRIMMABLE-BOUNDARY-START(51539673178)
            /*int*/ static FixedArgumentThreshold = 4;
            //--TRIMMABLE-BOUNDARY-END(51539673178)
            
            //--TRIMMABLE-BOUNDARY-START(68719542362)
            /*MethodInfo*/ static GetServiceInfo = null;
            //--TRIMMABLE-BOUNDARY-END(68719542362)
            
            //--TRIMMABLE-BOUNDARY-START(34359803994)
            static /*object */ CreateInstance(/*IServiceProvider*/ provider, /*Type*/ instanceType, /*params object[]*/ parameters)
            {
                /*ConstructorInfo*/ let constructorInfo;
                /*int?[]*/ let parameterMap;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                if (instanceType.IsAbstract$1)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.CannotCreateAbstractClasses);
                }
                /*ConstructorInfoEx[]?*/ let constructors;
                if (!$.$mxdi.MED.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx))))
                {
                    constructors = $.$mxdi.MED.ActivatorUtilities.GetOrAddConstructors(instanceType);
                }
                /*StackAllocatedObjects*/ let stackValues = new $.$mxdi.MED.ActivatorUtilities.StackAllocatedObjects();
                /*int*/ let maxArgs = GetMaxArgCount.call(this);
                /*Span<object?>*/ let values = maxArgs <= $.trunc(8/*StackAllocatedObjects.MaxStackAllocArgCount*/ / 2) ? $.$$.S.Span$$($.$$.S.Object).op_Implicit$2(stackValues.$fields) : $.$$.S.Span$$($.$$.S.Object).op_Implicit$2($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [((maxArgs * 2) | 0)], null));
                /*Span<object?>*/ let ctorArgs = values.Slice(0, maxArgs);
                /*Span<object?>*/ let bestCtorArgs = values.Slice(maxArgs, maxArgs);
                /*scoped ConstructorMatcher*/ let matcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher();
                /*ConstructorInfoEx?*/ let $constructor;
                /*IServiceProviderIsService?*/ let serviceProviderIsService = $.$mxdi.MED.ServiceProviderServiceExtensions.GetService($.$mxdi.MED.IServiceProviderIsService, provider);
                if (serviceProviderIsService !== null)
                {
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$$.System.Array.$ReadT1.call(constructors, i);
                        if ($constructor.IsPreferred)
                        {
                            for(/*int*/ let j = ((i + 1) | 0); j < constructors.length; j++)
                            {
                                if ($.$$.System.Array.$ReadT1.call(constructors, j).IsPreferred)
                                {
                                    $.$mxdi.MED.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                                }
                            }
                            InitializeCtorArgValues($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Object), () => ctorArgs, ($v) => ctorArgs = $v, null, true), $constructor.Parameters.length);
                            matcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                            if (matcher.Match(parameters, serviceProviderIsService) === -1)
                            {
                                $.$mxdi.MED.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                            }
                            return matcher.CreateInstance(provider);
                        }
                    }
                    /*int*/ let bestLength = -1;
                    /*scoped ConstructorMatcher*/ let bestMatcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher();
                    /*bool*/ let multipleBestLengthFound = false;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$$.System.Array.$ReadT1.call(constructors, i);
                        InitializeCtorArgValues($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Object), () => ctorArgs, ($v) => ctorArgs = $v, null, true), $constructor.Parameters.length);
                        matcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                        /*int*/ let length = matcher.Match(parameters, serviceProviderIsService);
                        $.$$.SD.Debug.Assert$4(!$constructor.IsPreferred, "!constructor.IsPreferred");
                        if (bestLength < length)
                        {
                            bestLength = length;
                            ctorArgs.CopyTo(bestCtorArgs);
                            bestMatcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher().$ctor$3(matcher.ConstructorInfo, bestCtorArgs);
                            multipleBestLengthFound = false;
                        }
                        else if (bestLength === length)
                        {
                            multipleBestLengthFound = true;
                        }
                    }
                    if (bestLength !== -1)
                    {
                        if (multipleBestLengthFound)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$5($.$mxdi.S.SR.MultipleCtorsFoundWithBestLength, instanceType, $.$box(bestLength, $.$$.S.Int32)));
                        }
                        return bestMatcher.CreateInstance(provider);
                    }
                }
                /*Type?[]*/ let argumentTypes;
                if (parameters.length === 0)
                {
                    argumentTypes = $.$$.S.Type.EmptyTypes;
                }
                else 
                {
                    argumentTypes = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Type), null, [parameters.length], null);
                    for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                    {
                        /*object*/ let __ca1__;
                        $.$$.System.Array.$WriteT1.call(argumentTypes, ((__ca1__ = $.$$.System.Array.$ReadT1.call(parameters, i)) !== null ? $.$$.S.Object.GetType.call(__ca1__) : null), i);
                    }
                }
                $.$mxdi.MED.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.SR.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32))));
                $constructor = $.$mxdi.MED.ActivatorUtilities.FindConstructorEx(constructorInfo, constructors);
                InitializeCtorArgValues($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Span$$($.$$.S.Object), () => ctorArgs, ($v) => ctorArgs = $v, null, true), $constructor.Parameters.length);
                matcher = new $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                matcher.MapParameters(parameterMap, parameters);
                return matcher.CreateInstance(provider);
                /*int*/  function GetMaxArgCount()
                {
                    /*int*/ let max = 0;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        max = $.$$.S.Int32.Max(max, $.$$.System.Array.$ReadT1.call(constructors, i).Parameters.length);
                    }
                    return max;
                }
                /*static void*/  function InitializeCtorArgValues(/*ref Span<object?>*/ ctorArgs, /*int*/ _)
                {
                    ctorArgs.$v.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803994)
            
            //--TRIMMABLE-BOUNDARY-START(60129607770)
            static /*ConstructorInfoEx[] */ GetOrAddConstructors(/*Type*/ type)
            {
                /*ConstructorInfoEx[]?*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.Assembly.IsCollectible)
                {
                    return $.$mxdi.MED.ActivatorUtilities.s_constructorInfos.GetOrAdd$1(type, $.$mxdi.MED.ActivatorUtilities.CreateConstructorInfoExs(type));
                }
                if ($.$mxdi.MED.ActivatorUtilities.s_collectibleConstructorInfos.Value.TryGetValue(type, $.$ref(() => value, ($v) => value = $v, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx))))
                {
                    return value;
                }
                value = $.$mxdi.MED.ActivatorUtilities.CreateConstructorInfoExs(type);
                $.$mxdi.MED.ActivatorUtilities.s_collectibleConstructorInfos.Value.AddOrUpdate(type, value);
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(60129607770)
            
            //--TRIMMABLE-BOUNDARY-START(12884967514)
            static /*ConstructorInfoEx[] */ CreateConstructorInfoExs(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors();
                /*ConstructorInfoEx[]?*/ let value = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx), null, [constructors.length], null);
                for(/*int*/ let i = 0; i < constructors.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(value, new $.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx().$ctor$1($.$$.System.Array.$ReadT1.call(constructors, i)), i);
                }
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967514)
            
            //--TRIMMABLE-BOUNDARY-START(17179934810)
            static /*ObjectFactory */ CreateFactory(/*Type*/ instanceType, /*Type[]*/ argumentTypes)
            {
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    return $.$mxdi.MED.ActivatorUtilities.CreateFactoryReflection(instanceType, argumentTypes);
                }
                $.$mxdi.MED.ActivatorUtilities.CreateFactoryInternal(instanceType, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.SLE.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.SLE.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.SLE.Expression));
                /*var*/ let factoryLambda = $.$sle.SLE.Expression.Lambda$15($.$mxdi.MED.ObjectFactory, factoryExpressionBody, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934810)
            
            //--TRIMMABLE-BOUNDARY-START(21474902106)
            static /*ObjectFactory<T> */ CreateFactory$1(T, /*Type[]*/ argumentTypes)
            {
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    /*var*/ let factory = $.$mxdi.MED.ActivatorUtilities.CreateFactoryReflection(T.$type, argumentTypes);
                    return new ($.$mxdi.MED.ObjectFactory$$(T))().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$cast(factory.Invoke(serviceProvider, $arguments), T);
                    }, $jytXVh ??= {"r":(T) => T.$h,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794});
                }
                $.$mxdi.MED.ActivatorUtilities.CreateFactoryInternal(T.$type, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.SLE.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.SLE.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.SLE.Expression));
                /*var*/ let factoryLambda = $.$sle.SLE.Expression.Lambda$15($.$mxdi.MED.ObjectFactory$$(T), factoryExpressionBody, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory<T>?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902106)
            
            //--TRIMMABLE-BOUNDARY-START(25769869402)
            static /*void */ CreateFactoryInternal(/*Type*/ instanceType, /*Type[]*/ argumentTypes, /*out ParameterExpression*/ provider, /*out ParameterExpression*/ argumentArray, /*out Expression*/ factoryExpressionBody)
            {
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$$.SR.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32))));
                provider.$v = $.$sle.SLE.Expression.Parameter($.$scm.S.IServiceProvider.$type, "provider");
                argumentArray.$v = $.$sle.SLE.Expression.Parameter($.$typeArray($.$$.S.Object).$type, "argumentArray");
                factoryExpressionBody.$v = $.$mxdi.MED.ActivatorUtilities.BuildFactoryExpression($constructor, parameterMap, provider.$v, argumentArray.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(25769869402)
            
            //--TRIMMABLE-BOUNDARY-START(38654771290)
            static /*T */ CreateInstance$1(T, /*IServiceProvider*/ provider, /*params object[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mxdi.MED.ActivatorUtilities.CreateInstance(provider, T.$type, parameters), T);
            }
            //--TRIMMABLE-BOUNDARY-END(38654771290)
            
            //--TRIMMABLE-BOUNDARY-START(77309476954)
            static /*T */ GetServiceOrCreateInstance$1(T, /*IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mxdi.MED.ActivatorUtilities.GetServiceOrCreateInstance(provider, T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(77309476954)
            
            //--TRIMMABLE-BOUNDARY-START(73014509658)
            static /*object */ GetServiceOrCreateInstance(/*IServiceProvider*/ provider, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return provider.S$IServiceProvider$GetService(type) ?? $.$mxdi.MED.ActivatorUtilities.CreateInstance(provider, type, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(73014509658)
            
            //--TRIMMABLE-BOUNDARY-START(64424575066)
            static /*object? */ GetService(/*IServiceProvider*/ sp, /*Type*/ type, /*Type*/ requiredBy, /*bool*/ hasDefaultValue, /*object?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let service = key === null ? sp.S$IServiceProvider$GetService(type) : $.$mxdi.MED.ActivatorUtilities.GetKeyedService(sp, type, key);
                if (service === null && !hasDefaultValue)
                {
                    $.$mxdi.MED.ActivatorUtilities.ThrowHelperUnableToResolveService(type, requiredBy);
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(64424575066)
            
            //--TRIMMABLE-BOUNDARY-START(115964182618)
            static /*void */ ThrowHelperUnableToResolveService(/*Type*/ type, /*Type*/ requiredBy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964182618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$5($.$mxdi.S.SR.UnableToResolveService, type, requiredBy));
            }
            //--TRIMMABLE-BOUNDARY-END(115964182618)
            
            //--TRIMMABLE-BOUNDARY-START(8590000218)
            static /*BlockExpression */ BuildFactoryExpression(/*ConstructorInfo*/ $constructor, /*int?[]*/ parameterMap, /*Expression*/ serviceProvider, /*Expression*/ factoryArgumentArray)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ParameterInfo[]?*/ let constructorParameters = $constructor.GetParameters();
                /*var*/ let constructorArguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    /*object?*/ let defaultValue;
                    /*ParameterInfo?*/ let constructorParameter = $.$$.System.Array.$ReadT1.call(constructorParameters, i);
                    /*Type?*/ let parameterType = constructorParameter.ParameterType;
                    /*bool*/ let hasDefaultValue = $.$mxdi.MEI.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.S.Object));
                    if ($.$$.System.Array.$ReadT1.call(parameterMap, i) !== null)
                    {
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.SLE.Expression.ArrayAccess$1(factoryArgumentArray, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [ $.$sle.SLE.Expression.Constant$1($.$box($.$$.System.Array.$ReadT1.call(parameterMap, i), $.$$.S.Int32)) ], null, null)), i);
                    }
                    else 
                    {
                        /*var*/ let keyAttribute = $.$cast($.$$.S.Attribute.GetCustomAttribute$6(constructorParameter, $.$mxdi.MED.FromKeyedServicesAttribute.$type, false), $.$mxdi.MED.FromKeyedServicesAttribute);
                        /*var*/ let parameterTypeExpression = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sle.SLE.Expression), [serviceProvider, $.$sle.SLE.Expression.Constant(parameterType, $.$$.S.Type.$type), $.$sle.SLE.Expression.Constant($constructor.DeclaringType, $.$$.S.Type.$type), $.$sle.SLE.Expression.Constant$1($.$box(hasDefaultValue, $.$$.S.Boolean)), $.$sle.SLE.Expression.Constant((keyAttribute?.Key ?? null), $.$$.S.Object.$type)], [-1], null);
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.SLE.Expression.Call$1($.$mxdi.MED.ActivatorUtilities.GetServiceInfo, parameterTypeExpression), i);
                    }
                    if (hasDefaultValue)
                    {
                        /*ConstantExpression?*/ let defaultValueExpression = $.$sle.SLE.Expression.Constant$1(defaultValue);
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.SLE.Expression.Coalesce$1($.$$.System.Array.$ReadT1.call(constructorArguments, i), defaultValueExpression), i);
                    }
                    $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.SLE.Expression.Convert$1($.$$.System.Array.$ReadT1.call(constructorArguments, i), parameterType), i);
                }
                return $.$sle.SLE.Expression.Block$11($.$sle.SLE.Expression.IfThen($.$sle.SLE.Expression.Equal$1(serviceProvider, $.$sle.SLE.Expression.Constant$1(null)), $.$sle.SLE.Expression.Throw$1($.$sle.SLE.Expression.Constant$1(new $.$$.S.ArgumentNullException().$ctor$19("serviceProvider")))), $.$sle.SLE.Expression.New$3($constructor, constructorArguments));
            }
            //--TRIMMABLE-BOUNDARY-END(8590000218)
            
            //--TRIMMABLE-BOUNDARY-START(30064836698)
            static /*ObjectFactory */ CreateFactoryReflection(/*Type*/ instanceType, /*Type?[]*/ argumentTypes)
            {
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MED.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$$.SR.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32))));
                /*Type*/ let declaringType = $constructor.DeclaringType;
                /*ConstructorInvoker*/ let invoker = $.$$.SR.ConstructorInvoker.Create($constructor);
                /*ParameterInfo[]*/ let constructorParameters = $constructor.GetParameters();
                if (constructorParameters.length === 0)
                {
                    return new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments) =>
                    {
                        return invoker.Invoke();
                    }, $Ukzyti ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794});
                }
                /*bool*/ let useFixedValues = constructorParameters.length <= 4/*FixedArgumentThreshold*/;
                /*bool*/ let hasAnyDefaultValues = false;
                /*int*/ let matchedArgCount = 0;
                /*int*/ let matchedArgCountWithMap = 0;
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    hasAnyDefaultValues = $.$$.S.Boolean.op_BitwiseOr$2(hasAnyDefaultValues, $.$$.System.Array.$ReadT1.call(constructorParameters, i).HasDefaultValue);
                    if (!($.$$.System.Array.$ReadT1.call(parameterMap, i) === null))
                    {
                        matchedArgCount++;
                        if ($.$$.System.Array.$ReadT1.call(parameterMap, i) === i)
                        {
                            matchedArgCountWithMap++;
                        }
                    }
                }
                if (hasAnyDefaultValues || matchedArgCount !== matchedArgCountWithMap)
                {
                    return InvokeCanonical.call(this);
                }
                if (matchedArgCount === 0)
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.MED.ActivatorUtilities.ReflectionFactoryServiceOnlyFixed(invoker, parameters, declaringType, serviceProvider);
                    }, $WsfNJe ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794}) : new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.MED.ActivatorUtilities.ReflectionFactoryServiceOnlySpan(invoker, parameters, declaringType, serviceProvider);
                    }, $FUJPpi ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794});
                }
                if (matchedArgCount === constructorParameters.length)
                {
                    return new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.MED.ActivatorUtilities.ReflectionFactoryDirect(invoker, serviceProvider, $arguments);
                    }, $pgJnbc ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794});
                }
                return InvokeCanonical.call(this);
                /*ObjectFactory*/  function InvokeCanonical()
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.MED.ActivatorUtilities.ReflectionFactoryCanonicalFixed(invoker, parameters, declaringType, serviceProvider, $arguments);
                    }, $GHzdtf ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794}) : new $.$mxdi.MED.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.MED.ActivatorUtilities.ReflectionFactoryCanonicalSpan(invoker, parameters, declaringType, serviceProvider, $arguments);
                    }, $bqIEZk ??= {"r":131073,"p":[{"n":"serviceProvider","p":327718},{"n":"arguments","p":$.$typeArray($.$$.S.Object).$h}],"n":"","d":65626,"h":0,"f":17825794});
                }
                /*FactoryParameterContext[]*/  function GetFactoryParameterContext()
                {
                    /*FactoryParameterContext[]*/ let parameters = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext), null, [constructorParameters.length], null);
                    for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                    {
                        /*object?*/ let defaultValue;
                        /*ParameterInfo*/ let constructorParameter = $.$$.System.Array.$ReadT1.call(constructorParameters, i);
                        /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$$.S.Attribute.GetCustomAttribute$6(constructorParameter, $.$mxdi.MED.FromKeyedServicesAttribute.$type, false), $.$mxdi.MED.FromKeyedServicesAttribute);
                        /*bool*/ let hasDefaultValue = $.$mxdi.MEI.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.S.Object));
                        $.$$.System.Array.$WriteT1.call(parameters, new $.$mxdi.MED.ActivatorUtilities.FactoryParameterContext().$ctor$3(constructorParameter.ParameterType, hasDefaultValue, defaultValue, $.$$.System.Array.$ReadT1.call(parameterMap, i) ?? -1, (attr?.Key ?? null)), i);
                    }
                    return parameters;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836698)
            
            //--TRIMMABLE-BOUNDARY-START(327770)
            static $_FactoryParameterContext;
            static get FactoryParameterContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.ActivatorUtilities;
                return $cls.$_FactoryParameterContext ??= $asm.$nstr(`$mxdi.MED.ActivatorUtilities.FactoryParameterContext`, ($self) => class FactoryParameterContext extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30065098842)
                    $ctor$3(/*Type*/ parameterType, /*bool*/ hasDefaultValue, /*object?*/ defaultValue, /*int*/ argumentIndex, /*object?*/ serviceKey)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065098842);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.ParameterType = parameterType;
                            this.HasDefaultValue = hasDefaultValue;
                            this.DefaultValue = defaultValue;
                            this.ArgumentIndex = argumentIndex;
                            this.ServiceKey = serviceKey;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065098842)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194640986)
                    /*Type*/ ParameterType = null;
                    //--TRIMMABLE-BOUNDARY-END(90194640986)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899673690)
                    /*bool*/ HasDefaultValue = false;
                    //--TRIMMABLE-BOUNDARY-END(85899673690)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655033434)
                    /*object?*/ DefaultValue = null;
                    //--TRIMMABLE-BOUNDARY-END(38655033434)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360066138)
                    /*int*/ ArgumentIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(34360066138)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489608282)
                    /*object?*/ ServiceKey = null;
                    //--TRIMMABLE-BOUNDARY-END(94489608282)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131546)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770131546);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131546)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131546)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131546)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ParameterType = this.ParameterType;
                        copy.HasDefaultValue = this.HasDefaultValue;
                        copy.DefaultValue = this.DefaultValue;
                        copy.ArgumentIndex = this.ArgumentIndex;
                        copy.ServiceKey = this.ServiceKey;
                        return copy;
                    }
                    static $h = 327770;
                    static $z = 17;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194640986),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771802,
        "f": 50331649
      },
      "n": "ParameterType",
      "d": 327770,
      "h": 90194640986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640986),
//--TRIMMABLE-BOUNDARY-START(85899673690),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837210,
        "f": 50331649
      },
      "n": "HasDefaultValue",
      "d": 327770,
      "h": 85899673690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899673690),
//--TRIMMABLE-BOUNDARY-START(38655033434),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902618,
        "f": 50331649
      },
      "n": "DefaultValue",
      "d": 327770,
      "h": 38655033434,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033434),
//--TRIMMABLE-BOUNDARY-START(34360066138),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968026,
        "f": 50331649
      },
      "n": "ArgumentIndex",
      "d": 327770,
      "h": 34360066138,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360066138),
//--TRIMMABLE-BOUNDARY-START(94489608282),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604706394,
        "f": 50331649
      },
      "n": "ServiceKey",
      "d": 327770,
      "h": 94489608282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608282)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098842),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 188547073
        },
        {
          "n": "hasDefaultValue",
          "p": 262145
        },
        {
          "n": "defaultValue",
          "p": 131073
        },
        {
          "n": "argumentIndex",
          "p": 655361
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327770,
      "h": 30065098842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098842),
//--TRIMMABLE-BOUNDARY-START(25770131546),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327770,
      "h": 25770131546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131546)
  ],
  "d": 65626,
  "h": 327770
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities+FactoryParameterContext`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities${separator}FactoryParameterContext`; }
                }, $cls, ($v) => $cls.$_FactoryParameterContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327770)
            
            //--TRIMMABLE-BOUNDARY-START(42949738586)
            static /*void */ FindApplicableConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo*/ matchingConstructor, /*out int?[]*/ matchingParameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo?*/ let constructorInfo;
                /*int?[]?*/ let parameterMap;
                if (!$.$mxdi.MED.ActivatorUtilities.TryFindPreferredConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.SR.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32)))) && !$.$mxdi.MED.ActivatorUtilities.TryFindMatchingConstructor(instanceType, argumentTypes, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.SR.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32)))))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$6($.$mxdi.S.SR.CtorNotLocated, instanceType));
                }
                matchingConstructor.$v = constructorInfo;
                matchingParameterMap.$v = parameterMap;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738586)
            
            //--TRIMMABLE-BOUNDARY-START(47244705882)
            static /*ConstructorInfoEx */ FindConstructorEx(/*ConstructorInfo*/ constructorInfo, /*ConstructorInfoEx[]*/ constructorExs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < constructorExs.length; i++)
                {
                    if ($.$$.S.Object.ReferenceEquals($.$$.System.Array.$ReadT1.call(constructorExs, i).Info, constructorInfo))
                    {
                        return $.$$.System.Array.$ReadT1.call(constructorExs, i);
                    }
                }
                $.$$.SD.Debug.Assert$4(false, "false");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705882)
            
            //--TRIMMABLE-BOUNDARY-START(133144051802)
            static /*bool */ TryFindMatchingConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144051802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                let $i24 = 0;
                let $arr24 = instanceType.GetConstructors();
                while ($i24 < $arr24.length)
                {
                    /*int?[]*/ let tempParameterMap;
                    let $constructor = $arr24[$i24++];
                    if ($.$mxdi.MED.ActivatorUtilities.TryCreateParameterMap($constructor.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32)))))
                    {
                        if ($.$$.SR.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$6($.$mxdi.S.SR.MultipleCtorsFound, instanceType));
                        }
                        matchingConstructor.$v = $constructor;
                        parameterMap.$v = tempParameterMap;
                    }
                }
                if ($.$$.SR.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$$.SD.Debug.Assert$4(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(133144051802)
            
            //--TRIMMABLE-BOUNDARY-START(137439019098)
            static /*bool */ TryFindPreferredConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439019098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let seenPreferred = false;
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                if (constructors === null)
                {
                    if (!$.$mxdi.MED.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx))))
                    {
                        constructors = $.$mxdi.MED.ActivatorUtilities.GetOrAddConstructors(instanceType);
                    }
                }
                let $i27 = 0;
                let $arr27 = constructors;
                while ($i27 < $arr27.length)
                {
                    let $constructor = $arr27[$i27++];
                    if ($constructor.IsPreferred)
                    {
                        /*int?[]*/ let tempParameterMap;
                        if (seenPreferred)
                        {
                            $.$mxdi.MED.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                        }
                        if (!$.$mxdi.MED.ActivatorUtilities.TryCreateParameterMap($constructor.Info.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$$.S.Int32)))))
                        {
                            $.$mxdi.MED.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                        }
                        matchingConstructor.$v = $constructor.Info;
                        parameterMap.$v = tempParameterMap;
                        seenPreferred = true;
                    }
                }
                if ($.$$.SR.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$$.SD.Debug.Assert$4(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(137439019098)
            
            //--TRIMMABLE-BOUNDARY-START(128849084506)
            static /*bool */ TryCreateParameterMap(/*ParameterInfo[]*/ constructorParameters, /*Type?[]*/ argumentTypes, /*out int?[]*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parameterMap.$v = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$$.S.Int32)), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                {
                    /*bool*/ let foundMatch = false;
                    /*Type?*/ let givenParameter = $.$$.System.Array.$ReadT1.call(argumentTypes, i);
                    for(/*int*/ let j = 0; j < constructorParameters.length; j++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(parameterMap.$v, j) !== null)
                        {
                            continue;
                        }
                        if ($.$$.System.Array.$ReadT1.call(constructorParameters, j).ParameterType.IsAssignableFrom(givenParameter))
                        {
                            foundMatch = true;
                            $.$$.System.Array.$WriteT1.call(parameterMap.$v, i, j);
                            break;
                        }
                    }
                    if (!foundMatch)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(128849084506)
            
            //--TRIMMABLE-BOUNDARY-START(196698)
            static $_ConstructorInfoEx;
            static get ConstructorInfoEx()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.ActivatorUtilities;
                return $cls.$_ConstructorInfoEx ??= $asm.$ncls(`$mxdi.MED.ActivatorUtilities.ConstructorInfoEx`, ($self) => class ConstructorInfoEx extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(30064967770)
                    /*ConstructorInfo*/ Info = null;
                    //--TRIMMABLE-BOUNDARY-END(30064967770)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836954)
                    /*ParameterInfo[]*/ Parameters = null;
                    //--TRIMMABLE-BOUNDARY-END(47244836954)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654902362)
                    /*bool*/ IsPreferred = false;
                    //--TRIMMABLE-BOUNDARY-END(38654902362)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131290)
                    /*object?[]?*/ _parameterKeys = null;
                    //--TRIMMABLE-BOUNDARY-END(8590131290)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295163994)
                    /*ConstructorInvoker?*/ _invoker = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163994)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935066)
                    /*ConstructorInvoker */ get Invoker()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033178);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._invoker ??= $.$$.SR.ConstructorInvoker.Create(this.Info);
                        return this._invoker;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935066)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098586)
                    $ctor$1(/*ConstructorInfo*/ $constructor)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098586);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Info = $constructor;
                            this.Parameters = $constructor.GetParameters();
                            this.IsPreferred = $constructor.IsDefined($.$mxdi.MED.ActivatorUtilitiesConstructorAttribute.$type, false);
                            for(/*int*/ let i = 0; i < this.Parameters.length; i++)
                            {
                                /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$$.S.Attribute.GetCustomAttribute$6($.$$.System.Array.$ReadT1.call(this.Parameters, i), $.$mxdi.MED.FromKeyedServicesAttribute.$type, false), $.$mxdi.MED.FromKeyedServicesAttribute);
                                if (!(attr === null))
                                {
                                    this._parameterKeys ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [this.Parameters.length], null);
                                    $.$$.System.Array.$WriteT1.call(this._parameterKeys, attr.Key, i);
                                }
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098586)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869658)
                    /*bool */ IsService(/*IServiceProviderIsService*/ serviceProviderIsService, /*int*/ parameterIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949869658);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ParameterInfo*/ let parameterInfo = $.$$.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t29 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t29, ($t) => $.$$.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let serviceProviderIsKeyedService;
                            if ($.$is(serviceProviderIsService, $.$mxdi.MED.IServiceProviderIsKeyedService, { set $v($v){ serviceProviderIsKeyedService = $v; } }))
                            {
                                return serviceProviderIsKeyedService.MED$IServiceProviderIsKeyedService$IsKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
                        }
                        return serviceProviderIsService.MED$IServiceProviderIsService$IsService(parameterInfo.ParameterType);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869658)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000474)
                    /*object? */ GetService(/*IServiceProvider*/ serviceProvider, /*int*/ parameterIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770000474);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ParameterInfo*/ let parameterInfo = $.$$.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t30 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t30, ($t) => $.$$.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let keyedServiceProvider;
                            if ($.$is(serviceProvider, $.$mxdi.MED.IKeyedServiceProvider, { set $v($v){ keyedServiceProvider = $v; } }))
                            {
                                return keyedServiceProvider.MED$IKeyedServiceProvider$GetKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
                        }
                        return serviceProvider.S$IServiceProvider$GetService(parameterInfo.ParameterType);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000474)
                    
                    static $h = 196698;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935066),
    {
      "p": 109248513,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475033178,
        "f": 50331649
      },
      "n": "Invoker",
      "d": 196698,
      "h": 34359935066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935066)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949869658),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceProviderIsService",
          "p": 983130
        },
        {
          "n": "parameterIndex",
          "p": 655361
        }
      ],
      "n": "IsService",
      "d": 196698,
      "h": 42949869658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949869658),
//--TRIMMABLE-BOUNDARY-START(25770000474),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "parameterIndex",
          "p": 655361
        }
      ],
      "n": "GetService",
      "d": 196698,
      "h": 25770000474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000474)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30064967770),
    {
      "t": 109182977,
      "n": "Info",
      "d": 196698,
      "h": 30064967770,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(30064967770),
//--TRIMMABLE-BOUNDARY-START(47244836954),
    {
      "t": $.$typeArray($.$$.SR.ParameterInfo).$h,
      "n": "Parameters",
      "d": 196698,
      "h": 47244836954,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(47244836954),
//--TRIMMABLE-BOUNDARY-START(38654902362),
    {
      "t": 262145,
      "n": "IsPreferred",
      "d": 196698,
      "h": 38654902362,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38654902362),
//--TRIMMABLE-BOUNDARY-START(8590131290),
    {
      "t": $.$typeArray($.$$.S.Object).$h,
      "n": "_parameterKeys",
      "d": 196698,
      "h": 8590131290,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131290),
//--TRIMMABLE-BOUNDARY-START(4295163994),
    {
      "t": 109248513,
      "n": "_invoker",
      "d": 196698,
      "h": 4295163994,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(4295163994)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098586),
    {
      "p": [
        {
          "n": "constructor",
          "p": 109182977
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196698,
      "h": 12885098586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098586)
  ],
  "d": 65626,
  "h": 196698
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities+ConstructorInfoEx`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities${separator}ConstructorInfoEx`; }
                }, $cls, ($v) => $cls.$_ConstructorInfoEx = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196698)
            
            //--TRIMMABLE-BOUNDARY-START(262234)
            static $_ConstructorMatcher;
            static get ConstructorMatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.ActivatorUtilities;
                return $cls.$_ConstructorMatcher ??= $asm.$nstr(`$mxdi.MED.ActivatorUtilities.ConstructorMatcher`, ($self) => class ConstructorMatcher extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295229530)
                    /*ConstructorInfoEx*/ _constructor = null;
                    //--TRIMMABLE-BOUNDARY-END(4295229530)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196826)
                    /*Span<object?>*/ _parameterValues;
                    //--TRIMMABLE-BOUNDARY-END(8590196826)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131418)
                    $ctor$3(/*ConstructorInfoEx*/ $constructor, /*Span<object?>*/ parameterValues)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180131418);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._constructor = $constructor;
                            this._parameterValues = parameterValues;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180131418)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098714)
                    /*ConstructorInfoEx */ get ConstructorInfo()
                    {
                        return this._constructor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475098714)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949935194)
                    /*int */ Match(/*object[]*/ givenParameters, /*IServiceProviderIsService*/ serviceProviderIsService)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949935194);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let givenIndex = 0; givenIndex < givenParameters.length; givenIndex++)
                        {
                            /*object*/ let __ca2__;
                            /*Type?*/ let givenType = ((__ca2__ = $.$$.System.Array.$ReadT1.call(givenParameters, givenIndex)) !== null ? $.$$.S.Object.GetType.call(__ca2__) : null);
                            /*bool*/ let givenMatched = false;
                            for(/*int*/ let applyIndex = 0; applyIndex < this._constructor.Parameters.length; applyIndex++)
                            {
                                if (this._parameterValues._reference.GetAt(applyIndex) === null && $.$$.System.Array.$ReadT1.call(this._constructor.Parameters, applyIndex).ParameterType.IsAssignableFrom(givenType))
                                {
                                    givenMatched = true;
                                    this._parameterValues._reference.SetAt($.$$.System.Array.$ReadT1.call(givenParameters, givenIndex), applyIndex);
                                    break;
                                }
                            }
                            if (!givenMatched)
                            {
                                return -1;
                            }
                        }
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if (this._parameterValues._reference.GetAt(i) === null && !this._constructor.IsService(serviceProviderIsService, i))
                            {
                                /*object?*/ let defaultValue;
                                if ($.$mxdi.MEI.ParameterDefaultValue.TryGetDefaultValue($.$$.System.Array.$ReadT1.call(this._constructor.Parameters, i), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.S.Object)))
                                {
                                    this._parameterValues._reference.SetAt(defaultValue, i);
                                }
                                else 
                                {
                                    return -1;
                                }
                            }
                        }
                        return this._constructor.Parameters.length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949935194)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770066010)
                    /*object */ CreateInstance(/*IServiceProvider*/ provider)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770066010);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let index = 0; index < this._constructor.Parameters.length; index++)
                        {
                            if (this._parameterValues._reference.GetAt(index) === null)
                            {
                                /*object?*/ let value = this._constructor.GetService(provider, index);
                                if (value === null)
                                {
                                    /*object?*/ let defaultValue;
                                    if (!$.$mxdi.MEI.ParameterDefaultValue.TryGetDefaultValue($.$$.System.Array.$ReadT1.call(this._constructor.Parameters, index), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.S.Object)))
                                    {
                                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$5($.$mxdi.S.SR.UnableToResolveService, $.$$.System.Array.$ReadT1.call(this._constructor.Parameters, index).ParameterType, this._constructor.Info.DeclaringType));
                                    }
                                    else 
                                    {
                                        this._parameterValues._reference.SetAt(defaultValue, index);
                                    }
                                }
                                else 
                                {
                                    this._parameterValues._reference.SetAt(value, index);
                                }
                            }
                        }
                        return this._constructor.Invoker.Invoke$5(this._parameterValues.Slice(0, this._constructor.Parameters.length));
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770066010)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654967898)
                    /*void */ MapParameters(/*int?[]*/ parameterMap, /*object[]*/ givenParameters)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38654967898);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if ($.$$.System.Array.$ReadT1.call(parameterMap, i) !== null)
                            {
                                this._parameterValues._reference.SetAt($.$$.System.Array.$ReadT1.call(givenParameters, $.$cast($.$$.System.Array.$ReadT1.call(parameterMap, i), $.$$.S.Int32)), i);
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654967898)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164122)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885164122);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164122)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164122)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164122)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._constructor = this._constructor;
                        copy._parameterValues = this._parameterValues.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590196826)
                        this._parameterValues = $.$default($.$$.S.Span$$($.$$.S.Object));
                        //--TRIMMABLE-BOUNDARY-END(8590196826)
                        
                    }
                    static $h = 262234;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475098714),
    {
      "p": 196698,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000602,
        "f": 50331649
      },
      "n": "ConstructorInfo",
      "d": 262234,
      "h": 21475098714,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098714)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949935194),
    {
      "r": 655361,
      "p": [
        {
          "n": "givenParameters",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "serviceProviderIsService",
          "p": 983130
        }
      ],
      "n": "Match",
      "d": 262234,
      "h": 42949935194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935194),
//--TRIMMABLE-BOUNDARY-START(25770066010),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateInstance",
      "d": 262234,
      "h": 25770066010,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066010),
//--TRIMMABLE-BOUNDARY-START(38654967898),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h
        },
        {
          "n": "givenParameters",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "MapParameters",
      "d": 262234,
      "h": 38654967898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967898)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229530),
    {
      "t": 196698,
      "n": "_constructor",
      "d": 262234,
      "h": 4295229530,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229530),
//--TRIMMABLE-BOUNDARY-START(8590196826),
    {
      "t": $.$$.S.Span$$($.$$.S.Object).$h,
      "n": "_parameterValues",
      "d": 262234,
      "h": 8590196826,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196826)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131418),
    {
      "p": [
        {
          "n": "constructor",
          "p": 196698
        },
        {
          "n": "parameterValues",
          "p": $.$$.S.Span$$($.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262234,
      "h": 17180131418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131418),
//--TRIMMABLE-BOUNDARY-START(12885164122),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262234,
      "h": 12885164122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164122)
  ],
  "d": 65626,
  "h": 262234
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities+ConstructorMatcher`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities${separator}ConstructorMatcher`; }
                }, $cls, ($v) => $cls.$_ConstructorMatcher = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262234)
            
            //--TRIMMABLE-BOUNDARY-START(124554117210)
            static /*void */ ThrowMultipleCtorsMarkedWithAttributeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554117210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$6($.$mxdi.S.SR.MultipleCtorsMarkedWithAttribute, "ActivatorUtilitiesConstructorAttribute"));
            }
            //--TRIMMABLE-BOUNDARY-END(124554117210)
            
            //--TRIMMABLE-BOUNDARY-START(120259149914)
            static /*void */ ThrowMarkedCtorDoesNotTakeAllProvidedArguments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259149914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.Format$6($.$mxdi.S.SR.MarkedCtorMissingArgumentTypes, "ActivatorUtilitiesConstructorAttribute"));
            }
            //--TRIMMABLE-BOUNDARY-END(120259149914)
            
            //--TRIMMABLE-BOUNDARY-START(94489346138)
            static /*object */ ReflectionFactoryServiceOnlyFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$$.SD.Debug.Assert$4(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                let $switch33 = parameters.length;
                switch($switch33)
                {
                    case 1:
                    return invoker.Invoke$4($.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey));
                    case 2:
                    return invoker.Invoke$3($.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey));
                    case 3:
                    return invoker.Invoke$2($.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 2).ServiceKey));
                    case 4:
                    return invoker.Invoke$1($.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 2).ServiceKey), $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 3).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 3).ServiceKey));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(94489346138)
            
            //--TRIMMABLE-BOUNDARY-START(98784313434)
            static /*object */ ReflectionFactoryServiceOnlySpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*object?[]*/ let $arguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call($arguments, $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, i).ServiceKey), i);
                }
                return invoker.Invoke$5($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Object, $arguments));
            }
            //--TRIMMABLE-BOUNDARY-END(98784313434)
            
            //--TRIMMABLE-BOUNDARY-START(81604444250)
            static /*object */ ReflectionFactoryCanonicalFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$$.SD.Debug.Assert$4(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*ref FactoryParameterContext*/ let parameter1 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 0, false, true);
                let $switch34 = parameters.length;
                switch($switch34)
                {
                    case 1:
                    return invoker.Invoke$4(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue);
                    case 2:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        return invoker.Invoke$3(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue);
                    }
                    case 3:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        return invoker.Invoke$2(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue);
                    }
                    case 4:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        /*ref FactoryParameterContext*/ let parameter4 = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, 3, false, true);
                        return invoker.Invoke$1(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue, ((parameter4.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter4.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter4.$v.ParameterType, declaringType, parameter4.$v.HasDefaultValue, parameter4.$v.ServiceKey)) ?? parameter4.$v.DefaultValue);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604444250)
            
            //--TRIMMABLE-BOUNDARY-START(85899411546)
            static /*object */ ReflectionFactoryCanonicalSpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*object?[]*/ let constructorArguments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    /*ref FactoryParameterContext*/ let parameter = $.$$.SRC.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, parameters, i, false, true);
                    $.$$.System.Array.$WriteT1.call(constructorArguments, ((parameter.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter.$v.ArgumentIndex) : $.$mxdi.MED.ActivatorUtilities.GetService(serviceProvider, parameter.$v.ParameterType, declaringType, parameter.$v.HasDefaultValue, parameter.$v.ServiceKey)) ?? parameter.$v.DefaultValue, i);
                }
                return invoker.Invoke$5($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Object, constructorArguments));
            }
            //--TRIMMABLE-BOUNDARY-END(85899411546)
            
            //--TRIMMABLE-BOUNDARY-START(90194378842)
            static /*object */ ReflectionFactoryDirect(/*ConstructorInvoker*/ invoker, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                if ($arguments === null)
                {
                    $.$mxdi.MED.ActivatorUtilities.ThrowHelperNullReferenceException();
                }
                return invoker.Invoke$5($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Object, $arguments));
            }
            //--TRIMMABLE-BOUNDARY-END(90194378842)
            
            //--TRIMMABLE-BOUNDARY-START(111669215322)
            static /*void */ ThrowHelperNullReferenceException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NullReferenceException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(111669215322)
            
            //--TRIMMABLE-BOUNDARY-START(131162)
            static $_ActivatorUtilitiesUpdateHandler;
            static get ActivatorUtilitiesUpdateHandler()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(131162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.ActivatorUtilities;
                return $cls.$_ActivatorUtilitiesUpdateHandler ??= $asm.$ncls(`$mxdi.MED.ActivatorUtilities.ActivatorUtilitiesUpdateHandler`, ($self) => class ActivatorUtilitiesUpdateHandler
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098458)
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295098458);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$mxdi.MED.ActivatorUtilities.s_constructorInfos.Clear();
                        if ($.$mxdi.MED.ActivatorUtilities.s_collectibleConstructorInfos.IsValueCreated)
                        {
                            $.$mxdi.MED.ActivatorUtilities.s_collectibleConstructorInfos.Value.Clear();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295098458)
                    
                    static $h = 131162;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098458),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 131162,
      "h": 4295098458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098458)
  ],
  "d": 65626,
  "h": 131162
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities+ActivatorUtilitiesUpdateHandler`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities${separator}ActivatorUtilitiesUpdateHandler`; }
                }, $cls, ($v) => $cls.$_ActivatorUtilitiesUpdateHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131162)
            
            //--TRIMMABLE-BOUNDARY-START(393306)
            static $_StackAllocatedObjects;
            static get StackAllocatedObjects()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.ActivatorUtilities;
                return $cls.$_StackAllocatedObjects ??= $asm.$nstr(`$mxdi.MED.ActivatorUtilities.StackAllocatedObjects`, ($self) => class StackAllocatedObjects extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295194)
                    //--TRIMMABLE-BOUNDARY-END(12885295194)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360602)
                    //--TRIMMABLE-BOUNDARY-END(4295360602)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327898)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590327898);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590327898)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327898)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590327898)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(int, 8)
                        copy.$fields = [...this.$fields];
                        $.$$.S.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(object?, 8)
                        for (let $i = 7; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, null);
                        }
                        $.$$.S.Array.AddMetadata(this.$fields, $.$typeOf($.$$.S.Object), null, null)
                    }
                    static $h = 393306;
                    static $z = 32;
                    static $f = 0b1000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static get $iat() { return $.$$.S.Int32; }
                    static $iaz = 8;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295194),
    {
      "t": 655361,
      "n": "MaxStackAllocArgCount",
      "d": 393306,
      "h": 12885295194,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885295194),
//--TRIMMABLE-BOUNDARY-START(4295360602),
    {
      "t": 131073,
      "n": "_arg0",
      "d": 393306,
      "h": 4295360602,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327898),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393306,
      "h": 8590327898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327898)
  ],
  "d": 65626,
  "h": 393306,
  "a": [
    {
      "t": 130285569,
      "c": 8720220161,
      "a": [
        {
          "v": 8,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities+StackAllocatedObjects`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities${separator}StackAllocatedObjects`; }
                }, $cls, ($v) => $cls.$_StackAllocatedObjects = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393306)
            
            //--TRIMMABLE-BOUNDARY-START(55834640474)
            static /*object? */ GetKeyedService(/*IServiceProvider*/ provider, /*Type*/ type, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.MED.IKeyedServiceProvider, { set $v($v){ keyedServiceProvider = $v; } }))
                {
                    return keyedServiceProvider.MED$IKeyedServiceProvider$GetKeyedService(type, serviceKey);
                }
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(55834640474)
            
            //--TRIMMABLE-BOUNDARY-START(4295032922)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(107374248026)
                    this.s_constructorInfos = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(107374248026)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079280730)
                    this.s_collectibleConstructorInfos = new ($.$$.S.Lazy$$($.$$.SRC.ConditionalWeakTable$$$($.$$.S.Type, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(103079280730)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719542362)
                    this.GetServiceInfo = new ($.$$.S.Func$$$$$$$($.$scm.S.IServiceProvider, $.$$.S.Type, $.$$.S.Type, $.$$.S.Boolean, $.$$.S.Object, $.$$.S.Object))().$ctor($.$mxdi.MED.ActivatorUtilities, $.$mxdi.MED.ActivatorUtilities.GetService).Method;
                    //--TRIMMABLE-BOUNDARY-END(68719542362)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032922)
            
            static $h = 65626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34359803994),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "CreateInstance",
      "d": 65626,
      "h": 34359803994,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359803994),
//--TRIMMABLE-BOUNDARY-START(60129607770),
    {
      "r": $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetOrAddConstructors",
      "d": 65626,
      "h": 60129607770,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60129607770),
//--TRIMMABLE-BOUNDARY-START(12884967514),
    {
      "r": $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx).$h,
      "p": [
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "CreateConstructorInfoExs",
      "d": 65626,
      "h": 12884967514,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12884967514),
//--TRIMMABLE-BOUNDARY-START(17179934810),
    {
      "r": 1376346,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "CreateFactory",
      "d": 65626,
      "h": 17179934810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934810),
//--TRIMMABLE-BOUNDARY-START(21474902106),
    {
      "r": (T) => $.$mxdi.MED.ObjectFactory$$(T).$h,
      "p": [
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateFactory",
      "o": "@$1",
      "d": 65626,
      "h": 21474902106,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474902106),
//--TRIMMABLE-BOUNDARY-START(25769869402),
    {
      "r": 65537,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "provider",
          "p": 40566821,
          "f": 2
        },
        {
          "n": "argumentArray",
          "p": 40566821,
          "f": 2
        },
        {
          "n": "factoryExpressionBody",
          "p": 8781861,
          "f": 2
        }
      ],
      "n": "CreateFactoryInternal",
      "d": 65626,
      "h": 25769869402,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25769869402),
//--TRIMMABLE-BOUNDARY-START(38654771290),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateInstance",
      "o": "@$1",
      "d": 65626,
      "h": 38654771290,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38654771290),
//--TRIMMABLE-BOUNDARY-START(77309476954),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetServiceOrCreateInstance",
      "o": "@$1",
      "d": 65626,
      "h": 77309476954,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77309476954),
//--TRIMMABLE-BOUNDARY-START(73014509658),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "type",
          "p": 188547073
        }
      ],
      "n": "GetServiceOrCreateInstance",
      "d": 65626,
      "h": 73014509658,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014509658),
//--TRIMMABLE-BOUNDARY-START(64424575066),
    {
      "r": 131073,
      "p": [
        {
          "n": "sp",
          "p": 327718
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "requiredBy",
          "p": 188547073
        },
        {
          "n": "hasDefaultValue",
          "p": 262145
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "GetService",
      "d": 65626,
      "h": 64424575066,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424575066),
//--TRIMMABLE-BOUNDARY-START(115964182618),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "requiredBy",
          "p": 188547073
        }
      ],
      "n": "ThrowHelperUnableToResolveService",
      "d": 65626,
      "h": 115964182618,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964182618),
//--TRIMMABLE-BOUNDARY-START(8590000218),
    {
      "r": 3997733,
      "p": [
        {
          "n": "constructor",
          "p": 109182977
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h
        },
        {
          "n": "serviceProvider",
          "p": 8781861
        },
        {
          "n": "factoryArgumentArray",
          "p": 8781861
        }
      ],
      "n": "BuildFactoryExpression",
      "d": 65626,
      "h": 8590000218,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590000218),
//--TRIMMABLE-BOUNDARY-START(30064836698),
    {
      "r": 1376346,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        }
      ],
      "n": "CreateFactoryReflection",
      "d": 65626,
      "h": 30064836698,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064836698),
//--TRIMMABLE-BOUNDARY-START(42949738586),
    {
      "r": 65537,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "constructors",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx).$h
        },
        {
          "n": "matchingConstructor",
          "p": 109182977,
          "f": 2
        },
        {
          "n": "matchingParameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h,
          "f": 2
        }
      ],
      "n": "FindApplicableConstructor",
      "d": 65626,
      "h": 42949738586,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42949738586),
//--TRIMMABLE-BOUNDARY-START(47244705882),
    {
      "r": 196698,
      "p": [
        {
          "n": "constructorInfo",
          "p": 109182977
        },
        {
          "n": "constructorExs",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx).$h
        }
      ],
      "n": "FindConstructorEx",
      "d": 65626,
      "h": 47244705882,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244705882),
//--TRIMMABLE-BOUNDARY-START(133144051802),
    {
      "r": 262145,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "matchingConstructor",
          "p": 109182977,
          "f": 2
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryFindMatchingConstructor",
      "d": 65626,
      "h": 133144051802,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133144051802),
//--TRIMMABLE-BOUNDARY-START(137439019098),
    {
      "r": 262145,
      "p": [
        {
          "n": "instanceType",
          "p": 188547073
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "constructors",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx).$h
        },
        {
          "n": "matchingConstructor",
          "p": 109182977,
          "f": 2
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryFindPreferredConstructor",
      "d": 65626,
      "h": 137439019098,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137439019098),
//--TRIMMABLE-BOUNDARY-START(128849084506),
    {
      "r": 262145,
      "p": [
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.SR.ParameterInfo).$h
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.S.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryCreateParameterMap",
      "d": 65626,
      "h": 128849084506,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(128849084506),
//--TRIMMABLE-BOUNDARY-START(124554117210),
    {
      "r": 65537,
      "n": "ThrowMultipleCtorsMarkedWithAttributeException",
      "d": 65626,
      "h": 124554117210,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124554117210),
//--TRIMMABLE-BOUNDARY-START(120259149914),
    {
      "r": 65537,
      "n": "ThrowMarkedCtorDoesNotTakeAllProvidedArguments",
      "d": 65626,
      "h": 120259149914,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259149914),
//--TRIMMABLE-BOUNDARY-START(94489346138),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 109248513
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 188547073
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "ReflectionFactoryServiceOnlyFixed",
      "d": 65626,
      "h": 94489346138,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94489346138),
//--TRIMMABLE-BOUNDARY-START(98784313434),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 109248513
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 188547073
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "ReflectionFactoryServiceOnlySpan",
      "d": 65626,
      "h": 98784313434,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98784313434),
//--TRIMMABLE-BOUNDARY-START(81604444250),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 109248513
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 188547073
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ReflectionFactoryCanonicalFixed",
      "d": 65626,
      "h": 81604444250,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604444250),
//--TRIMMABLE-BOUNDARY-START(85899411546),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 109248513
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.MED.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 188547073
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ReflectionFactoryCanonicalSpan",
      "d": 65626,
      "h": 85899411546,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899411546),
//--TRIMMABLE-BOUNDARY-START(90194378842),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 109248513
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ReflectionFactoryDirect",
      "d": 65626,
      "h": 90194378842,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194378842),
//--TRIMMABLE-BOUNDARY-START(111669215322),
    {
      "r": 65537,
      "n": "ThrowHelperNullReferenceException",
      "d": 65626,
      "h": 111669215322,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669215322),
//--TRIMMABLE-BOUNDARY-START(55834640474),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 65626,
      "h": 55834640474,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55834640474)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(107374248026),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.Type, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx)).$h,
      "n": "s_constructorInfos",
      "d": 65626,
      "h": 107374248026,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(107374248026),
//--TRIMMABLE-BOUNDARY-START(103079280730),
    {
      "t": $.$$.S.Lazy$$($.$$.SRC.ConditionalWeakTable$$$($.$$.S.Type, $.$typeArray($.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx))).$h,
      "n": "s_collectibleConstructorInfos",
      "d": 65626,
      "h": 103079280730,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103079280730),
//--TRIMMABLE-BOUNDARY-START(51539673178),
    {
      "t": 655361,
      "n": "FixedArgumentThreshold",
      "d": 65626,
      "h": 51539673178,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539673178),
//--TRIMMABLE-BOUNDARY-START(68719542362),
    {
      "t": 117571585,
      "n": "GetServiceInfo",
      "d": 65626,
      "h": 68719542362,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68719542362)
  ],
  "h": 65626
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mxdi.MED.ActivatorUtilities.FactoryParameterContext, $.$mxdi.MED.ActivatorUtilities.ConstructorInfoEx, $.$mxdi.MED.ActivatorUtilities.ConstructorMatcher, $.$mxdi.MED.ActivatorUtilities.ActivatorUtilitiesUpdateHandler, $.$mxdi.MED.ActivatorUtilities.StackAllocatedObjects ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilities`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65626)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245274)
        $asm.$cls(`$mxdi.MED.KeyedService`, ($self) => class KeyedService
        {
            //--TRIMMABLE-BOUNDARY-START(12886147162)
            /*object*/ static AnyKey = null;
            //--TRIMMABLE-BOUNDARY-END(12886147162)
            
            //--TRIMMABLE-BOUNDARY-START(1310810)
            static $_AnyKeyObj;
            static get AnyKeyObj()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mxdi.MED.KeyedService;
                return $cls.$_AnyKeyObj ??= $asm.$ncls(`$mxdi.MED.KeyedService.AnyKeyObj`, ($self) => class AnyKeyObj extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591245402)
                    /*string? */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591245402);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return "*";
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591245402)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278106)
                    //default constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296278106);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278106)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278106)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278106)
                    
                    static $h = 1310810;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245402),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310810,
      "h": 8591245402,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591245402)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278106),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310810,
      "h": 4296278106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278106)
  ],
  "d": 1245274,
  "h": 1310810
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.KeyedService+AnyKeyObj`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}KeyedService${separator}AnyKeyObj`; }
                }, $cls, ($v) => $cls.$_AnyKeyObj = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310810)
            
            //--TRIMMABLE-BOUNDARY-START(8591179866)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12886147162)
                    this.AnyKey = new $.$mxdi.MED.KeyedService.AnyKeyObj().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(12886147162)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591179866)
            
            static $h = 1245274;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886147162),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476081754,
        "f": 50331681
      },
      "n": "AnyKey",
      "d": 1245274,
      "h": 12886147162,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12886147162)
  ],
  "h": 1245274
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mxdi.MED.KeyedService.AnyKeyObj ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.KeyedService`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}KeyedService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245274)
        
        

        //--TRIMMABLE-BOUNDARY-START(786522)
        $asm.$cls(`$mxdi.MED.IServiceCollection`, ($self) => class IServiceCollection
        {
            static $h = 786522;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 786522
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IList$$($.$mxdi.MED.ServiceDescriptor), $.$$.SCG.ICollection$$($.$mxdi.MED.ServiceDescriptor), $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.IServiceCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}IServiceCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786522)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769562)
        $asm.$cls(`$mxdi.MED.ServiceKeyAttribute`, ($self) => class ServiceKeyAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296736858)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296736858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736858)
            
            //--TRIMMABLE-BOUNDARY-START(4296736858)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296736858)
            
            static $h = 1769562;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736858),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769562,
      "h": 4296736858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736858)
  ],
  "h": 1769562,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 2048,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceKeyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769562)
        
        

        //--TRIMMABLE-BOUNDARY-START(458842)
        $asm.$cls(`$mxdi.MED.ActivatorUtilitiesConstructorAttribute`, ($self) => class ActivatorUtilitiesConstructorAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426138)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426138)
            
            //--TRIMMABLE-BOUNDARY-START(4295426138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426138)
            
            static $h = 458842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426138),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458842,
      "h": 4295426138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426138)
  ],
  "h": 458842,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 32767,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ActivatorUtilitiesConstructorAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458842)
        
        

        //--TRIMMABLE-BOUNDARY-START(655450)
        $asm.$cls(`$mxdi.MED.FromKeyedServicesAttribute`, ($self) => class FromKeyedServicesAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180524634)
            $ctor$3(/*object?*/ key)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180524634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.LookupMode = key === null ? 1/*ServiceKeyLookupMode.NullKey*/ : 2/*ServiceKeyLookupMode.ExplicitKey*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524634)
            
            //--TRIMMABLE-BOUNDARY-START(12885557338)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = null;
                    this.LookupMode = 0/*ServiceKeyLookupMode.InheritKey*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557338)
            
            //--TRIMMABLE-BOUNDARY-START(38655361114)
            /*object?*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(38655361114)
            
            //--TRIMMABLE-BOUNDARY-START(42950328410)
            /*ServiceKeyLookupMode*/ LookupMode = 0;
            //--TRIMMABLE-BOUNDARY-END(42950328410)
            
            //--TRIMMABLE-BOUNDARY-START(12885557338)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885557338)
            
            static $h = 655450;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655361114),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459226,
        "f": 50331649
      },
      "n": "Key",
      "d": 655450,
      "h": 38655361114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655361114),
//--TRIMMABLE-BOUNDARY-START(42950328410),
    {
      "p": 1835098,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393818,
        "f": 50331649
      },
      "n": "LookupMode",
      "d": 655450,
      "h": 42950328410,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950328410)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180524634),
    {
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655450,
      "h": 17180524634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524634),
//--TRIMMABLE-BOUNDARY-START(12885557338),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655450,
      "h": 12885557338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557338)
  ],
  "h": 655450,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 2048,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}FromKeyedServicesAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655450)
        
        

        //--TRIMMABLE-BOUNDARY-START(524378)
        $asm.$str(`$mxdi.MED.AsyncServiceScope`, ($self) => class AsyncServiceScope extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295491674)
            /*IServiceScope*/ _serviceScope = null;
            //--TRIMMABLE-BOUNDARY-END(4295491674)
            
            //--TRIMMABLE-BOUNDARY-START(12885426266)
            $ctor$3(/*IServiceScope*/ serviceScope)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(serviceScope, "serviceScope");
                    this._serviceScope = serviceScope;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426266)
            
            //--TRIMMABLE-BOUNDARY-START(34360262746)
            /*IServiceProvider */ get ServiceProvider()
            {
                return this._serviceScope.MED$IServiceScope$ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262746)
            
            //--TRIMMABLE-BOUNDARY-START(17180393562)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceScope.S$IDisposable$Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(17180393562)
            
            //--TRIMMABLE-BOUNDARY-START(21475360858)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ad;
                if ($.$is(this._serviceScope, $.$$.S.IAsyncDisposable, { set $v($v){ ad = $v; } }))
                {
                    return ad.S$IAsyncDisposable$DisposeAsync();
                }
                this._serviceScope.S$IDisposable$Dispose();
                return new $.$$.STT.ValueTask();
            }
            //--TRIMMABLE-BOUNDARY-END(21475360858)
            
            //--TRIMMABLE-BOUNDARY-START(8590983258)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get MED$IServiceScope$ServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983258)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //--TRIMMABLE-BOUNDARY-START(8590458970)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458970)
            
            //--TRIMMABLE-BOUNDARY-START(8590458970)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458970)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._serviceScope = this._serviceScope;
                return copy;
            }
            static $h = 524378;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360262746),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295450,
        "f": 50331649
      },
      "n": "ServiceProvider",
      "d": 524378,
      "h": 34360262746,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360262746)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393562),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 524378,
      "h": 17180393562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393562),
//--TRIMMABLE-BOUNDARY-START(21475360858),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 524378,
      "h": 21475360858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360858)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491674),
    {
      "t": 1048666,
      "n": "_serviceScope",
      "d": 524378,
      "h": 4295491674,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426266),
    {
      "p": [
        {
          "n": "serviceScope",
          "p": 1048666
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524378,
      "h": 12885426266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426266),
//--TRIMMABLE-BOUNDARY-START(8590458970),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524378,
      "h": 8590458970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458970)
  ],
  "h": 524378,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ServiceProvider,nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.MED.IServiceScope, $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.AsyncServiceScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}AsyncServiceScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524378)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376346)
        $asm.$cls(`$mxdi.MED.ObjectFactory`, ($self) => class ObjectFactory extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*object*/ Invoke(/**/ serviceProvider, /*$.$typeArray($.$$.S.Object)*/ $arguments)
            {
                return this.$nativeFunction.call(this.$target, serviceProvider, $arguments);
            }
            static $h = 1376346;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245530),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "Invoke",
      "d": 1376346,
      "h": 17181245530,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181245530),
//--TRIMMABLE-BOUNDARY-START(8591310938),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1376346,
      "h": 8591310938,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591310938),
//--TRIMMABLE-BOUNDARY-START(12886278234),
    {
      "r": 131073,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 1376346,
      "h": 12886278234,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886278234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343642),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1376346,
      "h": 4296343642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343642)
  ],
  "h": 1376346
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ObjectFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ObjectFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376346)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441882)
        $asm.$cls(`$mxdi.MED.ObjectFactory<>`, (/*out*/ T) => $asm.$gt(`$mxdi.MED.ObjectFactory<>`, [/*out*/ T], ($self) => class ObjectFactory$$ extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*T*/ Invoke(/**/ serviceProvider, /*$.$typeArray($.$$.S.Object)*/ $arguments)
            {
                return this.$nativeFunction.call(this.$target, serviceProvider, $arguments);
            }
            static $H = 1441882;
            static $h = 1441882;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181311066),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "H": 17181311066,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 17301633
    },
//--TRIMMABLE-BOUNDARY-END(17181311066),
//--TRIMMABLE-BOUNDARY-START(8591376474),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "H": 8591376474,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591376474),
//--TRIMMABLE-BOUNDARY-START(12886343770),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "H": 12886343770,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 17301633
    },
//--TRIMMABLE-BOUNDARY-END(12886343770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409178),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 4296409178,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409178)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 32
    }
  ],
  "r": 1,
  "H": 1441882,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ObjectFactory<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ObjectFactory$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1441882)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900634)
        $asm.$str(`$mxdi.MED.ServiceLifetime`, ($self) => class ServiceLifetime extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Singleton = 0;
            static Scoped = 1;
            static Transient = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Singleton": 0n,
                    "Scoped": 1n,
                    "Transient": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296867930)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296867930)
            
            //--TRIMMABLE-BOUNDARY-START(4296867930)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296867930)
            
            static $h = 1900634;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886802522),
    {
      "t": 1900634,
      "n": "Singleton",
      "d": 1900634,
      "h": 12886802522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886802522),
//--TRIMMABLE-BOUNDARY-START(8591835226),
    {
      "t": 1900634,
      "n": "Scoped",
      "d": 1900634,
      "h": 8591835226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591835226),
//--TRIMMABLE-BOUNDARY-START(17181769818),
    {
      "t": 1900634,
      "n": "Transient",
      "d": 1900634,
      "h": 17181769818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181769818)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900634,
      "h": 4296867930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867930)
  ],
  "h": 1900634
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceLifetime`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceLifetime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900634)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835098)
        $asm.$str(`$mxdi.MED.ServiceKeyLookupMode`, ($self) => class ServiceKeyLookupMode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static InheritKey = 0;
            static NullKey = 1;
            static ExplicitKey = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "InheritKey": 0n,
                    "NullKey": 1n,
                    "ExplicitKey": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296802394)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802394)
            
            //--TRIMMABLE-BOUNDARY-START(4296802394)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296802394)
            
            static $h = 1835098;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886736986),
    {
      "t": 1835098,
      "n": "InheritKey",
      "d": 1835098,
      "h": 12886736986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736986),
//--TRIMMABLE-BOUNDARY-START(17181704282),
    {
      "t": 1835098,
      "n": "NullKey",
      "d": 1835098,
      "h": 17181704282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704282),
//--TRIMMABLE-BOUNDARY-START(8591769690),
    {
      "t": 1835098,
      "n": "ExplicitKey",
      "d": 1835098,
      "h": 8591769690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802394),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835098,
      "h": 4296802394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802394)
  ],
  "h": 1835098
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceKeyLookupMode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceKeyLookupMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835098)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507418)
        $asm.$cls(`$mxdi.MED.ServiceCollection`, ($self) => class ServiceCollection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474714)
            /*List<ServiceDescriptor>*/ _descriptors = null;
            //--TRIMMABLE-BOUNDARY-END(4296474714)
            
            //--TRIMMABLE-BOUNDARY-START(8591442010)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(8591442010)
            
            //--TRIMMABLE-BOUNDARY-START(34361245786)
            /*int */ get Count()
            {
                return this._descriptors.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(34361245786)
            
            //--TRIMMABLE-BOUNDARY-START(81605886042)
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(81605886042)
            
            //--TRIMMABLE-BOUNDARY-START(115965624410)
            /*ServiceDescriptor*/ get_Item$1(/*int*/ index)
            {
                return this._descriptors.get_Item(index);
            }
            /*void*/ set_Item$1(/*int*/ index, /*ServiceDescriptor*/ value)
            {
                this.CheckReadOnly();
                this._descriptors.set_Item(index, value);
            }
            //--TRIMMABLE-BOUNDARY-END(115965624410)
            
            //--TRIMMABLE-BOUNDARY-START(21476343898)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(21476343898)
            
            //--TRIMMABLE-BOUNDARY-START(25771311194)
            /*bool */ Contains(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.Contains(item);
            }
            //--TRIMMABLE-BOUNDARY-END(25771311194)
            
            //--TRIMMABLE-BOUNDARY-START(30066278490)
            /*void */ CopyTo(/*ServiceDescriptor[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptors.CopyTo$1(array, arrayIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278490)
            
            //--TRIMMABLE-BOUNDARY-START(90195820634)
            /*bool */ Remove(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                return this._descriptors.Remove(item);
            }
            //--TRIMMABLE-BOUNDARY-END(90195820634)
            
            //--TRIMMABLE-BOUNDARY-START(68720984154)
            /*IEnumerator<ServiceDescriptor> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(68720984154)
            
            //--TRIMMABLE-BOUNDARY-START(107375689818)
            /*void */ SCG$ICollection$$$Add(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Add(item);
            }
            //--TRIMMABLE-BOUNDARY-END(107375689818)
            
            //--TRIMMABLE-BOUNDARY-START(111670657114)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(111670657114)
            
            //--TRIMMABLE-BOUNDARY-START(73015951450)
            /*int */ IndexOf(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.IndexOf$2(item);
            }
            //--TRIMMABLE-BOUNDARY-END(73015951450)
            
            //--TRIMMABLE-BOUNDARY-START(77310918746)
            /*void */ Insert(/*int*/ index, /*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Insert(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(77310918746)
            
            //--TRIMMABLE-BOUNDARY-START(94490787930)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.RemoveAt(index);
            }
            //--TRIMMABLE-BOUNDARY-END(94490787930)
            
            //--TRIMMABLE-BOUNDARY-START(85900853338)
            /*void */ MakeReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._isReadOnly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(85900853338)
            
            //--TRIMMABLE-BOUNDARY-START(17181376602)
            /*void */ CheckReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReadOnly)
                {
                    $.$mxdi.MED.ServiceCollection.ThrowReadOnlyException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181376602)
            
            //--TRIMMABLE-BOUNDARY-START(120260591706)
            static /*void */ ThrowReadOnlyException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260591706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mxdi.S.SR.ServiceCollectionReadOnly);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260591706)
            
            //--TRIMMABLE-BOUNDARY-START(38656213082)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText = `Count = ${$.$strNN(this._descriptors.Count)}`;
                if (this._isReadOnly)
                {
                    debugText += `, IsReadOnly = true`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(38656213082)
            
            //--TRIMMABLE-BOUNDARY-START(8650555393)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].get
            SCG$IList$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650555393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650555393)
            
            //--TRIMMABLE-BOUNDARY-START(30125391873)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].set
            SCG$IList$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30125391873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30125391873)
            
            //--TRIMMABLE-BOUNDARY-START(12945522689)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IndexOf(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            SCG$IList$$$IndexOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945522689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12945522689)
            
            //--TRIMMABLE-BOUNDARY-START(17240489985)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Insert(int, Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            SCG$IList$$$Insert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17240489985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Insert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17240489985)
            
            //--TRIMMABLE-BOUNDARY-START(21535457281)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.RemoveAt(int)
            SCG$IList$$$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21535457281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21535457281)
            
            //--TRIMMABLE-BOUNDARY-START(30124802049)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Count.get
            get SCG$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534867457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124802049)
            
            //--TRIMMABLE-BOUNDARY-START(38714736641)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IsReadOnly.get
            get SCG$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009703937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714736641)
            
            //--TRIMMABLE-BOUNDARY-START(8649965569)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Clear()
            SCG$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649965569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649965569)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Contains(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            SCG$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944932865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //--TRIMMABLE-BOUNDARY-START(17239900161)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.CopyTo(Microsoft.Extensions.DependencyInjection.ServiceDescriptor[], int)
            SCG$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239900161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239900161)
            
            //--TRIMMABLE-BOUNDARY-START(47304671233)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Remove(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            SCG$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47304671233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47304671233)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(12886409306)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409306)
            
            //--TRIMMABLE-BOUNDARY-START(12886409306)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12886409306)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474714)
                this._descriptors = new ($.$$.SCG.List$$($.$mxdi.MED.ServiceDescriptor))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296474714)
                
            }
            static $h = 1507418;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361245786),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246147674,
        "f": 50331649
      },
      "n": "Count",
      "d": 1507418,
      "h": 34361245786,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361245786),
//--TRIMMABLE-BOUNDARY-START(81605886042),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836082266,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1507418,
      "h": 81605886042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605886042),
//--TRIMMABLE-BOUNDARY-START(115965624410),
    {
      "p": 1704026,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426016858,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080722522,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1507418,
      "h": 115965624410,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(115965624410)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476343898),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1507418,
      "h": 21476343898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343898),
//--TRIMMABLE-BOUNDARY-START(25771311194),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Contains",
      "d": 1507418,
      "h": 25771311194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771311194),
//--TRIMMABLE-BOUNDARY-START(30066278490),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$mxdi.MED.ServiceDescriptor).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1507418,
      "h": 30066278490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066278490),
//--TRIMMABLE-BOUNDARY-START(90195820634),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Remove",
      "d": 1507418,
      "h": 90195820634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195820634),
//--TRIMMABLE-BOUNDARY-START(68720984154),
    {
      "r": $.$$.SCG.IEnumerator$$($.$mxdi.MED.ServiceDescriptor).$h,
      "n": "GetEnumerator",
      "d": 1507418,
      "h": 68720984154,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720984154),
//--TRIMMABLE-BOUNDARY-START(73015951450),
    {
      "r": 655361,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "IndexOf",
      "d": 1507418,
      "h": 73015951450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015951450),
//--TRIMMABLE-BOUNDARY-START(77310918746),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Insert",
      "d": 1507418,
      "h": 77310918746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310918746),
//--TRIMMABLE-BOUNDARY-START(94490787930),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1507418,
      "h": 94490787930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490787930),
//--TRIMMABLE-BOUNDARY-START(85900853338),
    {
      "r": 65537,
      "n": "MakeReadOnly",
      "d": 1507418,
      "h": 85900853338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900853338),
//--TRIMMABLE-BOUNDARY-START(17181376602),
    {
      "r": 65537,
      "n": "CheckReadOnly",
      "d": 1507418,
      "h": 17181376602,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181376602),
//--TRIMMABLE-BOUNDARY-START(120260591706),
    {
      "r": 65537,
      "n": "ThrowReadOnlyException",
      "d": 1507418,
      "h": 120260591706,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120260591706),
//--TRIMMABLE-BOUNDARY-START(38656213082),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1507418,
      "h": 38656213082,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656213082)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474714),
    {
      "t": $.$$.SCG.List$$($.$mxdi.MED.ServiceDescriptor).$h,
      "n": "_descriptors",
      "d": 1507418,
      "h": 4296474714,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474714),
//--TRIMMABLE-BOUNDARY-START(8591442010),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1507418,
      "h": 8591442010,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442010)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886409306),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507418,
      "h": 12886409306,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409306)
  ],
  "h": 1507418,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": null,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.MED.IServiceCollection, $.$$.SCG.IList$$($.$mxdi.MED.ServiceDescriptor), $.$$.SCG.ICollection$$($.$mxdi.MED.ServiceDescriptor), $.$$.SCG.IEnumerable$$($.$mxdi.MED.ServiceDescriptor), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ /*$.$mxdi.MED.ServiceCollection.ServiceCollectionDebugView*/$.$$.DeletedObject ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.ServiceCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}ServiceCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507418)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.ComponentModel", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"));
})();
//--TRIMMABLE-BOUNDARY-END(90)
