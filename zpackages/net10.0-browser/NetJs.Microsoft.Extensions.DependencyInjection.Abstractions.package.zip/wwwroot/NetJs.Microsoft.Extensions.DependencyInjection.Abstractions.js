
//--TRIMMABLE-BOUNDARY-START(90)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scm, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", 
    {
  "h": 90,
  "f": "Microsoft.Extensions.DependencyInjection.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.DependencyInjection.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 115736577,
      "c": 8705671169,
      "a": [
        {
          "v": 131162,
          "t": 187760641
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(983130)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService", ($self) => class IServiceProviderIsService
        {
            static $h = 983130;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950426),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "IsService",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService",
      "d": 983130,
      "h": 4295950426,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295950426)
  ],
  "h": 983130
}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderIsService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983130)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114202)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory", ($self) => class IServiceScopeFactory
        {
            static $h = 1114202;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081498),
    {
      "r": 1048666,
      "n": "CreateScope",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope",
      "d": 1114202,
      "h": 4296081498,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081498)
  ],
  "h": 1114202
}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceScopeFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114202)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179738)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ISupportRequiredService", ($self) => class ISupportRequiredService
        {
            static $h = 1179738;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147034),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetRequiredService",
      "o": "Microsoft$Extensions$DependencyInjection$ISupportRequiredService$GetRequiredService",
      "d": 1179738,
      "h": 4296147034,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296147034)
  ],
  "h": 1179738
}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ISupportRequiredService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179738)
        
        
        //--TRIMMABLE-BOUNDARY-START(852058)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<>", (TContainerBuilder) => $asm.$gt("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<>", [TContainerBuilder], ($self) => class IServiceProviderFactory$$
        {
            static $h = 852058;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819354),
    {
      "r": TContainerBuilder?.$h??1507328,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "CreateBuilder",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295819354),
//--TRIMMABLE-BOUNDARY-START(8590786650),
    {
      "r": 327718,
      "p": [
        {
          "n": "containerBuilder",
          "p": TContainerBuilder?.$h??1507328
        }
      ],
      "n": "CreateServiceProvider",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590786650)
  ],
  "g": [TContainerBuilder?.$h??1507328
  ],
  "s": [
    {
      "n": "TContainerBuilder",
      "f": 64
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<${TContainerBuilder?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(852058)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048666)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope", ($self) => class IServiceScope
        {
            static $h = 1048666;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885950554),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590983258,
        "f": 50331905
      },
      "n": "ServiceProvider",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider",
      "d": 1048666,
      "h": 12885950554,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885950554)
  ],
  "i": [90308609
  ],
  "h": 1048666
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048666)
        
        
        //--TRIMMABLE-BOUNDARY-START(917594)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService", ($self) => class IServiceProviderIsKeyedService
        {
            static $h = 917594;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295884890),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "IsKeyedService",
      "o": "Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService",
      "d": 917594,
      "h": 4295884890,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295884890)
  ],
  "i": [983130
  ],
  "h": 917594
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917594)
        
        
        //--TRIMMABLE-BOUNDARY-START(720986)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider", ($self) => class IKeyedServiceProvider
        {
            static $h = 720986;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295688282),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "o": "Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService",
      "d": 720986,
      "h": 4295688282,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295688282),
//--TRIMMABLE-BOUNDARY-START(8590655578),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "o": "Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService",
      "d": 720986,
      "h": 8590655578,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590655578)
  ],
  "i": [327718
  ],
  "h": 720986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720986)
        
        
        $asm.$typeProxy("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor");
        //--TRIMMABLE-BOUNDARY-START(786522)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection", ($self) => class IServiceCollection
        {
            static $h = 786522;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "i": [$.$$.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,62652417
  ],
  "h": 786522
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786522)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097242)
        $asm.$cls("$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            //--TRIMMABLE-BOUNDARY-START(4297064538)
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297064538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(4297064538)
            
            //--TRIMMABLE-BOUNDARY-START(8592031834)
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592031834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$$.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        {
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                        }
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$$.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.System.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031834)
            
            static $h = 2097242;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297064538),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "tryToGetDefaultValue",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "CheckHasDefaultValue",
      "d": 2097242,
      "h": 4297064538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297064538),
//--TRIMMABLE-BOUNDARY-START(8592031834),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "defaultValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetDefaultValue",
      "d": 2097242,
      "h": 8592031834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592031834)
  ],
  "h": 2097242
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097242)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245274)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService", ($self) => class KeyedService
        {
            //--TRIMMABLE-BOUNDARY-START(17181114458)
            /*object*/ static AnyKey = null;
            //--TRIMMABLE-BOUNDARY-END(17181114458)
            
            //--TRIMMABLE-BOUNDARY-START(1310810)
            static $_AnyKeyObj;
            static get AnyKeyObj()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService;
                return $cls.$_AnyKeyObj ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj", ($self) => class AnyKeyObj extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591245402)
                    static/*conventional*/ /*string? */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591245402);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return "*";
                        }
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(8591245402)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278106)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296278106)
                    
                    static $h = 1310810;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245402),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1310810,
      "h": 8591245402,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591245402)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278106),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310810,
      "h": 4296278106,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278106)
  ],
  "d": 1245274,
  "h": 1310810
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj`; }
                }, $cls, ($v) => $cls.$_AnyKeyObj = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310810)
            
            //--TRIMMABLE-BOUNDARY-START(12886147162)
            //Static Initializer
            static $sinit()
            {
                {
                    this.AnyKey = new $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886147162)
            
            static $h = 1245274;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181114458),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771049050,
        "f": 50331681
      },
      "n": "AnyKey",
      "d": 1245274,
      "h": 17181114458,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17181114458)
  ],
  "j": [1310810
  ],
  "h": 1245274
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.KeyedService`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245274)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031706)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions", ($self) => class ServiceProviderServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(25771835482)
            static /*T? */ GetService(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771835482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast(provider.System$IServiceProvider$GetService(T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(25771835482)
            
            //--TRIMMABLE-BOUNDARY-START(17181900890)
            static /*object */ GetRequiredService(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181900890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.ISupportRequiredService, { set $v(v){ requiredServiceSupportingProvider = v; } }))
                {
                    return requiredServiceSupportingProvider.Microsoft$Extensions$DependencyInjection$ISupportRequiredService$GetRequiredService(serviceType);
                }
                /*object?*/ let service = provider.System$IServiceProvider$GetService(serviceType);
                if (service === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$6($.$mxdi.System.SR.NoServiceRegistered, serviceType));
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(17181900890)
            
            //--TRIMMABLE-BOUNDARY-START(21476868186)
            static /*T */ GetRequiredService$1(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476868186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService(provider, T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(21476868186)
            
            //--TRIMMABLE-BOUNDARY-START(34361770074)
            static /*IEnumerable<T> */ GetServices$1(T, /*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$$.System.Collections.Generic.IEnumerable$$(T), provider);
            }
            //--TRIMMABLE-BOUNDARY-END(34361770074)
            
            //--TRIMMABLE-BOUNDARY-START(30066802778)
            static /*IEnumerable<object?> */ GetServices(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066802778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService(provider, genericEnumerable), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(30066802778)
            
            //--TRIMMABLE-BOUNDARY-START(12886933594)
            static /*IServiceScope */ CreateScope(/*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory, provider).Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope();
            }
            //--TRIMMABLE-BOUNDARY-END(12886933594)
            
            //--TRIMMABLE-BOUNDARY-START(8591966298)
            static /*AsyncServiceScope */ CreateAsyncScope$1(/*this IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.CreateScope(provider));
            }
            //--TRIMMABLE-BOUNDARY-END(8591966298)
            
            //--TRIMMABLE-BOUNDARY-START(4296999002)
            static /*AsyncServiceScope */ CreateAsyncScope(/*this IServiceScopeFactory*/ serviceScopeFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296999002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope().$ctor$3(serviceScopeFactory.Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope());
            }
            //--TRIMMABLE-BOUNDARY-END(4296999002)
            
            static $h = 2031706;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771835482),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetService",
      "d": 2031706,
      "h": 25771835482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771835482),
//--TRIMMABLE-BOUNDARY-START(17181900890),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetRequiredService",
      "d": 2031706,
      "h": 17181900890,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181900890),
//--TRIMMABLE-BOUNDARY-START(21476868186),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetRequiredService",
      "o": "@$1",
      "d": 2031706,
      "h": 21476868186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21476868186),
//--TRIMMABLE-BOUNDARY-START(34361770074),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetServices",
      "o": "@$1",
      "d": 2031706,
      "h": 34361770074,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361770074),
//--TRIMMABLE-BOUNDARY-START(30066802778),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetServices",
      "d": 2031706,
      "h": 30066802778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066802778),
//--TRIMMABLE-BOUNDARY-START(12886933594),
    {
      "r": 1048666,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateScope",
      "d": 2031706,
      "h": 12886933594,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886933594),
//--TRIMMABLE-BOUNDARY-START(8591966298),
    {
      "r": 524378,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateAsyncScope",
      "o": "@$1",
      "d": 2031706,
      "h": 8591966298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591966298),
//--TRIMMABLE-BOUNDARY-START(4296999002),
    {
      "r": 524378,
      "p": [
        {
          "n": "serviceScopeFactory",
          "p": 1114202
        }
      ],
      "n": "CreateAsyncScope",
      "d": 2031706,
      "h": 4296999002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296999002)
  ],
  "h": 2031706
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031706)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966170)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions", ($self) => class ServiceProviderKeyedServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591900762)
            static /*T? */ GetKeyedService$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return $.$cast(keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(T.$type, serviceKey), T);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(8591900762)
            
            //--TRIMMABLE-BOUNDARY-START(4296933466)
            static /*object? */ GetKeyedService(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296933466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(serviceType, serviceKey);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(4296933466)
            
            //--TRIMMABLE-BOUNDARY-START(21476802650)
            static /*object */ GetRequiredKeyedService(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476802650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ requiredServiceSupportingProvider = v; } }))
                {
                    return requiredServiceSupportingProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService(serviceType, serviceKey);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(21476802650)
            
            //--TRIMMABLE-BOUNDARY-START(25771769946)
            static /*T */ GetRequiredKeyedService$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, T.$type, serviceKey), T);
            }
            //--TRIMMABLE-BOUNDARY-END(25771769946)
            
            //--TRIMMABLE-BOUNDARY-START(17181835354)
            static /*IEnumerable<T> */ GetKeyedServices$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181835354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$$.System.Collections.Generic.IEnumerable$$(T), provider, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(17181835354)
            
            //--TRIMMABLE-BOUNDARY-START(12886868058)
            static /*IEnumerable<object?> */ GetKeyedServices(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, genericEnumerable, serviceKey), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(12886868058)
            
            static $h = 1966170;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591900762),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetKeyedService",
      "o": "@$1",
      "d": 1966170,
      "h": 8591900762,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591900762),
//--TRIMMABLE-BOUNDARY-START(4296933466),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 1966170,
      "h": 4296933466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296933466),
//--TRIMMABLE-BOUNDARY-START(21476802650),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 1966170,
      "h": 21476802650,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476802650),
//--TRIMMABLE-BOUNDARY-START(25771769946),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetRequiredKeyedService",
      "o": "@$1",
      "d": 1966170,
      "h": 25771769946,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771769946),
//--TRIMMABLE-BOUNDARY-START(17181835354),
    {
      "r": (T) => $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetKeyedServices",
      "o": "@$1",
      "d": 1966170,
      "h": 17181835354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17181835354),
//--TRIMMABLE-BOUNDARY-START(12886868058),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedServices",
      "d": 1966170,
      "h": 12886868058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886868058)
  ],
  "h": 1966170
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966170)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162778)
        $asm.$cls("$mxdi.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(317829742682)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(317829742682)
            
            //--TRIMMABLE-BOUNDARY-START(266290135130)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266290135130);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266290135130)
            
            //--TRIMMABLE-BOUNDARY-START(343599546458)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343599546458);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mxdi.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343599546458)
            
            //--TRIMMABLE-BOUNDARY-START(261995167834)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995167834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mxdi.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(261995167834)
            
            //--TRIMMABLE-BOUNDARY-START(257700200538)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700200538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mxdi.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(257700200538)
            
            //--TRIMMABLE-BOUNDARY-START(55836737626)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836737626)
            
            //--TRIMMABLE-BOUNDARY-START(51541770330)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541770330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51541770330)
            
            //--TRIMMABLE-BOUNDARY-START(47246803034)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246803034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246803034)
            
            //--TRIMMABLE-BOUNDARY-START(60131704922)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdi.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60131704922)
            
            //--TRIMMABLE-BOUNDARY-START(38656868442)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656868442)
            
            //--TRIMMABLE-BOUNDARY-START(34361901146)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361901146)
            
            //--TRIMMABLE-BOUNDARY-START(30066933850)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30066933850)
            
            //--TRIMMABLE-BOUNDARY-START(42951835738)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdi.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951835738)
            
            //--TRIMMABLE-BOUNDARY-START(313534775386)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(313534775386)
            
            //--TRIMMABLE-BOUNDARY-START(304944840794)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(304944840794)
            
            //--TRIMMABLE-BOUNDARY-START(309239808090)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635429466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mxdi.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.DependencyInjection.Abstractions", $.$mxdi.System.SR.$type.Assembly);
                    $.$mxdi.System.SR.s_resourceManager = temp;
                }
                return $.$mxdi.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(309239808090)
            
            //--TRIMMABLE-BOUNDARY-START(25771966554)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326018138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714644570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966554)
            
            //--TRIMMABLE-BOUNDARY-START(8592097370)
            static /*string */ get AmbiguousConstructorMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966279770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592097370)
            
            //--TRIMMABLE-BOUNDARY-START(64426672218)
            static /*string */ FormatAmbiguousConstructorMatch(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64426672218)
            
            //--TRIMMABLE-BOUNDARY-START(17182031962)
            static /*string */ get CannotResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182031962)
            
            //--TRIMMABLE-BOUNDARY-START(68721639514)
            static /*string */ FormatCannotResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721639514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68721639514)
            
            //--TRIMMABLE-BOUNDARY-START(292059938906)
            static /*string */ get NoConstructorMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865625690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(292059938906)
            
            //--TRIMMABLE-BOUNDARY-START(94491443290)
            static /*string */ FormatNoConstructorMatch(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491443290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94491443290)
            
            //--TRIMMABLE-BOUNDARY-START(300649873498)
            static /*string */ get NoServiceRegistered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045494874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No service for type '{0}' has been registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(300649873498)
            
            //--TRIMMABLE-BOUNDARY-START(98786410586)
            static /*string */ FormatNoServiceRegistered(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786410586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("No service for type '{0}' has been registered.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(98786410586)
            
            //--TRIMMABLE-BOUNDARY-START(322124709978)
            static /*string */ get ServiceCollectionReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225364058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The service collection cannot be modified because it is read-only.";
            }
            //--TRIMMABLE-BOUNDARY-END(322124709978)
            
            //--TRIMMABLE-BOUNDARY-START(335009611866)
            static /*string */ get TryAddIndistinguishableTypeToEnumerable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815298650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(335009611866)
            
            //--TRIMMABLE-BOUNDARY-START(103081377882)
            static /*string */ FormatTryAddIndistinguishableTypeToEnumerable(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081377882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(103081377882)
            
            //--TRIMMABLE-BOUNDARY-START(287764971610)
            static /*string */ get MultipleCtorsMarkedWithAttribute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275691098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors were marked with {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(287764971610)
            
            //--TRIMMABLE-BOUNDARY-START(90196475994)
            static /*string */ FormatMultipleCtorsMarkedWithAttribute(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Multiple constructors were marked with {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90196475994)
            
            //--TRIMMABLE-BOUNDARY-START(274880069722)
            static /*string */ get MarkedCtorMissingArgumentTypes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505887322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constructor marked with {0} does not accept all given argument types.";
            }
            //--TRIMMABLE-BOUNDARY-END(274880069722)
            
            //--TRIMMABLE-BOUNDARY-START(77311574106)
            static /*string */ FormatMarkedCtorMissingArgumentTypes(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311574106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Constructor marked with {0} does not accept all given argument types.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77311574106)
            
            //--TRIMMABLE-BOUNDARY-START(12887064666)
            static /*string */ get CannotCreateAbstractClasses()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556214362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Instances of abstract classes cannot be created.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887064666)
            
            //--TRIMMABLE-BOUNDARY-START(283470004314)
            static /*string */ get MultipleCtorsFoundWithBestLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685756506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors for type '{0}' were found with length {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(283470004314)
            
            //--TRIMMABLE-BOUNDARY-START(85901508698)
            static /*string */ FormatMultipleCtorsFoundWithBestLength(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901508698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Multiple constructors for type '{0}' were found with length {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(85901508698)
            
            //--TRIMMABLE-BOUNDARY-START(339304579162)
            static /*string */ get UnableToResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405233242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(339304579162)
            
            //--TRIMMABLE-BOUNDARY-START(107376345178)
            static /*string */ FormatUnableToResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(107376345178)
            
            //--TRIMMABLE-BOUNDARY-START(21476999258)
            static /*string */ get CtorNotLocated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736083546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476999258)
            
            //--TRIMMABLE-BOUNDARY-START(73016606810)
            static /*string */ FormatCtorNotLocated(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73016606810)
            
            //--TRIMMABLE-BOUNDARY-START(279175037018)
            static /*string */ get MultipleCtorsFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095821914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(279175037018)
            
            //--TRIMMABLE-BOUNDARY-START(81606541402)
            static /*string */ FormatMultipleCtorsFound(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81606541402)
            
            //--TRIMMABLE-BOUNDARY-START(270585102426)
            static /*string */ get KeyedServicesNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915952730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This service provider doesn't support keyed services.";
            }
            //--TRIMMABLE-BOUNDARY-END(270585102426)
            
            //--TRIMMABLE-BOUNDARY-START(296354906202)
            static /*string */ get NonKeyedDescriptorMisuse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455560282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This service descriptor is not keyed.";
            }
            //--TRIMMABLE-BOUNDARY-END(296354906202)
            
            //--TRIMMABLE-BOUNDARY-START(4297130074)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(317829742682)
                    this.s_usingResourceKeys = $.$mxdi.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(317829742682)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297130074)
            
            static $h = 2162778;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 2162778
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162778)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638490)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions", ($self) => class ServiceCollectionServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(193275166810)
            static /*IServiceCollection */ AddTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275166810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193275166810)
            
            //--TRIMMABLE-BOUNDARY-START(188980199514)
            static /*IServiceCollection */ AddTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980199514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(188980199514)
            
            //--TRIMMABLE-BOUNDARY-START(206160068698)
            static /*IServiceCollection */ AddTransient$4(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160068698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(206160068698)
            
            //--TRIMMABLE-BOUNDARY-START(197570134106)
            static /*IServiceCollection */ AddTransient$2(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570134106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(197570134106)
            
            //--TRIMMABLE-BOUNDARY-START(214750003290)
            static /*IServiceCollection */ AddTransient$6(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750003290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$2(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(214750003290)
            
            //--TRIMMABLE-BOUNDARY-START(210455035994)
            static /*IServiceCollection */ AddTransient$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455035994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(210455035994)
            
            //--TRIMMABLE-BOUNDARY-START(201865101402)
            static /*IServiceCollection */ AddTransient$3(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865101402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(201865101402)
            
            //--TRIMMABLE-BOUNDARY-START(124555690074)
            static /*IServiceCollection */ AddScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555690074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124555690074)
            
            //--TRIMMABLE-BOUNDARY-START(120260722778)
            static /*IServiceCollection */ AddScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260722778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120260722778)
            
            //--TRIMMABLE-BOUNDARY-START(137440591962)
            static /*IServiceCollection */ AddScoped$4(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440591962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$1(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(137440591962)
            
            //--TRIMMABLE-BOUNDARY-START(128850657370)
            static /*IServiceCollection */ AddScoped$2(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850657370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$1(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(128850657370)
            
            //--TRIMMABLE-BOUNDARY-START(146030526554)
            static /*IServiceCollection */ AddScoped$6(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030526554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$2(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(146030526554)
            
            //--TRIMMABLE-BOUNDARY-START(141735559258)
            static /*IServiceCollection */ AddScoped$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735559258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(141735559258)
            
            //--TRIMMABLE-BOUNDARY-START(133145624666)
            static /*IServiceCollection */ AddScoped$3(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145624666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(133145624666)
            
            //--TRIMMABLE-BOUNDARY-START(158915428442)
            static /*IServiceCollection */ AddSingleton$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915428442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158915428442)
            
            //--TRIMMABLE-BOUNDARY-START(150325493850)
            static /*IServiceCollection */ AddSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325493850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150325493850)
            
            //--TRIMMABLE-BOUNDARY-START(171800330330)
            static /*IServiceCollection */ AddSingleton$5(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800330330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$2(services, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(171800330330)
            
            //--TRIMMABLE-BOUNDARY-START(163210395738)
            static /*IServiceCollection */ AddSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210395738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$2(services, serviceType, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(163210395738)
            
            //--TRIMMABLE-BOUNDARY-START(184685232218)
            static /*IServiceCollection */ AddSingleton$8(TService, /*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685232218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$3(services, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(184685232218)
            
            //--TRIMMABLE-BOUNDARY-START(176095297626)
            static /*IServiceCollection */ AddSingleton$6(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095297626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(176095297626)
            
            //--TRIMMABLE-BOUNDARY-START(167505363034)
            static /*IServiceCollection */ AddSingleton$4(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505363034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton(services, TService.$type, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(167505363034)
            
            //--TRIMMABLE-BOUNDARY-START(154620461146)
            static /*IServiceCollection */ AddSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620461146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$6(serviceType, implementationInstance);
                services.System$Collections$Generic$ICollection$$$Add(serviceDescriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(154620461146)
            
            //--TRIMMABLE-BOUNDARY-START(180390264922)
            static /*IServiceCollection */ AddSingleton$7(TService, /*this IServiceCollection*/ services, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390264922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$1(services, TService.$type, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(180390264922)
            
            //--TRIMMABLE-BOUNDARY-START(8591573082)
            static /*IServiceCollection */ Add$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$7(serviceType, implementationType, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573082)
            
            //--TRIMMABLE-BOUNDARY-START(4296605786)
            static /*IServiceCollection */ Add(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$1(serviceType, implementationFactory, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605786)
            
            //--TRIMMABLE-BOUNDARY-START(94490919002)
            static /*IServiceCollection */ AddKeyedTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490919002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94490919002)
            
            //--TRIMMABLE-BOUNDARY-START(90195951706)
            static /*IServiceCollection */ AddKeyedTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195951706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90195951706)
            
            //--TRIMMABLE-BOUNDARY-START(107375820890)
            static /*IServiceCollection */ AddKeyedTransient$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375820890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(107375820890)
            
            //--TRIMMABLE-BOUNDARY-START(98785886298)
            static /*IServiceCollection */ AddKeyedTransient$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785886298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(98785886298)
            
            //--TRIMMABLE-BOUNDARY-START(115965755482)
            static /*IServiceCollection */ AddKeyedTransient$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965755482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$2(services, TService.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(115965755482)
            
            //--TRIMMABLE-BOUNDARY-START(111670788186)
            static /*IServiceCollection */ AddKeyedTransient$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670788186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(111670788186)
            
            //--TRIMMABLE-BOUNDARY-START(103080853594)
            static /*IServiceCollection */ AddKeyedTransient$3(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080853594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(103080853594)
            
            //--TRIMMABLE-BOUNDARY-START(25771442266)
            static /*IServiceCollection */ AddKeyedScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25771442266)
            
            //--TRIMMABLE-BOUNDARY-START(21476474970)
            static /*IServiceCollection */ AddKeyedScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476474970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21476474970)
            
            //--TRIMMABLE-BOUNDARY-START(38656344154)
            static /*IServiceCollection */ AddKeyedScoped$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656344154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(38656344154)
            
            //--TRIMMABLE-BOUNDARY-START(30066409562)
            static /*IServiceCollection */ AddKeyedScoped$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066409562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(30066409562)
            
            //--TRIMMABLE-BOUNDARY-START(47246278746)
            static /*IServiceCollection */ AddKeyedScoped$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246278746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$2(services, TService.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(47246278746)
            
            //--TRIMMABLE-BOUNDARY-START(42951311450)
            static /*IServiceCollection */ AddKeyedScoped$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951311450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(42951311450)
            
            //--TRIMMABLE-BOUNDARY-START(34361376858)
            static /*IServiceCollection */ AddKeyedScoped$3(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361376858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(34361376858)
            
            //--TRIMMABLE-BOUNDARY-START(60131180634)
            static /*IServiceCollection */ AddKeyedSingleton$2(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131180634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60131180634)
            
            //--TRIMMABLE-BOUNDARY-START(51541246042)
            static /*IServiceCollection */ AddKeyedSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541246042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51541246042)
            
            //--TRIMMABLE-BOUNDARY-START(73016082522)
            static /*IServiceCollection */ AddKeyedSingleton$5(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016082522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(73016082522)
            
            //--TRIMMABLE-BOUNDARY-START(64426147930)
            static /*IServiceCollection */ AddKeyedSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426147930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, serviceType, serviceKey, serviceType);
            }
            //--TRIMMABLE-BOUNDARY-END(64426147930)
            
            //--TRIMMABLE-BOUNDARY-START(85900984410)
            static /*IServiceCollection */ AddKeyedSingleton$8(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900984410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$2(services, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(85900984410)
            
            //--TRIMMABLE-BOUNDARY-START(77311049818)
            static /*IServiceCollection */ AddKeyedSingleton$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311049818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(77311049818)
            
            //--TRIMMABLE-BOUNDARY-START(68721115226)
            static /*IServiceCollection */ AddKeyedSingleton$4(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721115226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, implementationFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(68721115226)
            
            //--TRIMMABLE-BOUNDARY-START(55836213338)
            static /*IServiceCollection */ AddKeyedSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836213338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$3(serviceType, serviceKey, implementationInstance);
                services.System$Collections$Generic$ICollection$$$Add(serviceDescriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(55836213338)
            
            //--TRIMMABLE-BOUNDARY-START(81606017114)
            static /*IServiceCollection */ AddKeyedSingleton$7(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606017114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$1(services, TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(81606017114)
            
            //--TRIMMABLE-BOUNDARY-START(17181507674)
            static /*IServiceCollection */ AddKeyed$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationType, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507674)
            
            //--TRIMMABLE-BOUNDARY-START(12886540378)
            static /*IServiceCollection */ AddKeyed(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$2(serviceType, serviceKey, implementationFactory, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540378)
            
            static $h = 1638490;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(193275166810),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddTransient",
      "o": "@$1",
      "d": 1638490,
      "h": 193275166810,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193275166810),
//--TRIMMABLE-BOUNDARY-START(188980199514),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "AddTransient",
      "d": 1638490,
      "h": 188980199514,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188980199514),
//--TRIMMABLE-BOUNDARY-START(206160068698),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddTransient",
      "o": "@$4",
      "d": 1638490,
      "h": 206160068698,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206160068698),
//--TRIMMABLE-BOUNDARY-START(197570134106),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "AddTransient",
      "o": "@$2",
      "d": 1638490,
      "h": 197570134106,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197570134106),
//--TRIMMABLE-BOUNDARY-START(214750003290),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddTransient",
      "o": "@$6",
      "d": 1638490,
      "h": 214750003290,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214750003290),
//--TRIMMABLE-BOUNDARY-START(210455035994),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddTransient",
      "o": "@$5",
      "d": 1638490,
      "h": 210455035994,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210455035994),
//--TRIMMABLE-BOUNDARY-START(201865101402),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddTransient",
      "o": "@$3",
      "d": 1638490,
      "h": 201865101402,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201865101402),
//--TRIMMABLE-BOUNDARY-START(124555690074),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddScoped",
      "o": "@$1",
      "d": 1638490,
      "h": 124555690074,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555690074),
//--TRIMMABLE-BOUNDARY-START(120260722778),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "AddScoped",
      "d": 1638490,
      "h": 120260722778,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260722778),
//--TRIMMABLE-BOUNDARY-START(137440591962),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddScoped",
      "o": "@$4",
      "d": 1638490,
      "h": 137440591962,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(137440591962),
//--TRIMMABLE-BOUNDARY-START(128850657370),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "AddScoped",
      "o": "@$2",
      "d": 1638490,
      "h": 128850657370,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850657370),
//--TRIMMABLE-BOUNDARY-START(146030526554),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddScoped",
      "o": "@$6",
      "d": 1638490,
      "h": 146030526554,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146030526554),
//--TRIMMABLE-BOUNDARY-START(141735559258),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddScoped",
      "o": "@$5",
      "d": 1638490,
      "h": 141735559258,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(141735559258),
//--TRIMMABLE-BOUNDARY-START(133145624666),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddScoped",
      "o": "@$3",
      "d": 1638490,
      "h": 133145624666,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133145624666),
//--TRIMMABLE-BOUNDARY-START(158915428442),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddSingleton",
      "o": "@$2",
      "d": 1638490,
      "h": 158915428442,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158915428442),
//--TRIMMABLE-BOUNDARY-START(150325493850),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "AddSingleton",
      "d": 1638490,
      "h": 150325493850,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150325493850),
//--TRIMMABLE-BOUNDARY-START(171800330330),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddSingleton",
      "o": "@$5",
      "d": 1638490,
      "h": 171800330330,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(171800330330),
//--TRIMMABLE-BOUNDARY-START(163210395738),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "AddSingleton",
      "o": "@$3",
      "d": 1638490,
      "h": 163210395738,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163210395738),
//--TRIMMABLE-BOUNDARY-START(184685232218),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$8",
      "d": 1638490,
      "h": 184685232218,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184685232218),
//--TRIMMABLE-BOUNDARY-START(176095297626),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$6",
      "d": 1638490,
      "h": 176095297626,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176095297626),
//--TRIMMABLE-BOUNDARY-START(167505363034),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddSingleton",
      "o": "@$4",
      "d": 1638490,
      "h": 167505363034,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(167505363034),
//--TRIMMABLE-BOUNDARY-START(154620461146),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "AddSingleton",
      "o": "@$1",
      "d": 1638490,
      "h": 154620461146,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154620461146),
//--TRIMMABLE-BOUNDARY-START(180390264922),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddSingleton",
      "o": "@$7",
      "d": 1638490,
      "h": 180390264922,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180390264922),
//--TRIMMABLE-BOUNDARY-START(8591573082),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 1638490,
      "h": 8591573082,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591573082),
//--TRIMMABLE-BOUNDARY-START(4296605786),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Add",
      "d": 1638490,
      "h": 4296605786,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296605786),
//--TRIMMABLE-BOUNDARY-START(94490919002),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddKeyedTransient",
      "o": "@$1",
      "d": 1638490,
      "h": 94490919002,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490919002),
//--TRIMMABLE-BOUNDARY-START(90195951706),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "AddKeyedTransient",
      "d": 1638490,
      "h": 90195951706,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90195951706),
//--TRIMMABLE-BOUNDARY-START(107375820890),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedTransient",
      "o": "@$4",
      "d": 1638490,
      "h": 107375820890,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107375820890),
//--TRIMMABLE-BOUNDARY-START(98785886298),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedTransient",
      "o": "@$2",
      "d": 1638490,
      "h": 98785886298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785886298),
//--TRIMMABLE-BOUNDARY-START(115965755482),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedTransient",
      "o": "@$6",
      "d": 1638490,
      "h": 115965755482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115965755482),
//--TRIMMABLE-BOUNDARY-START(111670788186),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedTransient",
      "o": "@$5",
      "d": 1638490,
      "h": 111670788186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111670788186),
//--TRIMMABLE-BOUNDARY-START(103080853594),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedTransient",
      "o": "@$3",
      "d": 1638490,
      "h": 103080853594,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103080853594),
//--TRIMMABLE-BOUNDARY-START(25771442266),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddKeyedScoped",
      "o": "@$1",
      "d": 1638490,
      "h": 25771442266,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771442266),
//--TRIMMABLE-BOUNDARY-START(21476474970),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "AddKeyedScoped",
      "d": 1638490,
      "h": 21476474970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476474970),
//--TRIMMABLE-BOUNDARY-START(38656344154),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedScoped",
      "o": "@$4",
      "d": 1638490,
      "h": 38656344154,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38656344154),
//--TRIMMABLE-BOUNDARY-START(30066409562),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedScoped",
      "o": "@$2",
      "d": 1638490,
      "h": 30066409562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066409562),
//--TRIMMABLE-BOUNDARY-START(47246278746),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedScoped",
      "o": "@$6",
      "d": 1638490,
      "h": 47246278746,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47246278746),
//--TRIMMABLE-BOUNDARY-START(42951311450),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedScoped",
      "o": "@$5",
      "d": 1638490,
      "h": 42951311450,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42951311450),
//--TRIMMABLE-BOUNDARY-START(34361376858),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedScoped",
      "o": "@$3",
      "d": 1638490,
      "h": 34361376858,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361376858),
//--TRIMMABLE-BOUNDARY-START(60131180634),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$2",
      "d": 1638490,
      "h": 60131180634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131180634),
//--TRIMMABLE-BOUNDARY-START(51541246042),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "AddKeyedSingleton",
      "d": 1638490,
      "h": 51541246042,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541246042),
//--TRIMMABLE-BOUNDARY-START(73016082522),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$5",
      "d": 1638490,
      "h": 73016082522,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73016082522),
//--TRIMMABLE-BOUNDARY-START(64426147930),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$3",
      "d": 1638490,
      "h": 64426147930,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426147930),
//--TRIMMABLE-BOUNDARY-START(85900984410),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$8",
      "d": 1638490,
      "h": 85900984410,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85900984410),
//--TRIMMABLE-BOUNDARY-START(77311049818),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$6",
      "d": 1638490,
      "h": 77311049818,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77311049818),
//--TRIMMABLE-BOUNDARY-START(68721115226),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$4",
      "d": 1638490,
      "h": 68721115226,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68721115226),
//--TRIMMABLE-BOUNDARY-START(55836213338),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "AddKeyedSingleton",
      "o": "@$1",
      "d": 1638490,
      "h": 55836213338,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836213338),
//--TRIMMABLE-BOUNDARY-START(81606017114),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "AddKeyedSingleton",
      "o": "@$7",
      "d": 1638490,
      "h": 81606017114,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81606017114),
//--TRIMMABLE-BOUNDARY-START(17181507674),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "AddKeyed",
      "o": "@$1",
      "d": 1638490,
      "h": 17181507674,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181507674),
//--TRIMMABLE-BOUNDARY-START(12886540378),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "AddKeyed",
      "d": 1638490,
      "h": 12886540378,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886540378)
  ],
  "h": 1638490
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638490)
        
        
        //--TRIMMABLE-BOUNDARY-START(589914)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions", ($self) => class ServiceCollectionDescriptorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(115964706906)
            static /*void */ TryAddKeyedTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$1(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706906)
            
            //--TRIMMABLE-BOUNDARY-START(111669739610)
            static /*void */ TryAddKeyedTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$1(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(111669739610)
            
            //--TRIMMABLE-BOUNDARY-START(107374772314)
            static /*void */ TryAddKeyedTransient(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(107374772314)
            
            //--TRIMMABLE-BOUNDARY-START(128849608794)
            static /*void */ TryAddKeyedTransient$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(128849608794)
            
            //--TRIMMABLE-BOUNDARY-START(120259674202)
            static /*void */ TryAddKeyedTransient$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674202)
            
            //--TRIMMABLE-BOUNDARY-START(124554641498)
            static /*void */ TryAddKeyedTransient$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$4(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(124554641498)
            
            //--TRIMMABLE-BOUNDARY-START(60130132058)
            static /*void */ TryAddKeyedScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$1(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(60130132058)
            
            //--TRIMMABLE-BOUNDARY-START(55835164762)
            static /*void */ TryAddKeyedScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$1(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(55835164762)
            
            //--TRIMMABLE-BOUNDARY-START(51540197466)
            static /*void */ TryAddKeyedScoped(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197466)
            
            //--TRIMMABLE-BOUNDARY-START(73015033946)
            static /*void */ TryAddKeyedScoped$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033946)
            
            //--TRIMMABLE-BOUNDARY-START(64425099354)
            static /*void */ TryAddKeyedScoped$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(64425099354)
            
            //--TRIMMABLE-BOUNDARY-START(68720066650)
            static /*void */ TryAddKeyedScoped$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$4(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(68720066650)
            
            //--TRIMMABLE-BOUNDARY-START(85899935834)
            static /*void */ TryAddKeyedSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$2(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(85899935834)
            
            //--TRIMMABLE-BOUNDARY-START(81604968538)
            static /*void */ TryAddKeyedSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$2(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(81604968538)
            
            //--TRIMMABLE-BOUNDARY-START(77310001242)
            static /*void */ TryAddKeyedSingleton(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001242)
            
            //--TRIMMABLE-BOUNDARY-START(103079805018)
            static /*void */ TryAddKeyedSingleton$6(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079805018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(103079805018)
            
            //--TRIMMABLE-BOUNDARY-START(90194903130)
            static /*void */ TryAddKeyedSingleton$3(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(90194903130)
            
            //--TRIMMABLE-BOUNDARY-START(98784837722)
            static /*void */ TryAddKeyedSingleton$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey, /*TService*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$1(TService.$type, serviceKey, $.$box(instance, TService));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837722)
            
            //--TRIMMABLE-BOUNDARY-START(94489870426)
            static /*void */ TryAddKeyedSingleton$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$5(TService, serviceKey, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(94489870426)
            
            //--TRIMMABLE-BOUNDARY-START(25770393690)
            static /*IServiceCollection */ RemoveAllKeyed$1(T, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAllKeyed(collection, T.$type, serviceKey);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393690)
            
            //--TRIMMABLE-BOUNDARY-START(21475426394)
            static /*IServiceCollection */ RemoveAllKeyed(/*this IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$$.System.Type.op_Equality$1(descriptor.ServiceType, serviceType) && $.$$.System.Object.Equals(descriptor.ServiceKey, serviceKey))
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426394)
            
            //--TRIMMABLE-BOUNDARY-START(8590524506)
            static /*IServiceCollection */ Add$1(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524506)
            
            //--TRIMMABLE-BOUNDARY-START(4295557210)
            static /*IServiceCollection */ Add(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var descriptor = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557210)
            
            //--TRIMMABLE-BOUNDARY-START(38655295578)
            static /*void */ TryAdd$1(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*int*/ let count = collection.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if ($.$$.System.Type.op_Equality$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceType, descriptor.ServiceType) && $.$$.System.Object.Equals(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
            }
            //--TRIMMABLE-BOUNDARY-END(38655295578)
            
            //--TRIMMABLE-BOUNDARY-START(34360328282)
            static /*void */ TryAdd(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var d = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, d);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360328282)
            
            //--TRIMMABLE-BOUNDARY-START(197569085530)
            static /*void */ TryAddTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(197569085530)
            
            //--TRIMMABLE-BOUNDARY-START(193274118234)
            static /*void */ TryAddTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(193274118234)
            
            //--TRIMMABLE-BOUNDARY-START(188979150938)
            static /*void */ TryAddTransient(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(188979150938)
            
            //--TRIMMABLE-BOUNDARY-START(210453987418)
            static /*void */ TryAddTransient$5(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(210453987418)
            
            //--TRIMMABLE-BOUNDARY-START(201864052826)
            static /*void */ TryAddTransient$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(201864052826)
            
            //--TRIMMABLE-BOUNDARY-START(206159020122)
            static /*void */ TryAddTransient$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$4(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(206159020122)
            
            //--TRIMMABLE-BOUNDARY-START(141734510682)
            static /*void */ TryAddScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(141734510682)
            
            //--TRIMMABLE-BOUNDARY-START(137439543386)
            static /*void */ TryAddScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(137439543386)
            
            //--TRIMMABLE-BOUNDARY-START(133144576090)
            static /*void */ TryAddScoped(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(133144576090)
            
            //--TRIMMABLE-BOUNDARY-START(154619412570)
            static /*void */ TryAddScoped$5(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(154619412570)
            
            //--TRIMMABLE-BOUNDARY-START(146029477978)
            static /*void */ TryAddScoped$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(146029477978)
            
            //--TRIMMABLE-BOUNDARY-START(150324445274)
            static /*void */ TryAddScoped$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324445274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$4(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(150324445274)
            
            //--TRIMMABLE-BOUNDARY-START(167504314458)
            static /*void */ TryAddSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314458)
            
            //--TRIMMABLE-BOUNDARY-START(163209347162)
            static /*void */ TryAddSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$2(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(163209347162)
            
            //--TRIMMABLE-BOUNDARY-START(158914379866)
            static /*void */ TryAddSingleton(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(158914379866)
            
            //--TRIMMABLE-BOUNDARY-START(184684183642)
            static /*void */ TryAddSingleton$6(TService, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(184684183642)
            
            //--TRIMMABLE-BOUNDARY-START(171799281754)
            static /*void */ TryAddSingleton$3(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TImplementation.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(171799281754)
            
            //--TRIMMABLE-BOUNDARY-START(180389216346)
            static /*void */ TryAddSingleton$5(TService, /*this IServiceCollection*/ collection, /*TService*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$1(TService.$type, $.$box(instance, TService));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(collection, descriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(180389216346)
            
            //--TRIMMABLE-BOUNDARY-START(176094249050)
            static /*void */ TryAddSingleton$4(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd$1(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$5(TService, implementationFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(176094249050)
            
            //--TRIMMABLE-BOUNDARY-START(47245230170)
            static /*void */ TryAddEnumerable$1(/*this IServiceCollection*/ services, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*Type?*/ let implementationType = descriptor.GetImplementationType();
                if ($.$$.System.Type.op_Equality$1(implementationType, $.$$.System.Object.$type) || $.$$.System.Type.op_Equality$1(implementationType, descriptor.ServiceType))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$mxdi.System.SR.Format$5($.$mxdi.System.SR.TryAddIndistinguishableTypeToEnumerable, implementationType, descriptor.ServiceType), "descriptor");
                }
                /*int*/ let count = services.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*ServiceDescriptor*/ let service = services.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$$.System.Type.op_Equality$1(service.ServiceType, descriptor.ServiceType) && $.$$.System.Type.op_Equality$1(service.GetImplementationType(), implementationType) && $.$$.System.Object.Equals(service.ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                services.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
            }
            //--TRIMMABLE-BOUNDARY-END(47245230170)
            
            //--TRIMMABLE-BOUNDARY-START(42950262874)
            static /*void */ TryAddEnumerable(/*this IServiceCollection*/ services, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var d = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable$1(services, d);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950262874)
            
            //--TRIMMABLE-BOUNDARY-START(30065360986)
            static /*IServiceCollection */ Replace(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(descriptor, "descriptor");
                /*int*/ let count = collection.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if ($.$$.System.Type.op_Equality$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceType, descriptor.ServiceType) && $.$$.System.Object.Equals(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceKey, descriptor.ServiceKey))
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                        break;
                    }
                }
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360986)
            
            //--TRIMMABLE-BOUNDARY-START(17180459098)
            static /*IServiceCollection */ RemoveAll$1(T, /*this IServiceCollection*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAll(collection, T.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459098)
            
            //--TRIMMABLE-BOUNDARY-START(12885491802)
            static /*IServiceCollection */ RemoveAll(/*this IServiceCollection*/ collection, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$$.System.Type.op_Equality$1(descriptor.ServiceType, serviceType) && descriptor.ServiceKey === null)
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491802)
            
            static $h = 589914;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964706906),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$2",
      "d": 589914,
      "h": 115964706906,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964706906),
//--TRIMMABLE-BOUNDARY-START(111669739610),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$1",
      "d": 589914,
      "h": 111669739610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111669739610),
//--TRIMMABLE-BOUNDARY-START(107374772314),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddKeyedTransient",
      "d": 589914,
      "h": 107374772314,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374772314),
//--TRIMMABLE-BOUNDARY-START(128849608794),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$5",
      "d": 589914,
      "h": 128849608794,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849608794),
//--TRIMMABLE-BOUNDARY-START(120259674202),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$3",
      "d": 589914,
      "h": 120259674202,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259674202),
//--TRIMMABLE-BOUNDARY-START(124554641498),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedTransient",
      "o": "@$4",
      "d": 589914,
      "h": 124554641498,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554641498),
//--TRIMMABLE-BOUNDARY-START(60130132058),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$2",
      "d": 589914,
      "h": 60130132058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130132058),
//--TRIMMABLE-BOUNDARY-START(55835164762),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$1",
      "d": 589914,
      "h": 55835164762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835164762),
//--TRIMMABLE-BOUNDARY-START(51540197466),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddKeyedScoped",
      "d": 589914,
      "h": 51540197466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540197466),
//--TRIMMABLE-BOUNDARY-START(73015033946),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$5",
      "d": 589914,
      "h": 73015033946,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73015033946),
//--TRIMMABLE-BOUNDARY-START(64425099354),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$3",
      "d": 589914,
      "h": 64425099354,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64425099354),
//--TRIMMABLE-BOUNDARY-START(68720066650),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedScoped",
      "o": "@$4",
      "d": 589914,
      "h": 68720066650,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68720066650),
//--TRIMMABLE-BOUNDARY-START(85899935834),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$2",
      "d": 589914,
      "h": 85899935834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899935834),
//--TRIMMABLE-BOUNDARY-START(81604968538),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$1",
      "d": 589914,
      "h": 81604968538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604968538),
//--TRIMMABLE-BOUNDARY-START(77310001242),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddKeyedSingleton",
      "d": 589914,
      "h": 77310001242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310001242),
//--TRIMMABLE-BOUNDARY-START(103079805018),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$6",
      "d": 589914,
      "h": 103079805018,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079805018),
//--TRIMMABLE-BOUNDARY-START(90194903130),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$3",
      "d": 589914,
      "h": 90194903130,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90194903130),
//--TRIMMABLE-BOUNDARY-START(98784837722),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "instance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$5",
      "d": 589914,
      "h": 98784837722,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784837722),
//--TRIMMABLE-BOUNDARY-START(94489870426),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddKeyedSingleton",
      "o": "@$4",
      "d": 589914,
      "h": 94489870426,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489870426),
//--TRIMMABLE-BOUNDARY-START(25770393690),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveAllKeyed",
      "o": "@$1",
      "d": 589914,
      "h": 25770393690,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770393690),
//--TRIMMABLE-BOUNDARY-START(21475426394),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "RemoveAllKeyed",
      "d": 589914,
      "h": 21475426394,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475426394),
//--TRIMMABLE-BOUNDARY-START(8590524506),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 589914,
      "h": 8590524506,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590524506),
//--TRIMMABLE-BOUNDARY-START(4295557210),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        }
      ],
      "n": "Add",
      "d": 589914,
      "h": 4295557210,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295557210),
//--TRIMMABLE-BOUNDARY-START(38655295578),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": 589914,
      "h": 38655295578,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655295578),
//--TRIMMABLE-BOUNDARY-START(34360328282),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        }
      ],
      "n": "TryAdd",
      "d": 589914,
      "h": 34360328282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360328282),
//--TRIMMABLE-BOUNDARY-START(197569085530),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        }
      ],
      "n": "TryAddTransient",
      "o": "@$2",
      "d": 589914,
      "h": 197569085530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(197569085530),
//--TRIMMABLE-BOUNDARY-START(193274118234),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddTransient",
      "o": "@$1",
      "d": 589914,
      "h": 193274118234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193274118234),
//--TRIMMABLE-BOUNDARY-START(188979150938),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddTransient",
      "d": 589914,
      "h": 188979150938,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188979150938),
//--TRIMMABLE-BOUNDARY-START(210453987418),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddTransient",
      "o": "@$5",
      "d": 589914,
      "h": 210453987418,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210453987418),
//--TRIMMABLE-BOUNDARY-START(201864052826),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddTransient",
      "o": "@$3",
      "d": 589914,
      "h": 201864052826,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201864052826),
//--TRIMMABLE-BOUNDARY-START(206159020122),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddTransient",
      "o": "@$4",
      "d": 589914,
      "h": 206159020122,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206159020122),
//--TRIMMABLE-BOUNDARY-START(141734510682),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        }
      ],
      "n": "TryAddScoped",
      "o": "@$2",
      "d": 589914,
      "h": 141734510682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734510682),
//--TRIMMABLE-BOUNDARY-START(137439543386),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddScoped",
      "o": "@$1",
      "d": 589914,
      "h": 137439543386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137439543386),
//--TRIMMABLE-BOUNDARY-START(133144576090),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddScoped",
      "d": 589914,
      "h": 133144576090,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133144576090),
//--TRIMMABLE-BOUNDARY-START(154619412570),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddScoped",
      "o": "@$5",
      "d": 589914,
      "h": 154619412570,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(154619412570),
//--TRIMMABLE-BOUNDARY-START(146029477978),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddScoped",
      "o": "@$3",
      "d": 589914,
      "h": 146029477978,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146029477978),
//--TRIMMABLE-BOUNDARY-START(150324445274),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddScoped",
      "o": "@$4",
      "d": 589914,
      "h": 150324445274,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(150324445274),
//--TRIMMABLE-BOUNDARY-START(167504314458),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        }
      ],
      "n": "TryAddSingleton",
      "o": "@$2",
      "d": 589914,
      "h": 167504314458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504314458),
//--TRIMMABLE-BOUNDARY-START(163209347162),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "TryAddSingleton",
      "o": "@$1",
      "d": 589914,
      "h": 163209347162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209347162),
//--TRIMMABLE-BOUNDARY-START(158914379866),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "TryAddSingleton",
      "d": 589914,
      "h": 158914379866,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158914379866),
//--TRIMMABLE-BOUNDARY-START(184684183642),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$6",
      "d": 589914,
      "h": 184684183642,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184684183642),
//--TRIMMABLE-BOUNDARY-START(171799281754),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "TryAddSingleton",
      "o": "@$3",
      "d": 589914,
      "h": 171799281754,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(171799281754),
//--TRIMMABLE-BOUNDARY-START(180389216346),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "instance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$5",
      "d": 589914,
      "h": 180389216346,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180389216346),
//--TRIMMABLE-BOUNDARY-START(176094249050),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "TryAddSingleton",
      "o": "@$4",
      "d": 589914,
      "h": 176094249050,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176094249050),
//--TRIMMABLE-BOUNDARY-START(47245230170),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "TryAddEnumerable",
      "o": "@$1",
      "d": 589914,
      "h": 47245230170,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245230170),
//--TRIMMABLE-BOUNDARY-START(42950262874),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "descriptors",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        }
      ],
      "n": "TryAddEnumerable",
      "d": 589914,
      "h": 42950262874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950262874),
//--TRIMMABLE-BOUNDARY-START(30065360986),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "Replace",
      "d": 589914,
      "h": 30065360986,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065360986),
//--TRIMMABLE-BOUNDARY-START(17180459098),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        }
      ],
      "g": [
        "T"
      ],
      "n": "RemoveAll",
      "o": "@$1",
      "d": 589914,
      "h": 17180459098,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180459098),
//--TRIMMABLE-BOUNDARY-START(12885491802),
    {
      "r": 786522,
      "p": [
        {
          "n": "collection",
          "p": 786522
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "RemoveAll",
      "d": 589914,
      "h": 12885491802,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885491802)
  ],
  "h": 589914
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589914)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704026)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor", ($self) => class ServiceDescriptor extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55836278874)
            $ctor$7(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$4(serviceType, null, implementationType, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55836278874);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55836278874)
            
            //--TRIMMABLE-BOUNDARY-START(42951376986)
            $ctor$4(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$5(serviceType, serviceKey, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951376986);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                    this._implementationType = implementationType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951376986)
            
            //--TRIMMABLE-BOUNDARY-START(51541311578)
            $ctor$6(/*Type*/ serviceType, /*object*/ instance)
            {
                this.$ctor$3(serviceType, null, instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541311578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541311578)
            
            //--TRIMMABLE-BOUNDARY-START(38656409690)
            $ctor$3(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ instance)
            {
                this.$ctor$5(serviceType, serviceKey, 0/*ServiceLifetime.Singleton*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656409690);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                    this._implementationInstance = instance;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656409690)
            
            //--TRIMMABLE-BOUNDARY-START(30066475098)
            $ctor$1(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$5(serviceType, null, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066475098);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                    this._implementationFactory = factory;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066475098)
            
            //--TRIMMABLE-BOUNDARY-START(34361442394)
            $ctor$2(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$5(serviceType, serviceKey, lifetime);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361442394);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                    if (serviceKey === null)
                    {
                        /*Func<IServiceProvider, object>*/ let nullKeyedFactory = new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object))().$ctor(this,  (/*sp*/ sp) =>
                        {
                            return factory.Invoke(sp, null);
                        }, {
  "r": 131073,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": 1704026,
  "h": 0,
  "f": 17825794
});
                        this._implementationFactory = nullKeyedFactory;
                    }
                    else 
                    {
                        this._implementationFactory = factory;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361442394)
            
            //--TRIMMABLE-BOUNDARY-START(47246344282)
            $ctor$5(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246344282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Lifetime = lifetime;
                    this.ServiceType = serviceType;
                    this.ServiceKey = serviceKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246344282)
            
            //--TRIMMABLE-BOUNDARY-START(279174578266)
            /*ServiceLifetime*/ Lifetime = 0;
            //--TRIMMABLE-BOUNDARY-END(279174578266)
            
            //--TRIMMABLE-BOUNDARY-START(304944382042)
            /*object?*/ ServiceKey = null;
            //--TRIMMABLE-BOUNDARY-END(304944382042)
            
            //--TRIMMABLE-BOUNDARY-START(309239349338)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(309239349338)
            
            //--TRIMMABLE-BOUNDARY-START(12886605914)
            /*Type?*/ _implementationType = null;
            //--TRIMMABLE-BOUNDARY-END(12886605914)
            
            //--TRIMMABLE-BOUNDARY-START(184685297754)
            /*Type? */ get ImplementationType()
            {
                return this.IsKeyedService ? null : this._implementationType;
            }
            //--TRIMMABLE-BOUNDARY-END(184685297754)
            
            //--TRIMMABLE-BOUNDARY-START(201865166938)
            /*Type? */ get KeyedImplementationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationType;
            }
            //--TRIMMABLE-BOUNDARY-END(201865166938)
            
            //--TRIMMABLE-BOUNDARY-START(8591638618)
            /*object?*/ _implementationInstance = null;
            //--TRIMMABLE-BOUNDARY-END(8591638618)
            
            //--TRIMMABLE-BOUNDARY-START(180390330458)
            /*object? */ get ImplementationInstance()
            {
                return this.IsKeyedService ? null : this._implementationInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(180390330458)
            
            //--TRIMMABLE-BOUNDARY-START(197570199642)
            /*object? */ get KeyedImplementationInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145690202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(197570199642)
            
            //--TRIMMABLE-BOUNDARY-START(4296671322)
            /*object?*/ _implementationFactory = null;
            //--TRIMMABLE-BOUNDARY-END(4296671322)
            
            //--TRIMMABLE-BOUNDARY-START(176095363162)
            /*Func<IServiceProvider, object>? */ get ImplementationFactory()
            {
                return this.IsKeyedService ? null : $.$cast(this._implementationFactory, $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(176095363162)
            
            //--TRIMMABLE-BOUNDARY-START(193275232346)
            /*Func<IServiceProvider, object?, object>? */ get KeyedImplementationFactory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555755610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return $.$cast(this._implementationFactory, $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(193275232346)
            
            //--TRIMMABLE-BOUNDARY-START(188980265050)
            /*bool */ get IsKeyedService()
            {
                return this.ServiceKey !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(188980265050)
            
            //--TRIMMABLE-BOUNDARY-START(347894055002)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894055002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let lifetime = `${"ServiceType"}: ${$.$$.System.Type.ToString.call(this.ServiceType)} ${"Lifetime"}: ${this.Lifetime} `;
                if (this.IsKeyedService)
                {
                    lifetime += `${"ServiceKey"}: ${$.$$.System.Object.ToString.call(this.ServiceKey)} `;
                    if ($.$$.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        return lifetime + `${"KeyedImplementationType"}: ${$.$$.System.Type.ToString.call(this.KeyedImplementationType)}`;
                    }
                    if (this.KeyedImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$$.System.Diagnostics.DiagnosticMethodInfo.Create(this.KeyedImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return lifetime + `${"KeyedImplementationFactory"}: ${declaringTypeName}.${methodName}`;
                    }
                    return lifetime + `${"KeyedImplementationInstance"}: ${$.$$.System.Object.ToString.call(this.KeyedImplementationInstance)}`;
                }
                else 
                {
                    if ($.$$.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        return lifetime + `${"ImplementationType"}: ${$.$$.System.Type.ToString.call(this.ImplementationType)}`;
                    }
                    if (this.ImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$$.System.Diagnostics.DiagnosticMethodInfo.Create(this.ImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return lifetime + `${"ImplementationFactory"}: ${declaringTypeName}.${methodName}`;
                    }
                    return lifetime + `${"ImplementationInstance"}: ${$.$$.System.Object.ToString.call(this.ImplementationInstance)}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(347894055002)
            
            //--TRIMMABLE-BOUNDARY-START(171800395866)
            /*Type */ GetImplementationType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800395866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceKey === null)
                {
                    if ($.$$.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        return this.ImplementationType;
                    }
                    else if (this.ImplementationInstance !== null)
                    {
                        return $.$$.System.Object.GetType.call(this.ImplementationInstance);
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$$.System.Object.GetType.call(this.ImplementationFactory).GenericTypeArguments;
                        $.$$.System.Diagnostics.Debug.Assert$2(typeArguments.length === 2, "typeArguments.Length == 2");
                        return $.$$.System.Array.$ReadT1.call(typeArguments, 1);
                    }
                }
                else 
                {
                    if ($.$$.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        return this.KeyedImplementationType;
                    }
                    else if (this.KeyedImplementationInstance !== null)
                    {
                        return $.$$.System.Object.GetType.call(this.KeyedImplementationInstance);
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$$.System.Object.GetType.call(this.KeyedImplementationFactory).GenericTypeArguments;
                        $.$$.System.Diagnostics.Debug.Assert$2(typeArguments.length === 3, "typeArguments.Length == 3");
                        return $.$$.System.Array.$ReadT1.call(typeArguments, 2);
                    }
                }
                $.$$.System.Diagnostics.Debug.Fail$1("ImplementationType, ImplementationInstance, ImplementationFactory or KeyedImplementationFactory must be non null");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(171800395866)
            
            //--TRIMMABLE-BOUNDARY-START(360778956890)
            static /*ServiceDescriptor */ Transient$2(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778956890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(360778956890)
            
            //--TRIMMABLE-BOUNDARY-START(270584643674)
            static /*ServiceDescriptor */ KeyedTransient$3(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584643674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(270584643674)
            
            //--TRIMMABLE-BOUNDARY-START(356483989594)
            static /*ServiceDescriptor */ Transient$1(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483989594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(service, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(356483989594)
            
            //--TRIMMABLE-BOUNDARY-START(261994709082)
            static /*ServiceDescriptor */ KeyedTransient$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994709082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(261994709082)
            
            //--TRIMMABLE-BOUNDARY-START(365073924186)
            static /*ServiceDescriptor */ Transient$3(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073924186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(365073924186)
            
            //--TRIMMABLE-BOUNDARY-START(266289676378)
            static /*ServiceDescriptor */ KeyedTransient$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289676378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(266289676378)
            
            //--TRIMMABLE-BOUNDARY-START(369368891482)
            static /*ServiceDescriptor */ Transient$4(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368891482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(369368891482)
            
            //--TRIMMABLE-BOUNDARY-START(274879610970)
            static /*ServiceDescriptor */ KeyedTransient$4(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879610970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(274879610970)
            
            //--TRIMMABLE-BOUNDARY-START(352189022298)
            static /*ServiceDescriptor */ Transient(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189022298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(service, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(352189022298)
            
            //--TRIMMABLE-BOUNDARY-START(257699741786)
            static /*ServiceDescriptor */ KeyedTransient(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699741786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(service, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            //--TRIMMABLE-BOUNDARY-END(257699741786)
            
            //--TRIMMABLE-BOUNDARY-START(292059480154)
            static /*ServiceDescriptor */ Scoped$2(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059480154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292059480154)
            
            //--TRIMMABLE-BOUNDARY-START(219045036122)
            static /*ServiceDescriptor */ KeyedScoped$3(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045036122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(219045036122)
            
            //--TRIMMABLE-BOUNDARY-START(287764512858)
            static /*ServiceDescriptor */ Scoped$1(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764512858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(service, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287764512858)
            
            //--TRIMMABLE-BOUNDARY-START(210455101530)
            static /*ServiceDescriptor */ KeyedScoped$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(210455101530)
            
            //--TRIMMABLE-BOUNDARY-START(296354447450)
            static /*ServiceDescriptor */ Scoped$3(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354447450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296354447450)
            
            //--TRIMMABLE-BOUNDARY-START(214750068826)
            static /*ServiceDescriptor */ KeyedScoped$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750068826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(214750068826)
            
            //--TRIMMABLE-BOUNDARY-START(300649414746)
            static /*ServiceDescriptor */ Scoped$4(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649414746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(300649414746)
            
            //--TRIMMABLE-BOUNDARY-START(223340003418)
            static /*ServiceDescriptor */ KeyedScoped$4(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340003418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(223340003418)
            
            //--TRIMMABLE-BOUNDARY-START(283469545562)
            static /*ServiceDescriptor */ Scoped(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469545562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(service, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(283469545562)
            
            //--TRIMMABLE-BOUNDARY-START(206160134234)
            static /*ServiceDescriptor */ KeyedScoped(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(service, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206160134234)
            
            //--TRIMMABLE-BOUNDARY-START(326419218522)
            static /*ServiceDescriptor */ Singleton$3(TService, TImplementation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419218522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, null, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(326419218522)
            
            //--TRIMMABLE-BOUNDARY-START(244814839898)
            static /*ServiceDescriptor */ KeyedSingleton$4(TService, TImplementation, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814839898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService, TImplementation, serviceKey, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(244814839898)
            
            //--TRIMMABLE-BOUNDARY-START(322124251226)
            static /*ServiceDescriptor */ Singleton$2(/*Type*/ service, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124251226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(service, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(322124251226)
            
            //--TRIMMABLE-BOUNDARY-START(236224905306)
            static /*ServiceDescriptor */ KeyedSingleton$2(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224905306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(service, "service");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236224905306)
            
            //--TRIMMABLE-BOUNDARY-START(330714185818)
            static /*ServiceDescriptor */ Singleton$4(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714185818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(330714185818)
            
            //--TRIMMABLE-BOUNDARY-START(240519872602)
            static /*ServiceDescriptor */ KeyedSingleton$3(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519872602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240519872602)
            
            //--TRIMMABLE-BOUNDARY-START(335009153114)
            static /*ServiceDescriptor */ Singleton$5(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335009153114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(TService.$type, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(335009153114)
            
            //--TRIMMABLE-BOUNDARY-START(249109807194)
            static /*ServiceDescriptor */ KeyedSingleton$5(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109807194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService.$type, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(249109807194)
            
            //--TRIMMABLE-BOUNDARY-START(313534316634)
            static /*ServiceDescriptor */ Singleton(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534316634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(313534316634)
            
            //--TRIMMABLE-BOUNDARY-START(227634970714)
            static /*ServiceDescriptor */ KeyedSingleton(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634970714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            //--TRIMMABLE-BOUNDARY-END(227634970714)
            
            //--TRIMMABLE-BOUNDARY-START(339304120410)
            static /*ServiceDescriptor */ Singleton$6(TService, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304120410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$1(TService.$type, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(339304120410)
            
            //--TRIMMABLE-BOUNDARY-START(253404774490)
            static /*ServiceDescriptor */ KeyedSingleton$6(TService, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404774490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$1(TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            //--TRIMMABLE-BOUNDARY-END(253404774490)
            
            //--TRIMMABLE-BOUNDARY-START(317829283930)
            static /*ServiceDescriptor */ Singleton$1(/*Type*/ serviceType, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829283930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$6(serviceType, implementationInstance);
            }
            //--TRIMMABLE-BOUNDARY-END(317829283930)
            
            //--TRIMMABLE-BOUNDARY-START(231929938010)
            static /*ServiceDescriptor */ KeyedSingleton$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929938010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(implementationInstance, "implementationInstance");
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$3(serviceType, serviceKey, implementationInstance);
            }
            //--TRIMMABLE-BOUNDARY-END(231929938010)
            
            //--TRIMMABLE-BOUNDARY-START(81606082650)
            static /*ServiceDescriptor */ DescribeKeyed$2(TService, TImplementation, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606082650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(TService.$type, serviceKey, TImplementation.$type, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(81606082650)
            
            //--TRIMMABLE-BOUNDARY-START(68721180762)
            static /*ServiceDescriptor */ Describe$1(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$7(serviceType, implementationType, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(68721180762)
            
            //--TRIMMABLE-BOUNDARY-START(77311115354)
            static /*ServiceDescriptor */ DescribeKeyed$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311115354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationType, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(77311115354)
            
            //--TRIMMABLE-BOUNDARY-START(64426213466)
            static /*ServiceDescriptor */ Describe(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$1(serviceType, implementationFactory, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(64426213466)
            
            //--TRIMMABLE-BOUNDARY-START(73016148058)
            static /*ServiceDescriptor */ DescribeKeyed(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$2(serviceType, serviceKey, implementationFactory, lifetime);
            }
            //--TRIMMABLE-BOUNDARY-END(73016148058)
            
            //--TRIMMABLE-BOUNDARY-START(60131246170)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText = `Lifetime = ${this.Lifetime}, ServiceType = \"${this.ServiceType.FullName}\"`;
                if (this.IsKeyedService)
                {
                    debugText += `, ServiceKey = \"${$.$$.System.Object.ToString.call(this.ServiceKey)}\"`;
                    if ($.$$.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        debugText += `, KeyedImplementationType = \"${this.KeyedImplementationType.FullName}\"`;
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        debugText += `, KeyedImplementationFactory = ${$.$$.System.Object.ToString.call(this.KeyedImplementationFactory.Method)}`;
                    }
                    else 
                    {
                        debugText += `, KeyedImplementationInstance = ${$.$$.System.Object.ToString.call(this.KeyedImplementationInstance)}`;
                    }
                }
                else 
                {
                    if ($.$$.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        debugText += `, ImplementationType = \"${this.ImplementationType.FullName}\"`;
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        debugText += `, ImplementationFactory = ${$.$$.System.Object.ToString.call(this.ImplementationFactory.Method)}`;
                    }
                    else 
                    {
                        debugText += `, ImplementationInstance = ${$.$$.System.Object.ToString.call(this.ImplementationInstance)}`;
                    }
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(60131246170)
            
            //--TRIMMABLE-BOUNDARY-START(343599087706)
            static /*void */ ThrowNonKeyedDescriptor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(343599087706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.NonKeyedDescriptorMisuse);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343599087706)
            
            static $h = 1704026;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(279174578266),
    {
      "p": 1900634,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325559386,
        "f": 50331649
      },
      "n": "Lifetime",
      "d": 1704026,
      "h": 279174578266,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279174578266),
//--TRIMMABLE-BOUNDARY-START(304944382042),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915493978,
        "f": 50331649
      },
      "n": "ServiceKey",
      "d": 1704026,
      "h": 304944382042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304944382042),
//--TRIMMABLE-BOUNDARY-START(309239349338),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505428570,
        "f": 50331649
      },
      "n": "ServiceType",
      "d": 1704026,
      "h": 309239349338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309239349338),
//--TRIMMABLE-BOUNDARY-START(184685297754),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375886426,
        "f": 50331649
      },
      "n": "ImplementationType",
      "d": 1704026,
      "h": 184685297754,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184685297754),
//--TRIMMABLE-BOUNDARY-START(201865166938),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735624794,
        "f": 50331649
      },
      "n": "KeyedImplementationType",
      "d": 1704026,
      "h": 201865166938,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201865166938),
//--TRIMMABLE-BOUNDARY-START(180390330458),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785951834,
        "f": 50331649
      },
      "n": "ImplementationInstance",
      "d": 1704026,
      "h": 180390330458,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390330458),
//--TRIMMABLE-BOUNDARY-START(197570199642),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145690202,
        "f": 50331649
      },
      "n": "KeyedImplementationInstance",
      "d": 1704026,
      "h": 197570199642,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197570199642),
//--TRIMMABLE-BOUNDARY-START(176095363162),
    {
      "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196017242,
        "f": 50331649
      },
      "n": "ImplementationFactory",
      "d": 1704026,
      "h": 176095363162,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176095363162),
//--TRIMMABLE-BOUNDARY-START(193275232346),
    {
      "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555755610,
        "f": 50331649
      },
      "n": "KeyedImplementationFactory",
      "d": 1704026,
      "h": 193275232346,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193275232346),
//--TRIMMABLE-BOUNDARY-START(188980265050),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965821018,
        "f": 50331649
      },
      "n": "IsKeyedService",
      "d": 1704026,
      "h": 188980265050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188980265050)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(347894055002),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1704026,
      "h": 347894055002,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(347894055002),
//--TRIMMABLE-BOUNDARY-START(171800395866),
    {
      "r": 187760641,
      "n": "GetImplementationType",
      "d": 1704026,
      "h": 171800395866,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(171800395866),
//--TRIMMABLE-BOUNDARY-START(360778956890),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Transient",
      "o": "@$2",
      "d": 1704026,
      "h": 360778956890,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(360778956890),
//--TRIMMABLE-BOUNDARY-START(270584643674),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedTransient",
      "o": "@$3",
      "d": 1704026,
      "h": 270584643674,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(270584643674),
//--TRIMMABLE-BOUNDARY-START(356483989594),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "Transient",
      "o": "@$1",
      "d": 1704026,
      "h": 356483989594,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(356483989594),
//--TRIMMABLE-BOUNDARY-START(261994709082),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "KeyedTransient",
      "o": "@$1",
      "d": 1704026,
      "h": 261994709082,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261994709082),
//--TRIMMABLE-BOUNDARY-START(365073924186),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Transient",
      "o": "@$3",
      "d": 1704026,
      "h": 365073924186,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(365073924186),
//--TRIMMABLE-BOUNDARY-START(266289676378),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedTransient",
      "o": "@$2",
      "d": 1704026,
      "h": 266289676378,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(266289676378),
//--TRIMMABLE-BOUNDARY-START(369368891482),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Transient",
      "o": "@$4",
      "d": 1704026,
      "h": 369368891482,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(369368891482),
//--TRIMMABLE-BOUNDARY-START(274879610970),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedTransient",
      "o": "@$4",
      "d": 1704026,
      "h": 274879610970,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(274879610970),
//--TRIMMABLE-BOUNDARY-START(352189022298),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "Transient",
      "d": 1704026,
      "h": 352189022298,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(352189022298),
//--TRIMMABLE-BOUNDARY-START(257699741786),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "KeyedTransient",
      "d": 1704026,
      "h": 257699741786,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257699741786),
//--TRIMMABLE-BOUNDARY-START(292059480154),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Scoped",
      "o": "@$2",
      "d": 1704026,
      "h": 292059480154,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(292059480154),
//--TRIMMABLE-BOUNDARY-START(219045036122),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedScoped",
      "o": "@$3",
      "d": 1704026,
      "h": 219045036122,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(219045036122),
//--TRIMMABLE-BOUNDARY-START(287764512858),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "Scoped",
      "o": "@$1",
      "d": 1704026,
      "h": 287764512858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(287764512858),
//--TRIMMABLE-BOUNDARY-START(210455101530),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "KeyedScoped",
      "o": "@$1",
      "d": 1704026,
      "h": 210455101530,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210455101530),
//--TRIMMABLE-BOUNDARY-START(296354447450),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Scoped",
      "o": "@$3",
      "d": 1704026,
      "h": 296354447450,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(296354447450),
//--TRIMMABLE-BOUNDARY-START(214750068826),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedScoped",
      "o": "@$2",
      "d": 1704026,
      "h": 214750068826,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214750068826),
//--TRIMMABLE-BOUNDARY-START(300649414746),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Scoped",
      "o": "@$4",
      "d": 1704026,
      "h": 300649414746,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(300649414746),
//--TRIMMABLE-BOUNDARY-START(223340003418),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedScoped",
      "o": "@$4",
      "d": 1704026,
      "h": 223340003418,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(223340003418),
//--TRIMMABLE-BOUNDARY-START(283469545562),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "Scoped",
      "d": 1704026,
      "h": 283469545562,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(283469545562),
//--TRIMMABLE-BOUNDARY-START(206160134234),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "KeyedScoped",
      "d": 1704026,
      "h": 206160134234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206160134234),
//--TRIMMABLE-BOUNDARY-START(326419218522),
    {
      "r": 1704026,
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Singleton",
      "o": "@$3",
      "d": 1704026,
      "h": 326419218522,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(326419218522),
//--TRIMMABLE-BOUNDARY-START(244814839898),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedSingleton",
      "o": "@$4",
      "d": 1704026,
      "h": 244814839898,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(244814839898),
//--TRIMMABLE-BOUNDARY-START(322124251226),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "Singleton",
      "o": "@$2",
      "d": 1704026,
      "h": 322124251226,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(322124251226),
//--TRIMMABLE-BOUNDARY-START(236224905306),
    {
      "r": 1704026,
      "p": [
        {
          "n": "service",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": "KeyedSingleton",
      "o": "@$2",
      "d": 1704026,
      "h": 236224905306,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(236224905306),
//--TRIMMABLE-BOUNDARY-START(330714185818),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "Singleton",
      "o": "@$4",
      "d": 1704026,
      "h": 330714185818,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(330714185818),
//--TRIMMABLE-BOUNDARY-START(240519872602),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService, TImplementation) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TImplementation).$h
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "KeyedSingleton",
      "o": "@$3",
      "d": 1704026,
      "h": 240519872602,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(240519872602),
//--TRIMMABLE-BOUNDARY-START(335009153114),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$($.$scm.System.IServiceProvider, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Singleton",
      "o": "@$5",
      "d": 1704026,
      "h": 335009153114,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(335009153114),
//--TRIMMABLE-BOUNDARY-START(249109807194),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": (TService) => $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, TService).$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedSingleton",
      "o": "@$5",
      "d": 1704026,
      "h": 249109807194,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(249109807194),
//--TRIMMABLE-BOUNDARY-START(313534316634),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": "Singleton",
      "d": 1704026,
      "h": 313534316634,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313534316634),
//--TRIMMABLE-BOUNDARY-START(227634970714),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "KeyedSingleton",
      "d": 1704026,
      "h": 227634970714,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227634970714),
//--TRIMMABLE-BOUNDARY-START(339304120410),
    {
      "r": 1704026,
      "p": [
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "Singleton",
      "o": "@$6",
      "d": 1704026,
      "h": 339304120410,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(339304120410),
//--TRIMMABLE-BOUNDARY-START(253404774490),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": (TService) => TService.$h
        }
      ],
      "g": [
        "TService"
      ],
      "n": "KeyedSingleton",
      "o": "@$6",
      "d": 1704026,
      "h": 253404774490,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(253404774490),
//--TRIMMABLE-BOUNDARY-START(317829283930),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "Singleton",
      "o": "@$1",
      "d": 1704026,
      "h": 317829283930,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317829283930),
//--TRIMMABLE-BOUNDARY-START(231929938010),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationInstance",
          "p": 131073
        }
      ],
      "n": "KeyedSingleton",
      "o": "@$1",
      "d": 1704026,
      "h": 231929938010,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231929938010),
//--TRIMMABLE-BOUNDARY-START(81606082650),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "g": [
        "TService",
        "TImplementation"
      ],
      "n": "DescribeKeyed",
      "o": "@$2",
      "d": 1704026,
      "h": 81606082650,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(81606082650),
//--TRIMMABLE-BOUNDARY-START(68721180762),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Describe",
      "o": "@$1",
      "d": 1704026,
      "h": 68721180762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68721180762),
//--TRIMMABLE-BOUNDARY-START(77311115354),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "DescribeKeyed",
      "o": "@$1",
      "d": 1704026,
      "h": 77311115354,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77311115354),
//--TRIMMABLE-BOUNDARY-START(64426213466),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "Describe",
      "d": 1704026,
      "h": 64426213466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64426213466),
//--TRIMMABLE-BOUNDARY-START(73016148058),
    {
      "r": 1704026,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationFactory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": "DescribeKeyed",
      "d": 1704026,
      "h": 73016148058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73016148058),
//--TRIMMABLE-BOUNDARY-START(60131246170),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1704026,
      "h": 60131246170,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60131246170),
//--TRIMMABLE-BOUNDARY-START(343599087706),
    {
      "r": 65537,
      "n": "ThrowNonKeyedDescriptor",
      "d": 1704026,
      "h": 343599087706,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343599087706)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886605914),
    {
      "t": 187760641,
      "n": "_implementationType",
      "d": 1704026,
      "h": 12886605914,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605914),
//--TRIMMABLE-BOUNDARY-START(8591638618),
    {
      "t": 131073,
      "n": "_implementationInstance",
      "d": 1704026,
      "h": 8591638618,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638618),
//--TRIMMABLE-BOUNDARY-START(4296671322),
    {
      "t": 131073,
      "n": "_implementationFactory",
      "d": 1704026,
      "h": 4296671322,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671322)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55836278874),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1704026,
      "h": 55836278874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836278874),
//--TRIMMABLE-BOUNDARY-START(42951376986),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1704026,
      "h": 42951376986,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951376986),
//--TRIMMABLE-BOUNDARY-START(51541311578),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1704026,
      "h": 51541311578,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541311578),
//--TRIMMABLE-BOUNDARY-START(38656409690),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704026,
      "h": 38656409690,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656409690),
//--TRIMMABLE-BOUNDARY-START(30066475098),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "factory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1704026,
      "h": 30066475098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066475098),
//--TRIMMABLE-BOUNDARY-START(34361442394),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "factory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704026,
      "h": 34361442394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361442394),
//--TRIMMABLE-BOUNDARY-START(47246344282),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "lifetime",
          "p": 1900634
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1704026,
      "h": 47246344282,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246344282)
  ],
  "h": 1704026,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704026)
        
        
        //--TRIMMABLE-BOUNDARY-START(65626)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities", ($self) => class ActivatorUtilities
        {
            //--TRIMMABLE-BOUNDARY-START(128849084506)
            /*ConcurrentDictionary<Type, ConstructorInfoEx[]>*/ static s_constructorInfos = null;
            //--TRIMMABLE-BOUNDARY-END(128849084506)
            
            //--TRIMMABLE-BOUNDARY-START(124554117210)
            /*Lazy<ConditionalWeakTable<Type, ConstructorInfoEx[]>>*/ static s_collectibleConstructorInfos = null;
            //--TRIMMABLE-BOUNDARY-END(124554117210)
            
            //--TRIMMABLE-BOUNDARY-START(73014509658)
            /*int*/ static FixedArgumentThreshold = 4;
            //--TRIMMABLE-BOUNDARY-END(73014509658)
            
            //--TRIMMABLE-BOUNDARY-START(90194378842)
            /*MethodInfo*/ static GetServiceInfo = null;
            //--TRIMMABLE-BOUNDARY-END(90194378842)
            
            //--TRIMMABLE-BOUNDARY-START(55834640474)
            static /*object */ CreateInstance(/*IServiceProvider*/ provider, /*Type*/ instanceType, /*params object[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                if (instanceType.IsAbstract$1)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.CannotCreateAbstractClasses);
                }
                /*ConstructorInfoEx[]?*/ let constructors;
                if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                {
                    constructors = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetOrAddConstructors(instanceType);
                }
                /*StackAllocatedObjects*/ let stackValues = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects();
                /*int*/ let maxArgs = GetMaxArgCount.call(this);
                /*Span<object?>*/ let values = maxArgs <= $.trunc(8/*StackAllocatedObjects.MaxStackAllocArgCount*/ / 2) ? $.$$.System.Span$$($.$$.System.Object).op_Implicit$2(stackValues.$fields) : $.$$.System.Span$$($.$$.System.Object).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((maxArgs * 2) | 0)], null));
                /*Span<object?>*/ let ctorArgs = values.Slice(0, maxArgs);
                /*Span<object?>*/ let bestCtorArgs = values.Slice(maxArgs, maxArgs);
                /*scoped ConstructorMatcher*/ let matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher();
                /*ConstructorInfoEx?*/ let $constructor;
                /*IServiceProviderIsService?*/ let serviceProviderIsService = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService, provider);
                if (serviceProviderIsService !== null)
                {
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$$.System.Array.$ReadT1.call(constructors, i);
                        if ($constructor.IsPreferred)
                        {
                            for(/*int*/ let j = ((i + 1) | 0); j < constructors.length; j++)
                            {
                                if ($.$$.System.Array.$ReadT1.call(constructors, j).IsPreferred)
                                {
                                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                                }
                            }
                            InitializeCtorArgValues($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                            matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                            if (matcher.Match(parameters, serviceProviderIsService) === -1)
                            {
                                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                            }
                            return matcher.CreateInstance(provider);
                        }
                    }
                    /*int*/ let bestLength = -1;
                    /*scoped ConstructorMatcher*/ let bestMatcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher();
                    /*bool*/ let multipleBestLengthFound = false;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$$.System.Array.$ReadT1.call(constructors, i);
                        InitializeCtorArgValues($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                        matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                        /*int*/ let length = matcher.Match(parameters, serviceProviderIsService);
                        $.$$.System.Diagnostics.Debug.Assert$2(!$constructor.IsPreferred, "!constructor.IsPreferred");
                        if (bestLength < length)
                        {
                            bestLength = length;
                            ctorArgs.CopyTo(bestCtorArgs);
                            bestMatcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$3(matcher.ConstructorInfo, bestCtorArgs);
                            multipleBestLengthFound = false;
                        }
                        else if (bestLength === length)
                        {
                            multipleBestLengthFound = true;
                        }
                    }
                    if (bestLength !== -1)
                    {
                        if (multipleBestLengthFound)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$5($.$mxdi.System.SR.MultipleCtorsFoundWithBestLength, instanceType, $.$box(bestLength, $.$$.System.Int32)));
                        }
                        return bestMatcher.CreateInstance(provider);
                    }
                }
                /*Type?[]*/ let argumentTypes;
                if (parameters.length === 0)
                {
                    argumentTypes = $.$$.System.Type.EmptyTypes;
                }
                else 
                {
                    argumentTypes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), null, [parameters.length], null);
                    for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                    {
                        const $t2 = () => $.$$.System.Array.$ReadT1.call(parameters, i);
                        $.$$.System.Array.$WriteT1.call(argumentTypes, $.$ifnn($t2, ($t) => $.$$.System.Object.GetType.call($t)), i);
                    }
                }
                /*ConstructorInfo*/ let constructorInfo;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32))));
                $constructor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindConstructorEx(constructorInfo, constructors);
                InitializeCtorArgValues($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Span$$($.$$.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$3($constructor, ctorArgs);
                matcher.MapParameters(parameterMap, parameters);
                return matcher.CreateInstance(provider);
                /*int*/  function GetMaxArgCount()
                {
                    /*int*/ let max = 0;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        max = $.$$.System.Int32.Max(max, $.$$.System.Array.$ReadT1.call(constructors, i).Parameters.length);
                    }
                    return max;
                }
                /*static void*/  function InitializeCtorArgValues(/*ref Span<object?>*/ ctorArgs, /*int*/ _)
                {
                    ctorArgs.$v.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834640474)
            
            //--TRIMMABLE-BOUNDARY-START(81604444250)
            static /*ConstructorInfoEx[] */ GetOrAddConstructors(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!type.Assembly.IsCollectible)
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.GetOrAdd$1(type, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateConstructorInfoExs(type));
                }
                /*ConstructorInfoEx[]?*/ let value;
                if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.TryGetValue(type, $.$ref(() => value, ($v) => value = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                {
                    return value;
                }
                value = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateConstructorInfoExs(type);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.AddOrUpdate(type, value);
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(81604444250)
            
            //--TRIMMABLE-BOUNDARY-START(34359803994)
            static /*ConstructorInfoEx[] */ CreateConstructorInfoExs(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors();
                /*ConstructorInfoEx[]?*/ let value = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx), null, [constructors.length], null);
                for(/*int*/ let i = 0; i < constructors.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(value, new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx().$ctor$1($.$$.System.Array.$ReadT1.call(constructors, i)), i);
                }
                return value;
            }
            //--TRIMMABLE-BOUNDARY-END(34359803994)
            
            //--TRIMMABLE-BOUNDARY-START(38654771290)
            static /*ObjectFactory */ CreateFactory(/*Type*/ instanceType, /*Type[]*/ argumentTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryReflection(instanceType, argumentTypes);
                }
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryInternal(instanceType, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.System.Linq.Expressions.Expression));
                /*var*/ let factoryLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory, factoryExpressionBody, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771290)
            
            //--TRIMMABLE-BOUNDARY-START(42949738586)
            static /*ObjectFactory<T> */ CreateFactory$1(T, /*Type[]*/ argumentTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    /*var*/ let factory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryReflection(T.$type, argumentTypes);
                    return new ($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T))().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$cast(factory.Invoke(serviceProvider, $arguments), T);
                    }, {
  "r": (T) => T.$h,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
});
                }
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryInternal(T.$type, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.System.Linq.Expressions.Expression));
                /*var*/ let factoryLambda = $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T), factoryExpressionBody, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory<T>?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738586)
            
            //--TRIMMABLE-BOUNDARY-START(47244705882)
            static /*void */ CreateFactoryInternal(/*Type*/ instanceType, /*Type[]*/ argumentTypes, /*out ParameterExpression*/ provider, /*out ParameterExpression*/ argumentArray, /*out Expression*/ factoryExpressionBody)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$$.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32))));
                provider.$v = $.$sle.System.Linq.Expressions.Expression.Parameter($.$scm.System.IServiceProvider.$type, "provider");
                argumentArray.$v = $.$sle.System.Linq.Expressions.Expression.Parameter($.$typeArray($.$$.System.Object).$type, "argumentArray");
                factoryExpressionBody.$v = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.BuildFactoryExpression($constructor, parameterMap, provider.$v, argumentArray.$v);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705882)
            
            //--TRIMMABLE-BOUNDARY-START(60129607770)
            static /*T */ CreateInstance$1(T, /*IServiceProvider*/ provider, /*params object[]*/ parameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateInstance(provider, T.$type, parameters), T);
            }
            //--TRIMMABLE-BOUNDARY-END(60129607770)
            
            //--TRIMMABLE-BOUNDARY-START(98784313434)
            static /*T */ GetServiceOrCreateInstance$1(T, /*IServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetServiceOrCreateInstance(provider, T.$type), T);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313434)
            
            //--TRIMMABLE-BOUNDARY-START(94489346138)
            static /*object */ GetServiceOrCreateInstance(/*IServiceProvider*/ provider, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return provider.System$IServiceProvider$GetService(type) ?? $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateInstance(provider, type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(94489346138)
            
            //--TRIMMABLE-BOUNDARY-START(85899411546)
            static /*object? */ GetService(/*IServiceProvider*/ sp, /*Type*/ type, /*Type*/ requiredBy, /*bool*/ hasDefaultValue, /*object?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let service = key === null ? sp.System$IServiceProvider$GetService(type) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetKeyedService(sp, type, key);
                if (service === null && !hasDefaultValue)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowHelperUnableToResolveService(type, requiredBy);
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(85899411546)
            
            //--TRIMMABLE-BOUNDARY-START(137439019098)
            static /*void */ ThrowHelperUnableToResolveService(/*Type*/ type, /*Type*/ requiredBy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439019098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$5($.$mxdi.System.SR.UnableToResolveService, type, requiredBy));
            }
            //--TRIMMABLE-BOUNDARY-END(137439019098)
            
            //--TRIMMABLE-BOUNDARY-START(30064836698)
            static /*BlockExpression */ BuildFactoryExpression(/*ConstructorInfo*/ $constructor, /*int?[]*/ parameterMap, /*Expression*/ serviceProvider, /*Expression*/ factoryArgumentArray)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ParameterInfo[]?*/ let constructorParameters = $constructor.GetParameters();
                /*var*/ let constructorArguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    /*ParameterInfo?*/ let constructorParameter = $.$$.System.Array.$ReadT1.call(constructorParameters, i);
                    /*Type?*/ let parameterType = constructorParameter.ParameterType;
                    /*object?*/ let defaultValue;
                    /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object));
                    if ($.$$.System.Array.$ReadT1.call(parameterMap, i) !== null)
                    {
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.ArrayAccess$1(factoryArgumentArray, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box($.$$.System.Array.$ReadT1.call(parameterMap, i), $.$$.System.Nullable$$($.$$.System.Int32))) ], null, null)), i);
                    }
                    else 
                    {
                        /*var*/ let keyAttribute = $.$cast($.$$.System.Attribute.GetCustomAttribute$6(constructorParameter, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                        /*var*/ let parameterTypeExpression = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [serviceProvider, $.$sle.System.Linq.Expressions.Expression.Constant(parameterType, $.$$.System.Type.$type), $.$sle.System.Linq.Expressions.Expression.Constant($constructor.DeclaringType, $.$$.System.Type.$type), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(hasDefaultValue, $.$$.System.Boolean)), $.$sle.System.Linq.Expressions.Expression.Constant((keyAttribute?.Key ?? null), $.$$.System.Object.$type)], [-1], null);
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Call$6($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetServiceInfo, parameterTypeExpression), i);
                    }
                    if (hasDefaultValue)
                    {
                        /*ConstantExpression?*/ let defaultValueExpression = $.$sle.System.Linq.Expressions.Expression.Constant$1(defaultValue);
                        $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Coalesce$1($.$$.System.Array.$ReadT1.call(constructorArguments, i), defaultValueExpression), i);
                    }
                    $.$$.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Convert$1($.$$.System.Array.$ReadT1.call(constructorArguments, i), parameterType), i);
                }
                return $.$sle.System.Linq.Expressions.Expression.Block$10($.$sle.System.Linq.Expressions.Expression.IfThen($.$sle.System.Linq.Expressions.Expression.Equal$1(serviceProvider, $.$sle.System.Linq.Expressions.Expression.Constant$1(null)), $.$sle.System.Linq.Expressions.Expression.Throw$1($.$sle.System.Linq.Expressions.Expression.Constant$1(new $.$$.System.ArgumentNullException().$ctor$19("serviceProvider")))), $.$sle.System.Linq.Expressions.Expression.New$3($constructor, constructorArguments));
            }
            //--TRIMMABLE-BOUNDARY-END(30064836698)
            
            //--TRIMMABLE-BOUNDARY-START(51539673178)
            static /*ObjectFactory */ CreateFactoryReflection(/*Type*/ instanceType, /*Type?[]*/ argumentTypes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$$.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32))));
                /*Type*/ let declaringType = $constructor.DeclaringType;
                /*ConstructorInvoker*/ let invoker = $.$$.System.Reflection.ConstructorInvoker.Create($constructor);
                /*ParameterInfo[]*/ let constructorParameters = $constructor.GetParameters();
                if (constructorParameters.length === 0)
                {
                    return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments) =>
                    {
                        return invoker.Invoke();
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
});
                }
                /*bool*/ let useFixedValues = constructorParameters.length <= 4/*FixedArgumentThreshold*/;
                /*bool*/ let hasAnyDefaultValues = false;
                /*int*/ let matchedArgCount = 0;
                /*int*/ let matchedArgCountWithMap = 0;
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    hasAnyDefaultValues = $.$$.System.Boolean.op_BitwiseOr(hasAnyDefaultValues, $.$$.System.Array.$ReadT1.call(constructorParameters, i).HasDefaultValue);
                    if (!($.$$.System.Array.$ReadT1.call(parameterMap, i) === null))
                    {
                        matchedArgCount++;
                        if ($.$$.System.Array.$ReadT1.call(parameterMap, i) === i)
                        {
                            matchedArgCountWithMap++;
                        }
                    }
                }
                if (hasAnyDefaultValues || matchedArgCount !== matchedArgCountWithMap)
                {
                    return InvokeCanonical.call(this);
                }
                if (matchedArgCount === 0)
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryServiceOnlyFixed(invoker, parameters, declaringType, serviceProvider);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
}) : new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryServiceOnlySpan(invoker, parameters, declaringType, serviceProvider);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
});
                }
                if (matchedArgCount === constructorParameters.length)
                {
                    return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryDirect(invoker, serviceProvider, $arguments);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
});
                }
                return InvokeCanonical.call(this);
                /*ObjectFactory*/  function InvokeCanonical()
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryCanonicalFixed(invoker, parameters, declaringType, serviceProvider, $arguments);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
}) : new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryCanonicalSpan(invoker, parameters, declaringType, serviceProvider, $arguments);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "serviceProvider",
      "p": 327718
    },
    {
      "n": "arguments",
      "p": $.$typeArray($.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 65626,
  "h": 0,
  "f": 17825794
});
                }
                /*FactoryParameterContext[]*/  function GetFactoryParameterContext()
                {
                    /*FactoryParameterContext[]*/ let parameters = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext), null, [constructorParameters.length], null);
                    for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                    {
                        /*ParameterInfo*/ let constructorParameter = $.$$.System.Array.$ReadT1.call(constructorParameters, i);
                        /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$$.System.Attribute.GetCustomAttribute$6(constructorParameter, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                        /*object?*/ let defaultValue;
                        /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object));
                        $.$$.System.Array.$WriteT1.call(parameters, new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext().$ctor$3(constructorParameter.ParameterType, hasDefaultValue, defaultValue, $.$$.System.Array.$ReadT1.call(parameterMap, i) ?? -1, (attr?.Key ?? null)), i);
                    }
                    return parameters;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539673178)
            
            //--TRIMMABLE-BOUNDARY-START(327770)
            static $_FactoryParameterContext;
            static get FactoryParameterContext()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_FactoryParameterContext ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext", ($self) => class FactoryParameterContext extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30065098842)
                    $ctor$3(/*Type*/ parameterType, /*bool*/ hasDefaultValue, /*object?*/ defaultValue, /*int*/ argumentIndex, /*object?*/ serviceKey)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065098842);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.ParameterType = parameterType;
                            this.HasDefaultValue = hasDefaultValue;
                            this.DefaultValue = defaultValue;
                            this.ArgumentIndex = argumentIndex;
                            this.ServiceKey = serviceKey;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065098842)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194640986)
                    /*Type*/ ParameterType = null;
                    //--TRIMMABLE-BOUNDARY-END(90194640986)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899673690)
                    /*bool*/ HasDefaultValue = false;
                    //--TRIMMABLE-BOUNDARY-END(85899673690)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655033434)
                    /*object?*/ DefaultValue = null;
                    //--TRIMMABLE-BOUNDARY-END(38655033434)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360066138)
                    /*int*/ ArgumentIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(34360066138)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489608282)
                    /*object?*/ ServiceKey = null;
                    //--TRIMMABLE-BOUNDARY-END(94489608282)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131546)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131546)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ParameterType = this.ParameterType;
                        copy.HasDefaultValue = this.HasDefaultValue;
                        copy.DefaultValue = this.DefaultValue;
                        copy.ArgumentIndex = this.ArgumentIndex;
                        copy.ServiceKey = this.ServiceKey;
                        return copy;
                    }
                    static $h = 327770;
                    static $z = 17;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(90194640986),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771802,
        "f": 50331649
      },
      "n": "ParameterType",
      "d": 327770,
      "h": 90194640986,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640986),
//--TRIMMABLE-BOUNDARY-START(85899673690),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837210,
        "f": 50331649
      },
      "n": "HasDefaultValue",
      "d": 327770,
      "h": 85899673690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899673690),
//--TRIMMABLE-BOUNDARY-START(38655033434),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902618,
        "f": 50331649
      },
      "n": "DefaultValue",
      "d": 327770,
      "h": 38655033434,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033434),
//--TRIMMABLE-BOUNDARY-START(34360066138),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968026,
        "f": 50331649
      },
      "n": "ArgumentIndex",
      "d": 327770,
      "h": 34360066138,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360066138),
//--TRIMMABLE-BOUNDARY-START(94489608282),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604706394,
        "f": 50331649
      },
      "n": "ServiceKey",
      "d": 327770,
      "h": 94489608282,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608282)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098842),
    {
      "p": [
        {
          "n": "parameterType",
          "p": 187760641
        },
        {
          "n": "hasDefaultValue",
          "p": 262145
        },
        {
          "n": "defaultValue",
          "p": 131073
        },
        {
          "n": "argumentIndex",
          "p": 655361
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327770,
      "h": 30065098842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098842),
//--TRIMMABLE-BOUNDARY-START(25770131546),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327770,
      "h": 25770131546,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131546)
  ],
  "d": 65626,
  "h": 327770
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext`; }
                }, $cls, ($v) => $cls.$_FactoryParameterContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327770)
            
            //--TRIMMABLE-BOUNDARY-START(64424575066)
            static /*void */ FindApplicableConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo*/ matchingConstructor, /*out int?[]*/ matchingParameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstructorInfo?*/ let constructorInfo;
                /*int?[]?*/ let parameterMap;
                if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryFindPreferredConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32)))) && !$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryFindMatchingConstructor(instanceType, argumentTypes, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$$.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32)))))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$6($.$mxdi.System.SR.CtorNotLocated, instanceType));
                }
                matchingConstructor.$v = constructorInfo;
                matchingParameterMap.$v = parameterMap;
            }
            //--TRIMMABLE-BOUNDARY-END(64424575066)
            
            //--TRIMMABLE-BOUNDARY-START(68719542362)
            static /*ConstructorInfoEx */ FindConstructorEx(/*ConstructorInfo*/ constructorInfo, /*ConstructorInfoEx[]*/ constructorExs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < constructorExs.length; i++)
                {
                    if ($.$$.System.Object.ReferenceEquals($.$$.System.Array.$ReadT1.call(constructorExs, i).Info, constructorInfo))
                    {
                        return $.$$.System.Array.$ReadT1.call(constructorExs, i);
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(false, "false");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(68719542362)
            
            //--TRIMMABLE-BOUNDARY-START(154618888282)
            static /*bool */ TryFindMatchingConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618888282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                let $i1 = 0;
                let $arr1 = instanceType.GetConstructors();
                while ($i1 < $arr1.length)
                {
                    let $constructor = $arr1[$i1++];
                    /*int?[]*/ let tempParameterMap;
                    if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryCreateParameterMap($constructor.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32)))))
                    {
                        if ($.$$.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$6($.$mxdi.System.SR.MultipleCtorsFound, instanceType));
                        }
                        matchingConstructor.$v = $constructor;
                        parameterMap.$v = tempParameterMap;
                    }
                }
                if ($.$$.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154618888282)
            
            //--TRIMMABLE-BOUNDARY-START(158913855578)
            static /*bool */ TryFindPreferredConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913855578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let seenPreferred = false;
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                if (constructors === null)
                {
                    if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                    {
                        constructors = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetOrAddConstructors(instanceType);
                    }
                }
                let $i1 = 0;
                let $arr1 = constructors;
                while ($i1 < $arr1.length)
                {
                    let $constructor = $arr1[$i1++];
                    if ($constructor.IsPreferred)
                    {
                        if (seenPreferred)
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                        }
                        /*int?[]*/ let tempParameterMap;
                        if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryCreateParameterMap($constructor.Info.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$$.System.Int32)))))
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                        }
                        matchingConstructor.$v = $constructor.Info;
                        parameterMap.$v = tempParameterMap;
                        seenPreferred = true;
                    }
                }
                if ($.$$.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(158913855578)
            
            //--TRIMMABLE-BOUNDARY-START(150323920986)
            static /*bool */ TryCreateParameterMap(/*ParameterInfo[]*/ constructorParameters, /*Type?[]*/ argumentTypes, /*out int?[]*/ parameterMap)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323920986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                parameterMap.$v = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$$.System.Int32)), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                {
                    /*bool*/ let foundMatch = false;
                    /*Type?*/ let givenParameter = $.$$.System.Array.$ReadT1.call(argumentTypes, i);
                    for(/*int*/ let j = 0; j < constructorParameters.length; j++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(parameterMap.$v, j) !== null)
                        {
                            continue;
                        }
                        if ($.$$.System.Array.$ReadT1.call(constructorParameters, j).ParameterType.IsAssignableFrom(givenParameter))
                        {
                            foundMatch = true;
                            $.$$.System.Array.$WriteT1.call(parameterMap.$v, i, j);
                            break;
                        }
                    }
                    if (!foundMatch)
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(150323920986)
            
            //--TRIMMABLE-BOUNDARY-START(196698)
            static $_ConstructorInfoEx;
            static get ConstructorInfoEx()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ConstructorInfoEx ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx", ($self) => class ConstructorInfoEx extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(30064967770)
                    /*ConstructorInfo*/ Info = null;
                    //--TRIMMABLE-BOUNDARY-END(30064967770)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836954)
                    /*ParameterInfo[]*/ Parameters = null;
                    //--TRIMMABLE-BOUNDARY-END(47244836954)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654902362)
                    /*bool*/ IsPreferred = false;
                    //--TRIMMABLE-BOUNDARY-END(38654902362)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131290)
                    /*object?[]?*/ _parameterKeys = null;
                    //--TRIMMABLE-BOUNDARY-END(8590131290)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295163994)
                    /*ConstructorInvoker?*/ _invoker = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163994)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359935066)
                    /*ConstructorInvoker */ get Invoker()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033178);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._invoker ??= $.$$.System.Reflection.ConstructorInvoker.Create(this.Info);
                        return this._invoker;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359935066)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098586)
                    $ctor$1(/*ConstructorInfo*/ $constructor)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098586);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Info = $constructor;
                            this.Parameters = $constructor.GetParameters();
                            this.IsPreferred = $constructor.IsDefined($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute.$type, false);
                            for(/*int*/ let i = 0; i < this.Parameters.length; i++)
                            {
                                /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$$.System.Attribute.GetCustomAttribute$6($.$$.System.Array.$ReadT1.call(this.Parameters, i), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                                if (!(attr === null))
                                {
                                    this._parameterKeys ??= $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this.Parameters.length], null);
                                    $.$$.System.Array.$WriteT1.call(this._parameterKeys, attr.Key, i);
                                }
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098586)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869658)
                    /*bool */ IsService(/*IServiceProviderIsService*/ serviceProviderIsService, /*int*/ parameterIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949869658);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ParameterInfo*/ let parameterInfo = $.$$.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t1 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t1, ($t) => $.$$.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let serviceProviderIsKeyedService;
                            if ($.$is(serviceProviderIsService, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService, { set $v(v){ serviceProviderIsKeyedService = v; } }))
                            {
                                return serviceProviderIsKeyedService.Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
                        }
                        return serviceProviderIsService.Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService(parameterInfo.ParameterType);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869658)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000474)
                    /*object? */ GetService(/*IServiceProvider*/ serviceProvider, /*int*/ parameterIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770000474);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*ParameterInfo*/ let parameterInfo = $.$$.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t1 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t1, ($t) => $.$$.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let keyedServiceProvider;
                            if ($.$is(serviceProvider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                            {
                                return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
                        }
                        return serviceProvider.System$IServiceProvider$GetService(parameterInfo.ParameterType);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000474)
                    
                    static $h = 196698;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34359935066),
    {
      "p": 108527617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475033178,
        "f": 50331649
      },
      "n": "Invoker",
      "d": 196698,
      "h": 34359935066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359935066)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949869658),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceProviderIsService",
          "p": 983130
        },
        {
          "n": "parameterIndex",
          "p": 655361
        }
      ],
      "n": "IsService",
      "d": 196698,
      "h": 42949869658,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949869658),
//--TRIMMABLE-BOUNDARY-START(25770000474),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "parameterIndex",
          "p": 655361
        }
      ],
      "n": "GetService",
      "d": 196698,
      "h": 25770000474,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000474)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30064967770),
    {
      "t": 108462081,
      "n": "Info",
      "d": 196698,
      "h": 30064967770,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(30064967770),
//--TRIMMABLE-BOUNDARY-START(47244836954),
    {
      "t": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h,
      "n": "Parameters",
      "d": 196698,
      "h": 47244836954,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(47244836954),
//--TRIMMABLE-BOUNDARY-START(38654902362),
    {
      "t": 262145,
      "n": "IsPreferred",
      "d": 196698,
      "h": 38654902362,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38654902362),
//--TRIMMABLE-BOUNDARY-START(8590131290),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_parameterKeys",
      "d": 196698,
      "h": 8590131290,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131290),
//--TRIMMABLE-BOUNDARY-START(4295163994),
    {
      "t": 108527617,
      "n": "_invoker",
      "d": 196698,
      "h": 4295163994,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(4295163994)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098586),
    {
      "p": [
        {
          "n": "constructor",
          "p": 108462081
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196698,
      "h": 12885098586,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098586)
  ],
  "d": 65626,
  "h": 196698
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx`; }
                }, $cls, ($v) => $cls.$_ConstructorInfoEx = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196698)
            
            //--TRIMMABLE-BOUNDARY-START(262234)
            static $_ConstructorMatcher;
            static get ConstructorMatcher()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ConstructorMatcher ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher", ($self) => class ConstructorMatcher extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295229530)
                    /*ConstructorInfoEx*/  get _constructor() { return this.$getField(0, 4); }
                    /*ConstructorInfoEx*/  set _constructor(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295229530)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196826)
                    /*Span<object?>*/  get _parameterValues() { return this.$getField(4, 8); }
                    /*Span<object?>*/  set _parameterValues(value) { this.$setField(4, 8, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590196826)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131418)
                    $ctor$3(/*ConstructorInfoEx*/ $constructor, /*Span<object?>*/ parameterValues)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180131418);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._constructor = $constructor;
                            this._parameterValues = parameterValues;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180131418)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098714)
                    /*ConstructorInfoEx */ get ConstructorInfo()
                    {
                        return this._constructor;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475098714)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949935194)
                    /*int */ Match(/*object[]*/ givenParameters, /*IServiceProviderIsService*/ serviceProviderIsService)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949935194);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let givenIndex = 0; givenIndex < givenParameters.length; givenIndex++)
                        {
                            const $t1 = () => $.$$.System.Array.$ReadT1.call(givenParameters, givenIndex);
                            /*Type?*/ let givenType = $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t));
                            /*bool*/ let givenMatched = false;
                            for(/*int*/ let applyIndex = 0; applyIndex < this._constructor.Parameters.length; applyIndex++)
                            {
                                if (this._parameterValues.get_Item(applyIndex).$v === null && $.$$.System.Array.$ReadT1.call(this._constructor.Parameters, applyIndex).ParameterType.IsAssignableFrom(givenType))
                                {
                                    givenMatched = true;
                                    this._parameterValues.get_Item(applyIndex).$v = $.$$.System.Array.$ReadT1.call(givenParameters, givenIndex);
                                    break;
                                }
                            }
                            if (!givenMatched)
                            {
                                return -1;
                            }
                        }
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if (this._parameterValues.get_Item(i).$v === null && !this._constructor.IsService(serviceProviderIsService, i))
                            {
                                /*object?*/ let defaultValue;
                                if ($.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$$.System.Array.$ReadT1.call(this._constructor.Parameters, i), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object)))
                                {
                                    this._parameterValues.get_Item(i).$v = defaultValue;
                                }
                                else 
                                {
                                    return -1;
                                }
                            }
                        }
                        return this._constructor.Parameters.length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949935194)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770066010)
                    /*object */ CreateInstance(/*IServiceProvider*/ provider)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770066010);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let index = 0; index < this._constructor.Parameters.length; index++)
                        {
                            if (this._parameterValues.get_Item(index).$v === null)
                            {
                                /*object?*/ let value = this._constructor.GetService(provider, index);
                                if (value === null)
                                {
                                    /*object?*/ let defaultValue;
                                    if (!$.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$$.System.Array.$ReadT1.call(this._constructor.Parameters, index), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object)))
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$5($.$mxdi.System.SR.UnableToResolveService, $.$$.System.Array.$ReadT1.call(this._constructor.Parameters, index).ParameterType, this._constructor.Info.DeclaringType));
                                    }
                                    else 
                                    {
                                        this._parameterValues.get_Item(index).$v = defaultValue;
                                    }
                                }
                                else 
                                {
                                    this._parameterValues.get_Item(index).$v = value;
                                }
                            }
                        }
                        return this._constructor.Invoker.Invoke$5(this._parameterValues.Slice(0, this._constructor.Parameters.length));
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770066010)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654967898)
                    /*void */ MapParameters(/*int?[]*/ parameterMap, /*object[]*/ givenParameters)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38654967898);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if ($.$$.System.Array.$ReadT1.call(parameterMap, i) !== null)
                            {
                                this._parameterValues.get_Item(i).$v = $.$$.System.Array.$ReadT1.call(givenParameters, $.$cast($.$$.System.Array.$ReadT1.call(parameterMap, i), $.$$.System.Int32));
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654967898)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164122)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164122)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._constructor = this._constructor;
                        copy._parameterValues = this._parameterValues.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295229530)
                        this._constructor = null;
                        //--TRIMMABLE-BOUNDARY-END(4295229530)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590196826)
                        this._parameterValues = $.$default($.$$.System.Span$$($.$$.System.Object));
                        //--TRIMMABLE-BOUNDARY-END(8590196826)
                        
                    }
                    static $h = 262234;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475098714),
    {
      "p": 196698,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000602,
        "f": 50331649
      },
      "n": "ConstructorInfo",
      "d": 262234,
      "h": 21475098714,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098714)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42949935194),
    {
      "r": 655361,
      "p": [
        {
          "n": "givenParameters",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "serviceProviderIsService",
          "p": 983130
        }
      ],
      "n": "Match",
      "d": 262234,
      "h": 42949935194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935194),
//--TRIMMABLE-BOUNDARY-START(25770066010),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "n": "CreateInstance",
      "d": 262234,
      "h": 25770066010,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770066010),
//--TRIMMABLE-BOUNDARY-START(38654967898),
    {
      "r": 65537,
      "p": [
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h
        },
        {
          "n": "givenParameters",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "MapParameters",
      "d": 262234,
      "h": 38654967898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967898)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229530),
    {
      "t": 196698,
      "n": "_constructor",
      "d": 262234,
      "h": 4295229530,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229530),
//--TRIMMABLE-BOUNDARY-START(8590196826),
    {
      "t": $.$$.System.Span$$($.$$.System.Object).$h,
      "n": "_parameterValues",
      "d": 262234,
      "h": 8590196826,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196826)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131418),
    {
      "p": [
        {
          "n": "constructor",
          "p": 196698
        },
        {
          "n": "parameterValues",
          "p": $.$$.System.Span$$($.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262234,
      "h": 17180131418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131418),
//--TRIMMABLE-BOUNDARY-START(12885164122),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262234,
      "h": 12885164122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164122)
  ],
  "d": 65626,
  "h": 262234
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher`; }
                }, $cls, ($v) => $cls.$_ConstructorMatcher = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262234)
            
            //--TRIMMABLE-BOUNDARY-START(146028953690)
            static /*void */ ThrowMultipleCtorsMarkedWithAttributeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$6($.$mxdi.System.SR.MultipleCtorsMarkedWithAttribute, "ActivatorUtilitiesConstructorAttribute"));
            }
            //--TRIMMABLE-BOUNDARY-END(146028953690)
            
            //--TRIMMABLE-BOUNDARY-START(141733986394)
            static /*void */ ThrowMarkedCtorDoesNotTakeAllProvidedArguments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141733986394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.Format$6($.$mxdi.System.SR.MarkedCtorMissingArgumentTypes, "ActivatorUtilitiesConstructorAttribute"));
            }
            //--TRIMMABLE-BOUNDARY-END(141733986394)
            
            //--TRIMMABLE-BOUNDARY-START(115964182618)
            static /*object */ ReflectionFactoryServiceOnlyFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964182618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$$.System.Diagnostics.Debug.Assert$2(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                let $switch1 = parameters.length;
                switch($switch1)
                {
                    case 1:
                    return invoker.Invoke$4($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey));
                    case 2:
                    return invoker.Invoke$3($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey));
                    case 3:
                    return invoker.Invoke$2($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 2).ServiceKey));
                    case 4:
                    return invoker.Invoke$1($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 2).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, 3).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, 3).ServiceKey));
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964182618)
            
            //--TRIMMABLE-BOUNDARY-START(120259149914)
            static /*object */ ReflectionFactoryServiceOnlySpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259149914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*object?[]*/ let $arguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call($arguments, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, declaringType, false, $.$$.System.Array.$ReadT1.call(parameters, i).ServiceKey), i);
                }
                return invoker.Invoke$5($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Object, $arguments));
            }
            //--TRIMMABLE-BOUNDARY-END(120259149914)
            
            //--TRIMMABLE-BOUNDARY-START(103079280730)
            static /*object */ ReflectionFactoryCanonicalFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079280730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$$.System.Diagnostics.Debug.Assert$2(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*ref FactoryParameterContext*/ let parameter1 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 0, false, true);
                let $switch1 = parameters.length;
                switch($switch1)
                {
                    case 1:
                    return invoker.Invoke$4(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue);
                    case 2:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        return invoker.Invoke$3(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue);
                    }
                    case 3:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        return invoker.Invoke$2(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue);
                    }
                    case 4:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        /*ref FactoryParameterContext*/ let parameter4 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 3, false, true);
                        return invoker.Invoke$1(((parameter1.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue, ((parameter4.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter4.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter4.$v.ParameterType, declaringType, parameter4.$v.HasDefaultValue, parameter4.$v.ServiceKey)) ?? parameter4.$v.DefaultValue);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(103079280730)
            
            //--TRIMMABLE-BOUNDARY-START(107374248026)
            static /*object */ ReflectionFactoryCanonicalSpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374248026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                /*object?[]*/ let constructorArguments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    /*ref FactoryParameterContext*/ let parameter = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, i, false, true);
                    $.$$.System.Array.$WriteT1.call(constructorArguments, ((parameter.$v.ArgumentIndex !== -1) ? $.$$.System.Array.$ReadT1.call($arguments, parameter.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter.$v.ParameterType, declaringType, parameter.$v.HasDefaultValue, parameter.$v.ServiceKey)) ?? parameter.$v.DefaultValue, i);
                }
                return invoker.Invoke$5($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Object, constructorArguments));
            }
            //--TRIMMABLE-BOUNDARY-END(107374248026)
            
            //--TRIMMABLE-BOUNDARY-START(111669215322)
            static /*object */ ReflectionFactoryDirect(/*ConstructorInvoker*/ invoker, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceProvider, "serviceProvider");
                if ($arguments === null)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowHelperNullReferenceException();
                }
                return invoker.Invoke$5($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Object, $arguments));
            }
            //--TRIMMABLE-BOUNDARY-END(111669215322)
            
            //--TRIMMABLE-BOUNDARY-START(133144051802)
            static /*void */ ThrowHelperNullReferenceException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144051802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NullReferenceException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(133144051802)
            
            //--TRIMMABLE-BOUNDARY-START(131162)
            static $_ActivatorUtilitiesUpdateHandler;
            static get ActivatorUtilitiesUpdateHandler()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ActivatorUtilitiesUpdateHandler ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ActivatorUtilitiesUpdateHandler", ($self) => class ActivatorUtilitiesUpdateHandler
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098458)
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295098458);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.Clear();
                        if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.IsValueCreated)
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.Clear();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295098458)
                    
                    static $h = 131162;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098458),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ClearCache",
      "d": 131162,
      "h": 4295098458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098458)
  ],
  "d": 65626,
  "h": 131162
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ActivatorUtilitiesUpdateHandler`; }
                }, $cls, ($v) => $cls.$_ActivatorUtilitiesUpdateHandler = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131162)
            
            //--TRIMMABLE-BOUNDARY-START(393306)
            static $_StackAllocatedObjects;
            static get StackAllocatedObjects()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_StackAllocatedObjects ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects", ($self) => class StackAllocatedObjects extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295194)
                    //--TRIMMABLE-BOUNDARY-END(12885295194)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360602)
                    /*object?*/  get _arg0() { return this.$getField(0, 4); }
                    /*object?*/  set _arg0(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295360602)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327898)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590327898)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(8)
                        copy.$fields = [...this.$fields];
                        $.$$.System.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(object?, 8)
                        for (let $i = 7; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, null);
                        }
                        $.$$.System.Array.AddMetadata(this.$fields, $.$typeOf($.$$.System.Object), null, null)
                    }
                    static $h = 393306;
                    static $z = 32;
                    static $f = 0b1000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295194),
    {
      "t": 655361,
      "n": "MaxStackAllocArgCount",
      "d": 393306,
      "h": 12885295194,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885295194),
//--TRIMMABLE-BOUNDARY-START(4295360602),
    {
      "t": 131073,
      "n": "_arg0",
      "d": 393306,
      "h": 4295360602,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360602)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327898),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393306,
      "h": 8590327898,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327898)
  ],
  "d": 65626,
  "h": 393306,
  "a": [
    {
      "t": 129564673,
      "c": 8719499265,
      "a": [
        {
          "v": 8,
          "t": 655361
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects`; }
                }, $cls, ($v) => $cls.$_StackAllocatedObjects = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393306)
            
            //--TRIMMABLE-BOUNDARY-START(77309476954)
            static /*object? */ GetKeyedService(/*IServiceProvider*/ provider, /*Type*/ type, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(type, serviceKey);
                }
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(77309476954)
            
            //--TRIMMABLE-BOUNDARY-START(25769869402)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(128849084506)
                    this.s_constructorInfos = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(128849084506)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554117210)
                    this.s_collectibleConstructorInfos = new ($.$$.System.Lazy$$($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(124554117210)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194378842)
                    this.GetServiceInfo = new ($.$$.System.Func$$$$$$$($.$scm.System.IServiceProvider, $.$$.System.Type, $.$$.System.Type, $.$$.System.Boolean, $.$$.System.Object, $.$$.System.Object))().$ctor($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService).Method;
                    //--TRIMMABLE-BOUNDARY-END(90194378842)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869402)
            
            static $h = 65626;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834640474),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "CreateInstance",
      "d": 65626,
      "h": 55834640474,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834640474),
//--TRIMMABLE-BOUNDARY-START(81604444250),
    {
      "r": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetOrAddConstructors",
      "d": 65626,
      "h": 81604444250,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604444250),
//--TRIMMABLE-BOUNDARY-START(34359803994),
    {
      "r": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "CreateConstructorInfoExs",
      "d": 65626,
      "h": 34359803994,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359803994),
//--TRIMMABLE-BOUNDARY-START(38654771290),
    {
      "r": 1376346,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "CreateFactory",
      "d": 65626,
      "h": 38654771290,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654771290),
//--TRIMMABLE-BOUNDARY-START(42949738586),
    {
      "r": (T) => $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T).$h,
      "p": [
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateFactory",
      "o": "@$1",
      "d": 65626,
      "h": 42949738586,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42949738586),
//--TRIMMABLE-BOUNDARY-START(47244705882),
    {
      "r": 65537,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "provider",
          "p": 40566821,
          "f": 2
        },
        {
          "n": "argumentArray",
          "p": 40566821,
          "f": 2
        },
        {
          "n": "factoryExpressionBody",
          "p": 8781861,
          "f": 2
        }
      ],
      "n": "CreateFactoryInternal",
      "d": 65626,
      "h": 47244705882,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244705882),
//--TRIMMABLE-BOUNDARY-START(60129607770),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateInstance",
      "o": "@$1",
      "d": 65626,
      "h": 60129607770,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129607770),
//--TRIMMABLE-BOUNDARY-START(98784313434),
    {
      "r": (T) => T.$h,
      "p": [
        {
          "n": "provider",
          "p": 327718
        }
      ],
      "g": [
        "T"
      ],
      "n": "GetServiceOrCreateInstance",
      "o": "@$1",
      "d": 65626,
      "h": 98784313434,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784313434),
//--TRIMMABLE-BOUNDARY-START(94489346138),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetServiceOrCreateInstance",
      "d": 65626,
      "h": 94489346138,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489346138),
//--TRIMMABLE-BOUNDARY-START(85899411546),
    {
      "r": 131073,
      "p": [
        {
          "n": "sp",
          "p": 327718
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "requiredBy",
          "p": 187760641
        },
        {
          "n": "hasDefaultValue",
          "p": 262145
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "GetService",
      "d": 65626,
      "h": 85899411546,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85899411546),
//--TRIMMABLE-BOUNDARY-START(137439019098),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "requiredBy",
          "p": 187760641
        }
      ],
      "n": "ThrowHelperUnableToResolveService",
      "d": 65626,
      "h": 137439019098,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137439019098),
//--TRIMMABLE-BOUNDARY-START(30064836698),
    {
      "r": 3997733,
      "p": [
        {
          "n": "constructor",
          "p": 108462081
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h
        },
        {
          "n": "serviceProvider",
          "p": 8781861
        },
        {
          "n": "factoryArgumentArray",
          "p": 8781861
        }
      ],
      "n": "BuildFactoryExpression",
      "d": 65626,
      "h": 30064836698,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064836698),
//--TRIMMABLE-BOUNDARY-START(51539673178),
    {
      "r": 1376346,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "CreateFactoryReflection",
      "d": 65626,
      "h": 51539673178,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539673178),
//--TRIMMABLE-BOUNDARY-START(64424575066),
    {
      "r": 65537,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "constructors",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx).$h
        },
        {
          "n": "matchingConstructor",
          "p": 108462081,
          "f": 2
        },
        {
          "n": "matchingParameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h,
          "f": 2
        }
      ],
      "n": "FindApplicableConstructor",
      "d": 65626,
      "h": 64424575066,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424575066),
//--TRIMMABLE-BOUNDARY-START(68719542362),
    {
      "r": 196698,
      "p": [
        {
          "n": "constructorInfo",
          "p": 108462081
        },
        {
          "n": "constructorExs",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx).$h
        }
      ],
      "n": "FindConstructorEx",
      "d": 65626,
      "h": 68719542362,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719542362),
//--TRIMMABLE-BOUNDARY-START(154618888282),
    {
      "r": 262145,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "matchingConstructor",
          "p": 108462081,
          "f": 2
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryFindMatchingConstructor",
      "d": 65626,
      "h": 154618888282,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154618888282),
//--TRIMMABLE-BOUNDARY-START(158913855578),
    {
      "r": 262145,
      "p": [
        {
          "n": "instanceType",
          "p": 187760641
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "constructors",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx).$h
        },
        {
          "n": "matchingConstructor",
          "p": 108462081,
          "f": 2
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryFindPreferredConstructor",
      "d": 65626,
      "h": 158913855578,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158913855578),
//--TRIMMABLE-BOUNDARY-START(150323920986),
    {
      "r": 262145,
      "p": [
        {
          "n": "constructorParameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h
        },
        {
          "n": "argumentTypes",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "parameterMap",
          "p": $.$typeArray($.$typeNullable($.$$.System.Int32)).$h,
          "f": 2
        }
      ],
      "n": "TryCreateParameterMap",
      "d": 65626,
      "h": 150323920986,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(150323920986),
//--TRIMMABLE-BOUNDARY-START(146028953690),
    {
      "r": 65537,
      "n": "ThrowMultipleCtorsMarkedWithAttributeException",
      "d": 65626,
      "h": 146028953690,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146028953690),
//--TRIMMABLE-BOUNDARY-START(141733986394),
    {
      "r": 65537,
      "n": "ThrowMarkedCtorDoesNotTakeAllProvidedArguments",
      "d": 65626,
      "h": 141733986394,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141733986394),
//--TRIMMABLE-BOUNDARY-START(115964182618),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 108527617
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 187760641
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "ReflectionFactoryServiceOnlyFixed",
      "d": 65626,
      "h": 115964182618,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(115964182618),
//--TRIMMABLE-BOUNDARY-START(120259149914),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 108527617
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 187760641
        },
        {
          "n": "serviceProvider",
          "p": 327718
        }
      ],
      "n": "ReflectionFactoryServiceOnlySpan",
      "d": 65626,
      "h": 120259149914,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259149914),
//--TRIMMABLE-BOUNDARY-START(103079280730),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 108527617
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 187760641
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "ReflectionFactoryCanonicalFixed",
      "d": 65626,
      "h": 103079280730,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(103079280730),
//--TRIMMABLE-BOUNDARY-START(107374248026),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 108527617
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext).$h
        },
        {
          "n": "declaringType",
          "p": 187760641
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "ReflectionFactoryCanonicalSpan",
      "d": 65626,
      "h": 107374248026,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374248026),
//--TRIMMABLE-BOUNDARY-START(111669215322),
    {
      "r": 131073,
      "p": [
        {
          "n": "invoker",
          "p": 108527617
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "ReflectionFactoryDirect",
      "d": 65626,
      "h": 111669215322,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669215322),
//--TRIMMABLE-BOUNDARY-START(133144051802),
    {
      "r": 65537,
      "n": "ThrowHelperNullReferenceException",
      "d": 65626,
      "h": 133144051802,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(133144051802),
//--TRIMMABLE-BOUNDARY-START(77309476954),
    {
      "r": 131073,
      "p": [
        {
          "n": "provider",
          "p": 327718
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 65626,
      "h": 77309476954,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309476954)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128849084506),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx)).$h,
      "n": "s_constructorInfos",
      "d": 65626,
      "h": 128849084506,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849084506),
//--TRIMMABLE-BOUNDARY-START(124554117210),
    {
      "t": $.$$.System.Lazy$$($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))).$h,
      "n": "s_collectibleConstructorInfos",
      "d": 65626,
      "h": 124554117210,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(124554117210),
//--TRIMMABLE-BOUNDARY-START(73014509658),
    {
      "t": 655361,
      "n": "FixedArgumentThreshold",
      "d": 65626,
      "h": 73014509658,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73014509658),
//--TRIMMABLE-BOUNDARY-START(90194378842),
    {
      "t": 116850689,
      "n": "GetServiceInfo",
      "d": 65626,
      "h": 90194378842,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90194378842)
  ],
  "j": [327770,196698,262234,131162,393306
  ],
  "h": 65626
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65626)
        
        
        //--TRIMMABLE-BOUNDARY-START(458842)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute", ($self) => class ActivatorUtilitiesConstructorAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426138)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426138)
            
            static $h = 458842;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426138),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458842,
      "h": 4295426138,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426138)
  ],
  "h": 458842,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458842)
        
        
        //--TRIMMABLE-BOUNDARY-START(655450)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute", ($self) => class FromKeyedServicesAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180524634)
            $ctor$3(/*object?*/ key)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180524634);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.LookupMode = key === null ? 1/*ServiceKeyLookupMode.NullKey*/ : 2/*ServiceKeyLookupMode.ExplicitKey*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524634)
            
            //--TRIMMABLE-BOUNDARY-START(12885557338)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = null;
                    this.LookupMode = 0/*ServiceKeyLookupMode.InheritKey*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557338)
            
            //--TRIMMABLE-BOUNDARY-START(38655361114)
            /*object?*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(38655361114)
            
            //--TRIMMABLE-BOUNDARY-START(42950328410)
            /*ServiceKeyLookupMode*/ LookupMode = 0;
            //--TRIMMABLE-BOUNDARY-END(42950328410)
            
            static $h = 655450;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655361114),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459226,
        "f": 50331649
      },
      "n": "Key",
      "d": 655450,
      "h": 38655361114,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655361114),
//--TRIMMABLE-BOUNDARY-START(42950328410),
    {
      "p": 1835098,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393818,
        "f": 50331649
      },
      "n": "LookupMode",
      "d": 655450,
      "h": 42950328410,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950328410)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180524634),
    {
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655450,
      "h": 17180524634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524634),
//--TRIMMABLE-BOUNDARY-START(12885557338),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655450,
      "h": 12885557338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557338)
  ],
  "h": 655450,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2048,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655450)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769562)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute", ($self) => class ServiceKeyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296736858)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736858)
            
            static $h = 1769562;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736858),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769562,
      "h": 4296736858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736858)
  ],
  "h": 1769562,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2048,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769562)
        
        
        //--TRIMMABLE-BOUNDARY-START(524378)
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope", ($self) => class AsyncServiceScope extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295491674)
            /*IServiceScope*/  get _serviceScope() { return this.$getField(0, 4); }
            /*IServiceScope*/  set _serviceScope(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295491674)
            
            //--TRIMMABLE-BOUNDARY-START(12885426266)
            $ctor$3(/*IServiceScope*/ serviceScope)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceScope, "serviceScope");
                    this._serviceScope = serviceScope;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426266)
            
            //--TRIMMABLE-BOUNDARY-START(34360262746)
            /*IServiceProvider */ get ServiceProvider()
            {
                return this._serviceScope.Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262746)
            
            //--TRIMMABLE-BOUNDARY-START(17180393562)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceScope.System$IDisposable$Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(17180393562)
            
            //--TRIMMABLE-BOUNDARY-START(21475360858)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let ad;
                if ($.$is(this._serviceScope, $.$$.System.IAsyncDisposable, { set $v(v){ ad = v; } }))
                {
                    return ad.System$IAsyncDisposable$DisposeAsync();
                }
                this._serviceScope.System$IDisposable$Dispose();
                return new $.$$.System.Threading.Tasks.ValueTask();
            }
            //--TRIMMABLE-BOUNDARY-END(21475360858)
            
            //--TRIMMABLE-BOUNDARY-START(8590983258)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983258)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(4384686081)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384686081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384686081)
            
            //--TRIMMABLE-BOUNDARY-START(8590458970)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458970)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._serviceScope = this._serviceScope;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295491674)
                this._serviceScope = null;
                //--TRIMMABLE-BOUNDARY-END(4295491674)
                
            }
            static $h = 524378;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360262746),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295450,
        "f": 50331649
      },
      "n": "ServiceProvider",
      "d": 524378,
      "h": 34360262746,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360262746)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393562),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 524378,
      "h": 17180393562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393562),
//--TRIMMABLE-BOUNDARY-START(21475360858),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 524378,
      "h": 21475360858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360858)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491674),
    {
      "t": 1048666,
      "n": "_serviceScope",
      "d": 524378,
      "h": 4295491674,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426266),
    {
      "p": [
        {
          "n": "serviceScope",
          "p": 1048666
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524378,
      "h": 12885426266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426266),
//--TRIMMABLE-BOUNDARY-START(8590458970),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524378,
      "h": 8590458970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458970)
  ],
  "i": [1048666,90308609,89718785
  ],
  "h": 524378,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{ServiceProvider,nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope, $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.AsyncServiceScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524378)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441882)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory<>", (/*out*/ T) => $asm.$gt("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory<>", [/*out*/ T], ($self) => class ObjectFactory$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*T*/ Invoke(/**/ serviceProvider, /*$.$typeArray($.$$.System.Object)*/ $arguments)
            {
                return this.$nativeFunction.call(this.$target, serviceProvider, $arguments);
            }
            static $h = 1441882;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181311066),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "Invoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 17301633
    },
//--TRIMMABLE-BOUNDARY-END(17181311066),
//--TRIMMABLE-BOUNDARY-START(8591376474),
    {
      "r": 89784321,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591376474),
//--TRIMMABLE-BOUNDARY-START(12886343770),
    {
      "r": T?.$h??1507328,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 17301633
    },
//--TRIMMABLE-BOUNDARY-END(12886343770)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409178),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409178)
  ],
  "i": [89980929,157483009
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 32
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ObjectFactory<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1441882)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376346)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory", ($self) => class ObjectFactory extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*object*/ Invoke(/**/ serviceProvider, /*$.$typeArray($.$$.System.Object)*/ $arguments)
            {
                return this.$nativeFunction.call(this.$target, serviceProvider, $arguments);
            }
            static $h = 1376346;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245530),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "Invoke",
      "d": 1376346,
      "h": 17181245530,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181245530),
//--TRIMMABLE-BOUNDARY-START(8591310938),
    {
      "r": 89784321,
      "p": [
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1376346,
      "h": 8591310938,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591310938),
//--TRIMMABLE-BOUNDARY-START(12886278234),
    {
      "r": 131073,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 1376346,
      "h": 12886278234,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886278234)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343642),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1376346,
      "h": 4296343642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343642)
  ],
  "i": [89980929,157483009
  ],
  "h": 1376346
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ObjectFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376346)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835098)
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyLookupMode", ($self) => class ServiceKeyLookupMode extends $.$$.System.Enum
        {
            static InheritKey = 0;
            static NullKey = 1;
            static ExplicitKey = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "InheritKey": 0n,
                    "NullKey": 1n,
                    "ExplicitKey": 2n
                };
            }
            static $h = 1835098;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886736986),
    {
      "t": 1835098,
      "n": "InheritKey",
      "d": 1835098,
      "h": 12886736986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736986),
//--TRIMMABLE-BOUNDARY-START(17181704282),
    {
      "t": 1835098,
      "n": "NullKey",
      "d": 1835098,
      "h": 17181704282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704282),
//--TRIMMABLE-BOUNDARY-START(8591769690),
    {
      "t": 1835098,
      "n": "ExplicitKey",
      "d": 1835098,
      "h": 8591769690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769690)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802394),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835098,
      "h": 4296802394,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802394)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1835098
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceKeyLookupMode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835098)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900634)
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceLifetime", ($self) => class ServiceLifetime extends $.$$.System.Enum
        {
            static Singleton = 0;
            static Scoped = 1;
            static Transient = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Singleton": 0n,
                    "Scoped": 1n,
                    "Transient": 2n
                };
            }
            static $h = 1900634;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886802522),
    {
      "t": 1900634,
      "n": "Singleton",
      "d": 1900634,
      "h": 12886802522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886802522),
//--TRIMMABLE-BOUNDARY-START(8591835226),
    {
      "t": 1900634,
      "n": "Scoped",
      "d": 1900634,
      "h": 8591835226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591835226),
//--TRIMMABLE-BOUNDARY-START(17181769818),
    {
      "t": 1900634,
      "n": "Transient",
      "d": 1900634,
      "h": 17181769818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181769818)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867930),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900634,
      "h": 4296867930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867930)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1900634
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLifetime`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900634)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507418)
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection", ($self) => class ServiceCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474714)
            /*List<ServiceDescriptor>*/ _descriptors = null;
            //--TRIMMABLE-BOUNDARY-END(4296474714)
            
            //--TRIMMABLE-BOUNDARY-START(8591442010)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(8591442010)
            
            //--TRIMMABLE-BOUNDARY-START(38656213082)
            /*int */ get Count()
            {
                return this._descriptors.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(38656213082)
            
            //--TRIMMABLE-BOUNDARY-START(85900853338)
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(85900853338)
            
            //--TRIMMABLE-BOUNDARY-START(120260591706)
            /*ServiceDescriptor*/ get_Item$1(/*int*/ index)
            {
                return this._descriptors.get_Item(index);
            }
            /*void*/ set_Item$1(/*int*/ index, /*ServiceDescriptor*/ value)
            {
                this.CheckReadOnly();
                this._descriptors.set_Item(index, value);
            }
            //--TRIMMABLE-BOUNDARY-END(120260591706)
            
            //--TRIMMABLE-BOUNDARY-START(25771311194)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(25771311194)
            
            //--TRIMMABLE-BOUNDARY-START(30066278490)
            /*bool */ Contains(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.Contains(item);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278490)
            
            //--TRIMMABLE-BOUNDARY-START(34361245786)
            /*void */ CopyTo(/*ServiceDescriptor[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptors.CopyTo(array, arrayIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(34361245786)
            
            //--TRIMMABLE-BOUNDARY-START(94490787930)
            /*bool */ Remove(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                return this._descriptors.Remove(item);
            }
            //--TRIMMABLE-BOUNDARY-END(94490787930)
            
            //--TRIMMABLE-BOUNDARY-START(73015951450)
            /*IEnumerator<ServiceDescriptor> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(73015951450)
            
            //--TRIMMABLE-BOUNDARY-START(111670657114)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Add(item);
            }
            //--TRIMMABLE-BOUNDARY-END(111670657114)
            
            //--TRIMMABLE-BOUNDARY-START(115965624410)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(115965624410)
            
            //--TRIMMABLE-BOUNDARY-START(77310918746)
            /*int */ IndexOf(/*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptors.IndexOf$2(item);
            }
            //--TRIMMABLE-BOUNDARY-END(77310918746)
            
            //--TRIMMABLE-BOUNDARY-START(81605886042)
            /*void */ Insert(/*int*/ index, /*ServiceDescriptor*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605886042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.Insert(index, item);
            }
            //--TRIMMABLE-BOUNDARY-END(81605886042)
            
            //--TRIMMABLE-BOUNDARY-START(98785755226)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckReadOnly();
                this._descriptors.RemoveAt(index);
            }
            //--TRIMMABLE-BOUNDARY-END(98785755226)
            
            //--TRIMMABLE-BOUNDARY-START(90195820634)
            /*void */ MakeReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._isReadOnly = true;
            }
            //--TRIMMABLE-BOUNDARY-END(90195820634)
            
            //--TRIMMABLE-BOUNDARY-START(21476343898)
            /*void */ CheckReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._isReadOnly)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection.ThrowReadOnlyException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476343898)
            
            //--TRIMMABLE-BOUNDARY-START(124555559002)
            static /*void */ ThrowReadOnlyException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555559002);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdi.System.SR.ServiceCollectionReadOnly);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555559002)
            
            //--TRIMMABLE-BOUNDARY-START(42951180378)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText = `Count = ${this._descriptors.Count}`;
                if (this._isReadOnly)
                {
                    debugText += `, IsReadOnly = true`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(42951180378)
            
            //--TRIMMABLE-BOUNDARY-START(8649834497)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].get
            System$Collections$Generic$IList$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649834497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649834497)
            
            //--TRIMMABLE-BOUNDARY-START(30124670977)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].set
            System$Collections$Generic$IList$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30124670977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30124670977)
            
            //--TRIMMABLE-BOUNDARY-START(12944801793)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IndexOf(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$IList$$$IndexOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944801793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944801793)
            
            //--TRIMMABLE-BOUNDARY-START(17239769089)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Insert(int, Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$IList$$$Insert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239769089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Insert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239769089)
            
            //--TRIMMABLE-BOUNDARY-START(21534736385)
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.RemoveAt(int)
            System$Collections$Generic$IList$$$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534736385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21534736385)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(38714015745)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43008983041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714015745)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Contains(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.CopyTo(Microsoft.Extensions.DependencyInjection.ServiceDescriptor[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Remove(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            //--TRIMMABLE-BOUNDARY-START(17181376602)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376602)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474714)
                this._descriptors = new ($.$$.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296474714)
                
            }
            static $h = 1507418;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656213082),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114970,
        "f": 50331649
      },
      "n": "Count",
      "d": 1507418,
      "h": 38656213082,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656213082),
//--TRIMMABLE-BOUNDARY-START(85900853338),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131049562,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1507418,
      "h": 85900853338,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900853338),
//--TRIMMABLE-BOUNDARY-START(120260591706),
    {
      "p": 1704026,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720984154,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375689818,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1507418,
      "h": 120260591706,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260591706)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771311194),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1507418,
      "h": 25771311194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771311194),
//--TRIMMABLE-BOUNDARY-START(30066278490),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Contains",
      "d": 1507418,
      "h": 30066278490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066278490),
//--TRIMMABLE-BOUNDARY-START(34361245786),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1507418,
      "h": 34361245786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245786),
//--TRIMMABLE-BOUNDARY-START(94490787930),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Remove",
      "d": 1507418,
      "h": 94490787930,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490787930),
//--TRIMMABLE-BOUNDARY-START(73015951450),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,
      "n": "GetEnumerator",
      "d": 1507418,
      "h": 73015951450,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015951450),
//--TRIMMABLE-BOUNDARY-START(77310918746),
    {
      "r": 655361,
      "p": [
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "IndexOf",
      "d": 1507418,
      "h": 77310918746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310918746),
//--TRIMMABLE-BOUNDARY-START(81605886042),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "item",
          "p": 1704026
        }
      ],
      "n": "Insert",
      "d": 1507418,
      "h": 81605886042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605886042),
//--TRIMMABLE-BOUNDARY-START(98785755226),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1507418,
      "h": 98785755226,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98785755226),
//--TRIMMABLE-BOUNDARY-START(90195820634),
    {
      "r": 65537,
      "n": "MakeReadOnly",
      "d": 1507418,
      "h": 90195820634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195820634),
//--TRIMMABLE-BOUNDARY-START(21476343898),
    {
      "r": 65537,
      "n": "CheckReadOnly",
      "d": 1507418,
      "h": 21476343898,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476343898),
//--TRIMMABLE-BOUNDARY-START(124555559002),
    {
      "r": 65537,
      "n": "ThrowReadOnlyException",
      "d": 1507418,
      "h": 124555559002,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124555559002),
//--TRIMMABLE-BOUNDARY-START(42951180378),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 1507418,
      "h": 42951180378,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42951180378)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474714),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,
      "n": "_descriptors",
      "d": 1507418,
      "h": 4296474714,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474714),
//--TRIMMABLE-BOUNDARY-START(8591442010),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1507418,
      "h": 8591442010,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442010)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181376602),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507418,
      "h": 17181376602,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376602)
  ],
  "i": [786522,$.$$.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,62652417
  ],
  "h": 1507418,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection, $.$$.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507418)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.ComponentModel", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))
//--TRIMMABLE-BOUNDARY-END(90)
