
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $stee, $st, $stt, $sr, $scc, $scm, $so, $sris, $sic, $sim, $sl, $sci, $srm, $sre, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", 
    {"h":3,"f":"Microsoft.Extensions.DependencyInjection.Abstractions","v":"1.0.35.0","a":[{"t":78512129,"c":4373479425,"a":[{"v":131075,"t":142606337}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.DependencyInjection.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.DependencyInjection.Abstractions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.DependencyInjection.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<>", (TContainerBuilder) => $asm.$gt("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<>", [TContainerBuilder], ($self) => class IServiceProviderFactory$$
        {
            static $h = 851971;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":TContainerBuilder?.$h??1507328,"p":[{"n":"services","p":786435}],"n":"CreateBuilder","o":"Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":257},{"r":327717,"p":[{"n":"containerBuilder","p":TContainerBuilder?.$h??1507328}],"n":"CreateServiceProvider","o":"Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":257}],"g":[TContainerBuilder?.$h??1507328],"s":[{"n":"TContainerBuilder","f":64}],"r":1,"h":this.$h}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<${TContainerBuilder?.$fullName}>`; }
        }));
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService", ($self) => class IServiceProviderIsService
        {
            static $h = 983043;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"serviceType","p":142606337}],"n":"IsService","o":"Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService","d":983043,"h":4295950339,"f":257}],"h":983043}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderIsService`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ISupportRequiredService", ($self) => class ISupportRequiredService
        {
            static $h = 1179651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"serviceType","p":142606337}],"n":"GetRequiredService","o":"Microsoft$Extensions$DependencyInjection$ISupportRequiredService$GetRequiredService","d":1179651,"h":4296146947,"f":257}],"h":1179651}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ISupportRequiredService`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory", ($self) => class IServiceScopeFactory
        {
            static $h = 1114115;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1048579,"n":"CreateScope","o":"Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope","d":1114115,"h":4296081411,"f":257}],"h":1114115}; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceScopeFactory`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider", ($self) => class IKeyedServiceProvider
        {
            static $h = 720899;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedService","o":"Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService","d":720899,"h":4295688195,"f":257},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetRequiredKeyedService","o":"Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService","d":720899,"h":8590655491,"f":257}],"i":[327717],"h":720899}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService", ($self) => class IServiceProviderIsKeyedService
        {
            static $h = 917507;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262145,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"IsKeyedService","o":"Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService","d":917507,"h":4295884803,"f":257}],"i":[983043],"h":917507}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope", ($self) => class IServiceScope
        {
            static $h = 1048579;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":327717,"g":{"r":0,"d":0,"h":8590983171,"f":257},"n":"ServiceProvider","o":"Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider","d":1048579,"h":4296015875,"f":257}],"i":[57475073],"h":1048579}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceScope`; }
        });
        
        $asm.$typeProxy("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor");
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection", ($self) => class IServiceCollection
        {
            static $h = 786435;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"i":[$.$spc.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,31588353],"h":786435}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.IServiceCollection`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$spc.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$spc.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$spc.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$spc.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$spc.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$spc.System.Enum.ToObject(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            static $h = 2031619;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"defaultValue","p":131073,"f":2}],"n":"TryGetDefaultValue","d":2031619,"h":4296998915,"f":33},{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"tryToGetDefaultValue","p":262145,"f":2}],"n":"CheckHasDefaultValue","d":2031619,"h":8591966211,"f":33}],"h":2031619}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        
        $asm.$cls("$mxdi.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mxdi.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.DependencyInjection.Abstractions", $.$mxdi.System.SR.$type.Assembly);
                    $.$mxdi.System.SR.s_resourceManager = temp;
                }
                return $.$mxdi.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mxdi.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mxdi.System.SR.resourceCulture = value;
            }
            static /*string */ get AmbiguousConstructorMatch()
            {
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            static /*string */ FormatAmbiguousConstructorMatch(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            static /*string */ get CannotResolveService()
            {
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            static /*string */ FormatCannotResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            static /*string */ get NoConstructorMatch()
            {
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.";
            }
            static /*string */ FormatNoConstructorMatch(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.", arg1);
            }
            static /*string */ get NoServiceRegistered()
            {
                return "No service for type '{0}' has been registered.";
            }
            static /*string */ FormatNoServiceRegistered(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No service for type '{0}' has been registered.", arg1);
            }
            static /*string */ get ServiceCollectionReadOnly()
            {
                return "The service collection cannot be modified because it is read-only.";
            }
            static /*string */ get TryAddIndistinguishableTypeToEnumerable()
            {
                return "Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.";
            }
            static /*string */ FormatTryAddIndistinguishableTypeToEnumerable(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Implementation type cannot be '{0}' because it is indistinguishable from other services registered for '{1}'.", arg1, arg2);
            }
            static /*string */ get MultipleCtorsMarkedWithAttribute()
            {
                return "Multiple constructors were marked with {0}.";
            }
            static /*string */ FormatMultipleCtorsMarkedWithAttribute(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Multiple constructors were marked with {0}.", arg1);
            }
            static /*string */ get MarkedCtorMissingArgumentTypes()
            {
                return "Constructor marked with {0} does not accept all given argument types.";
            }
            static /*string */ FormatMarkedCtorMissingArgumentTypes(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Constructor marked with {0} does not accept all given argument types.", arg1);
            }
            static /*string */ get CannotCreateAbstractClasses()
            {
                return "Instances of abstract classes cannot be created.";
            }
            static /*string */ get MultipleCtorsFoundWithBestLength()
            {
                return "Multiple constructors for type '{0}' were found with length {1}.";
            }
            static /*string */ FormatMultipleCtorsFoundWithBestLength(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Multiple constructors for type '{0}' were found with length {1}.", arg1, arg2);
            }
            static /*string */ get UnableToResolveService()
            {
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            static /*string */ FormatUnableToResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            static /*string */ get CtorNotLocated()
            {
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.";
            }
            static /*string */ FormatCtorNotLocated(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and all parameters of a public constructor are either registered as services or passed as arguments. Also ensure no extraneous arguments are provided.", arg1);
            }
            static /*string */ get MultipleCtorsFound()
            {
                return "Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.";
            }
            static /*string */ FormatMultipleCtorsFound(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Multiple constructors accepting all given argument types have been found in type '{0}'. There should only be one applicable constructor.", arg1);
            }
            static /*string */ get KeyedServicesNotSupported()
            {
                return "This service provider doesn't support keyed services.";
            }
            static /*string */ get NonKeyedDescriptorMisuse()
            {
                return "This service descriptor is not keyed.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mxdi.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mxdi.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mxdi.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mxdi.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mxdi.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mxdi.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mxdi.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2097155;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2097155}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities", ($self) => class ActivatorUtilities
        {
            /*ConcurrentDictionary<Type, ConstructorInfoEx[]>*/ static s_constructorInfos = null;
            /*Lazy<ConditionalWeakTable<Type, ConstructorInfoEx[]>>*/ static s_collectibleConstructorInfos = null;
            /*int*/ static FixedArgumentThreshold = 4;
            /*MethodInfo*/ static GetServiceInfo = null;
            static /*object */ CreateInstance(/*IServiceProvider*/ provider, /*Type*/ instanceType, /*params object[]*/ parameters)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                if (instanceType.IsAbstract$1)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.CannotCreateAbstractClasses);
                }
                /*ConstructorInfoEx[]?*/ let constructors;
                if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                {
                    constructors = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetOrAddConstructors(instanceType);
                }
                /*StackAllocatedObjects*/ let stackValues = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects();
                /*int*/ let maxArgs = GetMaxArgCount.call(this);
                /*Span<object?>*/ let values = maxArgs <= $.trunc(8/*StackAllocatedObjects.MaxStackAllocArgCount*/ / 2) ? $.$spc.System.Span$$($.$spc.System.Object).op_Implicit(stackValues.$fields) : $.$spc.System.Span$$($.$spc.System.Object).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((maxArgs * 2) | 0)], null));
                /*Span<object?>*/ let ctorArgs = values.Slice$1(0, maxArgs);
                /*Span<object?>*/ let bestCtorArgs = values.Slice$1(maxArgs, maxArgs);
                /*scoped ConstructorMatcher*/ let matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher();
                /*ConstructorInfoEx?*/ let $constructor;
                /*IServiceProviderIsService?*/ let serviceProviderIsService = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetService($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService, provider);
                if (serviceProviderIsService !== null)
                {
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$spc.System.Array.$ReadT1.call(constructors, i);
                        if ($constructor.IsPreferred)
                        {
                            for(/*int*/ let j = ((i + 1) | 0); j < constructors.length; j++)
                            {
                                if ($.$spc.System.Array.$ReadT1.call(constructors, j).IsPreferred)
                                {
                                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                                }
                            }
                            InitializeCtorArgValues($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                            matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$2($constructor, ctorArgs);
                            if (matcher.Match(parameters, serviceProviderIsService) === -1)
                            {
                                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                            }
                            return matcher.CreateInstance(provider);
                        }
                    }
                    /*int*/ let bestLength = -1;
                    /*scoped ConstructorMatcher*/ let bestMatcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher();
                    /*bool*/ let multipleBestLengthFound = false;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        $constructor = $.$spc.System.Array.$ReadT1.call(constructors, i);
                        InitializeCtorArgValues($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                        matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$2($constructor, ctorArgs);
                        /*int*/ let length = matcher.Match(parameters, serviceProviderIsService);
                        $.$spc.System.Diagnostics.Debug.Assert$1(!$constructor.IsPreferred, "!constructor.IsPreferred");
                        if (bestLength < length)
                        {
                            bestLength = length;
                            ctorArgs.CopyTo(bestCtorArgs);
                            bestMatcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$2(matcher.ConstructorInfo, bestCtorArgs);
                            multipleBestLengthFound = false;
                        }
                        else if (bestLength === length)
                        {
                            multipleBestLengthFound = true;
                        }
                    }
                    if (bestLength !== -1)
                    {
                        if (multipleBestLengthFound)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format$1($.$mxdi.System.SR.MultipleCtorsFoundWithBestLength, instanceType, $.$box(bestLength, $.$spc.System.Int32)));
                        }
                        return bestMatcher.CreateInstance(provider);
                    }
                }
                /*Type?[]*/ let argumentTypes;
                if (parameters.length === 0)
                {
                    argumentTypes = $.$spc.System.Type.EmptyTypes;
                }
                else 
                {
                    argumentTypes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), null, [parameters.length], null);
                    for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                    {
                        const $t2 = () => $.$spc.System.Array.$ReadT1.call(parameters, i);
                        $.$spc.System.Array.$WriteT1.call(argumentTypes, $.$ifnn($t2, ($t) => $.$spc.System.Object.GetType.call($t)), i);
                    }
                }
                /*ConstructorInfo*/ let constructorInfo;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$spc.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32))));
                $constructor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindConstructorEx(constructorInfo, constructors);
                InitializeCtorArgValues($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Span$$($.$spc.System.Object), () => ctorArgs, ($v) => ctorArgs = $v, null), $constructor.Parameters.length);
                matcher = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher().$ctor$2($constructor, ctorArgs);
                matcher.MapParameters(parameterMap, parameters);
                return matcher.CreateInstance(provider);
                /*int*/  function GetMaxArgCount()
                {
                    /*int*/ let max = 0;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        max = $.$spc.System.Int32.Max(max, $.$spc.System.Array.$ReadT1.call(constructors, i).Parameters.length);
                    }
                    return max;
                }
                /*static void*/  function InitializeCtorArgValues(/*ref Span<object?>*/ ctorArgs, /*int*/ _)
                {
                    ctorArgs.$v.Clear();
                }
            }
            static /*ConstructorInfoEx[] */ GetOrAddConstructors(/*Type*/ type)
            {
                if (!type.Assembly.IsCollectible)
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.GetOrAdd$2(type, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateConstructorInfoExs(type));
                }
                /*ConstructorInfoEx[]?*/ let value;
                if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.TryGetValue(type, $.$ref(() => value, ($v) => value = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                {
                    return value;
                }
                value = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateConstructorInfoExs(type);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.AddOrUpdate(type, value);
                return value;
            }
            static /*ConstructorInfoEx[] */ CreateConstructorInfoExs(/*Type*/ type)
            {
                /*ConstructorInfo[]*/ let constructors = type.GetConstructors();
                /*ConstructorInfoEx[]?*/ let value = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx), null, [constructors.length], null);
                for(/*int*/ let i = 0; i < constructors.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(value, new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx().$ctor$1($.$spc.System.Array.$ReadT1.call(constructors, i)), i);
                }
                return value;
            }
            static /*ObjectFactory */ CreateFactory(/*Type*/ instanceType, /*Type[]*/ argumentTypes)
            {
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryReflection(instanceType, argumentTypes);
                }
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryInternal(instanceType, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.System.Linq.Expressions.Expression));
                /*var*/ let factoryLambda = $.$sle.System.Linq.Expressions.Expression.Lambda($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory, factoryExpressionBody, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            static /*ObjectFactory<T> */ CreateFactory$1(T, /*Type[]*/ argumentTypes)
            {
                //if (!RuntimeFeature.IsDynamicCodeCompiled)
                {
                    /*var*/ let factory = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryReflection(T.$type, argumentTypes);
                    return new ($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T))().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$cast(factory.Invoke(serviceProvider, $arguments), T);
                    });
                }
                /*ParameterExpression*/ let provider;
                /*ParameterExpression*/ let argumentArray;
                /*Expression*/ let factoryExpressionBody;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateFactoryInternal(T.$type, argumentTypes, $.$ref(() => provider, ($v) => provider = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => argumentArray, ($v) => argumentArray = $v, $.$sle.System.Linq.Expressions.ParameterExpression), $.$ref(() => factoryExpressionBody, ($v) => factoryExpressionBody = $v, $.$sle.System.Linq.Expressions.Expression));
                /*var*/ let factoryLambda = $.$sle.System.Linq.Expressions.Expression.Lambda($.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T), factoryExpressionBody, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ provider, argumentArray ], null, null));
                /*ObjectFactory<T>?*/ let result = factoryLambda.Compile$3();
                return result;
            }
            static /*void */ CreateFactoryInternal(/*Type*/ instanceType, /*Type[]*/ argumentTypes, /*out ParameterExpression*/ provider, /*out ParameterExpression*/ argumentArray, /*out Expression*/ factoryExpressionBody)
            {
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$spc.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32))));
                provider.$v = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$scm.System.IServiceProvider.$type, "provider");
                argumentArray.$v = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$typeArray($.$spc.System.Object).$type, "argumentArray");
                factoryExpressionBody.$v = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.BuildFactoryExpression($constructor, parameterMap, provider.$v, argumentArray.$v);
            }
            static /*T */ CreateInstance$1(T, /*IServiceProvider*/ provider, /*params object[]*/ parameters)
            {
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateInstance(provider, T.$type, parameters), T);
            }
            static /*T */ GetServiceOrCreateInstance(T, /*IServiceProvider*/ provider)
            {
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetServiceOrCreateInstance$1(provider, T.$type), T);
            }
            static /*object */ GetServiceOrCreateInstance$1(/*IServiceProvider*/ provider, /*Type*/ type)
            {
                return provider.System$IServiceProvider$GetService(type) ?? $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.CreateInstance(provider, type, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [  ], null, null));
            }
            static /*object? */ GetService(/*IServiceProvider*/ sp, /*Type*/ type, /*Type*/ requiredBy, /*bool*/ hasDefaultValue, /*object?*/ key)
            {
                /*object?*/ let service = key === null ? sp.System$IServiceProvider$GetService(type) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetKeyedService(sp, type, key);
                if (service === null && !hasDefaultValue)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowHelperUnableToResolveService(type, requiredBy);
                }
                return service;
            }
            static /*void */ ThrowHelperUnableToResolveService(/*Type*/ type, /*Type*/ requiredBy)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format$1($.$mxdi.System.SR.UnableToResolveService, type, requiredBy));
            }
            static /*BlockExpression */ BuildFactoryExpression(/*ConstructorInfo*/ $constructor, /*int?[]*/ parameterMap, /*Expression*/ serviceProvider, /*Expression*/ factoryArgumentArray)
            {
                /*ParameterInfo[]?*/ let constructorParameters = $constructor.GetParameters();
                /*var*/ let constructorArguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    /*ParameterInfo?*/ let constructorParameter = $.$spc.System.Array.$ReadT1.call(constructorParameters, i);
                    /*Type?*/ let parameterType = constructorParameter.ParameterType;
                    /*object?*/ let defaultValue;
                    /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$spc.System.Object));
                    if ($.$spc.System.Array.$ReadT1.call(parameterMap, i) !== null)
                    {
                        $.$spc.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.ArrayAccess(factoryArgumentArray, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.Constant($.$box($.$spc.System.Array.$ReadT1.call(parameterMap, i), $.$spc.System.Nullable$$($.$spc.System.Int32))) ], null, null)), i);
                    }
                    else 
                    {
                        /*var*/ let keyAttribute = $.$cast($.$spc.System.Attribute.GetCustomAttribute$7(constructorParameter, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                        /*var*/ let parameterTypeExpression = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [serviceProvider, $.$sle.System.Linq.Expressions.Expression.Constant$1(parameterType, $.$spc.System.Type.$type), $.$sle.System.Linq.Expressions.Expression.Constant$1($constructor.DeclaringType, $.$spc.System.Type.$type), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(hasDefaultValue, $.$spc.System.Boolean)), $.$sle.System.Linq.Expressions.Expression.Constant$1((keyAttribute?.Key ?? null), $.$spc.System.Object.$type)], [-1], null);
                        $.$spc.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Call$6($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetServiceInfo, parameterTypeExpression), i);
                    }
                    if (hasDefaultValue)
                    {
                        /*ConstantExpression?*/ let defaultValueExpression = $.$sle.System.Linq.Expressions.Expression.Constant(defaultValue);
                        $.$spc.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Coalesce($.$spc.System.Array.$ReadT1.call(constructorArguments, i), defaultValueExpression), i);
                    }
                    $.$spc.System.Array.$WriteT1.call(constructorArguments, $.$sle.System.Linq.Expressions.Expression.Convert($.$spc.System.Array.$ReadT1.call(constructorArguments, i), parameterType), i);
                }
                return $.$sle.System.Linq.Expressions.Expression.Block($.$sle.System.Linq.Expressions.Expression.IfThen($.$sle.System.Linq.Expressions.Expression.Equal(serviceProvider, $.$sle.System.Linq.Expressions.Expression.Constant(null)), $.$sle.System.Linq.Expressions.Expression.Throw($.$sle.System.Linq.Expressions.Expression.Constant(new $.$spc.System.ArgumentNullException().$ctor$16("serviceProvider")))), $.$sle.System.Linq.Expressions.Expression.New$1($constructor, constructorArguments));
            }
            static /*ObjectFactory */ CreateFactoryReflection(/*Type*/ instanceType, /*Type?[]*/ argumentTypes)
            {
                /*ConstructorInfo*/ let $constructor;
                /*int?[]*/ let parameterMap;
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FindApplicableConstructor(instanceType, argumentTypes, null, $.$ref(() => $constructor, ($v) => $constructor = $v, $.$spc.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32))));
                /*Type*/ let declaringType = $constructor.DeclaringType;
                /*ConstructorInvoker*/ let invoker = $.$spc.System.Reflection.ConstructorInvoker.Create($constructor);
                /*ParameterInfo[]*/ let constructorParameters = $constructor.GetParameters();
                if (constructorParameters.length === 0)
                {
                    return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments) =>
                    {
                        return invoker.Invoke();
                    });
                }
                /*bool*/ let useFixedValues = constructorParameters.length <= 4/*FixedArgumentThreshold*/;
                /*bool*/ let hasAnyDefaultValues = false;
                /*int*/ let matchedArgCount = 0;
                /*int*/ let matchedArgCountWithMap = 0;
                for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                {
                    hasAnyDefaultValues = $.$spc.System.Boolean.op_BitwiseOr(hasAnyDefaultValues, $.$spc.System.Array.$ReadT1.call(constructorParameters, i).HasDefaultValue);
                    if (!($.$spc.System.Array.$ReadT1.call(parameterMap, i) === null))
                    {
                        matchedArgCount++;
                        if ($.$spc.System.Array.$ReadT1.call(parameterMap, i) === i)
                        {
                            matchedArgCountWithMap++;
                        }
                    }
                }
                if (hasAnyDefaultValues || matchedArgCount !== matchedArgCountWithMap)
                {
                    return InvokeCanonical.call(this);
                }
                if (matchedArgCount === 0)
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryServiceOnlyFixed(invoker, parameters, declaringType, serviceProvider);
                    }) : new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryServiceOnlySpan(invoker, parameters, declaringType, serviceProvider);
                    });
                }
                if (matchedArgCount === constructorParameters.length)
                {
                    return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryDirect(invoker, serviceProvider, $arguments);
                    });
                }
                return InvokeCanonical.call(this);
                /*ObjectFactory*/  function InvokeCanonical()
                {
                    /*FactoryParameterContext[]*/ let parameters = GetFactoryParameterContext.call(this);
                    return useFixedValues ? new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryCanonicalFixed(invoker, parameters, declaringType, serviceProvider, $arguments);
                    }) : new $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory().$ctor(this,  (/*serviceProvider*/ serviceProvider, /*arguments*/ $arguments) =>
                    {
                        return $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ReflectionFactoryCanonicalSpan(invoker, parameters, declaringType, serviceProvider, $arguments);
                    });
                }
                /*FactoryParameterContext[]*/  function GetFactoryParameterContext()
                {
                    /*FactoryParameterContext[]*/ let parameters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext), null, [constructorParameters.length], null);
                    for(/*int*/ let i = 0; i < constructorParameters.length; i++)
                    {
                        /*ParameterInfo*/ let constructorParameter = $.$spc.System.Array.$ReadT1.call(constructorParameters, i);
                        /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$spc.System.Attribute.GetCustomAttribute$7(constructorParameter, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                        /*object?*/ let defaultValue;
                        /*bool*/ let hasDefaultValue = $.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue(constructorParameter, $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$spc.System.Object));
                        $.$spc.System.Array.$WriteT1.call(parameters, new $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext().$ctor$2(constructorParameter.ParameterType, hasDefaultValue, defaultValue, $.$spc.System.Array.$ReadT1.call(parameterMap, i) ?? -1, (attr?.Key ?? null)), i);
                    }
                    return parameters;
                }
            }
            static $_FactoryParameterContext;
            static get FactoryParameterContext()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_FactoryParameterContext ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext", ($self) => class FactoryParameterContext extends $.$spc.System.ValueType
                {
                    $ctor$2(/*Type*/ parameterType, /*bool*/ hasDefaultValue, /*object?*/ defaultValue, /*int*/ argumentIndex, /*object?*/ serviceKey)
                    {
                        super.$ctor$1();
                        {
                            this.ParameterType = parameterType;
                            this.HasDefaultValue = hasDefaultValue;
                            this.DefaultValue = defaultValue;
                            this.ArgumentIndex = argumentIndex;
                            this.ServiceKey = serviceKey;
                        }
                        return this;
                    }
                    /*Type*/ ParameterType = null;
                    /*bool*/ HasDefaultValue = false;
                    /*object?*/ DefaultValue = null;
                    /*int*/ ArgumentIndex = 0;
                    /*object?*/ ServiceKey = null;
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.ParameterType = this.ParameterType;
                        copy.HasDefaultValue = this.HasDefaultValue;
                        copy.DefaultValue = this.DefaultValue;
                        copy.ArgumentIndex = this.ArgumentIndex;
                        copy.ServiceKey = this.ServiceKey;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.HasDefaultValue = false;
                    }
                    static $h = 327683;
                    static $z = 17;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17180196867,"f":1},"n":"ParameterType","d":327683,"h":12885229571,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065098755,"f":1},"n":"HasDefaultValue","d":327683,"h":25770131459,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":42950000643,"f":1},"n":"DefaultValue","d":327683,"h":38655033347,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834902531,"f":1},"n":"ArgumentIndex","d":327683,"h":51539935235,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":68719804419,"f":1},"n":"ServiceKey","d":327683,"h":64424837123,"f":1}],"c":[{"p":[{"n":"parameterType","p":142606337},{"n":"hasDefaultValue","p":262145},{"n":"defaultValue","p":131073},{"n":"argumentIndex","p":655361},{"n":"serviceKey","p":131073}],"n":".ctor","o":"$ctor$2","d":327683,"h":4295294979,"f":1},{"n":".ctor","o":"$ctor$3","d":327683,"h":73014771715,"f":1}],"d":65539,"h":327683}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext`; }
                }, $cls, ($v) => $cls.$_FactoryParameterContext = $v);
            }
            static /*void */ FindApplicableConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo*/ matchingConstructor, /*out int?[]*/ matchingParameterMap)
            {
                /*ConstructorInfo?*/ let constructorInfo;
                /*int?[]?*/ let parameterMap;
                if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryFindPreferredConstructor(instanceType, argumentTypes, constructors, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$spc.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32)))) && !$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryFindMatchingConstructor(instanceType, argumentTypes, $.$ref(() => constructorInfo, ($v) => constructorInfo = $v, $.$spc.System.Reflection.ConstructorInfo), $.$ref(() => parameterMap, ($v) => parameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32)))))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format($.$mxdi.System.SR.CtorNotLocated, instanceType));
                }
                matchingConstructor.$v = constructorInfo;
                matchingParameterMap.$v = parameterMap;
            }
            static /*ConstructorInfoEx */ FindConstructorEx(/*ConstructorInfo*/ constructorInfo, /*ConstructorInfoEx[]*/ constructorExs)
            {
                for(/*int*/ let i = 0; i < constructorExs.length; i++)
                {
                    if ($.$spc.System.Object.ReferenceEquals($.$spc.System.Array.$ReadT1.call(constructorExs, i).Info, constructorInfo))
                    {
                        return $.$spc.System.Array.$ReadT1.call(constructorExs, i);
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(false, "false");
                return null;
            }
            static /*bool */ TryFindMatchingConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                let $i1 = 0;
                let $arr1 = instanceType.GetConstructors();
                while ($i1 < $arr1.length)
                {
                    let $constructor = $arr1[$i1++];
                    /*int?[]*/ let tempParameterMap;
                    if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryCreateParameterMap($constructor.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32)))))
                    {
                        if ($.$spc.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format($.$mxdi.System.SR.MultipleCtorsFound, instanceType));
                        }
                        matchingConstructor.$v = $constructor;
                        parameterMap.$v = tempParameterMap;
                    }
                }
                if ($.$spc.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            static /*bool */ TryFindPreferredConstructor(/*Type*/ instanceType, /*Type?[]*/ argumentTypes, /*ConstructorInfoEx[]?*/ constructors, /*out ConstructorInfo?*/ matchingConstructor, /*out int?[]?*/ parameterMap)
            {
                /*bool*/ let seenPreferred = false;
                matchingConstructor.$v = null;
                parameterMap.$v = null;
                if (constructors === null)
                {
                    if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.TryGetValue(instanceType, $.$ref(() => constructors, ($v) => constructors = $v, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))
                    {
                        constructors = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetOrAddConstructors(instanceType);
                    }
                }
                let $i1 = 0;
                let $arr1 = constructors;
                while ($i1 < $arr1.length)
                {
                    let $constructor = $arr1[$i1++];
                    if ($constructor.IsPreferred)
                    {
                        if (seenPreferred)
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMultipleCtorsMarkedWithAttributeException();
                        }
                        /*int?[]*/ let tempParameterMap;
                        if (!$.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.TryCreateParameterMap($constructor.Info.GetParameters(), argumentTypes, $.$ref(() => tempParameterMap, ($v) => tempParameterMap = $v, $.$typeArray($.$typeNullable($.$spc.System.Int32)))))
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowMarkedCtorDoesNotTakeAllProvidedArguments();
                        }
                        matchingConstructor.$v = $constructor.Info;
                        parameterMap.$v = tempParameterMap;
                        seenPreferred = true;
                    }
                }
                if ($.$spc.System.Reflection.ConstructorInfo.op_Inequality$2(matchingConstructor.$v, null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(parameterMap.$v !== null, "parameterMap != null");
                    return true;
                }
                return false;
            }
            static /*bool */ TryCreateParameterMap(/*ParameterInfo[]*/ constructorParameters, /*Type?[]*/ argumentTypes, /*out int?[]*/ parameterMap)
            {
                parameterMap.$v = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeNullable($.$spc.System.Int32)), null, [constructorParameters.length], null);
                for(/*int*/ let i = 0; i < argumentTypes.length; i++)
                {
                    /*bool*/ let foundMatch = false;
                    /*Type?*/ let givenParameter = $.$spc.System.Array.$ReadT1.call(argumentTypes, i);
                    for(/*int*/ let j = 0; j < constructorParameters.length; j++)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(parameterMap.$v, j) !== null)
                        {
                            continue;
                        }
                        if ($.$spc.System.Array.$ReadT1.call(constructorParameters, j).ParameterType.IsAssignableFrom(givenParameter))
                        {
                            foundMatch = true;
                            $.$spc.System.Array.$WriteT1.call(parameterMap.$v, i, j);
                            break;
                        }
                    }
                    if (!foundMatch)
                    {
                        return false;
                    }
                }
                return true;
            }
            static $_ConstructorInfoEx;
            static get ConstructorInfoEx()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ConstructorInfoEx ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx", ($self) => class ConstructorInfoEx extends $.$spc.System.Object
                {
                    /*ConstructorInfo*/ Info = null;
                    /*ParameterInfo[]*/ Parameters = null;
                    /*bool*/ IsPreferred = false;
                    /*object?[]?*/ _parameterKeys = null;
                    /*ConstructorInvoker?*/ _invoker = null;
                    /*ConstructorInvoker */ get Invoker()
                    {
                        this._invoker ??= $.$spc.System.Reflection.ConstructorInvoker.Create(this.Info);
                        return this._invoker;
                    }
                    $ctor$1(/*ConstructorInfo*/ $constructor)
                    {
                        super.$ctor();
                        {
                            this.Info = $constructor;
                            this.Parameters = $constructor.GetParameters();
                            this.IsPreferred = $constructor.IsDefined($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute.$type, false);
                            for(/*int*/ let i = 0; i < this.Parameters.length; i++)
                            {
                                /*FromKeyedServicesAttribute?*/ let attr = $.$cast($.$spc.System.Attribute.GetCustomAttribute$7($.$spc.System.Array.$ReadT1.call(this.Parameters, i), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute.$type, false), $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute);
                                if (!(attr === null))
                                {
                                    this._parameterKeys ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this.Parameters.length], null);
                                    $.$spc.System.Array.$WriteT1.call(this._parameterKeys, attr.Key, i);
                                }
                            }
                        }
                        return this;
                    }
                    /*bool */ IsService(/*IServiceProviderIsService*/ serviceProviderIsService, /*int*/ parameterIndex)
                    {
                        /*ParameterInfo*/ let parameterInfo = $.$spc.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t1 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t1, ($t) => $.$spc.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let serviceProviderIsKeyedService;
                            if ($.$is(serviceProviderIsService, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService, { set $v(v){ serviceProviderIsKeyedService = v; } }))
                            {
                                return serviceProviderIsKeyedService.Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
                        }
                        return serviceProviderIsService.Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService(parameterInfo.ParameterType);
                    }
                    /*object? */ GetService(/*IServiceProvider*/ serviceProvider, /*int*/ parameterIndex)
                    {
                        /*ParameterInfo*/ let parameterInfo = $.$spc.System.Array.$ReadT1.call(this.Parameters, parameterIndex);
                        const $t1 = this._parameterKeys;
                        /*object?*/ let key = $.$ifnn($t1, ($t) => $.$spc.System.Array.$ReadT1.call($t, parameterIndex));
                        if (!(key === null))
                        {
                            let keyedServiceProvider;
                            if ($.$is(serviceProvider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                            {
                                return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(parameterInfo.ParameterType, key);
                            }
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
                        }
                        return serviceProvider.System$IServiceProvider$GetService(parameterInfo.ParameterType);
                    }
                    static $h = 196611;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":75694081,"g":{"r":0,"d":0,"h":30064967683,"f":1},"n":"Invoker","d":196611,"h":25770000387,"f":1}],"m":[{"r":262145,"p":[{"n":"serviceProviderIsService","p":983043},{"n":"parameterIndex","p":655361}],"n":"IsService","d":196611,"h":38654902275,"f":1},{"r":131073,"p":[{"n":"serviceProvider","p":327717},{"n":"parameterIndex","p":655361}],"n":"GetService","d":196611,"h":42949869571,"f":1}],"l":[{"t":75628545,"n":"Info","d":196611,"h":4295163907,"f":1},{"t":0,"n":"Parameters","d":196611,"h":8590131203,"f":1},{"t":262145,"n":"IsPreferred","d":196611,"h":12885098499,"f":1},{"t":0,"n":"_parameterKeys","d":196611,"h":17180065795,"f":2},{"t":75694081,"n":"_invoker","d":196611,"h":21475033091,"f":1}],"c":[{"p":[{"n":"constructor","p":75628545}],"n":".ctor","o":"$ctor$1","d":196611,"h":34359934979,"f":1}],"d":65539,"h":196611}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx`; }
                }, $cls, ($v) => $cls.$_ConstructorInfoEx = $v);
            }
            static $_ConstructorMatcher;
            static get ConstructorMatcher()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ConstructorMatcher ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher", ($self) => class ConstructorMatcher extends $.$spc.System.ValueType
                {
                    /*ConstructorInfoEx*/  get _constructor() { return this.$getField(0, 4); }
                    /*ConstructorInfoEx*/  set _constructor(value) { this.$setField(0, 4, value); }
                    /*Span<object?>*/  get _parameterValues() { return this.$getField(4, 8); }
                    /*Span<object?>*/  set _parameterValues(value) { this.$setField(4, 8, value); }
                    $ctor$2(/*ConstructorInfoEx*/ $constructor, /*Span<object?>*/ parameterValues)
                    {
                        super.$ctor$1();
                        {
                            this._constructor = $constructor;
                            this._parameterValues = parameterValues;
                        }
                        return this;
                    }
                    /*ConstructorInfoEx */ get ConstructorInfo()
                    {
                        return this._constructor;
                    }
                    /*int */ Match(/*object[]*/ givenParameters, /*IServiceProviderIsService*/ serviceProviderIsService)
                    {
                        for(/*int*/ let givenIndex = 0; givenIndex < givenParameters.length; givenIndex++)
                        {
                            const $t1 = () => $.$spc.System.Array.$ReadT1.call(givenParameters, givenIndex);
                            /*Type?*/ let givenType = $.$ifnn($t1, ($t) => $.$spc.System.Object.GetType.call($t));
                            /*bool*/ let givenMatched = false;
                            for(/*int*/ let applyIndex = 0; applyIndex < this._constructor.Parameters.length; applyIndex++)
                            {
                                if (this._parameterValues.get_Item(applyIndex).$v === null && $.$spc.System.Array.$ReadT1.call(this._constructor.Parameters, applyIndex).ParameterType.IsAssignableFrom(givenType))
                                {
                                    givenMatched = true;
                                    this._parameterValues.get_Item(applyIndex).$v = $.$spc.System.Array.$ReadT1.call(givenParameters, givenIndex);
                                    break;
                                }
                            }
                            if (!givenMatched)
                            {
                                return -1;
                            }
                        }
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if (this._parameterValues.get_Item(i).$v === null && !this._constructor.IsService(serviceProviderIsService, i))
                            {
                                /*object?*/ let defaultValue;
                                if ($.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$spc.System.Array.$ReadT1.call(this._constructor.Parameters, i), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$spc.System.Object)))
                                {
                                    this._parameterValues.get_Item(i).$v = defaultValue;
                                }
                                else 
                                {
                                    return -1;
                                }
                            }
                        }
                        return this._constructor.Parameters.length;
                    }
                    /*object */ CreateInstance(/*IServiceProvider*/ provider)
                    {
                        for(/*int*/ let index = 0; index < this._constructor.Parameters.length; index++)
                        {
                            if (this._parameterValues.get_Item(index).$v === null)
                            {
                                /*object?*/ let value = this._constructor.GetService(provider, index);
                                if (value === null)
                                {
                                    /*object?*/ let defaultValue;
                                    if (!$.$mxdi.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$spc.System.Array.$ReadT1.call(this._constructor.Parameters, index), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$spc.System.Object)))
                                    {
                                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format$1($.$mxdi.System.SR.UnableToResolveService, $.$spc.System.Array.$ReadT1.call(this._constructor.Parameters, index).ParameterType, this._constructor.Info.DeclaringType));
                                    }
                                    else 
                                    {
                                        this._parameterValues.get_Item(index).$v = defaultValue;
                                    }
                                }
                                else 
                                {
                                    this._parameterValues.get_Item(index).$v = value;
                                }
                            }
                        }
                        return this._constructor.Invoker.Invoke$5(this._parameterValues.Slice$1(0, this._constructor.Parameters.length));
                    }
                    /*void */ MapParameters(/*int?[]*/ parameterMap, /*object[]*/ givenParameters)
                    {
                        for(/*int*/ let i = 0; i < this._constructor.Parameters.length; i++)
                        {
                            if ($.$spc.System.Array.$ReadT1.call(parameterMap, i) !== null)
                            {
                                this._parameterValues.get_Item(i).$v = $.$spc.System.Array.$ReadT1.call(givenParameters, $.$cast($.$spc.System.Array.$ReadT1.call(parameterMap, i), $.$spc.System.Int32));
                            }
                        }
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._constructor = this._constructor;
                        copy._parameterValues = this._parameterValues.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._constructor = null;
                        this._parameterValues = $.$default($.$spc.System.Span$$($.$spc.System.Object));
                    }
                    static $h = 262147;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":196611,"g":{"r":0,"d":0,"h":21475098627,"f":1},"n":"ConstructorInfo","d":262147,"h":17180131331,"f":1}],"m":[{"r":655361,"p":[{"n":"givenParameters","p":0},{"n":"serviceProviderIsService","p":983043}],"n":"Match","d":262147,"h":25770065923,"f":1},{"r":131073,"p":[{"n":"provider","p":327717}],"n":"CreateInstance","d":262147,"h":30065033219,"f":1},{"r":65537,"p":[{"n":"parameterMap","p":0},{"n":"givenParameters","p":0}],"n":"MapParameters","d":262147,"h":34360000515,"f":1}],"l":[{"t":196611,"n":"_constructor","d":262147,"h":4295229443,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Object).$h,"n":"_parameterValues","d":262147,"h":8590196739,"f":2}],"c":[{"p":[{"n":"constructor","p":196611},{"n":"parameterValues","p":$.$spc.System.Span$$($.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":262147,"h":12885164035,"f":1},{"n":".ctor","o":"$ctor$3","d":262147,"h":38654967811,"f":1}],"d":65539,"h":262147}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorMatcher`; }
                }, $cls, ($v) => $cls.$_ConstructorMatcher = $v);
            }
            static /*void */ ThrowMultipleCtorsMarkedWithAttributeException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format($.$mxdi.System.SR.MultipleCtorsMarkedWithAttribute, "ActivatorUtilitiesConstructorAttribute"));
            }
            static /*void */ ThrowMarkedCtorDoesNotTakeAllProvidedArguments()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format($.$mxdi.System.SR.MarkedCtorMissingArgumentTypes, "ActivatorUtilitiesConstructorAttribute"));
            }
            static /*object */ ReflectionFactoryServiceOnlyFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$spc.System.Diagnostics.Debug.Assert$1(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                let $switch1 = parameters.length;
                switch($switch1)
                {
                    case 1:
                    return invoker.Invoke$1($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 0).ServiceKey));
                    case 2:
                    return invoker.Invoke$2($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 1).ServiceKey));
                    case 3:
                    return invoker.Invoke$3($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 2).ServiceKey));
                    case 4:
                    return invoker.Invoke$4($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 0).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 0).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 1).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 1).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 2).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 2).ServiceKey), $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, 3).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, 3).ServiceKey));
                }
                return null;
            }
            static /*object */ ReflectionFactoryServiceOnlySpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                /*object?[]*/ let $arguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call($arguments, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, declaringType, false, $.$spc.System.Array.$ReadT1.call(parameters, i).ServiceKey), i);
                }
                return invoker.Invoke$5($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Object, $arguments));
            }
            static /*object */ ReflectionFactoryCanonicalFixed(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(parameters.length >= 1 && parameters.length <= 4/*FixedArgumentThreshold*/, "parameters.Length >= 1 && parameters.Length <= FixedArgumentThreshold");
                $.$spc.System.Diagnostics.Debug.Assert$1(4/*FixedArgumentThreshold*/ === 4, "FixedArgumentThreshold == 4");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                /*ref FactoryParameterContext*/ let parameter1 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 0, false, true);
                let $switch1 = parameters.length;
                switch($switch1)
                {
                    case 1:
                    return invoker.Invoke$1(((parameter1.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue);
                    case 2:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        return invoker.Invoke$2(((parameter1.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue);
                    }
                    case 3:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        return invoker.Invoke$3(((parameter1.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue);
                    }
                    case 4:
                    {
                        /*ref FactoryParameterContext*/ let parameter2 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 1, false, true);
                        /*ref FactoryParameterContext*/ let parameter3 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 2, false, true);
                        /*ref FactoryParameterContext*/ let parameter4 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, 3, false, true);
                        return invoker.Invoke$4(((parameter1.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter1.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter1.$v.ParameterType, declaringType, parameter1.$v.HasDefaultValue, parameter1.$v.ServiceKey)) ?? parameter1.$v.DefaultValue, ((parameter2.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter2.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter2.$v.ParameterType, declaringType, parameter2.$v.HasDefaultValue, parameter2.$v.ServiceKey)) ?? parameter2.$v.DefaultValue, ((parameter3.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter3.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter3.$v.ParameterType, declaringType, parameter3.$v.HasDefaultValue, parameter3.$v.ServiceKey)) ?? parameter3.$v.DefaultValue, ((parameter4.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter4.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter4.$v.ParameterType, declaringType, parameter4.$v.HasDefaultValue, parameter4.$v.ServiceKey)) ?? parameter4.$v.DefaultValue);
                    }
                }
                return null;
            }
            static /*object */ ReflectionFactoryCanonicalSpan(/*ConstructorInvoker*/ invoker, /*FactoryParameterContext[]*/ parameters, /*Type*/ declaringType, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                /*object?[]*/ let constructorArguments = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [parameters.length], null);
                for(/*int*/ let i = 0; i < parameters.length; i++)
                {
                    /*ref FactoryParameterContext*/ let parameter = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.FactoryParameterContext, parameters, i, false, true);
                    $.$spc.System.Array.$WriteT1.call(constructorArguments, ((parameter.$v.ArgumentIndex !== -1) ? $.$spc.System.Array.$ReadT1.call($arguments, parameter.$v.ArgumentIndex) : $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService(serviceProvider, parameter.$v.ParameterType, declaringType, parameter.$v.HasDefaultValue, parameter.$v.ServiceKey)) ?? parameter.$v.DefaultValue, i);
                }
                return invoker.Invoke$5($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Object, constructorArguments));
            }
            static /*object */ ReflectionFactoryDirect(/*ConstructorInvoker*/ invoker, /*IServiceProvider*/ serviceProvider, /*object?[]?*/ $arguments)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceProvider, "serviceProvider");
                if ($arguments === null)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ThrowHelperNullReferenceException();
                }
                return invoker.Invoke$5($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Object, $arguments));
            }
            static /*void */ ThrowHelperNullReferenceException()
            {
                throw new $.$spc.System.NullReferenceException().$ctor$9();
            }
            static $_ActivatorUtilitiesUpdateHandler;
            static get ActivatorUtilitiesUpdateHandler()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_ActivatorUtilitiesUpdateHandler ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ActivatorUtilitiesUpdateHandler", ($self) => class ActivatorUtilitiesUpdateHandler
                {
                    static /*void */ ClearCache(/*Type[]?*/ _)
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_constructorInfos.Clear();
                        if ($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.IsValueCreated)
                        {
                            $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.s_collectibleConstructorInfos.Value.Clear();
                        }
                    }
                    static $h = 131075;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"_","p":0}],"n":"ClearCache","d":131075,"h":4295098371,"f":33}],"d":65539,"h":131075}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ActivatorUtilitiesUpdateHandler`; }
                }, $cls, ($v) => $cls.$_ActivatorUtilitiesUpdateHandler = $v);
            }
            static $_StackAllocatedObjects;
            static get StackAllocatedObjects()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities;
                return $cls.$_StackAllocatedObjects ??= $asm.$nstr("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects", ($self) => class StackAllocatedObjects extends $.$spc.System.ValueType
                {
                    /*object?*/  get _arg0() { return this.$getField(0, 4); }
                    /*object?*/  set _arg0(value) { this.$setField(0, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(8)
                        copy.$fields = [...this.$fields];
                        $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(object?, 8)
                        for (let $i = 7; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, null);
                        }
                        $.$spc.System.Array.AddMetadata(this.$fields, $.$typeOf($.$spc.System.Object), null, null)
                    }
                    static $h = 393219;
                    static $z = 32;
                    static $f = 0b1000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"MaxStackAllocArgCount","d":393219,"h":4295360515,"f":40},{"t":131073,"n":"_arg0","d":393219,"h":8590327811,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":393219,"h":12885295107,"f":1}],"d":65539,"h":393219,"a":[{"t":92274689,"c":4387241985,"a":[{"v":8,"t":655361}]}]}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities.StackAllocatedObjects`; }
                }, $cls, ($v) => $cls.$_StackAllocatedObjects = $v);
            }
            static /*object? */ GetKeyedService(/*IServiceProvider*/ provider, /*Type*/ type, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(type, serviceKey);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_constructorInfos = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx)))().$ctor$1();
                }
                {
                    this.s_collectibleConstructorInfos = new ($.$spc.System.Lazy$$($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))))().$ctor$1();
                }
                {
                    this.GetServiceInfo = new ($.$spc.System.Func$$$$$$$($.$scm.System.IServiceProvider, $.$spc.System.Type, $.$spc.System.Type, $.$spc.System.Boolean, $.$spc.System.Object, $.$spc.System.Object))().$ctor(null, $.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.GetService).Method;
                }
            }
            static $h = 65539;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"p":[{"n":"provider","p":327717},{"n":"instanceType","p":142606337},{"n":"parameters","p":0,"f":16}],"n":"CreateInstance","d":65539,"h":21474902019,"f":33},{"r":0,"p":[{"n":"type","p":142606337}],"n":"GetOrAddConstructors","d":65539,"h":25769869315,"f":34},{"r":0,"p":[{"n":"type","p":142606337}],"n":"CreateConstructorInfoExs","d":65539,"h":30064836611,"f":34},{"r":1376259,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0}],"n":"CreateFactory","d":65539,"h":34359803907,"f":33},{"r":(T) => $.$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory$$(T).$h,"p":[{"n":"argumentTypes","p":0}],"g":["T"],"n":"CreateFactory","o":"@$1","d":65539,"h":38654771203,"f":131105},{"r":65537,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0},{"n":"provider","p":40235590,"f":2},{"n":"argumentArray","p":40235590,"f":2},{"n":"factoryExpressionBody","p":8712774,"f":2}],"n":"CreateFactoryInternal","d":65539,"h":42949738499,"f":34},{"r":42953277440,"p":[{"n":"provider","p":327717},{"n":"parameters","p":0,"f":16}],"g":["T"],"n":"CreateInstance","o":"@$1","d":65539,"h":47244705795,"f":131105},{"r":47248244736,"p":[{"n":"provider","p":327717}],"g":["T"],"n":"GetServiceOrCreateInstance","d":65539,"h":51539673091,"f":131105},{"r":131073,"p":[{"n":"provider","p":327717},{"n":"type","p":142606337}],"n":"GetServiceOrCreateInstance","o":"@$1","d":65539,"h":55834640387,"f":33},{"r":131073,"p":[{"n":"sp","p":327717},{"n":"type","p":142606337},{"n":"requiredBy","p":142606337},{"n":"hasDefaultValue","p":262145},{"n":"key","p":131073}],"n":"GetService","d":65539,"h":60129607683,"f":34},{"r":65537,"p":[{"n":"type","p":142606337},{"n":"requiredBy","p":142606337}],"n":"ThrowHelperUnableToResolveService","d":65539,"h":64424574979,"f":34},{"r":3928646,"p":[{"n":"constructor","p":75628545},{"n":"parameterMap","p":0},{"n":"serviceProvider","p":8712774},{"n":"factoryArgumentArray","p":8712774}],"n":"BuildFactoryExpression","d":65539,"h":68719542275,"f":34},{"r":1376259,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0}],"n":"CreateFactoryReflection","d":65539,"h":73014509571,"f":34},{"r":65537,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0},{"n":"constructors","p":0},{"n":"matchingConstructor","p":75628545,"f":2},{"n":"matchingParameterMap","p":0,"f":2}],"n":"FindApplicableConstructor","d":65539,"h":81604444163,"f":34},{"r":196611,"p":[{"n":"constructorInfo","p":75628545},{"n":"constructorExs","p":0}],"n":"FindConstructorEx","d":65539,"h":85899411459,"f":34},{"r":262145,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0},{"n":"matchingConstructor","p":75628545,"f":2},{"n":"parameterMap","p":0,"f":2}],"n":"TryFindMatchingConstructor","d":65539,"h":90194378755,"f":34},{"r":262145,"p":[{"n":"instanceType","p":142606337},{"n":"argumentTypes","p":0},{"n":"constructors","p":0},{"n":"matchingConstructor","p":75628545,"f":2},{"n":"parameterMap","p":0,"f":2}],"n":"TryFindPreferredConstructor","d":65539,"h":94489346051,"f":34},{"r":262145,"p":[{"n":"constructorParameters","p":0},{"n":"argumentTypes","p":0},{"n":"parameterMap","p":0,"f":2}],"n":"TryCreateParameterMap","d":65539,"h":98784313347,"f":34},{"r":65537,"n":"ThrowMultipleCtorsMarkedWithAttributeException","d":65539,"h":111669215235,"f":34},{"r":65537,"n":"ThrowMarkedCtorDoesNotTakeAllProvidedArguments","d":65539,"h":115964182531,"f":34},{"r":131073,"p":[{"n":"invoker","p":75694081},{"n":"parameters","p":0},{"n":"declaringType","p":142606337},{"n":"serviceProvider","p":327717}],"n":"ReflectionFactoryServiceOnlyFixed","d":65539,"h":120259149827,"f":34},{"r":131073,"p":[{"n":"invoker","p":75694081},{"n":"parameters","p":0},{"n":"declaringType","p":142606337},{"n":"serviceProvider","p":327717}],"n":"ReflectionFactoryServiceOnlySpan","d":65539,"h":124554117123,"f":34},{"r":131073,"p":[{"n":"invoker","p":75694081},{"n":"parameters","p":0},{"n":"declaringType","p":142606337},{"n":"serviceProvider","p":327717},{"n":"arguments","p":0}],"n":"ReflectionFactoryCanonicalFixed","d":65539,"h":128849084419,"f":34},{"r":131073,"p":[{"n":"invoker","p":75694081},{"n":"parameters","p":0},{"n":"declaringType","p":142606337},{"n":"serviceProvider","p":327717},{"n":"arguments","p":0}],"n":"ReflectionFactoryCanonicalSpan","d":65539,"h":133144051715,"f":34},{"r":131073,"p":[{"n":"invoker","p":75694081},{"n":"serviceProvider","p":327717},{"n":"arguments","p":0}],"n":"ReflectionFactoryDirect","d":65539,"h":137439019011,"f":34},{"r":65537,"n":"ThrowHelperNullReferenceException","d":65539,"h":141733986307,"f":34},{"r":131073,"p":[{"n":"provider","p":327717},{"n":"type","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedService","d":65539,"h":154618888195,"f":34}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx)).$h,"n":"s_constructorInfos","d":65539,"h":4295032835,"f":34},{"t":$.$spc.System.Lazy$$($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Type, $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilities.ConstructorInfoEx))).$h,"n":"s_collectibleConstructorInfos","d":65539,"h":8590000131,"f":34},{"t":655361,"n":"FixedArgumentThreshold","d":65539,"h":12884967427,"f":34},{"t":79626241,"n":"GetServiceInfo","d":65539,"h":17179934723,"f":34}],"j":[327683,196611,262147,131075,393219],"h":65539}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilities`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService", ($self) => class KeyedService
        {
            /*object*/ static AnyKey = null;
            static $_AnyKeyObj;
            static get AnyKeyObj()
            {
                let $cls = $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService;
                return $cls.$_AnyKeyObj ??= $asm.$ncls("$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj", ($self) => class AnyKeyObj extends $.$spc.System.Object
                {
                    static/*conventional*/ /*string? */ ToString()
                    {
                        return "*";
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj.ToString.apply(this, arguments); }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1310723;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"n":"ToString","d":1310723,"h":4296278019,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":1310723,"h":8591245315,"f":1}],"d":1245187,"h":1310723}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj`; }
                }, $cls, ($v) => $cls.$_AnyKeyObj = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.AnyKey = new $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKeyObj().$ctor$1();
                }
            }
            static $h = 1245187;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12886147075,"f":33},"n":"AnyKey","d":1245187,"h":8591179779,"f":33}],"j":[1310723],"h":1245187}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.KeyedService`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions", ($self) => class ServiceProviderKeyedServiceExtensions
        {
            static /*T? */ GetKeyedService(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return $.$cast(keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(T.$type, serviceKey), T);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            static /*object? */ GetKeyedService$1(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                let keyedServiceProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ keyedServiceProvider = v; } }))
                {
                    return keyedServiceProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService(serviceType, serviceKey);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            static /*object */ GetRequiredKeyedService(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, { set $v(v){ requiredServiceSupportingProvider = v; } }))
                {
                    return requiredServiceSupportingProvider.Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService(serviceType, serviceKey);
                }
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.KeyedServicesNotSupported);
            }
            static /*T */ GetRequiredKeyedService$1(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, T.$type, serviceKey), T);
            }
            static /*IEnumerable<T> */ GetKeyedServices(T, /*this IServiceProvider*/ provider, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService$1($.$spc.System.Collections.Generic.IEnumerable$$(T), provider, serviceKey);
            }
            static /*IEnumerable<object?> */ GetKeyedServices$1(/*this IServiceProvider*/ provider, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$spc.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions.GetRequiredKeyedService(provider, genericEnumerable, serviceKey), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object));
            }
            static $h = 1900547;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"provider","p":327717},{"n":"serviceKey","p":131073}],"g":["T"],"n":"GetKeyedService","d":1900547,"h":4296867843,"f":131105},{"r":131073,"p":[{"n":"provider","p":327717},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedService","o":"@$1","d":1900547,"h":8591835139,"f":33},{"r":131073,"p":[{"n":"provider","p":327717},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetRequiredKeyedService","d":1900547,"h":12886802435,"f":33},{"r":12888506368,"p":[{"n":"provider","p":327717},{"n":"serviceKey","p":131073}],"g":["T"],"n":"GetRequiredKeyedService","o":"@$1","d":1900547,"h":17181769731,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"provider","p":327717},{"n":"serviceKey","p":131073}],"g":["T"],"n":"GetKeyedServices","d":1900547,"h":21476737027,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"provider","p":327717},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedServices","o":"@$1","d":1900547,"h":25771704323,"f":33}],"h":1900547}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderKeyedServiceExtensions`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions", ($self) => class ServiceProviderServiceExtensions
        {
            static /*T? */ GetService(T, /*this IServiceProvider*/ provider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                return $.$cast(provider.System$IServiceProvider$GetService(T.$type), T);
            }
            static /*object */ GetRequiredService(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                let requiredServiceSupportingProvider;
                if ($.$is(provider, $.$mxdi.Microsoft.Extensions.DependencyInjection.ISupportRequiredService, { set $v(v){ requiredServiceSupportingProvider = v; } }))
                {
                    return requiredServiceSupportingProvider.Microsoft$Extensions$DependencyInjection$ISupportRequiredService$GetRequiredService(serviceType);
                }
                /*object?*/ let service = provider.System$IServiceProvider$GetService(serviceType);
                if (service === null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.Format($.$mxdi.System.SR.NoServiceRegistered, serviceType));
                }
                return service;
            }
            static /*T */ GetRequiredService$1(T, /*this IServiceProvider*/ provider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService(provider, T.$type), T);
            }
            static /*IEnumerable<T> */ GetServices(T, /*this IServiceProvider*/ provider)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$spc.System.Collections.Generic.IEnumerable$$(T), provider);
            }
            static /*IEnumerable<object?> */ GetServices$1(/*this IServiceProvider*/ provider, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(provider, "provider");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                /*Type?*/ let genericEnumerable = $.$spc.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ serviceType ], null, null));
                return $.$cast($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService(provider, genericEnumerable), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object));
            }
            static /*IServiceScope */ CreateScope(/*this IServiceProvider*/ provider)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.GetRequiredService$1($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory, provider).Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope();
            }
            static /*AsyncServiceScope */ CreateAsyncScope(/*this IServiceProvider*/ provider)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions.CreateScope(provider));
            }
            static /*AsyncServiceScope */ CreateAsyncScope$1(/*this IServiceScopeFactory*/ serviceScopeFactory)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope().$ctor$2(serviceScopeFactory.Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope());
            }
            static $h = 1966083;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"p":[{"n":"provider","p":327717}],"g":["T"],"n":"GetService","d":1966083,"h":4296933379,"f":131105},{"r":131073,"p":[{"n":"provider","p":327717},{"n":"serviceType","p":142606337}],"n":"GetRequiredService","d":1966083,"h":8591900675,"f":33},{"r":8593539072,"p":[{"n":"provider","p":327717}],"g":["T"],"n":"GetRequiredService","o":"@$1","d":1966083,"h":12886867971,"f":131105},{"r":(T) => $.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"provider","p":327717}],"g":["T"],"n":"GetServices","d":1966083,"h":17181835267,"f":131105},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object).$h,"p":[{"n":"provider","p":327717},{"n":"serviceType","p":142606337}],"n":"GetServices","o":"@$1","d":1966083,"h":21476802563,"f":33},{"r":1048579,"p":[{"n":"provider","p":327717}],"n":"CreateScope","d":1966083,"h":25771769859,"f":33},{"r":524291,"p":[{"n":"provider","p":327717}],"n":"CreateAsyncScope","d":1966083,"h":30066737155,"f":33},{"r":524291,"p":[{"n":"serviceScopeFactory","p":1114115}],"n":"CreateAsyncScope","o":"@$1","d":1966083,"h":34361704451,"f":33}],"h":1966083}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderServiceExtensions`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions", ($self) => class ServiceCollectionServiceExtensions
        {
            static /*IServiceCollection */ AddTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            static /*IServiceCollection */ AddTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*IServiceCollection */ AddTransient$2(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient(services, TService.$type, TImplementation.$type);
            }
            static /*IServiceCollection */ AddTransient$3(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient(services, serviceType, serviceType);
            }
            static /*IServiceCollection */ AddTransient$4(TService, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$3(services, TService.$type);
            }
            static /*IServiceCollection */ AddTransient$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddTransient$6(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddTransient$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            static /*IServiceCollection */ AddScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*IServiceCollection */ AddScoped$2(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped(services, TService.$type, TImplementation.$type);
            }
            static /*IServiceCollection */ AddScoped$3(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped(services, serviceType, serviceType);
            }
            static /*IServiceCollection */ AddScoped$4(TService, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$3(services, TService.$type);
            }
            static /*IServiceCollection */ AddScoped$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddScoped$6(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddScoped$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add(services, serviceType, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            static /*IServiceCollection */ AddSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.Add$1(services, serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*IServiceCollection */ AddSingleton$2(TService, TImplementation, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton(services, TService.$type, TImplementation.$type);
            }
            static /*IServiceCollection */ AddSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton(services, serviceType, serviceType);
            }
            static /*IServiceCollection */ AddSingleton$4(TService, /*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$3(services, TService.$type);
            }
            static /*IServiceCollection */ AddSingleton$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddSingleton$6(TService, TImplementation, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$1(services, TService.$type, implementationFactory);
            }
            static /*IServiceCollection */ AddSingleton$7(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$3(serviceType, implementationInstance);
                services.System$Collections$Generic$ICollection$$$Add(serviceDescriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return services;
            }
            static /*IServiceCollection */ AddSingleton$8(TService, /*this IServiceCollection*/ services, /*TService*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7(services, TService.$type, $.$box(implementationInstance, TService));
            }
            static /*IServiceCollection */ Add(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$1(serviceType, implementationType, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static /*IServiceCollection */ Add$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$5(serviceType, implementationFactory, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static /*IServiceCollection */ AddKeyedTransient(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            static /*IServiceCollection */ AddKeyedTransient$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*IServiceCollection */ AddKeyedTransient$2(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient(services, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*IServiceCollection */ AddKeyedTransient$3(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient(services, serviceType, serviceKey, serviceType);
            }
            static /*IServiceCollection */ AddKeyedTransient$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$3(services, TService.$type, serviceKey);
            }
            static /*IServiceCollection */ AddKeyedTransient$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedTransient$6(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedTransient$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedScoped(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            static /*IServiceCollection */ AddKeyedScoped$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*IServiceCollection */ AddKeyedScoped$2(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped(services, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*IServiceCollection */ AddKeyedScoped$3(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped(services, serviceType, serviceKey, serviceType);
            }
            static /*IServiceCollection */ AddKeyedScoped$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$3(services, TService.$type, serviceKey);
            }
            static /*IServiceCollection */ AddKeyedScoped$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedScoped$6(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedScoped$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedSingleton(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed(services, serviceType, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            static /*IServiceCollection */ AddKeyedSingleton$1(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyed$1(services, serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*IServiceCollection */ AddKeyedSingleton$2(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*IServiceCollection */ AddKeyedSingleton$3(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, serviceType, serviceKey, serviceType);
            }
            static /*IServiceCollection */ AddKeyedSingleton$4(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton(services, TService.$type, serviceKey, TService.$type);
            }
            static /*IServiceCollection */ AddKeyedSingleton$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedSingleton$6(TService, TImplementation, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$1(services, TService.$type, serviceKey, implementationFactory);
            }
            static /*IServiceCollection */ AddKeyedSingleton$7(/*this IServiceCollection*/ services, /*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationInstance, "implementationInstance");
                /*var*/ let serviceDescriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationInstance);
                services.System$Collections$Generic$ICollection$$$Add(serviceDescriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return services;
            }
            static /*IServiceCollection */ AddKeyedSingleton$8(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddKeyedSingleton$7(services, TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            static /*IServiceCollection */ AddKeyed(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$2(serviceType, serviceKey, implementationType, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static /*IServiceCollection */ AddKeyed$1(/*IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                /*var*/ let descriptor = new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$6(serviceType, serviceKey, implementationFactory, lifetime);
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static $h = 1572867;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337}],"n":"AddTransient","d":1572867,"h":4296540163,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"AddTransient","o":"@$1","d":1572867,"h":8591507459,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService","TImplementation"],"n":"AddTransient","o":"@$2","d":1572867,"h":12886474755,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337}],"n":"AddTransient","o":"@$3","d":1572867,"h":17181442051,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService"],"n":"AddTransient","o":"@$4","d":1572867,"h":21476409347,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"AddTransient","o":"@$5","d":1572867,"h":25771376643,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddTransient","o":"@$6","d":1572867,"h":30066343939,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337}],"n":"AddScoped","d":1572867,"h":34361311235,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"AddScoped","o":"@$1","d":1572867,"h":38656278531,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService","TImplementation"],"n":"AddScoped","o":"@$2","d":1572867,"h":42951245827,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337}],"n":"AddScoped","o":"@$3","d":1572867,"h":47246213123,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService"],"n":"AddScoped","o":"@$4","d":1572867,"h":51541180419,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"AddScoped","o":"@$5","d":1572867,"h":55836147715,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddScoped","o":"@$6","d":1572867,"h":60131115011,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337}],"n":"AddSingleton","d":1572867,"h":64426082307,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"AddSingleton","o":"@$1","d":1572867,"h":68721049603,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService","TImplementation"],"n":"AddSingleton","o":"@$2","d":1572867,"h":73016016899,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337}],"n":"AddSingleton","o":"@$3","d":1572867,"h":77310984195,"f":33},{"r":786435,"p":[{"n":"services","p":786435}],"g":["TService"],"n":"AddSingleton","o":"@$4","d":1572867,"h":81605951491,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"AddSingleton","o":"@$5","d":1572867,"h":85900918787,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddSingleton","o":"@$6","d":1572867,"h":90195886083,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationInstance","p":131073}],"n":"AddSingleton","o":"@$7","d":1572867,"h":94490853379,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"implementationInstance","p":94492884992}],"g":["TService"],"n":"AddSingleton","o":"@$8","d":1572867,"h":98785820675,"f":131105},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":"Add","d":1572867,"h":103080787971,"f":34},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":"Add","o":"@$1","d":1572867,"h":107375755267,"f":34},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"AddKeyedTransient","d":1572867,"h":111670722563,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"AddKeyedTransient","o":"@$1","d":1572867,"h":115965689859,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"AddKeyedTransient","o":"@$2","d":1572867,"h":120260657155,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"AddKeyedTransient","o":"@$3","d":1572867,"h":124555624451,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"AddKeyedTransient","o":"@$4","d":1572867,"h":128850591747,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"AddKeyedTransient","o":"@$5","d":1572867,"h":133145559043,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddKeyedTransient","o":"@$6","d":1572867,"h":137440526339,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"AddKeyedScoped","d":1572867,"h":141735493635,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"AddKeyedScoped","o":"@$1","d":1572867,"h":146030460931,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"AddKeyedScoped","o":"@$2","d":1572867,"h":150325428227,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"AddKeyedScoped","o":"@$3","d":1572867,"h":154620395523,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"AddKeyedScoped","o":"@$4","d":1572867,"h":158915362819,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"AddKeyedScoped","o":"@$5","d":1572867,"h":163210330115,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddKeyedScoped","o":"@$6","d":1572867,"h":167505297411,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"AddKeyedSingleton","d":1572867,"h":171800264707,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"AddKeyedSingleton","o":"@$1","d":1572867,"h":176095232003,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"AddKeyedSingleton","o":"@$2","d":1572867,"h":180390199299,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"AddKeyedSingleton","o":"@$3","d":1572867,"h":184685166595,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"AddKeyedSingleton","o":"@$4","d":1572867,"h":188980133891,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"AddKeyedSingleton","o":"@$5","d":1572867,"h":193275101187,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"AddKeyedSingleton","o":"@$6","d":1572867,"h":197570068483,"f":131105},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationInstance","p":131073}],"n":"AddKeyedSingleton","o":"@$7","d":1572867,"h":201865035779,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationInstance","p":201867067392}],"g":["TService"],"n":"AddKeyedSingleton","o":"@$8","d":1572867,"h":206160003075,"f":131105},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":"AddKeyed","d":1572867,"h":210454970371,"f":34},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":"AddKeyed","o":"@$1","d":1572867,"h":214749937667,"f":34}],"h":1572867}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions", ($self) => class ServiceCollectionDescriptorExtensions
        {
            static /*IServiceCollection */ Add(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptor, "descriptor");
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static /*IServiceCollection */ Add$1(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var descriptor = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            static /*void */ TryAdd(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptor, "descriptor");
                /*int*/ let count = collection.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if ($.$spc.System.Type.op_Equality$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceType, descriptor.ServiceType) && $.$spc.System.Object.Equals$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
            }
            static /*void */ TryAdd$1(/*this IServiceCollection*/ collection, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var d = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, d);
                    }
                }
            }
            static /*void */ TryAddTransient(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$1(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$4(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddTransient$3(TService, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TService.$type);
            }
            static /*void */ TryAddTransient$4(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(collection, TService.$type, TImplementation.$type);
            }
            static /*void */ TryAddTransient$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Transient$3(TService, implementationFactory));
            }
            static /*void */ TryAddScoped(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$1(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$4(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddScoped$3(TService, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TService.$type);
            }
            static /*void */ TryAddScoped$4(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddScoped$1(collection, TService.$type, TImplementation.$type);
            }
            static /*void */ TryAddScoped$5(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Scoped$3(TService, implementationFactory));
            }
            static /*void */ TryAddSingleton(/*this IServiceCollection*/ collection, /*Type*/ service)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$1(service, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$1(service, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$4(service, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddSingleton$3(TService, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TService.$type);
            }
            static /*void */ TryAddSingleton$4(TService, TImplementation, /*this IServiceCollection*/ collection)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$1(collection, TService.$type, TImplementation.$type);
            }
            static /*void */ TryAddSingleton$5(TService, /*this IServiceCollection*/ collection, /*TService*/ instance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$6(TService.$type, $.$box(instance, TService));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddSingleton$6(TService, /*this IServiceCollection*/ services, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$3(TService, implementationFactory));
            }
            static /*void */ TryAddEnumerable(/*this IServiceCollection*/ services, /*ServiceDescriptor*/ descriptor)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptor, "descriptor");
                /*Type?*/ let implementationType = descriptor.GetImplementationType();
                if ($.$spc.System.Type.op_Equality$1(implementationType, $.$spc.System.Object.$type) || $.$spc.System.Type.op_Equality$1(implementationType, descriptor.ServiceType))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$mxdi.System.SR.Format$1($.$mxdi.System.SR.TryAddIndistinguishableTypeToEnumerable, implementationType, descriptor.ServiceType), "descriptor");
                }
                /*int*/ let count = services.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    /*ServiceDescriptor*/ let service = services.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$spc.System.Type.op_Equality$1(service.ServiceType, descriptor.ServiceType) && $.$spc.System.Type.op_Equality$1(service.GetImplementationType(), implementationType) && $.$spc.System.Object.Equals$1(service.ServiceKey, descriptor.ServiceKey))
                    {
                        return;
                    }
                }
                services.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
            }
            static /*void */ TryAddEnumerable$1(/*this IServiceCollection*/ services, /*IEnumerable<ServiceDescriptor>*/ descriptors)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptors, "descriptors");
                var $en2 = descriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var d = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable(services, d);
                    }
                }
            }
            static /*IServiceCollection */ Replace(/*this IServiceCollection*/ collection, /*ServiceDescriptor*/ descriptor)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(descriptor, "descriptor");
                /*int*/ let count = collection.System$Collections$Generic$ICollection$$$Count;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    if ($.$spc.System.Type.op_Equality$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceType, descriptor.ServiceType) && $.$spc.System.Object.Equals$1(collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]).ServiceKey, descriptor.ServiceKey))
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                        break;
                    }
                }
                collection.System$Collections$Generic$ICollection$$$Add(descriptor, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                return collection;
            }
            static /*IServiceCollection */ RemoveAll(T, /*this IServiceCollection*/ collection)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAll$1(collection, T.$type);
            }
            static /*IServiceCollection */ RemoveAll$1(/*this IServiceCollection*/ collection, /*Type*/ serviceType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$spc.System.Type.op_Equality$1(descriptor.ServiceType, serviceType) && descriptor.ServiceKey === null)
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            static /*void */ TryAddKeyedTransient(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$1(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedTransient$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$1(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedTransient$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$4(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedTransient$3(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TService.$type);
            }
            static /*void */ TryAddKeyedTransient$4(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedTransient$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*void */ TryAddKeyedTransient$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedTransient$3(TService, serviceKey, implementationFactory));
            }
            static /*void */ TryAddKeyedScoped(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$1(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedScoped$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$1(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedScoped$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$4(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedScoped$3(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TService.$type);
            }
            static /*void */ TryAddKeyedScoped$4(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedScoped$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*void */ TryAddKeyedScoped$5(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedScoped$3(TService, serviceKey, implementationFactory));
            }
            static /*void */ TryAddKeyedSingleton(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$1(service, serviceKey, service);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedSingleton$1(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$1(service, serviceKey, implementationType);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedSingleton$2(/*this IServiceCollection*/ collection, /*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$4(service, serviceKey, implementationFactory);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedSingleton$3(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TService.$type);
            }
            static /*void */ TryAddKeyedSingleton$4(TService, TImplementation, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddKeyedSingleton$1(collection, TService.$type, serviceKey, TImplementation.$type);
            }
            static /*void */ TryAddKeyedSingleton$5(TService, /*this IServiceCollection*/ collection, /*object?*/ serviceKey, /*TService*/ instance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(collection, "collection");
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(instance, TService), "instance");
                /*var*/ let descriptor = $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$6(TService.$type, serviceKey, $.$box(instance, TService));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(collection, descriptor);
            }
            static /*void */ TryAddKeyedSingleton$6(TService, /*this IServiceCollection*/ services, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAdd(services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$3(TService, serviceKey, implementationFactory));
            }
            static /*IServiceCollection */ RemoveAllKeyed(T, /*this IServiceCollection*/ collection, /*object?*/ serviceKey)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAllKeyed$1(collection, T.$type, serviceKey);
            }
            static /*IServiceCollection */ RemoveAllKeyed$1(/*this IServiceCollection*/ collection, /*Type*/ serviceType, /*object?*/ serviceKey)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                for(/*int*/ let i = ((collection.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; i--)
                {
                    /*ServiceDescriptor?*/ let descriptor = collection.System$Collections$Generic$IList$$$get_Item(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    if ($.$spc.System.Type.op_Equality$1(descriptor.ServiceType, serviceType) && $.$spc.System.Object.Equals$1(descriptor.ServiceKey, serviceKey))
                    {
                        collection.System$Collections$Generic$IList$$$RemoveAt(i, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    }
                }
                return collection;
            }
            static $h = 589827;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"collection","p":786435},{"n":"descriptor","p":1638403}],"n":"Add","d":589827,"h":4295557123,"f":33},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"descriptors","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h}],"n":"Add","o":"@$1","d":589827,"h":8590524419,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"descriptor","p":1638403}],"n":"TryAdd","d":589827,"h":12885491715,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"descriptors","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h}],"n":"TryAdd","o":"@$1","d":589827,"h":17180459011,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337}],"n":"TryAddTransient","d":589827,"h":21475426307,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"TryAddTransient","o":"@$1","d":589827,"h":25770393603,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"TryAddTransient","o":"@$2","d":589827,"h":30065360899,"f":33},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService"],"n":"TryAddTransient","o":"@$3","d":589827,"h":34360328195,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService","TImplementation"],"n":"TryAddTransient","o":"@$4","d":589827,"h":38655295491,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"TryAddTransient","o":"@$5","d":589827,"h":42950262787,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337}],"n":"TryAddScoped","d":589827,"h":47245230083,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"TryAddScoped","o":"@$1","d":589827,"h":51540197379,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"TryAddScoped","o":"@$2","d":589827,"h":55835164675,"f":33},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService"],"n":"TryAddScoped","o":"@$3","d":589827,"h":60130131971,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService","TImplementation"],"n":"TryAddScoped","o":"@$4","d":589827,"h":64425099267,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"TryAddScoped","o":"@$5","d":589827,"h":68720066563,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337}],"n":"TryAddSingleton","d":589827,"h":73015033859,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"TryAddSingleton","o":"@$1","d":589827,"h":77310001155,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"TryAddSingleton","o":"@$2","d":589827,"h":81604968451,"f":33},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService"],"n":"TryAddSingleton","o":"@$3","d":589827,"h":85899935747,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435}],"g":["TService","TImplementation"],"n":"TryAddSingleton","o":"@$4","d":589827,"h":90194903043,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"instance","p":90197917696}],"g":["TService"],"n":"TryAddSingleton","o":"@$5","d":589827,"h":94489870339,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"TryAddSingleton","o":"@$6","d":589827,"h":98784837635,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"descriptor","p":1638403}],"n":"TryAddEnumerable","d":589827,"h":103079804931,"f":33},{"r":65537,"p":[{"n":"services","p":786435},{"n":"descriptors","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h}],"n":"TryAddEnumerable","o":"@$1","d":589827,"h":107374772227,"f":33},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"descriptor","p":1638403}],"n":"Replace","d":589827,"h":111669739523,"f":33},{"r":786435,"p":[{"n":"collection","p":786435}],"g":["T"],"n":"RemoveAll","d":589827,"h":115964706819,"f":131105},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337}],"n":"RemoveAll","o":"@$1","d":589827,"h":120259674115,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073}],"n":"TryAddKeyedTransient","d":589827,"h":124554641411,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"TryAddKeyedTransient","o":"@$1","d":589827,"h":128849608707,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"TryAddKeyedTransient","o":"@$2","d":589827,"h":133144576003,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"TryAddKeyedTransient","o":"@$3","d":589827,"h":137439543299,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"TryAddKeyedTransient","o":"@$4","d":589827,"h":141734510595,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"TryAddKeyedTransient","o":"@$5","d":589827,"h":146029477891,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073}],"n":"TryAddKeyedScoped","d":589827,"h":150324445187,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"TryAddKeyedScoped","o":"@$1","d":589827,"h":154619412483,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"TryAddKeyedScoped","o":"@$2","d":589827,"h":158914379779,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"TryAddKeyedScoped","o":"@$3","d":589827,"h":163209347075,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"TryAddKeyedScoped","o":"@$4","d":589827,"h":167504314371,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"TryAddKeyedScoped","o":"@$5","d":589827,"h":171799281667,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073}],"n":"TryAddKeyedSingleton","d":589827,"h":176094248963,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"TryAddKeyedSingleton","o":"@$1","d":589827,"h":180389216259,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"TryAddKeyedSingleton","o":"@$2","d":589827,"h":184684183555,"f":33},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService"],"n":"TryAddKeyedSingleton","o":"@$3","d":589827,"h":188979150851,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"TryAddKeyedSingleton","o":"@$4","d":589827,"h":193274118147,"f":131105},{"r":65537,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073},{"n":"instance","p":193277132800}],"g":["TService"],"n":"TryAddKeyedSingleton","o":"@$5","d":589827,"h":197569085443,"f":131105},{"r":65537,"p":[{"n":"services","p":786435},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"TryAddKeyedSingleton","o":"@$6","d":589827,"h":201864052739,"f":131105},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceKey","p":131073}],"g":["T"],"n":"RemoveAllKeyed","d":589827,"h":206159020035,"f":131105},{"r":786435,"p":[{"n":"collection","p":786435},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"RemoveAllKeyed","o":"@$1","d":589827,"h":210453987331,"f":33}],"h":589827}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor", ($self) => class ServiceDescriptor extends $.$spc.System.Object
        {
            $ctor$1(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$2(serviceType, null, implementationType, lifetime);
                {
                }
                return this;
            }
            $ctor$2(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$7(serviceType, serviceKey, lifetime);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                    this._implementationType = implementationType;
                }
                return this;
            }
            $ctor$3(/*Type*/ serviceType, /*object*/ instance)
            {
                this.$ctor$4(serviceType, null, instance);
                {
                }
                return this;
            }
            $ctor$4(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ instance)
            {
                this.$ctor$7(serviceType, serviceKey, 0/*ServiceLifetime.Singleton*/);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(instance, "instance");
                    this._implementationInstance = instance;
                }
                return this;
            }
            $ctor$5(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$7(serviceType, null, lifetime);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                    this._implementationFactory = factory;
                }
                return this;
            }
            $ctor$6(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ factory, /*ServiceLifetime*/ lifetime)
            {
                this.$ctor$7(serviceType, serviceKey, lifetime);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                    if (serviceKey === null)
                    {
                        /*Func<IServiceProvider, object>*/ let nullKeyedFactory = new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object))().$ctor(this,  (/*sp*/ sp) =>
                        {
                            return factory.Invoke(sp, null);
                        });
                        this._implementationFactory = nullKeyedFactory;
                    }
                    else 
                    {
                        this._implementationFactory = factory;
                    }
                }
                return this;
            }
            $ctor$7(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                super.$ctor();
                {
                    this.Lifetime = lifetime;
                    this.ServiceType = serviceType;
                    this.ServiceKey = serviceKey;
                }
                return this;
            }
            /*ServiceLifetime*/ Lifetime = 0;
            /*object?*/ ServiceKey = null;
            /*Type*/ ServiceType = null;
            /*Type?*/ _implementationType = null;
            /*Type? */ get ImplementationType()
            {
                return this.IsKeyedService ? null : this._implementationType;
            }
            /*Type? */ get KeyedImplementationType()
            {
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationType;
            }
            /*object?*/ _implementationInstance = null;
            /*object? */ get ImplementationInstance()
            {
                return this.IsKeyedService ? null : this._implementationInstance;
            }
            /*object? */ get KeyedImplementationInstance()
            {
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return this._implementationInstance;
            }
            /*object?*/ _implementationFactory = null;
            /*Func<IServiceProvider, object>? */ get ImplementationFactory()
            {
                return this.IsKeyedService ? null : $.$cast(this._implementationFactory, $.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object));
            }
            /*Func<IServiceProvider, object?, object>? */ get KeyedImplementationFactory()
            {
                if (!this.IsKeyedService)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ThrowNonKeyedDescriptor();
                }
                return $.$cast(this._implementationFactory, $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object));
            }
            /*bool */ get IsKeyedService()
            {
                return this.ServiceKey !== null;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string?*/ let lifetime = `${"ServiceType"}: ${$.$spc.System.Type.ToString.call(this.ServiceType)} ${"Lifetime"}: ${this.Lifetime} `;
                if (this.IsKeyedService)
                {
                    lifetime += `${"ServiceKey"}: ${$.$spc.System.Object.ToString.call(this.ServiceKey)} `;
                    if ($.$spc.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        return lifetime + `${"KeyedImplementationType"}: ${$.$spc.System.Type.ToString.call(this.KeyedImplementationType)}`;
                    }
                    if (this.KeyedImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$spc.System.Diagnostics.DiagnosticMethodInfo.Create(this.KeyedImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return lifetime + `${"KeyedImplementationFactory"}: ${declaringTypeName}.${methodName}`;
                    }
                    return lifetime + `${"KeyedImplementationInstance"}: ${$.$spc.System.Object.ToString.call(this.KeyedImplementationInstance)}`;
                }
                else 
                {
                    if ($.$spc.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        return lifetime + `${"ImplementationType"}: ${$.$spc.System.Type.ToString.call(this.ImplementationType)}`;
                    }
                    if (this.ImplementationFactory !== null)
                    {
                        /*DiagnosticMethodInfo?*/ let dmi = $.$spc.System.Diagnostics.DiagnosticMethodInfo.Create(this.ImplementationFactory);
                        /*string*/ let declaringTypeName = (dmi?.DeclaringTypeName ?? null) ?? "?";
                        /*string*/ let methodName = (dmi?.Name ?? null) ?? "?";
                        return lifetime + `${"ImplementationFactory"}: ${declaringTypeName}.${methodName}`;
                    }
                    return lifetime + `${"ImplementationInstance"}: ${$.$spc.System.Object.ToString.call(this.ImplementationInstance)}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ToString.apply(this, arguments); }
            /*Type */ GetImplementationType()
            {
                if (this.ServiceKey === null)
                {
                    if ($.$spc.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        return this.ImplementationType;
                    }
                    else if (this.ImplementationInstance !== null)
                    {
                        return $.$spc.System.Object.GetType.call(this.ImplementationInstance);
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$spc.System.Object.GetType.call(this.ImplementationFactory).GenericTypeArguments;
                        $.$spc.System.Diagnostics.Debug.Assert$1(typeArguments.length === 2, "typeArguments.Length == 2");
                        return $.$spc.System.Array.$ReadT1.call(typeArguments, 1);
                    }
                }
                else 
                {
                    if ($.$spc.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        return this.KeyedImplementationType;
                    }
                    else if (this.KeyedImplementationInstance !== null)
                    {
                        return $.$spc.System.Object.GetType.call(this.KeyedImplementationInstance);
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        /*Type[]?*/ let typeArguments = $.$spc.System.Object.GetType.call(this.KeyedImplementationFactory).GenericTypeArguments;
                        $.$spc.System.Diagnostics.Debug.Assert$1(typeArguments.length === 3, "typeArguments.Length == 3");
                        return $.$spc.System.Array.$ReadT1.call(typeArguments, 2);
                    }
                }
                $.$spc.System.Diagnostics.Debug.Fail("ImplementationType, ImplementationInstance, ImplementationFactory or KeyedImplementationFactory must be non null");
                return null;
            }
            static /*ServiceDescriptor */ Transient(TService, TImplementation, )
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, null, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ KeyedTransient(TService, TImplementation, /*object?*/ serviceKey)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, serviceKey, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ Transient$1(/*Type*/ service, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(service, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ KeyedTransient$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ Transient$2(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ KeyedTransient$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ Transient$3(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ KeyedTransient$3(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ Transient$4(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(service, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ KeyedTransient$4(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(service, serviceKey, implementationFactory, 2/*ServiceLifetime.Transient*/);
            }
            static /*ServiceDescriptor */ Scoped(TService, TImplementation, )
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, null, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ KeyedScoped(TService, TImplementation, /*object?*/ serviceKey)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, serviceKey, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ Scoped$1(/*Type*/ service, /*Type*/ implementationType)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(service, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ KeyedScoped$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ Scoped$2(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ KeyedScoped$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ Scoped$3(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ KeyedScoped$3(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ Scoped$4(/*Type*/ service, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(service, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ KeyedScoped$4(/*Type*/ service, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(service, serviceKey, implementationFactory, 1/*ServiceLifetime.Scoped*/);
            }
            static /*ServiceDescriptor */ Singleton(TService, TImplementation, )
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, null, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ KeyedSingleton(TService, TImplementation, /*object?*/ serviceKey)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed(TService, TImplementation, serviceKey, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ Singleton$1(/*Type*/ service, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe(service, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ KeyedSingleton$1(/*Type*/ service, /*object?*/ serviceKey, /*Type*/ implementationType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(service, "service");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationType, "implementationType");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(service, serviceKey, implementationType, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ Singleton$2(TService, TImplementation, /*Func<IServiceProvider, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ KeyedSingleton$2(TService, TImplementation, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TImplementation>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ Singleton$3(TService, /*Func<IServiceProvider, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(TService.$type, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ KeyedSingleton$3(TService, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, TService>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(TService.$type, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ Singleton$4(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Describe$1(serviceType, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ KeyedSingleton$4(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationFactory, "implementationFactory");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$2(serviceType, serviceKey, implementationFactory, 0/*ServiceLifetime.Singleton*/);
            }
            static /*ServiceDescriptor */ Singleton$5(TService, /*TService*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$6(TService.$type, $.$box(implementationInstance, TService));
            }
            static /*ServiceDescriptor */ KeyedSingleton$5(TService, /*object?*/ serviceKey, /*TService*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull($.$box(implementationInstance, TService), "implementationInstance");
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.KeyedSingleton$6(TService.$type, serviceKey, $.$box(implementationInstance, TService));
            }
            static /*ServiceDescriptor */ Singleton$6(/*Type*/ serviceType, /*object*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationInstance, "implementationInstance");
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$3(serviceType, implementationInstance);
            }
            static /*ServiceDescriptor */ KeyedSingleton$6(/*Type*/ serviceType, /*object?*/ serviceKey, /*object*/ implementationInstance)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                $.$spc.System.ArgumentNullException.ThrowIfNull(implementationInstance, "implementationInstance");
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$4(serviceType, serviceKey, implementationInstance);
            }
            static /*ServiceDescriptor */ DescribeKeyed(TService, TImplementation, /*object?*/ serviceKey, /*ServiceLifetime*/ lifetime)
            {
                return $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.DescribeKeyed$1(TService.$type, serviceKey, TImplementation.$type, lifetime);
            }
            static /*ServiceDescriptor */ Describe(/*Type*/ serviceType, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$1(serviceType, implementationType, lifetime);
            }
            static /*ServiceDescriptor */ DescribeKeyed$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*Type*/ implementationType, /*ServiceLifetime*/ lifetime)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$2(serviceType, serviceKey, implementationType, lifetime);
            }
            static /*ServiceDescriptor */ Describe$1(/*Type*/ serviceType, /*Func<IServiceProvider, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$5(serviceType, implementationFactory, lifetime);
            }
            static /*ServiceDescriptor */ DescribeKeyed$2(/*Type*/ serviceType, /*object?*/ serviceKey, /*Func<IServiceProvider, object?, object>*/ implementationFactory, /*ServiceLifetime*/ lifetime)
            {
                return new $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor().$ctor$6(serviceType, serviceKey, implementationFactory, lifetime);
            }
            /*string */ DebuggerToString()
            {
                /*string*/ let debugText = `Lifetime = ${this.Lifetime}, ServiceType = \"${this.ServiceType.FullName}\"`;
                if (this.IsKeyedService)
                {
                    debugText += `, ServiceKey = \"${$.$spc.System.Object.ToString.call(this.ServiceKey)}\"`;
                    if ($.$spc.System.Type.op_Inequality$1(this.KeyedImplementationType, null))
                    {
                        debugText += `, KeyedImplementationType = \"${this.KeyedImplementationType.FullName}\"`;
                    }
                    else if (this.KeyedImplementationFactory !== null)
                    {
                        debugText += `, KeyedImplementationFactory = ${$.$spc.System.Object.ToString.call(this.KeyedImplementationFactory.Method)}`;
                    }
                    else 
                    {
                        debugText += `, KeyedImplementationInstance = ${$.$spc.System.Object.ToString.call(this.KeyedImplementationInstance)}`;
                    }
                }
                else 
                {
                    if ($.$spc.System.Type.op_Inequality$1(this.ImplementationType, null))
                    {
                        debugText += `, ImplementationType = \"${this.ImplementationType.FullName}\"`;
                    }
                    else if (this.ImplementationFactory !== null)
                    {
                        debugText += `, ImplementationFactory = ${$.$spc.System.Object.ToString.call(this.ImplementationFactory.Method)}`;
                    }
                    else 
                    {
                        debugText += `, ImplementationInstance = ${$.$spc.System.Object.ToString.call(this.ImplementationInstance)}`;
                    }
                }
                return debugText;
            }
            static /*void */ ThrowNonKeyedDescriptor()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.NonKeyedDescriptorMisuse);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Lifetime = 0;
            }
            static $h = 1638403;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1835011,"g":{"r":0,"d":0,"h":42951311363,"f":1},"n":"Lifetime","d":1638403,"h":38656344067,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":55836213251,"f":1},"n":"ServiceKey","d":1638403,"h":51541245955,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":68721115139,"f":1},"n":"ServiceType","d":1638403,"h":64426147843,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":81606017027,"f":1},"n":"ImplementationType","d":1638403,"h":77311049731,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":90195951619,"f":1},"n":"KeyedImplementationType","d":1638403,"h":85900984323,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":103080853507,"f":1},"n":"ImplementationInstance","d":1638403,"h":98785886211,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":111670788099,"f":1},"n":"KeyedImplementationInstance","d":1638403,"h":107375820803,"f":1},{"p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":124555689987,"f":1},"n":"ImplementationFactory","d":1638403,"h":120260722691,"f":1},{"p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":133145624579,"f":1},"n":"KeyedImplementationFactory","d":1638403,"h":128850657283,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":141735559171,"f":1},"n":"IsKeyedService","d":1638403,"h":137440591875,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1638403,"h":146030526467,"f":32769},{"r":142606337,"n":"GetImplementationType","d":1638403,"h":150325493763,"f":8},{"r":1638403,"g":["TService","TImplementation"],"n":"Transient","d":1638403,"h":154620461059,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"KeyedTransient","d":1638403,"h":158915428355,"f":131105},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"Transient","o":"@$1","d":1638403,"h":163210395651,"f":33},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"KeyedTransient","o":"@$1","d":1638403,"h":167505362947,"f":33},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"Transient","o":"@$2","d":1638403,"h":171800330243,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"KeyedTransient","o":"@$2","d":1638403,"h":176095297539,"f":131105},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"Transient","o":"@$3","d":1638403,"h":180390264835,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"KeyedTransient","o":"@$3","d":1638403,"h":184685232131,"f":131105},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"Transient","o":"@$4","d":1638403,"h":188980199427,"f":33},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"KeyedTransient","o":"@$4","d":1638403,"h":193275166723,"f":33},{"r":1638403,"g":["TService","TImplementation"],"n":"Scoped","d":1638403,"h":197570134019,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"KeyedScoped","d":1638403,"h":201865101315,"f":131105},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"Scoped","o":"@$1","d":1638403,"h":206160068611,"f":33},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"KeyedScoped","o":"@$1","d":1638403,"h":210455035907,"f":33},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"Scoped","o":"@$2","d":1638403,"h":214750003203,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"KeyedScoped","o":"@$2","d":1638403,"h":219044970499,"f":131105},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"Scoped","o":"@$3","d":1638403,"h":223339937795,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"KeyedScoped","o":"@$3","d":1638403,"h":227634905091,"f":131105},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"Scoped","o":"@$4","d":1638403,"h":231929872387,"f":33},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"KeyedScoped","o":"@$4","d":1638403,"h":236224839683,"f":33},{"r":1638403,"g":["TService","TImplementation"],"n":"Singleton","d":1638403,"h":240519806979,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073}],"g":["TService","TImplementation"],"n":"KeyedSingleton","d":1638403,"h":244814774275,"f":131105},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"implementationType","p":142606337}],"n":"Singleton","o":"@$1","d":1638403,"h":249109741571,"f":33},{"r":1638403,"p":[{"n":"service","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337}],"n":"KeyedSingleton","o":"@$1","d":1638403,"h":253404708867,"f":33},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TImplementation).$h}],"g":["TService","TImplementation"],"n":"Singleton","o":"@$2","d":1638403,"h":257699676163,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService, TImplementation) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TImplementation).$h}],"g":["TService","TImplementation"],"n":"KeyedSingleton","o":"@$2","d":1638403,"h":261994643459,"f":131105},{"r":1638403,"p":[{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$($.$scm.System.IServiceProvider, TService).$h}],"g":["TService"],"n":"Singleton","o":"@$3","d":1638403,"h":266289610755,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":(TService) => $.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, TService).$h}],"g":["TService"],"n":"KeyedSingleton","o":"@$3","d":1638403,"h":270584578051,"f":131105},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":"Singleton","o":"@$4","d":1638403,"h":274879545347,"f":33},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":"KeyedSingleton","o":"@$4","d":1638403,"h":279174512643,"f":33},{"r":1638403,"p":[{"n":"implementationInstance","p":279176478720}],"g":["TService"],"n":"Singleton","o":"@$5","d":1638403,"h":283469479939,"f":131105},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"implementationInstance","p":283471446016}],"g":["TService"],"n":"KeyedSingleton","o":"@$5","d":1638403,"h":287764447235,"f":131105},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"implementationInstance","p":131073}],"n":"Singleton","o":"@$6","d":1638403,"h":292059414531,"f":33},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationInstance","p":131073}],"n":"KeyedSingleton","o":"@$6","d":1638403,"h":296354381827,"f":33},{"r":1638403,"p":[{"n":"serviceKey","p":131073},{"n":"lifetime","p":1835011}],"g":["TService","TImplementation"],"n":"DescribeKeyed","d":1638403,"h":300649349123,"f":131106},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":"Describe","d":1638403,"h":304944316419,"f":33},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":"DescribeKeyed","o":"@$1","d":1638403,"h":309239283715,"f":33},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"implementationFactory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":"Describe","o":"@$1","d":1638403,"h":313534251011,"f":33},{"r":1638403,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationFactory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":"DescribeKeyed","o":"@$2","d":1638403,"h":317829218307,"f":33},{"r":1310721,"n":"DebuggerToString","d":1638403,"h":322124185603,"f":2},{"r":65537,"n":"ThrowNonKeyedDescriptor","d":1638403,"h":326419152899,"f":34}],"l":[{"t":142606337,"n":"_implementationType","d":1638403,"h":73016082435,"f":2},{"t":131073,"n":"_implementationInstance","d":1638403,"h":94490918915,"f":2},{"t":131073,"n":"_implementationFactory","d":1638403,"h":115965755395,"f":2}],"c":[{"p":[{"n":"serviceType","p":142606337},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":".ctor","o":"$ctor$1","d":1638403,"h":4296605699,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"implementationType","p":142606337},{"n":"lifetime","p":1835011}],"n":".ctor","o":"$ctor$2","d":1638403,"h":8591572995,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"instance","p":131073}],"n":".ctor","o":"$ctor$3","d":1638403,"h":12886540291,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"instance","p":131073}],"n":".ctor","o":"$ctor$4","d":1638403,"h":17181507587,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"factory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":".ctor","o":"$ctor$5","d":1638403,"h":21476474883,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"factory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h},{"n":"lifetime","p":1835011}],"n":".ctor","o":"$ctor$6","d":1638403,"h":25771442179,"f":1},{"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"lifetime","p":1835011}],"n":".ctor","o":"$ctor$7","d":1638403,"h":30066409475,"f":2}],"h":1638403,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceDescriptor`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute", ($self) => class ActivatorUtilitiesConstructorAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 458755;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":458755,"h":4295426051,"f":1}],"h":458755,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructorAttribute`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute", ($self) => class FromKeyedServicesAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*object?*/ key)
            {
                super.$ctor$1();
                {
                    this.Key = key;
                    this.LookupMode = key === null ? 1/*ServiceKeyLookupMode.NullKey*/ : 2/*ServiceKeyLookupMode.ExplicitKey*/;
                }
                return this;
            }
            $ctor$3()
            {
                super.$ctor$1();
                {
                    this.Key = null;
                    this.LookupMode = 0/*ServiceKeyLookupMode.InheritKey*/;
                }
                return this;
            }
            /*object?*/ Key = null;
            /*ServiceKeyLookupMode*/ LookupMode = 0;
            //default member initializer
            constructor()
            {
                super();
                this.LookupMode = 0;
            }
            static $h = 655363;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":131073,"g":{"r":0,"d":0,"h":21475491843,"f":1},"n":"Key","d":655363,"h":17180524547,"f":1},{"p":1769475,"g":{"r":0,"d":0,"h":34360393731,"f":1},"n":"LookupMode","d":655363,"h":30065426435,"f":1}],"c":[{"p":[{"n":"key","p":131073}],"n":".ctor","o":"$ctor$2","d":655363,"h":4295622659,"f":1},{"n":".ctor","o":"$ctor$3","d":655363,"h":8590589955,"f":1}],"h":655363,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2048,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute", ($self) => class ServiceKeyAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1703939;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":1703939,"h":4296671235,"f":1}],"h":1703939,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2048,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute`; }
        });
        
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.AsyncServiceScope", ($self) => class AsyncServiceScope extends $.$spc.System.ValueType
        {
            /*IServiceScope*/  get _serviceScope() { return this.$getField(0, 4); }
            /*IServiceScope*/  set _serviceScope(value) { this.$setField(0, 4, value); }
            $ctor$2(/*IServiceScope*/ serviceScope)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(serviceScope, "serviceScope");
                    this._serviceScope = serviceScope;
                }
                return this;
            }
            /*IServiceProvider */ get ServiceProvider()
            {
                return this._serviceScope.Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider;
            }
            /*void */ Dispose()
            {
                this._serviceScope.System$IDisposable$Dispose();
            }
            /*ValueTask */ DisposeAsync()
            {
                let ad;
                if ($.$is(this._serviceScope, $.$spc.System.IAsyncDisposable, { set $v(v){ ad = v; } }))
                {
                    return ad.System$IAsyncDisposable$DisposeAsync();
                }
                this._serviceScope.System$IDisposable$Dispose();
                return new $.$spc.System.Threading.Tasks.ValueTask();
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider()
            {
                return this.ServiceProvider;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._serviceScope = this._serviceScope;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._serviceScope = null;
            }
            static $h = 524291;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":327717,"g":{"r":0,"d":0,"h":17180393475,"f":1},"n":"ServiceProvider","d":524291,"h":12885426179,"f":1}],"m":[{"r":65537,"n":"Dispose","d":524291,"h":21475360771,"f":1},{"r":136118273,"n":"DisposeAsync","d":524291,"h":25770328067,"f":1}],"l":[{"t":1048579,"n":"_serviceScope","d":524291,"h":4295491587,"f":2}],"c":[{"p":[{"n":"serviceScope","p":1048579}],"n":".ctor","o":"$ctor$2","d":524291,"h":8590458883,"f":1},{"n":".ctor","o":"$ctor$3","d":524291,"h":30065295363,"f":1}],"i":[1048579,57475073,56885249],"h":524291,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{ServiceProvider,nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope, $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.AsyncServiceScope`; }
        });
        
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyLookupMode", ($self) => class ServiceKeyLookupMode extends $.$spc.System.Enum
        {
            static InheritKey = 0;
            static NullKey = 1;
            static ExplicitKey = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "InheritKey": 0n,
                    "NullKey": 1n,
                    "ExplicitKey": 2n
                };
            }
            static $h = 1769475;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1769475,"n":"InheritKey","d":1769475,"h":4296736771,"f":33},{"t":1769475,"n":"NullKey","d":1769475,"h":8591704067,"f":33},{"t":1769475,"n":"ExplicitKey","d":1769475,"h":12886671363,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1769475,"h":17181638659,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1769475}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceKeyLookupMode`; }
        });
        
        $asm.$str("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceLifetime", ($self) => class ServiceLifetime extends $.$spc.System.Enum
        {
            static Singleton = 0;
            static Scoped = 1;
            static Transient = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Singleton": 0n,
                    "Scoped": 1n,
                    "Transient": 2n
                };
            }
            static $h = 1835011;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1835011,"n":"Singleton","d":1835011,"h":4296802307,"f":33},{"t":1835011,"n":"Scoped","d":1835011,"h":8591769603,"f":33},{"t":1835011,"n":"Transient","d":1835011,"h":12886736899,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1835011,"h":17181704195,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1835011}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLifetime`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection", ($self) => class ServiceCollection extends $.$spc.System.Object
        {
            /*List<ServiceDescriptor>*/ _descriptors = null;
            /*bool*/ _isReadOnly = false;
            /*int */ get Count()
            {
                return this._descriptors.Count;
            }
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly;
            }
            /*ServiceDescriptor*/ get_Item(/*int*/ index)
            {
                return this._descriptors.get_Item(index);
            }
            /*void*/ set_Item(/*int*/ index, /*ServiceDescriptor*/ value)
            {
                this.CheckReadOnly();
                this._descriptors.set_Item(index, value);
            }
            /*void */ Clear()
            {
                this.CheckReadOnly();
                this._descriptors.Clear();
            }
            /*bool */ Contains(/*ServiceDescriptor*/ item)
            {
                return this._descriptors.Contains(item);
            }
            /*void */ CopyTo(/*ServiceDescriptor[]*/ array, /*int*/ arrayIndex)
            {
                this._descriptors.CopyTo$2(array, arrayIndex);
            }
            /*bool */ Remove(/*ServiceDescriptor*/ item)
            {
                this.CheckReadOnly();
                return this._descriptors.Remove(item);
            }
            /*IEnumerator<ServiceDescriptor> */ GetEnumerator()
            {
                return this._descriptors.GetEnumerator();
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*ServiceDescriptor*/ item)
            {
                this.CheckReadOnly();
                this._descriptors.Add(item);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*int */ IndexOf(/*ServiceDescriptor*/ item)
            {
                return this._descriptors.IndexOf(item);
            }
            /*void */ Insert(/*int*/ index, /*ServiceDescriptor*/ item)
            {
                this.CheckReadOnly();
                this._descriptors.Insert(index, item);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                this.CheckReadOnly();
                this._descriptors.RemoveAt(index);
            }
            /*void */ MakeReadOnly()
            {
                this._isReadOnly = true;
            }
            /*void */ CheckReadOnly()
            {
                if (this._isReadOnly)
                {
                    $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollection.ThrowReadOnlyException();
                }
            }
            static /*void */ ThrowReadOnlyException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdi.System.SR.ServiceCollectionReadOnly);
            }
            /*string */ DebuggerToString()
            {
                /*string*/ let debugText = `Count = ${this._descriptors.Count}`;
                if (this._isReadOnly)
                {
                    debugText += `, IsReadOnly = true`;
                }
                return debugText;
            }
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].get
            System$Collections$Generic$IList$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.this[int].set
            System$Collections$Generic$IList$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IndexOf(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$IList$$$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Insert(int, Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$IList$$$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.RemoveAt(int)
            System$Collections$Generic$IList$$$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Contains(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.CopyTo(Microsoft.Extensions.DependencyInjection.ServiceDescriptor[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.Remove(Microsoft.Extensions.DependencyInjection.ServiceDescriptor)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.DependencyInjection.ServiceDescriptor>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._descriptors = new ($.$spc.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor))().$ctor$1();
            }
            static $h = 1507331;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181376515,"f":1},"n":"Count","d":1507331,"h":12886409219,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771311107,"f":1},"n":"IsReadOnly","d":1507331,"h":21476343811,"f":1},{"p":1638403,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34361245699,"f":1},"s":{"r":0,"d":0,"h":38656212995,"f":1},"n":"Item","o":"@$2","d":1507331,"h":30066278403,"f":1}],"m":[{"r":65537,"n":"Clear","d":1507331,"h":42951180291,"f":1},{"r":262145,"p":[{"n":"item","p":1638403}],"n":"Contains","d":1507331,"h":47246147587,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":1507331,"h":51541114883,"f":1},{"r":262145,"p":[{"n":"item","p":1638403}],"n":"Remove","d":1507331,"h":55836082179,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,"n":"GetEnumerator","d":1507331,"h":60131049475,"f":1},{"r":655361,"p":[{"n":"item","p":1638403}],"n":"IndexOf","d":1507331,"h":73015951363,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"item","p":1638403}],"n":"Insert","d":1507331,"h":77310918659,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":1507331,"h":81605885955,"f":1},{"r":65537,"n":"MakeReadOnly","d":1507331,"h":85900853251,"f":1},{"r":65537,"n":"CheckReadOnly","d":1507331,"h":90195820547,"f":2},{"r":65537,"n":"ThrowReadOnlyException","d":1507331,"h":94490787843,"f":34},{"r":1310721,"n":"DebuggerToString","d":1507331,"h":98785755139,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,"n":"_descriptors","d":1507331,"h":4296474627,"f":2},{"t":262145,"n":"_isReadOnly","d":1507331,"h":8591441923,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1507331,"h":107375689731,"f":1}],"i":[786435,$.$spc.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,31588353],"h":1507331,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection, $.$spc.System.Collections.Generic.IList$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.Generic.IEnumerable$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollection`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory", ($self) => class ObjectFactory extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*object*/ Invoke(/**/ $serviceProvider, /*$.$typeArray($.$spc.System.Object)*/ $arguments)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1376259;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":131073,"p":[{"n":"serviceProvider","p":327717},{"n":"arguments","p":0}],"n":"Invoke","d":1376259,"h":8591310851,"f":129},{"r":56950785,"p":[{"n":"serviceProvider","p":327717},{"n":"arguments","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1376259,"h":12886278147,"f":129},{"r":131073,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1376259,"h":17181245443,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1376259,"h":4296343555,"f":1}],"i":[57147393,113377281],"h":1376259}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ObjectFactory`; }
        });
        
        $asm.$cls("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory<>", (/*out*/ T) => $asm.$gt("$mxdi.Microsoft.Extensions.DependencyInjection.ObjectFactory<>", [/*out*/ T], ($self) => class ObjectFactory$$ extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*T*/ Invoke(/**/ $serviceProvider, /*$.$typeArray($.$spc.System.Object)*/ $arguments)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1441795;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":T?.$h??1507328,"p":[{"n":"serviceProvider","p":327717},{"n":"arguments","p":0}],"n":"Invoke","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":524417},{"r":56950785,"p":[{"n":"serviceProvider","p":327717},{"n":"arguments","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":T?.$h??1507328,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":524417}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1}],"i":[57147393,113377281],"g":[T?.$h??1507328],"s":[{"n":"T","f":32}],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ObjectFactory<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Linq.Expressions"))