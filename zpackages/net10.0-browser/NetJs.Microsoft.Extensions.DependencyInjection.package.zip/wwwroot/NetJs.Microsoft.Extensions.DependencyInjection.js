
//--TRIMMABLE-BOUNDARY-START(93)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.DependencyInjection", 
    {
  "h": 93,
  "f": "Microsoft.Extensions.DependencyInjection",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.DependencyInjection.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "MicroBenchmarks, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 133824513,
      "c": 8723759105,
      "a": [
        {
          "v": 1507418,
          "t": 187760641
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.DependencyInjection",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1179741)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<,>", (TArgument, TResult) => $asm.$gt("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<,>", [TArgument, TResult], ($self) => class CallSiteVisitor$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296147037)
            /*StackGuard*/ _stackGuard = null;
            //--TRIMMABLE-BOUNDARY-END(4296147037)
            
            //--TRIMMABLE-BOUNDARY-START(8591114333)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stackGuard = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114333)
            
            //--TRIMMABLE-BOUNDARY-START(12886081629)
            /*TResult */ VisitCallSite(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._stackGuard.TryEnterOnCurrentStack())
                {
                    return this._stackGuard.RunOnEmptyStack($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, TArgument, TResult, new ($.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, TArgument, TResult))().$ctor(this, this.VisitCallSite), callSite, argument);
                }
                let $switch1 = callSite.Cache.Location;
                switch($switch1)
                {
                    case 0/*CallSiteResultCacheLocation.Root*/:
                    return this.VisitRootCache(callSite, argument);
                    case 1/*CallSiteResultCacheLocation.Scope*/:
                    return this.VisitScopeCache(callSite, argument);
                    case 2/*CallSiteResultCacheLocation.Dispose*/:
                    return this.VisitDisposeCache(callSite, argument);
                    case 3/*CallSiteResultCacheLocation.None*/:
                    return this.VisitNoCache(callSite, argument);
                    default:
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$15();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886081629)
            
            //--TRIMMABLE-BOUNDARY-START(17181048925)
            /*TResult */ VisitCallSiteMain(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switch1 = callSite.Kind;
                switch($switch1)
                {
                    case 0/*CallSiteKind.Factory*/:
                    return this.VisitFactory($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite), argument);
                    case 3/*CallSiteKind.IEnumerable*/:
                    return this.VisitIEnumerable($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite), argument);
                    case 1/*CallSiteKind.Constructor*/:
                    return this.VisitConstructor($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite), argument);
                    case 2/*CallSiteKind.Constant*/:
                    return this.VisitConstant($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite), argument);
                    case 4/*CallSiteKind.ServiceProvider*/:
                    return this.VisitServiceProvider($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite), argument);
                    default:
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.CallSiteTypeNotSupported, $.$$.System.Object.GetType.call(callSite)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181048925)
            
            //--TRIMMABLE-BOUNDARY-START(42950852701)
            /*TResult */ VisitNoCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950852701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VisitCallSiteMain(callSite, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(42950852701)
            
            //--TRIMMABLE-BOUNDARY-START(30065950813)
            /*TResult */ VisitDisposeCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VisitCallSiteMain(callSite, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950813)
            
            //--TRIMMABLE-BOUNDARY-START(47245819997)
            /*TResult */ VisitRootCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245819997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VisitCallSiteMain(callSite, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(47245819997)
            
            //--TRIMMABLE-BOUNDARY-START(51540787293)
            /*TResult */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540787293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.VisitCallSiteMain(callSite, argument);
            }
            //--TRIMMABLE-BOUNDARY-END(51540787293)
            
            static $h = 1179741;
            static $g = 2;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886081629),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitCallSite",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(12886081629),
//--TRIMMABLE-BOUNDARY-START(17181048925),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitCallSiteMain",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(17181048925),
//--TRIMMABLE-BOUNDARY-START(42950852701),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitNoCache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(42950852701),
//--TRIMMABLE-BOUNDARY-START(30065950813),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitDisposeCache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30065950813),
//--TRIMMABLE-BOUNDARY-START(47245819997),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitRootCache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47245819997),
//--TRIMMABLE-BOUNDARY-START(51540787293),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitScopeCache",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(51540787293),
//--TRIMMABLE-BOUNDARY-START(25770983517),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "constructorCallSite",
          "p": 1376349
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitConstructor",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(25770983517),
//--TRIMMABLE-BOUNDARY-START(21476016221),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitConstant",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(21476016221),
//--TRIMMABLE-BOUNDARY-START(55835754589),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitServiceProvider",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(55835754589),
//--TRIMMABLE-BOUNDARY-START(38655885405),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "enumerableCallSite",
          "p": 1704029
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitIEnumerable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(38655885405),
//--TRIMMABLE-BOUNDARY-START(34360918109),
    {
      "r": TResult?.$h??1572864,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "argument",
          "p": TArgument?.$h??1507328
        }
      ],
      "n": "VisitFactory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(34360918109)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296147037),
    {
      "t": 2949213,
      "n": "_stackGuard",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296147037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114333),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591114333)
  ],
  "g": [TArgument?.$h??1507328,TResult?.$h??1572864
  ],
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<${TArgument?.$fullName},${TResult?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179741)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752605)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine", ($self) => class ServiceProviderEngine extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297719901)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297719901)
            
            static $h = 2752605;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592687197),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 2752605,
      "h": 8592687197,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8592687197)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719901),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2752605,
      "h": 4297719901,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297719901)
  ],
  "h": 2752605
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752605)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424925)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite", ($self) => class ServiceCallSite extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17182294109)
            $ctor$1(/*ResultCache*/ cache, /*object?*/ key)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182294109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Cache = cache.Clone();
                    this.Key = key;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182294109)
            
            //--TRIMMABLE-BOUNDARY-START(21477261405)
            /*ResultCache*/ Cache;
            //--TRIMMABLE-BOUNDARY-END(21477261405)
            
            //--TRIMMABLE-BOUNDARY-START(115966541917)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(115966541917)
            
            //--TRIMMABLE-BOUNDARY-START(94491705437)
            /*object?*/ Key = null;
            //--TRIMMABLE-BOUNDARY-END(94491705437)
            
            //--TRIMMABLE-BOUNDARY-START(25772228701)
            /*bool */ get CaptureDisposable()
            {
                return $.$$.System.Type.op_Equality$1(this.ImplementationType, null) || $.$$.System.IDisposable.$type.IsAssignableFrom(this.ImplementationType) || $.$$.System.IAsyncDisposable.$type.IsAssignableFrom(this.ImplementationType);
            }
            //--TRIMMABLE-BOUNDARY-END(25772228701)
            
            //default member initializer
            constructor()
            {
                super();
                this.Cache = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache);
            }
            static $h = 2424925;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103081640029),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311836253,
        "f": 50331905
      },
      "n": "ServiceType",
      "d": 2424925,
      "h": 103081640029,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103081640029),
//--TRIMMABLE-BOUNDARY-START(90196738141),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542032477,
        "f": 50331905
      },
      "n": "ImplementationType",
      "d": 2424925,
      "h": 90196738141,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90196738141),
//--TRIMMABLE-BOUNDARY-START(98786672733),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721901661,
        "f": 50331905
      },
      "n": "Kind",
      "d": 2424925,
      "h": 98786672733,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98786672733),
//--TRIMMABLE-BOUNDARY-START(21477261405),
    {
      "p": 2097245,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362163293,
        "f": 50331649
      },
      "n": "Cache",
      "d": 2424925,
      "h": 21477261405,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477261405),
//--TRIMMABLE-BOUNDARY-START(115966541917),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901770845,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671574621,
        "f": 83886081
      },
      "n": "Value",
      "d": 2424925,
      "h": 115966541917,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115966541917),
//--TRIMMABLE-BOUNDARY-START(94491705437),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131967069,
        "f": 50331649
      },
      "n": "Key",
      "d": 2424925,
      "h": 94491705437,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491705437),
//--TRIMMABLE-BOUNDARY-START(25772228701),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952097885,
        "f": 50331649
      },
      "n": "CaptureDisposable",
      "d": 2424925,
      "h": 25772228701,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772228701)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182294109),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424925,
      "h": 17182294109,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17182294109)
  ],
  "h": 2424925
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424925)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245277)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine", ($self) => class CompiledServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            //--TRIMMABLE-BOUNDARY-START(25771049053)
            /*ILEmitResolverBuilder*/ ResolverBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(25771049053)
            
            //--TRIMMABLE-BOUNDARY-START(8591179869)
            $ctor$2(/*ServiceProvider*/ provider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder().$ctor$2(provider);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179869)
            
            //--TRIMMABLE-BOUNDARY-START(21476081757)
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476081757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ResolverBuilder.Build(callSite);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476081757)
            
            static $h = 1245277;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2752605,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771049053),
    {
      "p": 1769565,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181114461,
        "f": 50331649
      },
      "n": "ResolverBuilder",
      "d": 1245277,
      "h": 25771049053,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771049053)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476081757),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 1245277,
      "h": 21476081757,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476081757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179869),
    {
      "p": [
        {
          "n": "provider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245277,
      "h": 8591179869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179869)
  ],
  "h": 1245277
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245277)
        
        
        //--TRIMMABLE-BOUNDARY-START(524381)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions", ($self) => class ServiceCollectionContainerBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885426269)
            static /*ServiceProvider */ BuildServiceProvider$2(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$1(services, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(12885426269)
            
            //--TRIMMABLE-BOUNDARY-START(4295491677)
            static /*ServiceProvider */ BuildServiceProvider(/*this IServiceCollection*/ services, /*bool*/ validateScopes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$1(services, (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions;
                    const $i1 = new $t1();
                    $i1.ValidateScopes = validateScopes;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(4295491677)
            
            //--TRIMMABLE-BOUNDARY-START(8590458973)
            static /*ServiceProvider */ BuildServiceProvider$1(/*this IServiceCollection*/ services, /*ServiceProviderOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(options, "options");
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider().$ctor$1(services, options);
            }
            //--TRIMMABLE-BOUNDARY-END(8590458973)
            
            static $h = 524381;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885426269),
    {
      "r": 3080285,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "BuildServiceProvider",
      "o": "@$2",
      "d": 524381,
      "h": 12885426269,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885426269),
//--TRIMMABLE-BOUNDARY-START(4295491677),
    {
      "r": 3080285,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "validateScopes",
          "p": 262145
        }
      ],
      "n": "BuildServiceProvider",
      "d": 524381,
      "h": 4295491677,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295491677),
//--TRIMMABLE-BOUNDARY-START(8590458973),
    {
      "r": 3080285,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "options",
          "p": 3276893
        }
      ],
      "n": "BuildServiceProvider",
      "o": "@$1",
      "d": 524381,
      "h": 8590458973,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590458973)
  ],
  "h": 524381
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524381)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490461)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions", ($self) => class ServiceDescriptorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(21477326941)
            static /*bool */ HasImplementationInstance(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477326941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(serviceDescriptor) !== null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477326941)
            
            //--TRIMMABLE-BOUNDARY-START(17182359645)
            static /*bool */ HasImplementationFactory(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182359645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationFactory(serviceDescriptor) !== null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182359645)
            
            //--TRIMMABLE-BOUNDARY-START(25772294237)
            static /*bool */ HasImplementationType(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772294237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Type.op_Inequality$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(serviceDescriptor), null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772294237)
            
            //--TRIMMABLE-BOUNDARY-START(8592425053)
            static /*object? */ GetImplementationInstance(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592425053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationInstance : serviceDescriptor.ImplementationInstance;
            }
            //--TRIMMABLE-BOUNDARY-END(8592425053)
            
            //--TRIMMABLE-BOUNDARY-START(4297457757)
            static /*object? */ GetImplementationFactory(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationFactory : serviceDescriptor.ImplementationFactory;
            }
            //--TRIMMABLE-BOUNDARY-END(4297457757)
            
            //--TRIMMABLE-BOUNDARY-START(12887392349)
            static /*Type? */ GetImplementationType(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887392349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationType : serviceDescriptor.ImplementationType;
            }
            //--TRIMMABLE-BOUNDARY-END(12887392349)
            
            //--TRIMMABLE-BOUNDARY-START(30067261533)
            static /*bool */ TryGetImplementationType(/*this ServiceDescriptor*/ serviceDescriptor, /*out Type?*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067261533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                type.$v = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(serviceDescriptor);
                return $.$$.System.Type.op_Inequality$1(type.$v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(30067261533)
            
            static $h = 2490461;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477326941),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "HasImplementationInstance",
      "d": 2490461,
      "h": 21477326941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477326941),
//--TRIMMABLE-BOUNDARY-START(17182359645),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "HasImplementationFactory",
      "d": 2490461,
      "h": 17182359645,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182359645),
//--TRIMMABLE-BOUNDARY-START(25772294237),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "HasImplementationType",
      "d": 2490461,
      "h": 25772294237,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772294237),
//--TRIMMABLE-BOUNDARY-START(8592425053),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "GetImplementationInstance",
      "d": 2490461,
      "h": 8592425053,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592425053),
//--TRIMMABLE-BOUNDARY-START(4297457757),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "GetImplementationFactory",
      "d": 2490461,
      "h": 4297457757,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457757),
//--TRIMMABLE-BOUNDARY-START(12887392349),
    {
      "r": 187760641,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "GetImplementationType",
      "d": 2490461,
      "h": 12887392349,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887392349),
//--TRIMMABLE-BOUNDARY-START(30067261533),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        },
        {
          "n": "type",
          "p": 187760641,
          "f": 2
        }
      ],
      "n": "TryGetImplementationType",
      "d": 2490461,
      "h": 30067261533,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067261533)
  ],
  "h": 2490461
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490461)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621533)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers", ($self) => class ServiceLookupHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(30067392605)
            /*BindingFlags*/ static LookupFlags = 52;
            //--TRIMMABLE-BOUNDARY-END(30067392605)
            
            //--TRIMMABLE-BOUNDARY-START(12887523421)
            /*MethodInfo*/ static ArrayEmptyMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(12887523421)
            
            //--TRIMMABLE-BOUNDARY-START(25772425309)
            /*MethodInfo*/ static InvokeFactoryMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(25772425309)
            
            //--TRIMMABLE-BOUNDARY-START(17182490717)
            /*MethodInfo*/ static CaptureDisposableMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(17182490717)
            
            //--TRIMMABLE-BOUNDARY-START(47247261789)
            /*MethodInfo*/ static TryGetValueMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(47247261789)
            
            //--TRIMMABLE-BOUNDARY-START(42952294493)
            /*MethodInfo*/ static ResolveCallSiteAndScopeMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(42952294493)
            
            //--TRIMMABLE-BOUNDARY-START(8592556125)
            /*MethodInfo*/ static AddMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(8592556125)
            
            //--TRIMMABLE-BOUNDARY-START(34362359901)
            /*MethodInfo*/ static MonitorEnterMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(34362359901)
            
            //--TRIMMABLE-BOUNDARY-START(38657327197)
            /*MethodInfo*/ static MonitorExitMethodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(38657327197)
            
            //--TRIMMABLE-BOUNDARY-START(21477458013)
            static /*MethodInfo */ GetArrayEmptyMethodInfo(/*Type*/ itemType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477458013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.ArrayEmptyMethodInfo.MakeGenericMethod($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ itemType ], null, null));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477458013)
            
            //--TRIMMABLE-BOUNDARY-START(4297588829)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12887523421)
                    this.ArrayEmptyMethodInfo = $.$$.System.Array.$type.GetMethod$12("Empty");
                    //--TRIMMABLE-BOUNDARY-END(12887523421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25772425309)
                    this.InvokeFactoryMethodInfo = $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$type.GetMethod$9("Invoke", 52/*LookupFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(25772425309)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17182490717)
                    this.CaptureDisposableMethodInfo = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetMethod$9("CaptureDisposable", 52/*LookupFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(17182490717)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47247261789)
                    this.TryGetValueMethodInfo = $.$$.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object).$type.GetMethod$9("TryGetValue", 52/*LookupFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(47247261789)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42952294493)
                    this.ResolveCallSiteAndScopeMethodInfo = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetMethod$9("Resolve", 52/*LookupFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(42952294493)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8592556125)
                    this.AddMethodInfo = $.$$.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object).$type.GetMethod$9("Add", 52/*LookupFlags*/);
                    //--TRIMMABLE-BOUNDARY-END(8592556125)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34362359901)
                    this.MonitorEnterMethodInfo = $.$$.System.Threading.Monitor.$type.GetMethod$7("Enter", 16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/, null, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.Object.$type, $.$$.System.Boolean.$type.MakeByRefType()], [-1], null), null);
                    //--TRIMMABLE-BOUNDARY-END(34362359901)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38657327197)
                    this.MonitorExitMethodInfo = $.$$.System.Threading.Monitor.$type.GetMethod$7("Exit", 16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/, null, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$$.System.Object.$type], [-1], null), null);
                    //--TRIMMABLE-BOUNDARY-END(38657327197)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297588829)
            
            static $h = 2621533;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477458013),
    {
      "r": 116850689,
      "p": [
        {
          "n": "itemType",
          "p": 187760641
        }
      ],
      "n": "GetArrayEmptyMethodInfo",
      "d": 2621533,
      "h": 21477458013,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21477458013)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067392605),
    {
      "t": 108331009,
      "n": "LookupFlags",
      "d": 2621533,
      "h": 30067392605,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30067392605),
//--TRIMMABLE-BOUNDARY-START(12887523421),
    {
      "t": 116850689,
      "n": "ArrayEmptyMethodInfo",
      "d": 2621533,
      "h": 12887523421,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887523421),
//--TRIMMABLE-BOUNDARY-START(25772425309),
    {
      "t": 116850689,
      "n": "InvokeFactoryMethodInfo",
      "d": 2621533,
      "h": 25772425309,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25772425309),
//--TRIMMABLE-BOUNDARY-START(17182490717),
    {
      "t": 116850689,
      "n": "CaptureDisposableMethodInfo",
      "d": 2621533,
      "h": 17182490717,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17182490717),
//--TRIMMABLE-BOUNDARY-START(47247261789),
    {
      "t": 116850689,
      "n": "TryGetValueMethodInfo",
      "d": 2621533,
      "h": 47247261789,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47247261789),
//--TRIMMABLE-BOUNDARY-START(42952294493),
    {
      "t": 116850689,
      "n": "ResolveCallSiteAndScopeMethodInfo",
      "d": 2621533,
      "h": 42952294493,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42952294493),
//--TRIMMABLE-BOUNDARY-START(8592556125),
    {
      "t": 116850689,
      "n": "AddMethodInfo",
      "d": 2621533,
      "h": 8592556125,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8592556125),
//--TRIMMABLE-BOUNDARY-START(34362359901),
    {
      "t": 116850689,
      "n": "MonitorEnterMethodInfo",
      "d": 2621533,
      "h": 34362359901,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34362359901),
//--TRIMMABLE-BOUNDARY-START(38657327197),
    {
      "t": 116850689,
      "n": "MonitorExitMethodInfo",
      "d": 2621533,
      "h": 38657327197,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38657327197)
  ],
  "h": 2621533
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621533)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014749)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper", ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17182883933)
            static /*void */ ThrowObjectDisposedException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182883933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.ObjectDisposedException().$ctor$17("IServiceProvider");
            }
            //--TRIMMABLE-BOUNDARY-END(17182883933)
            
            //--TRIMMABLE-BOUNDARY-START(4297982045)
            static /*void */ ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297982045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$5($.$med.System.SR.KeyedServiceAnyKeyUsedToResolveService, "IServiceProvider", "IServiceScopeFactory"));
            }
            //--TRIMMABLE-BOUNDARY-END(4297982045)
            
            //--TRIMMABLE-BOUNDARY-START(12887916637)
            static /*void */ ThrowInvalidOperationException_NoServiceRegistered(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887916637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.NoServiceRegistered, serviceType));
            }
            //--TRIMMABLE-BOUNDARY-END(12887916637)
            
            //--TRIMMABLE-BOUNDARY-START(8592949341)
            static /*void */ ThrowInvalidOperationException_NoKeyedServiceRegistered(/*Type*/ serviceType, /*Type*/ keyType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592949341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$5($.$med.System.SR.NoKeyedServiceRegistered, serviceType, keyType));
            }
            //--TRIMMABLE-BOUNDARY-END(8592949341)
            
            static $h = 3014749;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182883933),
    {
      "r": 65537,
      "n": "ThrowObjectDisposedException",
      "d": 3014749,
      "h": 17182883933,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17182883933),
//--TRIMMABLE-BOUNDARY-START(4297982045),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService",
      "d": 3014749,
      "h": 4297982045,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4297982045),
//--TRIMMABLE-BOUNDARY-START(12887916637),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "ThrowInvalidOperationException_NoServiceRegistered",
      "d": 3014749,
      "h": 12887916637,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12887916637),
//--TRIMMABLE-BOUNDARY-START(8592949341),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "keyType",
          "p": 187760641
        }
      ],
      "n": "ThrowInvalidOperationException_NoKeyedServiceRegistered",
      "d": 3014749,
      "h": 8592949341,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8592949341)
  ],
  "h": 3014749
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014749)
        
        
        //--TRIMMABLE-BOUNDARY-START(3539037)
        $asm.$cls("$med.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(481039876189)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(481039876189)
            
            //--TRIMMABLE-BOUNDARY-START(472449941597)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(472449941597)
            
            //--TRIMMABLE-BOUNDARY-START(476744908893)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356485824605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$med.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.DependencyInjection", $.$med.System.SR.$type.Assembly);
                    $.$med.System.SR.s_resourceManager = temp;
                }
                return $.$med.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(476744908893)
            
            //--TRIMMABLE-BOUNDARY-START(47248179293)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261996544093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506809679965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$med.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47248179293)
            
            //--TRIMMABLE-BOUNDARY-START(8593473629)
            static /*string */ get AmbiguousConstructorException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184687132765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to activate type '{0}'. The following constructors are ambiguous:";
            }
            //--TRIMMABLE-BOUNDARY-END(8593473629)
            
            //--TRIMMABLE-BOUNDARY-START(90197852253)
            static /*string */ FormatAmbiguousConstructorException(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197852253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unable to activate type '{0}'. The following constructors are ambiguous:", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(90197852253)
            
            //--TRIMMABLE-BOUNDARY-START(34363277405)
            static /*string */ get CannotResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236226740317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(34363277405)
            
            //--TRIMMABLE-BOUNDARY-START(115967656029)
            static /*string */ FormatCannotResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967656029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(115967656029)
            
            //--TRIMMABLE-BOUNDARY-START(38658244701)
            static /*string */ get CircularDependencyException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244816674909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A circular dependency was detected for the service of type '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(38658244701)
            
            //--TRIMMABLE-BOUNDARY-START(120262623325)
            static /*string */ FormatCircularDependencyException(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262623325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A circular dependency was detected for the service of type '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120262623325)
            
            //--TRIMMABLE-BOUNDARY-START(523989549149)
            static /*string */ get UnableToActivateTypeException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416615366749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No constructor for type '{0}' can be instantiated using services from the service container and default values.";
            }
            //--TRIMMABLE-BOUNDARY-END(523989549149)
            
            //--TRIMMABLE-BOUNDARY-START(176097198173)
            static /*string */ FormatUnableToActivateTypeException(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176097198173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("No constructor for type '{0}' can be instantiated using services from the service container and default values.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176097198173)
            
            //--TRIMMABLE-BOUNDARY-START(468154974301)
            static /*string */ get OpenGenericServiceRequiresOpenGenericImplementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347895890013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Open generic service type '{0}' requires registering an open generic implementation type.";
            }
            //--TRIMMABLE-BOUNDARY-END(468154974301)
            
            //--TRIMMABLE-BOUNDARY-START(150327394397)
            static /*string */ FormatOpenGenericServiceRequiresOpenGenericImplementation(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327394397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Open generic service type '{0}' requires registering an open generic implementation type.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(150327394397)
            
            //--TRIMMABLE-BOUNDARY-START(21478375517)
            static /*string */ get ArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210456936541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Arity of open generic service type '{0}' does not equal arity of open generic implementation type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(21478375517)
            
            //--TRIMMABLE-BOUNDARY-START(103082754141)
            static /*string */ FormatArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082754141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Arity of open generic service type '{0}' does not equal arity of open generic implementation type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(103082754141)
            
            //--TRIMMABLE-BOUNDARY-START(519694581853)
            static /*string */ get TypeCannotBeActivated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408025432157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot instantiate implementation type '{0}' for service type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(519694581853)
            
            //--TRIMMABLE-BOUNDARY-START(171802230877)
            static /*string */ FormatTypeCannotBeActivated(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171802230877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Cannot instantiate implementation type '{0}' for service type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(171802230877)
            
            //--TRIMMABLE-BOUNDARY-START(455270072413)
            static /*string */ get NoConstructorMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322126086237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.";
            }
            //--TRIMMABLE-BOUNDARY-END(455270072413)
            
            //--TRIMMABLE-BOUNDARY-START(137442492509)
            static /*string */ FormatNoConstructorMatch(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442492509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(137442492509)
            
            //--TRIMMABLE-BOUNDARY-START(489629810781)
            static /*string */ get ScopedInSingletonException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365075759197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot consume {2} service '{0}' from {3} '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(489629810781)
            
            //--TRIMMABLE-BOUNDARY-START(154622361693)
            static /*string */ FormatScopedInSingletonException(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622361693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$11("Cannot consume {2} service '{0}' from {3} '{1}'.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(154622361693)
            
            //--TRIMMABLE-BOUNDARY-START(493924778077)
            static /*string */ get ScopedResolvedFromRootException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373665693789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot resolve '{0}' from root provider because it requires {2} service '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(493924778077)
            
            //--TRIMMABLE-BOUNDARY-START(158917328989)
            static /*string */ FormatScopedResolvedFromRootException(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917328989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Cannot resolve '{0}' from root provider because it requires {2} service '{1}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(158917328989)
            
            //--TRIMMABLE-BOUNDARY-START(51543146589)
            static /*string */ get DirectScopedResolvedFromRootException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270586478685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot resolve {1} service '{0}' from root provider.";
            }
            //--TRIMMABLE-BOUNDARY-END(51543146589)
            
            //--TRIMMABLE-BOUNDARY-START(128852557917)
            static /*string */ FormatDirectScopedResolvedFromRootException(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852557917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Cannot resolve {1} service '{0}' from root provider.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(128852557917)
            
            //--TRIMMABLE-BOUNDARY-START(42953211997)
            static /*string */ get ConstantCantBeConvertedToServiceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253406609501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Constant value of type '{0}' can't be converted to service type '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(42953211997)
            
            //--TRIMMABLE-BOUNDARY-START(124557590621)
            static /*string */ FormatConstantCantBeConvertedToServiceType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124557590621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Constant value of type '{0}' can't be converted to service type '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(124557590621)
            
            //--TRIMMABLE-BOUNDARY-START(438090203229)
            static /*string */ get ImplementationTypeCantBeConvertedToServiceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287766347869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Implementation type '{0}' can't be converted to service type '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(438090203229)
            
            //--TRIMMABLE-BOUNDARY-START(133147525213)
            static /*string */ FormatImplementationTypeCantBeConvertedToServiceType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147525213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Implementation type '{0}' can't be converted to service type '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(133147525213)
            
            //--TRIMMABLE-BOUNDARY-START(25773342813)
            static /*string */ get AsyncDisposableServiceDispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046871133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' type only implements IAsyncDisposable. Use DisposeAsync to dispose the container.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773342813)
            
            //--TRIMMABLE-BOUNDARY-START(107377721437)
            static /*string */ FormatAsyncDisposableServiceDispose(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377721437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("'{0}' type only implements IAsyncDisposable. Use DisposeAsync to dispose the container.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(107377721437)
            
            //--TRIMMABLE-BOUNDARY-START(420910334045)
            static /*string */ get GetCaptureDisposableNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279176413277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "GetCaptureDisposable call is supported only for main scope";
            }
            //--TRIMMABLE-BOUNDARY-END(420910334045)
            
            //--TRIMMABLE-BOUNDARY-START(442385170525)
            static /*string */ get InvalidServiceDescriptor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296356282461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Invalid service descriptor";
            }
            //--TRIMMABLE-BOUNDARY-END(442385170525)
            
            //--TRIMMABLE-BOUNDARY-START(498219745373)
            static /*string */ get ServiceDescriptorNotExist()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382255628381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Requested service descriptor doesn't exist.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219745373)
            
            //--TRIMMABLE-BOUNDARY-START(30068310109)
            static /*string */ get CallSiteTypeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227636805725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Call site type {0} is not supported";
            }
            //--TRIMMABLE-BOUNDARY-END(30068310109)
            
            //--TRIMMABLE-BOUNDARY-START(111672688733)
            static /*string */ FormatCallSiteTypeNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672688733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Call site type {0} is not supported", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111672688733)
            
            //--TRIMMABLE-BOUNDARY-START(511104647261)
            static /*string */ get TrimmingAnnotationsDoNotMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399435497565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Generic implementation type '{0}' has a DynamicallyAccessedMembers attribute applied to a generic argument type, but the service type '{1}' doesn't have a matching DynamicallyAccessedMembers attribute on its generic argument type.";
            }
            //--TRIMMABLE-BOUNDARY-END(511104647261)
            
            //--TRIMMABLE-BOUNDARY-START(167507263581)
            static /*string */ FormatTrimmingAnnotationsDoNotMatch(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507263581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Generic implementation type '{0}' has a DynamicallyAccessedMembers attribute applied to a generic argument type, but the service type '{1}' doesn't have a matching DynamicallyAccessedMembers attribute on its generic argument type.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(167507263581)
            
            //--TRIMMABLE-BOUNDARY-START(515399614557)
            static /*string */ get TrimmingAnnotationsDoNotMatch_NewConstraint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390845562973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Generic implementation type '{0}' has a DefaultConstructorConstraint ('new()' constraint), but the generic service type '{1}' doesn't.";
            }
            //--TRIMMABLE-BOUNDARY-END(515399614557)
            
            //--TRIMMABLE-BOUNDARY-START(163212296285)
            static /*string */ FormatTrimmingAnnotationsDoNotMatch_NewConstraint(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212296285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Generic implementation type '{0}' has a DefaultConstructorConstraint ('new()' constraint), but the generic service type '{1}' doesn't.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(163212296285)
            
            //--TRIMMABLE-BOUNDARY-START(12888440925)
            static /*string */ get AotCannotCreateEnumerableValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193277067357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to create an Enumerable service of type '{0}' because it is a ValueType. Native code to support creating Enumerable services might not be available with native AOT.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888440925)
            
            //--TRIMMABLE-BOUNDARY-START(94492819549)
            static /*string */ FormatAotCannotCreateEnumerableValueType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492819549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unable to create an Enumerable service of type '{0}' because it is a ValueType. Native code to support creating Enumerable services might not be available with native AOT.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(94492819549)
            
            //--TRIMMABLE-BOUNDARY-START(17183408221)
            static /*string */ get AotCannotCreateGenericValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201867001949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to create a generic service for type '{0}' because '{1}' is a ValueType. Native code to support creating generic services might not be available with native AOT.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183408221)
            
            //--TRIMMABLE-BOUNDARY-START(98787786845)
            static /*string */ FormatAotCannotCreateGenericValueType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787786845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Unable to create a generic service for type '{0}' because '{1}' is a ValueType. Native code to support creating generic services might not be available with native AOT.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(98787786845)
            
            //--TRIMMABLE-BOUNDARY-START(463860007005)
            static /*string */ get NoServiceRegistered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339305955421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No service for type '{0}' has been registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(463860007005)
            
            //--TRIMMABLE-BOUNDARY-START(146032427101)
            static /*string */ FormatNoServiceRegistered(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032427101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("No service for type '{0}' has been registered.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146032427101)
            
            //--TRIMMABLE-BOUNDARY-START(446680137821)
            static /*string */ get InvalidServiceKeyType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304946217053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type of the key used for lookup doesn't match the type in the constructor parameter with the ServiceKey attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(446680137821)
            
            //--TRIMMABLE-BOUNDARY-START(450975105117)
            static /*string */ get KeyedServiceAnyKeyUsedToResolveService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313536151645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "KeyedService.AnyKey cannot be used to resolve a single service.";
            }
            //--TRIMMABLE-BOUNDARY-END(450975105117)
            
            //--TRIMMABLE-BOUNDARY-START(459565039709)
            static /*string */ get NoKeyedServiceRegistered()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330716020829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No keyed service for type '{0}' using key type '{1}' has been registered.";
            }
            //--TRIMMABLE-BOUNDARY-END(459565039709)
            
            //--TRIMMABLE-BOUNDARY-START(141737459805)
            static /*string */ FormatNoKeyedServiceRegistered(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737459805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("No keyed service for type '{0}' using key type '{1}' has been registered.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(141737459805)
            
            //--TRIMMABLE-BOUNDARY-START(485334843485)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(485334843485)
            
            //--TRIMMABLE-BOUNDARY-START(433795235933)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(433795235933);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(433795235933)
            
            //--TRIMMABLE-BOUNDARY-START(528284516445)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(528284516445);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$med.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(528284516445)
            
            //--TRIMMABLE-BOUNDARY-START(429500268637)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429500268637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$med.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(429500268637)
            
            //--TRIMMABLE-BOUNDARY-START(425205301341)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425205301341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$med.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(425205301341)
            
            //--TRIMMABLE-BOUNDARY-START(81607917661)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607917661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(81607917661)
            
            //--TRIMMABLE-BOUNDARY-START(77312950365)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312950365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(77312950365)
            
            //--TRIMMABLE-BOUNDARY-START(73017983069)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017983069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(73017983069)
            
            //--TRIMMABLE-BOUNDARY-START(85902884957)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902884957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$med.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(85902884957)
            
            //--TRIMMABLE-BOUNDARY-START(64428048477)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428048477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(64428048477)
            
            //--TRIMMABLE-BOUNDARY-START(60133081181)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133081181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60133081181)
            
            //--TRIMMABLE-BOUNDARY-START(55838113885)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55838113885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(55838113885)
            
            //--TRIMMABLE-BOUNDARY-START(68723015773)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723015773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$med.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68723015773)
            
            //--TRIMMABLE-BOUNDARY-START(4298506333)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(485334843485)
                    this.s_usingResourceKeys = $.$med.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(485334843485)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298506333)
            
            static $h = 3539037;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3539037
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3539037)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342429)
        $asm.$cls("$med.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            //--TRIMMABLE-BOUNDARY-START(8593277021)
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593277021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$med.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$$.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$$.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        {
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                        }
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$$.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$$.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$$.System.Enum.ToObject$4(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(8593277021)
            
            //--TRIMMABLE-BOUNDARY-START(4298309725)
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298309725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(4298309725)
            
            static $h = 3342429;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593277021),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "defaultValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryGetDefaultValue",
      "d": 3342429,
      "h": 8593277021,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593277021),
//--TRIMMABLE-BOUNDARY-START(4298309725),
    {
      "r": 262145,
      "p": [
        {
          "n": "parameter",
          "p": 118358017
        },
        {
          "n": "tryToGetDefaultValue",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "CheckHasDefaultValue",
      "d": 3342429,
      "h": 4298309725,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298309725)
  ],
  "h": 3342429
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342429)
        
        
        //--TRIMMABLE-BOUNDARY-START(3407965)
        $asm.$cls("$med.Microsoft.Extensions.Internal.TypeNameHelper", ($self) => class TypeNameHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17183277149)
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            //--TRIMMABLE-BOUNDARY-END(17183277149)
            
            //--TRIMMABLE-BOUNDARY-START(4298375261)
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            //--TRIMMABLE-BOUNDARY-END(4298375261)
            
            //--TRIMMABLE-BOUNDARY-START(21478244445)
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478244445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return item === null ? null : $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1($.$$.System.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            //--TRIMMABLE-BOUNDARY-END(21478244445)
            
            //--TRIMMABLE-BOUNDARY-START(25773211741)
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773211741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), type, $.$ref(() => new $.$med.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions().$ctor$3(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                const $t2 = builder;
                return name ?? $.$ifnn($t2, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(25773211741)
            
            //--TRIMMABLE-BOUNDARY-START(38658113629)
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658113629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let builtInName;
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                    $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                    $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$med.Microsoft.Extensions.Internal.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$$.System.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$19(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$19(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$$.System.String.Replace.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$19(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38658113629)
            
            //--TRIMMABLE-BOUNDARY-START(30068179037)
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068179037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$3(/*[*/ 91);
                    builder.Append$2(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$3(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30068179037)
            
            //--TRIMMABLE-BOUNDARY-START(34363146333)
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363146333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$3(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$$.System.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$19(type.Namespace);
                        builder.Append$3(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$$.System.String.IndexOf$3.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$19(type.Name);
                    return;
                }
                builder.Append$18(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$3(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), $.$$.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$3(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$$.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$3(/* */ 32);
                        }
                    }
                    builder.Append$3(/*>*/ 62);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34363146333)
            
            //--TRIMMABLE-BOUNDARY-START(3473501)
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                let $cls = $.$med.Microsoft.Extensions.Internal.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr("$med.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions", ($self) => class DisplayNameOptions extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25773277277)
                    $ctor$3(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25773277277);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25773277277)
                    
                    //--TRIMMABLE-BOUNDARY-START(30068244573)
                    /*bool*/ FullName = false;
                    //--TRIMMABLE-BOUNDARY-END(30068244573)
                    
                    //--TRIMMABLE-BOUNDARY-START(73017917533)
                    /*bool*/ IncludeGenericParameters = false;
                    //--TRIMMABLE-BOUNDARY-END(73017917533)
                    
                    //--TRIMMABLE-BOUNDARY-START(68722950237)
                    /*bool*/ IncludeGenericParameterNames = false;
                    //--TRIMMABLE-BOUNDARY-END(68722950237)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312884829)
                    /*char*/ NestedTypeDelimiter = 0;
                    //--TRIMMABLE-BOUNDARY-END(77312884829)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478309981)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21478309981)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    static $h = 3473501;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30068244573),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38658179165,
        "f": 50331649
      },
      "n": "FullName",
      "d": 3473501,
      "h": 30068244573,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30068244573),
//--TRIMMABLE-BOUNDARY-START(73017917533),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55838048349,
        "f": 50331649
      },
      "n": "IncludeGenericParameters",
      "d": 3473501,
      "h": 73017917533,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017917533),
//--TRIMMABLE-BOUNDARY-START(68722950237),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47248113757,
        "f": 50331649
      },
      "n": "IncludeGenericParameterNames",
      "d": 3473501,
      "h": 68722950237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722950237),
//--TRIMMABLE-BOUNDARY-START(77312884829),
    {
      "p": 458753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64427982941,
        "f": 50331649
      },
      "n": "NestedTypeDelimiter",
      "d": 3473501,
      "h": 77312884829,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312884829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25773277277),
    {
      "p": [
        {
          "n": "fullName",
          "p": 262145
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145
        },
        {
          "n": "includeGenericParameters",
          "p": 262145
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3473501,
      "h": 25773277277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773277277),
//--TRIMMABLE-BOUNDARY-START(21478309981),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3473501,
      "h": 21478309981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21478309981)
  ],
  "d": 3407965,
  "h": 3473501
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3473501)
            
            //--TRIMMABLE-BOUNDARY-START(12888309853)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4298375261)
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$$.System.Void.$type, "void");
                        $i1.Add($.$$.System.Boolean.$type, "bool");
                        $i1.Add($.$$.System.Byte.$type, "byte");
                        $i1.Add($.$$.System.Char.$type, "char");
                        $i1.Add($.$$.System.Decimal.$type, "decimal");
                        $i1.Add($.$$.System.Double.$type, "double");
                        $i1.Add($.$$.System.Single.$type, "float");
                        $i1.Add($.$$.System.Int32.$type, "int");
                        $i1.Add($.$$.System.Int64.$type, "long");
                        $i1.Add($.$$.System.Object.$type, "object");
                        $i1.Add($.$$.System.SByte.$type, "sbyte");
                        $i1.Add($.$$.System.Int16.$type, "short");
                        $i1.Add($.$$.System.String.$type, "string");
                        $i1.Add($.$$.System.UInt32.$type, "uint");
                        $i1.Add($.$$.System.UInt64.$type, "ulong");
                        $i1.Add($.$$.System.UInt16.$type, "ushort");
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4298375261)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888309853)
            
            static $h = 3407965;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21478244445),
    {
      "r": 1310721,
      "p": [
        {
          "n": "item",
          "p": 131073
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetTypeDisplayName",
      "d": 3407965,
      "h": 21478244445,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21478244445),
//--TRIMMABLE-BOUNDARY-START(25773211741),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "includeGenericParameters",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753,
          "f": 65,
          "v": "\u002B"
        }
      ],
      "n": "GetTypeDisplayName",
      "o": "@$1",
      "d": 3407965,
      "h": 25773211741,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25773211741),
//--TRIMMABLE-BOUNDARY-START(38658113629),
    {
      "r": 1310721,
      "p": [
        {
          "n": "builder",
          "p": 167051265,
          "f": 4
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "options",
          "p": 3473501,
          "f": 8
        }
      ],
      "n": "ProcessType",
      "d": 3407965,
      "h": 38658113629,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38658113629),
//--TRIMMABLE-BOUNDARY-START(30068179037),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "options",
          "p": 3473501,
          "f": 8
        }
      ],
      "n": "ProcessArrayType",
      "d": 3407965,
      "h": 30068179037,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30068179037),
//--TRIMMABLE-BOUNDARY-START(34363146333),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "genericArguments",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "options",
          "p": 3473501,
          "f": 8
        }
      ],
      "n": "ProcessGenericType",
      "d": 3407965,
      "h": 34363146333,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34363146333)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17183277149),
    {
      "t": 458753,
      "n": "DefaultNestedTypeDelimiter",
      "d": 3407965,
      "h": 17183277149,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17183277149),
//--TRIMMABLE-BOUNDARY-START(4298375261),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String).$h,
      "n": "_builtInTypeNames",
      "d": 3407965,
      "h": 4298375261,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298375261)
  ],
  "j": [3473501
  ],
  "h": 3407965
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407965)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276893)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions", ($self) => class ServiceProviderOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21478113373)
            /*ServiceProviderOptions*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21478113373)
            
            //--TRIMMABLE-BOUNDARY-START(64427786333)
            /*bool*/ ValidateScopes = false;
            //--TRIMMABLE-BOUNDARY-END(64427786333)
            
            //--TRIMMABLE-BOUNDARY-START(60132819037)
            /*bool*/ ValidateOnBuild = false;
            //--TRIMMABLE-BOUNDARY-END(60132819037)
            
            //--TRIMMABLE-BOUNDARY-START(17183146077)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183146077)
            
            //--TRIMMABLE-BOUNDARY-START(12888178781)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21478113373)
                    this.Default = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21478113373)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888178781)
            
            static $h = 3276893;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64427786333),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657982557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837851741,
        "f": 83886081
      },
      "n": "ValidateScopes",
      "d": 3276893,
      "h": 64427786333,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427786333),
//--TRIMMABLE-BOUNDARY-START(60132819037),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30068047965,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247917149,
        "f": 83886081
      },
      "n": "ValidateOnBuild",
      "d": 3276893,
      "h": 60132819037,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60132819037)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21478113373),
    {
      "t": 3276893,
      "n": "Default",
      "d": 3276893,
      "h": 21478113373,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21478113373)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183146077),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3276893,
      "h": 17183146077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183146077)
  ],
  "h": 3276893
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276893)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949213)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard", ($self) => class StackGuard extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887851101)
            /*int*/ static MaxExecutionStackCount = 1024;
            //--TRIMMABLE-BOUNDARY-END(12887851101)
            
            //--TRIMMABLE-BOUNDARY-START(4297916509)
            /*int*/ _executionStackCount = 0;
            //--TRIMMABLE-BOUNDARY-END(4297916509)
            
            //--TRIMMABLE-BOUNDARY-START(25772752989)
            /*bool */ TryEnterOnCurrentStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772752989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Runtime.CompilerServices.RuntimeHelpers.TryEnsureSufficientExecutionStack())
                {
                    return true;
                }
                if (this._executionStackCount < 1024/*MaxExecutionStackCount*/)
                {
                    return false;
                }
                throw new $.$$.System.InsufficientExecutionStackException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(25772752989)
            
            //--TRIMMABLE-BOUNDARY-START(17182818397)
            /*TR */ RunOnEmptyStack(T1, T2, TR, /*Func<T1, T2, TR>*/ action, /*T1*/ arg1, /*T2*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RunOnEmptyStackCore(TR, new ($.$$.System.Func$$$($.$$.System.Object, TR))().$ctor($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard, /*static*/ (/*s*/ s) =>
                {
                    /*var*/ let t = $.$cast(s, $.$$.System.ValueTuple$$$$($.$$.System.Func$$$$(T1, T2, TR), T1, T2));
                    return t.Item1.Invoke(t.Item2, t.Item3);
                }, {
  "r": (T1, T2, TR) => TR.$h,
  "p": [
    {
      "n": "s",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2949213,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$$($.$$.System.Func$$$$(T1, T2, TR), T1, T2))().$ctor$3(action, arg1, arg2));
            }
            //--TRIMMABLE-BOUNDARY-END(17182818397)
            
            //--TRIMMABLE-BOUNDARY-START(21477785693)
            /*R */ RunOnEmptyStackCore(R, /*Func<object, R>*/ action, /*object*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477785693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._executionStackCount++;
                try
                {
                    /*Task<R>*/ let task = $.$$.System.Threading.Tasks.Task.Factory.StartNew$8(R, action, state, $.$$.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.System.Threading.Tasks.TaskScheduler.Default);
                    if (!task.IsCompleted)
                    {
                        (task).System$IAsyncResult$AsyncWaitHandle.WaitOne();
                    }
                    return task.GetAwaiter$1().GetResult();
                }
                finally
                {
                    {
                        this._executionStackCount--;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477785693)
            
            //--TRIMMABLE-BOUNDARY-START(8592883805)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592883805)
            
            static $h = 2949213;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772752989),
    {
      "r": 262145,
      "n": "TryEnterOnCurrentStack",
      "d": 2949213,
      "h": 25772752989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772752989),
//--TRIMMABLE-BOUNDARY-START(17182818397),
    {
      "r": (T1, T2, TR) => TR.$h,
      "p": [
        {
          "n": "action",
          "p": (T1, T2, TR) => $.$$.System.Func$$$$(T1, T2, TR).$h
        },
        {
          "n": "arg1",
          "p": (T1, T2, TR) => T1.$h
        },
        {
          "n": "arg2",
          "p": (T1, T2, TR) => T2.$h
        }
      ],
      "g": [
        "T1",
        "T2",
        "TR"
      ],
      "n": "RunOnEmptyStack",
      "d": 2949213,
      "h": 17182818397,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17182818397),
//--TRIMMABLE-BOUNDARY-START(21477785693),
    {
      "r": (R) => R.$h,
      "p": [
        {
          "n": "action",
          "p": (R) => $.$$.System.Func$$$($.$$.System.Object, R).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "g": [
        "R"
      ],
      "n": "RunOnEmptyStackCore",
      "d": 2949213,
      "h": 21477785693,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(21477785693)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887851101),
    {
      "t": 655361,
      "n": "MaxExecutionStackCount",
      "d": 2949213,
      "h": 12887851101,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12887851101),
//--TRIMMABLE-BOUNDARY-START(4297916509),
    {
      "t": 655361,
      "n": "_executionStackCount",
      "d": 2949213,
      "h": 4297916509,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297916509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592883805),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2949213,
      "h": 8592883805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592883805)
  ],
  "h": 2949213
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949213)
        
        
        //--TRIMMABLE-BOUNDARY-START(589917)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain", ($self) => class CallSiteChain extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557213)
            /*Dictionary<ServiceIdentifier, ChainItemInfo>*/ _callSiteChain = null;
            //--TRIMMABLE-BOUNDARY-END(4295557213)
            
            //--TRIMMABLE-BOUNDARY-START(12885491805)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._callSiteChain = new ($.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491805)
            
            //--TRIMMABLE-BOUNDARY-START(25770393693)
            /*void */ CheckCircularDependency(/*ServiceIdentifier*/ serviceIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._callSiteChain.ContainsKey(serviceIdentifier))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(this.CreateCircularDependencyExceptionMessage(serviceIdentifier));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770393693)
            
            //--TRIMMABLE-BOUNDARY-START(34360328285)
            /*void */ Remove(/*ServiceIdentifier*/ serviceIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._callSiteChain.Remove$1(serviceIdentifier);
            }
            //--TRIMMABLE-BOUNDARY-END(34360328285)
            
            //--TRIMMABLE-BOUNDARY-START(17180459101)
            /*void */ Add(/*ServiceIdentifier*/ serviceIdentifier, /*Type?*/ implementationType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._callSiteChain.set_Item(serviceIdentifier, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo().$ctor$3(this._callSiteChain.Count, implementationType));
            }
            //--TRIMMABLE-BOUNDARY-END(17180459101)
            
            //--TRIMMABLE-BOUNDARY-START(30065360989)
            /*string */ CreateCircularDependencyExceptionMessage(/*ServiceIdentifier*/ serviceIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let messageBuilder = new $.$$.System.Text.StringBuilder().$ctor$1();
                messageBuilder.Append$19($.$med.System.SR.Format$6($.$med.System.SR.CircularDependencyException, $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43)));
                messageBuilder.AppendLine();
                this.AppendResolutionPath(messageBuilder, serviceIdentifier);
                return $.$$.System.Text.StringBuilder.ToString.call(messageBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(30065360989)
            
            //--TRIMMABLE-BOUNDARY-START(21475426397)
            /*void */ AppendResolutionPath(/*StringBuilder*/ builder, /*ServiceIdentifier*/ currentlyResolving)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let ordered = new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo)))().$ctor$2(this._callSiteChain);
                ordered.Sort$2(new ($.$$.System.Comparison$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo)))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    return $.$$.System.Int32.CompareTo.call(a.Value.Order, b.Value.Order);
                }, {
  "r": 655361,
  "p": [
    {
      "n": "a",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo).$h
    },
    {
      "n": "b",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo).$h
    }
  ],
  "n": "",
  "d": 589917,
  "h": 0,
  "f": 17825794
}));
                var $en2 = ordered.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var pair = $en2.Current;
                    {
                        /*ServiceIdentifier*/ let serviceIdentifier = pair.Key;
                        /*Type?*/ let implementationType = pair.Value.ImplementationType;
                        if ($.$$.System.Type.op_Equality$1(implementationType, null) || $.$$.System.Type.op_Equality$1(serviceIdentifier.ServiceType, implementationType))
                        {
                            builder.Append$19($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43));
                        }
                        else 
                        {
                            builder.Append$19($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43)).Append$3(/*(*/ 40).Append$19($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(implementationType, true, false, true, /*+*/ 43)).Append$3(/*)*/ 41);
                        }
                        builder.Append$19(" -> ");
                    }
                }
                builder.Append$19($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(currentlyResolving.ServiceType, true, false, true, /*+*/ 43));
            }
            //--TRIMMABLE-BOUNDARY-END(21475426397)
            
            //--TRIMMABLE-BOUNDARY-START(655453)
            static $_ChainItemInfo;
            static get ChainItemInfo()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain;
                return $cls.$_ChainItemInfo ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo", ($self) => class ChainItemInfo extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(42950328413)
                    /*int*/ Order = 0;
                    //--TRIMMABLE-BOUNDARY-END(42950328413)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655361117)
                    /*Type?*/ ImplementationType = null;
                    //--TRIMMABLE-BOUNDARY-END(38655361117)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524637)
                    $ctor$3(/*int*/ order, /*Type?*/ implementationType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180524637);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Order = order;
                            this.ImplementationType = implementationType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180524637)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557341)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557341)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Order = this.Order;
                        copy.ImplementationType = this.ImplementationType;
                        return copy;
                    }
                    static $h = 655453;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950328413),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393821,
        "f": 50331649
      },
      "n": "Order",
      "d": 655453,
      "h": 42950328413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950328413),
//--TRIMMABLE-BOUNDARY-START(38655361117),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459229,
        "f": 50331649
      },
      "n": "ImplementationType",
      "d": 655453,
      "h": 38655361117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655361117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180524637),
    {
      "p": [
        {
          "n": "order",
          "p": 655361
        },
        {
          "n": "implementationType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655453,
      "h": 17180524637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180524637),
//--TRIMMABLE-BOUNDARY-START(12885557341),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655453,
      "h": 12885557341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557341)
  ],
  "d": 589917,
  "h": 655453
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo`; }
                }, $cls, ($v) => $cls.$_ChainItemInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655453)
            
            static $h = 589917;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770393693),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        }
      ],
      "n": "CheckCircularDependency",
      "d": 589917,
      "h": 25770393693,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393693),
//--TRIMMABLE-BOUNDARY-START(34360328285),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        }
      ],
      "n": "Remove",
      "d": 589917,
      "h": 34360328285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360328285),
//--TRIMMABLE-BOUNDARY-START(17180459101),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "implementationType",
          "p": 187760641,
          "f": 65
        }
      ],
      "n": "Add",
      "d": 589917,
      "h": 17180459101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459101),
//--TRIMMABLE-BOUNDARY-START(30065360989),
    {
      "r": 1310721,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        }
      ],
      "n": "CreateCircularDependencyExceptionMessage",
      "d": 589917,
      "h": 30065360989,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065360989),
//--TRIMMABLE-BOUNDARY-START(21475426397),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "currentlyResolving",
          "p": 2555997
        }
      ],
      "n": "AppendResolutionPath",
      "d": 589917,
      "h": 21475426397,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475426397)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557213),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo).$h,
      "n": "_callSiteChain",
      "d": 589917,
      "h": 4295557213,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491805),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589917,
      "h": 12885491805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491805)
  ],
  "j": [655453
  ],
  "h": 589917
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589917)
        
        
        //--TRIMMABLE-BOUNDARY-START(393309)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions", ($self) => class DependencyInjectionEventSourceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590327901)
            static /*void */ ExpressionTreeGenerated(/*this DependencyInjectionEventSource*/ source, /*ServiceProvider*/ provider, /*Type*/ serviceType, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    /*var*/ let visitor = new $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor().$ctor$2();
                    visitor.Visit$1(expression);
                    source.ExpressionTreeGenerated($.$$.System.Type.ToString.call(serviceType), visitor.NodeCount, $.$$.System.Object.GetHashCode.call(provider));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327901)
            
            //--TRIMMABLE-BOUNDARY-START(458845)
            static $_NodeCountingVisitor;
            static get NodeCountingVisitor()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions;
                return $cls.$_NodeCountingVisitor ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor", ($self) => class NodeCountingVisitor extends $.$sle.System.Linq.Expressions.ExpressionVisitor
                {
                    //--TRIMMABLE-BOUNDARY-START(21475295325)
                    /*int*/ NodeCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475295325)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360197213)
                    /*Expression? */ Visit$1(/*Expression?*/ e)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360197213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        super.Visit$1(e);
                        this.NodeCount++;
                        return e;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360197213)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590393437)
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590393437)
                    
                    static $h = 458845;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 11337765,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475295325),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328029,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065229917,
        "f": 83886082
      },
      "n": "NodeCount",
      "d": 458845,
      "h": 21475295325,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475295325)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360197213),
    {
      "r": 8781861,
      "p": [
        {
          "n": "e",
          "p": 8781861
        }
      ],
      "n": "Visit",
      "o": "@$1",
      "d": 458845,
      "h": 34360197213,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360197213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393437),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458845,
      "h": 8590393437,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393437)
  ],
  "d": 393309,
  "h": 458845
}; }
                    static get $b() { return $.$sle.System.Linq.Expressions.ExpressionVisitor; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor`; }
                }, $cls, ($v) => $cls.$_NodeCountingVisitor = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458845)
            
            static $h = 393309;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327901),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 262237
        },
        {
          "n": "provider",
          "p": 3080285
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "ExpressionTreeGenerated",
      "d": 393309,
      "h": 8590327901,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327901)
  ],
  "j": [458845
  ],
  "h": 393309
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393309)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966173)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext", ($self) => class ILEmitResolverBuilderContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17181835357)
            $ctor$1(/*ILGenerator*/ generator)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Generator = generator;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181835357)
            
            //--TRIMMABLE-BOUNDARY-START(30066737245)
            /*ILGenerator*/ Generator = null;
            //--TRIMMABLE-BOUNDARY-END(30066737245)
            
            //--TRIMMABLE-BOUNDARY-START(21476802653)
            /*List<object?>?*/ Constants = null;
            //--TRIMMABLE-BOUNDARY-END(21476802653)
            
            //--TRIMMABLE-BOUNDARY-START(25771769949)
            /*List<Func<IServiceProvider, object>>?*/ Factories = null;
            //--TRIMMABLE-BOUNDARY-END(25771769949)
            
            static $h = 1966173;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066737245),
    {
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836541021,
        "f": 50331649
      },
      "n": "Generator",
      "d": 1966173,
      "h": 30066737245,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066737245),
//--TRIMMABLE-BOUNDARY-START(21476802653),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656671837,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426475613,
        "f": 83886081
      },
      "n": "Constants",
      "d": 1966173,
      "h": 21476802653,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476802653),
//--TRIMMABLE-BOUNDARY-START(25771769949),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246606429,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016410205,
        "f": 83886081
      },
      "n": "Factories",
      "d": 1966173,
      "h": 25771769949,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771769949)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181835357),
    {
      "p": [
        {
          "n": "generator"
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966173,
      "h": 17181835357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181835357)
  ],
  "h": 1966173
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966173)
        
        
        //--TRIMMABLE-BOUNDARY-START(720989)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory", ($self) => class CallSiteFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425230429)
            /*int*/ static DefaultSlot = 0;
            //--TRIMMABLE-BOUNDARY-END(64425230429)
            
            //--TRIMMABLE-BOUNDARY-START(17180590173)
            /*ServiceDescriptor[]*/ _descriptors = null;
            //--TRIMMABLE-BOUNDARY-END(17180590173)
            
            //--TRIMMABLE-BOUNDARY-START(4295688285)
            /*ConcurrentDictionary<ServiceCacheKey, ServiceCallSite>*/ _callSiteCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295688285)
            
            //--TRIMMABLE-BOUNDARY-START(12885622877)
            /*Dictionary<ServiceIdentifier, ServiceDescriptorCacheItem>*/ _descriptorLookup = null;
            //--TRIMMABLE-BOUNDARY-END(12885622877)
            
            //--TRIMMABLE-BOUNDARY-START(8590655581)
            /*ConcurrentDictionary<ServiceIdentifier, object>*/ _callSiteLocks = null;
            //--TRIMMABLE-BOUNDARY-END(8590655581)
            
            //--TRIMMABLE-BOUNDARY-START(21475557469)
            /*StackGuard*/ _stackGuard = null;
            //--TRIMMABLE-BOUNDARY-END(21475557469)
            
            //--TRIMMABLE-BOUNDARY-START(30065492061)
            $ctor$1(/*ICollection<ServiceDescriptor>*/ descriptors)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065492061);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stackGuard = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard().$ctor$1();
                    this._descriptors = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), null, [descriptors.System$Collections$Generic$ICollection$$$Count], null);
                    descriptors.System$Collections$Generic$ICollection$$$CopyTo(this._descriptors, 0, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    this.Populate();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492061)
            
            //--TRIMMABLE-BOUNDARY-START(68720197725)
            /*ServiceDescriptor[] */ get Descriptors()
            {
                return this._descriptors;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197725)
            
            //--TRIMMABLE-BOUNDARY-START(115964837981)
            /*void */ Populate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._descriptors;
                while ($i1 < $arr1.length)
                {
                    let descriptor = $arr1[$i1++];
                    /*Type*/ let serviceType = descriptor.ServiceType;
                    /*Type?*/ let implementationType;
                    if (serviceType.IsGenericTypeDefinition)
                    {
                        /*Type?*/ let implementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor);
                        if ($.$$.System.Type.op_Equality$1(implementationType, null) || !implementationType.IsGenericTypeDefinition)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$med.System.SR.Format$6($.$med.System.SR.OpenGenericServiceRequiresOpenGenericImplementation, serviceType), "descriptors");
                        }
                        if (implementationType.IsAbstract$1 || implementationType.IsInterface)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.TypeCannotBeActivated, implementationType, serviceType));
                        }
                        /*Type[]*/ let serviceTypeGenericArguments = serviceType.GetGenericArguments();
                        /*Type[]*/ let implementationTypeGenericArguments = implementationType.GetGenericArguments();
                        if (serviceTypeGenericArguments.length !== implementationTypeGenericArguments.length)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$med.System.SR.Format$5($.$med.System.SR.ArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation, serviceType, implementationType), "descriptors");
                        }
                        if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyOpenGenericServiceTrimmability)
                        {
                            $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ValidateTrimmingAnnotations(serviceType, serviceTypeGenericArguments, implementationType, implementationTypeGenericArguments);
                        }
                    }
                    else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.TryGetImplementationType(descriptor, $.$ref(() => implementationType, ($v) => implementationType = $v, $.$$.System.Type)))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(implementationType, null), "implementationType != null");
                        if (implementationType.IsGenericTypeDefinition || implementationType.IsAbstract$1 || implementationType.IsInterface)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.TypeCannotBeActivated, implementationType, serviceType));
                        }
                    }
                    /*var*/ let cacheKey = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(descriptor);
                    /*ServiceDescriptorCacheItem*/ let cacheItem;
                    this._descriptorLookup.TryGetValue(cacheKey, $.$ref(() => cacheItem, ($v) => cacheItem = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem));
                    this._descriptorLookup.set_Item(cacheKey, cacheItem.Add(descriptor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964837981)
            
            //--TRIMMABLE-BOUNDARY-START(150324576349)
            static /*void */ ValidateTrimmingAnnotations(/*Type*/ serviceType, /*Type[]*/ serviceTypeGenericArguments, /*Type*/ implementationType, /*Type[]*/ implementationTypeGenericArguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(serviceTypeGenericArguments.length === implementationTypeGenericArguments.length, "serviceTypeGenericArguments.Length == implementationTypeGenericArguments.Length");
                for(/*int*/ let i = 0; i < serviceTypeGenericArguments.length; i++)
                {
                    /*Type*/ let serviceGenericType = $.$$.System.Array.$ReadT1.call(serviceTypeGenericArguments, i);
                    /*Type*/ let implementationGenericType = $.$$.System.Array.$ReadT1.call(implementationTypeGenericArguments, i);
                    /*DynamicallyAccessedMemberTypes*/ let serviceDynamicallyAccessedMembers = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetDynamicallyAccessedMemberTypes(serviceGenericType);
                    /*DynamicallyAccessedMemberTypes*/ let implementationDynamicallyAccessedMembers = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetDynamicallyAccessedMemberTypes(implementationGenericType);
                    if (!$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.AreCompatible(serviceDynamicallyAccessedMembers, implementationDynamicallyAccessedMembers))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.TrimmingAnnotationsDoNotMatch, implementationType.FullName, serviceType.FullName));
                    }
                    /*bool*/ let serviceHasNewConstraint = ((serviceGenericType.GenericParameterAttributes & (16/*GenericParameterAttributes.DefaultConstructorConstraint*/)) == (16/*GenericParameterAttributes.DefaultConstructorConstraint*/));
                    /*bool*/ let implementationHasNewConstraint = ((implementationGenericType.GenericParameterAttributes & (16/*GenericParameterAttributes.DefaultConstructorConstraint*/)) == (16/*GenericParameterAttributes.DefaultConstructorConstraint*/));
                    if (implementationHasNewConstraint && !serviceHasNewConstraint)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.TrimmingAnnotationsDoNotMatch_NewConstraint, implementationType.FullName, serviceType.FullName));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324576349)
            
            //--TRIMMABLE-BOUNDARY-START(94490001501)
            static /*DynamicallyAccessedMemberTypes */ GetDynamicallyAccessedMemberTypes(/*Type*/ serviceGenericType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = serviceGenericType.GetCustomAttributesData().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attributeData = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.op_Equality(attributeData.AttributeType.FullName, "System.Diagnostics.CodeAnalysis.DynamicallyAccessedMembersAttribute") && attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count === 1 && $.$$.System.String.op_Equality(attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$$.System.Reflection.CustomAttributeTypedArgument]).ArgumentType.FullName, "System.Diagnostics.CodeAnalysis.DynamicallyAccessedMemberTypes"))
                        {
                            return $.$cast(attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$$.System.Reflection.CustomAttributeTypedArgument]).Value, $.$$.System.Int32);
                        }
                    }
                }
                return 0/*DynamicallyAccessedMemberTypes.None*/;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001501)
            
            //--TRIMMABLE-BOUNDARY-START(38655426653)
            static /*bool */ AreCompatible(/*DynamicallyAccessedMemberTypes*/ serviceDynamicallyAccessedMembers, /*DynamicallyAccessedMemberTypes*/ implementationDynamicallyAccessedMembers)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ((serviceDynamicallyAccessedMembers & (implementationDynamicallyAccessedMembers)) == (implementationDynamicallyAccessedMembers));
            }
            //--TRIMMABLE-BOUNDARY-END(38655426653)
            
            //--TRIMMABLE-BOUNDARY-START(98784968797)
            /*int? */ GetSlot$1(/*ServiceDescriptor*/ serviceDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceDescriptorCacheItem*/ let item;
                if (this._descriptorLookup.TryGetValue($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(serviceDescriptor), $.$ref(() => item, ($v) => item = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return item.GetSlot(serviceDescriptor);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968797)
            
            //--TRIMMABLE-BOUNDARY-START(81605099613)
            /*ServiceCallSite? */ GetCallSite(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605099613);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*ServiceCallSite?*/ let site;
                    return this._callSiteCache.TryGetValue(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, 0/*DefaultSlot*/), $.$ref(() => site, ($v) => site = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)) ? site : this.CreateCallSite(serviceIdentifier, callSiteChain);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605099613)
            
            //--TRIMMABLE-BOUNDARY-START(85900066909)
            /*ServiceCallSite? */ GetCallSite$1(/*ServiceDescriptor*/ serviceDescriptor, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let serviceIdentifier = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(serviceDescriptor);
                /*ServiceDescriptorCacheItem*/ let descriptor;
                if (this._descriptorLookup.TryGetValue(serviceIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return this.TryCreateExact$1(serviceDescriptor, serviceIdentifier, callSiteChain, descriptor.GetSlot(serviceDescriptor));
                }
                $.$$.System.Diagnostics.Debug.Fail$1("_descriptorLookup didn't contain requested serviceDescriptor");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066909)
            
            //--TRIMMABLE-BOUNDARY-START(47245361245)
            /*ServiceCallSite? */ CreateCallSite(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._stackGuard.TryEnterOnCurrentStack())
                {
                    return this._stackGuard.RunOnEmptyStack($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, new ($.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor(this, this.CreateCallSite), serviceIdentifier, callSiteChain);
                }
                /*var*/ let callsiteLock = this._callSiteLocks.GetOrAdd(serviceIdentifier, new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$$.System.Object))().$ctor($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory, /*static*/ (/*_*/ _0) =>
                {
                    return new $.$$.System.Object().$ctor();
                }, {
  "r": 131073,
  "p": [
    {
      "n": "_",
      "p": 2555997
    }
  ],
  "n": "",
  "d": 720989,
  "h": 0,
  "f": 17825826
}));
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(callsiteLock)
                    {
                        callSiteChain.CheckCircularDependency(serviceIdentifier);
                        /*ServiceCallSite?*/ let callSite = this.TryCreateExact(serviceIdentifier, callSiteChain) ?? this.TryCreateOpenGeneric(serviceIdentifier, callSiteChain) ?? this.TryCreateEnumerable(serviceIdentifier, callSiteChain);
                        return callSite;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(callsiteLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245361245)
            
            //--TRIMMABLE-BOUNDARY-START(133144707165)
            /*ServiceCallSite? */ TryCreateExact(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceDescriptorCacheItem*/ let descriptor;
                if (this._descriptorLookup.TryGetValue(serviceIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return this.TryCreateExact$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/);
                }
                if (serviceIdentifier.ServiceKey !== null)
                {
                    /*var*/ let catchAllIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, serviceIdentifier.ServiceType);
                    if (this._descriptorLookup.TryGetValue(catchAllIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        return this.TryCreateExact$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(133144707165)
            
            //--TRIMMABLE-BOUNDARY-START(141734641757)
            /*ServiceCallSite? */ TryCreateOpenGeneric(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceIdentifier.ServiceType.IsConstructedGenericType)
                {
                    /*ServiceIdentifier*/ let genericIdentifier = serviceIdentifier.GetGenericTypeDefinition();
                    /*ServiceDescriptorCacheItem*/ let descriptor;
                    if (this._descriptorLookup.TryGetValue(genericIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        return this.TryCreateOpenGeneric$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/, true);
                    }
                    if (serviceIdentifier.ServiceKey !== null)
                    {
                        /*var*/ let catchAllIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, genericIdentifier.ServiceType);
                        if (this._descriptorLookup.TryGetValue(catchAllIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                        {
                            return this.TryCreateOpenGeneric$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/, true);
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(141734641757)
            
            //--TRIMMABLE-BOUNDARY-START(128849739869)
            /*ServiceCallSite? */ TryCreateEnumerable(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, 0/*DefaultSlot*/);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                try
                {
                    callSiteChain.Add(serviceIdentifier, null);
                    /*var*/ let serviceType = serviceIdentifier.ServiceType;
                    if (!serviceType.IsConstructedGenericType || $.$$.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        return null;
                    }
                    /*Type*/ let itemType = $.$$.System.Array.$ReadT1.call(serviceType.GenericTypeArguments, 0);
                    /*var*/ let cacheKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceIdentifier.ServiceKey, itemType);
                    if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility && itemType.IsValueType)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.AotCannotCreateEnumerableValueType, itemType));
                    }
                    /*CallSiteResultCacheLocation*/ let cacheLocation = 0/*CallSiteResultCacheLocation.Root*/;
                    /*ServiceCallSite[]*/ let callSites;
                    /*bool*/ let isAnyKeyLookup = serviceIdentifier.ServiceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey;
                    /*ServiceDescriptorCacheItem*/ let descriptors;
                    if (!itemType.IsConstructedGenericType && !isAnyKeyLookup && this._descriptorLookup.TryGetValue(cacheKey, $.$ref(() => descriptors, ($v) => descriptors = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        /*int*/ let slot = descriptors.Count;
                        callSites = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [descriptors.Count], null);
                        for(/*int*/ let i = 0; i < descriptors.Count; i++)
                        {
                            /*ServiceDescriptor*/ let descriptor = descriptors.get_Item$1(i);
                            /*ServiceCallSite*/ let callSite = this.CreateExact(descriptor, cacheKey, callSiteChain, --slot);
                            cacheLocation = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetCommonCacheLocation(cacheLocation, callSite.Cache.Location);
                            $.$$.System.Array.$WriteT1.call(callSites, callSite, i);
                        }
                    }
                    else 
                    {
                        /*List<KeyValuePair<int, ServiceCallSite>>*/ let callSitesByIndex = new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))().$ctor$1();
                        /*Dictionary<ServiceIdentifier, int>?*/ let keyedSlotAssignment = null;
                        /*int*/ let slot = 0;
                        for(/*int*/ let i = ((this._descriptors.length - 1) | 0); i >= 0; i--)
                        {
                            if (KeysMatch(cacheKey.ServiceKey, $.$$.System.Array.$ReadT1.call(this._descriptors, i).ServiceKey))
                            {
                                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateExact($.$$.System.Array.$ReadT1.call(this._descriptors, i).ServiceType, cacheKey.ServiceType))
                                {
                                    /*ServiceIdentifier*/ let registrationKey = isAnyKeyLookup ? $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor($.$$.System.Array.$ReadT1.call(this._descriptors, i)) : cacheKey;
                                    slot = GetSlot.call(this, registrationKey);
                                    /*ServiceCallSite*/ let callSite = this.CreateExact($.$$.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot);
                                    AddCallSite.call(this, callSite, i);
                                    UpdateSlot.call(this, registrationKey);
                                }
                            }
                        }
                        for(/*int*/ let i = ((this._descriptors.length - 1) | 0); i >= 0; i--)
                        {
                            if (KeysMatch(cacheKey.ServiceKey, $.$$.System.Array.$ReadT1.call(this._descriptors, i).ServiceKey))
                            {
                                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateOpenGeneric($.$$.System.Array.$ReadT1.call(this._descriptors, i).ServiceType, cacheKey.ServiceType))
                                {
                                    /*ServiceIdentifier*/ let registrationKey = isAnyKeyLookup ? $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor($.$$.System.Array.$ReadT1.call(this._descriptors, i)) : cacheKey;
                                    slot = GetSlot.call(this, registrationKey);
                                    let callSite;
                                    if (this.CreateOpenGeneric($.$$.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot, false) !== null && ((callSite = this.CreateOpenGeneric($.$$.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot, false), callSite != null && true)))
                                    {
                                        AddCallSite.call(this, callSite, i);
                                        UpdateSlot.call(this, registrationKey);
                                    }
                                }
                            }
                        }
                        callSitesByIndex.Sort$2(new ($.$$.System.Comparison$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                        {
                            return $.$$.System.Int32.CompareTo.call(a.Key, b.Key);
                        }, {
  "r": 655361,
  "p": [
    {
      "n": "a",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h
    },
    {
      "n": "b",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h
    }
  ],
  "n": "",
  "d": 720989,
  "h": 0,
  "f": 17825794
}));
                        callSites = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [callSitesByIndex.Count], null);
                        for(/*var*/ let i = 0; i < callSites.length; ++i)
                        {
                            $.$$.System.Array.$WriteT1.call(callSites, callSitesByIndex.get_Item(i).Value, i);
                        }
                        /*void*/  function AddCallSite(/*ServiceCallSite*/ callSite, /*int*/ index)
                        {
                            cacheLocation = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetCommonCacheLocation(cacheLocation, callSite.Cache.Location);
                            callSitesByIndex.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$3(index, callSite));
                        }
                        /*int*/  function GetSlot(/*ServiceIdentifier*/ key)
                        {
                            if (!isAnyKeyLookup)
                            {
                                return slot;
                            }
                            if (keyedSlotAssignment === null)
                            {
                                keyedSlotAssignment = (() =>
                                {
                                    //new $.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$$.System.Int32)()
                                    const $t3 = $.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$$.System.Int32);
                                    const $i3 = new $t3();
                                    $i3.$ctor$8(this._descriptors.length);
                                    $i3.Add(key, 0);
                                    return $i3;
                                })();
                                return 0;
                            }
                            /*int*/ let existingSlot;
                            if (keyedSlotAssignment.TryGetValue(key, $.$ref(() => existingSlot, ($v) => existingSlot = $v, $.$$.System.Int32)))
                            {
                                return existingSlot;
                            }
                            keyedSlotAssignment.Add(key, 0);
                            return 0;
                        }
                        /*void*/  function UpdateSlot(/*ServiceIdentifier*/ key)
                        {
                            if (!isAnyKeyLookup)
                            {
                                slot++;
                            }
                            else 
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(!(keyedSlotAssignment === null), "keyedSlotAssignment is not null");
                                keyedSlotAssignment.set_Item(key, ((slot + 1) | 0));
                            }
                        }
                    }
                    /*ResultCache*/ let resultCache = (cacheLocation === 1/*CallSiteResultCacheLocation.Scope*/ || cacheLocation === 0/*CallSiteResultCacheLocation.Root*/) ? new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$3(cacheLocation, callSiteKey) : new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$3(3/*CallSiteResultCacheLocation.None*/, callSiteKey);
                    let $t3;
                    return this._callSiteCache.set_Item$1(callSiteKey, $t3 = (new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite().$ctor$2(resultCache.Clone(), itemType, callSites, serviceIdentifier.ServiceKey))), $t3;
                }
                finally
                {
                    {
                        callSiteChain.Remove(serviceIdentifier);
                    }
                }
                /*static bool*/  function KeysMatch(/*object?*/ lookupKey, /*object?*/ descriptorKey)
                {
                    if (lookupKey === null && descriptorKey === null)
                    {
                        return true;
                    }
                    if (lookupKey !== null && descriptorKey !== null)
                    {
                        if ($.$$.System.Object.Equals$1.call(descriptorKey, $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey))
                        {
                            return false;
                        }
                        return $.$$.System.Object.Equals$1.call(lookupKey, descriptorKey) || $.$$.System.Object.Equals$1.call(lookupKey, $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey);
                    }
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849739869)
            
            //--TRIMMABLE-BOUNDARY-START(90195034205)
            static /*CallSiteResultCacheLocation */ GetCommonCacheLocation(/*CallSiteResultCacheLocation*/ locationA, /*CallSiteResultCacheLocation*/ locationB)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast($.$$.System.Math.Max$4(locationA, locationB), $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation);
            }
            //--TRIMMABLE-BOUNDARY-END(90195034205)
            
            //--TRIMMABLE-BOUNDARY-START(137439674461)
            /*ServiceCallSite? */ TryCreateExact$1(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateExact(descriptor.ServiceType, serviceIdentifier.ServiceType))
                {
                    return this.CreateExact(descriptor, serviceIdentifier, callSiteChain, slot);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(137439674461)
            
            //--TRIMMABLE-BOUNDARY-START(120259805277)
            static /*bool */ ShouldCreateExact(/*Type*/ descriptorType, /*Type*/ serviceType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259805277);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Type.op_Equality$1(descriptorType, serviceType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259805277)
            
            //--TRIMMABLE-BOUNDARY-START(55835295837)
            /*ServiceCallSite */ CreateExact(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, slot);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                /*ServiceCallSite*/ let callSite;
                /*var*/ let lifetime = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$4(descriptor.Lifetime, serviceIdentifier, slot);
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationInstance(descriptor))
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(descriptor.ServiceType, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(descriptor), descriptor.ServiceKey);
                }
                else if (!descriptor.IsKeyedService && descriptor.ImplementationFactory !== null)
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite().$ctor$2(lifetime.Clone(), descriptor.ServiceType, descriptor.ImplementationFactory);
                }
                else if (descriptor.IsKeyedService && descriptor.KeyedImplementationFactory !== null)
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite().$ctor$3(lifetime.Clone(), descriptor.ServiceType, serviceIdentifier.ServiceKey, descriptor.KeyedImplementationFactory);
                }
                else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationType(descriptor))
                {
                    callSite = this.CreateConstructorCallSite(lifetime.Clone(), serviceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor), callSiteChain);
                }
                else 
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.InvalidServiceDescriptor);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(callSite !== null, "callSite != null");
                let $t2;
                return this._callSiteCache.set_Item$1(callSiteKey, $t2 = (callSite)), $t2;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295837)
            
            //--TRIMMABLE-BOUNDARY-START(146029609053)
            /*ServiceCallSite? */ TryCreateOpenGeneric$1(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot, /*bool*/ throwOnConstraintViolation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029609053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateOpenGeneric(descriptor.ServiceType, serviceIdentifier.ServiceType))
                {
                    return this.CreateOpenGeneric(descriptor, serviceIdentifier, callSiteChain, slot, throwOnConstraintViolation);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146029609053)
            
            //--TRIMMABLE-BOUNDARY-START(124554772573)
            static /*bool */ ShouldCreateOpenGeneric(/*Type*/ descriptorType, /*Type*/ serviceType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554772573);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return serviceType.IsConstructedGenericType && $.$$.System.Type.op_Equality$1(serviceType.GetGenericTypeDefinition(), descriptorType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554772573)
            
            //--TRIMMABLE-BOUNDARY-START(60130263133)
            /*ServiceCallSite? */ CreateOpenGeneric(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot, /*bool*/ throwOnConstraintViolation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, slot);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                /*Type?*/ let implementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor);
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(implementationType, null), "descriptor.ImplementationType != null");
                /*var*/ let lifetime = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$4(descriptor.Lifetime, serviceIdentifier, slot);
                /*Type*/ let closedType;
                try
                {
                    /*Type[]*/ let genericTypeArguments = serviceIdentifier.ServiceType.GenericTypeArguments;
                    if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.VerifyOpenGenericAotCompatibility(serviceIdentifier.ServiceType, genericTypeArguments);
                    }
                    closedType = implementationType.MakeGenericType(genericTypeArguments);
                }
                catch($e)
                {
                    if (throwOnConstraintViolation)
                    {
                        throw $e;
                    }
                    return null;
                }
                /*ConstructorCallSite*/ let site = this.CreateConstructorCallSite(lifetime.Clone(), serviceIdentifier, closedType, callSiteChain);
                $.$$.System.Diagnostics.Debug.Assert$2(site !== null, "site != null");
                let $t2;
                return this._callSiteCache.set_Item$1(callSiteKey, $t2 = (site)), $t2;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263133)
            
            //--TRIMMABLE-BOUNDARY-START(51540328541)
            /*ConstructorCallSite */ CreateConstructorCallSite(/*ResultCache*/ lifetime, /*ServiceIdentifier*/ serviceIdentifier, /*Type*/ implementationType, /*CallSiteChain*/ callSiteChain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    callSiteChain.Add(serviceIdentifier, implementationType);
                    /*ConstructorInfo[]*/ let constructors = implementationType.GetConstructors();
                    /*ServiceCallSite[]?*/ let parameterCallSites = null;
                    if (constructors.length === 0)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.NoConstructorMatch, implementationType));
                    }
                    else if (constructors.length === 1)
                    {
                        /*ConstructorInfo*/ let $constructor = $.$$.System.Array.$ReadT1.call(constructors, 0);
                        /*ParameterInfo[]*/ let parameters = $constructor.GetParameters();
                        if (parameters.length === 0)
                        {
                            return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$2(lifetime.Clone(), serviceIdentifier.ServiceType, $constructor, serviceIdentifier.ServiceKey);
                        }
                        parameterCallSites = this.CreateArgumentCallSites(serviceIdentifier, implementationType, callSiteChain, parameters, true);
                        return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$3(lifetime.Clone(), serviceIdentifier.ServiceType, $constructor, parameterCallSites, serviceIdentifier.ServiceKey);
                    }
                    $.$$.System.Array.Sort$9($.$$.System.Reflection.ConstructorInfo, constructors, new ($.$$.System.Comparison$$($.$$.System.Reflection.ConstructorInfo))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                    {
                        return $.$$.System.Int32.CompareTo.call(b.GetParameters().length, a.GetParameters().length);
                    }, {
  "r": 655361,
  "p": [
    {
      "n": "a",
      "p": 108462081
    },
    {
      "n": "b",
      "p": 108462081
    }
  ],
  "n": "",
  "d": 720989,
  "h": 0,
  "f": 17825794
}));
                    /*ConstructorInfo?*/ let bestConstructor = null;
                    /*HashSet<Type>?*/ let bestConstructorParameterTypes = null;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        /*ParameterInfo[]*/ let parameters = $.$$.System.Array.$ReadT1.call(constructors, i).GetParameters();
                        /*ServiceCallSite[]?*/ let currentParameterCallSites = this.CreateArgumentCallSites(serviceIdentifier, implementationType, callSiteChain, parameters, false);
                        if (currentParameterCallSites !== null)
                        {
                            if ($.$$.System.Reflection.ConstructorInfo.op_Equality$2(bestConstructor, null))
                            {
                                bestConstructor = $.$$.System.Array.$ReadT1.call(constructors, i);
                                parameterCallSites = currentParameterCallSites;
                            }
                            else 
                            {
                                if (bestConstructorParameterTypes === null)
                                {
                                    bestConstructorParameterTypes = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.Type))().$ctor$1();
                                    let $i1 = 0;
                                    let $arr1 = bestConstructor.GetParameters();
                                    while ($i1 < $arr1.length)
                                    {
                                        let p = $arr1[$i1++];
                                        bestConstructorParameterTypes.Add(p.ParameterType);
                                    }
                                }
                                let $i1 = 0;
                                let $arr1 = parameters;
                                while ($i1 < $arr1.length)
                                {
                                    let p = $arr1[$i1++];
                                    if (!bestConstructorParameterTypes.Contains(p.ParameterType))
                                    {
                                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$$.System.String.Join$7($.$$.System.Environment.NewLine, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ $.$med.System.SR.Format$6($.$med.System.SR.AmbiguousConstructorException, implementationType), bestConstructor, $.$$.System.Array.$ReadT1.call(constructors, i) ])));
                                    }
                                }
                            }
                        }
                    }
                    if ($.$$.System.Reflection.ConstructorInfo.op_Equality$2(bestConstructor, null))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.UnableToActivateTypeException, implementationType));
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(parameterCallSites !== null, "parameterCallSites != null");
                        return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$3(lifetime.Clone(), serviceIdentifier.ServiceType, bestConstructor, parameterCallSites, serviceIdentifier.ServiceKey);
                    }
                }
                finally
                {
                    {
                        callSiteChain.Remove(serviceIdentifier);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540328541)
            
            //--TRIMMABLE-BOUNDARY-START(42950393949)
            /*ServiceCallSite[]? */ CreateArgumentCallSites(/*ServiceIdentifier*/ serviceIdentifier, /*Type*/ implementationType, /*CallSiteChain*/ callSiteChain, /*ParameterInfo[]*/ parameters, /*bool*/ throwIfCallSiteNotFound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let parameterCallSites = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [parameters.length], null);
                for(/*int*/ let index = 0; index < parameters.length; index++)
                {
                    /*ServiceCallSite?*/ let callSite = null;
                    /*bool*/ let isKeyedParameter = false;
                    /*Type*/ let parameterType = $.$$.System.Array.$ReadT1.call(parameters, index).ParameterType;
                    let $i1 = 0;
                    let $arr1 = $.$$.System.Array.$ReadT1.call(parameters, index).GetCustomAttributes(true);
                    while ($i1 < $arr1.length)
                    {
                        let attribute = $arr1[$i1++];
                        if (serviceIdentifier.ServiceKey !== null && $.$is(attribute, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute))
                        {
                            if (serviceIdentifier.ServiceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                            {
                                parameterType = $.$$.System.Object.$type;
                            }
                            else if ($.$$.System.Type.op_Inequality$1(parameterType, $.$$.System.Object.GetType.call(serviceIdentifier.ServiceKey)) && $.$$.System.Type.op_Inequality$1(parameterType, $.$$.System.Object.$type))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.InvalidServiceKeyType);
                            }
                            callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(parameterType, serviceIdentifier.ServiceKey, null);
                            break;
                        }
                        let fromKeyedServicesAttribute;
                        if ($.$is(attribute, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute, { set $v(v){ fromKeyedServicesAttribute = v; } }))
                        {
                            /*object?*/ let serviceKey = (() =>
                            {
                                let $switch2 = fromKeyedServicesAttribute.LookupMode;
                                if ($switch2 === 0/*ServiceKeyLookupMode.InheritKey*/)
                                {
                                    return serviceIdentifier.ServiceKey;
                                }
                                if ($switch2 === 2/*ServiceKeyLookupMode.ExplicitKey*/)
                                {
                                    return fromKeyedServicesAttribute.Key;
                                }
                                if ($switch2 === 1/*ServiceKeyLookupMode.NullKey*/)
                                {
                                    return null;
                                }
                                return null;
                            })();
                            if (!(serviceKey === null))
                            {
                                callSite = this.GetCallSite(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceKey, parameterType), callSiteChain);
                                isKeyedParameter = true;
                                break;
                            }
                        }
                    }
                    if (!isKeyedParameter)
                    {
                        callSite ??= this.GetCallSite($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(parameterType), callSiteChain);
                    }
                    /*object?*/ let defaultValue;
                    if (callSite === null && $.$med.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$$.System.Array.$ReadT1.call(parameters, index), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$$.System.Object)))
                    {
                        callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(parameterType, defaultValue, null);
                    }
                    if (callSite === null)
                    {
                        if (throwIfCallSiteNotFound)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$5($.$med.System.SR.CannotResolveService, parameterType, implementationType));
                        }
                        return null;
                    }
                    $.$$.System.Array.$WriteT1.call(parameterCallSites, callSite, index);
                }
                return parameterCallSites;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393949)
            
            //--TRIMMABLE-BOUNDARY-START(154619543645)
            static /*void */ VerifyOpenGenericAotCompatibility(/*Type*/ serviceType, /*Type[]*/ genericTypeArguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619543645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = genericTypeArguments;
                while ($i1 < $arr1.length)
                {
                    let typeArg = $arr1[$i1++];
                    if (typeArg.IsValueType)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$5($.$med.System.SR.AotCannotCreateGenericValueType, serviceType, typeArg));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619543645)
            
            //--TRIMMABLE-BOUNDARY-START(34360459357)
            /*void */ Add(/*ServiceIdentifier*/ serviceIdentifier, /*ServiceCallSite*/ serviceCallSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._callSiteCache.set_Item$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, 0/*DefaultSlot*/), serviceCallSite);
            }
            //--TRIMMABLE-BOUNDARY-END(34360459357)
            
            //--TRIMMABLE-BOUNDARY-START(107374903389)
            /*bool */ IsService(/*Type*/ serviceType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374903389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(null, serviceType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374903389)
            
            //--TRIMMABLE-BOUNDARY-START(103079936093)
            /*bool */ IsKeyedService(/*Type*/ serviceType, /*object?*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079936093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(key, serviceType));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936093)
            
            //--TRIMMABLE-BOUNDARY-START(111669870685)
            /*bool */ IsService$1(/*ServiceIdentifier*/ serviceIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let serviceType = serviceIdentifier.ServiceType;
                $.$$.System.ArgumentNullException.ThrowIfNull$2(serviceType, "serviceType");
                if (serviceType.IsGenericTypeDefinition)
                {
                    return false;
                }
                if (this._descriptorLookup.ContainsKey(serviceIdentifier))
                {
                    return true;
                }
                if (serviceIdentifier.ServiceKey !== null && this._descriptorLookup.ContainsKey(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, serviceType)))
                {
                    return true;
                }
                let genericDefinition;
                if (serviceType.IsConstructedGenericType && $.$is(serviceType.GetGenericTypeDefinition(), $.$$.System.Type, { set $v(v){ genericDefinition = v; } }))
                {
                    return $.$$.System.Type.op_Equality$1(genericDefinition, $.$$.System.Collections.Generic.IEnumerable$$().$type) || this._descriptorLookup.ContainsKey(serviceIdentifier.GetGenericTypeDefinition());
                }
                return $.$$.System.Type.op_Equality$1(serviceType, $.$scm.System.IServiceProvider.$type) || $.$$.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type) || $.$$.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type) || $.$$.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type);
            }
            //--TRIMMABLE-BOUNDARY-END(111669870685)
            
            //--TRIMMABLE-BOUNDARY-START(786525)
            static $_ServiceDescriptorCacheItem;
            static get ServiceDescriptorCacheItem()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory;
                return $cls.$_ServiceDescriptorCacheItem ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem", ($self) => class ServiceDescriptorCacheItem extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753821)
                    /*ServiceDescriptor?*/  get _item() { return this.$getField(0, 4); }
                    /*ServiceDescriptor?*/  set _item(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295753821)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721117)
                    /*List<ServiceDescriptor>?*/  get _items() { return this.$getField(4, 4); }
                    /*List<ServiceDescriptor>?*/  set _items(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590721117)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835361373)
                    /*ServiceDescriptor */ get Last()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245426781);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._items !== null && this._items.Count > 0)
                        {
                            return this._items.get_Item(((this._items.Count - 1) | 0));
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._item !== null, "_item != null");
                        return this._item;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835361373)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623005)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065557597);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._item === null)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._items === null, "_items == null");
                            return 0;
                        }
                        return ((1 + ((this._items?.Count ?? null) ?? 0)) | 0);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475623005)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130328669)
                    /*ServiceDescriptor*/ get_Item$1(/*int*/ index)
                    {
                        if (index >= this.Count)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                        }
                        if (index === 0)
                        {
                            return this._item;
                        }
                        return this._items.get_Item(((index - 1) | 0));
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130328669)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540394077)
                    /*int */ GetSlot(/*ServiceDescriptor*/ descriptor)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540394077);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (descriptor === this._item)
                        {
                            return ((this.Count - 1) | 0);
                        }
                        if (this._items !== null)
                        {
                            /*int*/ let index = this._items.IndexOf$2(descriptor);
                            if (index !== -1)
                            {
                                return ((this._items.Count - (((index + 1) | 0))) | 0);
                            }
                        }
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.ServiceDescriptorNotExist);
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540394077)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655709)
                    /*ServiceDescriptorCacheItem */ Add(/*ServiceDescriptor*/ descriptor)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655709);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let newCacheItem = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem);
                        if (this._item === null)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._items === null, "_items == null");
                            newCacheItem._item = descriptor;
                        }
                        else 
                        {
                            newCacheItem._item = this._item;
                            newCacheItem._items = this._items ?? new ($.$$.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor))().$ctor$1();
                            newCacheItem._items.Add(descriptor);
                        }
                        return newCacheItem;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655709)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688413)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688413)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._item = this._item;
                        copy._items = this._items;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295753821)
                        this._item = null;
                        //--TRIMMABLE-BOUNDARY-END(4295753821)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590721117)
                        this._items = null;
                        //--TRIMMABLE-BOUNDARY-END(8590721117)
                        
                    }
                    static $h = 786525;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835361373),
    {
      "p": 1704026,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426781,
        "f": 50331649
      },
      "n": "Last",
      "d": 786525,
      "h": 55835361373,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835361373),
//--TRIMMABLE-BOUNDARY-START(21475623005),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065557597,
        "f": 50331649
      },
      "n": "Count",
      "d": 786525,
      "h": 21475623005,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475623005),
//--TRIMMABLE-BOUNDARY-START(60130328669),
    {
      "p": 1704026,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492189,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 786525,
      "h": 60130328669,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328669)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540394077),
    {
      "r": 655361,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "GetSlot",
      "d": 786525,
      "h": 51540394077,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540394077),
//--TRIMMABLE-BOUNDARY-START(17180655709),
    {
      "r": 786525,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "Add",
      "d": 786525,
      "h": 17180655709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655709)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753821),
    {
      "t": 1704026,
      "n": "_item",
      "d": 786525,
      "h": 4295753821,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753821),
//--TRIMMABLE-BOUNDARY-START(8590721117),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,
      "n": "_items",
      "d": 786525,
      "h": 8590721117,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688413),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786525,
      "h": 12885688413,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688413)
  ],
  "d": 720989,
  "h": 786525
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem`; }
                }, $cls, ($v) => $cls.$_ServiceDescriptorCacheItem = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786525)
            
            //--TRIMMABLE-BOUNDARY-START(4295884890)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.IsKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884890)
            
            //--TRIMMABLE-BOUNDARY-START(4295950426)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.IsService(System.Type)
            Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295950426)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688285)
                this._callSiteCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295688285)
                
                //--TRIMMABLE-BOUNDARY-START(12885622877)
                this._descriptorLookup = new ($.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885622877)
                
                //--TRIMMABLE-BOUNDARY-START(8590655581)
                this._callSiteLocks = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$$.System.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590655581)
                
            }
            static $h = 720989;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720197725),
    {
      "p": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310132317,
        "f": 50331656
      },
      "n": "Descriptors",
      "d": 720989,
      "h": 68720197725,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68720197725)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964837981),
    {
      "r": 65537,
      "n": "Populate",
      "d": 720989,
      "h": 115964837981,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964837981),
//--TRIMMABLE-BOUNDARY-START(150324576349),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceTypeGenericArguments",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "implementationTypeGenericArguments",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ValidateTrimmingAnnotations",
      "d": 720989,
      "h": 150324576349,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(150324576349),
//--TRIMMABLE-BOUNDARY-START(94490001501),
    {
      "r": null,
      "p": [
        {
          "n": "serviceGenericType",
          "p": 187760641
        }
      ],
      "n": "GetDynamicallyAccessedMemberTypes",
      "d": 720989,
      "h": 94490001501,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490001501),
//--TRIMMABLE-BOUNDARY-START(38655426653),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceDynamicallyAccessedMembers"
        },
        {
          "n": "implementationDynamicallyAccessedMembers"
        }
      ],
      "n": "AreCompatible",
      "d": 720989,
      "h": 38655426653,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655426653),
//--TRIMMABLE-BOUNDARY-START(98784968797),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "GetSlot",
      "o": "@$1",
      "d": 720989,
      "h": 98784968797,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98784968797),
//--TRIMMABLE-BOUNDARY-START(81605099613),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "GetCallSite",
      "d": 720989,
      "h": 81605099613,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(81605099613),
//--TRIMMABLE-BOUNDARY-START(85900066909),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "GetCallSite",
      "o": "@$1",
      "d": 720989,
      "h": 85900066909,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85900066909),
//--TRIMMABLE-BOUNDARY-START(47245361245),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "CreateCallSite",
      "d": 720989,
      "h": 47245361245,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245361245),
//--TRIMMABLE-BOUNDARY-START(133144707165),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "TryCreateExact",
      "d": 720989,
      "h": 133144707165,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707165),
//--TRIMMABLE-BOUNDARY-START(141734641757),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "TryCreateOpenGeneric",
      "d": 720989,
      "h": 141734641757,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141734641757),
//--TRIMMABLE-BOUNDARY-START(128849739869),
    {
      "r": 2424925,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "TryCreateEnumerable",
      "d": 720989,
      "h": 128849739869,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849739869),
//--TRIMMABLE-BOUNDARY-START(90195034205),
    {
      "r": 917597,
      "p": [
        {
          "n": "locationA",
          "p": 917597
        },
        {
          "n": "locationB",
          "p": 917597
        }
      ],
      "n": "GetCommonCacheLocation",
      "d": 720989,
      "h": 90195034205,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195034205),
//--TRIMMABLE-BOUNDARY-START(137439674461),
    {
      "r": 2424925,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        },
        {
          "n": "slot",
          "p": 655361
        }
      ],
      "n": "TryCreateExact",
      "o": "@$1",
      "d": 720989,
      "h": 137439674461,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439674461),
//--TRIMMABLE-BOUNDARY-START(120259805277),
    {
      "r": 262145,
      "p": [
        {
          "n": "descriptorType",
          "p": 187760641
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "ShouldCreateExact",
      "d": 720989,
      "h": 120259805277,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120259805277),
//--TRIMMABLE-BOUNDARY-START(55835295837),
    {
      "r": 2424925,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        },
        {
          "n": "slot",
          "p": 655361
        }
      ],
      "n": "CreateExact",
      "d": 720989,
      "h": 55835295837,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835295837),
//--TRIMMABLE-BOUNDARY-START(146029609053),
    {
      "r": 2424925,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        },
        {
          "n": "slot",
          "p": 655361
        },
        {
          "n": "throwOnConstraintViolation",
          "p": 262145
        }
      ],
      "n": "TryCreateOpenGeneric",
      "o": "@$1",
      "d": 720989,
      "h": 146029609053,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029609053),
//--TRIMMABLE-BOUNDARY-START(124554772573),
    {
      "r": 262145,
      "p": [
        {
          "n": "descriptorType",
          "p": 187760641
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "ShouldCreateOpenGeneric",
      "d": 720989,
      "h": 124554772573,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124554772573),
//--TRIMMABLE-BOUNDARY-START(60130263133),
    {
      "r": 2424925,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "callSiteChain",
          "p": 589917
        },
        {
          "n": "slot",
          "p": 655361
        },
        {
          "n": "throwOnConstraintViolation",
          "p": 262145
        }
      ],
      "n": "CreateOpenGeneric",
      "d": 720989,
      "h": 60130263133,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130263133),
//--TRIMMABLE-BOUNDARY-START(51540328541),
    {
      "r": 1376349,
      "p": [
        {
          "n": "lifetime",
          "p": 2097245
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "callSiteChain",
          "p": 589917
        }
      ],
      "n": "CreateConstructorCallSite",
      "d": 720989,
      "h": 51540328541,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540328541),
//--TRIMMABLE-BOUNDARY-START(42950393949),
    {
      "r": $.$typeArray($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "implementationType",
          "p": 187760641
        },
        {
          "n": "callSiteChain",
          "p": 589917
        },
        {
          "n": "parameters",
          "p": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h
        },
        {
          "n": "throwIfCallSiteNotFound",
          "p": 262145
        }
      ],
      "n": "CreateArgumentCallSites",
      "d": 720989,
      "h": 42950393949,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393949),
//--TRIMMABLE-BOUNDARY-START(154619543645),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "genericTypeArguments",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "VerifyOpenGenericAotCompatibility",
      "d": 720989,
      "h": 154619543645,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(154619543645),
//--TRIMMABLE-BOUNDARY-START(34360459357),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "serviceCallSite",
          "p": 2424925
        }
      ],
      "n": "Add",
      "d": 720989,
      "h": 34360459357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360459357),
//--TRIMMABLE-BOUNDARY-START(107374903389),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "IsService",
      "d": 720989,
      "h": 107374903389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374903389),
//--TRIMMABLE-BOUNDARY-START(103079936093),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "IsKeyedService",
      "d": 720989,
      "h": 103079936093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079936093),
//--TRIMMABLE-BOUNDARY-START(111669870685),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        }
      ],
      "n": "IsService",
      "o": "@$1",
      "d": 720989,
      "h": 111669870685,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111669870685)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(64425230429),
    {
      "t": 655361,
      "n": "DefaultSlot",
      "d": 720989,
      "h": 64425230429,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64425230429),
//--TRIMMABLE-BOUNDARY-START(17180590173),
    {
      "t": $.$typeArray($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,
      "n": "_descriptors",
      "d": 720989,
      "h": 17180590173,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590173),
//--TRIMMABLE-BOUNDARY-START(4295688285),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,
      "n": "_callSiteCache",
      "d": 720989,
      "h": 4295688285,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688285),
//--TRIMMABLE-BOUNDARY-START(12885622877),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem).$h,
      "n": "_descriptorLookup",
      "d": 720989,
      "h": 12885622877,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622877),
//--TRIMMABLE-BOUNDARY-START(8590655581),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$$.System.Object).$h,
      "n": "_callSiteLocks",
      "d": 720989,
      "h": 8590655581,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655581),
//--TRIMMABLE-BOUNDARY-START(21475557469),
    {
      "t": 2949213,
      "n": "_stackGuard",
      "d": 720989,
      "h": 21475557469,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557469)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065492061),
    {
      "p": [
        {
          "n": "descriptors",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720989,
      "h": 30065492061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492061)
  ],
  "i": [917594,983130
  ],
  "j": [786525
  ],
  "h": 720989
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720989)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080285)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceProvider", ($self) => class ServiceProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298047581)
            /*CallSiteValidator?*/ _callSiteValidator = null;
            //--TRIMMABLE-BOUNDARY-END(4298047581)
            
            //--TRIMMABLE-BOUNDARY-START(8593014877)
            /*Func<ServiceIdentifier, ServiceAccessor>*/ _createServiceAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(8593014877)
            
            //--TRIMMABLE-BOUNDARY-START(17182949469)
            /*ServiceProviderEngine*/ _engine = null;
            //--TRIMMABLE-BOUNDARY-END(17182949469)
            
            //--TRIMMABLE-BOUNDARY-START(12887982173)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(12887982173)
            
            //--TRIMMABLE-BOUNDARY-START(21477916765)
            /*ConcurrentDictionary<ServiceIdentifier, ServiceAccessor>*/ _serviceAccessors = null;
            //--TRIMMABLE-BOUNDARY-END(21477916765)
            
            //--TRIMMABLE-BOUNDARY-START(60132622429)
            /*CallSiteFactory*/ CallSiteFactory = null;
            //--TRIMMABLE-BOUNDARY-END(60132622429)
            
            //--TRIMMABLE-BOUNDARY-START(184686674013)
            /*ServiceProviderEngineScope*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(184686674013)
            
            //--TRIMMABLE-BOUNDARY-START(197571575901)
            /*bool*/ static VerifyOpenGenericServiceTrimmability = false;
            //--TRIMMABLE-BOUNDARY-END(197571575901)
            
            //--TRIMMABLE-BOUNDARY-START(77312491613)
            /*bool*/ static DisableDynamicEngine = false;
            //--TRIMMABLE-BOUNDARY-END(77312491613)
            
            //--TRIMMABLE-BOUNDARY-START(193276608605)
            static /*bool */ get VerifyAotCompatibility()
            {
                return !$.$$.System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported;
            }
            //--TRIMMABLE-BOUNDARY-END(193276608605)
            
            //--TRIMMABLE-BOUNDARY-START(55837655133)
            $ctor$1(/*ICollection<ServiceDescriptor>*/ serviceDescriptors, /*ServiceProviderOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837655133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Root = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope().$ctor$1(this, true);
                    this._engine = this.GetEngine();
                    this._createServiceAccessor = new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor))().$ctor(this, this.CreateServiceAccessor);
                    this._serviceAccessors = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor))().$ctor$1();
                    this.CallSiteFactory = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory().$ctor$1(serviceDescriptors);
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$scm.System.IServiceProvider.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite().$ctor$2());
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type, this.Root, null));
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type, this.CallSiteFactory, null));
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type, this.CallSiteFactory, null));
                    if (options.ValidateScopes)
                    {
                        this._callSiteValidator = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator().$ctor$2();
                    }
                    if (options.ValidateOnBuild)
                    {
                        /*List<Exception>?*/ let exceptions = null;
                        var $en4 = serviceDescriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var serviceDescriptor = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                try
                                {
                                    this.ValidateService(serviceDescriptor);
                                }
                                catch(e)
                                {
                                    exceptions ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Exception))().$ctor$1();
                                    exceptions.Add(e);
                                }
                            }
                        }
                        if (exceptions !== null)
                        {
                            throw new $.$$.System.AggregateException().$ctor$14("Some services are not able to be constructed", exceptions.ToArray());
                        }
                    }
                    $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceProviderBuilt$1(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55837655133)
            
            //--TRIMMABLE-BOUNDARY-START(158916870237)
            /*object? */ GetService(/*Type*/ serviceType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158916870237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetService$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), this.Root);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158916870237)
            
            //--TRIMMABLE-BOUNDARY-START(146031968349)
            /*object? */ GetKeyedService$1(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146031968349);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetKeyedService(serviceType, serviceKey, this.Root);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146031968349)
            
            //--TRIMMABLE-BOUNDARY-START(141737001053)
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737001053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                {
                    if (!serviceType.IsGenericType || $.$$.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService();
                    }
                }
                return this.GetService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceKey, serviceType), serviceProviderEngineScope);
            }
            //--TRIMMABLE-BOUNDARY-END(141737001053)
            
            //--TRIMMABLE-BOUNDARY-START(154621902941)
            /*object */ GetRequiredKeyedService$1(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621902941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (serviceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                {
                    if (!serviceType.IsGenericType || $.$$.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService();
                    }
                }
                return this.GetRequiredKeyedService(serviceType, serviceKey, this.Root);
            }
            //--TRIMMABLE-BOUNDARY-END(154621902941)
            
            //--TRIMMABLE-BOUNDARY-START(150326935645)
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326935645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let service = this.GetKeyedService(serviceType, serviceKey, serviceProviderEngineScope);
                if (service === null)
                {
                    if (serviceKey === null)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_NoServiceRegistered(serviceType);
                    }
                    else 
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_NoKeyedServiceRegistered(serviceType, $.$$.System.Object.GetType.call(serviceKey));
                    }
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(150326935645)
            
            //--TRIMMABLE-BOUNDARY-START(167506804829)
            /*bool */ IsDisposed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167506804829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._disposed;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167506804829)
            
            //--TRIMMABLE-BOUNDARY-START(81607458909)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607458909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeCore();
                this.Root.Dispose();
            }
            //--TRIMMABLE-BOUNDARY-END(81607458909)
            
            //--TRIMMABLE-BOUNDARY-START(85902426205)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902426205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.DisposeCore();
                return this.Root.DisposeAsync();
            }
            //--TRIMMABLE-BOUNDARY-END(85902426205)
            
            //--TRIMMABLE-BOUNDARY-START(90197393501)
            /*void */ DisposeCore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197393501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._disposed = true;
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceProviderDisposed(this);
            }
            //--TRIMMABLE-BOUNDARY-END(90197393501)
            
            //--TRIMMABLE-BOUNDARY-START(171801772125)
            /*void */ OnCreate(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801772125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._callSiteValidator?.ValidateCallSite(callSite);
            }
            //--TRIMMABLE-BOUNDARY-END(171801772125)
            
            //--TRIMMABLE-BOUNDARY-START(176096739421)
            /*void */ OnResolve(/*ServiceCallSite?*/ callSite, /*IServiceScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096739421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callSite !== null)
                {
                    this._callSiteValidator?.ValidateResolution(callSite, scope, this.Root);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176096739421)
            
            //--TRIMMABLE-BOUNDARY-START(163211837533)
            /*object? */ GetService$1(/*ServiceIdentifier*/ serviceIdentifier, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211837533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                /*ServiceAccessor*/ let serviceAccessor = this._serviceAccessors.GetOrAdd(serviceIdentifier, this._createServiceAccessor);
                this.OnResolve(serviceAccessor.CallSite, serviceProviderEngineScope);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceResolved$1(this, serviceIdentifier.ServiceType);
                /*object?*/ let result = (serviceAccessor.RealizedService?.Invoke(serviceProviderEngineScope) ?? null);
                $.$$.System.Diagnostics.Debug.Assert$2(result === null || this.CallSiteFactory.IsService$1(serviceIdentifier), "result is null || CallSiteFactory.IsService(serviceIdentifier)");
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(163211837533)
            
            //--TRIMMABLE-BOUNDARY-START(188981641309)
            /*void */ ValidateService(/*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981641309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (descriptor.ServiceType.IsGenericType && !descriptor.ServiceType.IsConstructedGenericType)
                {
                    return;
                }
                try
                {
                    /*ServiceCallSite?*/ let callSite = this.CallSiteFactory.GetCallSite$1(descriptor, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain().$ctor$1());
                    if (callSite !== null)
                    {
                        this.OnCreate(callSite);
                    }
                }
                catch(e)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$11(`Error while validating the service descriptor '${$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ToString.call(descriptor)}': ${e.Message}`, e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188981641309)
            
            //--TRIMMABLE-BOUNDARY-START(68722557021)
            /*ServiceAccessor */ CreateServiceAccessor(/*ServiceIdentifier*/ serviceIdentifier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722557021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceCallSite?*/ let callSite = this.CallSiteFactory.GetCallSite(serviceIdentifier, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain().$ctor$1());
                if (callSite !== null)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.CallSiteBuilt$1(this, serviceIdentifier.ServiceType, callSite);
                    this.OnCreate(callSite);
                    if (callSite.Cache.Location === 0/*CallSiteResultCacheLocation.Root*/)
                    {
                        /*object?*/ let value = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, this.Root);
                        return (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                            const $i1 = new $t1();
                            $i1.CallSite = callSite;
                            $i1.RealizedService = new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object))().$ctor(this,  (/*scope*/ scope) =>
                            {
                                return value;
                            }, {
  "r": 131073,
  "p": [
    {
      "n": "scope",
      "p": 2818141
    }
  ],
  "n": "",
  "d": 3080285,
  "h": 0,
  "f": 17825794
});
                            return $i1;
                        })();
                    }
                    /*Func<ServiceProviderEngineScope, object?>*/ let realizedService = this._engine.RealizeService(callSite);
                    return (() =>
                    {
                        //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                        const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                        const $i1 = new $t1();
                        $i1.CallSite = callSite;
                        $i1.RealizedService = realizedService;
                        return $i1;
                    })();
                }
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                    const $i1 = new $t1();
                    $i1.CallSite = callSite;
                    $i1.RealizedService = new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object))().$ctor(this,  (/**/ _0) =>
                    {
                        return null;
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "_",
      "p": 2818141
    }
  ],
  "n": "",
  "d": 3080285,
  "h": 0,
  "f": 17825794
});
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(68722557021)
            
            //--TRIMMABLE-BOUNDARY-START(180391706717)
            /*void */ ReplaceServiceAccessor(/*ServiceCallSite*/ callSite, /*Func<ServiceProviderEngineScope, object?>*/ accessor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391706717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceAccessors.set_Item$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(callSite.Key, callSite.ServiceType), (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                    const $i1 = new $t1();
                    $i1.CallSite = callSite;
                    $i1.RealizedService = accessor;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(180391706717)
            
            //--TRIMMABLE-BOUNDARY-START(64427589725)
            /*IServiceScope */ CreateScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427589725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope().$ctor$1(this, false);
            }
            //--TRIMMABLE-BOUNDARY-END(64427589725)
            
            //--TRIMMABLE-BOUNDARY-START(137442033757)
            /*ServiceProviderEngine */ GetEngine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442033757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ServiceProviderEngine*/ let engine;
                //if (RuntimeFeature.IsDynamicCodeCompiled && !DisableDynamicEngine) { ... }
                //else 
                {
                    engine = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine.Instance;
                }
                return engine;
                /*ServiceProviderEngine*/  function CreateDynamicEngine()
                {
                    {
                        return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine().$ctor$3(this);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137442033757)
            
            //--TRIMMABLE-BOUNDARY-START(73017524317)
            /*string */ DebuggerToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73017524317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Root.DebuggerToString();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73017524317)
            
            //--TRIMMABLE-BOUNDARY-START(3145821)
            static $_ServiceAccessor;
            static get ServiceAccessor()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider;
                return $cls.$_ServiceAccessor ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor", ($self) => class ServiceAccessor extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17183015005)
                    /*ServiceCallSite?*/ CallSite = null;
                    //--TRIMMABLE-BOUNDARY-END(17183015005)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657851485)
                    /*Func<ServiceProviderEngineScope, object?>?*/ RealizedService = null;
                    //--TRIMMABLE-BOUNDARY-END(38657851485)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888047709)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888047709)
                    
                    static $h = 3145821;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17183015005),
    {
      "p": 2424925,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772949597,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247786077,
        "f": 83886081
      },
      "n": "CallSite",
      "d": 3145821,
      "h": 17183015005,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17183015005),
//--TRIMMABLE-BOUNDARY-START(38657851485),
    {
      "p": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362884189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55837720669,
        "f": 83886081
      },
      "n": "RealizedService",
      "d": 3145821,
      "h": 38657851485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657851485)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888047709),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3145821,
      "h": 12888047709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888047709)
  ],
  "d": 3080285,
  "h": 3145821
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor`; }
                }, $cls, ($v) => $cls.$_ServiceAccessor = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3145821)
            
            //--TRIMMABLE-BOUNDARY-START(4295688282)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyedService$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688282)
            
            //--TRIMMABLE-BOUNDARY-START(8590655578)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRequiredKeyedService$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590655578)
            
            //--TRIMMABLE-BOUNDARY-START(4295295014)
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295014)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(4384686081)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384686081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384686081)
            
            //--TRIMMABLE-BOUNDARY-START(51542687837)
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let verifyOpenGenerics;
                    this.VerifyOpenGenericServiceTrimmability = $.$$.System.AppContext.TryGetSwitch("Microsoft.Extensions.DependencyInjection.VerifyOpenGenericServiceTrimmability", $.$ref(() => verifyOpenGenerics, ($v) => verifyOpenGenerics = $v, $.$$.System.Boolean)) ? verifyOpenGenerics : false;
                }
                {
                    /*bool*/ let disableDynamicEngine;
                    this.DisableDynamicEngine = $.$$.System.AppContext.TryGetSwitch("Microsoft.Extensions.DependencyInjection.DisableDynamicEngine", $.$ref(() => disableDynamicEngine, ($v) => disableDynamicEngine = $v, $.$$.System.Boolean)) ? disableDynamicEngine : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51542687837)
            
            static $h = 3080285;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60132622429),
    {
      "p": 720989,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787328093,
        "f": 50331656
      },
      "n": "CallSiteFactory",
      "d": 3080285,
      "h": 60132622429,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(60132622429),
//--TRIMMABLE-BOUNDARY-START(184686674013),
    {
      "p": 2818141,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115967197277,
        "f": 50331656
      },
      "n": "Root",
      "d": 3080285,
      "h": 184686674013,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(184686674013),
//--TRIMMABLE-BOUNDARY-START(197571575901),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133147066461,
        "f": 50331688
      },
      "n": "VerifyOpenGenericServiceTrimmability",
      "d": 3080285,
      "h": 197571575901,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(197571575901),
//--TRIMMABLE-BOUNDARY-START(77312491613),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377262685,
        "f": 50331688
      },
      "n": "DisableDynamicEngine",
      "d": 3080285,
      "h": 77312491613,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(77312491613),
//--TRIMMABLE-BOUNDARY-START(193276608605),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124557131869,
        "f": 50331688
      },
      "n": "VerifyAotCompatibility",
      "d": 3080285,
      "h": 193276608605,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(193276608605)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(158916870237),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetService",
      "d": 3080285,
      "h": 158916870237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158916870237),
//--TRIMMABLE-BOUNDARY-START(146031968349),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "o": "@$1",
      "d": 3080285,
      "h": 146031968349,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146031968349),
//--TRIMMABLE-BOUNDARY-START(141737001053),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "serviceProviderEngineScope",
          "p": 2818141
        }
      ],
      "n": "GetKeyedService",
      "d": 3080285,
      "h": 141737001053,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(141737001053),
//--TRIMMABLE-BOUNDARY-START(154621902941),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "o": "@$1",
      "d": 3080285,
      "h": 154621902941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154621902941),
//--TRIMMABLE-BOUNDARY-START(150326935645),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "serviceProviderEngineScope",
          "p": 2818141
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 3080285,
      "h": 150326935645,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(150326935645),
//--TRIMMABLE-BOUNDARY-START(167506804829),
    {
      "r": 262145,
      "n": "IsDisposed",
      "d": 3080285,
      "h": 167506804829,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(167506804829),
//--TRIMMABLE-BOUNDARY-START(81607458909),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 3080285,
      "h": 81607458909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81607458909),
//--TRIMMABLE-BOUNDARY-START(85902426205),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 3080285,
      "h": 85902426205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85902426205),
//--TRIMMABLE-BOUNDARY-START(90197393501),
    {
      "r": 65537,
      "n": "DisposeCore",
      "d": 3080285,
      "h": 90197393501,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90197393501),
//--TRIMMABLE-BOUNDARY-START(171801772125),
    {
      "r": 65537,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "OnCreate",
      "d": 3080285,
      "h": 171801772125,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(171801772125),
//--TRIMMABLE-BOUNDARY-START(176096739421),
    {
      "r": 65537,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "scope",
          "p": 1048666
        }
      ],
      "n": "OnResolve",
      "d": 3080285,
      "h": 176096739421,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176096739421),
//--TRIMMABLE-BOUNDARY-START(163211837533),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "serviceProviderEngineScope",
          "p": 2818141
        }
      ],
      "n": "GetService",
      "o": "@$1",
      "d": 3080285,
      "h": 163211837533,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163211837533),
//--TRIMMABLE-BOUNDARY-START(188981641309),
    {
      "r": 65537,
      "p": [
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "ValidateService",
      "d": 3080285,
      "h": 188981641309,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(188981641309),
//--TRIMMABLE-BOUNDARY-START(68722557021),
    {
      "r": 3145821,
      "p": [
        {
          "n": "serviceIdentifier",
          "p": 2555997
        }
      ],
      "n": "CreateServiceAccessor",
      "d": 3080285,
      "h": 68722557021,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68722557021),
//--TRIMMABLE-BOUNDARY-START(180391706717),
    {
      "r": 65537,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "accessor",
          "p": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h
        }
      ],
      "n": "ReplaceServiceAccessor",
      "d": 3080285,
      "h": 180391706717,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(180391706717),
//--TRIMMABLE-BOUNDARY-START(64427589725),
    {
      "r": 1048666,
      "n": "CreateScope",
      "d": 3080285,
      "h": 64427589725,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64427589725),
//--TRIMMABLE-BOUNDARY-START(137442033757),
    {
      "r": 2752605,
      "n": "GetEngine",
      "d": 3080285,
      "h": 137442033757,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137442033757),
//--TRIMMABLE-BOUNDARY-START(73017524317),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 3080285,
      "h": 73017524317,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73017524317)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298047581),
    {
      "t": 1048669,
      "n": "_callSiteValidator",
      "d": 3080285,
      "h": 4298047581,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298047581),
//--TRIMMABLE-BOUNDARY-START(8593014877),
    {
      "t": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor).$h,
      "n": "_createServiceAccessor",
      "d": 3080285,
      "h": 8593014877,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593014877),
//--TRIMMABLE-BOUNDARY-START(17182949469),
    {
      "t": 2752605,
      "n": "_engine",
      "d": 3080285,
      "h": 17182949469,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17182949469),
//--TRIMMABLE-BOUNDARY-START(12887982173),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 3080285,
      "h": 12887982173,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887982173),
//--TRIMMABLE-BOUNDARY-START(21477916765),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor).$h,
      "n": "_serviceAccessors",
      "d": 3080285,
      "h": 21477916765,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477916765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55837655133),
    {
      "p": [
        {
          "n": "serviceDescriptors",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h
        },
        {
          "n": "options",
          "p": 3276893
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080285,
      "h": 55837655133,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55837655133)
  ],
  "i": [720986,327718,90308609,89718785
  ],
  "j": [3145821
  ],
  "h": 3080285,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, $.$scm.System.IServiceProvider, $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080285)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818141)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope", ($self) => class ServiceProviderEngineScope extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51542425693)
            /*IList<object> */ get Disposables()
            {
                return this._disposables ?? $.$$.System.Array.Empty($.$$.System.Object);
            }
            //--TRIMMABLE-BOUNDARY-END(51542425693)
            
            //--TRIMMABLE-BOUNDARY-START(8592752733)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8592752733)
            
            //--TRIMMABLE-BOUNDARY-START(4297785437)
            /*List<object>?*/ _disposables = null;
            //--TRIMMABLE-BOUNDARY-END(4297785437)
            
            //--TRIMMABLE-BOUNDARY-START(30067589213)
            $ctor$1(/*ServiceProvider*/ provider, /*bool*/ isRootScope)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067589213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ResolvedServices = new ($.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object))().$ctor$1();
                    this.RootProvider = provider;
                    this.IsRootScope = isRootScope;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067589213)
            
            //--TRIMMABLE-BOUNDARY-START(146031706205)
            /*Dictionary<ServiceCacheKey, object?>*/ ResolvedServices = null;
            //--TRIMMABLE-BOUNDARY-END(146031706205)
            
            //--TRIMMABLE-BOUNDARY-START(64427327581)
            /*bool */ get Disposed()
            {
                return this._disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(64427327581)
            
            //--TRIMMABLE-BOUNDARY-START(158916608093)
            /*object */ get Sync()
            {
                return this.ResolvedServices;
            }
            //--TRIMMABLE-BOUNDARY-END(158916608093)
            
            //--TRIMMABLE-BOUNDARY-START(141736738909)
            /*bool*/ IsRootScope = false;
            //--TRIMMABLE-BOUNDARY-END(141736738909)
            
            //--TRIMMABLE-BOUNDARY-START(150326673501)
            /*ServiceProvider*/ RootProvider = null;
            //--TRIMMABLE-BOUNDARY-END(150326673501)
            
            //--TRIMMABLE-BOUNDARY-START(137441771613)
            /*object? */ GetService(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441771613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetService$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), this);
            }
            //--TRIMMABLE-BOUNDARY-END(137441771613)
            
            //--TRIMMABLE-BOUNDARY-START(128851837021)
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851837021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetKeyedService(serviceType, serviceKey, this);
            }
            //--TRIMMABLE-BOUNDARY-END(128851837021)
            
            //--TRIMMABLE-BOUNDARY-START(133146804317)
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146804317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetRequiredKeyedService(serviceType, serviceKey, this);
            }
            //--TRIMMABLE-BOUNDARY-END(133146804317)
            
            //--TRIMMABLE-BOUNDARY-START(154621640797)
            /*IServiceProvider */ get ServiceProvider()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(154621640797)
            
            //--TRIMMABLE-BOUNDARY-START(42952491101)
            /*IServiceScope */ CreateScope()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952491101);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.RootProvider.CreateScope();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952491101)
            
            //--TRIMMABLE-BOUNDARY-START(38657523805)
            /*object? */ CaptureDisposable(/*object?*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657523805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals(this, service) || !($.$is(service, $.$$.System.IDisposable) || $.$is(service, $.$$.System.IAsyncDisposable)))
                {
                    return service;
                }
                /*bool*/ let disposed = false;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.Sync)
                    {
                        if (this._disposed)
                        {
                            disposed = true;
                        }
                        else 
                        {
                            this._disposables ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                            this._disposables.Add(service);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.Sync)
                }
                if (disposed)
                {
                    let disposable;
                    if ($.$is(service, $.$$.System.IDisposable, { set $v(v){ disposable = v; } }))
                    {
                        disposable.System$IDisposable$Dispose();
                    }
                    else 
                    {
                        /*object?*/ let localService = service;
                        $.$$.System.Threading.Tasks.Task.Run$3(new ($.$$.System.Func$$($.$$.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return ($.$cast(localService, $.$$.System.IAsyncDisposable)).System$IAsyncDisposable$DisposeAsync().AsTask();
                        }, {
  "r": 177668097,
  "n": "",
  "d": 2818141,
  "h": 0,
  "f": 17825794
})).GetAwaiter().GetResult();
                    }
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return service;
            }
            //--TRIMMABLE-BOUNDARY-END(38657523805)
            
            //--TRIMMABLE-BOUNDARY-START(55837392989)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837392989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<object>?*/ let toDispose = this.BeginDispose();
                if (toDispose !== null)
                {
                    for(/*int*/ let i = ((toDispose.Count - 1) | 0); i >= 0; i--)
                    {
                        let disposable;
                        if ($.$is(toDispose.get_Item(i), $.$$.System.IDisposable, { set $v(v){ disposable = v; } }))
                        {
                            disposable.System$IDisposable$Dispose();
                        }
                        else 
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$6($.$med.System.SR.AsyncDisposableServiceDispose, $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName(toDispose.get_Item(i), true)));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837392989)
            
            //--TRIMMABLE-BOUNDARY-START(60132360285)
            /*ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132360285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<object>?*/ let toDispose = this.BeginDispose();
                if (toDispose !== null)
                {
                    try
                    {
                        for(/*int*/ let i = ((toDispose.Count - 1) | 0); i >= 0; i--)
                        {
                            /*object*/ let disposable = toDispose.get_Item(i);
                            let asyncDisposable;
                            if ($.$is(disposable, $.$$.System.IAsyncDisposable, { set $v(v){ asyncDisposable = v; } }))
                            {
                                /*ValueTask*/ let vt = asyncDisposable.System$IAsyncDisposable$DisposeAsync();
                                if (!vt.IsCompletedSuccessfully)
                                {
                                    return Await(i, vt, toDispose);
                                }
                                vt.GetAwaiter().GetResult();
                            }
                            else 
                            {
                                ($.$cast(disposable, $.$$.System.IDisposable)).System$IDisposable$Dispose();
                            }
                        }
                    }
                    catch(ex)
                    {
                        return new $.$$.System.Threading.Tasks.ValueTask().$ctor$5($.$$.System.Threading.Tasks.Task.FromException(ex));
                    }
                }
                return new $.$$.System.Threading.Tasks.ValueTask();
                /*static ValueTask*/ /*async*/  function Await(/*int*/ i, /*ValueTask*/ vt, /*List<object>*/ toDispose)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask, $.$$.System.Void, async () => 
                    {
                        await vt.ConfigureAwait(false);
                        i--;
                        for(; i >= 0; i--)
                        {
                            /*object*/ let disposable = toDispose.get_Item(i);
                            let asyncDisposable;
                            if ($.$is(disposable, $.$$.System.IAsyncDisposable, { set $v(v){ asyncDisposable = v; } }))
                            {
                                await asyncDisposable.System$IAsyncDisposable$DisposeAsync().ConfigureAwait(false);
                            }
                            else 
                            {
                                ($.$cast(disposable, $.$$.System.IDisposable)).System$IDisposable$Dispose();
                            }
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132360285)
            
            //--TRIMMABLE-BOUNDARY-START(34362556509)
            /*List<object>? */ BeginDispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362556509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.Sync)
                    {
                        if (this._disposed)
                        {
                            return null;
                        }
                        $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ScopeDisposed($.$$.System.Object.GetHashCode.call(this.RootProvider), this.ResolvedServices.Count, (this._disposables?.Count ?? null) ?? 0);
                        this._disposed = true;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.Sync)
                }
                if (this.IsRootScope && !this.RootProvider.IsDisposed())
                {
                    this.RootProvider.Dispose();
                }
                return this._disposables;
            }
            //--TRIMMABLE-BOUNDARY-END(34362556509)
            
            //--TRIMMABLE-BOUNDARY-START(47247458397)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let debugText = `ServiceDescriptors = ${this.RootProvider.CallSiteFactory.Descriptors.length}`;
                if (!this.IsRootScope)
                {
                    debugText += `, IsScope = true`;
                }
                if (this._disposed)
                {
                    debugText += `, Disposed = true`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(47247458397)
            
            //--TRIMMABLE-BOUNDARY-START(8590983258)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ServiceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983258)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(4295688282)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688282)
            
            //--TRIMMABLE-BOUNDARY-START(8590655578)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetRequiredKeyedService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590655578)
            
            //--TRIMMABLE-BOUNDARY-START(4295295014)
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295014)
            
            //--TRIMMABLE-BOUNDARY-START(4384686081)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384686081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384686081)
            
            //--TRIMMABLE-BOUNDARY-START(4296081498)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.CreateScope()
            Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081498)
            
            static $h = 2818141;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51542425693),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73017262173,
        "f": 50331656
      },
      "n": "Disposables",
      "d": 2818141,
      "h": 51542425693,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51542425693),
//--TRIMMABLE-BOUNDARY-START(146031706205),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98787065949,
        "f": 50331656
      },
      "n": "ResolvedServices",
      "d": 2818141,
      "h": 146031706205,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(146031706205),
//--TRIMMABLE-BOUNDARY-START(64427327581),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81607196765,
        "f": 50331656
      },
      "n": "Disposed",
      "d": 2818141,
      "h": 64427327581,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(64427327581),
//--TRIMMABLE-BOUNDARY-START(158916608093),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556869725,
        "f": 50331656
      },
      "n": "Sync",
      "d": 2818141,
      "h": 158916608093,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(158916608093),
//--TRIMMABLE-BOUNDARY-START(141736738909),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197131357,
        "f": 50331649
      },
      "n": "IsRootScope",
      "d": 2818141,
      "h": 141736738909,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141736738909),
//--TRIMMABLE-BOUNDARY-START(150326673501),
    {
      "p": 3080285,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107377000541,
        "f": 50331656
      },
      "n": "RootProvider",
      "d": 2818141,
      "h": 150326673501,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(150326673501),
//--TRIMMABLE-BOUNDARY-START(154621640797),
    {
      "p": 327718,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966935133,
        "f": 50331649
      },
      "n": "ServiceProvider",
      "d": 2818141,
      "h": 154621640797,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154621640797)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137441771613),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetService",
      "d": 2818141,
      "h": 137441771613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441771613),
//--TRIMMABLE-BOUNDARY-START(128851837021),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetKeyedService",
      "d": 2818141,
      "h": 128851837021,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128851837021),
//--TRIMMABLE-BOUNDARY-START(133146804317),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": "GetRequiredKeyedService",
      "d": 2818141,
      "h": 133146804317,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133146804317),
//--TRIMMABLE-BOUNDARY-START(42952491101),
    {
      "r": 1048666,
      "n": "CreateScope",
      "d": 2818141,
      "h": 42952491101,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952491101),
//--TRIMMABLE-BOUNDARY-START(38657523805),
    {
      "r": 131073,
      "p": [
        {
          "n": "service",
          "p": 131073
        }
      ],
      "n": "CaptureDisposable",
      "d": 2818141,
      "h": 38657523805,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38657523805),
//--TRIMMABLE-BOUNDARY-START(55837392989),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2818141,
      "h": 55837392989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837392989),
//--TRIMMABLE-BOUNDARY-START(60132360285),
    {
      "r": 180551681,
      "n": "DisposeAsync",
      "d": 2818141,
      "h": 60132360285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132360285),
//--TRIMMABLE-BOUNDARY-START(34362556509),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.Object).$h,
      "n": "BeginDispose",
      "d": 2818141,
      "h": 34362556509,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34362556509),
//--TRIMMABLE-BOUNDARY-START(47247458397),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": 2818141,
      "h": 47247458397,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47247458397)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592752733),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 2818141,
      "h": 8592752733,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592752733),
//--TRIMMABLE-BOUNDARY-START(4297785437),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.Object).$h,
      "n": "_disposables",
      "d": 2818141,
      "h": 4297785437,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785437)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067589213),
    {
      "p": [
        {
          "n": "provider",
          "p": 3080285
        },
        {
          "n": "isRootScope",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2818141,
      "h": 30067589213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067589213)
  ],
  "i": [1048666,90308609,720986,327718,89718785,1114202
  ],
  "h": 2818141,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope, $.$$.System.IDisposable, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, $.$scm.System.IServiceProvider, $.$$.System.IAsyncDisposable, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818141)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572957)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionsServiceProviderEngine", ($self) => class ExpressionsServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            //--TRIMMABLE-BOUNDARY-START(4296540253)
            /*ExpressionResolverBuilder*/ _expressionResolverBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(4296540253)
            
            //--TRIMMABLE-BOUNDARY-START(8591507549)
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591507549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._expressionResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder().$ctor$2(serviceProvider);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507549)
            
            //--TRIMMABLE-BOUNDARY-START(12886474845)
            /*Func<ServiceProviderEngineScope, object> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._expressionResolverBuilder.Build(callSite);
            }
            //--TRIMMABLE-BOUNDARY-END(12886474845)
            
            static $h = 1572957;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2752605,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474845),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 1572957,
      "h": 12886474845,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886474845)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540253),
    {
      "t": 1507421,
      "n": "_expressionResolverBuilder",
      "d": 1572957,
      "h": 4296540253,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591507549),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572957,
      "h": 8591507549,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591507549)
  ],
  "h": 1572957
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionsServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572957)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704029)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite", ($self) => class IEnumerableCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            //--TRIMMABLE-BOUNDARY-START(68721180765)
            /*Type*/ ItemType = null;
            //--TRIMMABLE-BOUNDARY-END(68721180765)
            
            //--TRIMMABLE-BOUNDARY-START(77311115357)
            /*ServiceCallSite[]*/ ServiceCallSites = null;
            //--TRIMMABLE-BOUNDARY-END(77311115357)
            
            //--TRIMMABLE-BOUNDARY-START(17181573213)
            $ctor$2(/*ResultCache*/ cache, /*Type*/ itemType, /*ServiceCallSite[]*/ serviceCallSites, /*object?*/ serviceKey)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181573213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !itemType.IsValueType, "If VerifyAotCompatibility=true, an IEnumerableCallSite should not be created with a ValueType.");
                    this.ItemType = itemType;
                    this.ServiceCallSites = serviceCallSites;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181573213)
            
            //--TRIMMABLE-BOUNDARY-START(81606082653)
            /*Type */ get ServiceType()
            {
                return $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ this.ItemType ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(81606082653)
            
            //--TRIMMABLE-BOUNDARY-START(64426213469)
            /*Type */ get ImplementationType()
            {
                return this.ItemType.MakeArrayType();
            }
            //--TRIMMABLE-BOUNDARY-END(64426213469)
            
            //--TRIMMABLE-BOUNDARY-START(73016148061)
            /*CallSiteKind*/ Kind = 0;
            //--TRIMMABLE-BOUNDARY-END(73016148061)
            
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 3;
            }
            static $h = 1704029;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2424925,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721180765),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442397,
        "f": 50331656
      },
      "n": "ItemType",
      "d": 1704029,
      "h": 68721180765,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68721180765),
//--TRIMMABLE-BOUNDARY-START(77311115357),
    {
      "p": $.$typeArray($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541311581,
        "f": 50331656
      },
      "n": "ServiceCallSites",
      "d": 1704029,
      "h": 77311115357,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(77311115357),
//--TRIMMABLE-BOUNDARY-START(81606082653),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131246173,
        "f": 50364417
      },
      "n": "ServiceType",
      "d": 1704029,
      "h": 81606082653,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81606082653),
//--TRIMMABLE-BOUNDARY-START(64426213469),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771507805,
        "f": 50364417
      },
      "n": "ImplementationType",
      "d": 1704029,
      "h": 64426213469,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64426213469),
//--TRIMMABLE-BOUNDARY-START(73016148061),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951376989,
        "f": 50364417
      },
      "n": "Kind",
      "d": 1704029,
      "h": 73016148061,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016148061)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181573213),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "itemType",
          "p": 187760641
        },
        {
          "n": "serviceCallSites",
          "p": $.$typeArray($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h
        },
        {
          "n": "serviceKey",
          "p": 131073,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1704029,
      "h": 17181573213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573213)
  ],
  "h": 1704029
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704029)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097245)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache", ($self) => class ResultCache extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(51541704797)
            static /*ResultCache */ None(/*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541704797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cacheKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), 0);
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$3(3/*CallSiteResultCacheLocation.None*/, cacheKey);
            }
            //--TRIMMABLE-BOUNDARY-END(51541704797)
            
            //--TRIMMABLE-BOUNDARY-START(17181966429)
            $ctor$3(/*CallSiteResultCacheLocation*/ lifetime, /*ServiceCacheKey*/ cacheKey)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181966429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Location = lifetime;
                    this.Key = cacheKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181966429)
            
            //--TRIMMABLE-BOUNDARY-START(21476933725)
            $ctor$4(/*ServiceLifetime*/ lifetime, /*ServiceIdentifier*/ serviceIdentifier, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476933725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    switch(lifetime)
                    {
                        case 0/*ServiceLifetime.Singleton*/:
                        this.Location = 0/*CallSiteResultCacheLocation.Root*/;
                        break;
                        case 1/*ServiceLifetime.Scoped*/:
                        this.Location = 1/*CallSiteResultCacheLocation.Scope*/;
                        break;
                        case 2/*ServiceLifetime.Transient*/:
                        this.Location = 2/*CallSiteResultCacheLocation.Dispose*/;
                        break;
                        default:
                        this.Location = 3/*CallSiteResultCacheLocation.None*/;
                        break;
                    }
                    this.Key = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$4(serviceIdentifier, slot);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476933725)
            
            //--TRIMMABLE-BOUNDARY-START(47246737501)
            /*CallSiteResultCacheLocation*/ Location = 0;
            //--TRIMMABLE-BOUNDARY-END(47246737501)
            
            //--TRIMMABLE-BOUNDARY-START(42951770205)
            /*ServiceCacheKey*/ Key;
            //--TRIMMABLE-BOUNDARY-END(42951770205)
            
            //--TRIMMABLE-BOUNDARY-START(12886999133)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886999133)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Location = this.Location;
                copy.Key = this.Key.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Key = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey);
            }
            static $h = 2097245;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246737501),
    {
      "p": 917597,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656802909,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721573981,
        "f": 83886081
      },
      "n": "Location",
      "d": 2097245,
      "h": 47246737501,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246737501),
//--TRIMMABLE-BOUNDARY-START(42951770205),
    {
      "p": 2359389,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066868317,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131639389,
        "f": 83886081
      },
      "n": "Key",
      "d": 2097245,
      "h": 42951770205,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951770205)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541704797),
    {
      "r": 2097245,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "None",
      "d": 2097245,
      "h": 51541704797,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541704797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181966429),
    {
      "p": [
        {
          "n": "lifetime",
          "p": 917597
        },
        {
          "n": "cacheKey",
          "p": 2359389
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097245,
      "h": 17181966429,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181966429),
//--TRIMMABLE-BOUNDARY-START(21476933725),
    {
      "p": [
        {
          "n": "lifetime",
          "p": 1900634
        },
        {
          "n": "serviceIdentifier",
          "p": 2555997
        },
        {
          "n": "slot",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2097245,
      "h": 21476933725,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476933725),
//--TRIMMABLE-BOUNDARY-START(12886999133),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097245,
      "h": 12886999133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886999133)
  ],
  "h": 2097245
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097245)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687069)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite", ($self) => class ServiceProviderCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            //--TRIMMABLE-BOUNDARY-START(17182556253)
            $ctor$2()
            {
                super.$ctor$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache.None($.$scm.System.IServiceProvider.$type), null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182556253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182556253)
            
            //--TRIMMABLE-BOUNDARY-START(55837261917)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(55837261917)
            
            //--TRIMMABLE-BOUNDARY-START(47247327325)
            /*Type*/ ImplementationType = null;
            //--TRIMMABLE-BOUNDARY-END(47247327325)
            
            //--TRIMMABLE-BOUNDARY-START(51542294621)
            /*CallSiteKind*/ Kind = 0;
            //--TRIMMABLE-BOUNDARY-END(51542294621)
            
            //default member initializer
            constructor()
            {
                super();
                this.ServiceType = $.$scm.System.IServiceProvider.$type;
                this.ImplementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.$type;
                this.Kind = 4;
            }
            static $h = 2687069;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2424925,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55837261917),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952360029,
        "f": 50364417
      },
      "n": "ServiceType",
      "d": 2687069,
      "h": 55837261917,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55837261917),
//--TRIMMABLE-BOUNDARY-START(47247327325),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772490845,
        "f": 50364417
      },
      "n": "ImplementationType",
      "d": 2687069,
      "h": 47247327325,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(47247327325),
//--TRIMMABLE-BOUNDARY-START(51542294621),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362425437,
        "f": 50364417
      },
      "n": "Kind",
      "d": 2687069,
      "h": 51542294621,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51542294621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182556253),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687069,
      "h": 17182556253,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182556253)
  ],
  "h": 2687069
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687069)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031709)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitServiceProviderEngine", ($self) => class ILEmitServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            //--TRIMMABLE-BOUNDARY-START(4296999005)
            /*ILEmitResolverBuilder*/ _expressionResolverBuilder = null;
            //--TRIMMABLE-BOUNDARY-END(4296999005)
            
            //--TRIMMABLE-BOUNDARY-START(8591966301)
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591966301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._expressionResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder().$ctor$2(serviceProvider);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591966301)
            
            //--TRIMMABLE-BOUNDARY-START(12886933597)
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._expressionResolverBuilder.Build(callSite);
            }
            //--TRIMMABLE-BOUNDARY-END(12886933597)
            
            static $h = 2031709;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2752605,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886933597),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 2031709,
      "h": 12886933597,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886933597)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296999005),
    {
      "t": 1769565,
      "n": "_expressionResolverBuilder",
      "d": 2031709,
      "h": 4296999005,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296999005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591966301),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031709,
      "h": 8591966301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591966301)
  ],
  "h": 2031709
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031709)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310813)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite", ($self) => class ConstantCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            //--TRIMMABLE-BOUNDARY-START(4296278109)
            /*Type*/ _serviceType = null;
            //--TRIMMABLE-BOUNDARY-END(4296278109)
            
            //--TRIMMABLE-BOUNDARY-START(17181179997)
            /*object? */ get DefaultValue()
            {
                return this.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(17181179997)
            
            //--TRIMMABLE-BOUNDARY-START(12886212701)
            $ctor$2(/*Type*/ serviceType, /*object?*/ defaultValue, /*object?*/ serviceKey)
            {
                super.$ctor$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache.None(serviceType), serviceKey);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._serviceType = $.$firstOf(serviceType, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("serviceType") });
                    if (defaultValue !== null && !serviceType.IsInstanceOfType(defaultValue))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.ConstantCantBeConvertedToServiceType, $.$$.System.Object.GetType.call(defaultValue), serviceType));
                    }
                    this.Value = defaultValue;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212701)
            
            //--TRIMMABLE-BOUNDARY-START(64425820253)
            /*Type */ get ServiceType()
            {
                return this._serviceType;
            }
            //--TRIMMABLE-BOUNDARY-END(64425820253)
            
            //--TRIMMABLE-BOUNDARY-START(55835885661)
            /*Type */ get ImplementationType()
            {
                const $t1 = this.DefaultValue;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.GetType.call($t)) ?? this._serviceType;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885661)
            
            //--TRIMMABLE-BOUNDARY-START(60130852957)
            /*CallSiteKind*/ Kind = 0;
            //--TRIMMABLE-BOUNDARY-END(60130852957)
            
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 2;
            }
            static $h = 1310813;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2424925,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181179997),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771114589,
        "f": 50331656
      },
      "n": "DefaultValue",
      "d": 1310813,
      "h": 17181179997,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(17181179997),
//--TRIMMABLE-BOUNDARY-START(64425820253),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918365,
        "f": 50364417
      },
      "n": "ServiceType",
      "d": 1310813,
      "h": 64425820253,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425820253),
//--TRIMMABLE-BOUNDARY-START(55835885661),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361049181,
        "f": 50364417
      },
      "n": "ImplementationType",
      "d": 1310813,
      "h": 55835885661,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835885661),
//--TRIMMABLE-BOUNDARY-START(60130852957),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983773,
        "f": 50364417
      },
      "n": "Kind",
      "d": 1310813,
      "h": 60130852957,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130852957)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296278109),
    {
      "t": 187760641,
      "n": "_serviceType",
      "d": 1310813,
      "h": 4296278109,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278109)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886212701),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "defaultValue",
          "p": 131073
        },
        {
          "n": "serviceKey",
          "p": 131073,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310813,
      "h": 12886212701,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886212701)
  ],
  "h": 1310813
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310813)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376349)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite", ($self) => class ConstructorCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            //--TRIMMABLE-BOUNDARY-START(30066147421)
            /*ConstructorInfo*/ ConstructorInfo = null;
            //--TRIMMABLE-BOUNDARY-END(30066147421)
            
            //--TRIMMABLE-BOUNDARY-START(85900722269)
            /*ServiceCallSite[]*/ ParameterCallSites = null;
            //--TRIMMABLE-BOUNDARY-END(85900722269)
            
            //--TRIMMABLE-BOUNDARY-START(21476212829)
            $ctor$2(/*ResultCache*/ cache, /*Type*/ serviceType, /*ConstructorInfo*/ constructorInfo, /*object?*/ serviceKey)
            {
                this.$ctor$3(cache.Clone(), serviceType, constructorInfo, $.$$.System.Array.Empty($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), serviceKey);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476212829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212829)
            
            //--TRIMMABLE-BOUNDARY-START(25771180125)
            $ctor$3(/*ResultCache*/ cache, /*Type*/ serviceType, /*ConstructorInfo*/ constructorInfo, /*ServiceCallSite[]*/ parameterCallSites, /*object?*/ serviceKey)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771180125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!serviceType.IsAssignableFrom(constructorInfo.DeclaringType))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$med.System.SR.Format$5($.$med.System.SR.ImplementationTypeCantBeConvertedToServiceType, constructorInfo.DeclaringType, serviceType));
                    }
                    this.ServiceType = serviceType;
                    this.ConstructorInfo = constructorInfo;
                    this.ParameterCallSites = parameterCallSites;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771180125)
            
            //--TRIMMABLE-BOUNDARY-START(90195689565)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(90195689565)
            
            //--TRIMMABLE-BOUNDARY-START(77310787677)
            /*Type? */ get ImplementationType()
            {
                return this.ConstructorInfo.DeclaringType;
            }
            //--TRIMMABLE-BOUNDARY-END(77310787677)
            
            //--TRIMMABLE-BOUNDARY-START(81605754973)
            /*CallSiteKind*/ Kind = 0;
            //--TRIMMABLE-BOUNDARY-END(81605754973)
            
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 1;
            }
            static $h = 1376349;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2424925,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066147421),
    {
      "p": 108462081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656082013,
        "f": 50331656
      },
      "n": "ConstructorInfo",
      "d": 1376349,
      "h": 30066147421,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(30066147421),
//--TRIMMABLE-BOUNDARY-START(85900722269),
    {
      "p": $.$typeArray($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425885789,
        "f": 50331656
      },
      "n": "ParameterCallSites",
      "d": 1376349,
      "h": 85900722269,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(85900722269),
//--TRIMMABLE-BOUNDARY-START(90195689565),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015820381,
        "f": 50364417
      },
      "n": "ServiceType",
      "d": 1376349,
      "h": 90195689565,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195689565),
//--TRIMMABLE-BOUNDARY-START(77310787677),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246016605,
        "f": 50364417
      },
      "n": "ImplementationType",
      "d": 1376349,
      "h": 77310787677,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310787677),
//--TRIMMABLE-BOUNDARY-START(81605754973),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835951197,
        "f": 50364417
      },
      "n": "Kind",
      "d": 1376349,
      "h": 81605754973,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81605754973)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476212829),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "constructorInfo",
          "p": 108462081
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1376349,
      "h": 21476212829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476212829),
//--TRIMMABLE-BOUNDARY-START(25771180125),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "constructorInfo",
          "p": 108462081
        },
        {
          "n": "parameterCallSites",
          "p": $.$typeArray($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h
        },
        {
          "n": "serviceKey",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376349,
      "h": 25771180125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180125)
  ],
  "h": 1376349
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376349)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293853)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine", ($self) => class RuntimeServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            //--TRIMMABLE-BOUNDARY-START(25772097629)
            /*RuntimeServiceProviderEngine*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25772097629)
            
            //--TRIMMABLE-BOUNDARY-START(12887195741)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887195741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887195741)
            
            //--TRIMMABLE-BOUNDARY-START(30067064925)
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067064925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object))().$ctor(this,  (/**/ scope) =>
                {
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, scope);
                }, {
  "r": 131073,
  "p": [
    {
      "n": "scope",
      "p": 2818141
    }
  ],
  "n": "",
  "d": 2293853,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(30067064925)
            
            //--TRIMMABLE-BOUNDARY-START(8592228445)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine().$ctor$2();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592228445)
            
            static $h = 2293853;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2752605,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772097629),
    {
      "p": 2293853,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477130333,
        "f": 50331681
      },
      "n": "Instance",
      "d": 2293853,
      "h": 25772097629,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25772097629)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067064925),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 2293853,
      "h": 30067064925,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067064925)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887195741),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293853,
      "h": 12887195741,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887195741)
  ],
  "h": 2293853
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293853)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638493)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite", ($self) => class FactoryCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            //--TRIMMABLE-BOUNDARY-START(25771442269)
            /*Func<IServiceProvider, object>*/ Factory = null;
            //--TRIMMABLE-BOUNDARY-END(25771442269)
            
            //--TRIMMABLE-BOUNDARY-START(17181507677)
            $ctor$2(/*ResultCache*/ cache, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ factory)
            {
                super.$ctor$1(cache.Clone(), null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181507677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Factory = factory;
                    this.ServiceType = serviceType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181507677)
            
            //--TRIMMABLE-BOUNDARY-START(21476474973)
            $ctor$3(/*ResultCache*/ cache, /*Type*/ serviceType, /*object*/ serviceKey, /*Func<IServiceProvider, object, object>*/ factory)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476474973);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Factory = new ($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object))().$ctor(this,  (/*sp*/ sp) =>
                    {
                        return factory.Invoke(sp, serviceKey);
                    }, {
  "r": 131073,
  "p": [
    {
      "n": "sp",
      "p": 327718
    }
  ],
  "n": "",
  "d": 1638493,
  "h": 0,
  "f": 17825794
});
                    this.ServiceType = serviceType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476474973)
            
            //--TRIMMABLE-BOUNDARY-START(73016082525)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(73016082525)
            
            //--TRIMMABLE-BOUNDARY-START(64426147933)
            /*Type? */ get ImplementationType()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(64426147933)
            
            //--TRIMMABLE-BOUNDARY-START(68721115229)
            /*CallSiteKind*/ Kind = 0;
            //--TRIMMABLE-BOUNDARY-END(68721115229)
            
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 0;
            }
            static $h = 1638493;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2424925,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771442269),
    {
      "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361376861,
        "f": 50331649
      },
      "n": "Factory",
      "d": 1638493,
      "h": 25771442269,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771442269),
//--TRIMMABLE-BOUNDARY-START(73016082525),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131180637,
        "f": 50364417
      },
      "n": "ServiceType",
      "d": 1638493,
      "h": 73016082525,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016082525),
//--TRIMMABLE-BOUNDARY-START(64426147933),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951311453,
        "f": 50364417
      },
      "n": "ImplementationType",
      "d": 1638493,
      "h": 64426147933,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64426147933),
//--TRIMMABLE-BOUNDARY-START(68721115229),
    {
      "p": 852061,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541246045,
        "f": 50364417
      },
      "n": "Kind",
      "d": 1638493,
      "h": 68721115229,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721115229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181507677),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "factory",
          "p": $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638493,
      "h": 17181507677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181507677),
//--TRIMMABLE-BOUNDARY-START(21476474973),
    {
      "p": [
        {
          "n": "cache",
          "p": 2097245
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "factory",
          "p": $.$$.System.Func$$$$($.$scm.System.IServiceProvider, $.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638493,
      "h": 21476474973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476474973)
  ],
  "h": 1638493
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638493)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162781)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext", ($self) => class RuntimeResolverContext extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38656868445)
            /*ServiceProviderEngineScope*/ Scope = null;
            //--TRIMMABLE-BOUNDARY-END(38656868445)
            
            //--TRIMMABLE-BOUNDARY-START(17182031965)
            /*RuntimeResolverLock*/ AcquiredLocks = 0;
            //--TRIMMABLE-BOUNDARY-END(17182031965)
            
            //--TRIMMABLE-BOUNDARY-START(12887064669)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887064669)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Scope = this.Scope;
                copy.AcquiredLocks = this.AcquiredLocks;
                return copy;
            }
            static $h = 2162781;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656868445),
    {
      "p": 2818141,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361901149,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55836737629,
        "f": 83886081
      },
      "n": "Scope",
      "d": 2162781,
      "h": 38656868445,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656868445),
//--TRIMMABLE-BOUNDARY-START(17182031965),
    {
      "p": 2228317,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771966557,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47246803037,
        "f": 83886081
      },
      "n": "AcquiredLocks",
      "d": 2162781,
      "h": 17182031965,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17182031965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887064669),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2162781,
      "h": 12887064669,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887064669)
  ],
  "h": 2162781
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162781)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359389)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey", ($self) => class ServiceCacheKey extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55836934237)
            /*ServiceIdentifier*/ ServiceIdentifier;
            //--TRIMMABLE-BOUNDARY-END(55836934237)
            
            //--TRIMMABLE-BOUNDARY-START(60131901533)
            /*int*/ Slot = 0;
            //--TRIMMABLE-BOUNDARY-END(60131901533)
            
            //--TRIMMABLE-BOUNDARY-START(17182228573)
            $ctor$3(/*object*/ key, /*Type*/ type, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228573);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ServiceIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(key, type);
                    this.Slot = slot;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228573)
            
            //--TRIMMABLE-BOUNDARY-START(21477195869)
            $ctor$4(/*ServiceIdentifier*/ type, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477195869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ServiceIdentifier = type;
                    this.Slot = slot;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477195869)
            
            //--TRIMMABLE-BOUNDARY-START(30067130461)
            /*bool */ Equals$2(/*ServiceCacheKey*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067130461);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ServiceIdentifier.Equals$2(other.ServiceIdentifier) && this.Slot === other.Slot;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30067130461)
            
            //--TRIMMABLE-BOUNDARY-START(25772163165)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772163165);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, { set $v(v){ other = v; } }) && this.Equals$2(other);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25772163165)
            
            //--TRIMMABLE-BOUNDARY-START(51541966941)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541966941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    return ((($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.GetHashCode.call(this.ServiceIdentifier) * 397) | 0)) ^ this.Slot;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(51541966941)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey>.Equals(Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12887261277)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887261277)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ServiceIdentifier = this.ServiceIdentifier.Clone();
                copy.Slot = this.Slot;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ServiceIdentifier = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier);
            }
            static $h = 2359389;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836934237),
    {
      "p": 2555997,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657065053,
        "f": 50331649
      },
      "n": "ServiceIdentifier",
      "d": 2359389,
      "h": 55836934237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836934237),
//--TRIMMABLE-BOUNDARY-START(60131901533),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246999645,
        "f": 50331649
      },
      "n": "Slot",
      "d": 2359389,
      "h": 60131901533,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131901533)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30067130461),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2359389
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2359389,
      "h": 30067130461,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067130461),
//--TRIMMABLE-BOUNDARY-START(25772163165),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2359389,
      "h": 25772163165,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772163165),
//--TRIMMABLE-BOUNDARY-START(51541966941),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2359389,
      "h": 51541966941,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51541966941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228573),
    {
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "slot",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359389,
      "h": 17182228573,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228573),
//--TRIMMABLE-BOUNDARY-START(21477195869),
    {
      "p": [
        {
          "n": "type",
          "p": 2555997
        },
        {
          "n": "slot",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2359389,
      "h": 21477195869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477195869),
//--TRIMMABLE-BOUNDARY-START(12887261277),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2359389,
      "h": 12887261277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887261277)
  ],
  "i": [$.$$.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey).$h
  ],
  "h": 2359389
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359389)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555997)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier", ($self) => class ServiceIdentifier extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(68722032733)
            /*object?*/ ServiceKey = null;
            //--TRIMMABLE-BOUNDARY-END(68722032733)
            
            //--TRIMMABLE-BOUNDARY-START(73017000029)
            /*Type*/ ServiceType = null;
            //--TRIMMABLE-BOUNDARY-END(73017000029)
            
            //--TRIMMABLE-BOUNDARY-START(21477392477)
            $ctor$4(/*Type*/ serviceType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477392477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ServiceType = serviceType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477392477)
            
            //--TRIMMABLE-BOUNDARY-START(17182425181)
            $ctor$3(/*object?*/ serviceKey, /*Type*/ serviceType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182425181);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ServiceKey = serviceKey;
                    this.ServiceType = serviceType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182425181)
            
            //--TRIMMABLE-BOUNDARY-START(34362294365)
            static /*ServiceIdentifier */ FromDescriptor(/*ServiceDescriptor*/ serviceDescriptor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362294365);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceDescriptor.ServiceKey, serviceDescriptor.ServiceType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362294365)
            
            //--TRIMMABLE-BOUNDARY-START(38657261661)
            static /*ServiceIdentifier */ FromServiceType(/*Type*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657261661);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(null, type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38657261661)
            
            //--TRIMMABLE-BOUNDARY-START(30067327069)
            /*bool */ Equals$2(/*ServiceIdentifier*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067327069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceKey === null && other.ServiceKey === null)
                {
                    return $.$$.System.Type.op_Equality$1(this.ServiceType, other.ServiceType);
                }
                else if (this.ServiceKey !== null && other.ServiceKey !== null)
                {
                    return $.$$.System.Type.op_Equality$1(this.ServiceType, other.ServiceType) && $.$$.System.Object.Equals$1.call(this.ServiceKey, other.ServiceKey);
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(30067327069)
            
            //--TRIMMABLE-BOUNDARY-START(25772359773)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772359773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$is(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier) && this.Equals$2($.$cast(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25772359773)
            
            //--TRIMMABLE-BOUNDARY-START(64427065437)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427065437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceKey === null)
                {
                    return $.$$.System.Type.GetHashCode.call(this.ServiceType);
                }
                //unchecked
                {
                    return ((($.$$.System.Type.GetHashCode.call(this.ServiceType) * 397) | 0)) ^ $.$$.System.Object.GetHashCode.call(this.ServiceKey);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(64427065437)
            
            //--TRIMMABLE-BOUNDARY-START(60132098141)
            /*ServiceIdentifier */ GetGenericTypeDefinition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132098141);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(this.ServiceKey, this.ServiceType.GetGenericTypeDefinition());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60132098141)
            
            //--TRIMMABLE-BOUNDARY-START(77311967325)
            static/*conventional*/ /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311967325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.ServiceKey === null)
                {
                    return $.$$.System.Type.ToString.call(this.ServiceType);
                }
                return `(${$.$$.System.Object.ToString.call(this.ServiceKey)}, ${$.$$.System.Type.ToString.call(this.ServiceType)})`;
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(77311967325)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier>.Equals(Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12887457885)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887457885)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ServiceKey = this.ServiceKey;
                copy.ServiceType = this.ServiceType;
                return copy;
            }
            static $h = 2555997;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722032733),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247196253,
        "f": 50331649
      },
      "n": "ServiceKey",
      "d": 2555997,
      "h": 68722032733,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722032733),
//--TRIMMABLE-BOUNDARY-START(73017000029),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837130845,
        "f": 50331649
      },
      "n": "ServiceType",
      "d": 2555997,
      "h": 73017000029,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017000029)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362294365),
    {
      "r": 2555997,
      "p": [
        {
          "n": "serviceDescriptor",
          "p": 1704026
        }
      ],
      "n": "FromDescriptor",
      "d": 2555997,
      "h": 34362294365,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34362294365),
//--TRIMMABLE-BOUNDARY-START(38657261661),
    {
      "r": 2555997,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "FromServiceType",
      "d": 2555997,
      "h": 38657261661,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657261661),
//--TRIMMABLE-BOUNDARY-START(30067327069),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 2555997
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 2555997,
      "h": 30067327069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067327069),
//--TRIMMABLE-BOUNDARY-START(25772359773),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2555997,
      "h": 25772359773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772359773),
//--TRIMMABLE-BOUNDARY-START(64427065437),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2555997,
      "h": 64427065437,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64427065437),
//--TRIMMABLE-BOUNDARY-START(60132098141),
    {
      "r": 2555997,
      "n": "GetGenericTypeDefinition",
      "d": 2555997,
      "h": 60132098141,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132098141),
//--TRIMMABLE-BOUNDARY-START(77311967325),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2555997,
      "h": 77311967325,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311967325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477392477),
    {
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2555997,
      "h": 21477392477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477392477),
//--TRIMMABLE-BOUNDARY-START(17182425181),
    {
      "p": [
        {
          "n": "serviceKey",
          "p": 131073
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2555997,
      "h": 17182425181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182425181),
//--TRIMMABLE-BOUNDARY-START(12887457885),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2555997,
      "h": 12887457885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887457885)
  ],
  "i": [$.$$.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier).$h
  ],
  "h": 2555997
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555997)
        
        
        //--TRIMMABLE-BOUNDARY-START(196701)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DefaultServiceProviderFactory", ($self) => class DefaultServiceProviderFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163997)
            /*ServiceProviderOptions*/ _options = null;
            //--TRIMMABLE-BOUNDARY-END(4295163997)
            
            //--TRIMMABLE-BOUNDARY-START(8590131293)
            $ctor$1()
            {
                this.$ctor$2($.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions.Default);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131293);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131293)
            
            //--TRIMMABLE-BOUNDARY-START(12885098589)
            $ctor$2(/*ServiceProviderOptions*/ options)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098589);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._options = $.$firstOf(options, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("options") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098589)
            
            //--TRIMMABLE-BOUNDARY-START(17180065885)
            /*IServiceCollection */ CreateBuilder(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065885)
            
            //--TRIMMABLE-BOUNDARY-START(21475033181)
            /*IServiceProvider */ CreateServiceProvider(/*IServiceCollection*/ containerBuilder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$1(containerBuilder, this._options);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033181)
            
            //--TRIMMABLE-BOUNDARY-START(4295819354)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateBuilder(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateBuilder(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819354)
            
            //--TRIMMABLE-BOUNDARY-START(8590786650)
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateServiceProvider(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateServiceProvider(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786650)
            
            static $h = 196701;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065885),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "CreateBuilder",
      "d": 196701,
      "h": 17180065885,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065885),
//--TRIMMABLE-BOUNDARY-START(21475033181),
    {
      "r": 327718,
      "p": [
        {
          "n": "containerBuilder",
          "p": 786522
        }
      ],
      "n": "CreateServiceProvider",
      "d": 196701,
      "h": 21475033181,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033181)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163997),
    {
      "t": 3276893,
      "n": "_options",
      "d": 196701,
      "h": 4295163997,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131293),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196701,
      "h": 8590131293,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131293),
//--TRIMMABLE-BOUNDARY-START(12885098589),
    {
      "p": [
        {
          "n": "options",
          "p": 3276893
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196701,
      "h": 12885098589,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098589)
  ],
  "i": [$.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection).$h
  ],
  "h": 196701
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DefaultServiceProviderFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196701)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507421)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder", ($self) => class ExpressionResolverBuilder extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$$.System.Object, $.$sle.System.Linq.Expressions.Expression)
        {
            //--TRIMMABLE-BOUNDARY-START(73015951453)
            /*ParameterExpression*/ static ScopeParameter = null;
            //--TRIMMABLE-BOUNDARY-END(73015951453)
            
            //--TRIMMABLE-BOUNDARY-START(64426016861)
            /*ParameterExpression*/ static ResolvedServices = null;
            //--TRIMMABLE-BOUNDARY-END(64426016861)
            
            //--TRIMMABLE-BOUNDARY-START(77310918749)
            /*ParameterExpression*/ static Sync = null;
            //--TRIMMABLE-BOUNDARY-END(77310918749)
            
            //--TRIMMABLE-BOUNDARY-START(68720984157)
            /*BinaryExpression*/ static ResolvedServicesVariableAssignment = null;
            //--TRIMMABLE-BOUNDARY-END(68720984157)
            
            //--TRIMMABLE-BOUNDARY-START(81605886045)
            /*BinaryExpression*/ static SyncVariableAssignment = null;
            //--TRIMMABLE-BOUNDARY-END(81605886045)
            
            //--TRIMMABLE-BOUNDARY-START(51541114973)
            /*ParameterExpression*/ static CaptureDisposableParameter = null;
            //--TRIMMABLE-BOUNDARY-END(51541114973)
            
            //--TRIMMABLE-BOUNDARY-START(47246147677)
            /*LambdaExpression*/ static CaptureDisposable = null;
            //--TRIMMABLE-BOUNDARY-END(47246147677)
            
            //--TRIMMABLE-BOUNDARY-START(42951180381)
            /*ConstantExpression*/ static CallSiteRuntimeResolverInstanceExpression = null;
            //--TRIMMABLE-BOUNDARY-END(42951180381)
            
            //--TRIMMABLE-BOUNDARY-START(8591442013)
            /*ServiceProviderEngineScope*/ _rootScope = null;
            //--TRIMMABLE-BOUNDARY-END(8591442013)
            
            //--TRIMMABLE-BOUNDARY-START(12886409309)
            /*ConcurrentDictionary<ServiceCacheKey, Func<ServiceProviderEngineScope, object>>*/ _scopeResolverCache = null;
            //--TRIMMABLE-BOUNDARY-END(12886409309)
            
            //--TRIMMABLE-BOUNDARY-START(4296474717)
            /*Func<ServiceCacheKey, ServiceCallSite, Func<ServiceProviderEngineScope, object>>*/ _buildTypeDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(4296474717)
            
            //--TRIMMABLE-BOUNDARY-START(21476343901)
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343901);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._rootScope = serviceProvider.Root;
                    this._scopeResolverCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object)))().$ctor$1();
                    this._buildTypeDelegate = new ($.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object)))().$ctor(this,  (/*key*/ key, /*cs*/ cs) =>
                    {
                        return this.BuildNoCache(cs);
                    }, {
  "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
  "p": [
    {
      "n": "key",
      "p": 2359389
    },
    {
      "n": "cs",
      "p": 2424925
    }
  ],
  "n": "",
  "d": 1507421,
  "h": 0,
  "f": 17825794
});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343901)
            
            //--TRIMMABLE-BOUNDARY-START(25771311197)
            /*Func<ServiceProviderEngineScope, object> */ Build(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return this._scopeResolverCache.GetOrAdd$2($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, callSite.Cache.Key, this._buildTypeDelegate, callSite);
                }
                return this.BuildNoCache(callSite);
            }
            //--TRIMMABLE-BOUNDARY-END(25771311197)
            
            //--TRIMMABLE-BOUNDARY-START(34361245789)
            /*Func<ServiceProviderEngineScope, object> */ BuildNoCache(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Expression<Func<ServiceProviderEngineScope, object>>*/ let expression = this.BuildExpression(callSite);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.ExpressionTreeGenerated($.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log, this._rootScope.RootProvider, callSite.ServiceType, expression);
                return expression.Compile$3();
            }
            //--TRIMMABLE-BOUNDARY-END(34361245789)
            
            //--TRIMMABLE-BOUNDARY-START(30066278493)
            /*Expression<Func<ServiceProviderEngineScope, object>> */ BuildExpression(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object), $.$sle.System.Linq.Expressions.Expression.Block$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServicesVariableAssignment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.SyncVariableAssignment, this.BuildScopedExpression(callSite) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
                }
                return $.$sle.System.Linq.Expressions.Expression.Lambda$17($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object), $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite(callSite, null), $.$$.System.Object.$type, true), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30066278493)
            
            //--TRIMMABLE-BOUNDARY-START(111670657117)
            /*Expression */ VisitRootCache(/*ServiceCallSite*/ singletonCallSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.System.Linq.Expressions.Expression.Constant$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(singletonCallSite, this._rootScope));
            }
            //--TRIMMABLE-BOUNDARY-END(111670657117)
            
            //--TRIMMABLE-BOUNDARY-START(90195820637)
            /*Expression */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.System.Linq.Expressions.Expression.Constant$1(constantCallSite.DefaultValue);
            }
            //--TRIMMABLE-BOUNDARY-END(90195820637)
            
            //--TRIMMABLE-BOUNDARY-START(120260591709)
            /*Expression */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260591709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter;
            }
            //--TRIMMABLE-BOUNDARY-END(120260591709)
            
            //--TRIMMABLE-BOUNDARY-START(103080722525)
            /*Expression */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080722525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$sle.System.Linq.Expressions.Expression.Constant$1(factoryCallSite.Factory), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(103080722525)
            
            //--TRIMMABLE-BOUNDARY-START(107375689821)
            /*Expression */ VisitIEnumerable(/*IEnumerableCallSite*/ callSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static MethodInfo*/  function GetArrayEmptyMethodInfo(/*Type*/ elementType)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.GetArrayEmptyMethodInfo(elementType);
                }
                /*static NewArrayExpression*/  function NewArrayInit(/*Type*/ elementType, /*IEnumerable<Expression>*/ expr)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$sle.System.Linq.Expressions.Expression.NewArrayInit(elementType, expr);
                }
                if (callSite.ServiceCallSites.length === 0)
                {
                    return $.$sle.System.Linq.Expressions.Expression.Constant$1(GetArrayEmptyMethodInfo(callSite.ItemType).Invoke(null, $.$$.System.Array.Empty($.$$.System.Object)));
                }
                return NewArrayInit(callSite.ItemType, $.$sl.System.Linq.Enumerable.Select$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$sle.System.Linq.Expressions.Expression, callSite.ServiceCallSites, new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$sle.System.Linq.Expressions.Expression))().$ctor(this,  (/**/ cs) =>
                {
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite(cs, context), callSite.ItemType, false);
                }, {
  "r": 8781861,
  "p": [
    {
      "n": "cs",
      "p": 2424925
    }
  ],
  "n": "",
  "d": 1507421,
  "h": 0,
  "f": 17825794
})));
            }
            //--TRIMMABLE-BOUNDARY-END(107375689821)
            
            //--TRIMMABLE-BOUNDARY-START(98785755229)
            /*Expression */ VisitDisposeCache(/*ServiceCallSite*/ callSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.TryCaptureDisposable(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, this.VisitCallSiteMain(callSite, context));
            }
            //--TRIMMABLE-BOUNDARY-END(98785755229)
            
            //--TRIMMABLE-BOUNDARY-START(85900853341)
            static /*Expression */ TryCaptureDisposable(/*ServiceCallSite*/ callSite, /*ParameterExpression*/ scope, /*Expression*/ service)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!callSite.CaptureDisposable)
                {
                    return service;
                }
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.GetCaptureDisposable(scope), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ service ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(85900853341)
            
            //--TRIMMABLE-BOUNDARY-START(94490787933)
            /*Expression */ VisitConstructor(/*ConstructorCallSite*/ callSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ParameterInfo[]*/ let parameters = callSite.ConstructorInfo.GetParameters();
                /*Expression[]*/ let parameterExpressions;
                if (callSite.ParameterCallSites.length === 0)
                {
                    parameterExpressions = $.$$.System.Array.Empty($.$sle.System.Linq.Expressions.Expression);
                }
                else 
                {
                    parameterExpressions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), null, [callSite.ParameterCallSites.length], null);
                    for(/*int*/ let i = 0; i < parameterExpressions.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(parameterExpressions, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite($.$$.System.Array.$ReadT1.call(callSite.ParameterCallSites, i), context), $.$$.System.Array.$ReadT1.call(parameters, i).ParameterType, false), i);
                    }
                }
                /*Expression*/ let expression = $.$sle.System.Linq.Expressions.Expression.New$3(callSite.ConstructorInfo, parameterExpressions);
                if (callSite.ImplementationType.IsValueType)
                {
                    expression = $.$sle.System.Linq.Expressions.Expression.Convert$1(expression, $.$$.System.Object.$type);
                }
                return expression;
            }
            //--TRIMMABLE-BOUNDARY-END(94490787933)
            
            //--TRIMMABLE-BOUNDARY-START(55836082269)
            static /*Expression */ Convert(/*Expression*/ expression, /*Type*/ type, /*bool*/ forceValueTypeConversion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsAssignableFrom(expression.Type) && (!expression.Type.IsValueType || !forceValueTypeConversion))
                {
                    return expression;
                }
                return $.$sle.System.Linq.Expressions.Expression.Convert$1(expression, type);
            }
            //--TRIMMABLE-BOUNDARY-END(55836082269)
            
            //--TRIMMABLE-BOUNDARY-START(115965624413)
            /*Expression */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*object?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Func<ServiceProviderEngineScope, object>*/ let lambda = this.Build(callSite);
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$sle.System.Linq.Expressions.Expression.Constant$1(lambda), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(115965624413)
            
            //--TRIMMABLE-BOUNDARY-START(38656213085)
            /*ConditionalExpression */ BuildScopedExpression(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ConstantExpression*/ let callSiteExpression = $.$sle.System.Linq.Expressions.Expression.Constant(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite.$type);
                /*MethodCallExpression*/ let resolveRootScopeExpression = $.$sle.System.Linq.Expressions.Expression.Call$11($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CallSiteRuntimeResolverInstanceExpression, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.ResolveCallSiteAndScopeMethodInfo, callSiteExpression, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter);
                /*ConstantExpression*/ let keyExpression = $.$sle.System.Linq.Expressions.Expression.Constant(callSite.Cache.Key, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type);
                /*ParameterExpression*/ let resolvedVariable = $.$sle.System.Linq.Expressions.Expression.Variable($.$$.System.Object.$type, "resolved");
                /*ParameterExpression*/ let resolvedServices = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices;
                /*MethodCallExpression*/ let tryGetValueExpression = $.$sle.System.Linq.Expressions.Expression.Call$11(resolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.TryGetValueMethodInfo, keyExpression, resolvedVariable);
                /*Expression*/ let captureDisposible = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.TryCaptureDisposable(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, this.VisitCallSiteMain(callSite, null));
                /*BinaryExpression*/ let assignExpression = $.$sle.System.Linq.Expressions.Expression.Assign(resolvedVariable, captureDisposible);
                /*MethodCallExpression*/ let addValueExpression = $.$sle.System.Linq.Expressions.Expression.Call$11(resolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.AddMethodInfo, keyExpression, resolvedVariable);
                /*BlockExpression*/ let blockExpression = $.$sle.System.Linq.Expressions.Expression.Block$5($.$$.System.Object.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [resolvedVariable], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.IfThen($.$sle.System.Linq.Expressions.Expression.Not$1(tryGetValueExpression), $.$sle.System.Linq.Expressions.Expression.Block$10(assignExpression, addValueExpression)), resolvedVariable ], null, null));
                /*ParameterExpression*/ let lockWasTaken = $.$sle.System.Linq.Expressions.Expression.Variable($.$$.System.Boolean.$type, "lockWasTaken");
                /*ParameterExpression*/ let sync = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync;
                /*MethodCallExpression*/ let monitorEnter = $.$sle.System.Linq.Expressions.Expression.Call$4($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorEnterMethodInfo, sync, lockWasTaken);
                /*MethodCallExpression*/ let monitorExit = $.$sle.System.Linq.Expressions.Expression.Call$5($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorExitMethodInfo, sync);
                /*BlockExpression*/ let tryBody = $.$sle.System.Linq.Expressions.Expression.Block$10(monitorEnter, blockExpression);
                /*ConditionalExpression*/ let finallyBody = $.$sle.System.Linq.Expressions.Expression.IfThen(lockWasTaken, monitorExit);
                return $.$sle.System.Linq.Expressions.Expression.Condition$1($.$sle.System.Linq.Expressions.Expression.Property$3($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("IsRootScope", 4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/)), resolveRootScopeExpression, $.$sle.System.Linq.Expressions.Expression.Block$5($.$$.System.Object.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [lockWasTaken], null, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.TryFinally(tryBody, finallyBody) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(38656213085)
            
            //--TRIMMABLE-BOUNDARY-START(60131049565)
            static /*Expression */ GetCaptureDisposable(/*ParameterExpression*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (scope !== $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$med.System.SR.GetCaptureDisposableNotSupported);
                }
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposable;
            }
            //--TRIMMABLE-BOUNDARY-END(60131049565)
            
            //--TRIMMABLE-BOUNDARY-START(17181376605)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(73015951453)
                    this.ScopeParameter = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type);
                    //--TRIMMABLE-BOUNDARY-END(73015951453)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426016861)
                    this.ResolvedServices = $.$sle.System.Linq.Expressions.Expression.Variable($.$$.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object).$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter.Name + "resolvedServices");
                    //--TRIMMABLE-BOUNDARY-END(64426016861)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310918749)
                    this.Sync = $.$sle.System.Linq.Expressions.Expression.Variable($.$$.System.Object.$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter.Name + "sync");
                    //--TRIMMABLE-BOUNDARY-END(77310918749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720984157)
                    this.ResolvedServicesVariableAssignment = $.$sle.System.Linq.Expressions.Expression.Assign($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices, $.$sle.System.Linq.Expressions.Expression.Property$3($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("ResolvedServices", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/)));
                    //--TRIMMABLE-BOUNDARY-END(68720984157)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605886045)
                    this.SyncVariableAssignment = $.$sle.System.Linq.Expressions.Expression.Assign($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync, $.$sle.System.Linq.Expressions.Expression.Property$3($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("Sync", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/)));
                    //--TRIMMABLE-BOUNDARY-END(81605886045)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541114973)
                    this.CaptureDisposableParameter = $.$sle.System.Linq.Expressions.Expression.Parameter$1($.$$.System.Object.$type);
                    //--TRIMMABLE-BOUNDARY-END(51541114973)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246147677)
                    this.CaptureDisposable = $.$sle.System.Linq.Expressions.Expression.Lambda$5($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object).$type, $.$sle.System.Linq.Expressions.Expression.Call$13($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.CaptureDisposableMethodInfo, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposableParameter ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposableParameter ], null, null));
                    //--TRIMMABLE-BOUNDARY-END(47246147677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951180381)
                    this.CallSiteRuntimeResolverInstanceExpression = $.$sle.System.Linq.Expressions.Expression.Constant($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type);
                    //--TRIMMABLE-BOUNDARY-END(42951180381)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181376605)
            
            static $h = 1507421;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771311197),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "Build",
      "d": 1507421,
      "h": 25771311197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771311197),
//--TRIMMABLE-BOUNDARY-START(34361245789),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "BuildNoCache",
      "d": 1507421,
      "h": 34361245789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361245789),
//--TRIMMABLE-BOUNDARY-START(30066278493),
    {
      "r": $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object)).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "BuildExpression",
      "d": 1507421,
      "h": 30066278493,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30066278493),
//--TRIMMABLE-BOUNDARY-START(111670657117),
    {
      "r": 8781861,
      "p": [
        {
          "n": "singletonCallSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitRootCache",
      "d": 1507421,
      "h": 111670657117,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111670657117),
//--TRIMMABLE-BOUNDARY-START(90195820637),
    {
      "r": 8781861,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitConstant",
      "d": 1507421,
      "h": 90195820637,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(90195820637),
//--TRIMMABLE-BOUNDARY-START(120260591709),
    {
      "r": 8781861,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitServiceProvider",
      "d": 1507421,
      "h": 120260591709,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(120260591709),
//--TRIMMABLE-BOUNDARY-START(103080722525),
    {
      "r": 8781861,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitFactory",
      "d": 1507421,
      "h": 103080722525,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(103080722525),
//--TRIMMABLE-BOUNDARY-START(107375689821),
    {
      "r": 8781861,
      "p": [
        {
          "n": "callSite",
          "p": 1704029
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitIEnumerable",
      "d": 1507421,
      "h": 107375689821,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107375689821),
//--TRIMMABLE-BOUNDARY-START(98785755229),
    {
      "r": 8781861,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitDisposeCache",
      "d": 1507421,
      "h": 98785755229,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(98785755229),
//--TRIMMABLE-BOUNDARY-START(85900853341),
    {
      "r": 8781861,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "scope",
          "p": 40566821
        },
        {
          "n": "service",
          "p": 8781861
        }
      ],
      "n": "TryCaptureDisposable",
      "d": 1507421,
      "h": 85900853341,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85900853341),
//--TRIMMABLE-BOUNDARY-START(94490787933),
    {
      "r": 8781861,
      "p": [
        {
          "n": "callSite",
          "p": 1376349
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitConstructor",
      "d": 1507421,
      "h": 94490787933,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(94490787933),
//--TRIMMABLE-BOUNDARY-START(55836082269),
    {
      "r": 8781861,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "forceValueTypeConversion",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "Convert",
      "d": 1507421,
      "h": 55836082269,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836082269),
//--TRIMMABLE-BOUNDARY-START(115965624413),
    {
      "r": 8781861,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 131073
        }
      ],
      "n": "VisitScopeCache",
      "d": 1507421,
      "h": 115965624413,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(115965624413),
//--TRIMMABLE-BOUNDARY-START(38656213085),
    {
      "r": 7733285,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "BuildScopedExpression",
      "d": 1507421,
      "h": 38656213085,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38656213085),
//--TRIMMABLE-BOUNDARY-START(60131049565),
    {
      "r": 8781861,
      "p": [
        {
          "n": "scope",
          "p": 40566821
        }
      ],
      "n": "GetCaptureDisposable",
      "d": 1507421,
      "h": 60131049565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60131049565)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015951453),
    {
      "t": 40566821,
      "n": "ScopeParameter",
      "d": 1507421,
      "h": 73015951453,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015951453),
//--TRIMMABLE-BOUNDARY-START(64426016861),
    {
      "t": 40566821,
      "n": "ResolvedServices",
      "d": 1507421,
      "h": 64426016861,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64426016861),
//--TRIMMABLE-BOUNDARY-START(77310918749),
    {
      "t": 40566821,
      "n": "Sync",
      "d": 1507421,
      "h": 77310918749,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310918749),
//--TRIMMABLE-BOUNDARY-START(68720984157),
    {
      "t": 3670053,
      "n": "ResolvedServicesVariableAssignment",
      "d": 1507421,
      "h": 68720984157,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68720984157),
//--TRIMMABLE-BOUNDARY-START(81605886045),
    {
      "t": 3670053,
      "n": "SyncVariableAssignment",
      "d": 1507421,
      "h": 81605886045,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605886045),
//--TRIMMABLE-BOUNDARY-START(51541114973),
    {
      "t": 40566821,
      "n": "CaptureDisposableParameter",
      "d": 1507421,
      "h": 51541114973,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541114973),
//--TRIMMABLE-BOUNDARY-START(47246147677),
    {
      "t": 38797349,
      "n": "CaptureDisposable",
      "d": 1507421,
      "h": 47246147677,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47246147677),
//--TRIMMABLE-BOUNDARY-START(42951180381),
    {
      "t": 7864357,
      "n": "CallSiteRuntimeResolverInstanceExpression",
      "d": 1507421,
      "h": 42951180381,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951180381),
//--TRIMMABLE-BOUNDARY-START(8591442013),
    {
      "t": 2818141,
      "n": "_rootScope",
      "d": 1507421,
      "h": 8591442013,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591442013),
//--TRIMMABLE-BOUNDARY-START(12886409309),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object)).$h,
      "n": "_scopeResolverCache",
      "d": 1507421,
      "h": 12886409309,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409309),
//--TRIMMABLE-BOUNDARY-START(4296474717),
    {
      "t": $.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object)).$h,
      "n": "_buildTypeDelegate",
      "d": 1507421,
      "h": 4296474717,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474717)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476343901),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507421,
      "h": 21476343901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343901)
  ],
  "h": 1507421
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$$.System.Object, $.$sle.System.Linq.Expressions.Expression); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507421)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441885)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine", ($self) => class DynamicServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine
        {
            //--TRIMMABLE-BOUNDARY-START(4296409181)
            /*ServiceProvider*/ _serviceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(4296409181)
            
            //--TRIMMABLE-BOUNDARY-START(8591376477)
            $ctor$3(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$2(serviceProvider);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._serviceProvider = serviceProvider;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376477)
            
            //--TRIMMABLE-BOUNDARY-START(12886343773)
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let callCount = 0;
                return new ($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object))().$ctor(this,  (/*scope*/ scope) =>
                {
                    /*var*/ let result = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, scope);
                    if ($.$$.System.Threading.Interlocked.Increment($.$ref(() => callCount, ($v) => callCount = $v, $.$$.System.Int32)) === 2)
                    {
                        _ = $.$$.System.Threading.ThreadPool.UnsafeQueueUserWorkItem$1(new $.$$.System.Threading.WaitCallback().$ctor(this,  (/*_*/ _0) =>
                        {
                            try
                            {
                                this._serviceProvider.ReplaceServiceAccessor(callSite, super.RealizeService(callSite));
                            }
                            catch(ex)
                            {
                                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceRealizationFailed(ex, $.$$.System.Object.GetHashCode.call(this._serviceProvider));
                                $.$$.System.Diagnostics.Debug.Fail$1(`We should never get exceptions from the background compilation.${$.$$.System.Environment.NewLine}${$.$$.System.Exception.ToString.call(ex)}`);
                            }
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "_",
      "p": 131073
    }
  ],
  "n": "",
  "d": 1441885,
  "h": 0,
  "f": 17825794
}), null);
                    }
                    return result;
                }, {
  "r": 131073,
  "p": [
    {
      "n": "scope",
      "p": 2818141
    }
  ],
  "n": "",
  "d": 1441885,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(12886343773)
            
            static $h = 1441885;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1245277,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886343773),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "RealizeService",
      "d": 1441885,
      "h": 12886343773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886343773)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409181),
    {
      "t": 3080285,
      "n": "_serviceProvider",
      "d": 1441885,
      "h": 4296409181,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409181)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376477),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441885,
      "h": 8591376477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376477)
  ],
  "h": 1441885
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441885)
        
        
        //--TRIMMABLE-BOUNDARY-START(917597)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation", ($self) => class CallSiteResultCacheLocation extends $.$$.System.Enum
        {
            static Root = 0;
            static Scope = 1;
            static Dispose = 2;
            static None = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Root": 0n,
                    "Scope": 1n,
                    "Dispose": 2n,
                    "None": 3n
                };
            }
            static $h = 917597;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786781),
    {
      "t": 917597,
      "n": "Root",
      "d": 917597,
      "h": 17180786781,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786781),
//--TRIMMABLE-BOUNDARY-START(21475754077),
    {
      "t": 917597,
      "n": "Scope",
      "d": 917597,
      "h": 21475754077,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754077),
//--TRIMMABLE-BOUNDARY-START(8590852189),
    {
      "t": 917597,
      "n": "Dispose",
      "d": 917597,
      "h": 8590852189,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852189),
//--TRIMMABLE-BOUNDARY-START(12885819485),
    {
      "t": 917597,
      "n": "None",
      "d": 917597,
      "h": 12885819485,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819485)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884893),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917597,
      "h": 4295884893,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884893)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 917597
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917597)
        
        
        //--TRIMMABLE-BOUNDARY-START(852061)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind", ($self) => class CallSiteKind extends $.$$.System.Enum
        {
            static Factory = 0;
            static Constructor = 1;
            static Constant = 2;
            static IEnumerable = 3;
            static ServiceProvider = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Factory": 0n,
                    "Constructor": 1n,
                    "Constant": 2n,
                    "IEnumerable": 3n,
                    "ServiceProvider": 4n
                };
            }
            static $h = 852061;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180721245),
    {
      "t": 852061,
      "n": "Factory",
      "d": 852061,
      "h": 17180721245,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721245),
//--TRIMMABLE-BOUNDARY-START(12885753949),
    {
      "t": 852061,
      "n": "Constructor",
      "d": 852061,
      "h": 12885753949,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753949),
//--TRIMMABLE-BOUNDARY-START(8590786653),
    {
      "t": 852061,
      "n": "Constant",
      "d": 852061,
      "h": 8590786653,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786653),
//--TRIMMABLE-BOUNDARY-START(21475688541),
    {
      "t": 852061,
      "n": "IEnumerable",
      "d": 852061,
      "h": 21475688541,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475688541),
//--TRIMMABLE-BOUNDARY-START(25770655837),
    {
      "t": 852061,
      "n": "ServiceProvider",
      "d": 852061,
      "h": 25770655837,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770655837)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819357),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852061,
      "h": 4295819357,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819357)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 852061
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852061)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228317)
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverLock", ($self) => class RuntimeResolverLock extends $.$$.System.Enum
        {
            static Scope = 1;
            static Root = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2228317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Scope": 1n,
                    "Root": 2n
                };
            }
            static $h = 2228317;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887130205),
    {
      "t": 2228317,
      "n": "Scope",
      "d": 2228317,
      "h": 12887130205,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887130205),
//--TRIMMABLE-BOUNDARY-START(8592162909),
    {
      "t": 2228317,
      "n": "Root",
      "d": 2228317,
      "h": 8592162909,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592162909)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195613),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2228317,
      "h": 4297195613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195613)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2228317,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverLock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228317)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769565)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder", ($self) => class ILEmitResolverBuilder extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext, $.$$.System.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(94491050077)
            /*MethodInfo*/ static ResolvedServicesGetter = null;
            //--TRIMMABLE-BOUNDARY-END(94491050077)
            
            //--TRIMMABLE-BOUNDARY-START(103080984669)
            /*MethodInfo*/ static ScopeLockGetter = null;
            //--TRIMMABLE-BOUNDARY-END(103080984669)
            
            //--TRIMMABLE-BOUNDARY-START(98786017373)
            /*MethodInfo*/ static ScopeIsRootScope = null;
            //--TRIMMABLE-BOUNDARY-END(98786017373)
            
            //--TRIMMABLE-BOUNDARY-START(68721246301)
            /*MethodInfo*/ static CallSiteRuntimeResolverResolveMethod = null;
            //--TRIMMABLE-BOUNDARY-END(68721246301)
            
            //--TRIMMABLE-BOUNDARY-START(64426279005)
            /*MethodInfo*/ static CallSiteRuntimeResolverInstanceField = null;
            //--TRIMMABLE-BOUNDARY-END(64426279005)
            
            //--TRIMMABLE-BOUNDARY-START(81606148189)
            /*FieldInfo*/ static FactoriesField = null;
            //--TRIMMABLE-BOUNDARY-END(81606148189)
            
            //--TRIMMABLE-BOUNDARY-START(73016213597)
            /*FieldInfo*/ static ConstantsField = null;
            //--TRIMMABLE-BOUNDARY-END(73016213597)
            
            //--TRIMMABLE-BOUNDARY-START(90196082781)
            /*MethodInfo*/ static GetTypeFromHandleMethod = null;
            //--TRIMMABLE-BOUNDARY-END(90196082781)
            
            //--TRIMMABLE-BOUNDARY-START(60131311709)
            /*ConstructorInfo*/ static CacheKeyCtor = null;
            //--TRIMMABLE-BOUNDARY-END(60131311709)
            
            //--TRIMMABLE-BOUNDARY-START(1900637)
            static $_ILEmitResolverBuilderRuntimeContext;
            static get ILEmitResolverBuilderRuntimeContext()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder;
                return $cls.$_ILEmitResolverBuilderRuntimeContext ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext", ($self) => class ILEmitResolverBuilderRuntimeContext extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591835229)
                    /*object?[]?*/ Constants = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835229)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802525)
                    /*Func<IServiceProvider, object>[]?*/ Factories = null;
                    //--TRIMMABLE-BOUNDARY-END(12886802525)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867933)
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296867933)
                    
                    static $h = 1900637;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591835229),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "Constants",
      "d": 1900637,
      "h": 8591835229,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591835229),
//--TRIMMABLE-BOUNDARY-START(12886802525),
    {
      "t": $.$typeArray($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object)).$h,
      "n": "Factories",
      "d": 1900637,
      "h": 12886802525,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886802525)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867933),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1900637,
      "h": 4296867933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867933)
  ],
  "d": 1769565,
  "h": 1900637
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext`; }
                }, $cls, ($v) => $cls.$_ILEmitResolverBuilderRuntimeContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900637)
            
            //--TRIMMABLE-BOUNDARY-START(1835101)
            static $_GeneratedMethod;
            static get GeneratedMethod()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder;
                return $cls.$_GeneratedMethod ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod", ($self) => class GeneratedMethod extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17181704285)
                    /*Func<ServiceProviderEngineScope, object?>*/  get Lambda() { return this.$getField(0, 4); }
                    /*Func<ServiceProviderEngineScope, object?>*/  set Lambda(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181704285)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591769693)
                    /*ILEmitResolverBuilderRuntimeContext*/  get Context() { return this.$getField(4, 4); }
                    /*ILEmitResolverBuilderRuntimeContext*/  set Context(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591769693)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886736989)
                    /*DynamicMethod*/  get DynamicMethod() { return this.$getField(8, 4); }
                    /*DynamicMethod*/  set DynamicMethod(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886736989)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296802397)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296802397)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Lambda = this.Lambda;
                        copy.Context = this.Context;
                        copy.DynamicMethod = this.DynamicMethod;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17181704285)
                        this.Lambda = null;
                        //--TRIMMABLE-BOUNDARY-END(17181704285)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591769693)
                        this.Context = null;
                        //--TRIMMABLE-BOUNDARY-END(8591769693)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886736989)
                        this.DynamicMethod = null;
                        //--TRIMMABLE-BOUNDARY-END(12886736989)
                        
                    }
                    static $h = 1835101;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181704285),
    {
      "t": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "n": "Lambda",
      "d": 1835101,
      "h": 17181704285,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17181704285),
//--TRIMMABLE-BOUNDARY-START(8591769693),
    {
      "t": 1900637,
      "n": "Context",
      "d": 1835101,
      "h": 8591769693,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8591769693),
//--TRIMMABLE-BOUNDARY-START(12886736989),
    {
      "n": "DynamicMethod",
      "d": 1835101,
      "h": 12886736989,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886736989)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802397),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1835101,
      "h": 4296802397,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802397)
  ],
  "d": 1769565,
  "h": 1835101
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod`; }
                }, $cls, ($v) => $cls.$_GeneratedMethod = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1835101)
            
            //--TRIMMABLE-BOUNDARY-START(8591704157)
            /*ServiceProviderEngineScope*/ _rootScope = null;
            //--TRIMMABLE-BOUNDARY-END(8591704157)
            
            //--TRIMMABLE-BOUNDARY-START(12886671453)
            /*ConcurrentDictionary<ServiceCacheKey, GeneratedMethod>*/ _scopeResolverCache = null;
            //--TRIMMABLE-BOUNDARY-END(12886671453)
            
            //--TRIMMABLE-BOUNDARY-START(4296736861)
            /*Func<ServiceCacheKey, ServiceCallSite, GeneratedMethod>*/ _buildTypeDelegate = null;
            //--TRIMMABLE-BOUNDARY-END(4296736861)
            
            //--TRIMMABLE-BOUNDARY-START(30066540637)
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066540637);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._rootScope = serviceProvider.Root;
                    this._scopeResolverCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod))().$ctor$1();
                    this._buildTypeDelegate = new ($.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod))().$ctor(this,  (/*key*/ key, /*cs*/ cs) =>
                    {
                        return this.BuildTypeNoCache(cs);
                    }, {
  "r": 1835101,
  "p": [
    {
      "n": "key",
      "p": 2359389
    },
    {
      "n": "cs",
      "p": 2424925
    }
  ],
  "n": "",
  "d": 1769565,
  "h": 0,
  "f": 17825794
});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066540637)
            
            //--TRIMMABLE-BOUNDARY-START(47246409821)
            /*Func<ServiceProviderEngineScope, object?> */ Build(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246409821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BuildType(callSite).Lambda;
            }
            //--TRIMMABLE-BOUNDARY-END(47246409821)
            
            //--TRIMMABLE-BOUNDARY-START(51541377117)
            /*GeneratedMethod */ BuildType(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541377117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return this._scopeResolverCache.GetOrAdd$2($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, callSite.Cache.Key, this._buildTypeDelegate, callSite);
                }
                return this.BuildTypeNoCache(callSite);
            }
            //--TRIMMABLE-BOUNDARY-END(51541377117)
            
            //--TRIMMABLE-BOUNDARY-START(55836344413)
            /*GeneratedMethod */ BuildTypeNoCache(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836344413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let dynamicMethod = new DynamicMethod("ResolveService", 6/*MethodAttributes.Public*/ | 16/*MethodAttributes.Static*/, 1/*CallingConventions.Standard*/, $.$$.System.Object.$type, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type], null, null), $.$$.System.Object.GetType.call(this), true);
                /*ILGenerator*/ let ilGenerator = dynamicMethod.GetILGenerator(512);
                /*ILEmitResolverBuilderRuntimeContext*/ let runtimeContext = this.GenerateMethodBody(callSite, ilGenerator);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.DynamicMethodBuilt$1(this._rootScope.RootProvider, callSite.ServiceType, ilGenerator.ILOffset);
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod;
                    const $i1 = new $t1();
                    $i1.Lambda = $.$cast(dynamicMethod.CreateDelegate($.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$type, runtimeContext), $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object));
                    $i1.Context = runtimeContext;
                    $i1.DynamicMethod = dynamicMethod;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(55836344413)
            
            //--TRIMMABLE-BOUNDARY-START(115965886557)
            /*object? */ VisitDisposeCache(/*ServiceCallSite*/ transientCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965886557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (transientCallSite.CaptureDisposable)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.BeginCaptureDisposable(argument);
                    this.VisitCallSiteMain(transientCallSite, argument);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.EndCaptureDisposable(argument);
                }
                else 
                {
                    this.VisitCallSiteMain(transientCallSite, argument);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115965886557)
            
            //--TRIMMABLE-BOUNDARY-START(111670919261)
            /*object? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670919261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = constructorCallSite.ParameterCallSites;
                while ($i1 < $arr1.length)
                {
                    let parameterCallSite = $arr1[$i1++];
                    this.VisitCallSite(parameterCallSite, argument);
                    if (parameterCallSite.ServiceType.IsValueType)
                    {
                        argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Unbox_Any, parameterCallSite.ServiceType);
                    }
                }
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Newobj, constructorCallSite.ConstructorInfo);
                if (constructorCallSite.ImplementationType.IsValueType)
                {
                    argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Box, constructorCallSite.ImplementationType);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(111670919261)
            
            //--TRIMMABLE-BOUNDARY-START(128850788445)
            /*object? */ VisitRootCache(/*ServiceCallSite*/ callSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850788445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, this._rootScope));
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(128850788445)
            
            //--TRIMMABLE-BOUNDARY-START(133145755741)
            /*object? */ VisitScopeCache(/*ServiceCallSite*/ scopedCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145755741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*GeneratedMethod*/ let generatedMethod = this.BuildType(scopedCallSite);
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, generatedMethod.Context);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, generatedMethod.DynamicMethod);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(133145755741)
            
            //--TRIMMABLE-BOUNDARY-START(107375951965)
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375951965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, constantCallSite.DefaultValue);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(107375951965)
            
            //--TRIMMABLE-BOUNDARY-START(137440723037)
            /*object? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440723037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(137440723037)
            
            //--TRIMMABLE-BOUNDARY-START(124555821149)
            /*object? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555821149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (enumerableCallSite.ServiceCallSites.length === 0)
                {
                    argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.GetArrayEmptyMethodInfo(enumerableCallSite.ItemType));
                }
                else 
                {
                    argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldc_I4, enumerableCallSite.ServiceCallSites.length);
                    argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Newarr, enumerableCallSite.ItemType);
                    for(/*int*/ let i = 0; i < enumerableCallSite.ServiceCallSites.length; i++)
                    {
                        argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Dup);
                        argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldc_I4, i);
                        /*ServiceCallSite*/ let parameterCallSite = $.$$.System.Array.$ReadT1.call(enumerableCallSite.ServiceCallSites, i);
                        this.VisitCallSite(parameterCallSite, argument);
                        if (parameterCallSite.ServiceType.IsValueType)
                        {
                            argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Unbox_Any, parameterCallSite.ServiceType);
                        }
                        argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Stelem, enumerableCallSite.ItemType);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(124555821149)
            
            //--TRIMMABLE-BOUNDARY-START(120260853853)
            /*object? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260853853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.Factories ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object)))().$ctor$1();
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldfld, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.FactoriesField);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldc_I4, argument.Factories.Count);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldelem, $.$$.System.Func$$$($.$scm.System.IServiceProvider, $.$$.System.Object).$type);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.InvokeFactoryMethodInfo);
                argument.Factories.Add(factoryCallSite.Factory);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(120260853853)
            
            //--TRIMMABLE-BOUNDARY-START(38656475229)
            static /*void */ AddConstant(/*ILEmitResolverBuilderContext*/ argument, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656475229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.Constants ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_0);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldfld, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ConstantsField);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldc_I4, argument.Constants.Count);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldelem, $.$$.System.Object.$type);
                argument.Constants.Add(value);
            }
            //--TRIMMABLE-BOUNDARY-END(38656475229)
            
            //--TRIMMABLE-BOUNDARY-START(34361507933)
            static /*void */ AddCacheKey(/*ILEmitResolverBuilderContext*/ argument, /*ServiceCacheKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361507933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let id = key.ServiceIdentifier;
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, id.ServiceKey);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldtoken, id.ServiceType);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GetTypeFromHandleMethod);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldc_I4, key.Slot);
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Newobj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CacheKeyCtor);
            }
            //--TRIMMABLE-BOUNDARY-END(34361507933)
            
            //--TRIMMABLE-BOUNDARY-START(85901115485)
            /*ILEmitResolverBuilderRuntimeContext */ GenerateMethodBody(/*ServiceCallSite*/ callSite, /*ILGenerator*/ generator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901115485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let context = (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext;
                    const $i1 = new $t1();
                    $i1.$ctor$1(generator);
                    $i1.Constants = null;
                    $i1.Factories = null;
                    return $i1;
                })();
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    /*LocalBuilder*/ let cacheKeyLocal = context.Generator.DeclareLocal($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type);
                    /*LocalBuilder*/ let resolvedServicesLocal = context.Generator.DeclareLocal($.$$.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Object).$type);
                    /*LocalBuilder*/ let syncLocal = context.Generator.DeclareLocal($.$$.System.Object.$type);
                    /*LocalBuilder*/ let lockTakenLocal = context.Generator.DeclareLocal($.$$.System.Boolean.$type);
                    /*LocalBuilder*/ let resultLocal = context.Generator.DeclareLocal($.$$.System.Object.$type);
                    /*Label*/ let skipCreationLabel = context.Generator.DefineLabel();
                    /*Label*/ let returnLabel = context.Generator.DefineLabel();
                    /*Label*/ let defaultLabel = context.Generator.DefineLabel();
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ScopeIsRootScope);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Brfalse_S, defaultLabel);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CallSiteRuntimeResolverInstanceField);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(context, callSite);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CallSiteRuntimeResolverResolveMethod);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                    context.Generator.MarkLabel(defaultLabel);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddCacheKey(context, callSite.Cache.Key);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Stloc, cacheKeyLocal);
                    context.Generator.BeginExceptionBlock();
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ResolvedServicesGetter);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Stloc, resolvedServicesLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ScopeLockGetter);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Stloc, syncLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, syncLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloca, lockTakenLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorEnterMethodInfo);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, resolvedServicesLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, cacheKeyLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloca, resultLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.TryGetValueMethodInfo);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Brtrue, skipCreationLabel);
                    this.VisitCallSiteMain(callSite, context);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Stloc, resultLocal);
                    if (callSite.CaptureDisposable)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.BeginCaptureDisposable(context);
                        context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, resultLocal);
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.EndCaptureDisposable(context);
                        generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Pop);
                    }
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, resolvedServicesLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, cacheKeyLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, resultLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.AddMethodInfo);
                    context.Generator.MarkLabel(skipCreationLabel);
                    context.Generator.BeginFinallyBlock();
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, lockTakenLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Brfalse, returnLabel);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, syncLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorExitMethodInfo);
                    context.Generator.MarkLabel(returnLabel);
                    context.Generator.EndExceptionBlock();
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldloc, resultLocal);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                }
                else 
                {
                    this.VisitCallSite(callSite, context);
                    context.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ret);
                }
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext()
                    const $t2 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext;
                    const $i2 = new $t2();
                    $i2.Constants = (context.Constants?.ToArray() ?? null);
                    $i2.Factories = (context.Factories?.ToArray() ?? null);
                    return $i2;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(85901115485)
            
            //--TRIMMABLE-BOUNDARY-START(42951442525)
            static /*void */ BeginCaptureDisposable(/*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951442525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Ldarg_1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951442525)
            
            //--TRIMMABLE-BOUNDARY-START(77311180893)
            static /*void */ EndCaptureDisposable(/*ILEmitResolverBuilderContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311180893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.Generator.Emit(/*$.$$.System.Reflection.Emit.OpCodes*/$.$$.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.CaptureDisposableMethodInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(77311180893)
            
            //--TRIMMABLE-BOUNDARY-START(25771573341)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(94491050077)
                    this.ResolvedServicesGetter = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("ResolvedServices", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/).GetMethod;
                    //--TRIMMABLE-BOUNDARY-END(94491050077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080984669)
                    this.ScopeLockGetter = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("Sync", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/).GetMethod;
                    //--TRIMMABLE-BOUNDARY-END(103080984669)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98786017373)
                    this.ScopeIsRootScope = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("IsRootScope", 4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/).GetMethod;
                    //--TRIMMABLE-BOUNDARY-END(98786017373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68721246301)
                    this.CallSiteRuntimeResolverResolveMethod = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetMethod$9("Resolve", 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/);
                    //--TRIMMABLE-BOUNDARY-END(68721246301)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426279005)
                    this.CallSiteRuntimeResolverInstanceField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetProperty$1("Instance", 8/*BindingFlags.Static*/ | 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/).GetMethod;
                    //--TRIMMABLE-BOUNDARY-END(64426279005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606148189)
                    this.FactoriesField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type.GetField$2("Factories");
                    //--TRIMMABLE-BOUNDARY-END(81606148189)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73016213597)
                    this.ConstantsField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type.GetField$2("Constants");
                    //--TRIMMABLE-BOUNDARY-END(73016213597)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90196082781)
                    this.GetTypeFromHandleMethod = $.$$.System.Type.$type.GetMethod$12("GetTypeFromHandle");
                    //--TRIMMABLE-BOUNDARY-END(90196082781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131311709)
                    this.CacheKeyCtor = $.$$.System.Array.$ReadT1.call($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type.GetConstructors(), 0);
                    //--TRIMMABLE-BOUNDARY-END(60131311709)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771573341)
            
            static $h = 1769565;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246409821),
    {
      "r": $.$$.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$$.System.Object).$h,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "Build",
      "d": 1769565,
      "h": 47246409821,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246409821),
//--TRIMMABLE-BOUNDARY-START(51541377117),
    {
      "r": 1835101,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "BuildType",
      "d": 1769565,
      "h": 51541377117,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51541377117),
//--TRIMMABLE-BOUNDARY-START(55836344413),
    {
      "r": 1835101,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "BuildTypeNoCache",
      "d": 1769565,
      "h": 55836344413,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55836344413),
//--TRIMMABLE-BOUNDARY-START(115965886557),
    {
      "r": 131073,
      "p": [
        {
          "n": "transientCallSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitDisposeCache",
      "d": 1769565,
      "h": 115965886557,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(115965886557),
//--TRIMMABLE-BOUNDARY-START(111670919261),
    {
      "r": 131073,
      "p": [
        {
          "n": "constructorCallSite",
          "p": 1376349
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitConstructor",
      "d": 1769565,
      "h": 111670919261,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(111670919261),
//--TRIMMABLE-BOUNDARY-START(128850788445),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitRootCache",
      "d": 1769565,
      "h": 128850788445,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(128850788445),
//--TRIMMABLE-BOUNDARY-START(133145755741),
    {
      "r": 131073,
      "p": [
        {
          "n": "scopedCallSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitScopeCache",
      "d": 1769565,
      "h": 133145755741,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(133145755741),
//--TRIMMABLE-BOUNDARY-START(107375951965),
    {
      "r": 131073,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitConstant",
      "d": 1769565,
      "h": 107375951965,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(107375951965),
//--TRIMMABLE-BOUNDARY-START(137440723037),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitServiceProvider",
      "d": 1769565,
      "h": 137440723037,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(137440723037),
//--TRIMMABLE-BOUNDARY-START(124555821149),
    {
      "r": 131073,
      "p": [
        {
          "n": "enumerableCallSite",
          "p": 1704029
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitIEnumerable",
      "d": 1769565,
      "h": 124555821149,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(124555821149),
//--TRIMMABLE-BOUNDARY-START(120260853853),
    {
      "r": 131073,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "VisitFactory",
      "d": 1769565,
      "h": 120260853853,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(120260853853),
//--TRIMMABLE-BOUNDARY-START(38656475229),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1966173
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "AddConstant",
      "d": 1769565,
      "h": 38656475229,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656475229),
//--TRIMMABLE-BOUNDARY-START(34361507933),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1966173
        },
        {
          "n": "key",
          "p": 2359389
        }
      ],
      "n": "AddCacheKey",
      "d": 1769565,
      "h": 34361507933,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361507933),
//--TRIMMABLE-BOUNDARY-START(85901115485),
    {
      "r": 1900637,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "generator"
        }
      ],
      "n": "GenerateMethodBody",
      "d": 1769565,
      "h": 85901115485,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901115485),
//--TRIMMABLE-BOUNDARY-START(42951442525),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "BeginCaptureDisposable",
      "d": 1769565,
      "h": 42951442525,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951442525),
//--TRIMMABLE-BOUNDARY-START(77311180893),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1966173
        }
      ],
      "n": "EndCaptureDisposable",
      "d": 1769565,
      "h": 77311180893,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77311180893)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(94491050077),
    {
      "t": 116850689,
      "n": "ResolvedServicesGetter",
      "d": 1769565,
      "h": 94491050077,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94491050077),
//--TRIMMABLE-BOUNDARY-START(103080984669),
    {
      "t": 116850689,
      "n": "ScopeLockGetter",
      "d": 1769565,
      "h": 103080984669,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(103080984669),
//--TRIMMABLE-BOUNDARY-START(98786017373),
    {
      "t": 116850689,
      "n": "ScopeIsRootScope",
      "d": 1769565,
      "h": 98786017373,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(98786017373),
//--TRIMMABLE-BOUNDARY-START(68721246301),
    {
      "t": 116850689,
      "n": "CallSiteRuntimeResolverResolveMethod",
      "d": 1769565,
      "h": 68721246301,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(68721246301),
//--TRIMMABLE-BOUNDARY-START(64426279005),
    {
      "t": 116850689,
      "n": "CallSiteRuntimeResolverInstanceField",
      "d": 1769565,
      "h": 64426279005,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(64426279005),
//--TRIMMABLE-BOUNDARY-START(81606148189),
    {
      "t": 113901569,
      "n": "FactoriesField",
      "d": 1769565,
      "h": 81606148189,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81606148189),
//--TRIMMABLE-BOUNDARY-START(73016213597),
    {
      "t": 113901569,
      "n": "ConstantsField",
      "d": 1769565,
      "h": 73016213597,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73016213597),
//--TRIMMABLE-BOUNDARY-START(90196082781),
    {
      "t": 116850689,
      "n": "GetTypeFromHandleMethod",
      "d": 1769565,
      "h": 90196082781,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90196082781),
//--TRIMMABLE-BOUNDARY-START(60131311709),
    {
      "t": 108462081,
      "n": "CacheKeyCtor",
      "d": 1769565,
      "h": 60131311709,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60131311709),
//--TRIMMABLE-BOUNDARY-START(8591704157),
    {
      "t": 2818141,
      "n": "_rootScope",
      "d": 1769565,
      "h": 8591704157,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704157),
//--TRIMMABLE-BOUNDARY-START(12886671453),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod).$h,
      "n": "_scopeResolverCache",
      "d": 1769565,
      "h": 12886671453,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886671453),
//--TRIMMABLE-BOUNDARY-START(4296736861),
    {
      "t": $.$$.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod).$h,
      "n": "_buildTypeDelegate",
      "d": 1769565,
      "h": 4296736861,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736861)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066540637),
    {
      "p": [
        {
          "n": "serviceProvider",
          "p": 3080285
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769565,
      "h": 30066540637,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066540637)
  ],
  "j": [1900637,1835101
  ],
  "h": 1769565
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext, $.$$.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769565)
        
        
        //--TRIMMABLE-BOUNDARY-START(983133)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver", ($self) => class CallSiteRuntimeResolver extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext, $.$$.System.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(25770786909)
            /*CallSiteRuntimeResolver*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25770786909)
            
            //--TRIMMABLE-BOUNDARY-START(12885885021)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885885021);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885885021)
            
            //--TRIMMABLE-BOUNDARY-START(30065754205)
            /*object? */ Resolve(/*ServiceCallSite*/ callSite, /*ServiceProviderEngineScope*/ scope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let cached;
                if (scope.IsRootScope && $.$is(callSite.Value, $.$$.System.Object, { set $v(v){ cached = v; } }))
                {
                    return cached;
                }
                return this.VisitCallSite(callSite, (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                    const $i1 = new $t1();
                    $i1.Scope = scope;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(30065754205)
            
            //--TRIMMABLE-BOUNDARY-START(47245623389)
            /*object? */ VisitDisposeCache(/*ServiceCallSite*/ transientCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return context.Scope.CaptureDisposable(this.VisitCallSiteMain(transientCallSite, context.Clone()));
            }
            //--TRIMMABLE-BOUNDARY-END(47245623389)
            
            //--TRIMMABLE-BOUNDARY-START(42950656093)
            /*object */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?[]*/ let parameterValues;
                if (constructorCallSite.ParameterCallSites.length === 0)
                {
                    parameterValues = $.$$.System.Array.Empty($.$$.System.Object);
                }
                else 
                {
                    parameterValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [constructorCallSite.ParameterCallSites.length], null);
                    for(/*int*/ let index = 0; index < parameterValues.length; index++)
                    {
                        $.$$.System.Array.$WriteT1.call(parameterValues, this.VisitCallSite($.$$.System.Array.$ReadT1.call(constructorCallSite.ParameterCallSites, index), context.Clone()), index);
                    }
                }
                return constructorCallSite.ConstructorInfo.Invoke$3(33554432/*BindingFlags.DoNotWrapExceptions*/, null, parameterValues, null);
            }
            //--TRIMMABLE-BOUNDARY-END(42950656093)
            
            //--TRIMMABLE-BOUNDARY-START(60130525277)
            /*object? */ VisitRootCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let value;
                if ($.$is(callSite.Value, $.$$.System.Object, { set $v(v){ value = v; } }))
                {
                    return value;
                }
                /*var*/ let lockType = 2/*RuntimeResolverLock.Root*/;
                /*ServiceProviderEngineScope*/ let serviceProviderEngine = context.Scope.RootProvider.Root;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(callSite)
                    {
                        let callSiteValue;
                        if ($.$is(callSite.Value, $.$$.System.Object, { set $v(v){ callSiteValue = v; } }))
                        {
                            return callSiteValue;
                        }
                        /*object?*/ let resolved = this.VisitCallSiteMain(callSite, (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                            const $i1 = new $t1();
                            $i1.Scope = serviceProviderEngine;
                            $i1.AcquiredLocks = context.AcquiredLocks | lockType;
                            return $i1;
                        })());
                        serviceProviderEngine.CaptureDisposable(resolved);
                        callSite.Value = resolved;
                        return resolved;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(callSite)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130525277)
            
            //--TRIMMABLE-BOUNDARY-START(64425492573)
            /*object? */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return context.Scope.IsRootScope ? this.VisitRootCache(callSite, context.Clone()) : this.VisitCache(callSite, context.Clone(), context.Scope, 1/*RuntimeResolverLock.Scope*/);
            }
            //--TRIMMABLE-BOUNDARY-END(64425492573)
            
            //--TRIMMABLE-BOUNDARY-START(34360721501)
            /*object? */ VisitCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context, /*ServiceProviderEngineScope*/ serviceProviderEngine, /*RuntimeResolverLock*/ lockType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let lockTaken = false;
                /*object*/ let sync = serviceProviderEngine.Sync;
                /*Dictionary<ServiceCacheKey, object?>*/ let resolvedServices = serviceProviderEngine.ResolvedServices;
                if ((context.AcquiredLocks & lockType) === 0)
                {
                    $.$$.System.Threading.Monitor.Enter(sync, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                }
                try
                {
                    /*object?*/ let resolved;
                    if (resolvedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => resolved, ($v) => resolved = $v, $.$$.System.Object)))
                    {
                        return resolved;
                    }
                    resolved = this.VisitCallSiteMain(callSite, (() =>
                    {
                        //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                        const $t2 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                        const $i2 = new $t2();
                        $i2.Scope = serviceProviderEngine;
                        $i2.AcquiredLocks = context.AcquiredLocks | lockType;
                        return $i2;
                    })());
                    serviceProviderEngine.CaptureDisposable(resolved);
                    resolvedServices.Add(callSite.Cache.Key, resolved);
                    return resolved;
                }
                finally
                {
                    {
                        if (lockTaken)
                        {
                            $.$$.System.Threading.Monitor.Exit(sync);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360721501)
            
            //--TRIMMABLE-BOUNDARY-START(38655688797)
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return constantCallSite.DefaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688797)
            
            //--TRIMMABLE-BOUNDARY-START(68720459869)
            /*object */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return context.Scope;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459869)
            
            //--TRIMMABLE-BOUNDARY-START(55835557981)
            /*object */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Array*/ let array = CreateArray(enumerableCallSite.ItemType, enumerableCallSite.ServiceCallSites.length);
                for(/*int*/ let index = 0; index < enumerableCallSite.ServiceCallSites.length; index++)
                {
                    /*object?*/ let value = this.VisitCallSite($.$$.System.Array.$ReadT1.call(enumerableCallSite.ServiceCallSites, index), context.Clone());
                    array.SetValue$2(value, index);
                }
                return array;
                /*static Array*/  function CreateArray(/*Type*/ elementType, /*int*/ length)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$$.System.Array.CreateInstance$2(elementType, length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835557981)
            
            //--TRIMMABLE-BOUNDARY-START(51540590685)
            /*object */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*RuntimeResolverContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return factoryCallSite.Factory.Invoke(context.Scope);
            }
            //--TRIMMABLE-BOUNDARY-END(51540590685)
            
            //--TRIMMABLE-BOUNDARY-START(8590917725)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver().$ctor$2();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917725)
            
            static $h = 983133;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770786909),
    {
      "p": 983133,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819613,
        "f": 50331681
      },
      "n": "Instance",
      "d": 983133,
      "h": 25770786909,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770786909)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065754205),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "scope",
          "p": 2818141
        }
      ],
      "n": "Resolve",
      "d": 983133,
      "h": 30065754205,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065754205),
//--TRIMMABLE-BOUNDARY-START(47245623389),
    {
      "r": 131073,
      "p": [
        {
          "n": "transientCallSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitDisposeCache",
      "d": 983133,
      "h": 47245623389,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245623389),
//--TRIMMABLE-BOUNDARY-START(42950656093),
    {
      "r": 131073,
      "p": [
        {
          "n": "constructorCallSite",
          "p": 1376349
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitConstructor",
      "d": 983133,
      "h": 42950656093,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950656093),
//--TRIMMABLE-BOUNDARY-START(60130525277),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitRootCache",
      "d": 983133,
      "h": 60130525277,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60130525277),
//--TRIMMABLE-BOUNDARY-START(64425492573),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitScopeCache",
      "d": 983133,
      "h": 64425492573,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64425492573),
//--TRIMMABLE-BOUNDARY-START(34360721501),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "context",
          "p": 2162781
        },
        {
          "n": "serviceProviderEngine",
          "p": 2818141
        },
        {
          "n": "lockType",
          "p": 2228317
        }
      ],
      "n": "VisitCache",
      "d": 983133,
      "h": 34360721501,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360721501),
//--TRIMMABLE-BOUNDARY-START(38655688797),
    {
      "r": 131073,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitConstant",
      "d": 983133,
      "h": 38655688797,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655688797),
//--TRIMMABLE-BOUNDARY-START(68720459869),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitServiceProvider",
      "d": 983133,
      "h": 68720459869,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68720459869),
//--TRIMMABLE-BOUNDARY-START(55835557981),
    {
      "r": 131073,
      "p": [
        {
          "n": "enumerableCallSite",
          "p": 1704029
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitIEnumerable",
      "d": 983133,
      "h": 55835557981,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835557981),
//--TRIMMABLE-BOUNDARY-START(51540590685),
    {
      "r": 131073,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "context",
          "p": 2162781
        }
      ],
      "n": "VisitFactory",
      "d": 983133,
      "h": 51540590685,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540590685)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885885021),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983133,
      "h": 12885885021,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885885021)
  ],
  "h": 983133
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext, $.$$.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983133)
        
        
        //--TRIMMABLE-BOUNDARY-START(65629)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter", ($self) => class CallSiteJsonFormatter extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($self.$itype$CallSiteFormatterContext, $.$$.System.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(21474902109)
            /*CallSiteJsonFormatter*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(21474902109)
            
            //--TRIMMABLE-BOUNDARY-START(12884967517)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967517);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967517)
            
            //--TRIMMABLE-BOUNDARY-START(17179934813)
            /*string */ Format(/*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let stringBuilder = new $.$$.System.Text.StringBuilder().$ctor$1();
                /*var*/ let context = new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext().$ctor$3(stringBuilder, 0, new ($.$$.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$1());
                this.VisitCallSite(callSite, context.Clone());
                return $.$$.System.Text.StringBuilder.ToString.call(stringBuilder);
            }
            //--TRIMMABLE-BOUNDARY-END(17179934813)
            
            //--TRIMMABLE-BOUNDARY-START(34359803997)
            /*object? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.WriteProperty("implementationType", constructorCallSite.ImplementationType);
                if (constructorCallSite.ParameterCallSites.length > 0)
                {
                    argument.StartProperty("arguments");
                    /*CallSiteFormatterContext*/ let childContext = argument.StartArray();
                    let $i1 = 0;
                    let $arr1 = constructorCallSite.ParameterCallSites;
                    while ($i1 < $arr1.length)
                    {
                        let parameter = $arr1[$i1++];
                        childContext.StartArrayItem();
                        this.VisitCallSite(parameter, childContext.Clone());
                    }
                    argument.EndArray();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34359803997)
            
            //--TRIMMABLE-BOUNDARY-START(25769869405)
            /*object? */ VisitCallSiteMain(/*ServiceCallSite*/ callSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (argument.ShouldFormat(callSite))
                {
                    /*CallSiteFormatterContext*/ let childContext = argument.StartObject();
                    childContext.WriteProperty("serviceType", callSite.ServiceType);
                    childContext.WriteProperty("kind", $.$box(callSite.Kind, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind));
                    childContext.WriteProperty("cache", $.$box(callSite.Cache.Location, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation));
                    super.VisitCallSiteMain(callSite, childContext.Clone());
                    argument.EndObject();
                }
                else 
                {
                    /*CallSiteFormatterContext*/ let childContext = argument.StartObject();
                    childContext.WriteProperty("ref", callSite.ServiceType);
                    argument.EndObject();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869405)
            
            //--TRIMMABLE-BOUNDARY-START(30064836701)
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.WriteProperty("value", constantCallSite.DefaultValue ?? "");
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836701)
            
            //--TRIMMABLE-BOUNDARY-START(47244705885)
            /*object? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705885)
            
            //--TRIMMABLE-BOUNDARY-START(42949738589)
            /*object? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.WriteProperty("itemType", enumerableCallSite.ItemType);
                argument.WriteProperty("size", $.$box(enumerableCallSite.ServiceCallSites.length, $.$$.System.Int32));
                if (enumerableCallSite.ServiceCallSites.length > 0)
                {
                    argument.StartProperty("items");
                    /*CallSiteFormatterContext*/ let childContext = argument.StartArray();
                    let $i1 = 0;
                    let $arr1 = enumerableCallSite.ServiceCallSites;
                    while ($i1 < $arr1.length)
                    {
                        let item = $arr1[$i1++];
                        childContext.StartArrayItem();
                        this.VisitCallSite(item, childContext.Clone());
                    }
                    argument.EndArray();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738589)
            
            //--TRIMMABLE-BOUNDARY-START(38654771293)
            /*object? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*CallSiteFormatterContext*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                argument.WriteProperty("method", factoryCallSite.Factory.Method);
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771293)
            
            //--TRIMMABLE-BOUNDARY-START(131165)
            static $_CallSiteFormatterContext;
            static get CallSiteFormatterContext()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter;
                return $cls.$_CallSiteFormatterContext ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext", ($self) => class CallSiteFormatterContext extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8590065757)
                    /*HashSet<ServiceCallSite>*/  get _processedCallSites() { return this.$getField(0, 4); }
                    /*HashSet<ServiceCallSite>*/  set _processedCallSites(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590065757)
                    
                    //--TRIMMABLE-BOUNDARY-START(25769934941)
                    $ctor$3(/*StringBuilder*/ builder, /*int*/ offset, /*HashSet<ServiceCallSite>*/ processedCallSites)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25769934941);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Builder = builder;
                            this.Offset = offset;
                            this._processedCallSites = processedCallSites;
                            this._firstItem = true;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25769934941)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295098461)
                    /*bool*/  get _firstItem() { return this.$getField(4, 1); }
                    /*bool*/  set _firstItem(value) { this.$setField(4, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295098461)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424640605)
                    /*int*/ Offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(64424640605)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064902237)
                    /*StringBuilder*/ Builder = null;
                    //--TRIMMABLE-BOUNDARY-END(30064902237)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719607901)
                    /*bool */ ShouldFormat(/*ServiceCallSite*/ serviceCallSite)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719607901);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._processedCallSites.Add(serviceCallSite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719607901)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129673309)
                    /*CallSiteFormatterContext */ IncrementOffset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60129673309);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext;
                            const $i1 = new $t1();
                            $i1.$ctor$3(this.Builder, ((this.Offset + 4) | 0), this._processedCallSites);
                            $i1._firstItem = true;
                            return $i1;
                        })();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129673309)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604509789)
                    /*CallSiteFormatterContext */ StartObject()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604509789);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Builder.Append$3(/*{*/ 123);
                        return this.IncrementOffset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604509789)
                    
                    //--TRIMMABLE-BOUNDARY-START(38654836829)
                    /*void */ EndObject()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38654836829);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Builder.Append$3(/*}*/ 125);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38654836829)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899477085)
                    /*void */ StartProperty(/*string*/ name)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85899477085);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._firstItem)
                        {
                            this.Builder.Append$3(/*,*/ 44);
                        }
                        else 
                        {
                            this._firstItem = false;
                        }
                        this.Builder.Append$3(/*\"*/ 34).Append$19(name).Append$19("\":");
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899477085)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309542493)
                    /*void */ StartArrayItem()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309542493);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._firstItem)
                        {
                            this.Builder.Append$3(/*,*/ 44);
                        }
                        else 
                        {
                            this._firstItem = false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309542493)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194444381)
                    /*void */ WriteProperty(/*string*/ name, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90194444381);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.StartProperty(name);
                        if (value !== null)
                        {
                            this.Builder.Append$19(" \"").Append$13(value).Append$3(/*\"*/ 34);
                        }
                        else 
                        {
                            this.Builder.Append$19("null");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194444381)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014575197)
                    /*CallSiteFormatterContext */ StartArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014575197);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Builder.Append$3(/*[*/ 91);
                        return this.IncrementOffset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014575197)
                    
                    //--TRIMMABLE-BOUNDARY-START(34359869533)
                    /*void */ EndArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359869533);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.Builder.Append$3(/*]*/ 93);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34359869533)
                    
                    //--TRIMMABLE-BOUNDARY-START(21474967645)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21474967645)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._processedCallSites = this._processedCallSites;
                        copy._firstItem = this._firstItem;
                        copy.Offset = this.Offset;
                        copy.Builder = this.Builder;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590065757)
                        this._processedCallSites = null;
                        //--TRIMMABLE-BOUNDARY-END(8590065757)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295098461)
                        this._firstItem = false;
                        //--TRIMMABLE-BOUNDARY-END(4295098461)
                        
                    }
                    static $h = 131165;
                    static $z = 13;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64424640605),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706013,
        "f": 50331649
      },
      "n": "Offset",
      "d": 131165,
      "h": 64424640605,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64424640605),
//--TRIMMABLE-BOUNDARY-START(30064902237),
    {
      "p": 167051265,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771421,
        "f": 50331649
      },
      "n": "Builder",
      "d": 131165,
      "h": 30064902237,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064902237)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68719607901),
    {
      "r": 262145,
      "p": [
        {
          "n": "serviceCallSite",
          "p": 2424925
        }
      ],
      "n": "ShouldFormat",
      "d": 131165,
      "h": 68719607901,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719607901),
//--TRIMMABLE-BOUNDARY-START(60129673309),
    {
      "r": 131165,
      "n": "IncrementOffset",
      "d": 131165,
      "h": 60129673309,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129673309),
//--TRIMMABLE-BOUNDARY-START(81604509789),
    {
      "r": 131165,
      "n": "StartObject",
      "d": 131165,
      "h": 81604509789,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604509789),
//--TRIMMABLE-BOUNDARY-START(38654836829),
    {
      "r": 65537,
      "n": "EndObject",
      "d": 131165,
      "h": 38654836829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654836829),
//--TRIMMABLE-BOUNDARY-START(85899477085),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "StartProperty",
      "d": 131165,
      "h": 85899477085,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899477085),
//--TRIMMABLE-BOUNDARY-START(77309542493),
    {
      "r": 65537,
      "n": "StartArrayItem",
      "d": 131165,
      "h": 77309542493,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309542493),
//--TRIMMABLE-BOUNDARY-START(90194444381),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteProperty",
      "d": 131165,
      "h": 90194444381,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194444381),
//--TRIMMABLE-BOUNDARY-START(73014575197),
    {
      "r": 131165,
      "n": "StartArray",
      "d": 131165,
      "h": 73014575197,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014575197),
//--TRIMMABLE-BOUNDARY-START(34359869533),
    {
      "r": 65537,
      "n": "EndArray",
      "d": 131165,
      "h": 34359869533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359869533)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065757),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,
      "n": "_processedCallSites",
      "d": 131165,
      "h": 8590065757,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065757),
//--TRIMMABLE-BOUNDARY-START(4295098461),
    {
      "t": 262145,
      "n": "_firstItem",
      "d": 131165,
      "h": 4295098461,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098461)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769934941),
    {
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "processedCallSites",
          "p": $.$$.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131165,
      "h": 25769934941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934941),
//--TRIMMABLE-BOUNDARY-START(21474967645),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131165,
      "h": 21474967645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474967645)
  ],
  "d": 65629,
  "h": 131165
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext`; }
                }, $cls, ($v) => $cls.$_CallSiteFormatterContext = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131165)
            
            //--TRIMMABLE-BOUNDARY-START(8590000221)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902109)
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(21474902109)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000221)
            
            static $h = 65629;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934813),
    {
      "r": 1310721,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "Format",
      "d": 65629,
      "h": 17179934813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934813),
//--TRIMMABLE-BOUNDARY-START(34359803997),
    {
      "r": 131073,
      "p": [
        {
          "n": "constructorCallSite",
          "p": 1376349
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitConstructor",
      "d": 65629,
      "h": 34359803997,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34359803997),
//--TRIMMABLE-BOUNDARY-START(25769869405),
    {
      "r": 131073,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitCallSiteMain",
      "d": 65629,
      "h": 25769869405,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25769869405),
//--TRIMMABLE-BOUNDARY-START(30064836701),
    {
      "r": 131073,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitConstant",
      "d": 65629,
      "h": 30064836701,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30064836701),
//--TRIMMABLE-BOUNDARY-START(47244705885),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitServiceProvider",
      "d": 65629,
      "h": 47244705885,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47244705885),
//--TRIMMABLE-BOUNDARY-START(42949738589),
    {
      "r": 131073,
      "p": [
        {
          "n": "enumerableCallSite",
          "p": 1704029
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitIEnumerable",
      "d": 65629,
      "h": 42949738589,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42949738589),
//--TRIMMABLE-BOUNDARY-START(38654771293),
    {
      "r": 131073,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "argument",
          "p": 131165
        }
      ],
      "n": "VisitFactory",
      "d": 65629,
      "h": 38654771293,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38654771293)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21474902109),
    {
      "t": 65629,
      "n": "Instance",
      "d": 65629,
      "h": 21474902109,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21474902109)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967517),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65629,
      "h": 12884967517,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967517)
  ],
  "j": [131165
  ],
  "h": 65629
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext, $.$$.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65629)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048669)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator", ($self) => class CallSiteValidator extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($self.$itype$CallSiteValidatorState, $.$$.System.Type)
        {
            //--TRIMMABLE-BOUNDARY-START(4296015965)
            /*ConcurrentDictionary<ServiceCacheKey, Type?>*/ _scopedServices = null;
            //--TRIMMABLE-BOUNDARY-END(4296015965)
            
            //--TRIMMABLE-BOUNDARY-START(17180917853)
            /*void */ ValidateCallSite(/*ServiceCallSite*/ callSite)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180917853);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.VisitCallSite(callSite, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180917853)
            
            //--TRIMMABLE-BOUNDARY-START(21475885149)
            /*void */ ValidateResolution(/*ServiceCallSite*/ callSite, /*IServiceScope*/ scope, /*IServiceScope*/ rootScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type?*/ let scopedService;
                if ($.$$.System.Object.ReferenceEquals(scope, rootScope) && this._scopedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => scopedService, ($v) => scopedService = $v, $.$$.System.Type)) && $.$$.System.Type.op_Inequality$1(scopedService, null))
                {
                    /*Type*/ let serviceType = callSite.ServiceType;
                    if ($.$$.System.Type.op_Equality$1(serviceType, scopedService))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$5($.$med.System.SR.DirectScopedResolvedFromRootException, callSite.ServiceType, $.$$.System.String.ToLowerInvariant.call("Scoped")));
                    }
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$4($.$med.System.SR.ScopedResolvedFromRootException, callSite.ServiceType, scopedService, $.$$.System.String.ToLowerInvariant.call("Scoped")));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475885149)
            
            //--TRIMMABLE-BOUNDARY-START(25770852445)
            /*Type? */ VisitCallSite(/*ServiceCallSite*/ callSite, /*CallSiteValidatorState*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type?*/ let firstScopedServiceInCallSiteTree;
                if (!this._scopedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => firstScopedServiceInCallSiteTree, ($v) => firstScopedServiceInCallSiteTree = $v, $.$$.System.Type)))
                {
                    firstScopedServiceInCallSiteTree = super.VisitCallSite(callSite, argument.Clone());
                    this._scopedServices.set_Item$1(callSite.Cache.Key, firstScopedServiceInCallSiteTree);
                }
                if ($.$$.System.Type.op_Inequality$1(firstScopedServiceInCallSiteTree, null) && argument.Singleton !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$med.System.SR.Format$7($.$med.System.SR.ScopedInSingletonException, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ callSite.ServiceType, argument.Singleton.ServiceType, $.$$.System.String.ToLowerInvariant.call("Scoped"), $.$$.System.String.ToLowerInvariant.call("Singleton") ], null, null)));
                }
                return firstScopedServiceInCallSiteTree;
            }
            //--TRIMMABLE-BOUNDARY-END(25770852445)
            
            //--TRIMMABLE-BOUNDARY-START(34360787037)
            /*Type? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*CallSiteValidatorState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360787037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type?*/ let result = null;
                let $i1 = 0;
                let $arr1 = constructorCallSite.ParameterCallSites;
                while ($i1 < $arr1.length)
                {
                    let parameterCallSite = $arr1[$i1++];
                    /*Type?*/ let scoped = this.VisitCallSite(parameterCallSite, state.Clone());
                    result ??= scoped;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(34360787037)
            
            //--TRIMMABLE-BOUNDARY-START(42950721629)
            /*Type? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*CallSiteValidatorState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type?*/ let result = null;
                let $i1 = 0;
                let $arr1 = enumerableCallSite.ServiceCallSites;
                while ($i1 < $arr1.length)
                {
                    let serviceCallSite = $arr1[$i1++];
                    /*Type?*/ let scoped = this.VisitCallSite(serviceCallSite, state.Clone());
                    result ??= scoped;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(42950721629)
            
            //--TRIMMABLE-BOUNDARY-START(47245688925)
            /*Type? */ VisitRootCache(/*ServiceCallSite*/ singletonCallSite, /*CallSiteValidatorState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                state.Singleton = singletonCallSite;
                return this.VisitCallSiteMain(singletonCallSite, state.Clone());
            }
            //--TRIMMABLE-BOUNDARY-END(47245688925)
            
            //--TRIMMABLE-BOUNDARY-START(51540656221)
            /*Type? */ VisitScopeCache(/*ServiceCallSite*/ scopedCallSite, /*CallSiteValidatorState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(scopedCallSite.ServiceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type))
                {
                    return null;
                }
                this.VisitCallSiteMain(scopedCallSite, state.Clone());
                return scopedCallSite.ServiceType;
            }
            //--TRIMMABLE-BOUNDARY-END(51540656221)
            
            //--TRIMMABLE-BOUNDARY-START(30065819741)
            /*Type? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*CallSiteValidatorState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065819741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065819741)
            
            //--TRIMMABLE-BOUNDARY-START(55835623517)
            /*Type? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*CallSiteValidatorState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835623517);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835623517)
            
            //--TRIMMABLE-BOUNDARY-START(38655754333)
            /*Type? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*CallSiteValidatorState*/ state)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655754333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655754333)
            
            //--TRIMMABLE-BOUNDARY-START(1114205)
            static $_CallSiteValidatorState;
            static get CallSiteValidatorState()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator;
                return $cls.$_CallSiteValidatorState ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState", ($self) => class CallSiteValidatorState extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30065885277)
                    /*ServiceCallSite?*/ Singleton = null;
                    //--TRIMMABLE-BOUNDARY-END(30065885277)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591048797)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591048797)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Singleton = this.Singleton;
                        return copy;
                    }
                    static $h = 1114205;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065885277),
    {
      "p": 2424925,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180983389,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770917981,
        "f": 83886081
      },
      "n": "Singleton",
      "d": 1114205,
      "h": 30065885277,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065885277)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048797),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114205,
      "h": 8591048797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048797)
  ],
  "d": 1048669,
  "h": 1114205
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState`; }
                }, $cls, ($v) => $cls.$_CallSiteValidatorState = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114205)
            
            //--TRIMMABLE-BOUNDARY-START(12885950557)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950557)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296015965)
                this._scopedServices = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Type))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296015965)
                
            }
            static $h = 1048669;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180917853),
    {
      "r": 65537,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "ValidateCallSite",
      "d": 1048669,
      "h": 17180917853,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917853),
//--TRIMMABLE-BOUNDARY-START(21475885149),
    {
      "r": 65537,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "scope",
          "p": 1048666
        },
        {
          "n": "rootScope",
          "p": 1048666
        }
      ],
      "n": "ValidateResolution",
      "d": 1048669,
      "h": 21475885149,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885149),
//--TRIMMABLE-BOUNDARY-START(25770852445),
    {
      "r": 187760641,
      "p": [
        {
          "n": "callSite",
          "p": 2424925
        },
        {
          "n": "argument",
          "p": 1114205
        }
      ],
      "n": "VisitCallSite",
      "d": 1048669,
      "h": 25770852445,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770852445),
//--TRIMMABLE-BOUNDARY-START(34360787037),
    {
      "r": 187760641,
      "p": [
        {
          "n": "constructorCallSite",
          "p": 1376349
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitConstructor",
      "d": 1048669,
      "h": 34360787037,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34360787037),
//--TRIMMABLE-BOUNDARY-START(42950721629),
    {
      "r": 187760641,
      "p": [
        {
          "n": "enumerableCallSite",
          "p": 1704029
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitIEnumerable",
      "d": 1048669,
      "h": 42950721629,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950721629),
//--TRIMMABLE-BOUNDARY-START(47245688925),
    {
      "r": 187760641,
      "p": [
        {
          "n": "singletonCallSite",
          "p": 2424925
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitRootCache",
      "d": 1048669,
      "h": 47245688925,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(47245688925),
//--TRIMMABLE-BOUNDARY-START(51540656221),
    {
      "r": 187760641,
      "p": [
        {
          "n": "scopedCallSite",
          "p": 2424925
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitScopeCache",
      "d": 1048669,
      "h": 51540656221,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540656221),
//--TRIMMABLE-BOUNDARY-START(30065819741),
    {
      "r": 187760641,
      "p": [
        {
          "n": "constantCallSite",
          "p": 1310813
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitConstant",
      "d": 1048669,
      "h": 30065819741,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065819741),
//--TRIMMABLE-BOUNDARY-START(55835623517),
    {
      "r": 187760641,
      "p": [
        {
          "n": "serviceProviderCallSite",
          "p": 2687069
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitServiceProvider",
      "d": 1048669,
      "h": 55835623517,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55835623517),
//--TRIMMABLE-BOUNDARY-START(38655754333),
    {
      "r": 187760641,
      "p": [
        {
          "n": "factoryCallSite",
          "p": 1638493
        },
        {
          "n": "state",
          "p": 1114205
        }
      ],
      "n": "VisitFactory",
      "d": 1048669,
      "h": 38655754333,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655754333)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296015965),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$$.System.Type).$h,
      "n": "_scopedServices",
      "d": 1048669,
      "h": 4296015965,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950557),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048669,
      "h": 12885950557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950557)
  ],
  "j": [1114205
  ],
  "h": 1048669
}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState, $.$$.System.Type); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048669)
        
        
        //--TRIMMABLE-BOUNDARY-START(262237)
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource", ($self) => class DependencyInjectionEventSource extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(51539869789)
            /*DependencyInjectionEventSource*/ static Log = null;
            //--TRIMMABLE-BOUNDARY-END(51539869789)
            
            //--TRIMMABLE-BOUNDARY-START(327773)
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Keywords", ($self) => class Keywords
                {
                    //--TRIMMABLE-BOUNDARY-START(4295295069)
                    /*EventKeywords*/ static ServiceProviderInitialized = 1n;
                    //--TRIMMABLE-BOUNDARY-END(4295295069)
                    
                    static $h = 327773;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295069),
    {
      "t": 73662465,
      "n": "ServiceProviderInitialized",
      "d": 327773,
      "h": 4295295069,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295295069)
  ],
  "d": 262237,
  "h": 327773
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327773)
            
            //--TRIMMABLE-BOUNDARY-START(55834837085)
            /*int*/ static MaxChunkSize = 10240;
            //--TRIMMABLE-BOUNDARY-END(55834837085)
            
            //--TRIMMABLE-BOUNDARY-START(4295229533)
            /*List<WeakReference<ServiceProvider>>*/ _providers = null;
            //--TRIMMABLE-BOUNDARY-END(4295229533)
            
            //--TRIMMABLE-BOUNDARY-START(21475098717)
            $ctor$10()
            {
                super.$ctor$4(8/*EventSourceSettings.EtwSelfDescribingEventFormat*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098717);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098717)
            
            //--TRIMMABLE-BOUNDARY-START(8590196829)
            /*int?*/ _survivingProvidersCount = null;
            //--TRIMMABLE-BOUNDARY-END(8590196829)
            
            //--TRIMMABLE-BOUNDARY-START(30065033309)
            /*void */ CallSiteBuilt(/*string*/ serviceType, /*string*/ callSite, /*int*/ chunkIndex, /*int*/ chunkCount, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$1(1, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(serviceType), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(callSite), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(chunkIndex), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(chunkCount), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(serviceProviderHashCode) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(30065033309)
            
            //--TRIMMABLE-BOUNDARY-START(94489542749)
            /*void */ ServiceResolved(/*string*/ serviceType, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$13(2, serviceType, serviceProviderHashCode);
            }
            //--TRIMMABLE-BOUNDARY-END(94489542749)
            
            //--TRIMMABLE-BOUNDARY-START(47244902493)
            /*void */ ExpressionTreeGenerated(/*string*/ serviceType, /*int*/ nodeCount, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$12(3, serviceType, nodeCount, serviceProviderHashCode);
            }
            //--TRIMMABLE-BOUNDARY-END(47244902493)
            
            //--TRIMMABLE-BOUNDARY-START(38654967901)
            /*void */ DynamicMethodBuilt(/*string*/ serviceType, /*int*/ methodSize, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$12(4, serviceType, methodSize, serviceProviderHashCode);
            }
            //--TRIMMABLE-BOUNDARY-END(38654967901)
            
            //--TRIMMABLE-BOUNDARY-START(64424771677)
            /*void */ ScopeDisposed(/*int*/ serviceProviderHashCode, /*int*/ scopedServicesResolved, /*int*/ disposableServices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$2(5, serviceProviderHashCode, scopedServicesResolved, disposableServices);
            }
            //--TRIMMABLE-BOUNDARY-END(64424771677)
            
            //--TRIMMABLE-BOUNDARY-START(90194575453)
            /*void */ ServiceRealizationFailed$1(/*string?*/ exceptionMessage, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$13(6, exceptionMessage, serviceProviderHashCode);
            }
            //--TRIMMABLE-BOUNDARY-END(90194575453)
            
            //--TRIMMABLE-BOUNDARY-START(68719738973)
            /*void */ ServiceProviderBuilt(/*int*/ serviceProviderHashCode, /*int*/ singletonServices, /*int*/ scopedServices, /*int*/ transientServices, /*int*/ closedGenericsServices, /*int*/ openGenericsServices)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$1(7, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(serviceProviderHashCode), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(singletonServices), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(scopedServices), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(transientServices), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(closedGenericsServices), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(openGenericsServices) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68719738973)
            
            //--TRIMMABLE-BOUNDARY-START(77309673565)
            /*void */ ServiceProviderDescriptors(/*int*/ serviceProviderHashCode, /*string*/ descriptors, /*int*/ chunkIndex, /*int*/ chunkCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteEvent$1(8, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(serviceProviderHashCode), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$15(descriptors), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(chunkIndex), $.$$.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$10(chunkCount) ], null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(77309673565)
            
            //--TRIMMABLE-BOUNDARY-START(98784510045)
            /*void */ ServiceResolved$1(/*ServiceProvider*/ provider, /*Type*/ serviceType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784510045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ServiceResolved($.$$.System.Type.ToString.call(serviceType), $.$$.System.Object.GetHashCode.call(provider));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784510045)
            
            //--TRIMMABLE-BOUNDARY-START(34360000605)
            /*void */ CallSiteBuilt$1(/*ServiceProvider*/ provider, /*Type*/ serviceType, /*ServiceCallSite*/ callSite)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    /*string*/ let format = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.Instance.Format(callSite);
                    /*int*/ let chunkCount = (($.trunc(format.length / 10240/*MaxChunkSize*/) + (format.length % 10240/*MaxChunkSize*/ > 0 ? 1 : 0)) | 0);
                    /*int*/ let providerHashCode = $.$$.System.Object.GetHashCode.call(provider);
                    for(/*int*/ let i = 0; i < chunkCount; i++)
                    {
                        this.CallSiteBuilt($.$$.System.Type.ToString.call(serviceType), $.$$.System.String.Substring.call(format, ((i * 10240/*MaxChunkSize*/) | 0), $.$$.System.Math.Min$4(10240/*MaxChunkSize*/, ((format.length - ((i * 10240/*MaxChunkSize*/) | 0)) | 0))), i, chunkCount, providerHashCode);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000605)
            
            //--TRIMMABLE-BOUNDARY-START(42949935197)
            /*void */ DynamicMethodBuilt$1(/*ServiceProvider*/ provider, /*Type*/ serviceType, /*int*/ methodSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.DynamicMethodBuilt($.$$.System.Type.ToString.call(serviceType), methodSize, $.$$.System.Object.GetHashCode.call(provider));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935197)
            
            //--TRIMMABLE-BOUNDARY-START(85899608157)
            /*void */ ServiceRealizationFailed(/*Exception*/ exception, /*int*/ serviceProviderHashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(2/*EventLevel.Error*/, -1n))
                {
                    this.ServiceRealizationFailed$1($.$$.System.Exception.ToString.call(exception), serviceProviderHashCode);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899608157)
            
            //--TRIMMABLE-BOUNDARY-START(73014706269)
            /*void */ ServiceProviderBuilt$1(/*ServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._providers)
                    {
                        /*int*/ let providersCount = this._providers.Count;
                        let spc;
                        if (providersCount > 0 && ($.$is(this._survivingProvidersCount, $.$$.System.Int32, { set $v(v){ spc = v; } }) ? (providersCount >>> 0) >= ((2 * (spc >>> 0)) >>> 0) : providersCount === this._providers.Capacity))
                        {
                            this._providers.RemoveAll(new ($.$$.System.Predicate$$($.$$.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))().$ctor($.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource, /*static*/ (/**/ p) =>
                            {
                                return !p.TryGetTarget($.$discardRef());
                            }, {
  "r": 262145,
  "p": [
    {
      "n": "p",
      "p": $.$$.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider).$h
    }
  ],
  "n": "",
  "d": 262237,
  "h": 0,
  "f": 17825826
}));
                            this._survivingProvidersCount = this._providers.Count;
                        }
                        this._providers.Add(new ($.$$.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider))().$ctor$3(provider));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._providers)
                }
                this.WriteServiceProviderBuilt(provider);
            }
            //--TRIMMABLE-BOUNDARY-END(73014706269)
            
            //--TRIMMABLE-BOUNDARY-START(81604640861)
            /*void */ ServiceProviderDisposed(/*ServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._providers)
                    {
                        for(/*int*/ let i = ((this._providers.Count - 1) | 0); i >= 0; i--)
                        {
                            /*WeakReference<ServiceProvider>*/ let reference = this._providers.get_Item(i);
                            /*ServiceProvider?*/ let target;
                            if (!reference.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)) || target === provider)
                            {
                                this._providers.RemoveAt(i);
                                if (!(target === null))
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._providers)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604640861)
            
            //--TRIMMABLE-BOUNDARY-START(103079477341)
            /*void */ WriteServiceProviderBuilt(/*ServiceProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(4/*EventLevel.Informational*/, 1n))
                {
                    /*int*/ let singletonServices = 0;
                    /*int*/ let scopedServices = 0;
                    /*int*/ let transientServices = 0;
                    /*int*/ let closedGenericsServices = 0;
                    /*int*/ let openGenericsServices = 0;
                    /*StringBuilder*/ let descriptorBuilder = new $.$$.System.Text.StringBuilder().$ctor$8("{ \"descriptors\":[ ");
                    /*bool*/ let firstDescriptor = true;
                    let $i1 = 0;
                    let $arr1 = provider.CallSiteFactory.Descriptors;
                    while ($i1 < $arr1.length)
                    {
                        let descriptor = $arr1[$i1++];
                        if (firstDescriptor)
                        {
                            firstDescriptor = false;
                        }
                        else 
                        {
                            descriptorBuilder.Append$19(", ");
                        }
                        $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.AppendServiceDescriptor(descriptorBuilder, descriptor);
                        let $switch2 = descriptor.Lifetime;
                        switch($switch2)
                        {
                            case 0/*ServiceLifetime.Singleton*/:
                            singletonServices++;
                            break;
                            case 1/*ServiceLifetime.Scoped*/:
                            scopedServices++;
                            break;
                            case 2/*ServiceLifetime.Transient*/:
                            transientServices++;
                            break;
                        }
                        if (descriptor.ServiceType.IsGenericType)
                        {
                            if (descriptor.ServiceType.IsConstructedGenericType)
                            {
                                closedGenericsServices++;
                            }
                            else 
                            {
                                openGenericsServices++;
                            }
                        }
                    }
                    descriptorBuilder.Append$19(" ] }");
                    /*int*/ let providerHashCode = $.$$.System.Object.GetHashCode.call(provider);
                    this.ServiceProviderBuilt(providerHashCode, singletonServices, scopedServices, transientServices, closedGenericsServices, openGenericsServices);
                    /*string*/ let descriptorString = $.$$.System.Text.StringBuilder.ToString.call(descriptorBuilder);
                    /*int*/ let chunkCount = (($.trunc(descriptorString.length / 10240/*MaxChunkSize*/) + (descriptorString.length % 10240/*MaxChunkSize*/ > 0 ? 1 : 0)) | 0);
                    for(/*int*/ let i = 0; i < chunkCount; i++)
                    {
                        this.ServiceProviderDescriptors(providerHashCode, $.$$.System.String.Substring.call(descriptorString, ((i * 10240/*MaxChunkSize*/) | 0), $.$$.System.Math.Min$4(10240/*MaxChunkSize*/, ((descriptorString.length - ((i * 10240/*MaxChunkSize*/) | 0)) | 0))), i, chunkCount);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079477341)
            
            //--TRIMMABLE-BOUNDARY-START(25770066013)
            static /*void */ AppendServiceDescriptor(/*StringBuilder*/ builder, /*ServiceDescriptor*/ descriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770066013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                builder.Append$19("{ \"serviceType\": \"");
                builder.Append$13(descriptor.ServiceType);
                builder.Append$19("\", \"lifetime\": \"");
                builder.Append$13($.$box(descriptor.Lifetime, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceLifetime));
                builder.Append$19("\", ");
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationType(descriptor))
                {
                    builder.Append$19("\"implementationType\": \"");
                    builder.Append$13($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor));
                }
                else if (!descriptor.IsKeyedService && descriptor.ImplementationFactory !== null)
                {
                    builder.Append$19("\"implementationFactory\": \"");
                    builder.Append$13(descriptor.ImplementationFactory.Method);
                }
                else if (descriptor.IsKeyedService && descriptor.KeyedImplementationFactory !== null)
                {
                    builder.Append$19("\"implementationFactory\": \"");
                    builder.Append$13(descriptor.KeyedImplementationFactory.Method);
                }
                else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationInstance(descriptor))
                {
                    /*object?*/ let instance = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(descriptor);
                    $.$$.System.Diagnostics.Debug.Assert$2(instance !== null, "descriptor.ImplementationInstance != null");
                    builder.Append$19("\"implementationInstance\": \"");
                    builder.Append$13($.$$.System.Object.GetType.call(instance));
                    builder.Append$19(" (instance)");
                }
                else 
                {
                    builder.Append$19("\"unknown\": \"");
                }
                builder.Append$19("\" }");
            }
            //--TRIMMABLE-BOUNDARY-END(25770066013)
            
            //--TRIMMABLE-BOUNDARY-START(60129804381)
            /*void */ OnEventCommand(/*EventCommandEventArgs*/ command)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129804381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (command.Command === -2/*EventCommand.Enable*/)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._providers)
                        {
                            var $en5 = this._providers.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var reference = $en5.Current;
                                {
                                    /*ServiceProvider?*/ let provider;
                                    if (reference.TryGetTarget($.$ref(() => provider, ($v) => provider = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))
                                    {
                                        this.WriteServiceProviderBuilt(provider);
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._providers)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129804381)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295229533)
                this._providers = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295229533)
                
            }
            //--TRIMMABLE-BOUNDARY-START(17180131421)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51539869789)
                    this.Log = new $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource().$ctor$10();
                    //--TRIMMABLE-BOUNDARY-END(51539869789)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131421)
            
            static $h = 262237;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 74514433,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065033309),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 1310721
        },
        {
          "n": "callSite",
          "p": 1310721
        },
        {
          "n": "chunkIndex",
          "p": 655361
        },
        {
          "n": "chunkCount",
          "p": 655361
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "CallSiteBuilt",
      "d": 262237,
      "h": 30065033309,
      "f": 16777218,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065033309),
//--TRIMMABLE-BOUNDARY-START(94489542749),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 1310721
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "ServiceResolved",
      "d": 262237,
      "h": 94489542749,
      "f": 16777217,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489542749),
//--TRIMMABLE-BOUNDARY-START(47244902493),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 1310721
        },
        {
          "n": "nodeCount",
          "p": 655361
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "ExpressionTreeGenerated",
      "d": 262237,
      "h": 47244902493,
      "f": 16777217,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244902493),
//--TRIMMABLE-BOUNDARY-START(38654967901),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceType",
          "p": 1310721
        },
        {
          "n": "methodSize",
          "p": 655361
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "DynamicMethodBuilt",
      "d": 262237,
      "h": 38654967901,
      "f": 16777217,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654967901),
//--TRIMMABLE-BOUNDARY-START(64424771677),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        },
        {
          "n": "scopedServicesResolved",
          "p": 655361
        },
        {
          "n": "disposableServices",
          "p": 655361
        }
      ],
      "n": "ScopeDisposed",
      "d": 262237,
      "h": 64424771677,
      "f": 16777217,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424771677),
//--TRIMMABLE-BOUNDARY-START(90194575453),
    {
      "r": 65537,
      "p": [
        {
          "n": "exceptionMessage",
          "p": 1310721
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "ServiceRealizationFailed",
      "o": "@$1",
      "d": 262237,
      "h": 90194575453,
      "f": 16777217,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 6,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 2,
              "t": 73728001
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194575453),
//--TRIMMABLE-BOUNDARY-START(68719738973),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        },
        {
          "n": "singletonServices",
          "p": 655361
        },
        {
          "n": "scopedServices",
          "p": 655361
        },
        {
          "n": "transientServices",
          "p": 655361
        },
        {
          "n": "closedGenericsServices",
          "p": 655361
        },
        {
          "n": "openGenericsServices",
          "p": 655361
        }
      ],
      "n": "ServiceProviderBuilt",
      "d": 262237,
      "h": 68719738973,
      "f": 16777218,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 7,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 73728001
            },
            {
              "n": "Keywords",
              "v": 1,
              "t": 73662465
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719738973),
//--TRIMMABLE-BOUNDARY-START(77309673565),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        },
        {
          "n": "descriptors",
          "p": 1310721
        },
        {
          "n": "chunkIndex",
          "p": 655361
        },
        {
          "n": "chunkCount",
          "p": 655361
        }
      ],
      "n": "ServiceProviderDescriptors",
      "d": 262237,
      "h": 77309673565,
      "f": 16777218,
      "a": [
        {
          "t": 72744961,
          "c": 43022417921,
          "a": [
            {
              "v": 8,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 4,
              "t": 73728001
            },
            {
              "n": "Keywords",
              "v": 1,
              "t": 73662465
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309673565),
//--TRIMMABLE-BOUNDARY-START(98784510045),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        },
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "ServiceResolved",
      "o": "@$1",
      "d": 262237,
      "h": 98784510045,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784510045),
//--TRIMMABLE-BOUNDARY-START(34360000605),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "callSite",
          "p": 2424925
        }
      ],
      "n": "CallSiteBuilt",
      "o": "@$1",
      "d": 262237,
      "h": 34360000605,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360000605),
//--TRIMMABLE-BOUNDARY-START(42949935197),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        },
        {
          "n": "serviceType",
          "p": 187760641
        },
        {
          "n": "methodSize",
          "p": 655361
        }
      ],
      "n": "DynamicMethodBuilt",
      "o": "@$1",
      "d": 262237,
      "h": 42949935197,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949935197),
//--TRIMMABLE-BOUNDARY-START(85899608157),
    {
      "r": 65537,
      "p": [
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "serviceProviderHashCode",
          "p": 655361
        }
      ],
      "n": "ServiceRealizationFailed",
      "d": 262237,
      "h": 85899608157,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899608157),
//--TRIMMABLE-BOUNDARY-START(73014706269),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        }
      ],
      "n": "ServiceProviderBuilt",
      "o": "@$1",
      "d": 262237,
      "h": 73014706269,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014706269),
//--TRIMMABLE-BOUNDARY-START(81604640861),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        }
      ],
      "n": "ServiceProviderDisposed",
      "d": 262237,
      "h": 81604640861,
      "f": 16777217,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604640861),
//--TRIMMABLE-BOUNDARY-START(103079477341),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 3080285
        }
      ],
      "n": "WriteServiceProviderBuilt",
      "d": 262237,
      "h": 103079477341,
      "f": 16777218,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079477341),
//--TRIMMABLE-BOUNDARY-START(25770066013),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "descriptor",
          "p": 1704026
        }
      ],
      "n": "AppendServiceDescriptor",
      "d": 262237,
      "h": 25770066013,
      "f": 16777250,
      "a": [
        {
          "t": 77070337,
          "c": 4372037633
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770066013),
//--TRIMMABLE-BOUNDARY-START(60129804381),
    {
      "r": 65537,
      "p": [
        {
          "n": "command",
          "p": 73072641
        }
      ],
      "n": "OnEventCommand",
      "d": 262237,
      "h": 60129804381,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60129804381)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539869789),
    {
      "t": 262237,
      "n": "Log",
      "d": 262237,
      "h": 51539869789,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539869789),
//--TRIMMABLE-BOUNDARY-START(55834837085),
    {
      "t": 655361,
      "n": "MaxChunkSize",
      "d": 262237,
      "h": 55834837085,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834837085),
//--TRIMMABLE-BOUNDARY-START(4295229533),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)).$h,
      "n": "_providers",
      "d": 262237,
      "h": 4295229533,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229533),
//--TRIMMABLE-BOUNDARY-START(8590196829),
    {
      "t": $.$typeNullable($.$$.System.Int32).$h,
      "n": "_survivingProvidersCount",
      "d": 262237,
      "h": 8590196829,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475098717),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 262237,
      "h": 21475098717,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21475098717)
  ],
  "i": [90308609
  ],
  "j": [327773
  ],
  "h": 262237,
  "a": [
    {
      "t": 74842113,
      "c": 17254711297,
      "n": [
        {
          "n": "Name",
          "v": "Microsoft-Extensions-DependencyInjection",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262237)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions"))
//--TRIMMABLE-BOUNDARY-END(93)
