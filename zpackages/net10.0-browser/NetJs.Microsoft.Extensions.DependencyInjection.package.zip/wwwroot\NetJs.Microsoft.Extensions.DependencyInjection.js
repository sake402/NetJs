
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $stee, $st, $stt, $sr, $scc, $scm, $so, $sris, $sic, $sim, $sl, $sci, $srm, $sre, $sle, $mxdi) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.DependencyInjection", 
    {"h":4,"f":"Microsoft.Extensions.DependencyInjection","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.DependencyInjection.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"MicroBenchmarks, PublicKey=00240000048000009400000006020000002400005253413100040000010001004b86c4cb78549b34bab61a3b1800e23bfeb5b3ec390074041536a7e3cbd97f5f04cf0f857155a8928eaa29ebfd11cfbbad3ba70efea7bda3226c6a8d370a4cd303f714486b6ebc225985a638471e6ef571cc92a4613c00b8fa65d61ccee0cbe5f36330c9a01f4183559f1bef24cc2917c6d913e3a541333a1d05d9bed22b38cb","t":1310721}]},{"t":96337921,"c":4391305217,"a":[{"v":1507331,"t":142606337}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.DependencyInjection","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.DependencyInjection","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<,>", (TArgument, TResult) => $asm.$gt("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<,>", [TArgument, TResult], ($self) => class CallSiteVisitor$$$ extends $.$spc.System.Object
        {
            /*StackGuard*/ _stackGuard = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._stackGuard = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard().$ctor$1();
                }
                return this;
            }
            /*TResult */ VisitCallSite(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                if (!this._stackGuard.TryEnterOnCurrentStack())
                {
                    return this._stackGuard.RunOnEmptyStack($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, TArgument, TResult, new ($.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, TArgument, TResult))().$ctor(this, this.VisitCallSite), callSite, argument);
                }
                let $switch1 = callSite.Cache.Location;
                switch($switch1)
                {
                    case 0/*CallSiteResultCacheLocation.Root*/:
                    return this.VisitRootCache(callSite, argument);
                    case 1/*CallSiteResultCacheLocation.Scope*/:
                    return this.VisitScopeCache(callSite, argument);
                    case 2/*CallSiteResultCacheLocation.Dispose*/:
                    return this.VisitDisposeCache(callSite, argument);
                    case 3/*CallSiteResultCacheLocation.None*/:
                    return this.VisitNoCache(callSite, argument);
                    default:
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$15();
                }
            }
            /*TResult */ VisitCallSiteMain(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                let $switch1 = callSite.Kind;
                switch($switch1)
                {
                    case 0/*CallSiteKind.Factory*/:
                    return this.VisitFactory($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite), argument);
                    case 3/*CallSiteKind.IEnumerable*/:
                    return this.VisitIEnumerable($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite), argument);
                    case 1/*CallSiteKind.Constructor*/:
                    return this.VisitConstructor($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite), argument);
                    case 2/*CallSiteKind.Constant*/:
                    return this.VisitConstant($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite), argument);
                    case 4/*CallSiteKind.ServiceProvider*/:
                    return this.VisitServiceProvider($.$cast(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite), argument);
                    default:
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.CallSiteTypeNotSupported, $.$spc.System.Object.GetType.call(callSite)));
                }
            }
            /*TResult */ VisitNoCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                return this.VisitCallSiteMain(callSite, argument);
            }
            /*TResult */ VisitDisposeCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                return this.VisitCallSiteMain(callSite, argument);
            }
            /*TResult */ VisitRootCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                return this.VisitCallSiteMain(callSite, argument);
            }
            /*TResult */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*TArgument*/ argument)
            {
                return this.VisitCallSiteMain(callSite, argument);
            }
            static $h = 1179652;
            static $g = 2;
            static $f = 0b1110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitCallSite","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitCallSiteMain","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitNoCache","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitDisposeCache","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitRootCache","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitScopeCache","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":132},{"r":TResult?.$h??1572864,"p":[{"n":"constructorCallSite","p":1376260},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitConstructor","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":260},{"r":TResult?.$h??1572864,"p":[{"n":"constantCallSite","p":1310724},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitConstant","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":260},{"r":TResult?.$h??1572864,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitServiceProvider","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":260},{"r":TResult?.$h??1572864,"p":[{"n":"enumerableCallSite","p":1703940},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitIEnumerable","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":260},{"r":TResult?.$h??1572864,"p":[{"n":"factoryCallSite","p":1638404},{"n":"argument","p":TArgument?.$h??1507328}],"n":"VisitFactory","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":260}],"l":[{"t":2883588,"n":"_stackGuard","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4}],"g":[TArgument?.$h??1507328,TResult?.$h??1572864],"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor<${TArgument?.$fullName},${TResult?.$fullName}>`; }
        }));
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite", ($self) => class ServiceCallSite extends $.$spc.System.Object
        {
            $ctor$1(/*ResultCache*/ cache, /*object?*/ key)
            {
                super.$ctor();
                {
                    this.Cache = cache.Clone();
                    this.Key = key;
                }
                return this;
            }
            /*ResultCache*/ Cache;
            /*object?*/ Value = null;
            /*object?*/ Key = null;
            /*bool */ get CaptureDisposable()
            {
                return $.$spc.System.Type.op_Equality$1(this.ImplementationType, null) || $.$spc.System.IDisposable.$type.IsAssignableFrom(this.ImplementationType) || $.$spc.System.IAsyncDisposable.$type.IsAssignableFrom(this.ImplementationType);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Cache = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache);
            }
            static $h = 2424836;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":12887326724,"f":257},"n":"ServiceType","d":2424836,"h":8592359428,"f":257},{"p":142606337,"g":{"r":0,"d":0,"h":21477261316,"f":257},"n":"ImplementationType","d":2424836,"h":17182294020,"f":257},{"p":851972,"g":{"r":0,"d":0,"h":30067195908,"f":257},"n":"Kind","d":2424836,"h":25772228612,"f":257},{"p":2097156,"g":{"r":0,"d":0,"h":42952097796,"f":1},"n":"Cache","d":2424836,"h":38657130500,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":55836999684,"f":1},"s":{"r":0,"d":0,"h":60131966980,"f":1},"n":"Value","d":2424836,"h":51542032388,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":73016868868,"f":1},"n":"Key","d":2424836,"h":68721901572,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":81606803460,"f":1},"n":"CaptureDisposable","d":2424836,"h":77311836164,"f":1}],"c":[{"p":[{"n":"cache","p":2097156},{"n":"key","p":131073}],"n":".ctor","o":"$ctor$1","d":2424836,"h":4297392132,"f":4}],"h":2424836}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine", ($self) => class ServiceProviderEngine extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2752516;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":2752516,"h":4297719812,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2752516,"h":8592687108,"f":4}],"h":2752516}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine", ($self) => class CompiledServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            /*ILEmitResolverBuilder*/ ResolverBuilder = null;
            $ctor$2(/*ServiceProvider*/ provider)
            {
                super.$ctor$1();
                {
                    this.ResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder().$ctor$2(provider);
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                return this.ResolverBuilder.Build(callSite);
            }
            static $h = 1245188;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2752516,"p":[{"p":1769476,"g":{"r":0,"d":0,"h":12886147076,"f":1},"n":"ResolverBuilder","d":1245188,"h":8591179780,"f":1}],"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":1245188,"h":21476081668,"f":32769}],"c":[{"p":[{"n":"provider","p":3014660}],"n":".ctor","o":"$ctor$2","d":1245188,"h":17181114372,"f":1}],"h":1245188}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine`; }
        });
        
        $asm.$cls("$med.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$med.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.DependencyInjection", $.$med.System.SR.$type.Assembly);
                    $.$med.System.SR.s_resourceManager = temp;
                }
                return $.$med.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$med.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$med.System.SR.resourceCulture = value;
            }
            static /*string */ get AmbiguousConstructorException()
            {
                return "Unable to activate type '{0}'. The following constructors are ambiguous:";
            }
            static /*string */ FormatAmbiguousConstructorException(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to activate type '{0}'. The following constructors are ambiguous:", arg1);
            }
            static /*string */ get CannotResolveService()
            {
                return "Unable to resolve service for type '{0}' while attempting to activate '{1}'.";
            }
            static /*string */ FormatCannotResolveService(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to resolve service for type '{0}' while attempting to activate '{1}'.", arg1, arg2);
            }
            static /*string */ get CircularDependencyException()
            {
                return "A circular dependency was detected for the service of type '{0}'.";
            }
            static /*string */ FormatCircularDependencyException(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A circular dependency was detected for the service of type '{0}'.", arg1);
            }
            static /*string */ get UnableToActivateTypeException()
            {
                return "No constructor for type '{0}' can be instantiated using services from the service container and default values.";
            }
            static /*string */ FormatUnableToActivateTypeException(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No constructor for type '{0}' can be instantiated using services from the service container and default values.", arg1);
            }
            static /*string */ get OpenGenericServiceRequiresOpenGenericImplementation()
            {
                return "Open generic service type '{0}' requires registering an open generic implementation type.";
            }
            static /*string */ FormatOpenGenericServiceRequiresOpenGenericImplementation(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Open generic service type '{0}' requires registering an open generic implementation type.", arg1);
            }
            static /*string */ get ArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation()
            {
                return "Arity of open generic service type '{0}' does not equal arity of open generic implementation type '{1}'.";
            }
            static /*string */ FormatArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Arity of open generic service type '{0}' does not equal arity of open generic implementation type '{1}'.", arg1, arg2);
            }
            static /*string */ get TypeCannotBeActivated()
            {
                return "Cannot instantiate implementation type '{0}' for service type '{1}'.";
            }
            static /*string */ FormatTypeCannotBeActivated(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Cannot instantiate implementation type '{0}' for service type '{1}'.", arg1, arg2);
            }
            static /*string */ get NoConstructorMatch()
            {
                return "A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.";
            }
            static /*string */ FormatNoConstructorMatch(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("A suitable constructor for type '{0}' could not be located. Ensure the type is concrete and services are registered for all parameters of a public constructor.", arg1);
            }
            static /*string */ get ScopedInSingletonException()
            {
                return "Cannot consume {2} service '{0}' from {3} '{1}'.";
            }
            static /*string */ FormatScopedInSingletonException(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Cannot consume {2} service '{0}' from {3} '{1}'.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get ScopedResolvedFromRootException()
            {
                return "Cannot resolve '{0}' from root provider because it requires {2} service '{1}'.";
            }
            static /*string */ FormatScopedResolvedFromRootException(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Cannot resolve '{0}' from root provider because it requires {2} service '{1}'.", arg1, arg2, arg3);
            }
            static /*string */ get DirectScopedResolvedFromRootException()
            {
                return "Cannot resolve {1} service '{0}' from root provider.";
            }
            static /*string */ FormatDirectScopedResolvedFromRootException(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Cannot resolve {1} service '{0}' from root provider.", arg1, arg2);
            }
            static /*string */ get ConstantCantBeConvertedToServiceType()
            {
                return "Constant value of type '{0}' can't be converted to service type '{1}'";
            }
            static /*string */ FormatConstantCantBeConvertedToServiceType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Constant value of type '{0}' can't be converted to service type '{1}'", arg1, arg2);
            }
            static /*string */ get ImplementationTypeCantBeConvertedToServiceType()
            {
                return "Implementation type '{0}' can't be converted to service type '{1}'";
            }
            static /*string */ FormatImplementationTypeCantBeConvertedToServiceType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Implementation type '{0}' can't be converted to service type '{1}'", arg1, arg2);
            }
            static /*string */ get AsyncDisposableServiceDispose()
            {
                return "'{0}' type only implements IAsyncDisposable. Use DisposeAsync to dispose the container.";
            }
            static /*string */ FormatAsyncDisposableServiceDispose(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("'{0}' type only implements IAsyncDisposable. Use DisposeAsync to dispose the container.", arg1);
            }
            static /*string */ get GetCaptureDisposableNotSupported()
            {
                return "GetCaptureDisposable call is supported only for main scope";
            }
            static /*string */ get InvalidServiceDescriptor()
            {
                return "Invalid service descriptor";
            }
            static /*string */ get ServiceDescriptorNotExist()
            {
                return "Requested service descriptor doesn't exist.";
            }
            static /*string */ get CallSiteTypeNotSupported()
            {
                return "Call site type {0} is not supported";
            }
            static /*string */ FormatCallSiteTypeNotSupported(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Call site type {0} is not supported", arg1);
            }
            static /*string */ get TrimmingAnnotationsDoNotMatch()
            {
                return "Generic implementation type '{0}' has a DynamicallyAccessedMembers attribute applied to a generic argument type, but the service type '{1}' doesn't have a matching DynamicallyAccessedMembers attribute on its generic argument type.";
            }
            static /*string */ FormatTrimmingAnnotationsDoNotMatch(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Generic implementation type '{0}' has a DynamicallyAccessedMembers attribute applied to a generic argument type, but the service type '{1}' doesn't have a matching DynamicallyAccessedMembers attribute on its generic argument type.", arg1, arg2);
            }
            static /*string */ get TrimmingAnnotationsDoNotMatch_NewConstraint()
            {
                return "Generic implementation type '{0}' has a DefaultConstructorConstraint ('new()' constraint), but the generic service type '{1}' doesn't.";
            }
            static /*string */ FormatTrimmingAnnotationsDoNotMatch_NewConstraint(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Generic implementation type '{0}' has a DefaultConstructorConstraint ('new()' constraint), but the generic service type '{1}' doesn't.", arg1, arg2);
            }
            static /*string */ get AotCannotCreateEnumerableValueType()
            {
                return "Unable to create an Enumerable service of type '{0}' because it is a ValueType. Native code to support creating Enumerable services might not be available with native AOT.";
            }
            static /*string */ FormatAotCannotCreateEnumerableValueType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unable to create an Enumerable service of type '{0}' because it is a ValueType. Native code to support creating Enumerable services might not be available with native AOT.", arg1);
            }
            static /*string */ get AotCannotCreateGenericValueType()
            {
                return "Unable to create a generic service for type '{0}' because '{1}' is a ValueType. Native code to support creating generic services might not be available with native AOT.";
            }
            static /*string */ FormatAotCannotCreateGenericValueType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Unable to create a generic service for type '{0}' because '{1}' is a ValueType. Native code to support creating generic services might not be available with native AOT.", arg1, arg2);
            }
            static /*string */ get NoServiceRegistered()
            {
                return "No service for type '{0}' has been registered.";
            }
            static /*string */ FormatNoServiceRegistered(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("No service for type '{0}' has been registered.", arg1);
            }
            static /*string */ get InvalidServiceKeyType()
            {
                return "The type of the key used for lookup doesn't match the type in the constructor parameter with the ServiceKey attribute.";
            }
            static /*string */ get KeyedServiceAnyKeyUsedToResolveService()
            {
                return "KeyedService.AnyKey cannot be used to resolve a single service.";
            }
            static /*string */ get NoKeyedServiceRegistered()
            {
                return "No keyed service for type '{0}' using key type '{1}' has been registered.";
            }
            static /*string */ FormatNoKeyedServiceRegistered(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("No keyed service for type '{0}' using key type '{1}' has been registered.", arg1, arg2);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$med.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$med.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$med.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$med.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$med.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$med.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$med.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3407876;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3407876}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions", ($self) => class ServiceCollectionContainerBuilderExtensions
        {
            static /*ServiceProvider */ BuildServiceProvider(/*this IServiceCollection*/ services)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(services, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions.Default);
            }
            static /*ServiceProvider */ BuildServiceProvider$1(/*this IServiceCollection*/ services, /*bool*/ validateScopes)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(services, (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions;
                    const $i1 = new $t1();
                    $i1.ValidateScopes = validateScopes;
                    return $i1;
                })());
            }
            static /*ServiceProvider */ BuildServiceProvider$2(/*this IServiceCollection*/ services, /*ServiceProviderOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider().$ctor$1(services, options);
            }
            static $h = 524292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3014660,"p":[{"n":"services","p":786435}],"n":"BuildServiceProvider","d":524292,"h":4295491588,"f":33},{"r":3014660,"p":[{"n":"services","p":786435},{"n":"validateScopes","p":262145}],"n":"BuildServiceProvider","o":"@$1","d":524292,"h":8590458884,"f":33},{"r":3014660,"p":[{"n":"services","p":786435},{"n":"options","p":3145732}],"n":"BuildServiceProvider","o":"@$2","d":524292,"h":12885426180,"f":33}],"h":524292}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain", ($self) => class CallSiteChain extends $.$spc.System.Object
        {
            /*Dictionary<ServiceIdentifier, ChainItemInfo>*/ _callSiteChain = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._callSiteChain = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo))().$ctor$1();
                }
                return this;
            }
            /*void */ CheckCircularDependency(/*ServiceIdentifier*/ serviceIdentifier)
            {
                if (this._callSiteChain.ContainsKey(serviceIdentifier))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(this.CreateCircularDependencyExceptionMessage(serviceIdentifier));
                }
            }
            /*void */ Remove(/*ServiceIdentifier*/ serviceIdentifier)
            {
                this._callSiteChain.Remove(serviceIdentifier);
            }
            /*void */ Add(/*ServiceIdentifier*/ serviceIdentifier, /*Type?*/ implementationType)
            {
                this._callSiteChain.set_Item(serviceIdentifier, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo().$ctor$2(this._callSiteChain.Count, implementationType));
            }
            /*string */ CreateCircularDependencyExceptionMessage(/*ServiceIdentifier*/ serviceIdentifier)
            {
                /*var*/ let messageBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                messageBuilder.Append$2($.$med.System.SR.Format($.$med.System.SR.CircularDependencyException, $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43)));
                messageBuilder.AppendLine();
                this.AppendResolutionPath(messageBuilder, serviceIdentifier);
                return $.$spc.System.Text.StringBuilder.ToString.call(messageBuilder);
            }
            /*void */ AppendResolutionPath(/*StringBuilder*/ builder, /*ServiceIdentifier*/ currentlyResolving)
            {
                /*var*/ let ordered = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo)))().$ctor$3(this._callSiteChain);
                ordered.Sort$3(new ($.$spc.System.Comparison$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo)))().$ctor(this,  (/*a*/ a, /*b*/ b) =>
                {
                    return $.$spc.System.Int32.CompareTo$1.call(a.Value.Order, b.Value.Order);
                }));
                var $en2 = ordered.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var pair = $en2.Current;
                    {
                        /*ServiceIdentifier*/ let serviceIdentifier = pair.Key;
                        /*Type?*/ let implementationType = pair.Value.ImplementationType;
                        if ($.$spc.System.Type.op_Equality$1(implementationType, null) || $.$spc.System.Type.op_Equality$1(serviceIdentifier.ServiceType, implementationType))
                        {
                            builder.Append$2($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43));
                        }
                        else 
                        {
                            builder.Append$2($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(serviceIdentifier.ServiceType, true, false, true, /*+*/ 43)).Append$7(/*(*/ 40).Append$2($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(implementationType, true, false, true, /*+*/ 43)).Append$7(/*)*/ 41);
                        }
                        builder.Append$2(" -> ");
                    }
                }
                builder.Append$2($.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(currentlyResolving.ServiceType, true, false, true, /*+*/ 43));
            }
            static $_ChainItemInfo;
            static get ChainItemInfo()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain;
                return $cls.$_ChainItemInfo ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo", ($self) => class ChainItemInfo extends $.$spc.System.ValueType
                {
                    /*int*/ Order = 0;
                    /*Type?*/ ImplementationType = null;
                    $ctor$2(/*int*/ order, /*Type?*/ implementationType)
                    {
                        super.$ctor$1();
                        {
                            this.Order = order;
                            this.ImplementationType = implementationType;
                        }
                        return this;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Order = this.Order;
                        copy.ImplementationType = this.ImplementationType;
                        return copy;
                    }
                    static $h = 655364;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885557252,"f":1},"n":"Order","d":655364,"h":8590589956,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":25770459140,"f":1},"n":"ImplementationType","d":655364,"h":21475491844,"f":1}],"c":[{"p":[{"n":"order","p":655361},{"n":"implementationType","p":142606337}],"n":".ctor","o":"$ctor$2","d":655364,"h":30065426436,"f":1},{"n":".ctor","o":"$ctor$3","d":655364,"h":34360393732,"f":1}],"d":589828,"h":655364}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo`; }
                }, $cls, ($v) => $cls.$_ChainItemInfo = $v);
            }
            static $h = 589828;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"serviceIdentifier","p":2555908}],"n":"CheckCircularDependency","d":589828,"h":12885491716,"f":1},{"r":65537,"p":[{"n":"serviceIdentifier","p":2555908}],"n":"Remove","d":589828,"h":17180459012,"f":1},{"r":65537,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"implementationType","p":142606337,"f":65}],"n":"Add","d":589828,"h":21475426308,"f":1},{"r":1310721,"p":[{"n":"serviceIdentifier","p":2555908}],"n":"CreateCircularDependencyExceptionMessage","d":589828,"h":25770393604,"f":2},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"currentlyResolving","p":2555908}],"n":"AppendResolutionPath","d":589828,"h":30065360900,"f":2}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain.ChainItemInfo).$h,"n":"_callSiteChain","d":589828,"h":4295557124,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":589828,"h":8590524420,"f":1}],"j":[655364],"h":589828}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions", ($self) => class ServiceDescriptorExtensions
        {
            static /*bool */ HasImplementationInstance(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(serviceDescriptor) !== null;
            }
            static /*bool */ HasImplementationFactory(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationFactory(serviceDescriptor) !== null;
            }
            static /*bool */ HasImplementationType(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return $.$spc.System.Type.op_Inequality$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(serviceDescriptor), null);
            }
            static /*object? */ GetImplementationInstance(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationInstance : serviceDescriptor.ImplementationInstance;
            }
            static /*object? */ GetImplementationFactory(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationFactory : serviceDescriptor.ImplementationFactory;
            }
            static /*Type? */ GetImplementationType(/*this ServiceDescriptor*/ serviceDescriptor)
            {
                return serviceDescriptor.IsKeyedService ? serviceDescriptor.KeyedImplementationType : serviceDescriptor.ImplementationType;
            }
            static /*bool */ TryGetImplementationType(/*this ServiceDescriptor*/ serviceDescriptor, /*out Type?*/ type)
            {
                type.$v = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(serviceDescriptor);
                return $.$spc.System.Type.op_Inequality$1(type.$v, null);
            }
            static $h = 2490372;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"HasImplementationInstance","d":2490372,"h":4297457668,"f":33},{"r":262145,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"HasImplementationFactory","d":2490372,"h":8592424964,"f":33},{"r":262145,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"HasImplementationType","d":2490372,"h":12887392260,"f":33},{"r":131073,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"GetImplementationInstance","d":2490372,"h":17182359556,"f":33},{"r":131073,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"GetImplementationFactory","d":2490372,"h":21477326852,"f":33},{"r":142606337,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"GetImplementationType","d":2490372,"h":25772294148,"f":33},{"r":262145,"p":[{"n":"serviceDescriptor","p":1638403},{"n":"type","p":142606337,"f":2}],"n":"TryGetImplementationType","d":2490372,"h":30067261444,"f":33}],"h":2490372}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers", ($self) => class ServiceLookupHelpers
        {
            /*BindingFlags*/ static LookupFlags = 52;
            /*MethodInfo*/ static ArrayEmptyMethodInfo = null;
            /*MethodInfo*/ static InvokeFactoryMethodInfo = null;
            /*MethodInfo*/ static CaptureDisposableMethodInfo = null;
            /*MethodInfo*/ static TryGetValueMethodInfo = null;
            /*MethodInfo*/ static ResolveCallSiteAndScopeMethodInfo = null;
            /*MethodInfo*/ static AddMethodInfo = null;
            /*MethodInfo*/ static MonitorEnterMethodInfo = null;
            /*MethodInfo*/ static MonitorExitMethodInfo = null;
            static /*MethodInfo */ GetArrayEmptyMethodInfo(/*Type*/ itemType)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.ArrayEmptyMethodInfo.MakeGenericMethod($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ itemType ], null, null));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ArrayEmptyMethodInfo = $.$spc.System.Array.$type.GetMethod$1("Empty");
                }
                {
                    this.InvokeFactoryMethodInfo = $.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$type.GetMethod$2("Invoke", 52/*LookupFlags*/);
                }
                {
                    this.CaptureDisposableMethodInfo = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetMethod$2("CaptureDisposable", 52/*LookupFlags*/);
                }
                {
                    this.TryGetValueMethodInfo = $.$spc.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object).$type.GetMethod$2("TryGetValue", 52/*LookupFlags*/);
                }
                {
                    this.ResolveCallSiteAndScopeMethodInfo = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetMethod$2("Resolve", 52/*LookupFlags*/);
                }
                {
                    this.AddMethodInfo = $.$spc.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object).$type.GetMethod$2("Add", 52/*LookupFlags*/);
                }
                {
                    this.MonitorEnterMethodInfo = $.$spc.System.Threading.Monitor.$type.GetMethod$6("Enter", 16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/, null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.Object.$type, $.$spc.System.Boolean.$type.MakeByRefType()], [-1], null), null);
                }
                {
                    this.MonitorExitMethodInfo = $.$spc.System.Threading.Monitor.$type.GetMethod$6("Exit", 16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/, null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$spc.System.Object.$type], [-1], null), null);
                }
            }
            static $h = 2621444;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":79626241,"p":[{"n":"itemType","p":142606337}],"n":"GetArrayEmptyMethodInfo","d":2621444,"h":42952294404,"f":40}],"l":[{"t":75497473,"n":"LookupFlags","d":2621444,"h":4297588740,"f":34},{"t":79626241,"n":"ArrayEmptyMethodInfo","d":2621444,"h":8592556036,"f":34},{"t":79626241,"n":"InvokeFactoryMethodInfo","d":2621444,"h":12887523332,"f":40},{"t":79626241,"n":"CaptureDisposableMethodInfo","d":2621444,"h":17182490628,"f":40},{"t":79626241,"n":"TryGetValueMethodInfo","d":2621444,"h":21477457924,"f":40},{"t":79626241,"n":"ResolveCallSiteAndScopeMethodInfo","d":2621444,"h":25772425220,"f":40},{"t":79626241,"n":"AddMethodInfo","d":2621444,"h":30067392516,"f":40},{"t":79626241,"n":"MonitorEnterMethodInfo","d":2621444,"h":34362359812,"f":40},{"t":79626241,"n":"MonitorExitMethodInfo","d":2621444,"h":38657327108,"f":40}],"h":2621444}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowObjectDisposedException()
            {
                throw new $.$spc.System.ObjectDisposedException().$ctor$14("IServiceProvider");
            }
            static /*void */ ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.KeyedServiceAnyKeyUsedToResolveService, "IServiceProvider", "IServiceScopeFactory"));
            }
            static /*void */ ThrowInvalidOperationException_NoServiceRegistered(/*Type*/ serviceType)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.NoServiceRegistered, serviceType));
            }
            static /*void */ ThrowInvalidOperationException_NoKeyedServiceRegistered(/*Type*/ serviceType, /*Type*/ keyType)
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.NoKeyedServiceRegistered, serviceType, keyType));
            }
            static $h = 2949124;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowObjectDisposedException","d":2949124,"h":4297916420,"f":40},{"r":65537,"n":"ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService","d":2949124,"h":8592883716,"f":40},{"r":65537,"p":[{"n":"serviceType","p":142606337}],"n":"ThrowInvalidOperationException_NoServiceRegistered","d":2949124,"h":12887851012,"f":40},{"r":65537,"p":[{"n":"serviceType","p":142606337},{"n":"keyType","p":142606337}],"n":"ThrowInvalidOperationException_NoKeyedServiceRegistered","d":2949124,"h":17182818308,"f":40}],"h":2949124}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions", ($self) => class ServiceProviderOptions extends $.$spc.System.Object
        {
            /*ServiceProviderOptions*/ static Default = null;
            /*bool*/ ValidateScopes = false;
            /*bool*/ ValidateOnBuild = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ValidateScopes = false;
                this.ValidateOnBuild = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions().$ctor$1();
                }
            }
            static $h = 3145732;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17183014916,"f":1},"s":{"r":0,"d":0,"h":21477982212,"f":1},"n":"ValidateScopes","d":3145732,"h":12888047620,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34362884100,"f":1},"s":{"r":0,"d":0,"h":38657851396,"f":1},"n":"ValidateOnBuild","d":3145732,"h":30067916804,"f":1}],"l":[{"t":3145732,"n":"Default","d":3145732,"h":4298113028,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":3145732,"h":42952818692,"f":1}],"h":3145732}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProviderOptions`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext", ($self) => class ILEmitResolverBuilderContext extends $.$spc.System.Object
        {
            $ctor$1(/*ILGenerator*/ generator)
            {
                super.$ctor();
                this.Generator = generator;
                return this;
            }
            /*ILGenerator*/ Generator = null;
            /*List<object?>?*/ Constants = null;
            /*List<Func<IServiceProvider, object>>?*/ Factories = null;
            static $h = 1966084;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"g":{"r":0,"d":0,"h":17181835268,"f":1},"n":"Generator","d":1966084,"h":12886867972,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":30066737156,"f":1},"s":{"r":0,"d":0,"h":34361704452,"f":1},"n":"Constants","d":1966084,"h":25771769860,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object)).$h,"g":{"r":0,"d":0,"h":47246606340,"f":1},"s":{"r":0,"d":0,"h":51541573636,"f":1},"n":"Factories","d":1966084,"h":42951639044,"f":1}],"c":[{"p":[{"n":"generator"}],"n":".ctor","o":"$ctor$1","d":1966084,"h":4296933380,"f":1}],"h":1966084}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.Internal.ParameterDefaultValue", ($self) => class ParameterDefaultValue
        {
            static /*bool */ TryGetDefaultValue(/*ParameterInfo*/ parameter, /*out object?*/ defaultValue)
            {
                /*bool*/ let tryToGetDefaultValue;
                /*bool*/ let hasDefaultValue = $.$med.Microsoft.Extensions.Internal.ParameterDefaultValue.CheckHasDefaultValue(parameter, $.$ref(() => tryToGetDefaultValue, ($v) => tryToGetDefaultValue = $v, $.$spc.System.Boolean));
                defaultValue.$v = null;
                if (hasDefaultValue)
                {
                    if (tryToGetDefaultValue)
                    {
                        defaultValue.$v = parameter.DefaultValue;
                    }
                    /*bool*/ let isNullableParameterType = parameter.ParameterType.IsGenericType && $.$spc.System.Type.op_Equality$1(parameter.ParameterType.GetGenericTypeDefinition(), $.$spc.System.Nullable$$().$type);
                    if (defaultValue.$v === null && parameter.ParameterType.IsValueType && !isNullableParameterType)
                    {
                        defaultValue.$v = CreateValueType(parameter.ParameterType);
                    }
                    /*static object?*/  function CreateValueType(/*Type*/ t)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetUninitializedObject(t);
                    }
                    if (defaultValue.$v !== null && isNullableParameterType)
                    {
                        /*Type?*/ let underlyingType = $.$spc.System.Nullable.GetUnderlyingType(parameter.ParameterType);
                        if ($.$spc.System.Type.op_Inequality$1(underlyingType, null) && underlyingType.IsEnum)
                        {
                            defaultValue.$v = $.$spc.System.Enum.ToObject(underlyingType, defaultValue.$v);
                        }
                    }
                }
                return hasDefaultValue;
            }
            static /*bool */ CheckHasDefaultValue(/*ParameterInfo*/ parameter, /*out bool*/ tryToGetDefaultValue)
            {
                tryToGetDefaultValue.$v = true;
                return parameter.HasDefaultValue;
            }
            static $h = 3211268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"defaultValue","p":131073,"f":2}],"n":"TryGetDefaultValue","d":3211268,"h":4298178564,"f":33},{"r":262145,"p":[{"n":"parameter","p":81133569},{"n":"tryToGetDefaultValue","p":262145,"f":2}],"n":"CheckHasDefaultValue","d":3211268,"h":8593145860,"f":33}],"h":3211268}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.ParameterDefaultValue`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.Internal.TypeNameHelper", ($self) => class TypeNameHelper
        {
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                return item === null ? null : $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1($.$spc.System.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), type, $.$ref(() => new $.$med.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions().$ctor$2(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                const $t2 = builder;
                return name ?? $.$ifnn($t2, ($t) => $.$spc.System.Text.StringBuilder.ToString.call($t)) ?? $.$spc.System.String.Empty;
            }
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*string?*/ let builtInName;
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$med.Microsoft.Extensions.Internal.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$spc.System.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$2(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$2(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$spc.System.String.Replace$2.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$2(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace$5(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$7(/*[*/ 91);
                    builder.Append(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$7(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$7(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$spc.System.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$2(type.Namespace);
                        builder.Append$7(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$spc.System.String.IndexOf.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$2(type.Name);
                    return;
                }
                builder.Append$3(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$7(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$med.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), $.$spc.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$7(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$spc.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$7(/* */ 32);
                        }
                    }
                    builder.Append$7(/*>*/ 62);
                }
            }
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                let $cls = $.$med.Microsoft.Extensions.Internal.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr("$med.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions", ($self) => class DisplayNameOptions extends $.$spc.System.ValueType
                {
                    $ctor$2(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    /*bool*/ FullName = false;
                    /*bool*/ IncludeGenericParameters = false;
                    /*bool*/ IncludeGenericParameterNames = false;
                    /*char*/ NestedTypeDelimiter = 0;
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.FullName = false;
                        this.IncludeGenericParameters = false;
                        this.IncludeGenericParameterNames = false;
                    }
                    static $h = 3342340;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17183211524,"f":1},"n":"FullName","d":3342340,"h":12888244228,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30068113412,"f":1},"n":"IncludeGenericParameters","d":3342340,"h":25773146116,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42953015300,"f":1},"n":"IncludeGenericParameterNames","d":3342340,"h":38658048004,"f":1},{"p":458753,"g":{"r":0,"d":0,"h":55837917188,"f":1},"n":"NestedTypeDelimiter","d":3342340,"h":51542949892,"f":1}],"c":[{"p":[{"n":"fullName","p":262145},{"n":"includeGenericParameterNames","p":262145},{"n":"includeGenericParameters","p":262145},{"n":"nestedTypeDelimiter","p":458753}],"n":".ctor","o":"$ctor$2","d":3342340,"h":4298309636,"f":1},{"n":".ctor","o":"$ctor$3","d":3342340,"h":60132884484,"f":1}],"d":3276804,"h":3342340}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String)()
                        const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$spc.System.Void.$type, "void");
                        $i1.Add($.$spc.System.Boolean.$type, "bool");
                        $i1.Add($.$spc.System.Byte.$type, "byte");
                        $i1.Add($.$spc.System.Char.$type, "char");
                        $i1.Add($.$spc.System.Decimal.$type, "decimal");
                        $i1.Add($.$spc.System.Double.$type, "double");
                        $i1.Add($.$spc.System.Single.$type, "float");
                        $i1.Add($.$spc.System.Int32.$type, "int");
                        $i1.Add($.$spc.System.Int64.$type, "long");
                        $i1.Add($.$spc.System.Object.$type, "object");
                        $i1.Add($.$spc.System.SByte.$type, "sbyte");
                        $i1.Add($.$spc.System.Int16.$type, "short");
                        $i1.Add($.$spc.System.String.$type, "string");
                        $i1.Add($.$spc.System.UInt32.$type, "uint");
                        $i1.Add($.$spc.System.UInt64.$type, "ulong");
                        $i1.Add($.$spc.System.UInt16.$type, "ushort");
                        return $i1;
                    })();
                }
            }
            static $h = 3276804;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"item","p":131073},{"n":"fullName","p":262145,"f":65,"v":true}],"n":"GetTypeDisplayName","d":3276804,"h":12888178692,"f":33},{"r":1310721,"p":[{"n":"type","p":142606337},{"n":"fullName","p":262145,"f":65,"v":true},{"n":"includeGenericParameterNames","p":262145,"f":65,"v":false},{"n":"includeGenericParameters","p":262145,"f":65,"v":true},{"n":"nestedTypeDelimiter","p":458753,"f":65,"v":"\u002B"}],"n":"GetTypeDisplayName","o":"@$1","d":3276804,"h":17183145988,"f":33},{"r":1310721,"p":[{"n":"builder","p":122945537,"f":4},{"n":"type","p":142606337},{"n":"options","p":3342340,"f":8}],"n":"ProcessType","d":3276804,"h":21478113284,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"options","p":3342340,"f":8}],"n":"ProcessArrayType","d":3276804,"h":25773080580,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"genericArguments","p":0},{"n":"length","p":655361},{"n":"options","p":3342340,"f":8}],"n":"ProcessGenericType","d":3276804,"h":30068047876,"f":34}],"l":[{"t":458753,"n":"DefaultNestedTypeDelimiter","d":3276804,"h":4298244100,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String).$h,"n":"_builtInTypeNames","d":3276804,"h":8593211396,"f":34}],"j":[3342340],"h":3276804}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard", ($self) => class StackGuard extends $.$spc.System.Object
        {
            /*int*/ static MaxExecutionStackCount = 1024;
            /*int*/ _executionStackCount = 0;
            /*bool */ TryEnterOnCurrentStack()
            {
                if ($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.TryEnsureSufficientExecutionStack())
                {
                    return true;
                }
                if (this._executionStackCount < 1024/*MaxExecutionStackCount*/)
                {
                    return false;
                }
                throw new $.$spc.System.InsufficientExecutionStackException().$ctor$9();
            }
            /*TR */ RunOnEmptyStack(T1, T2, TR, /*Func<T1, T2, TR>*/ action, /*T1*/ arg1, /*T2*/ arg2)
            {
                return this.RunOnEmptyStackCore(TR, new ($.$spc.System.Func$$$($.$spc.System.Object, TR))().$ctor(null, /*static*/ (/*s*/ s) =>
                {
                    /*var*/ let t = $.$cast(s, $.$spc.System.ValueTuple$$$$($.$spc.System.Func$$$$(T1, T2, TR), T1, T2));
                    return t.Item1.Invoke(t.Item2, t.Item3);
                }), new ($.$spc.System.ValueTuple$$$$($.$spc.System.Func$$$$(T1, T2, TR), T1, T2))().$ctor$2(action, arg1, arg2));
            }
            /*R */ RunOnEmptyStackCore(R, /*Func<object, R>*/ action, /*object*/ state)
            {
                this._executionStackCount++;
                try
                {
                    /*Task<R>*/ let task = $.$spc.System.Threading.Tasks.Task.Factory.StartNew$15(R, action, state, $.$spc.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$spc.System.Threading.Tasks.TaskScheduler.Default);
                    if (!task.IsCompleted)
                    {
                        (task).System$IAsyncResult$AsyncWaitHandle.WaitOne$2();
                    }
                    return task.GetAwaiter$1().GetResult();
                }
                finally
                {
                    {
                        this._executionStackCount--;
                    }
                }
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2883588;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"n":"TryEnterOnCurrentStack","d":2883588,"h":12887785476,"f":1},{"r":(T1, T2, TR) => TR.$h,"p":[{"n":"action","p":(T1, T2, TR) => $.$spc.System.Func$$$$(T1, T2, TR).$h},{"n":"arg1","p":(T1, T2, TR) => T1.$h},{"n":"arg2","p":(T1, T2, TR) => T2.$h}],"g":["T1","T2","TR"],"n":"RunOnEmptyStack","d":2883588,"h":17182752772,"f":131073},{"r":(R) => R.$h,"p":[{"n":"action","p":(R) => $.$spc.System.Func$$$($.$spc.System.Object, R).$h},{"n":"state","p":131073}],"g":["R"],"n":"RunOnEmptyStackCore","d":2883588,"h":21477720068,"f":131074}],"l":[{"t":655361,"n":"MaxExecutionStackCount","d":2883588,"h":4297850884,"f":34},{"t":655361,"n":"_executionStackCount","d":2883588,"h":8592818180,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2883588,"h":25772687364,"f":1}],"h":2883588}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions", ($self) => class DependencyInjectionEventSourceExtensions
        {
            static /*void */ ExpressionTreeGenerated(/*this DependencyInjectionEventSource*/ source, /*ServiceProvider*/ provider, /*Type*/ serviceType, /*Expression*/ expression)
            {
                if (source.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    /*var*/ let visitor = new $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor().$ctor$2();
                    visitor.Visit(expression);
                    source.ExpressionTreeGenerated($.$spc.System.Type.ToString.call(serviceType), visitor.NodeCount, $.$spc.System.Object.GetHashCode.call(provider));
                }
            }
            static $_NodeCountingVisitor;
            static get NodeCountingVisitor()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions;
                return $cls.$_NodeCountingVisitor ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor", ($self) => class NodeCountingVisitor extends $.$sle.System.Linq.Expressions.ExpressionVisitor
                {
                    /*int*/ NodeCount = 0;
                    /*Expression? */ Visit(/*Expression?*/ e)
                    {
                        super.Visit(e);
                        this.NodeCount++;
                        return e;
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 458756;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":11251391,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885360644,"f":1},"s":{"r":0,"d":0,"h":17180327940,"f":2},"n":"NodeCount","d":458756,"h":8590393348,"f":1}],"m":[{"r":8695487,"p":[{"n":"e","p":8695487}],"n":"Visit","d":458756,"h":21475295236,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":458756,"h":25770262532,"f":1}],"d":393220,"h":458756}; }
                    static get $b() { return $.$sle.System.Linq.Expressions.ExpressionVisitor; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.NodeCountingVisitor`; }
                }, $cls, ($v) => $cls.$_NodeCountingVisitor = $v);
            }
            static $h = 393220;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"source","p":262148},{"n":"provider","p":3014660},{"n":"serviceType","p":142606337},{"n":"expression","p":8695487}],"n":"ExpressionTreeGenerated","d":393220,"h":4295360516,"f":33}],"j":[458756],"h":393220}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory", ($self) => class CallSiteFactory extends $.$spc.System.Object
        {
            /*int*/ static DefaultSlot = 0;
            /*ServiceDescriptor[]*/ _descriptors = null;
            /*ConcurrentDictionary<ServiceCacheKey, ServiceCallSite>*/ _callSiteCache = null;
            /*Dictionary<ServiceIdentifier, ServiceDescriptorCacheItem>*/ _descriptorLookup = null;
            /*ConcurrentDictionary<ServiceIdentifier, object>*/ _callSiteLocks = null;
            /*StackGuard*/ _stackGuard = null;
            $ctor$1(/*ICollection<ServiceDescriptor>*/ descriptors)
            {
                super.$ctor();
                {
                    this._stackGuard = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.StackGuard().$ctor$1();
                    this._descriptors = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor), null, [descriptors.System$Collections$Generic$ICollection$$$Count], null);
                    descriptors.System$Collections$Generic$ICollection$$$CopyTo(this._descriptors, 0, [$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor]);
                    this.Populate();
                }
                return this;
            }
            /*ServiceDescriptor[] */ get Descriptors()
            {
                return this._descriptors;
            }
            /*void */ Populate()
            {
                let $i1 = 0;
                let $arr1 = this._descriptors;
                while ($i1 < $arr1.length)
                {
                    let descriptor = $arr1[$i1++];
                    /*Type*/ let serviceType = descriptor.ServiceType;
                    /*Type?*/ let implementationType;
                    if (serviceType.IsGenericTypeDefinition)
                    {
                        /*Type?*/ let implementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor);
                        if ($.$spc.System.Type.op_Equality$1(implementationType, null) || !implementationType.IsGenericTypeDefinition)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$med.System.SR.Format($.$med.System.SR.OpenGenericServiceRequiresOpenGenericImplementation, serviceType), "descriptors");
                        }
                        if (implementationType.IsAbstract$1 || implementationType.IsInterface)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.TypeCannotBeActivated, implementationType, serviceType));
                        }
                        /*Type[]*/ let serviceTypeGenericArguments = serviceType.GetGenericArguments();
                        /*Type[]*/ let implementationTypeGenericArguments = implementationType.GetGenericArguments();
                        if (serviceTypeGenericArguments.length !== implementationTypeGenericArguments.length)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$med.System.SR.Format$1($.$med.System.SR.ArityOfOpenGenericServiceNotEqualArityOfOpenGenericImplementation, serviceType, implementationType), "descriptors");
                        }
                        if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyOpenGenericServiceTrimmability)
                        {
                            $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ValidateTrimmingAnnotations(serviceType, serviceTypeGenericArguments, implementationType, implementationTypeGenericArguments);
                        }
                    }
                    else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.TryGetImplementationType(descriptor, $.$ref(() => implementationType, ($v) => implementationType = $v, $.$spc.System.Type)))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(implementationType, null), "implementationType != null");
                        if (implementationType.IsGenericTypeDefinition || implementationType.IsAbstract$1 || implementationType.IsInterface)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.TypeCannotBeActivated, implementationType, serviceType));
                        }
                    }
                    /*var*/ let cacheKey = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(descriptor);
                    /*ServiceDescriptorCacheItem*/ let cacheItem;
                    this._descriptorLookup.TryGetValue(cacheKey, $.$ref(() => cacheItem, ($v) => cacheItem = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem));
                    this._descriptorLookup.set_Item(cacheKey, cacheItem.Add(descriptor));
                }
            }
            static /*void */ ValidateTrimmingAnnotations(/*Type*/ serviceType, /*Type[]*/ serviceTypeGenericArguments, /*Type*/ implementationType, /*Type[]*/ implementationTypeGenericArguments)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(serviceTypeGenericArguments.length === implementationTypeGenericArguments.length, "serviceTypeGenericArguments.Length == implementationTypeGenericArguments.Length");
                for(/*int*/ let i = 0; i < serviceTypeGenericArguments.length; i++)
                {
                    /*Type*/ let serviceGenericType = $.$spc.System.Array.$ReadT1.call(serviceTypeGenericArguments, i);
                    /*Type*/ let implementationGenericType = $.$spc.System.Array.$ReadT1.call(implementationTypeGenericArguments, i);
                    /*DynamicallyAccessedMemberTypes*/ let serviceDynamicallyAccessedMembers = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetDynamicallyAccessedMemberTypes(serviceGenericType);
                    /*DynamicallyAccessedMemberTypes*/ let implementationDynamicallyAccessedMembers = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetDynamicallyAccessedMemberTypes(implementationGenericType);
                    if (!$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.AreCompatible(serviceDynamicallyAccessedMembers, implementationDynamicallyAccessedMembers))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.TrimmingAnnotationsDoNotMatch, implementationType.FullName, serviceType.FullName));
                    }
                    /*bool*/ let serviceHasNewConstraint = ((serviceGenericType.GenericParameterAttributes & (16/*GenericParameterAttributes.DefaultConstructorConstraint*/)) == (16/*GenericParameterAttributes.DefaultConstructorConstraint*/));
                    /*bool*/ let implementationHasNewConstraint = ((implementationGenericType.GenericParameterAttributes & (16/*GenericParameterAttributes.DefaultConstructorConstraint*/)) == (16/*GenericParameterAttributes.DefaultConstructorConstraint*/));
                    if (implementationHasNewConstraint && !serviceHasNewConstraint)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.TrimmingAnnotationsDoNotMatch_NewConstraint, implementationType.FullName, serviceType.FullName));
                    }
                }
            }
            static /*DynamicallyAccessedMemberTypes */ GetDynamicallyAccessedMemberTypes(/*Type*/ serviceGenericType)
            {
                var $en2 = serviceGenericType.GetCustomAttributesData().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attributeData = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$spc.System.String.op_Equality(attributeData.AttributeType.FullName, "System.Diagnostics.CodeAnalysis.DynamicallyAccessedMembersAttribute") && attributeData.ConstructorArguments.System$Collections$Generic$ICollection$$$Count === 1 && $.$spc.System.String.op_Equality(attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$spc.System.Reflection.CustomAttributeTypedArgument]).ArgumentType.FullName, "System.Diagnostics.CodeAnalysis.DynamicallyAccessedMemberTypes"))
                        {
                            return $.$cast($.$cast(attributeData.ConstructorArguments.System$Collections$Generic$IList$$$get_Item(0, [$.$spc.System.Reflection.CustomAttributeTypedArgument]).Value, $.$spc.System.Int32), $.$spc.System.Diagnostics.CodeAnalysis.DynamicallyAccessedMemberTypes);
                        }
                    }
                }
                return 0/*DynamicallyAccessedMemberTypes.None*/;
            }
            static /*bool */ AreCompatible(/*DynamicallyAccessedMemberTypes*/ serviceDynamicallyAccessedMembers, /*DynamicallyAccessedMemberTypes*/ implementationDynamicallyAccessedMembers)
            {
                return ((serviceDynamicallyAccessedMembers & (implementationDynamicallyAccessedMembers)) == (implementationDynamicallyAccessedMembers));
            }
            /*int? */ GetSlot(/*ServiceDescriptor*/ serviceDescriptor)
            {
                /*ServiceDescriptorCacheItem*/ let item;
                if (this._descriptorLookup.TryGetValue($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(serviceDescriptor), $.$ref(() => item, ($v) => item = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return item.GetSlot(serviceDescriptor);
                }
                return null;
            }
            /*ServiceCallSite? */ GetCallSite(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                /*ServiceCallSite?*/ let site;
                return this._callSiteCache.TryGetValue(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, 0/*DefaultSlot*/), $.$ref(() => site, ($v) => site = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)) ? site : this.CreateCallSite(serviceIdentifier, callSiteChain);
            }
            /*ServiceCallSite? */ GetCallSite$1(/*ServiceDescriptor*/ serviceDescriptor, /*CallSiteChain*/ callSiteChain)
            {
                /*var*/ let serviceIdentifier = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor(serviceDescriptor);
                /*ServiceDescriptorCacheItem*/ let descriptor;
                if (this._descriptorLookup.TryGetValue(serviceIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return this.TryCreateExact$1(serviceDescriptor, serviceIdentifier, callSiteChain, descriptor.GetSlot(serviceDescriptor));
                }
                $.$spc.System.Diagnostics.Debug.Fail("_descriptorLookup didn't contain requested serviceDescriptor");
                return null;
            }
            /*ServiceCallSite? */ CreateCallSite(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                if (!this._stackGuard.TryEnterOnCurrentStack())
                {
                    return this._stackGuard.RunOnEmptyStack($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, new ($.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor(this, this.CreateCallSite), serviceIdentifier, callSiteChain);
                }
                /*var*/ let callsiteLock = this._callSiteLocks.GetOrAdd(serviceIdentifier, new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$spc.System.Object))().$ctor(null, /*static*/ (/**/ _0) =>
                {
                    return new $.$spc.System.Object().$ctor();
                }));
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(callsiteLock)
                    {
                        callSiteChain.CheckCircularDependency(serviceIdentifier);
                        /*ServiceCallSite?*/ let callSite = this.TryCreateExact(serviceIdentifier, callSiteChain) ?? this.TryCreateOpenGeneric(serviceIdentifier, callSiteChain) ?? this.TryCreateEnumerable(serviceIdentifier, callSiteChain);
                        return callSite;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(callsiteLock)
                }
            }
            /*ServiceCallSite? */ TryCreateExact(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                /*ServiceDescriptorCacheItem*/ let descriptor;
                if (this._descriptorLookup.TryGetValue(serviceIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                {
                    return this.TryCreateExact$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/);
                }
                if (serviceIdentifier.ServiceKey !== null)
                {
                    /*var*/ let catchAllIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, serviceIdentifier.ServiceType);
                    if (this._descriptorLookup.TryGetValue(catchAllIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        return this.TryCreateExact$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/);
                    }
                }
                return null;
            }
            /*ServiceCallSite? */ TryCreateOpenGeneric(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                if (serviceIdentifier.ServiceType.IsConstructedGenericType)
                {
                    /*ServiceIdentifier*/ let genericIdentifier = serviceIdentifier.GetGenericTypeDefinition();
                    /*ServiceDescriptorCacheItem*/ let descriptor;
                    if (this._descriptorLookup.TryGetValue(genericIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        return this.TryCreateOpenGeneric$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/, true);
                    }
                    if (serviceIdentifier.ServiceKey !== null)
                    {
                        /*var*/ let catchAllIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, genericIdentifier.ServiceType);
                        if (this._descriptorLookup.TryGetValue(catchAllIdentifier, $.$ref(() => descriptor, ($v) => descriptor = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                        {
                            return this.TryCreateOpenGeneric$1(descriptor.Last, serviceIdentifier, callSiteChain, 0/*DefaultSlot*/, true);
                        }
                    }
                }
                return null;
            }
            /*ServiceCallSite? */ TryCreateEnumerable(/*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain)
            {
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, 0/*DefaultSlot*/);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                try
                {
                    callSiteChain.Add(serviceIdentifier, null);
                    /*var*/ let serviceType = serviceIdentifier.ServiceType;
                    if (!serviceType.IsConstructedGenericType || $.$spc.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        return null;
                    }
                    /*Type*/ let itemType = $.$spc.System.Array.$ReadT1.call(serviceType.GenericTypeArguments, 0);
                    /*var*/ let cacheKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceIdentifier.ServiceKey, itemType);
                    if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility && itemType.IsValueType)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.AotCannotCreateEnumerableValueType, itemType));
                    }
                    /*CallSiteResultCacheLocation*/ let cacheLocation = 0/*CallSiteResultCacheLocation.Root*/;
                    /*ServiceCallSite[]*/ let callSites;
                    /*bool*/ let isAnyKeyLookup = serviceIdentifier.ServiceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey;
                    /*ServiceDescriptorCacheItem*/ let descriptors;
                    if (!itemType.IsConstructedGenericType && !isAnyKeyLookup && this._descriptorLookup.TryGetValue(cacheKey, $.$ref(() => descriptors, ($v) => descriptors = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem)))
                    {
                        /*int*/ let slot = descriptors.Count;
                        callSites = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [descriptors.Count], null);
                        for(/*int*/ let i = 0; i < descriptors.Count; i++)
                        {
                            /*ServiceDescriptor*/ let descriptor = descriptors.get_Item(i);
                            /*ServiceCallSite*/ let callSite = this.CreateExact(descriptor, cacheKey, callSiteChain, --slot);
                            cacheLocation = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetCommonCacheLocation(cacheLocation, callSite.Cache.Location);
                            $.$spc.System.Array.$WriteT1.call(callSites, callSite, i);
                        }
                    }
                    else 
                    {
                        /*List<KeyValuePair<int, ServiceCallSite>>*/ let callSitesByIndex = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))().$ctor$1();
                        /*Dictionary<ServiceIdentifier, int>?*/ let keyedSlotAssignment = null;
                        /*int*/ let slot = 0;
                        for(/*int*/ let i = ((this._descriptors.length - 1) | 0); i >= 0; i--)
                        {
                            if (KeysMatch(cacheKey.ServiceKey, $.$spc.System.Array.$ReadT1.call(this._descriptors, i).ServiceKey))
                            {
                                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateExact($.$spc.System.Array.$ReadT1.call(this._descriptors, i).ServiceType, cacheKey.ServiceType))
                                {
                                    /*ServiceIdentifier*/ let registrationKey = isAnyKeyLookup ? $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor($.$spc.System.Array.$ReadT1.call(this._descriptors, i)) : cacheKey;
                                    slot = GetSlot.call(this, registrationKey);
                                    /*ServiceCallSite*/ let callSite = this.CreateExact($.$spc.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot);
                                    AddCallSite.call(this, callSite, i);
                                    UpdateSlot.call(this, registrationKey);
                                }
                            }
                        }
                        for(/*int*/ let i = ((this._descriptors.length - 1) | 0); i >= 0; i--)
                        {
                            if (KeysMatch(cacheKey.ServiceKey, $.$spc.System.Array.$ReadT1.call(this._descriptors, i).ServiceKey))
                            {
                                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateOpenGeneric($.$spc.System.Array.$ReadT1.call(this._descriptors, i).ServiceType, cacheKey.ServiceType))
                                {
                                    /*ServiceIdentifier*/ let registrationKey = isAnyKeyLookup ? $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromDescriptor($.$spc.System.Array.$ReadT1.call(this._descriptors, i)) : cacheKey;
                                    slot = GetSlot.call(this, registrationKey);
                                    let callSite;
                                    if (this.CreateOpenGeneric($.$spc.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot, false) !== null && ((callSite = this.CreateOpenGeneric($.$spc.System.Array.$ReadT1.call(this._descriptors, i), registrationKey, callSiteChain, slot, false), callSite != null && true)))
                                    {
                                        AddCallSite.call(this, callSite, i);
                                        UpdateSlot.call(this, registrationKey);
                                    }
                                }
                            }
                        }
                        callSitesByIndex.Sort$3(new ($.$spc.System.Comparison$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))().$ctor(this,  (/**/ a, /**/ b) =>
                        {
                            return $.$spc.System.Int32.CompareTo$1.call(a.Key, b.Key);
                        }));
                        callSites = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [callSitesByIndex.Count], null);
                        for(/*var*/ let i = 0; i < callSites.length; ++i)
                        {
                            $.$spc.System.Array.$WriteT1.call(callSites, callSitesByIndex.get_Item(i).Value, i);
                        }
                        /*void*/  function AddCallSite(/*ServiceCallSite*/ callSite, /*int*/ index)
                        {
                            cacheLocation = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.GetCommonCacheLocation(cacheLocation, callSite.Cache.Location);
                            callSitesByIndex.Add(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.Int32, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$2(index, callSite));
                        }
                        /*int*/  function GetSlot(/*ServiceIdentifier*/ key)
                        {
                            if (!isAnyKeyLookup)
                            {
                                return slot;
                            }
                            if (keyedSlotAssignment === null)
                            {
                                keyedSlotAssignment = (() =>
                                {
                                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$spc.System.Int32)()
                                    const $t3 = $.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$spc.System.Int32);
                                    const $i3 = new $t3();
                                    $i3.$ctor$2(this._descriptors.length);
                                    $i3.Add(key, 0);
                                    return $i3;
                                })();
                                return 0;
                            }
                            /*int*/ let existingSlot;
                            if (keyedSlotAssignment.TryGetValue(key, $.$ref(() => existingSlot, ($v) => existingSlot = $v, $.$spc.System.Int32)))
                            {
                                return existingSlot;
                            }
                            keyedSlotAssignment.Add(key, 0);
                            return 0;
                        }
                        /*void*/  function UpdateSlot(/*ServiceIdentifier*/ key)
                        {
                            if (!isAnyKeyLookup)
                            {
                                slot++;
                            }
                            else 
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(keyedSlotAssignment === null), "keyedSlotAssignment is not null");
                                keyedSlotAssignment.set_Item(key, ((slot + 1) | 0));
                            }
                        }
                    }
                    /*ResultCache*/ let resultCache = (cacheLocation === 1/*CallSiteResultCacheLocation.Scope*/ || cacheLocation === 0/*CallSiteResultCacheLocation.Root*/) ? new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$2(cacheLocation, callSiteKey) : new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$2(3/*CallSiteResultCacheLocation.None*/, callSiteKey);
                    let $t3;
                    return this._callSiteCache.set_Item(callSiteKey, $t3 = (new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite().$ctor$2(resultCache.Clone(), itemType, callSites, serviceIdentifier.ServiceKey))), $t3;
                }
                finally
                {
                    {
                        callSiteChain.Remove(serviceIdentifier);
                    }
                }
                /*static bool*/  function KeysMatch(/*object?*/ lookupKey, /*object?*/ descriptorKey)
                {
                    if (lookupKey === null && descriptorKey === null)
                    {
                        return true;
                    }
                    if (lookupKey !== null && descriptorKey !== null)
                    {
                        if ($.$spc.System.Object.Equals.call(descriptorKey, $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey))
                        {
                            return false;
                        }
                        return $.$spc.System.Object.Equals.call(lookupKey, descriptorKey) || $.$spc.System.Object.Equals.call(lookupKey, $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey);
                    }
                    return false;
                }
            }
            static /*CallSiteResultCacheLocation */ GetCommonCacheLocation(/*CallSiteResultCacheLocation*/ locationA, /*CallSiteResultCacheLocation*/ locationB)
            {
                return $.$cast($.$spc.System.Math.Max$4(locationA, locationB), $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation);
            }
            /*ServiceCallSite? */ TryCreateExact$1(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot)
            {
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateExact(descriptor.ServiceType, serviceIdentifier.ServiceType))
                {
                    return this.CreateExact(descriptor, serviceIdentifier, callSiteChain, slot);
                }
                return null;
            }
            static /*bool */ ShouldCreateExact(/*Type*/ descriptorType, /*Type*/ serviceType)
            {
                return $.$spc.System.Type.op_Equality$1(descriptorType, serviceType);
            }
            /*ServiceCallSite */ CreateExact(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot)
            {
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, slot);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                /*ServiceCallSite*/ let callSite;
                /*var*/ let lifetime = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$3(descriptor.Lifetime, serviceIdentifier, slot);
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationInstance(descriptor))
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(descriptor.ServiceType, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(descriptor), descriptor.ServiceKey);
                }
                else if (!descriptor.IsKeyedService && descriptor.ImplementationFactory !== null)
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite().$ctor$2(lifetime.Clone(), descriptor.ServiceType, descriptor.ImplementationFactory);
                }
                else if (descriptor.IsKeyedService && descriptor.KeyedImplementationFactory !== null)
                {
                    callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite().$ctor$3(lifetime.Clone(), descriptor.ServiceType, serviceIdentifier.ServiceKey, descriptor.KeyedImplementationFactory);
                }
                else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationType(descriptor))
                {
                    callSite = this.CreateConstructorCallSite(lifetime.Clone(), serviceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor), callSiteChain);
                }
                else 
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.InvalidServiceDescriptor);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(callSite !== null, "callSite != null");
                let $t2;
                return this._callSiteCache.set_Item(callSiteKey, $t2 = (callSite)), $t2;
            }
            /*ServiceCallSite? */ TryCreateOpenGeneric$1(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot, /*bool*/ throwOnConstraintViolation)
            {
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ShouldCreateOpenGeneric(descriptor.ServiceType, serviceIdentifier.ServiceType))
                {
                    return this.CreateOpenGeneric(descriptor, serviceIdentifier, callSiteChain, slot, throwOnConstraintViolation);
                }
                return null;
            }
            static /*bool */ ShouldCreateOpenGeneric(/*Type*/ descriptorType, /*Type*/ serviceType)
            {
                return serviceType.IsConstructedGenericType && $.$spc.System.Type.op_Equality$1(serviceType.GetGenericTypeDefinition(), descriptorType);
            }
            /*ServiceCallSite? */ CreateOpenGeneric(/*ServiceDescriptor*/ descriptor, /*ServiceIdentifier*/ serviceIdentifier, /*CallSiteChain*/ callSiteChain, /*int*/ slot, /*bool*/ throwOnConstraintViolation)
            {
                /*ServiceCacheKey*/ let callSiteKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, slot);
                /*ServiceCallSite?*/ let serviceCallSite;
                if (this._callSiteCache.TryGetValue(callSiteKey, $.$ref(() => serviceCallSite, ($v) => serviceCallSite = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite)))
                {
                    return serviceCallSite;
                }
                /*Type?*/ let implementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor);
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(implementationType, null), "descriptor.ImplementationType != null");
                /*var*/ let lifetime = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$3(descriptor.Lifetime, serviceIdentifier, slot);
                /*Type*/ let closedType;
                try
                {
                    /*Type[]*/ let genericTypeArguments = serviceIdentifier.ServiceType.GenericTypeArguments;
                    if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.VerifyOpenGenericAotCompatibility(serviceIdentifier.ServiceType, genericTypeArguments);
                    }
                    closedType = implementationType.MakeGenericType(genericTypeArguments);
                }
                catch($e)
                {
                    if (throwOnConstraintViolation)
                    {
                        throw $e;
                    }
                    return null;
                }
                /*ConstructorCallSite*/ let site = this.CreateConstructorCallSite(lifetime.Clone(), serviceIdentifier, closedType, callSiteChain);
                $.$spc.System.Diagnostics.Debug.Assert$1(site !== null, "site != null");
                let $t2;
                return this._callSiteCache.set_Item(callSiteKey, $t2 = (site)), $t2;
            }
            /*ConstructorCallSite */ CreateConstructorCallSite(/*ResultCache*/ lifetime, /*ServiceIdentifier*/ serviceIdentifier, /*Type*/ implementationType, /*CallSiteChain*/ callSiteChain)
            {
                try
                {
                    callSiteChain.Add(serviceIdentifier, implementationType);
                    /*ConstructorInfo[]*/ let constructors = implementationType.GetConstructors();
                    /*ServiceCallSite[]?*/ let parameterCallSites = null;
                    if (constructors.length === 0)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.NoConstructorMatch, implementationType));
                    }
                    else if (constructors.length === 1)
                    {
                        /*ConstructorInfo*/ let $constructor = $.$spc.System.Array.$ReadT1.call(constructors, 0);
                        /*ParameterInfo[]*/ let parameters = $constructor.GetParameters();
                        if (parameters.length === 0)
                        {
                            return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$2(lifetime.Clone(), serviceIdentifier.ServiceType, $constructor, serviceIdentifier.ServiceKey);
                        }
                        parameterCallSites = this.CreateArgumentCallSites(serviceIdentifier, implementationType, callSiteChain, parameters, true);
                        return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$3(lifetime.Clone(), serviceIdentifier.ServiceType, $constructor, parameterCallSites, serviceIdentifier.ServiceKey);
                    }
                    $.$spc.System.Array.Sort$16($.$spc.System.Reflection.ConstructorInfo, constructors, new ($.$spc.System.Comparison$$($.$spc.System.Reflection.ConstructorInfo))().$ctor(this,  (/**/ a, /**/ b) =>
                    {
                        return $.$spc.System.Int32.CompareTo$1.call(b.GetParameters().length, a.GetParameters().length);
                    }));
                    /*ConstructorInfo?*/ let bestConstructor = null;
                    /*HashSet<Type>?*/ let bestConstructorParameterTypes = null;
                    for(/*int*/ let i = 0; i < constructors.length; i++)
                    {
                        /*ParameterInfo[]*/ let parameters = $.$spc.System.Array.$ReadT1.call(constructors, i).GetParameters();
                        /*ServiceCallSite[]?*/ let currentParameterCallSites = this.CreateArgumentCallSites(serviceIdentifier, implementationType, callSiteChain, parameters, false);
                        if (currentParameterCallSites !== null)
                        {
                            if ($.$spc.System.Reflection.ConstructorInfo.op_Equality$2(bestConstructor, null))
                            {
                                bestConstructor = $.$spc.System.Array.$ReadT1.call(constructors, i);
                                parameterCallSites = currentParameterCallSites;
                            }
                            else 
                            {
                                if (bestConstructorParameterTypes === null)
                                {
                                    bestConstructorParameterTypes = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.Type))().$ctor$1();
                                    let $i1 = 0;
                                    let $arr1 = bestConstructor.GetParameters();
                                    while ($i1 < $arr1.length)
                                    {
                                        let p = $arr1[$i1++];
                                        bestConstructorParameterTypes.Add(p.ParameterType);
                                    }
                                }
                                let $i1 = 0;
                                let $arr1 = parameters;
                                while ($i1 < $arr1.length)
                                {
                                    let p = $arr1[$i1++];
                                    if (!bestConstructorParameterTypes.Contains(p.ParameterType))
                                    {
                                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$spc.System.String.Join$10($.$spc.System.Environment.NewLine, $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ $.$med.System.SR.Format($.$med.System.SR.AmbiguousConstructorException, implementationType), bestConstructor, $.$spc.System.Array.$ReadT1.call(constructors, i) ])));
                                    }
                                }
                            }
                        }
                    }
                    if ($.$spc.System.Reflection.ConstructorInfo.op_Equality$2(bestConstructor, null))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.UnableToActivateTypeException, implementationType));
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(parameterCallSites !== null, "parameterCallSites != null");
                        return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite().$ctor$3(lifetime.Clone(), serviceIdentifier.ServiceType, bestConstructor, parameterCallSites, serviceIdentifier.ServiceKey);
                    }
                }
                finally
                {
                    {
                        callSiteChain.Remove(serviceIdentifier);
                    }
                }
            }
            /*ServiceCallSite[]? */ CreateArgumentCallSites(/*ServiceIdentifier*/ serviceIdentifier, /*Type*/ implementationType, /*CallSiteChain*/ callSiteChain, /*ParameterInfo[]*/ parameters, /*bool*/ throwIfCallSiteNotFound)
            {
                /*var*/ let parameterCallSites = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), null, [parameters.length], null);
                for(/*int*/ let index = 0; index < parameters.length; index++)
                {
                    /*ServiceCallSite?*/ let callSite = null;
                    /*bool*/ let isKeyedParameter = false;
                    /*Type*/ let parameterType = $.$spc.System.Array.$ReadT1.call(parameters, index).ParameterType;
                    let $i1 = 0;
                    let $arr1 = $.$spc.System.Array.$ReadT1.call(parameters, index).GetCustomAttributes(true);
                    while ($i1 < $arr1.length)
                    {
                        let attribute = $arr1[$i1++];
                        if (serviceIdentifier.ServiceKey !== null && $.$is(attribute, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceKeyAttribute))
                        {
                            if (serviceIdentifier.ServiceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                            {
                                parameterType = $.$spc.System.Object.$type;
                            }
                            else if ($.$spc.System.Type.op_Inequality$1(parameterType, $.$spc.System.Object.GetType.call(serviceIdentifier.ServiceKey)) && $.$spc.System.Type.op_Inequality$1(parameterType, $.$spc.System.Object.$type))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.InvalidServiceKeyType);
                            }
                            callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(parameterType, serviceIdentifier.ServiceKey, null);
                            break;
                        }
                        let fromKeyedServicesAttribute;
                        if ($.$is(attribute, $.$mxdi.Microsoft.Extensions.DependencyInjection.FromKeyedServicesAttribute, { set $v(v){ fromKeyedServicesAttribute = v; } }))
                        {
                            /*object?*/ let serviceKey = (() =>
                            {
                                let $switch2 = fromKeyedServicesAttribute.LookupMode;
                                if ($switch2 === 0/*ServiceKeyLookupMode.InheritKey*/)
                                {
                                    return serviceIdentifier.ServiceKey;
                                }
                                if ($switch2 === 2/*ServiceKeyLookupMode.ExplicitKey*/)
                                {
                                    return fromKeyedServicesAttribute.Key;
                                }
                                if ($switch2 === 1/*ServiceKeyLookupMode.NullKey*/)
                                {
                                    return null;
                                }
                                return null;
                            })();
                            if (!(serviceKey === null))
                            {
                                callSite = this.GetCallSite(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceKey, parameterType), callSiteChain);
                                isKeyedParameter = true;
                                break;
                            }
                        }
                    }
                    if (!isKeyedParameter)
                    {
                        callSite ??= this.GetCallSite($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(parameterType), callSiteChain);
                    }
                    /*object?*/ let defaultValue;
                    if (callSite === null && $.$med.Microsoft.Extensions.Internal.ParameterDefaultValue.TryGetDefaultValue($.$spc.System.Array.$ReadT1.call(parameters, index), $.$ref(() => defaultValue, ($v) => defaultValue = $v, $.$spc.System.Object)))
                    {
                        callSite = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2(parameterType, defaultValue, null);
                    }
                    if (callSite === null)
                    {
                        if (throwIfCallSiteNotFound)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.CannotResolveService, parameterType, implementationType));
                        }
                        return null;
                    }
                    $.$spc.System.Array.$WriteT1.call(parameterCallSites, callSite, index);
                }
                return parameterCallSites;
            }
            static /*void */ VerifyOpenGenericAotCompatibility(/*Type*/ serviceType, /*Type[]*/ genericTypeArguments)
            {
                let $i1 = 0;
                let $arr1 = genericTypeArguments;
                while ($i1 < $arr1.length)
                {
                    let typeArg = $arr1[$i1++];
                    if (typeArg.IsValueType)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.AotCannotCreateGenericValueType, serviceType, typeArg));
                    }
                }
            }
            /*void */ Add(/*ServiceIdentifier*/ serviceIdentifier, /*ServiceCallSite*/ serviceCallSite)
            {
                this._callSiteCache.set_Item(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, 0/*DefaultSlot*/), serviceCallSite);
            }
            /*bool */ IsService(/*Type*/ serviceType)
            {
                return this.IsService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(null, serviceType));
            }
            /*bool */ IsKeyedService(/*Type*/ serviceType, /*object?*/ key)
            {
                return this.IsService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(key, serviceType));
            }
            /*bool */ IsService$1(/*ServiceIdentifier*/ serviceIdentifier)
            {
                /*var*/ let serviceType = serviceIdentifier.ServiceType;
                $.$spc.System.ArgumentNullException.ThrowIfNull(serviceType, "serviceType");
                if (serviceType.IsGenericTypeDefinition)
                {
                    return false;
                }
                if (this._descriptorLookup.ContainsKey(serviceIdentifier))
                {
                    return true;
                }
                if (serviceIdentifier.ServiceKey !== null && this._descriptorLookup.ContainsKey(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3($.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey, serviceType)))
                {
                    return true;
                }
                let genericDefinition;
                if (serviceType.IsConstructedGenericType && $.$is(serviceType.GetGenericTypeDefinition(), $.$spc.System.Type, { set $v(v){ genericDefinition = v; } }))
                {
                    return $.$spc.System.Type.op_Equality$1(genericDefinition, $.$spc.System.Collections.Generic.IEnumerable$$().$type) || this._descriptorLookup.ContainsKey(serviceIdentifier.GetGenericTypeDefinition());
                }
                return $.$spc.System.Type.op_Equality$1(serviceType, $.$scm.System.IServiceProvider.$type) || $.$spc.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type) || $.$spc.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type) || $.$spc.System.Type.op_Equality$1(serviceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type);
            }
            static $_ServiceDescriptorCacheItem;
            static get ServiceDescriptorCacheItem()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory;
                return $cls.$_ServiceDescriptorCacheItem ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem", ($self) => class ServiceDescriptorCacheItem extends $.$spc.System.ValueType
                {
                    /*ServiceDescriptor?*/  get _item() { return this.$getField(0, 4); }
                    /*ServiceDescriptor?*/  set _item(value) { this.$setField(0, 4, value); }
                    /*List<ServiceDescriptor>?*/  get _items() { return this.$getField(4, 4); }
                    /*List<ServiceDescriptor>?*/  set _items(value) { this.$setField(4, 4, value); }
                    /*ServiceDescriptor */ get Last()
                    {
                        if (this._items !== null && this._items.Count > 0)
                        {
                            return this._items.get_Item(((this._items.Count - 1) | 0));
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._item !== null, "_item != null");
                        return this._item;
                    }
                    /*int */ get Count()
                    {
                        if (this._item === null)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._items === null, "_items == null");
                            return 0;
                        }
                        return ((1 + ((this._items?.Count ?? null) ?? 0)) | 0);
                    }
                    /*ServiceDescriptor*/ get_Item(/*int*/ index)
                    {
                        if (index >= this.Count)
                        {
                            throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("index");
                        }
                        if (index === 0)
                        {
                            return this._item;
                        }
                        return this._items.get_Item(((index - 1) | 0));
                    }
                    /*int */ GetSlot(/*ServiceDescriptor*/ descriptor)
                    {
                        if (descriptor === this._item)
                        {
                            return ((this.Count - 1) | 0);
                        }
                        if (this._items !== null)
                        {
                            /*int*/ let index = this._items.IndexOf(descriptor);
                            if (index !== -1)
                            {
                                return ((this._items.Count - (((index + 1) | 0))) | 0);
                            }
                        }
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.ServiceDescriptorNotExist);
                    }
                    /*ServiceDescriptorCacheItem */ Add(/*ServiceDescriptor*/ descriptor)
                    {
                        /*var*/ let newCacheItem = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem);
                        if (this._item === null)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._items === null, "_items == null");
                            newCacheItem._item = descriptor;
                        }
                        else 
                        {
                            newCacheItem._item = this._item;
                            newCacheItem._items = this._items ?? new ($.$spc.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor))().$ctor$1();
                            newCacheItem._items.Add(descriptor);
                        }
                        return newCacheItem;
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._item = this._item;
                        copy._items = this._items;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._item = null;
                        this._items = null;
                    }
                    static $h = 786436;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1638403,"g":{"r":0,"d":0,"h":17180655620,"f":1},"n":"Last","d":786436,"h":12885688324,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770590212,"f":1},"n":"Count","d":786436,"h":21475622916,"f":1},{"p":1638403,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34360524804,"f":1},"n":"Item","o":"@$2","d":786436,"h":30065557508,"f":1}],"m":[{"r":655361,"p":[{"n":"descriptor","p":1638403}],"n":"GetSlot","d":786436,"h":38655492100,"f":1},{"r":786436,"p":[{"n":"descriptor","p":1638403}],"n":"Add","d":786436,"h":42950459396,"f":1}],"l":[{"t":1638403,"n":"_item","d":786436,"h":4295753732,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h,"n":"_items","d":786436,"h":8590721028,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":786436,"h":47245426692,"f":1}],"d":720900,"h":786436}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem`; }
                }, $cls, ($v) => $cls.$_ServiceDescriptorCacheItem = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.IsKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IServiceProviderIsKeyedService$IsKeyedService()
            {
                return this.IsKeyedService(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.IsService(System.Type)
            Microsoft$Extensions$DependencyInjection$IServiceProviderIsService$IsService()
            {
                return this.IsService(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._callSiteCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$1();
                this._descriptorLookup = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem))().$ctor$1();
                this._callSiteLocks = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$spc.System.Object))().$ctor$1();
            }
            static $h = 720900;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":38655426564,"f":8},"n":"Descriptors","d":720900,"h":34360459268,"f":8}],"m":[{"r":65537,"n":"Populate","d":720900,"h":42950393860,"f":2},{"r":65537,"p":[{"n":"serviceType","p":142606337},{"n":"serviceTypeGenericArguments","p":0},{"n":"implementationType","p":142606337},{"n":"implementationTypeGenericArguments","p":0}],"n":"ValidateTrimmingAnnotations","d":720900,"h":47245361156,"f":34},{"r":35848193,"p":[{"n":"serviceGenericType","p":142606337}],"n":"GetDynamicallyAccessedMemberTypes","d":720900,"h":51540328452,"f":34},{"r":262145,"p":[{"n":"serviceDynamicallyAccessedMembers","p":35848193},{"n":"implementationDynamicallyAccessedMembers","p":35848193}],"n":"AreCompatible","d":720900,"h":55835295748,"f":34},{"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"GetSlot","d":720900,"h":60130263044,"f":8},{"r":2424836,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828}],"n":"GetCallSite","d":720900,"h":64425230340,"f":8},{"r":2424836,"p":[{"n":"serviceDescriptor","p":1638403},{"n":"callSiteChain","p":589828}],"n":"GetCallSite","o":"@$1","d":720900,"h":68720197636,"f":8},{"r":2424836,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828}],"n":"CreateCallSite","d":720900,"h":73015164932,"f":2},{"r":2424836,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828}],"n":"TryCreateExact","d":720900,"h":77310132228,"f":2},{"r":2424836,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828}],"n":"TryCreateOpenGeneric","d":720900,"h":81605099524,"f":2},{"r":2424836,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828}],"n":"TryCreateEnumerable","d":720900,"h":85900066820,"f":2},{"r":917508,"p":[{"n":"locationA","p":917508},{"n":"locationB","p":917508}],"n":"GetCommonCacheLocation","d":720900,"h":90195034116,"f":34},{"r":2424836,"p":[{"n":"descriptor","p":1638403},{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828},{"n":"slot","p":655361}],"n":"TryCreateExact","o":"@$1","d":720900,"h":94490001412,"f":2},{"r":262145,"p":[{"n":"descriptorType","p":142606337},{"n":"serviceType","p":142606337}],"n":"ShouldCreateExact","d":720900,"h":98784968708,"f":34},{"r":2424836,"p":[{"n":"descriptor","p":1638403},{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828},{"n":"slot","p":655361}],"n":"CreateExact","d":720900,"h":103079936004,"f":2},{"r":2424836,"p":[{"n":"descriptor","p":1638403},{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828},{"n":"slot","p":655361},{"n":"throwOnConstraintViolation","p":262145}],"n":"TryCreateOpenGeneric","o":"@$1","d":720900,"h":107374903300,"f":2},{"r":262145,"p":[{"n":"descriptorType","p":142606337},{"n":"serviceType","p":142606337}],"n":"ShouldCreateOpenGeneric","d":720900,"h":111669870596,"f":34},{"r":2424836,"p":[{"n":"descriptor","p":1638403},{"n":"serviceIdentifier","p":2555908},{"n":"callSiteChain","p":589828},{"n":"slot","p":655361},{"n":"throwOnConstraintViolation","p":262145}],"n":"CreateOpenGeneric","d":720900,"h":115964837892,"f":2},{"r":1376260,"p":[{"n":"lifetime","p":2097156},{"n":"serviceIdentifier","p":2555908},{"n":"implementationType","p":142606337},{"n":"callSiteChain","p":589828}],"n":"CreateConstructorCallSite","d":720900,"h":120259805188,"f":2},{"r":0,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"implementationType","p":142606337},{"n":"callSiteChain","p":589828},{"n":"parameters","p":0},{"n":"throwIfCallSiteNotFound","p":262145}],"n":"CreateArgumentCallSites","d":720900,"h":124554772484,"f":2},{"r":65537,"p":[{"n":"serviceType","p":142606337},{"n":"genericTypeArguments","p":0}],"n":"VerifyOpenGenericAotCompatibility","d":720900,"h":128849739780,"f":34},{"r":65537,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"serviceCallSite","p":2424836}],"n":"Add","d":720900,"h":133144707076,"f":1},{"r":262145,"p":[{"n":"serviceType","p":142606337}],"n":"IsService","d":720900,"h":137439674372,"f":1},{"r":262145,"p":[{"n":"serviceType","p":142606337},{"n":"key","p":131073}],"n":"IsKeyedService","d":720900,"h":141734641668,"f":1},{"r":262145,"p":[{"n":"serviceIdentifier","p":2555908}],"n":"IsService","o":"@$1","d":720900,"h":146029608964,"f":8}],"l":[{"t":655361,"n":"DefaultSlot","d":720900,"h":4295688196,"f":34},{"t":0,"n":"_descriptors","d":720900,"h":8590655492,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,"n":"_callSiteCache","d":720900,"h":12885622788,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory.ServiceDescriptorCacheItem).$h,"n":"_descriptorLookup","d":720900,"h":17180590084,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$spc.System.Object).$h,"n":"_callSiteLocks","d":720900,"h":21475557380,"f":2},{"t":2883588,"n":"_stackGuard","d":720900,"h":25770524676,"f":2}],"c":[{"p":[{"n":"descriptors","p":$.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h}],"n":".ctor","o":"$ctor$1","d":720900,"h":30065491972,"f":1}],"i":[917507,983043],"j":[786436],"h":720900}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceProvider", ($self) => class ServiceProvider extends $.$spc.System.Object
        {
            /*CallSiteValidator?*/ _callSiteValidator = null;
            /*Func<ServiceIdentifier, ServiceAccessor>*/ _createServiceAccessor = null;
            /*ServiceProviderEngine*/ _engine = null;
            /*bool*/ _disposed = false;
            /*ConcurrentDictionary<ServiceIdentifier, ServiceAccessor>*/ _serviceAccessors = null;
            /*CallSiteFactory*/ CallSiteFactory = null;
            /*ServiceProviderEngineScope*/ Root = null;
            /*bool*/ static VerifyOpenGenericServiceTrimmability = false;
            /*bool*/ static DisableDynamicEngine = false;
            static /*bool */ get VerifyAotCompatibility()
            {
                return !$.$spc.System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported;
            }
            $ctor$1(/*ICollection<ServiceDescriptor>*/ serviceDescriptors, /*ServiceProviderOptions*/ options)
            {
                super.$ctor();
                {
                    this.Root = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope().$ctor$1(this, true);
                    this._engine = this.GetEngine();
                    this._createServiceAccessor = new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor))().$ctor(this, this.CreateServiceAccessor);
                    this._serviceAccessors = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor))().$ctor$1();
                    this.CallSiteFactory = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteFactory().$ctor$1(serviceDescriptors);
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$scm.System.IServiceProvider.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite().$ctor$2());
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type, this.Root, null));
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsService.$type, this.CallSiteFactory, null));
                    this.CallSiteFactory.Add($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type), new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite().$ctor$2($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderIsKeyedService.$type, this.CallSiteFactory, null));
                    if (options.ValidateScopes)
                    {
                        this._callSiteValidator = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator().$ctor$2();
                    }
                    if (options.ValidateOnBuild)
                    {
                        /*List<Exception>?*/ let exceptions = null;
                        var $en4 = serviceDescriptors.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var serviceDescriptor = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                try
                                {
                                    this.ValidateService(serviceDescriptor);
                                }
                                catch(e)
                                {
                                    exceptions ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                                    exceptions.Add(e);
                                }
                            }
                        }
                        if (exceptions !== null)
                        {
                            throw new $.$spc.System.AggregateException().$ctor$11("Some services are not able to be constructed", exceptions.ToArray());
                        }
                    }
                    $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceProviderBuilt$1(this);
                }
                return this;
            }
            /*object? */ GetService(/*Type*/ serviceType)
            {
                return this.GetService$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), this.Root);
            }
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                return this.GetKeyedService$1(serviceType, serviceKey, this.Root);
            }
            /*object? */ GetKeyedService$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                if (serviceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                {
                    if (!serviceType.IsGenericType || $.$spc.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService();
                    }
                }
                return this.GetService$1(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceKey, serviceType), serviceProviderEngineScope);
            }
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                if (serviceKey === $.$mxdi.Microsoft.Extensions.DependencyInjection.KeyedService.AnyKey)
                {
                    if (!serviceType.IsGenericType || $.$spc.System.Type.op_Inequality$1(serviceType.GetGenericTypeDefinition(), $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_KeyedServiceAnyKeyUsedToResolveService();
                    }
                }
                return this.GetRequiredKeyedService$1(serviceType, serviceKey, this.Root);
            }
            /*object */ GetRequiredKeyedService$1(/*Type*/ serviceType, /*object?*/ serviceKey, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                /*object?*/ let service = this.GetKeyedService$1(serviceType, serviceKey, serviceProviderEngineScope);
                if (service === null)
                {
                    if (serviceKey === null)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_NoServiceRegistered(serviceType);
                    }
                    else 
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowInvalidOperationException_NoKeyedServiceRegistered(serviceType, $.$spc.System.Object.GetType.call(serviceKey));
                    }
                }
                return service;
            }
            /*bool */ IsDisposed()
            {
                return this._disposed;
            }
            /*void */ Dispose()
            {
                this.DisposeCore();
                this.Root.Dispose();
            }
            /*ValueTask */ DisposeAsync()
            {
                this.DisposeCore();
                return this.Root.DisposeAsync();
            }
            /*void */ DisposeCore()
            {
                this._disposed = true;
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceProviderDisposed(this);
            }
            /*void */ OnCreate(/*ServiceCallSite*/ callSite)
            {
                this._callSiteValidator?.ValidateCallSite(callSite);
            }
            /*void */ OnResolve(/*ServiceCallSite?*/ callSite, /*IServiceScope*/ scope)
            {
                if (callSite !== null)
                {
                    this._callSiteValidator?.ValidateResolution(callSite, scope, this.Root);
                }
            }
            /*object? */ GetService$1(/*ServiceIdentifier*/ serviceIdentifier, /*ServiceProviderEngineScope*/ serviceProviderEngineScope)
            {
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                /*ServiceAccessor*/ let serviceAccessor = this._serviceAccessors.GetOrAdd(serviceIdentifier, this._createServiceAccessor);
                this.OnResolve(serviceAccessor.CallSite, serviceProviderEngineScope);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceResolved$1(this, serviceIdentifier.ServiceType);
                /*object?*/ let result = (serviceAccessor.RealizedService?.Invoke(serviceProviderEngineScope) ?? null);
                $.$spc.System.Diagnostics.Debug.Assert$1(result === null || this.CallSiteFactory.IsService$1(serviceIdentifier), "result is null || CallSiteFactory.IsService(serviceIdentifier)");
                return result;
            }
            /*void */ ValidateService(/*ServiceDescriptor*/ descriptor)
            {
                if (descriptor.ServiceType.IsGenericType && !descriptor.ServiceType.IsConstructedGenericType)
                {
                    return;
                }
                try
                {
                    /*ServiceCallSite?*/ let callSite = this.CallSiteFactory.GetCallSite$1(descriptor, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain().$ctor$1());
                    if (callSite !== null)
                    {
                        this.OnCreate(callSite);
                    }
                }
                catch(e)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$11(`Error while validating the service descriptor '${$.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.ToString.call(descriptor)}': ${e.Message}`, e);
                }
            }
            /*ServiceAccessor */ CreateServiceAccessor(/*ServiceIdentifier*/ serviceIdentifier)
            {
                /*ServiceCallSite?*/ let callSite = this.CallSiteFactory.GetCallSite(serviceIdentifier, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteChain().$ctor$1());
                if (callSite !== null)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.CallSiteBuilt$1(this, serviceIdentifier.ServiceType, callSite);
                    this.OnCreate(callSite);
                    if (callSite.Cache.Location === 0/*CallSiteResultCacheLocation.Root*/)
                    {
                        /*object?*/ let value = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, this.Root);
                        return (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                            const $i1 = new $t1();
                            $i1.CallSite = callSite;
                            $i1.RealizedService = new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object))().$ctor(this,  (/*scope*/ scope) =>
                            {
                                return value;
                            });
                            return $i1;
                        })();
                    }
                    /*Func<ServiceProviderEngineScope, object?>*/ let realizedService = this._engine.RealizeService(callSite);
                    return (() =>
                    {
                        //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                        const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                        const $i1 = new $t1();
                        $i1.CallSite = callSite;
                        $i1.RealizedService = realizedService;
                        return $i1;
                    })();
                }
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                    const $i1 = new $t1();
                    $i1.CallSite = callSite;
                    $i1.RealizedService = new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return null;
                    });
                    return $i1;
                })();
            }
            /*void */ ReplaceServiceAccessor(/*ServiceCallSite*/ callSite, /*Func<ServiceProviderEngineScope, object?>*/ accessor)
            {
                this._serviceAccessors.set_Item(new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(callSite.Key, callSite.ServiceType), (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor;
                    const $i1 = new $t1();
                    $i1.CallSite = callSite;
                    $i1.RealizedService = accessor;
                    return $i1;
                })());
            }
            /*IServiceScope */ CreateScope()
            {
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope().$ctor$1(this, false);
            }
            /*ServiceProviderEngine */ GetEngine()
            {
                /*ServiceProviderEngine*/ let engine;
                //if (RuntimeFeature.IsDynamicCodeCompiled && !DisableDynamicEngine) { ... }
                //else 
                {
                    engine = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine.Instance;
                }
                return engine;
                /*ServiceProviderEngine*/  function CreateDynamicEngine()
                {
                    return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine().$ctor$3(this);
                }
            }
            /*string */ DebuggerToString()
            {
                return this.Root.DebuggerToString();
            }
            static $_ServiceAccessor;
            static get ServiceAccessor()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider;
                return $cls.$_ServiceAccessor ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor", ($self) => class ServiceAccessor extends $.$spc.System.Object
                {
                    /*ServiceCallSite?*/ CallSite = null;
                    /*Func<ServiceProviderEngineScope, object?>?*/ RealizedService = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3080196;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2424836,"g":{"r":0,"d":0,"h":12887982084,"f":1},"s":{"r":0,"d":0,"h":17182949380,"f":1},"n":"CallSite","d":3080196,"h":8593014788,"f":1},{"p":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":30067851268,"f":1},"s":{"r":0,"d":0,"h":34362818564,"f":1},"n":"RealizedService","d":3080196,"h":25772883972,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":3080196,"h":38657785860,"f":1}],"d":3014660,"h":3080196}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor`; }
                }, $cls, ($v) => $cls.$_ServiceAccessor = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService()
            {
                return this.GetKeyedService(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                return this.GetRequiredKeyedService(...arguments);
            }
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                return this.GetService(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let verifyOpenGenerics;
                    this.VerifyOpenGenericServiceTrimmability = $.$spc.System.AppContext.TryGetSwitch("Microsoft.Extensions.DependencyInjection.VerifyOpenGenericServiceTrimmability", $.$ref(() => verifyOpenGenerics, ($v) => verifyOpenGenerics = $v, $.$spc.System.Boolean)) ? verifyOpenGenerics : false;
                }
                {
                    /*bool*/ let disableDynamicEngine;
                    this.DisableDynamicEngine = $.$spc.System.AppContext.TryGetSwitch("Microsoft.Extensions.DependencyInjection.DisableDynamicEngine", $.$ref(() => disableDynamicEngine, ($v) => disableDynamicEngine = $v, $.$spc.System.Boolean)) ? disableDynamicEngine : false;
                }
            }
            static $h = 3014660;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":720900,"g":{"r":0,"d":0,"h":34362753028,"f":8},"n":"CallSiteFactory","d":3014660,"h":30067785732,"f":8},{"p":2818052,"g":{"r":0,"d":0,"h":47247654916,"f":8},"n":"Root","d":3014660,"h":42952687620,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":60132556804,"f":40},"n":"VerifyOpenGenericServiceTrimmability","d":3014660,"h":55837589508,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":73017458692,"f":40},"n":"DisableDynamicEngine","d":3014660,"h":68722491396,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":81607393284,"f":40},"n":"VerifyAotCompatibility","d":3014660,"h":77312425988,"f":40}],"m":[{"r":131073,"p":[{"n":"serviceType","p":142606337}],"n":"GetService","d":3014660,"h":90197327876,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedService","d":3014660,"h":94492295172,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"serviceProviderEngineScope","p":2818052}],"n":"GetKeyedService","o":"@$1","d":3014660,"h":98787262468,"f":8},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetRequiredKeyedService","d":3014660,"h":103082229764,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"serviceProviderEngineScope","p":2818052}],"n":"GetRequiredKeyedService","o":"@$1","d":3014660,"h":107377197060,"f":8},{"r":262145,"n":"IsDisposed","d":3014660,"h":111672164356,"f":8},{"r":65537,"n":"Dispose","d":3014660,"h":115967131652,"f":1},{"r":136118273,"n":"DisposeAsync","d":3014660,"h":120262098948,"f":1},{"r":65537,"n":"DisposeCore","d":3014660,"h":124557066244,"f":2},{"r":65537,"p":[{"n":"callSite","p":2424836}],"n":"OnCreate","d":3014660,"h":128852033540,"f":2},{"r":65537,"p":[{"n":"callSite","p":2424836},{"n":"scope","p":1048579}],"n":"OnResolve","d":3014660,"h":133147000836,"f":2},{"r":131073,"p":[{"n":"serviceIdentifier","p":2555908},{"n":"serviceProviderEngineScope","p":2818052}],"n":"GetService","o":"@$1","d":3014660,"h":137441968132,"f":8},{"r":65537,"p":[{"n":"descriptor","p":1638403}],"n":"ValidateService","d":3014660,"h":141736935428,"f":2},{"r":3080196,"p":[{"n":"serviceIdentifier","p":2555908}],"n":"CreateServiceAccessor","d":3014660,"h":146031902724,"f":2},{"r":65537,"p":[{"n":"callSite","p":2424836},{"n":"accessor","p":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h}],"n":"ReplaceServiceAccessor","d":3014660,"h":150326870020,"f":8},{"r":1048579,"n":"CreateScope","d":3014660,"h":154621837316,"f":8},{"r":2752516,"n":"GetEngine","d":3014660,"h":158916804612,"f":2},{"r":1310721,"n":"DebuggerToString","d":3014660,"h":163211771908,"f":2}],"l":[{"t":1048580,"n":"_callSiteValidator","d":3014660,"h":4297981956,"f":2},{"t":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor).$h,"n":"_createServiceAccessor","d":3014660,"h":8592949252,"f":2},{"t":2752516,"n":"_engine","d":3014660,"h":12887916548,"f":8},{"t":262145,"n":"_disposed","d":3014660,"h":17182883844,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.ServiceAccessor).$h,"n":"_serviceAccessors","d":3014660,"h":21477851140,"f":2}],"c":[{"p":[{"n":"serviceDescriptors","p":$.$spc.System.Collections.Generic.ICollection$$($.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor).$h},{"n":"options","p":3145732}],"n":".ctor","o":"$ctor$1","d":3014660,"h":85902360580,"f":8}],"i":[720899,327717,57475073,56885249],"j":[3080196],"h":3014660,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, $.$scm.System.IServiceProvider, $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceProvider`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope", ($self) => class ServiceProviderEngineScope extends $.$spc.System.Object
        {
            /*IList<object> */ get Disposables()
            {
                return this._disposables ?? $.$spc.System.Array.Empty($.$spc.System.Object);
            }
            /*bool*/ _disposed = false;
            /*List<object>?*/ _disposables = null;
            $ctor$1(/*ServiceProvider*/ provider, /*bool*/ isRootScope)
            {
                super.$ctor();
                {
                    this.ResolvedServices = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object))().$ctor$1();
                    this.RootProvider = provider;
                    this.IsRootScope = isRootScope;
                }
                return this;
            }
            /*Dictionary<ServiceCacheKey, object?>*/ ResolvedServices = null;
            /*bool */ get Disposed()
            {
                return this._disposed;
            }
            /*object */ get Sync()
            {
                return this.ResolvedServices;
            }
            /*bool*/ IsRootScope = false;
            /*ServiceProvider*/ RootProvider = null;
            /*object? */ GetService(/*Type*/ serviceType)
            {
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetService$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), this);
            }
            /*object? */ GetKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetKeyedService$1(serviceType, serviceKey, this);
            }
            /*object */ GetRequiredKeyedService(/*Type*/ serviceType, /*object?*/ serviceKey)
            {
                if (this._disposed)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return this.RootProvider.GetRequiredKeyedService$1(serviceType, serviceKey, this);
            }
            /*IServiceProvider */ get ServiceProvider()
            {
                return this;
            }
            /*IServiceScope */ CreateScope()
            {
                return this.RootProvider.CreateScope();
            }
            /*object? */ CaptureDisposable(/*object?*/ service)
            {
                if ($.$spc.System.Object.ReferenceEquals(this, service) || !($.$is(service, $.$spc.System.IDisposable) || $.$is(service, $.$spc.System.IAsyncDisposable)))
                {
                    return service;
                }
                /*bool*/ let disposed = false;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.Sync)
                    {
                        if (this._disposed)
                        {
                            disposed = true;
                        }
                        else 
                        {
                            this._disposables ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                            this._disposables.Add(service);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.Sync)
                }
                if (disposed)
                {
                    let disposable;
                    if ($.$is(service, $.$spc.System.IDisposable, { set $v(v){ disposable = v; } }))
                    {
                        disposable.System$IDisposable$Dispose();
                    }
                    else 
                    {
                        /*object?*/ let localService = service;
                        $.$spc.System.Threading.Tasks.Task.Run$4(new ($.$spc.System.Func$$($.$spc.System.Threading.Tasks.Task))().$ctor(this,  () =>
                        {
                            return ($.$cast(localService, $.$spc.System.IAsyncDisposable)).System$IAsyncDisposable$DisposeAsync().AsTask();
                        })).GetAwaiter().GetResult();
                    }
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ThrowHelper.ThrowObjectDisposedException();
                }
                return service;
            }
            /*void */ Dispose()
            {
                /*List<object>?*/ let toDispose = this.BeginDispose();
                if (toDispose !== null)
                {
                    for(/*int*/ let i = ((toDispose.Count - 1) | 0); i >= 0; i--)
                    {
                        let disposable;
                        if ($.$is(toDispose.get_Item(i), $.$spc.System.IDisposable, { set $v(v){ disposable = v; } }))
                        {
                            disposable.System$IDisposable$Dispose();
                        }
                        else 
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format($.$med.System.SR.AsyncDisposableServiceDispose, $.$med.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName(toDispose.get_Item(i), true)));
                        }
                    }
                }
            }
            /*ValueTask */ DisposeAsync()
            {
                /*List<object>?*/ let toDispose = this.BeginDispose();
                if (toDispose !== null)
                {
                    try
                    {
                        for(/*int*/ let i = ((toDispose.Count - 1) | 0); i >= 0; i--)
                        {
                            /*object*/ let disposable = toDispose.get_Item(i);
                            let asyncDisposable;
                            if ($.$is(disposable, $.$spc.System.IAsyncDisposable, { set $v(v){ asyncDisposable = v; } }))
                            {
                                /*ValueTask*/ let vt = asyncDisposable.System$IAsyncDisposable$DisposeAsync();
                                if (!vt.IsCompletedSuccessfully)
                                {
                                    return Await(i, vt, toDispose);
                                }
                                vt.GetAwaiter().GetResult();
                            }
                            else 
                            {
                                ($.$cast(disposable, $.$spc.System.IDisposable)).System$IDisposable$Dispose();
                            }
                        }
                    }
                    catch(ex)
                    {
                        return new $.$spc.System.Threading.Tasks.ValueTask().$ctor$2($.$spc.System.Threading.Tasks.Task.FromException(ex));
                    }
                }
                return new $.$spc.System.Threading.Tasks.ValueTask();
                /*static ValueTask*/ /*async*/  function Await(/*int*/ i, /*ValueTask*/ vt, /*List<object>*/ toDispose)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask, $.$spc.System.Void, async () => 
                    {
                        await vt.ConfigureAwait(false);
                        i--;
                        for(; i >= 0; i--)
                        {
                            /*object*/ let disposable = toDispose.get_Item(i);
                            let asyncDisposable;
                            if ($.$is(disposable, $.$spc.System.IAsyncDisposable, { set $v(v){ asyncDisposable = v; } }))
                            {
                                await asyncDisposable.System$IAsyncDisposable$DisposeAsync().ConfigureAwait(false);
                            }
                            else 
                            {
                                ($.$cast(disposable, $.$spc.System.IDisposable)).System$IDisposable$Dispose();
                            }
                        }
                    });
                }
            }
            /*List<object>? */ BeginDispose()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.Sync)
                    {
                        if (this._disposed)
                        {
                            return null;
                        }
                        $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ScopeDisposed($.$spc.System.Object.GetHashCode.call(this.RootProvider), this.ResolvedServices.Count, (this._disposables?.Count ?? null) ?? 0);
                        this._disposed = true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.Sync)
                }
                if (this.IsRootScope && !this.RootProvider.IsDisposed())
                {
                    this.RootProvider.Dispose();
                }
                return this._disposables;
            }
            /*string */ DebuggerToString()
            {
                /*string*/ let debugText = `ServiceDescriptors = ${this.RootProvider.CallSiteFactory.Descriptors.length}`;
                if (!this.IsRootScope)
                {
                    debugText += `, IsScope = true`;
                }
                if (this._disposed)
                {
                    debugText += `, Disposed = true`;
                }
                return debugText;
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScope.ServiceProvider.get
            get Microsoft$Extensions$DependencyInjection$IServiceScope$ServiceProvider()
            {
                return this.ServiceProvider;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetKeyedService()
            {
                return this.GetKeyedService(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider.GetRequiredKeyedService(System.Type, object?)
            Microsoft$Extensions$DependencyInjection$IKeyedServiceProvider$GetRequiredKeyedService()
            {
                return this.GetRequiredKeyedService(...arguments);
            }
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                return this.GetService(...arguments);
            }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.CreateScope()
            Microsoft$Extensions$DependencyInjection$IServiceScopeFactory$CreateScope()
            {
                return this.CreateScope(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsRootScope = false;
            }
            static $h = 2818052;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":8592752644,"f":8},"n":"Disposables","d":2818052,"h":4297785348,"f":8},{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":34362556420,"f":8},"n":"ResolvedServices","d":2818052,"h":30067589124,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":42952491012,"f":8},"n":"Disposed","d":2818052,"h":38657523716,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":51542425604,"f":8},"n":"Sync","d":2818052,"h":47247458308,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":64427327492,"f":1},"n":"IsRootScope","d":2818052,"h":60132360196,"f":1},{"p":3014660,"g":{"r":0,"d":0,"h":77312229380,"f":8},"n":"RootProvider","d":2818052,"h":73017262084,"f":8},{"p":327717,"g":{"r":0,"d":0,"h":98787065860,"f":1},"n":"ServiceProvider","d":2818052,"h":94492098564,"f":1}],"m":[{"r":131073,"p":[{"n":"serviceType","p":142606337}],"n":"GetService","d":2818052,"h":81607196676,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetKeyedService","d":2818052,"h":85902163972,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073}],"n":"GetRequiredKeyedService","d":2818052,"h":90197131268,"f":1},{"r":1048579,"n":"CreateScope","d":2818052,"h":103082033156,"f":1},{"r":131073,"p":[{"n":"service","p":131073}],"n":"CaptureDisposable","d":2818052,"h":107377000452,"f":8},{"r":65537,"n":"Dispose","d":2818052,"h":111671967748,"f":1},{"r":136118273,"n":"DisposeAsync","d":2818052,"h":115966935044,"f":1},{"r":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h,"n":"BeginDispose","d":2818052,"h":120261902340,"f":2},{"r":1310721,"n":"DebuggerToString","d":2818052,"h":124556869636,"f":8}],"l":[{"t":262145,"n":"_disposed","d":2818052,"h":12887719940,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h,"n":"_disposables","d":2818052,"h":17182687236,"f":2}],"c":[{"p":[{"n":"provider","p":3014660},{"n":"isRootScope","p":262145}],"n":".ctor","o":"$ctor$1","d":2818052,"h":21477654532,"f":1}],"i":[1048579,57475073,720899,327717,56885249,1114115],"h":2818052,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]},{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScope, $.$spc.System.IDisposable, $.$mxdi.Microsoft.Extensions.DependencyInjection.IKeyedServiceProvider, $.$scm.System.IServiceProvider, $.$spc.System.IAsyncDisposable, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite", ($self) => class ConstantCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            /*Type*/ _serviceType = null;
            /*object? */ get DefaultValue()
            {
                return this.Value;
            }
            $ctor$2(/*Type*/ serviceType, /*object?*/ defaultValue, /*object?*/ serviceKey)
            {
                super.$ctor$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache.None(serviceType), serviceKey);
                {
                    this._serviceType = $.$firstOf(serviceType, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("serviceType") });
                    if (defaultValue !== null && !serviceType.IsInstanceOfType(defaultValue))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.ConstantCantBeConvertedToServiceType, $.$spc.System.Object.GetType.call(defaultValue), serviceType));
                    }
                    this.Value = defaultValue;
                }
                return this;
            }
            /*Type */ get ServiceType()
            {
                return this._serviceType;
            }
            /*Type */ get ImplementationType()
            {
                const $t1 = this.DefaultValue;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetType.call($t)) ?? this._serviceType;
            }
            /*CallSiteKind*/ Kind = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 2;
            }
            static $h = 1310724;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2424836,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12886212612,"f":8},"n":"DefaultValue","d":1310724,"h":8591245316,"f":8},{"p":142606337,"g":{"r":0,"d":0,"h":25771114500,"f":32769},"n":"ServiceType","d":1310724,"h":21476147204,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":34361049092,"f":32769},"n":"ImplementationType","d":1310724,"h":30066081796,"f":32769},{"p":851972,"g":{"r":0,"d":0,"h":47245950980,"f":32769},"n":"Kind","d":1310724,"h":42950983684,"f":32769}],"l":[{"t":142606337,"n":"_serviceType","d":1310724,"h":4296278020,"f":2}],"c":[{"p":[{"n":"serviceType","p":142606337},{"n":"defaultValue","p":131073},{"n":"serviceKey","p":131073,"f":65}],"n":".ctor","o":"$ctor$2","d":1310724,"h":17181179908,"f":1}],"h":1310724}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstantCallSite`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite", ($self) => class ConstructorCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            /*ConstructorInfo*/ ConstructorInfo = null;
            /*ServiceCallSite[]*/ ParameterCallSites = null;
            $ctor$2(/*ResultCache*/ cache, /*Type*/ serviceType, /*ConstructorInfo*/ constructorInfo, /*object?*/ serviceKey)
            {
                this.$ctor$3(cache.Clone(), serviceType, constructorInfo, $.$spc.System.Array.Empty($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite), serviceKey);
                {
                }
                return this;
            }
            $ctor$3(/*ResultCache*/ cache, /*Type*/ serviceType, /*ConstructorInfo*/ constructorInfo, /*ServiceCallSite[]*/ parameterCallSites, /*object?*/ serviceKey)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    if (!serviceType.IsAssignableFrom(constructorInfo.DeclaringType))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.ImplementationTypeCantBeConvertedToServiceType, constructorInfo.DeclaringType, serviceType));
                    }
                    this.ServiceType = serviceType;
                    this.ConstructorInfo = constructorInfo;
                    this.ParameterCallSites = parameterCallSites;
                }
                return this;
            }
            /*Type*/ ServiceType = null;
            /*Type? */ get ImplementationType()
            {
                return this.ConstructorInfo.DeclaringType;
            }
            /*CallSiteKind*/ Kind = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 1;
            }
            static $h = 1376260;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2424836,"p":[{"p":75628545,"g":{"r":0,"d":0,"h":12886278148,"f":8},"n":"ConstructorInfo","d":1376260,"h":8591310852,"f":8},{"p":0,"g":{"r":0,"d":0,"h":25771180036,"f":8},"n":"ParameterCallSites","d":1376260,"h":21476212740,"f":8},{"p":142606337,"g":{"r":0,"d":0,"h":47246016516,"f":32769},"n":"ServiceType","d":1376260,"h":42951049220,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":55835951108,"f":32769},"n":"ImplementationType","d":1376260,"h":51540983812,"f":32769},{"p":851972,"g":{"r":0,"d":0,"h":68720852996,"f":32769},"n":"Kind","d":1376260,"h":64425885700,"f":32769}],"c":[{"p":[{"n":"cache","p":2097156},{"n":"serviceType","p":142606337},{"n":"constructorInfo","p":75628545},{"n":"serviceKey","p":131073}],"n":".ctor","o":"$ctor$2","d":1376260,"h":30066147332,"f":1},{"p":[{"n":"cache","p":2097156},{"n":"serviceType","p":142606337},{"n":"constructorInfo","p":75628545},{"n":"parameterCallSites","p":0},{"n":"serviceKey","p":131073}],"n":".ctor","o":"$ctor$3","d":1376260,"h":34361114628,"f":1}],"h":1376260}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ConstructorCallSite`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite", ($self) => class FactoryCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            /*Func<IServiceProvider, object>*/ Factory = null;
            $ctor$2(/*ResultCache*/ cache, /*Type*/ serviceType, /*Func<IServiceProvider, object>*/ factory)
            {
                super.$ctor$1(cache.Clone(), null);
                {
                    this.Factory = factory;
                    this.ServiceType = serviceType;
                }
                return this;
            }
            $ctor$3(/*ResultCache*/ cache, /*Type*/ serviceType, /*object*/ serviceKey, /*Func<IServiceProvider, object, object>*/ factory)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    this.Factory = new ($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object))().$ctor(this,  (/*sp*/ sp) =>
                    {
                        return factory.Invoke(sp, serviceKey);
                    });
                    this.ServiceType = serviceType;
                }
                return this;
            }
            /*Type*/ ServiceType = null;
            /*Type? */ get ImplementationType()
            {
                return null;
            }
            /*CallSiteKind*/ Kind = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 0;
            }
            static $h = 1638404;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2424836,"p":[{"p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":12886540292,"f":1},"n":"Factory","d":1638404,"h":8591572996,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34361376772,"f":32769},"n":"ServiceType","d":1638404,"h":30066409476,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":42951311364,"f":32769},"n":"ImplementationType","d":1638404,"h":38656344068,"f":32769},{"p":851972,"g":{"r":0,"d":0,"h":55836213252,"f":32769},"n":"Kind","d":1638404,"h":51541245956,"f":32769}],"c":[{"p":[{"n":"cache","p":2097156},{"n":"serviceType","p":142606337},{"n":"factory","p":$.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":1638404,"h":17181507588,"f":1},{"p":[{"n":"cache","p":2097156},{"n":"serviceType","p":142606337},{"n":"serviceKey","p":131073},{"n":"factory","p":$.$spc.System.Func$$$$($.$scm.System.IServiceProvider, $.$spc.System.Object, $.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$3","d":1638404,"h":21476474884,"f":1}],"h":1638404}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.FactoryCallSite`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite", ($self) => class IEnumerableCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            /*Type*/ ItemType = null;
            /*ServiceCallSite[]*/ ServiceCallSites = null;
            $ctor$2(/*ResultCache*/ cache, /*Type*/ itemType, /*ServiceCallSite[]*/ serviceCallSites, /*object?*/ serviceKey)
            {
                super.$ctor$1(cache.Clone(), serviceKey);
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !itemType.IsValueType, "If VerifyAotCompatibility=true, an IEnumerableCallSite should not be created with a ValueType.");
                    this.ItemType = itemType;
                    this.ServiceCallSites = serviceCallSites;
                }
                return this;
            }
            /*Type */ get ServiceType()
            {
                return $.$spc.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ this.ItemType ], null, null));
            }
            /*Type */ get ImplementationType()
            {
                return this.ItemType.MakeArrayType();
            }
            /*CallSiteKind*/ Kind = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Kind = 3;
            }
            static $h = 1703940;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2424836,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":12886605828,"f":8},"n":"ItemType","d":1703940,"h":8591638532,"f":8},{"p":0,"g":{"r":0,"d":0,"h":25771507716,"f":8},"n":"ServiceCallSites","d":1703940,"h":21476540420,"f":8},{"p":142606337,"g":{"r":0,"d":0,"h":38656409604,"f":32769},"n":"ServiceType","d":1703940,"h":34361442308,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":47246344196,"f":32769},"n":"ImplementationType","d":1703940,"h":42951376900,"f":32769},{"p":851972,"g":{"r":0,"d":0,"h":60131246084,"f":32769},"n":"Kind","d":1703940,"h":55836278788,"f":32769}],"c":[{"p":[{"n":"cache","p":2097156},{"n":"itemType","p":142606337},{"n":"serviceCallSites","p":0},{"n":"serviceKey","p":131073,"f":65}],"n":".ctor","o":"$ctor$2","d":1703940,"h":30066475012,"f":1}],"h":1703940}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.IEnumerableCallSite`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache", ($self) => class ResultCache extends $.$spc.System.ValueType
        {
            static /*ResultCache */ None(/*Type*/ serviceType)
            {
                /*var*/ let cacheKey = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.FromServiceType(serviceType), 0);
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache().$ctor$2(3/*CallSiteResultCacheLocation.None*/, cacheKey);
            }
            $ctor$2(/*CallSiteResultCacheLocation*/ lifetime, /*ServiceCacheKey*/ cacheKey)
            {
                super.$ctor$1();
                {
                    this.Location = lifetime;
                    this.Key = cacheKey;
                }
                return this;
            }
            $ctor$3(/*ServiceLifetime*/ lifetime, /*ServiceIdentifier*/ serviceIdentifier, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    switch(lifetime)
                    {
                        case 0/*ServiceLifetime.Singleton*/:
                        this.Location = 0/*CallSiteResultCacheLocation.Root*/;
                        break;
                        case 1/*ServiceLifetime.Scoped*/:
                        this.Location = 1/*CallSiteResultCacheLocation.Scope*/;
                        break;
                        case 2/*ServiceLifetime.Transient*/:
                        this.Location = 2/*CallSiteResultCacheLocation.Dispose*/;
                        break;
                        default:
                        this.Location = 3/*CallSiteResultCacheLocation.None*/;
                        break;
                    }
                    this.Key = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey().$ctor$3(serviceIdentifier, slot);
                }
                return this;
            }
            /*CallSiteResultCacheLocation*/ Location = 0;
            /*ServiceCacheKey*/ Key;
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Location = this.Location;
                copy.Key = this.Key.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Location = 0;
                this.Key = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey);
            }
            static $h = 2097156;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917508,"g":{"r":0,"d":0,"h":25771900932,"f":1},"s":{"r":0,"d":0,"h":30066868228,"f":1},"n":"Location","d":2097156,"h":21476933636,"f":1},{"p":2359300,"g":{"r":0,"d":0,"h":42951770116,"f":1},"s":{"r":0,"d":0,"h":47246737412,"f":1},"n":"Key","d":2097156,"h":38656802820,"f":1}],"m":[{"r":2097156,"p":[{"n":"serviceType","p":142606337}],"n":"None","d":2097156,"h":4297064452,"f":33}],"c":[{"p":[{"n":"lifetime","p":917508},{"n":"cacheKey","p":2359300}],"n":".ctor","o":"$ctor$2","d":2097156,"h":8592031748,"f":8},{"p":[{"n":"lifetime","p":1835011},{"n":"serviceIdentifier","p":2555908},{"n":"slot","p":655361}],"n":".ctor","o":"$ctor$3","d":2097156,"h":12886999044,"f":1},{"n":".ctor","o":"$ctor$4","d":2097156,"h":51541704708,"f":1}],"h":2097156}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine", ($self) => class RuntimeServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            /*RuntimeServiceProviderEngine*/ static Instance = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                return new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object))().$ctor(this,  (/*scope*/ scope) =>
                {
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, scope);
                });
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine().$ctor$2();
                }
            }
            static $h = 2293764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2752516,"p":[{"p":2293764,"g":{"r":0,"d":0,"h":12887195652,"f":33},"n":"Instance","d":2293764,"h":8592228356,"f":33}],"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":2293764,"h":21477130244,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":2293764,"h":17182162948,"f":2}],"h":2293764}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeServiceProviderEngine`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite", ($self) => class ServiceProviderCallSite extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite
        {
            $ctor$2()
            {
                super.$ctor$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ResultCache.None($.$scm.System.IServiceProvider.$type), null);
                {
                }
                return this;
            }
            /*Type*/ ServiceType = null;
            /*Type*/ ImplementationType = null;
            /*CallSiteKind*/ Kind = 0;
            //default member initializer
            constructor()
            {
                super();
                this.ServiceType = $.$scm.System.IServiceProvider.$type;
                this.ImplementationType = $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.$type;
                this.Kind = 4;
            }
            static $h = 2686980;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2424836,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17182556164,"f":32769},"n":"ServiceType","d":2686980,"h":12887588868,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":30067458052,"f":32769},"n":"ImplementationType","d":2686980,"h":25772490756,"f":32769},{"p":851972,"g":{"r":0,"d":0,"h":42952359940,"f":32769},"n":"Kind","d":2686980,"h":38657392644,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":2686980,"h":4297654276,"f":1}],"h":2686980}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderCallSite`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext", ($self) => class RuntimeResolverContext extends $.$spc.System.ValueType
        {
            /*ServiceProviderEngineScope*/ Scope = null;
            /*RuntimeResolverLock*/ AcquiredLocks = 0;
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Scope = this.Scope;
                copy.AcquiredLocks = this.AcquiredLocks;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.AcquiredLocks = 0;
            }
            static $h = 2162692;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2818052,"g":{"r":0,"d":0,"h":12887064580,"f":1},"s":{"r":0,"d":0,"h":17182031876,"f":1},"n":"Scope","d":2162692,"h":8592097284,"f":1},{"p":2228228,"g":{"r":0,"d":0,"h":30066933764,"f":1},"s":{"r":0,"d":0,"h":34361901060,"f":1},"n":"AcquiredLocks","d":2162692,"h":25771966468,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2162692,"h":38656868356,"f":1}],"h":2162692}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitServiceProviderEngine", ($self) => class ILEmitServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            /*ILEmitResolverBuilder*/ _expressionResolverBuilder = null;
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    this._expressionResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder().$ctor$2(serviceProvider);
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                return this._expressionResolverBuilder.Build(callSite);
            }
            static $h = 2031620;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2752516,"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":2031620,"h":12886933508,"f":32769}],"l":[{"t":1769476,"n":"_expressionResolverBuilder","d":2031620,"h":4296998916,"f":2}],"c":[{"p":[{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$2","d":2031620,"h":8591966212,"f":1}],"h":2031620}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitServiceProviderEngine`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionsServiceProviderEngine", ($self) => class ExpressionsServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine
        {
            /*ExpressionResolverBuilder*/ _expressionResolverBuilder = null;
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    this._expressionResolverBuilder = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder().$ctor$2(serviceProvider);
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                return this._expressionResolverBuilder.Build(callSite);
            }
            static $h = 1572868;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2752516,"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":1572868,"h":12886474756,"f":32769}],"l":[{"t":1507332,"n":"_expressionResolverBuilder","d":1572868,"h":4296540164,"f":2}],"c":[{"p":[{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$2","d":1572868,"h":8591507460,"f":1}],"h":1572868}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionsServiceProviderEngine`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey", ($self) => class ServiceCacheKey extends $.$spc.System.ValueType
        {
            /*ServiceIdentifier*/ ServiceIdentifier;
            /*int*/ Slot = 0;
            $ctor$2(/*object*/ key, /*Type*/ type, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    this.ServiceIdentifier = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(key, type);
                    this.Slot = slot;
                }
                return this;
            }
            $ctor$3(/*ServiceIdentifier*/ type, /*int*/ slot)
            {
                super.$ctor$1();
                {
                    this.ServiceIdentifier = type;
                    this.Slot = slot;
                }
                return this;
            }
            /*bool */ Equals$2(/*ServiceCacheKey*/ other)
            {
                return this.ServiceIdentifier.Equals$2(other.ServiceIdentifier) && this.Slot === other.Slot;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                //unchecked
                {
                    return ((($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.GetHashCode.call(this.ServiceIdentifier) * 397) | 0)) ^ this.Slot;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey>.Equals(Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ServiceIdentifier = this.ServiceIdentifier.Clone();
                copy.Slot = this.Slot;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ServiceIdentifier = $.$default($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier);
            }
            static $h = 2359300;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2555908,"g":{"r":0,"d":0,"h":12887261188,"f":1},"n":"ServiceIdentifier","d":2359300,"h":8592293892,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25772163076,"f":1},"n":"Slot","d":2359300,"h":21477195780,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":2359300}],"n":"Equals","o":"@$2","d":2359300,"h":38657064964,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2359300,"h":42952032260,"f":32769},{"r":655361,"n":"GetHashCode","d":2359300,"h":47246999556,"f":32769}],"c":[{"p":[{"n":"key","p":131073},{"n":"type","p":142606337},{"n":"slot","p":655361}],"n":".ctor","o":"$ctor$2","d":2359300,"h":30067130372,"f":1},{"p":[{"n":"type","p":2555908},{"n":"slot","p":655361}],"n":".ctor","o":"$ctor$3","d":2359300,"h":34362097668,"f":1},{"n":".ctor","o":"$ctor$4","d":2359300,"h":51541966852,"f":1}],"i":[$.$spc.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey).$h],"h":2359300}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier", ($self) => class ServiceIdentifier extends $.$spc.System.ValueType
        {
            /*object?*/ ServiceKey = null;
            /*Type*/ ServiceType = null;
            $ctor$2(/*Type*/ serviceType)
            {
                super.$ctor$1();
                {
                    this.ServiceType = serviceType;
                }
                return this;
            }
            $ctor$3(/*object?*/ serviceKey, /*Type*/ serviceType)
            {
                super.$ctor$1();
                {
                    this.ServiceKey = serviceKey;
                    this.ServiceType = serviceType;
                }
                return this;
            }
            static /*ServiceIdentifier */ FromDescriptor(/*ServiceDescriptor*/ serviceDescriptor)
            {
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(serviceDescriptor.ServiceKey, serviceDescriptor.ServiceType);
            }
            static /*ServiceIdentifier */ FromServiceType(/*Type*/ type)
            {
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(null, type);
            }
            /*bool */ Equals$2(/*ServiceIdentifier*/ other)
            {
                if (this.ServiceKey === null && other.ServiceKey === null)
                {
                    return $.$spc.System.Type.op_Equality$1(this.ServiceType, other.ServiceType);
                }
                else if (this.ServiceKey !== null && other.ServiceKey !== null)
                {
                    return $.$spc.System.Type.op_Equality$1(this.ServiceType, other.ServiceType) && $.$spc.System.Object.Equals.call(this.ServiceKey, other.ServiceKey);
                }
                return false;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier) && this.Equals$2($.$cast(obj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this.ServiceKey === null)
                {
                    return $.$spc.System.Type.GetHashCode.call(this.ServiceType);
                }
                //unchecked
                {
                    return ((($.$spc.System.Type.GetHashCode.call(this.ServiceType) * 397) | 0)) ^ $.$spc.System.Object.GetHashCode.call(this.ServiceKey);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.GetHashCode.apply(this, arguments); }
            /*ServiceIdentifier */ GetGenericTypeDefinition()
            {
                return new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier().$ctor$3(this.ServiceKey, this.ServiceType.GetGenericTypeDefinition());
            }
            static/*conventional*/ /*string? */ ToString()
            {
                if (this.ServiceKey === null)
                {
                    return $.$spc.System.Type.ToString.call(this.ServiceType);
                }
                return `(${$.$spc.System.Object.ToString.call(this.ServiceKey)}, ${$.$spc.System.Type.ToString.call(this.ServiceType)})`;
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier>.Equals(Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ServiceKey = this.ServiceKey;
                copy.ServiceType = this.ServiceType;
                return copy;
            }
            static $h = 2555908;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":131073,"g":{"r":0,"d":0,"h":12887457796,"f":1},"n":"ServiceKey","d":2555908,"h":8592490500,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":25772359684,"f":1},"n":"ServiceType","d":2555908,"h":21477392388,"f":1}],"m":[{"r":2555908,"p":[{"n":"serviceDescriptor","p":1638403}],"n":"FromDescriptor","d":2555908,"h":38657261572,"f":33},{"r":2555908,"p":[{"n":"type","p":142606337}],"n":"FromServiceType","d":2555908,"h":42952228868,"f":33},{"r":262145,"p":[{"n":"other","p":2555908}],"n":"Equals","o":"@$2","d":2555908,"h":47247196164,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2555908,"h":51542163460,"f":32769},{"r":655361,"n":"GetHashCode","d":2555908,"h":55837130756,"f":32769},{"r":2555908,"n":"GetGenericTypeDefinition","d":2555908,"h":60132098052,"f":1},{"r":1310721,"n":"ToString","d":2555908,"h":64427065348,"f":32769}],"c":[{"p":[{"n":"serviceType","p":142606337}],"n":".ctor","o":"$ctor$2","d":2555908,"h":30067326980,"f":1},{"p":[{"n":"serviceKey","p":131073},{"n":"serviceType","p":142606337}],"n":".ctor","o":"$ctor$3","d":2555908,"h":34362294276,"f":1},{"n":".ctor","o":"$ctor$4","d":2555908,"h":68722032644,"f":1}],"i":[$.$spc.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier).$h],"h":2555908}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceIdentifier`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DefaultServiceProviderFactory", ($self) => class DefaultServiceProviderFactory extends $.$spc.System.Object
        {
            /*ServiceProviderOptions*/ _options = null;
            $ctor$1()
            {
                this.$ctor$2($.$med.Microsoft.Extensions.DependencyInjection.ServiceProviderOptions.Default);
                {
                }
                return this;
            }
            $ctor$2(/*ServiceProviderOptions*/ options)
            {
                super.$ctor();
                {
                    this._options = $.$firstOf(options, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("options") });
                }
                return this;
            }
            /*IServiceCollection */ CreateBuilder(/*IServiceCollection*/ services)
            {
                return services;
            }
            /*IServiceProvider */ CreateServiceProvider(/*IServiceCollection*/ containerBuilder)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceCollectionContainerBuilderExtensions.BuildServiceProvider$2(containerBuilder, this._options);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateBuilder(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateBuilder()
            {
                return this.CreateBuilder(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.DependencyInjection.IServiceProviderFactory<Microsoft.Extensions.DependencyInjection.IServiceCollection>.CreateServiceProvider(Microsoft.Extensions.DependencyInjection.IServiceCollection)
            Microsoft$Extensions$DependencyInjection$IServiceProviderFactory$$$CreateServiceProvider()
            {
                return this.CreateServiceProvider(...arguments);
            }
            static $h = 196612;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"CreateBuilder","d":196612,"h":17180065796,"f":1},{"r":327717,"p":[{"n":"containerBuilder","p":786435}],"n":"CreateServiceProvider","d":196612,"h":21475033092,"f":1}],"l":[{"t":3145732,"n":"_options","d":196612,"h":4295163908,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":196612,"h":8590131204,"f":1},{"p":[{"n":"options","p":3145732}],"n":".ctor","o":"$ctor$2","d":196612,"h":12885098500,"f":1}],"i":[$.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection).$h],"h":196612}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceProviderFactory$$($.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceCollection) ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DefaultServiceProviderFactory`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder", ($self) => class ExpressionResolverBuilder extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$spc.System.Object, $.$sle.System.Linq.Expressions.Expression)
        {
            /*ParameterExpression*/ static ScopeParameter = null;
            /*ParameterExpression*/ static ResolvedServices = null;
            /*ParameterExpression*/ static Sync = null;
            /*BinaryExpression*/ static ResolvedServicesVariableAssignment = null;
            /*BinaryExpression*/ static SyncVariableAssignment = null;
            /*ParameterExpression*/ static CaptureDisposableParameter = null;
            /*LambdaExpression*/ static CaptureDisposable = null;
            /*ConstantExpression*/ static CallSiteRuntimeResolverInstanceExpression = null;
            /*ServiceProviderEngineScope*/ _rootScope = null;
            /*ConcurrentDictionary<ServiceCacheKey, Func<ServiceProviderEngineScope, object>>*/ _scopeResolverCache = null;
            /*Func<ServiceCacheKey, ServiceCallSite, Func<ServiceProviderEngineScope, object>>*/ _buildTypeDelegate = null;
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    this._rootScope = serviceProvider.Root;
                    this._scopeResolverCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object)))().$ctor$1();
                    this._buildTypeDelegate = new ($.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object)))().$ctor(this,  (/*key*/ key, /*cs*/ cs) =>
                    {
                        return this.BuildNoCache(cs);
                    });
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object> */ Build(/*ServiceCallSite*/ callSite)
            {
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return this._scopeResolverCache.GetOrAdd$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, callSite.Cache.Key, this._buildTypeDelegate, callSite);
                }
                return this.BuildNoCache(callSite);
            }
            /*Func<ServiceProviderEngineScope, object> */ BuildNoCache(/*ServiceCallSite*/ callSite)
            {
                /*Expression<Func<ServiceProviderEngineScope, object>>*/ let expression = this.BuildExpression(callSite);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSourceExtensions.ExpressionTreeGenerated($.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log, this._rootScope.RootProvider, callSite.ServiceType, expression);
                return expression.Compile$3();
            }
            /*Expression<Func<ServiceProviderEngineScope, object>> */ BuildExpression(/*ServiceCallSite*/ callSite)
            {
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return $.$sle.System.Linq.Expressions.Expression.Lambda($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object), $.$sle.System.Linq.Expressions.Expression.Block$8($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync], null, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServicesVariableAssignment, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.SyncVariableAssignment, this.BuildScopedExpression(callSite) ], null, null)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
                }
                return $.$sle.System.Linq.Expressions.Expression.Lambda($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object), $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite(callSite, null), $.$spc.System.Object.$type, true), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            /*Expression */ VisitRootCache(/*ServiceCallSite*/ singletonCallSite, /*object?*/ context)
            {
                return $.$sle.System.Linq.Expressions.Expression.Constant($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(singletonCallSite, this._rootScope));
            }
            /*Expression */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*object?*/ context)
            {
                return $.$sle.System.Linq.Expressions.Expression.Constant(constantCallSite.DefaultValue);
            }
            /*Expression */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*object?*/ context)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter;
            }
            /*Expression */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*object?*/ context)
            {
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$sle.System.Linq.Expressions.Expression.Constant(factoryCallSite.Factory), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            /*Expression */ VisitIEnumerable(/*IEnumerableCallSite*/ callSite, /*object?*/ context)
            {
                /*static MethodInfo*/  function GetArrayEmptyMethodInfo(/*Type*/ elementType)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.GetArrayEmptyMethodInfo(elementType);
                }
                /*static NewArrayExpression*/  function NewArrayInit(/*Type*/ elementType, /*IEnumerable<Expression>*/ expr)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$sle.System.Linq.Expressions.Expression.NewArrayInit$1(elementType, expr);
                }
                if (callSite.ServiceCallSites.length === 0)
                {
                    return $.$sle.System.Linq.Expressions.Expression.Constant(GetArrayEmptyMethodInfo(callSite.ItemType).Invoke(null, $.$spc.System.Array.Empty($.$spc.System.Object)));
                }
                return NewArrayInit(callSite.ItemType, $.$sl.System.Linq.Enumerable.Select($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$sle.System.Linq.Expressions.Expression, callSite.ServiceCallSites, new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$sle.System.Linq.Expressions.Expression))().$ctor(this,  (/*cs*/ cs) =>
                {
                    return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite(cs, context), callSite.ItemType, false);
                })));
            }
            /*Expression */ VisitDisposeCache(/*ServiceCallSite*/ callSite, /*object?*/ context)
            {
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.TryCaptureDisposable(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, this.VisitCallSiteMain(callSite, context));
            }
            static /*Expression */ TryCaptureDisposable(/*ServiceCallSite*/ callSite, /*ParameterExpression*/ scope, /*Expression*/ service)
            {
                if (!callSite.CaptureDisposable)
                {
                    return service;
                }
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.GetCaptureDisposable(scope), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ service ], null, null));
            }
            /*Expression */ VisitConstructor(/*ConstructorCallSite*/ callSite, /*object?*/ context)
            {
                /*ParameterInfo[]*/ let parameters = callSite.ConstructorInfo.GetParameters();
                /*Expression[]*/ let parameterExpressions;
                if (callSite.ParameterCallSites.length === 0)
                {
                    parameterExpressions = $.$spc.System.Array.Empty($.$sle.System.Linq.Expressions.Expression);
                }
                else 
                {
                    parameterExpressions = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), null, [callSite.ParameterCallSites.length], null);
                    for(/*int*/ let i = 0; i < parameterExpressions.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(parameterExpressions, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Convert(this.VisitCallSite($.$spc.System.Array.$ReadT1.call(callSite.ParameterCallSites, i), context), $.$spc.System.Array.$ReadT1.call(parameters, i).ParameterType, false), i);
                    }
                }
                /*Expression*/ let expression = $.$sle.System.Linq.Expressions.Expression.New$1(callSite.ConstructorInfo, parameterExpressions);
                if (callSite.ImplementationType.IsValueType)
                {
                    expression = $.$sle.System.Linq.Expressions.Expression.Convert(expression, $.$spc.System.Object.$type);
                }
                return expression;
            }
            static /*Expression */ Convert(/*Expression*/ expression, /*Type*/ type, /*bool*/ forceValueTypeConversion)
            {
                if (type.IsAssignableFrom(expression.Type) && (!expression.Type.IsValueType || !forceValueTypeConversion))
                {
                    return expression;
                }
                return $.$sle.System.Linq.Expressions.Expression.Convert(expression, type);
            }
            /*Expression */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*object?*/ context)
            {
                /*Func<ServiceProviderEngineScope, object>*/ let lambda = this.Build(callSite);
                return $.$sle.System.Linq.Expressions.Expression.Invoke$6($.$sle.System.Linq.Expressions.Expression.Constant(lambda), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter ], null, null));
            }
            /*ConditionalExpression */ BuildScopedExpression(/*ServiceCallSite*/ callSite)
            {
                /*ConstantExpression*/ let callSiteExpression = $.$sle.System.Linq.Expressions.Expression.Constant$1(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite.$type);
                /*MethodCallExpression*/ let resolveRootScopeExpression = $.$sle.System.Linq.Expressions.Expression.Call$11($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CallSiteRuntimeResolverInstanceExpression, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.ResolveCallSiteAndScopeMethodInfo, callSiteExpression, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter);
                /*ConstantExpression*/ let keyExpression = $.$sle.System.Linq.Expressions.Expression.Constant$1(callSite.Cache.Key, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type);
                /*ParameterExpression*/ let resolvedVariable = $.$sle.System.Linq.Expressions.Expression.Variable$1($.$spc.System.Object.$type, "resolved");
                /*ParameterExpression*/ let resolvedServices = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices;
                /*MethodCallExpression*/ let tryGetValueExpression = $.$sle.System.Linq.Expressions.Expression.Call$11(resolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.TryGetValueMethodInfo, keyExpression, resolvedVariable);
                /*Expression*/ let captureDisposible = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.TryCaptureDisposable(callSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, this.VisitCallSiteMain(callSite, null));
                /*BinaryExpression*/ let assignExpression = $.$sle.System.Linq.Expressions.Expression.Assign(resolvedVariable, captureDisposible);
                /*MethodCallExpression*/ let addValueExpression = $.$sle.System.Linq.Expressions.Expression.Call$11(resolvedServices, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.AddMethodInfo, keyExpression, resolvedVariable);
                /*BlockExpression*/ let blockExpression = $.$sle.System.Linq.Expressions.Expression.Block$9($.$spc.System.Object.$type, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [resolvedVariable], null, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.IfThen($.$sle.System.Linq.Expressions.Expression.Not(tryGetValueExpression), $.$sle.System.Linq.Expressions.Expression.Block(assignExpression, addValueExpression)), resolvedVariable ], null, null));
                /*ParameterExpression*/ let lockWasTaken = $.$sle.System.Linq.Expressions.Expression.Variable$1($.$spc.System.Boolean.$type, "lockWasTaken");
                /*ParameterExpression*/ let sync = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync;
                /*MethodCallExpression*/ let monitorEnter = $.$sle.System.Linq.Expressions.Expression.Call$2($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorEnterMethodInfo, sync, lockWasTaken);
                /*MethodCallExpression*/ let monitorExit = $.$sle.System.Linq.Expressions.Expression.Call$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorExitMethodInfo, sync);
                /*BlockExpression*/ let tryBody = $.$sle.System.Linq.Expressions.Expression.Block(monitorEnter, blockExpression);
                /*ConditionalExpression*/ let finallyBody = $.$sle.System.Linq.Expressions.Expression.IfThen(lockWasTaken, monitorExit);
                return $.$sle.System.Linq.Expressions.Expression.Condition($.$sle.System.Linq.Expressions.Expression.Property$5($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("IsRootScope", 4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/)), resolveRootScopeExpression, $.$sle.System.Linq.Expressions.Expression.Block$9($.$spc.System.Object.$type, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [lockWasTaken], null, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$sle.System.Linq.Expressions.Expression.TryFinally(tryBody, finallyBody) ], null, null)));
            }
            static /*Expression */ GetCaptureDisposable(/*ParameterExpression*/ scope)
            {
                if (scope !== $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter)
                {
                    throw new $.$spc.System.NotSupportedException().$ctor$10($.$med.System.SR.GetCaptureDisposableNotSupported);
                }
                return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposable;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ScopeParameter = $.$sle.System.Linq.Expressions.Expression.Parameter($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type);
                }
                {
                    this.ResolvedServices = $.$sle.System.Linq.Expressions.Expression.Variable$1($.$spc.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object).$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter.Name + "resolvedServices");
                }
                {
                    this.Sync = $.$sle.System.Linq.Expressions.Expression.Variable$1($.$spc.System.Object.$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter.Name + "sync");
                }
                {
                    this.ResolvedServicesVariableAssignment = $.$sle.System.Linq.Expressions.Expression.Assign($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ResolvedServices, $.$sle.System.Linq.Expressions.Expression.Property$5($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("ResolvedServices", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/)));
                }
                {
                    this.SyncVariableAssignment = $.$sle.System.Linq.Expressions.Expression.Assign($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.Sync, $.$sle.System.Linq.Expressions.Expression.Property$5($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("Sync", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/)));
                }
                {
                    this.CaptureDisposableParameter = $.$sle.System.Linq.Expressions.Expression.Parameter($.$spc.System.Object.$type);
                }
                {
                    this.CaptureDisposable = $.$sle.System.Linq.Expressions.Expression.Lambda$10($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object).$type, $.$sle.System.Linq.Expressions.Expression.Call$9($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.ScopeParameter, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.CaptureDisposableMethodInfo, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposableParameter ], null, null)), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.ParameterExpression), [ $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder.CaptureDisposableParameter ], null, null));
                }
                {
                    this.CallSiteRuntimeResolverInstanceExpression = $.$sle.System.Linq.Expressions.Expression.Constant$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type);
                }
            }
            static $h = 1507332;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"Build","d":1507332,"h":55836082180,"f":1},{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"BuildNoCache","d":1507332,"h":60131049476,"f":1},{"r":$.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object)).$h,"p":[{"n":"callSite","p":2424836}],"n":"BuildExpression","d":1507332,"h":64426016772,"f":2},{"r":8695487,"p":[{"n":"singletonCallSite","p":2424836},{"n":"context","p":131073}],"n":"VisitRootCache","d":1507332,"h":68720984068,"f":32772},{"r":8695487,"p":[{"n":"constantCallSite","p":1310724},{"n":"context","p":131073}],"n":"VisitConstant","d":1507332,"h":73015951364,"f":32772},{"r":8695487,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"context","p":131073}],"n":"VisitServiceProvider","d":1507332,"h":77310918660,"f":32772},{"r":8695487,"p":[{"n":"factoryCallSite","p":1638404},{"n":"context","p":131073}],"n":"VisitFactory","d":1507332,"h":81605885956,"f":32772},{"r":8695487,"p":[{"n":"callSite","p":1703940},{"n":"context","p":131073}],"n":"VisitIEnumerable","d":1507332,"h":85900853252,"f":32772},{"r":8695487,"p":[{"n":"callSite","p":2424836},{"n":"context","p":131073}],"n":"VisitDisposeCache","d":1507332,"h":90195820548,"f":32772},{"r":8695487,"p":[{"n":"callSite","p":2424836},{"n":"scope","p":40218303},{"n":"service","p":8695487}],"n":"TryCaptureDisposable","d":1507332,"h":94490787844,"f":34},{"r":8695487,"p":[{"n":"callSite","p":1376260},{"n":"context","p":131073}],"n":"VisitConstructor","d":1507332,"h":98785755140,"f":32772},{"r":8695487,"p":[{"n":"expression","p":8695487},{"n":"type","p":142606337},{"n":"forceValueTypeConversion","p":262145,"f":65,"v":false}],"n":"Convert","d":1507332,"h":103080722436,"f":34},{"r":8695487,"p":[{"n":"callSite","p":2424836},{"n":"context","p":131073}],"n":"VisitScopeCache","d":1507332,"h":107375689732,"f":32772},{"r":7646911,"p":[{"n":"callSite","p":2424836}],"n":"BuildScopedExpression","d":1507332,"h":111670657028,"f":2},{"r":8695487,"p":[{"n":"scope","p":40218303}],"n":"GetCaptureDisposable","d":1507332,"h":115965624324,"f":33}],"l":[{"t":40218303,"n":"ScopeParameter","d":1507332,"h":4296474628,"f":34},{"t":40218303,"n":"ResolvedServices","d":1507332,"h":8591441924,"f":34},{"t":40218303,"n":"Sync","d":1507332,"h":12886409220,"f":34},{"t":3583679,"n":"ResolvedServicesVariableAssignment","d":1507332,"h":17181376516,"f":34},{"t":3583679,"n":"SyncVariableAssignment","d":1507332,"h":21476343812,"f":34},{"t":40218303,"n":"CaptureDisposableParameter","d":1507332,"h":25771311108,"f":34},{"t":38514367,"n":"CaptureDisposable","d":1507332,"h":30066278404,"f":34},{"t":7777983,"n":"CallSiteRuntimeResolverInstanceExpression","d":1507332,"h":34361245700,"f":34},{"t":2818052,"n":"_rootScope","d":1507332,"h":38656212996,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object)).$h,"n":"_scopeResolverCache","d":1507332,"h":42951180292,"f":2},{"t":$.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object)).$h,"n":"_buildTypeDelegate","d":1507332,"h":47246147588,"f":2}],"c":[{"p":[{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$2","d":1507332,"h":51541114884,"f":1}],"h":1507332}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$spc.System.Object, $.$sle.System.Linq.Expressions.Expression); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ExpressionResolverBuilder`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine", ($self) => class DynamicServiceProviderEngine extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine
        {
            /*ServiceProvider*/ _serviceProvider = null;
            $ctor$3(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$2(serviceProvider);
                {
                    this._serviceProvider = serviceProvider;
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object?> */ RealizeService(/*ServiceCallSite*/ callSite)
            {
                /*int*/ let callCount = 0;
                return new ($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object))().$ctor(this,  (/**/ scope) =>
                {
                    /*var*/ let result = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, scope);
                    if ($.$spc.System.Threading.Interlocked.Increment($.$ref(() => callCount, ($v) => callCount = $v, $.$spc.System.Int32)) === 2)
                    {
                        _ = $.$spc.System.Threading.ThreadPool.UnsafeQueueUserWorkItem$1(new $.$spc.System.Threading.WaitCallback().$ctor(this,  (/*_*/ _0) =>
                        {
                            try
                            {
                                this._serviceProvider.ReplaceServiceAccessor(callSite, super.RealizeService(callSite));
                            }
                            catch(ex)
                            {
                                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.ServiceRealizationFailed$1(ex, $.$spc.System.Object.GetHashCode.call(this._serviceProvider));
                                $.$spc.System.Diagnostics.Debug.Fail(`We should never get exceptions from the background compilation.${$.$spc.System.Environment.NewLine}${$.$spc.System.Exception.ToString.call(ex)}`);
                            }
                        }), null);
                    }
                    return result;
                });
            }
            static $h = 1441796;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1245188,"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"RealizeService","d":1441796,"h":12886343684,"f":32769}],"l":[{"t":3014660,"n":"_serviceProvider","d":1441796,"h":4296409092,"f":2}],"c":[{"p":[{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$3","d":1441796,"h":8591376388,"f":1}],"h":1441796}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CompiledServiceProviderEngine; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.DynamicServiceProviderEngine`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind", ($self) => class CallSiteKind extends $.$spc.System.Enum
        {
            static Factory = 0;
            static Constructor = 1;
            static Constant = 2;
            static IEnumerable = 3;
            static ServiceProvider = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Factory": 0n,
                    "Constructor": 1n,
                    "Constant": 2n,
                    "IEnumerable": 3n,
                    "ServiceProvider": 4n
                };
            }
            static $h = 851972;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":851972,"n":"Factory","d":851972,"h":4295819268,"f":33},{"t":851972,"n":"Constructor","d":851972,"h":8590786564,"f":33},{"t":851972,"n":"Constant","d":851972,"h":12885753860,"f":33},{"t":851972,"n":"IEnumerable","d":851972,"h":17180721156,"f":33},{"t":851972,"n":"ServiceProvider","d":851972,"h":21475688452,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":851972,"h":25770655748,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":851972}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation", ($self) => class CallSiteResultCacheLocation extends $.$spc.System.Enum
        {
            static Root = 0;
            static Scope = 1;
            static Dispose = 2;
            static None = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Root": 0n,
                    "Scope": 1n,
                    "Dispose": 2n,
                    "None": 3n
                };
            }
            static $h = 917508;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":917508,"n":"Root","d":917508,"h":4295884804,"f":33},{"t":917508,"n":"Scope","d":917508,"h":8590852100,"f":33},{"t":917508,"n":"Dispose","d":917508,"h":12885819396,"f":33},{"t":917508,"n":"None","d":917508,"h":17180786692,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":917508,"h":21475753988,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":917508}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation`; }
        });
        
        $asm.$str("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverLock", ($self) => class RuntimeResolverLock extends $.$spc.System.Enum
        {
            static Scope = 1;
            static Root = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Scope": 1n,
                    "Root": 2n
                };
            }
            static $h = 2228228;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2228228,"n":"Scope","d":2228228,"h":4297195524,"f":33},{"t":2228228,"n":"Root","d":2228228,"h":8592162820,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2228228,"h":12887130116,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2228228,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverLock`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder", ($self) => class ILEmitResolverBuilder extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext, $.$spc.System.Object)
        {
            /*MethodInfo*/ static ResolvedServicesGetter = null;
            /*MethodInfo*/ static ScopeLockGetter = null;
            /*MethodInfo*/ static ScopeIsRootScope = null;
            /*MethodInfo*/ static CallSiteRuntimeResolverResolveMethod = null;
            /*MethodInfo*/ static CallSiteRuntimeResolverInstanceField = null;
            /*FieldInfo*/ static FactoriesField = null;
            /*FieldInfo*/ static ConstantsField = null;
            /*MethodInfo*/ static GetTypeFromHandleMethod = null;
            /*ConstructorInfo*/ static CacheKeyCtor = null;
            static $_ILEmitResolverBuilderRuntimeContext;
            static get ILEmitResolverBuilderRuntimeContext()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder;
                return $cls.$_ILEmitResolverBuilderRuntimeContext ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext", ($self) => class ILEmitResolverBuilderRuntimeContext extends $.$spc.System.Object
                {
                    /*object?[]?*/ Constants = null;
                    /*Func<IServiceProvider, object>[]?*/ Factories = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 1900548;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":0,"n":"Constants","d":1900548,"h":4296867844,"f":1},{"t":0,"n":"Factories","d":1900548,"h":8591835140,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1900548,"h":12886802436,"f":1}],"d":1769476,"h":1900548}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext`; }
                }, $cls, ($v) => $cls.$_ILEmitResolverBuilderRuntimeContext = $v);
            }
            static $_GeneratedMethod;
            static get GeneratedMethod()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder;
                return $cls.$_GeneratedMethod ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod", ($self) => class GeneratedMethod extends $.$spc.System.ValueType
                {
                    /*Func<ServiceProviderEngineScope, object?>*/  get Lambda() { return this.$getField(0, 4); }
                    /*Func<ServiceProviderEngineScope, object?>*/  set Lambda(value) { this.$setField(0, 4, value); }
                    /*ILEmitResolverBuilderRuntimeContext*/  get Context() { return this.$getField(4, 4); }
                    /*ILEmitResolverBuilderRuntimeContext*/  set Context(value) { this.$setField(4, 4, value); }
                    /*DynamicMethod*/  get DynamicMethod() { return this.$getField(8, 4); }
                    /*DynamicMethod*/  set DynamicMethod(value) { this.$setField(8, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Lambda = this.Lambda;
                        copy.Context = this.Context;
                        copy.DynamicMethod = this.DynamicMethod;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Lambda = null;
                        this.Context = null;
                        this.DynamicMethod = null;
                    }
                    static $h = 1835012;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"n":"Lambda","d":1835012,"h":4296802308,"f":1},{"t":1900548,"n":"Context","d":1835012,"h":8591769604,"f":1},{"n":"DynamicMethod","d":1835012,"h":12886736900,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1835012,"h":17181704196,"f":1}],"d":1769476,"h":1835012}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod`; }
                }, $cls, ($v) => $cls.$_GeneratedMethod = $v);
            }
            /*ServiceProviderEngineScope*/ _rootScope = null;
            /*ConcurrentDictionary<ServiceCacheKey, GeneratedMethod>*/ _scopeResolverCache = null;
            /*Func<ServiceCacheKey, ServiceCallSite, GeneratedMethod>*/ _buildTypeDelegate = null;
            $ctor$2(/*ServiceProvider*/ serviceProvider)
            {
                super.$ctor$1();
                {
                    this._rootScope = serviceProvider.Root;
                    this._scopeResolverCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod))().$ctor$1();
                    this._buildTypeDelegate = new ($.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod))().$ctor(this,  (/*key*/ key, /*cs*/ cs) =>
                    {
                        return this.BuildTypeNoCache(cs);
                    });
                }
                return this;
            }
            /*Func<ServiceProviderEngineScope, object?> */ Build(/*ServiceCallSite*/ callSite)
            {
                return this.BuildType(callSite).Lambda;
            }
            /*GeneratedMethod */ BuildType(/*ServiceCallSite*/ callSite)
            {
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    return this._scopeResolverCache.GetOrAdd$1($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, callSite.Cache.Key, this._buildTypeDelegate, callSite);
                }
                return this.BuildTypeNoCache(callSite);
            }
            /*GeneratedMethod */ BuildTypeNoCache(/*ServiceCallSite*/ callSite)
            {
                /*var*/ let dynamicMethod = new DynamicMethod("ResolveService", 6/*MethodAttributes.Public*/ | 16/*MethodAttributes.Static*/, 1/*CallingConventions.Standard*/, $.$spc.System.Object.$type, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [$.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type], null, null), $.$spc.System.Object.GetType.call(this), true);
                /*ILGenerator*/ let ilGenerator = dynamicMethod.GetILGenerator(512);
                /*ILEmitResolverBuilderRuntimeContext*/ let runtimeContext = this.GenerateMethodBody(callSite, ilGenerator);
                $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Log.DynamicMethodBuilt$1(this._rootScope.RootProvider, callSite.ServiceType, ilGenerator.ILOffset);
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod;
                    const $i1 = new $t1();
                    $i1.Lambda = $.$cast(dynamicMethod.CreateDelegate$1($.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$type, runtimeContext), $.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object));
                    $i1.Context = runtimeContext;
                    $i1.DynamicMethod = dynamicMethod;
                    return $i1;
                })();
            }
            /*object? */ VisitDisposeCache(/*ServiceCallSite*/ transientCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                if (transientCallSite.CaptureDisposable)
                {
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.BeginCaptureDisposable(argument);
                    this.VisitCallSiteMain(transientCallSite, argument);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.EndCaptureDisposable(argument);
                }
                else 
                {
                    this.VisitCallSiteMain(transientCallSite, argument);
                }
                return null;
            }
            /*object? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                let $i1 = 0;
                let $arr1 = constructorCallSite.ParameterCallSites;
                while ($i1 < $arr1.length)
                {
                    let parameterCallSite = $arr1[$i1++];
                    this.VisitCallSite(parameterCallSite, argument);
                    if (parameterCallSite.ServiceType.IsValueType)
                    {
                        argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Unbox_Any, parameterCallSite.ServiceType);
                    }
                }
                argument.Generator.Emit$9(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Newobj, constructorCallSite.ConstructorInfo);
                if (constructorCallSite.ImplementationType.IsValueType)
                {
                    argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Box, constructorCallSite.ImplementationType);
                }
                return null;
            }
            /*object? */ VisitRootCache(/*ServiceCallSite*/ callSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.Instance.Resolve(callSite, this._rootScope));
                return null;
            }
            /*object? */ VisitScopeCache(/*ServiceCallSite*/ scopedCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                /*GeneratedMethod*/ let generatedMethod = this.BuildType(scopedCallSite);
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, generatedMethod.Context);
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                argument.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, generatedMethod.DynamicMethod);
                return null;
            }
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, constantCallSite.DefaultValue);
                return null;
            }
            /*object? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                return null;
            }
            /*object? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                if (enumerableCallSite.ServiceCallSites.length === 0)
                {
                    argument.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.GetArrayEmptyMethodInfo(enumerableCallSite.ItemType));
                }
                else 
                {
                    argument.Generator.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldc_I4, enumerableCallSite.ServiceCallSites.length);
                    argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Newarr, enumerableCallSite.ItemType);
                    for(/*int*/ let i = 0; i < enumerableCallSite.ServiceCallSites.length; i++)
                    {
                        argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Dup);
                        argument.Generator.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldc_I4, i);
                        /*ServiceCallSite*/ let parameterCallSite = $.$spc.System.Array.$ReadT1.call(enumerableCallSite.ServiceCallSites, i);
                        this.VisitCallSite(parameterCallSite, argument);
                        if (parameterCallSite.ServiceType.IsValueType)
                        {
                            argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Unbox_Any, parameterCallSite.ServiceType);
                        }
                        argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Stelem, enumerableCallSite.ItemType);
                    }
                }
                return null;
            }
            /*object? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*ILEmitResolverBuilderContext*/ argument)
            {
                argument.Factories ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object)))().$ctor$1();
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_0);
                argument.Generator.Emit$13(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldfld, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.FactoriesField);
                argument.Generator.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldc_I4, argument.Factories.Count);
                argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldelem, $.$spc.System.Func$$$($.$scm.System.IServiceProvider, $.$spc.System.Object).$type);
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                argument.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.InvokeFactoryMethodInfo);
                argument.Factories.Add(factoryCallSite.Factory);
                return null;
            }
            static /*void */ AddConstant(/*ILEmitResolverBuilderContext*/ argument, /*object?*/ value)
            {
                argument.Constants ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_0);
                argument.Generator.Emit$13(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldfld, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ConstantsField);
                argument.Generator.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldc_I4, argument.Constants.Count);
                argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldelem, $.$spc.System.Object.$type);
                argument.Constants.Add(value);
            }
            static /*void */ AddCacheKey(/*ILEmitResolverBuilderContext*/ argument, /*ServiceCacheKey*/ key)
            {
                /*var*/ let id = key.ServiceIdentifier;
                $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(argument, id.ServiceKey);
                argument.Generator.Emit$10(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldtoken, id.ServiceType);
                argument.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GetTypeFromHandleMethod);
                argument.Generator.Emit$6(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldc_I4, key.Slot);
                argument.Generator.Emit$9(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Newobj, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CacheKeyCtor);
            }
            /*ILEmitResolverBuilderRuntimeContext */ GenerateMethodBody(/*ServiceCallSite*/ callSite, /*ILGenerator*/ generator)
            {
                /*var*/ let context = (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext;
                    const $i1 = new $t1();
                    $i1.$ctor$1(generator);
                    $i1.Constants = null;
                    $i1.Factories = null;
                    return $i1;
                })();
                if (callSite.Cache.Location === 1/*CallSiteResultCacheLocation.Scope*/)
                {
                    /*LocalBuilder*/ let cacheKeyLocal = context.Generator.DeclareLocal($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type);
                    /*LocalBuilder*/ let resolvedServicesLocal = context.Generator.DeclareLocal($.$spc.System.Collections.Generic.IDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Object).$type);
                    /*LocalBuilder*/ let syncLocal = context.Generator.DeclareLocal($.$spc.System.Object.$type);
                    /*LocalBuilder*/ let lockTakenLocal = context.Generator.DeclareLocal($.$spc.System.Boolean.$type);
                    /*LocalBuilder*/ let resultLocal = context.Generator.DeclareLocal($.$spc.System.Object.$type);
                    /*Label*/ let skipCreationLabel = context.Generator.DefineLabel();
                    /*Label*/ let returnLabel = context.Generator.DefineLabel();
                    /*Label*/ let defaultLabel = context.Generator.DefineLabel();
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ScopeIsRootScope);
                    context.Generator.Emit$11(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Brfalse_S, defaultLabel);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CallSiteRuntimeResolverInstanceField);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddConstant(context, callSite);
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.CallSiteRuntimeResolverResolveMethod);
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                    context.Generator.MarkLabel(defaultLabel);
                    $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.AddCacheKey(context, callSite.Cache.Key);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Stloc, cacheKeyLocal);
                    context.Generator.BeginExceptionBlock();
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ResolvedServicesGetter);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Stloc, resolvedServicesLocal);
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ScopeLockGetter);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Stloc, syncLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, syncLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloca, lockTakenLocal);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorEnterMethodInfo);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, resolvedServicesLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, cacheKeyLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloca, resultLocal);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.TryGetValueMethodInfo);
                    context.Generator.Emit$11(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Brtrue, skipCreationLabel);
                    this.VisitCallSiteMain(callSite, context);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Stloc, resultLocal);
                    if (callSite.CaptureDisposable)
                    {
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.BeginCaptureDisposable(context);
                        context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, resultLocal);
                        $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.EndCaptureDisposable(context);
                        generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Pop);
                    }
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, resolvedServicesLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, cacheKeyLocal);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, resultLocal);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.AddMethodInfo);
                    context.Generator.MarkLabel(skipCreationLabel);
                    context.Generator.BeginFinallyBlock();
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, lockTakenLocal);
                    context.Generator.Emit$11(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Brfalse, returnLabel);
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, syncLocal);
                    context.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Call, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.MonitorExitMethodInfo);
                    context.Generator.MarkLabel(returnLabel);
                    context.Generator.EndExceptionBlock();
                    context.Generator.Emit$15(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldloc, resultLocal);
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                }
                else 
                {
                    this.VisitCallSite(callSite, context);
                    context.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ret);
                }
                return (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext()
                    const $t2 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext;
                    const $i2 = new $t2();
                    $i2.Constants = (context.Constants?.ToArray() ?? null);
                    $i2.Factories = (context.Factories?.ToArray() ?? null);
                    return $i2;
                })();
            }
            static /*void */ BeginCaptureDisposable(/*ILEmitResolverBuilderContext*/ argument)
            {
                argument.Generator.Emit(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Ldarg_1);
            }
            static /*void */ EndCaptureDisposable(/*ILEmitResolverBuilderContext*/ argument)
            {
                argument.Generator.Emit$7(/*$.$spc.System.Reflection.Emit.OpCodes*/$.$spc.DeletedObject.Callvirt, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceLookupHelpers.CaptureDisposableMethodInfo);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ResolvedServicesGetter = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("ResolvedServices", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/).GetMethod;
                }
                {
                    this.ScopeLockGetter = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("Sync", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/).GetMethod;
                }
                {
                    this.ScopeIsRootScope = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope.$type.GetProperty$1("IsRootScope", 4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/).GetMethod;
                }
                {
                    this.CallSiteRuntimeResolverResolveMethod = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetMethod$2("Resolve", 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/);
                }
                {
                    this.CallSiteRuntimeResolverInstanceField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver.$type.GetProperty$1("Instance", 8/*BindingFlags.Static*/ | 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/).GetMethod;
                }
                {
                    this.FactoriesField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type.GetField$1("Factories");
                }
                {
                    this.ConstantsField = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.ILEmitResolverBuilderRuntimeContext.$type.GetField$1("Constants");
                }
                {
                    this.GetTypeFromHandleMethod = $.$spc.System.Type.$type.GetMethod$1("GetTypeFromHandle");
                }
                {
                    this.CacheKeyCtor = $.$spc.System.Array.$ReadT1.call($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey.$type.GetConstructors(), 0);
                }
            }
            static $h = 1769476;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Func$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceProviderEngineScope, $.$spc.System.Object).$h,"p":[{"n":"callSite","p":2424836}],"n":"Build","d":1769476,"h":68721246212,"f":1},{"r":1835012,"p":[{"n":"callSite","p":2424836}],"n":"BuildType","d":1769476,"h":73016213508,"f":2},{"r":1835012,"p":[{"n":"callSite","p":2424836}],"n":"BuildTypeNoCache","d":1769476,"h":77311180804,"f":2},{"r":131073,"p":[{"n":"transientCallSite","p":2424836},{"n":"argument","p":1966084}],"n":"VisitDisposeCache","d":1769476,"h":81606148100,"f":32772},{"r":131073,"p":[{"n":"constructorCallSite","p":1376260},{"n":"argument","p":1966084}],"n":"VisitConstructor","d":1769476,"h":85901115396,"f":32772},{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":1966084}],"n":"VisitRootCache","d":1769476,"h":90196082692,"f":32772},{"r":131073,"p":[{"n":"scopedCallSite","p":2424836},{"n":"argument","p":1966084}],"n":"VisitScopeCache","d":1769476,"h":94491049988,"f":32772},{"r":131073,"p":[{"n":"constantCallSite","p":1310724},{"n":"argument","p":1966084}],"n":"VisitConstant","d":1769476,"h":98786017284,"f":32772},{"r":131073,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"argument","p":1966084}],"n":"VisitServiceProvider","d":1769476,"h":103080984580,"f":32772},{"r":131073,"p":[{"n":"enumerableCallSite","p":1703940},{"n":"argument","p":1966084}],"n":"VisitIEnumerable","d":1769476,"h":107375951876,"f":32772},{"r":131073,"p":[{"n":"factoryCallSite","p":1638404},{"n":"argument","p":1966084}],"n":"VisitFactory","d":1769476,"h":111670919172,"f":32772},{"r":65537,"p":[{"n":"argument","p":1966084},{"n":"value","p":131073}],"n":"AddConstant","d":1769476,"h":115965886468,"f":34},{"r":65537,"p":[{"n":"argument","p":1966084},{"n":"key","p":2359300}],"n":"AddCacheKey","d":1769476,"h":120260853764,"f":34},{"r":1900548,"p":[{"n":"callSite","p":2424836},{"n":"generator"}],"n":"GenerateMethodBody","d":1769476,"h":124555821060,"f":2},{"r":65537,"p":[{"n":"argument","p":1966084}],"n":"BeginCaptureDisposable","d":1769476,"h":128850788356,"f":34},{"r":65537,"p":[{"n":"argument","p":1966084}],"n":"EndCaptureDisposable","d":1769476,"h":133145755652,"f":34}],"l":[{"t":79626241,"n":"ResolvedServicesGetter","d":1769476,"h":4296736772,"f":34},{"t":79626241,"n":"ScopeLockGetter","d":1769476,"h":8591704068,"f":34},{"t":79626241,"n":"ScopeIsRootScope","d":1769476,"h":12886671364,"f":34},{"t":79626241,"n":"CallSiteRuntimeResolverResolveMethod","d":1769476,"h":17181638660,"f":34},{"t":79626241,"n":"CallSiteRuntimeResolverInstanceField","d":1769476,"h":21476605956,"f":34},{"t":76677121,"n":"FactoriesField","d":1769476,"h":25771573252,"f":34},{"t":76677121,"n":"ConstantsField","d":1769476,"h":30066540548,"f":34},{"t":79626241,"n":"GetTypeFromHandleMethod","d":1769476,"h":34361507844,"f":34},{"t":75628545,"n":"CacheKeyCtor","d":1769476,"h":38656475140,"f":34},{"t":2818052,"n":"_rootScope","d":1769476,"h":51541377028,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod).$h,"n":"_scopeResolverCache","d":1769476,"h":55836344324,"f":2},{"t":$.$spc.System.Func$$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder.GeneratedMethod).$h,"n":"_buildTypeDelegate","d":1769476,"h":60131311620,"f":2}],"c":[{"p":[{"n":"serviceProvider","p":3014660}],"n":".ctor","o":"$ctor$2","d":1769476,"h":64426278916,"f":1}],"j":[1900548,1835012],"h":1769476}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilderContext, $.$spc.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.ILEmitResolverBuilder`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter", ($self) => class CallSiteJsonFormatter extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($self.$itype$CallSiteFormatterContext, $.$spc.System.Object)
        {
            /*CallSiteJsonFormatter*/ static Instance = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string */ Format(/*ServiceCallSite*/ callSite)
            {
                /*var*/ let stringBuilder = new $.$spc.System.Text.StringBuilder().$ctor$1();
                /*var*/ let context = new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext().$ctor$2(stringBuilder, 0, new ($.$spc.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite))().$ctor$1());
                this.VisitCallSite(callSite, context.Clone());
                return $.$spc.System.Text.StringBuilder.ToString.call(stringBuilder);
            }
            /*object? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*CallSiteFormatterContext*/ argument)
            {
                argument.WriteProperty("implementationType", constructorCallSite.ImplementationType);
                if (constructorCallSite.ParameterCallSites.length > 0)
                {
                    argument.StartProperty("arguments");
                    /*CallSiteFormatterContext*/ let childContext = argument.StartArray();
                    let $i1 = 0;
                    let $arr1 = constructorCallSite.ParameterCallSites;
                    while ($i1 < $arr1.length)
                    {
                        let parameter = $arr1[$i1++];
                        childContext.StartArrayItem();
                        this.VisitCallSite(parameter, childContext.Clone());
                    }
                    argument.EndArray();
                }
                return null;
            }
            /*object? */ VisitCallSiteMain(/*ServiceCallSite*/ callSite, /*CallSiteFormatterContext*/ argument)
            {
                if (argument.ShouldFormat(callSite))
                {
                    /*CallSiteFormatterContext*/ let childContext = argument.StartObject();
                    childContext.WriteProperty("serviceType", callSite.ServiceType);
                    childContext.WriteProperty("kind", $.$box(callSite.Kind, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteKind));
                    childContext.WriteProperty("cache", $.$box(callSite.Cache.Location, $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteResultCacheLocation));
                    super.VisitCallSiteMain(callSite, childContext.Clone());
                    argument.EndObject();
                }
                else 
                {
                    /*CallSiteFormatterContext*/ let childContext = argument.StartObject();
                    childContext.WriteProperty("ref", callSite.ServiceType);
                    argument.EndObject();
                }
                return null;
            }
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*CallSiteFormatterContext*/ argument)
            {
                argument.WriteProperty("value", constantCallSite.DefaultValue ?? "");
                return null;
            }
            /*object? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*CallSiteFormatterContext*/ argument)
            {
                return null;
            }
            /*object? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*CallSiteFormatterContext*/ argument)
            {
                argument.WriteProperty("itemType", enumerableCallSite.ItemType);
                argument.WriteProperty("size", $.$box(enumerableCallSite.ServiceCallSites.length, $.$spc.System.Int32));
                if (enumerableCallSite.ServiceCallSites.length > 0)
                {
                    argument.StartProperty("items");
                    /*CallSiteFormatterContext*/ let childContext = argument.StartArray();
                    let $i1 = 0;
                    let $arr1 = enumerableCallSite.ServiceCallSites;
                    while ($i1 < $arr1.length)
                    {
                        let item = $arr1[$i1++];
                        childContext.StartArrayItem();
                        this.VisitCallSite(item, childContext.Clone());
                    }
                    argument.EndArray();
                }
                return null;
            }
            /*object? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*CallSiteFormatterContext*/ argument)
            {
                argument.WriteProperty("method", factoryCallSite.Factory.Method);
                return null;
            }
            static $_CallSiteFormatterContext;
            static get CallSiteFormatterContext()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter;
                return $cls.$_CallSiteFormatterContext ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext", ($self) => class CallSiteFormatterContext extends $.$spc.System.ValueType
                {
                    /*HashSet<ServiceCallSite>*/  get _processedCallSites() { return this.$getField(0, 4); }
                    /*HashSet<ServiceCallSite>*/  set _processedCallSites(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*StringBuilder*/ builder, /*int*/ offset, /*HashSet<ServiceCallSite>*/ processedCallSites)
                    {
                        super.$ctor$1();
                        {
                            this.Builder = builder;
                            this.Offset = offset;
                            this._processedCallSites = processedCallSites;
                            this._firstItem = true;
                        }
                        return this;
                    }
                    /*bool*/  get _firstItem() { return this.$getField(4, 1); }
                    /*bool*/  set _firstItem(value) { this.$setField(4, 1, value); }
                    /*int*/ Offset = 0;
                    /*StringBuilder*/ Builder = null;
                    /*bool */ ShouldFormat(/*ServiceCallSite*/ serviceCallSite)
                    {
                        return this._processedCallSites.Add(serviceCallSite);
                    }
                    /*CallSiteFormatterContext */ IncrementOffset()
                    {
                        return (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext;
                            const $i1 = new $t1();
                            $i1.$ctor$2(this.Builder, ((this.Offset + 4) | 0), this._processedCallSites);
                            $i1._firstItem = true;
                            return $i1;
                        })();
                    }
                    /*CallSiteFormatterContext */ StartObject()
                    {
                        this.Builder.Append$7(/*{*/ 123);
                        return this.IncrementOffset();
                    }
                    /*void */ EndObject()
                    {
                        this.Builder.Append$7(/*}*/ 125);
                    }
                    /*void */ StartProperty(/*string*/ name)
                    {
                        if (!this._firstItem)
                        {
                            this.Builder.Append$7(/*,*/ 44);
                        }
                        else 
                        {
                            this._firstItem = false;
                        }
                        this.Builder.Append$7(/*\"*/ 34).Append$2(name).Append$2("\":");
                    }
                    /*void */ StartArrayItem()
                    {
                        if (!this._firstItem)
                        {
                            this.Builder.Append$7(/*,*/ 44);
                        }
                        else 
                        {
                            this._firstItem = false;
                        }
                    }
                    /*void */ WriteProperty(/*string*/ name, /*object?*/ value)
                    {
                        this.StartProperty(name);
                        if (value !== null)
                        {
                            this.Builder.Append$2(" \"").Append$19(value).Append$7(/*\"*/ 34);
                        }
                        else 
                        {
                            this.Builder.Append$2("null");
                        }
                    }
                    /*CallSiteFormatterContext */ StartArray()
                    {
                        this.Builder.Append$7(/*[*/ 91);
                        return this.IncrementOffset();
                    }
                    /*void */ EndArray()
                    {
                        this.Builder.Append$7(/*]*/ 93);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._processedCallSites = this._processedCallSites;
                        copy._firstItem = this._firstItem;
                        copy.Offset = this.Offset;
                        copy.Builder = this.Builder;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._processedCallSites = null;
                        this._firstItem = false;
                    }
                    static $h = 131076;
                    static $z = 13;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25769934852,"f":1},"n":"Offset","d":131076,"h":21474967556,"f":1},{"p":122945537,"g":{"r":0,"d":0,"h":38654836740,"f":1},"n":"Builder","d":131076,"h":34359869444,"f":1}],"m":[{"r":262145,"p":[{"n":"serviceCallSite","p":2424836}],"n":"ShouldFormat","d":131076,"h":42949804036,"f":1},{"r":131076,"n":"IncrementOffset","d":131076,"h":47244771332,"f":1},{"r":131076,"n":"StartObject","d":131076,"h":51539738628,"f":1},{"r":65537,"n":"EndObject","d":131076,"h":55834705924,"f":1},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"StartProperty","d":131076,"h":60129673220,"f":1},{"r":65537,"n":"StartArrayItem","d":131076,"h":64424640516,"f":1},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"WriteProperty","d":131076,"h":68719607812,"f":1},{"r":131076,"n":"StartArray","d":131076,"h":73014575108,"f":1},{"r":65537,"n":"EndArray","d":131076,"h":77309542404,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h,"n":"_processedCallSites","d":131076,"h":4295098372,"f":2},{"t":262145,"n":"_firstItem","d":131076,"h":12885032964,"f":2}],"c":[{"p":[{"n":"builder","p":122945537},{"n":"offset","p":655361},{"n":"processedCallSites","p":$.$spc.System.Collections.Generic.HashSet$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCallSite).$h}],"n":".ctor","o":"$ctor$2","d":131076,"h":8590065668,"f":1},{"n":".ctor","o":"$ctor$3","d":131076,"h":81604509700,"f":1}],"d":65540,"h":131076}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext`; }
                }, $cls, ($v) => $cls.$_CallSiteFormatterContext = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter().$ctor$2();
                }
            }
            static $h = 65540;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":1310721,"p":[{"n":"callSite","p":2424836}],"n":"Format","d":65540,"h":12884967428,"f":1},{"r":131073,"p":[{"n":"constructorCallSite","p":1376260},{"n":"argument","p":131076}],"n":"VisitConstructor","d":65540,"h":17179934724,"f":32772},{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":131076}],"n":"VisitCallSiteMain","d":65540,"h":21474902020,"f":32772},{"r":131073,"p":[{"n":"constantCallSite","p":1310724},{"n":"argument","p":131076}],"n":"VisitConstant","d":65540,"h":25769869316,"f":32772},{"r":131073,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"argument","p":131076}],"n":"VisitServiceProvider","d":65540,"h":30064836612,"f":32772},{"r":131073,"p":[{"n":"enumerableCallSite","p":1703940},{"n":"argument","p":131076}],"n":"VisitIEnumerable","d":65540,"h":34359803908,"f":32772},{"r":131073,"p":[{"n":"factoryCallSite","p":1638404},{"n":"argument","p":131076}],"n":"VisitFactory","d":65540,"h":38654771204,"f":32772}],"l":[{"t":65540,"n":"Instance","d":65540,"h":4295032836,"f":40}],"c":[{"n":".ctor","o":"$ctor$2","d":65540,"h":8590000132,"f":2}],"j":[131076],"h":65540}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.CallSiteFormatterContext, $.$spc.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver", ($self) => class CallSiteRuntimeResolver extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext, $.$spc.System.Object)
        {
            /*CallSiteRuntimeResolver*/ static Instance = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*object? */ Resolve(/*ServiceCallSite*/ callSite, /*ServiceProviderEngineScope*/ scope)
            {
                let cached;
                if (scope.IsRootScope && $.$is(callSite.Value, $.$spc.System.Object, { set $v(v){ cached = v; } }))
                {
                    return cached;
                }
                return this.VisitCallSite(callSite, (() =>
                {
                    //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                    const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                    const $i1 = new $t1();
                    $i1.Scope = scope;
                    return $i1;
                })());
            }
            /*object? */ VisitDisposeCache(/*ServiceCallSite*/ transientCallSite, /*RuntimeResolverContext*/ context)
            {
                return context.Scope.CaptureDisposable(this.VisitCallSiteMain(transientCallSite, context.Clone()));
            }
            /*object */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*RuntimeResolverContext*/ context)
            {
                /*object?[]*/ let parameterValues;
                if (constructorCallSite.ParameterCallSites.length === 0)
                {
                    parameterValues = $.$spc.System.Array.Empty($.$spc.System.Object);
                }
                else 
                {
                    parameterValues = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [constructorCallSite.ParameterCallSites.length], null);
                    for(/*int*/ let index = 0; index < parameterValues.length; index++)
                    {
                        $.$spc.System.Array.$WriteT1.call(parameterValues, this.VisitCallSite($.$spc.System.Array.$ReadT1.call(constructorCallSite.ParameterCallSites, index), context.Clone()), index);
                    }
                }
                return constructorCallSite.ConstructorInfo.Invoke$3(33554432/*BindingFlags.DoNotWrapExceptions*/, null, parameterValues, null);
            }
            /*object? */ VisitRootCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context)
            {
                let value;
                if ($.$is(callSite.Value, $.$spc.System.Object, { set $v(v){ value = v; } }))
                {
                    return value;
                }
                /*var*/ let lockType = 2/*RuntimeResolverLock.Root*/;
                /*ServiceProviderEngineScope*/ let serviceProviderEngine = context.Scope.RootProvider.Root;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(callSite)
                    {
                        let callSiteValue;
                        if ($.$is(callSite.Value, $.$spc.System.Object, { set $v(v){ callSiteValue = v; } }))
                        {
                            return callSiteValue;
                        }
                        /*object?*/ let resolved = this.VisitCallSiteMain(callSite, (() =>
                        {
                            //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                            const $t1 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                            const $i1 = new $t1();
                            $i1.Scope = serviceProviderEngine;
                            $i1.AcquiredLocks = context.AcquiredLocks | lockType;
                            return $i1;
                        })());
                        serviceProviderEngine.CaptureDisposable(resolved);
                        callSite.Value = resolved;
                        return resolved;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(callSite)
                }
            }
            /*object? */ VisitScopeCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context)
            {
                return context.Scope.IsRootScope ? this.VisitRootCache(callSite, context.Clone()) : this.VisitCache(callSite, context.Clone(), context.Scope, 1/*RuntimeResolverLock.Scope*/);
            }
            /*object? */ VisitCache(/*ServiceCallSite*/ callSite, /*RuntimeResolverContext*/ context, /*ServiceProviderEngineScope*/ serviceProviderEngine, /*RuntimeResolverLock*/ lockType)
            {
                /*bool*/ let lockTaken = false;
                /*object*/ let sync = serviceProviderEngine.Sync;
                /*Dictionary<ServiceCacheKey, object?>*/ let resolvedServices = serviceProviderEngine.ResolvedServices;
                if ((context.AcquiredLocks & lockType) === 0)
                {
                    $.$spc.System.Threading.Monitor.Enter$1(sync, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                }
                try
                {
                    /*object?*/ let resolved;
                    if (resolvedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => resolved, ($v) => resolved = $v, $.$spc.System.Object)))
                    {
                        return resolved;
                    }
                    resolved = this.VisitCallSiteMain(callSite, (() =>
                    {
                        //new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext()
                        const $t2 = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext;
                        const $i2 = new $t2();
                        $i2.Scope = serviceProviderEngine;
                        $i2.AcquiredLocks = context.AcquiredLocks | lockType;
                        return $i2;
                    })());
                    serviceProviderEngine.CaptureDisposable(resolved);
                    resolvedServices.Add(callSite.Cache.Key, resolved);
                    return resolved;
                }
                finally
                {
                    {
                        if (lockTaken)
                        {
                            $.$spc.System.Threading.Monitor.Exit(sync);
                        }
                    }
                }
            }
            /*object? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*RuntimeResolverContext*/ context)
            {
                return constantCallSite.DefaultValue;
            }
            /*object */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*RuntimeResolverContext*/ context)
            {
                return context.Scope;
            }
            /*object */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*RuntimeResolverContext*/ context)
            {
                /*Array*/ let array = CreateArray(enumerableCallSite.ItemType, enumerableCallSite.ServiceCallSites.length);
                for(/*int*/ let index = 0; index < enumerableCallSite.ServiceCallSites.length; index++)
                {
                    /*object?*/ let value = this.VisitCallSite($.$spc.System.Array.$ReadT1.call(enumerableCallSite.ServiceCallSites, index), context.Clone());
                    array.SetValue(value, index);
                }
                return array;
                /*static Array*/  function CreateArray(/*Type*/ elementType, /*int*/ length)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider.VerifyAotCompatibility || !elementType.IsValueType, "VerifyAotCompatibility=true will throw during building the IEnumerableCallSite if elementType is a ValueType.");
                    return $.$spc.System.Array.CreateInstance(elementType, length);
                }
            }
            /*object */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*RuntimeResolverContext*/ context)
            {
                return factoryCallSite.Factory.Invoke(context.Scope);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver().$ctor$2();
                }
            }
            static $h = 983044;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":983044,"g":{"r":0,"d":0,"h":12885884932,"f":33},"n":"Instance","d":983044,"h":8590917636,"f":33}],"m":[{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"scope","p":2818052}],"n":"Resolve","d":983044,"h":21475819524,"f":1},{"r":131073,"p":[{"n":"transientCallSite","p":2424836},{"n":"context","p":2162692}],"n":"VisitDisposeCache","d":983044,"h":25770786820,"f":32772},{"r":131073,"p":[{"n":"constructorCallSite","p":1376260},{"n":"context","p":2162692}],"n":"VisitConstructor","d":983044,"h":30065754116,"f":32772},{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"context","p":2162692}],"n":"VisitRootCache","d":983044,"h":34360721412,"f":32772},{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"context","p":2162692}],"n":"VisitScopeCache","d":983044,"h":38655688708,"f":32772},{"r":131073,"p":[{"n":"callSite","p":2424836},{"n":"context","p":2162692},{"n":"serviceProviderEngine","p":2818052},{"n":"lockType","p":2228228}],"n":"VisitCache","d":983044,"h":42950656004,"f":2},{"r":131073,"p":[{"n":"constantCallSite","p":1310724},{"n":"context","p":2162692}],"n":"VisitConstant","d":983044,"h":47245623300,"f":32772},{"r":131073,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"context","p":2162692}],"n":"VisitServiceProvider","d":983044,"h":51540590596,"f":32772},{"r":131073,"p":[{"n":"enumerableCallSite","p":1703940},{"n":"context","p":2162692}],"n":"VisitIEnumerable","d":983044,"h":55835557892,"f":32772},{"r":131073,"p":[{"n":"factoryCallSite","p":1638404},{"n":"context","p":2162692}],"n":"VisitFactory","d":983044,"h":60130525188,"f":32772}],"c":[{"n":".ctor","o":"$ctor$2","d":983044,"h":17180852228,"f":2}],"h":983044}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.RuntimeResolverContext, $.$spc.System.Object); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteRuntimeResolver`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator", ($self) => class CallSiteValidator extends $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($self.$itype$CallSiteValidatorState, $.$spc.System.Type)
        {
            /*ConcurrentDictionary<ServiceCacheKey, Type?>*/ _scopedServices = null;
            /*void */ ValidateCallSite(/*ServiceCallSite*/ callSite)
            {
                return this.VisitCallSite(callSite, new $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState());
            }
            /*void */ ValidateResolution(/*ServiceCallSite*/ callSite, /*IServiceScope*/ scope, /*IServiceScope*/ rootScope)
            {
                /*Type?*/ let scopedService;
                if ($.$spc.System.Object.ReferenceEquals(scope, rootScope) && this._scopedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => scopedService, ($v) => scopedService = $v, $.$spc.System.Type)) && $.$spc.System.Type.op_Inequality$1(scopedService, null))
                {
                    /*Type*/ let serviceType = callSite.ServiceType;
                    if ($.$spc.System.Type.op_Equality$1(serviceType, scopedService))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$1($.$med.System.SR.DirectScopedResolvedFromRootException, callSite.ServiceType, $.$spc.System.String.ToLowerInvariant.call("Scoped")));
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$2($.$med.System.SR.ScopedResolvedFromRootException, callSite.ServiceType, scopedService, $.$spc.System.String.ToLowerInvariant.call("Scoped")));
                }
            }
            /*Type? */ VisitCallSite(/*ServiceCallSite*/ callSite, /*CallSiteValidatorState*/ argument)
            {
                /*Type?*/ let firstScopedServiceInCallSiteTree;
                if (!this._scopedServices.TryGetValue(callSite.Cache.Key, $.$ref(() => firstScopedServiceInCallSiteTree, ($v) => firstScopedServiceInCallSiteTree = $v, $.$spc.System.Type)))
                {
                    firstScopedServiceInCallSiteTree = super.VisitCallSite(callSite, argument.Clone());
                    this._scopedServices.set_Item(callSite.Cache.Key, firstScopedServiceInCallSiteTree);
                }
                if ($.$spc.System.Type.op_Inequality$1(firstScopedServiceInCallSiteTree, null) && argument.Singleton !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$med.System.SR.Format$3($.$med.System.SR.ScopedInSingletonException, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ callSite.ServiceType, argument.Singleton.ServiceType, $.$spc.System.String.ToLowerInvariant.call("Scoped"), $.$spc.System.String.ToLowerInvariant.call("Singleton") ], null, null)));
                }
                return firstScopedServiceInCallSiteTree;
            }
            /*Type? */ VisitConstructor(/*ConstructorCallSite*/ constructorCallSite, /*CallSiteValidatorState*/ state)
            {
                /*Type?*/ let result = null;
                let $i1 = 0;
                let $arr1 = constructorCallSite.ParameterCallSites;
                while ($i1 < $arr1.length)
                {
                    let parameterCallSite = $arr1[$i1++];
                    /*Type?*/ let scoped = this.VisitCallSite(parameterCallSite, state.Clone());
                    result ??= scoped;
                }
                return result;
            }
            /*Type? */ VisitIEnumerable(/*IEnumerableCallSite*/ enumerableCallSite, /*CallSiteValidatorState*/ state)
            {
                /*Type?*/ let result = null;
                let $i1 = 0;
                let $arr1 = enumerableCallSite.ServiceCallSites;
                while ($i1 < $arr1.length)
                {
                    let serviceCallSite = $arr1[$i1++];
                    /*Type?*/ let scoped = this.VisitCallSite(serviceCallSite, state.Clone());
                    result ??= scoped;
                }
                return result;
            }
            /*Type? */ VisitRootCache(/*ServiceCallSite*/ singletonCallSite, /*CallSiteValidatorState*/ state)
            {
                state.Singleton = singletonCallSite;
                return this.VisitCallSiteMain(singletonCallSite, state.Clone());
            }
            /*Type? */ VisitScopeCache(/*ServiceCallSite*/ scopedCallSite, /*CallSiteValidatorState*/ state)
            {
                if ($.$spc.System.Type.op_Equality$1(scopedCallSite.ServiceType, $.$mxdi.Microsoft.Extensions.DependencyInjection.IServiceScopeFactory.$type))
                {
                    return null;
                }
                this.VisitCallSiteMain(scopedCallSite, state.Clone());
                return scopedCallSite.ServiceType;
            }
            /*Type? */ VisitConstant(/*ConstantCallSite*/ constantCallSite, /*CallSiteValidatorState*/ state)
            {
                return null;
            }
            /*Type? */ VisitServiceProvider(/*ServiceProviderCallSite*/ serviceProviderCallSite, /*CallSiteValidatorState*/ state)
            {
                return null;
            }
            /*Type? */ VisitFactory(/*FactoryCallSite*/ factoryCallSite, /*CallSiteValidatorState*/ state)
            {
                return null;
            }
            static $_CallSiteValidatorState;
            static get CallSiteValidatorState()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator;
                return $cls.$_CallSiteValidatorState ??= $asm.$nstr("$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState", ($self) => class CallSiteValidatorState extends $.$spc.System.ValueType
                {
                    /*ServiceCallSite?*/ Singleton = null;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Singleton = this.Singleton;
                        return copy;
                    }
                    static $h = 1114116;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2424836,"g":{"r":0,"d":0,"h":12886016004,"f":1},"s":{"r":0,"d":0,"h":17180983300,"f":1},"n":"Singleton","d":1114116,"h":8591048708,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1114116,"h":21475950596,"f":1}],"d":1048580,"h":1114116}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState`; }
                }, $cls, ($v) => $cls.$_CallSiteValidatorState = $v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._scopedServices = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Type))().$ctor$1();
            }
            static $h = 1048580;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"callSite","p":2424836}],"n":"ValidateCallSite","d":1048580,"h":8590983172,"f":1},{"r":65537,"p":[{"n":"callSite","p":2424836},{"n":"scope","p":1048579},{"n":"rootScope","p":1048579}],"n":"ValidateResolution","d":1048580,"h":12885950468,"f":1},{"r":142606337,"p":[{"n":"callSite","p":2424836},{"n":"argument","p":1114116}],"n":"VisitCallSite","d":1048580,"h":17180917764,"f":32772},{"r":142606337,"p":[{"n":"constructorCallSite","p":1376260},{"n":"state","p":1114116}],"n":"VisitConstructor","d":1048580,"h":21475885060,"f":32772},{"r":142606337,"p":[{"n":"enumerableCallSite","p":1703940},{"n":"state","p":1114116}],"n":"VisitIEnumerable","d":1048580,"h":25770852356,"f":32772},{"r":142606337,"p":[{"n":"singletonCallSite","p":2424836},{"n":"state","p":1114116}],"n":"VisitRootCache","d":1048580,"h":30065819652,"f":32772},{"r":142606337,"p":[{"n":"scopedCallSite","p":2424836},{"n":"state","p":1114116}],"n":"VisitScopeCache","d":1048580,"h":34360786948,"f":32772},{"r":142606337,"p":[{"n":"constantCallSite","p":1310724},{"n":"state","p":1114116}],"n":"VisitConstant","d":1048580,"h":38655754244,"f":32772},{"r":142606337,"p":[{"n":"serviceProviderCallSite","p":2686980},{"n":"state","p":1114116}],"n":"VisitServiceProvider","d":1048580,"h":42950721540,"f":32772},{"r":142606337,"p":[{"n":"factoryCallSite","p":1638404},{"n":"state","p":1114116}],"n":"VisitFactory","d":1048580,"h":47245688836,"f":32772}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceCacheKey, $.$spc.System.Type).$h,"n":"_scopedServices","d":1048580,"h":4296015876,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1048580,"h":55835623428,"f":1}],"j":[1114116],"h":1048580}; }
            static get $b() { return $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteVisitor$$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator.CallSiteValidatorState, $.$spc.System.Type); }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.ServiceLookup.CallSiteValidator`; }
        });
        
        $asm.$cls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource", ($self) => class DependencyInjectionEventSource extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*DependencyInjectionEventSource*/ static Log = null;
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static ServiceProviderInitialized = 1n;
                    static $h = 327684;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40828929,"n":"ServiceProviderInitialized","d":327684,"h":4295294980,"f":33}],"d":262148,"h":327684}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            /*int*/ static MaxChunkSize = 10240;
            /*List<WeakReference<ServiceProvider>>*/ _providers = null;
            $ctor$5()
            {
                super.$ctor$3(8/*EventSourceSettings.EtwSelfDescribingEventFormat*/);
                {
                }
                return this;
            }
            /*int?*/ _survivingProvidersCount = null;
            /*void */ CallSiteBuilt(/*string*/ serviceType, /*string*/ callSite, /*int*/ chunkIndex, /*int*/ chunkCount, /*int*/ serviceProviderHashCode)
            {
                this.WriteEvent$17(1, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(serviceType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(callSite), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(chunkIndex), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(chunkCount), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(serviceProviderHashCode) ], null, null));
            }
            /*void */ ServiceResolved(/*string*/ serviceType, /*int*/ serviceProviderHashCode)
            {
                this.WriteEvent$10(2, serviceType, serviceProviderHashCode);
            }
            /*void */ ExpressionTreeGenerated(/*string*/ serviceType, /*int*/ nodeCount, /*int*/ serviceProviderHashCode)
            {
                this.WriteEvent$11(3, serviceType, nodeCount, serviceProviderHashCode);
            }
            /*void */ DynamicMethodBuilt(/*string*/ serviceType, /*int*/ methodSize, /*int*/ serviceProviderHashCode)
            {
                this.WriteEvent$11(4, serviceType, methodSize, serviceProviderHashCode);
            }
            /*void */ ScopeDisposed(/*int*/ serviceProviderHashCode, /*int*/ scopedServicesResolved, /*int*/ disposableServices)
            {
                this.WriteEvent$3(5, serviceProviderHashCode, scopedServicesResolved, disposableServices);
            }
            /*void */ ServiceRealizationFailed(/*string?*/ exceptionMessage, /*int*/ serviceProviderHashCode)
            {
                this.WriteEvent$10(6, exceptionMessage, serviceProviderHashCode);
            }
            /*void */ ServiceProviderBuilt(/*int*/ serviceProviderHashCode, /*int*/ singletonServices, /*int*/ scopedServices, /*int*/ transientServices, /*int*/ closedGenericsServices, /*int*/ openGenericsServices)
            {
                this.WriteEvent$17(7, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(serviceProviderHashCode), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(singletonServices), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(scopedServices), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(transientServices), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(closedGenericsServices), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(openGenericsServices) ], null, null));
            }
            /*void */ ServiceProviderDescriptors(/*int*/ serviceProviderHashCode, /*string*/ descriptors, /*int*/ chunkIndex, /*int*/ chunkCount)
            {
                this.WriteEvent$17(8, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(serviceProviderHashCode), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(descriptors), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(chunkIndex), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(chunkCount) ], null, null));
            }
            /*void */ ServiceResolved$1(/*ServiceProvider*/ provider, /*Type*/ serviceType)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.ServiceResolved($.$spc.System.Type.ToString.call(serviceType), $.$spc.System.Object.GetHashCode.call(provider));
                }
            }
            /*void */ CallSiteBuilt$1(/*ServiceProvider*/ provider, /*Type*/ serviceType, /*ServiceCallSite*/ callSite)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    /*string*/ let format = $.$med.Microsoft.Extensions.DependencyInjection.CallSiteJsonFormatter.Instance.Format(callSite);
                    /*int*/ let chunkCount = (($.trunc(format.length / 10240/*MaxChunkSize*/) + (format.length % 10240/*MaxChunkSize*/ > 0 ? 1 : 0)) | 0);
                    /*int*/ let providerHashCode = $.$spc.System.Object.GetHashCode.call(provider);
                    for(/*int*/ let i = 0; i < chunkCount; i++)
                    {
                        this.CallSiteBuilt($.$spc.System.Type.ToString.call(serviceType), $.$spc.System.String.Substring$1.call(format, ((i * 10240/*MaxChunkSize*/) | 0), $.$spc.System.Math.Min$4(10240/*MaxChunkSize*/, ((format.length - ((i * 10240/*MaxChunkSize*/) | 0)) | 0))), i, chunkCount, providerHashCode);
                    }
                }
            }
            /*void */ DynamicMethodBuilt$1(/*ServiceProvider*/ provider, /*Type*/ serviceType, /*int*/ methodSize)
            {
                if (this.IsEnabled$1(5/*EventLevel.Verbose*/, -1n))
                {
                    this.DynamicMethodBuilt($.$spc.System.Type.ToString.call(serviceType), methodSize, $.$spc.System.Object.GetHashCode.call(provider));
                }
            }
            /*void */ ServiceRealizationFailed$1(/*Exception*/ exception, /*int*/ serviceProviderHashCode)
            {
                if (this.IsEnabled$1(2/*EventLevel.Error*/, -1n))
                {
                    this.ServiceRealizationFailed($.$spc.System.Exception.ToString.call(exception), serviceProviderHashCode);
                }
            }
            /*void */ ServiceProviderBuilt$1(/*ServiceProvider*/ provider)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._providers)
                    {
                        /*int*/ let providersCount = this._providers.Count;
                        let spc;
                        if (providersCount > 0 && ($.$is(this._survivingProvidersCount, $.$spc.System.Int32, { set $v(v){ spc = v; } }) ? (providersCount >>> 0) >= ((2 * (spc >>> 0)) >>> 0) : providersCount === this._providers.Capacity))
                        {
                            this._providers.RemoveAll(new ($.$spc.System.Predicate$$($.$spc.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))().$ctor(null, /*static*/ (/*p*/ p) =>
                            {
                                return !p.TryGetTarget($.$discardRef());
                            }));
                            this._survivingProvidersCount = this._providers.Count;
                        }
                        this._providers.Add(new ($.$spc.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider))().$ctor$1(provider));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._providers)
                }
                this.WriteServiceProviderBuilt(provider);
            }
            /*void */ ServiceProviderDisposed(/*ServiceProvider*/ provider)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._providers)
                    {
                        for(/*int*/ let i = ((this._providers.Count - 1) | 0); i >= 0; i--)
                        {
                            /*WeakReference<ServiceProvider>*/ let reference = this._providers.get_Item(i);
                            /*ServiceProvider?*/ let target;
                            if (!reference.TryGetTarget($.$ref(() => target, ($v) => target = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)) || target === provider)
                            {
                                this._providers.RemoveAt(i);
                                if (!(target === null))
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._providers)
                }
            }
            /*void */ WriteServiceProviderBuilt(/*ServiceProvider*/ provider)
            {
                if (this.IsEnabled$1(4/*EventLevel.Informational*/, 1n))
                {
                    /*int*/ let singletonServices = 0;
                    /*int*/ let scopedServices = 0;
                    /*int*/ let transientServices = 0;
                    /*int*/ let closedGenericsServices = 0;
                    /*int*/ let openGenericsServices = 0;
                    /*StringBuilder*/ let descriptorBuilder = new $.$spc.System.Text.StringBuilder().$ctor$3("{ \"descriptors\":[ ");
                    /*bool*/ let firstDescriptor = true;
                    let $i1 = 0;
                    let $arr1 = provider.CallSiteFactory.Descriptors;
                    while ($i1 < $arr1.length)
                    {
                        let descriptor = $arr1[$i1++];
                        if (firstDescriptor)
                        {
                            firstDescriptor = false;
                        }
                        else 
                        {
                            descriptorBuilder.Append$2(", ");
                        }
                        $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource.AppendServiceDescriptor(descriptorBuilder, descriptor);
                        let $switch2 = descriptor.Lifetime;
                        switch($switch2)
                        {
                            case 0/*ServiceLifetime.Singleton*/:
                            singletonServices++;
                            break;
                            case 1/*ServiceLifetime.Scoped*/:
                            scopedServices++;
                            break;
                            case 2/*ServiceLifetime.Transient*/:
                            transientServices++;
                            break;
                        }
                        if (descriptor.ServiceType.IsGenericType)
                        {
                            if (descriptor.ServiceType.IsConstructedGenericType)
                            {
                                closedGenericsServices++;
                            }
                            else 
                            {
                                openGenericsServices++;
                            }
                        }
                    }
                    descriptorBuilder.Append$2(" ] }");
                    /*int*/ let providerHashCode = $.$spc.System.Object.GetHashCode.call(provider);
                    this.ServiceProviderBuilt(providerHashCode, singletonServices, scopedServices, transientServices, closedGenericsServices, openGenericsServices);
                    /*string*/ let descriptorString = $.$spc.System.Text.StringBuilder.ToString.call(descriptorBuilder);
                    /*int*/ let chunkCount = (($.trunc(descriptorString.length / 10240/*MaxChunkSize*/) + (descriptorString.length % 10240/*MaxChunkSize*/ > 0 ? 1 : 0)) | 0);
                    for(/*int*/ let i = 0; i < chunkCount; i++)
                    {
                        this.ServiceProviderDescriptors(providerHashCode, $.$spc.System.String.Substring$1.call(descriptorString, ((i * 10240/*MaxChunkSize*/) | 0), $.$spc.System.Math.Min$4(10240/*MaxChunkSize*/, ((descriptorString.length - ((i * 10240/*MaxChunkSize*/) | 0)) | 0))), i, chunkCount);
                    }
                }
            }
            static /*void */ AppendServiceDescriptor(/*StringBuilder*/ builder, /*ServiceDescriptor*/ descriptor)
            {
                builder.Append$2("{ \"serviceType\": \"");
                builder.Append$19(descriptor.ServiceType);
                builder.Append$2("\", \"lifetime\": \"");
                builder.Append$19($.$box(descriptor.Lifetime, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceLifetime));
                builder.Append$2("\", ");
                if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationType(descriptor))
                {
                    builder.Append$2("\"implementationType\": \"");
                    builder.Append$19($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationType(descriptor));
                }
                else if (!descriptor.IsKeyedService && descriptor.ImplementationFactory !== null)
                {
                    builder.Append$2("\"implementationFactory\": \"");
                    builder.Append$19(descriptor.ImplementationFactory.Method);
                }
                else if (descriptor.IsKeyedService && descriptor.KeyedImplementationFactory !== null)
                {
                    builder.Append$2("\"implementationFactory\": \"");
                    builder.Append$19(descriptor.KeyedImplementationFactory.Method);
                }
                else if ($.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.HasImplementationInstance(descriptor))
                {
                    /*object?*/ let instance = $.$med.Microsoft.Extensions.DependencyInjection.ServiceLookup.ServiceDescriptorExtensions.GetImplementationInstance(descriptor);
                    $.$spc.System.Diagnostics.Debug.Assert$1(instance !== null, "descriptor.ImplementationInstance != null");
                    builder.Append$2("\"implementationInstance\": \"");
                    builder.Append$19($.$spc.System.Object.GetType.call(instance));
                    builder.Append$2(" (instance)");
                }
                else 
                {
                    builder.Append$2("\"unknown\": \"");
                }
                builder.Append$2("\" }");
            }
            /*void */ OnEventCommand(/*EventCommandEventArgs*/ command)
            {
                if (command.Command === -2/*EventCommand.Enable*/)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._providers)
                        {
                            var $en5 = this._providers.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var reference = $en5.Current;
                                {
                                    /*ServiceProvider?*/ let provider;
                                    if (reference.TryGetTarget($.$ref(() => provider, ($v) => provider = $v, $.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))
                                    {
                                        this.WriteServiceProviderBuilt(provider);
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._providers)
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._providers = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$med.Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource().$ctor$5();
                }
            }
            static $h = 262148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41680897,"m":[{"r":65537,"p":[{"n":"serviceType","p":1310721},{"n":"callSite","p":1310721},{"n":"chunkIndex","p":655361},{"n":"chunkCount","p":655361},{"n":"serviceProviderHashCode","p":655361}],"n":"CallSiteBuilt","d":262148,"h":30065033220,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":1,"t":655361}],"n":[{"n":"Level","v":5,"t":40894465}]}]},{"r":65537,"p":[{"n":"serviceType","p":1310721},{"n":"serviceProviderHashCode","p":655361}],"n":"ServiceResolved","d":262148,"h":34360000516,"f":1,"a":[{"t":39911425,"c":4334878721,"a":[{"v":2,"t":655361}],"n":[{"n":"Level","v":5,"t":40894465}]}]},{"r":65537,"p":[{"n":"serviceType","p":1310721},{"n":"nodeCount","p":655361},{"n":"serviceProviderHashCode","p":655361}],"n":"ExpressionTreeGenerated","d":262148,"h":38654967812,"f":1,"a":[{"t":39911425,"c":4334878721,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":5,"t":40894465}]}]},{"r":65537,"p":[{"n":"serviceType","p":1310721},{"n":"methodSize","p":655361},{"n":"serviceProviderHashCode","p":655361}],"n":"DynamicMethodBuilt","d":262148,"h":42949935108,"f":1,"a":[{"t":39911425,"c":4334878721,"a":[{"v":4,"t":655361}],"n":[{"n":"Level","v":5,"t":40894465}]}]},{"r":65537,"p":[{"n":"serviceProviderHashCode","p":655361},{"n":"scopedServicesResolved","p":655361},{"n":"disposableServices","p":655361}],"n":"ScopeDisposed","d":262148,"h":47244902404,"f":1,"a":[{"t":39911425,"c":4334878721,"a":[{"v":5,"t":655361}],"n":[{"n":"Level","v":5,"t":40894465}]}]},{"r":65537,"p":[{"n":"exceptionMessage","p":1310721},{"n":"serviceProviderHashCode","p":655361}],"n":"ServiceRealizationFailed","d":262148,"h":51539869700,"f":1,"a":[{"t":39911425,"c":4334878721,"a":[{"v":6,"t":655361}],"n":[{"n":"Level","v":2,"t":40894465}]}]},{"r":65537,"p":[{"n":"serviceProviderHashCode","p":655361},{"n":"singletonServices","p":655361},{"n":"scopedServices","p":655361},{"n":"transientServices","p":655361},{"n":"closedGenericsServices","p":655361},{"n":"openGenericsServices","p":655361}],"n":"ServiceProviderBuilt","d":262148,"h":55834836996,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":7,"t":655361}],"n":[{"n":"Level","v":4,"t":40894465},{"n":"Keywords","v":1,"t":40828929}]}]},{"r":65537,"p":[{"n":"serviceProviderHashCode","p":655361},{"n":"descriptors","p":1310721},{"n":"chunkIndex","p":655361},{"n":"chunkCount","p":655361}],"n":"ServiceProviderDescriptors","d":262148,"h":60129804292,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":8,"t":655361}],"n":[{"n":"Level","v":4,"t":40894465},{"n":"Keywords","v":1,"t":40828929}]}]},{"r":65537,"p":[{"n":"provider","p":3014660},{"n":"serviceType","p":142606337}],"n":"ServiceResolved","o":"@$1","d":262148,"h":64424771588,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"provider","p":3014660},{"n":"serviceType","p":142606337},{"n":"callSite","p":2424836}],"n":"CallSiteBuilt","o":"@$1","d":262148,"h":68719738884,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"provider","p":3014660},{"n":"serviceType","p":142606337},{"n":"methodSize","p":655361}],"n":"DynamicMethodBuilt","o":"@$1","d":262148,"h":73014706180,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"exception","p":47185921},{"n":"serviceProviderHashCode","p":655361}],"n":"ServiceRealizationFailed","o":"@$1","d":262148,"h":77309673476,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"provider","p":3014660}],"n":"ServiceProviderBuilt","o":"@$1","d":262148,"h":81604640772,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"provider","p":3014660}],"n":"ServiceProviderDisposed","d":262148,"h":85899608068,"f":1,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"provider","p":3014660}],"n":"WriteServiceProviderBuilt","d":262148,"h":90194575364,"f":2,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"descriptor","p":1638403}],"n":"AppendServiceDescriptor","d":262148,"h":94489542660,"f":34,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"command","p":40239105}],"n":"OnEventCommand","d":262148,"h":98784509956,"f":32772}],"l":[{"t":262148,"n":"Log","d":262148,"h":4295229444,"f":33},{"t":655361,"n":"MaxChunkSize","d":262148,"h":12885164036,"f":34},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$med.Microsoft.Extensions.DependencyInjection.ServiceProvider)).$h,"n":"_providers","d":262148,"h":17180131332,"f":2},{"t":$.$typeNullable($.$spc.System.Int32).$h,"n":"_survivingProvidersCount","d":262148,"h":25770065924,"f":2}],"c":[{"n":".ctor","o":"$ctor$5","d":262148,"h":21475098628,"f":2}],"i":[57475073],"j":[327684],"h":262148,"a":[{"t":42008577,"c":55876583425,"n":[{"n":"Name","v":"Microsoft-Extensions-DependencyInjection","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.DependencyInjectionEventSource`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions"))