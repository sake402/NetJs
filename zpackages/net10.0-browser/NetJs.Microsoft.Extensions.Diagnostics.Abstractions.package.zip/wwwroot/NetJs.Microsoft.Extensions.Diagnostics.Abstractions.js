
//--TRIMMABLE-BOUNDARY-START(91)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    let $LBjOSh;
    let $UdhmQj;
    let $RehDLj;
    let $XrBRVh;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", 
    {
  "h": 91,
  "f": "Microsoft.Extensions.Diagnostics.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Diagnostics.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Diagnostics.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131163)
        $asm.$cls(`$meda.MEDM.IMetricsListener`, ($self) => class IMetricsListener
        {
            static $h = 131163;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064902235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590065755,
        "f": 50331905
      },
      "n": "Name",
      "o": "MEDM$IMetricsListener$Name",
      "d": 131163,
      "h": 30064902235,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30064902235)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000347),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 262235
        }
      ],
      "n": "Initialize",
      "o": "MEDM$IMetricsListener$Initialize",
      "d": 131163,
      "h": 17180000347,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180000347),
//--TRIMMABLE-BOUNDARY-START(21474967643),
    {
      "r": 262145,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "userState",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "InstrumentPublished",
      "o": "MEDM$IMetricsListener$InstrumentPublished",
      "d": 131163,
      "h": 21474967643,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474967643),
//--TRIMMABLE-BOUNDARY-START(25769934939),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "userState",
          "p": 131073
        }
      ],
      "n": "MeasurementsCompleted",
      "o": "MEDM$IMetricsListener$MeasurementsCompleted",
      "d": 131163,
      "h": 25769934939,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25769934939),
//--TRIMMABLE-BOUNDARY-START(12885033051),
    {
      "r": 327771,
      "n": "GetMeasurementHandlers",
      "o": "MEDM$IMetricsListener$GetMeasurementHandlers",
      "d": 131163,
      "h": 12885033051,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885033051)
  ],
  "h": 131163
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}IMetricsListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131163)
        
        

        //--TRIMMABLE-BOUNDARY-START(65627)
        $asm.$cls(`$meda.MEDM.IMetricsBuilder`, ($self) => class IMetricsBuilder
        {
            static $h = 65627;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12884967515),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590000219,
        "f": 50331905
      },
      "n": "Services",
      "o": "MEDM$IMetricsBuilder$Services",
      "d": 65627,
      "h": 12884967515,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12884967515)
  ],
  "h": 65627
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}IMetricsBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65627)
        
        

        //--TRIMMABLE-BOUNDARY-START(262235)
        $asm.$cls(`$meda.MEDM.IObservableInstrumentsSource`, ($self) => class IObservableInstrumentsSource
        {
            static $h = 262235;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229531),
    {
      "r": 65537,
      "n": "RecordObservableInstruments",
      "o": "MEDM$IObservableInstrumentsSource$RecordObservableInstruments",
      "d": 262235,
      "h": 4295229531,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229531)
  ],
  "h": 262235
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}IObservableInstrumentsSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262235)
        
        

        //--TRIMMABLE-BOUNDARY-START(589915)
        $asm.$cls(`$meda.MEI.TypeNameHelper`, ($self) => class TypeNameHelper
        {
            //--TRIMMABLE-BOUNDARY-START(12885491803)
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            //--TRIMMABLE-BOUNDARY-END(12885491803)
            
            //--TRIMMABLE-BOUNDARY-START(4295557211)
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            //--TRIMMABLE-BOUNDARY-END(4295557211)
            
            //--TRIMMABLE-BOUNDARY-START(17180459099)
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return item === null ? null : $.$meda.MEI.TypeNameHelper.GetTypeDisplayName$1($.$$.S.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459099)
            
            //--TRIMMABLE-BOUNDARY-START(21475426395)
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$meda.MEI.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.ST.StringBuilder), type, $.$ref(() => new $.$meda.MEI.TypeNameHelper.DisplayNameOptions().$ctor$3(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                return name ?? (builder?.ToString() ?? null) ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426395)
            
            //--TRIMMABLE-BOUNDARY-START(34360328283)
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*string?*/ let builtInName;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$$.ST.StringBuilder().$ctor$1();
                    $.$meda.MEI.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$$.ST.StringBuilder().$ctor$1();
                    $.$meda.MEI.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$meda.MEI.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$$.S.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$21(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$21(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$$.S.String.Replace.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$21(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328283)
            
            //--TRIMMABLE-BOUNDARY-START(25770393691)
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$meda.MEI.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.ST.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$5(/*[*/ 91);
                    builder.Append$4(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$5(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770393691)
            
            //--TRIMMABLE-BOUNDARY-START(30065360987)
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$meda.MEI.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$5(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$$.S.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$21(type.Namespace);
                        builder.Append$5(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$$.S.String.IndexOf$3.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$21(type.Name);
                    return;
                }
                builder.Append$20(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$5(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$meda.MEI.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.ST.StringBuilder), $.$$.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$5(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$$.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$5(/* */ 32);
                        }
                    }
                    builder.Append$5(/*>*/ 62);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065360987)
            
            //--TRIMMABLE-BOUNDARY-START(655451)
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$meda.MEI.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr(`$meda.MEI.TypeNameHelper.DisplayNameOptions`, ($self) => class DisplayNameOptions extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770459227)
                    $ctor$3(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770459227);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459227)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426523)
                    /*bool*/ FullName = false;
                    //--TRIMMABLE-BOUNDARY-END(30065426523)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015099483)
                    /*bool*/ IncludeGenericParameters = false;
                    //--TRIMMABLE-BOUNDARY-END(73015099483)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720132187)
                    /*bool*/ IncludeGenericParameterNames = false;
                    //--TRIMMABLE-BOUNDARY-END(68720132187)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310066779)
                    /*char*/ NestedTypeDelimiter = 0;
                    //--TRIMMABLE-BOUNDARY-END(77310066779)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491931)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475491931);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491931)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491931)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475491931)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    static $h = 655451;
                    static $z = 5;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065426523),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361115,
        "f": 50331649
      },
      "n": "FullName",
      "d": 655451,
      "h": 30065426523,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065426523),
//--TRIMMABLE-BOUNDARY-START(73015099483),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835230299,
        "f": 50331649
      },
      "n": "IncludeGenericParameters",
      "d": 655451,
      "h": 73015099483,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015099483),
//--TRIMMABLE-BOUNDARY-START(68720132187),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245295707,
        "f": 50331649
      },
      "n": "IncludeGenericParameterNames",
      "d": 655451,
      "h": 68720132187,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720132187),
//--TRIMMABLE-BOUNDARY-START(77310066779),
    {
      "p": 458753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425164891,
        "f": 50331649
      },
      "n": "NestedTypeDelimiter",
      "d": 655451,
      "h": 77310066779,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310066779)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770459227),
    {
      "p": [
        {
          "n": "fullName",
          "p": 262145
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145
        },
        {
          "n": "includeGenericParameters",
          "p": 262145
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655451,
      "h": 25770459227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459227),
//--TRIMMABLE-BOUNDARY-START(21475491931),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655451,
      "h": 21475491931,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491931)
  ],
  "d": 589915,
  "h": 655451
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.TypeNameHelper+DisplayNameOptions`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}TypeNameHelper${separator}DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655451)
            
            //--TRIMMABLE-BOUNDARY-START(8590524507)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557211)
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.Type, $.$$.S.String)()
                        const $t10 = $.$$.SCG.Dictionary$$$($.$$.S.Type, $.$$.S.String);
                        const $i10 = new $t10();
                        $i10.$ctor$1();
                        $i10.Add($.$$.S.Void.$type, "void");
                        $i10.Add($.$$.S.Boolean.$type, "bool");
                        $i10.Add($.$$.S.Byte.$type, "byte");
                        $i10.Add($.$$.S.Char.$type, "char");
                        $i10.Add($.$$.S.Decimal.$type, "decimal");
                        $i10.Add($.$$.S.Double.$type, "double");
                        $i10.Add($.$$.S.Single.$type, "float");
                        $i10.Add($.$$.S.Int32.$type, "int");
                        $i10.Add($.$$.S.Int64.$type, "long");
                        $i10.Add($.$$.S.Object.$type, "object");
                        $i10.Add($.$$.S.SByte.$type, "sbyte");
                        $i10.Add($.$$.S.Int16.$type, "short");
                        $i10.Add($.$$.S.String.$type, "string");
                        $i10.Add($.$$.S.UInt32.$type, "uint");
                        $i10.Add($.$$.S.UInt64.$type, "ulong");
                        $i10.Add($.$$.S.UInt16.$type, "ushort");
                        return $i10;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295557211)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590524507)
            
            static $h = 589915;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459099),
    {
      "r": 1310721,
      "p": [
        {
          "n": "item",
          "p": 131073
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetTypeDisplayName",
      "d": 589915,
      "h": 17180459099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180459099),
//--TRIMMABLE-BOUNDARY-START(21475426395),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "includeGenericParameters",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753,
          "f": 65,
          "v": "\u002B"
        }
      ],
      "n": "GetTypeDisplayName",
      "o": "@$1",
      "d": 589915,
      "h": 21475426395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475426395),
//--TRIMMABLE-BOUNDARY-START(34360328283),
    {
      "r": 1310721,
      "p": [
        {
          "n": "builder",
          "p": 167837697,
          "f": 4
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 655451,
          "f": 8
        }
      ],
      "n": "ProcessType",
      "d": 589915,
      "h": 34360328283,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360328283),
//--TRIMMABLE-BOUNDARY-START(25770393691),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "options",
          "p": 655451,
          "f": 8
        }
      ],
      "n": "ProcessArrayType",
      "d": 589915,
      "h": 25770393691,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770393691),
//--TRIMMABLE-BOUNDARY-START(30065360987),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167837697
        },
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "genericArguments",
          "p": $.$typeArray($.$$.S.Type).$h
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "options",
          "p": 655451,
          "f": 8
        }
      ],
      "n": "ProcessGenericType",
      "d": 589915,
      "h": 30065360987,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065360987)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491803),
    {
      "t": 458753,
      "n": "DefaultNestedTypeDelimiter",
      "d": 589915,
      "h": 12885491803,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885491803),
//--TRIMMABLE-BOUNDARY-START(4295557211),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.Type, $.$$.S.String).$h,
      "n": "_builtInTypeNames",
      "d": 589915,
      "h": 4295557211,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295557211)
  ],
  "h": 589915
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$meda.MEI.TypeNameHelper.DisplayNameOptions ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.TypeNameHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}TypeNameHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589915)
        
        

        //--TRIMMABLE-BOUNDARY-START(720987)
        $asm.$cls(`$meda.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(85900066907)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(85900066907)
            
            //--TRIMMABLE-BOUNDARY-START(77310132315)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(77310132315)
            
            //--TRIMMABLE-BOUNDARY-START(81605099611)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$meda.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Diagnostics.Abstractions", $.$meda.S.SR.$type.Assembly);
                    $.$meda.S.SR.s_resourceManager = temp;
                }
                return $.$meda.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099611)
            
            //--TRIMMABLE-BOUNDARY-START(8590655579)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$meda.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$meda.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655579)
            
            //--TRIMMABLE-BOUNDARY-START(90195034203)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(90195034203)
            
            //--TRIMMABLE-BOUNDARY-START(73015165019)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015165019);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015165019)
            
            //--TRIMMABLE-BOUNDARY-START(103079936091)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079936091);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936091)
            
            //--TRIMMABLE-BOUNDARY-START(68720197723)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meda.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197723)
            
            //--TRIMMABLE-BOUNDARY-START(64425230427)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$meda.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230427)
            
            //--TRIMMABLE-BOUNDARY-START(38655426651)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38655426651)
            
            //--TRIMMABLE-BOUNDARY-START(34360459355)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360459355)
            
            //--TRIMMABLE-BOUNDARY-START(30065492059)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492059)
            
            //--TRIMMABLE-BOUNDARY-START(42950393947)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meda.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393947)
            
            //--TRIMMABLE-BOUNDARY-START(21475557467)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21475557467)
            
            //--TRIMMABLE-BOUNDARY-START(17180590171)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590171)
            
            //--TRIMMABLE-BOUNDARY-START(12885622875)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$meda.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12885622875)
            
            //--TRIMMABLE-BOUNDARY-START(25770524763)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$meda.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN($.$strNN(resourceFormat) + ", ") + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524763)
            
            //--TRIMMABLE-BOUNDARY-START(4295688283)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034203)
                    this.s_usingResourceKeys = $.$meda.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(90195034203)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295688283)
            
            static $h = 720987;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 720987
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720987)
        
        

        //--TRIMMABLE-BOUNDARY-START(327771)
        $asm.$cls(`$meda.MEDM.MeasurementHandlers`, ($self) => class MeasurementHandlers extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655033435)
            /*MeasurementCallback<byte>?*/ ByteHandler = null;
            //--TRIMMABLE-BOUNDARY-END(38655033435)
            
            //--TRIMMABLE-BOUNDARY-START(184683921499)
            /*MeasurementCallback<short>?*/ ShortHandler = null;
            //--TRIMMABLE-BOUNDARY-END(184683921499)
            
            //--TRIMMABLE-BOUNDARY-START(115964444763)
            /*MeasurementCallback<int>?*/ IntHandler = null;
            //--TRIMMABLE-BOUNDARY-END(115964444763)
            
            //--TRIMMABLE-BOUNDARY-START(120259412059)
            /*MeasurementCallback<long>?*/ LongHandler = null;
            //--TRIMMABLE-BOUNDARY-END(120259412059)
            
            //--TRIMMABLE-BOUNDARY-START(51539935323)
            /*MeasurementCallback<float>?*/ FloatHandler = null;
            //--TRIMMABLE-BOUNDARY-END(51539935323)
            
            //--TRIMMABLE-BOUNDARY-START(47244968027)
            /*MeasurementCallback<double>?*/ DoubleHandler = null;
            //--TRIMMABLE-BOUNDARY-END(47244968027)
            
            //--TRIMMABLE-BOUNDARY-START(42950000731)
            /*MeasurementCallback<decimal>?*/ DecimalHandler = null;
            //--TRIMMABLE-BOUNDARY-END(42950000731)
            
            //--TRIMMABLE-BOUNDARY-START(34360066139)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360066139)
            
            //--TRIMMABLE-BOUNDARY-START(34360066139)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(34360066139)
            
            static $h = 327771;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655033435),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129869915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849346651,
        "f": 83886081
      },
      "n": "ByteHandler",
      "d": 327771,
      "h": 38655033435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033435),
//--TRIMMABLE-BOUNDARY-START(184683921499),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Int16).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669477467,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180388954203,
        "f": 83886081
      },
      "n": "ShortHandler",
      "d": 327771,
      "h": 184683921499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184683921499),
//--TRIMMABLE-BOUNDARY-START(115964444763),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489608283,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209085019,
        "f": 83886081
      },
      "n": "IntHandler",
      "d": 327771,
      "h": 115964444763,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964444763),
//--TRIMMABLE-BOUNDARY-START(120259412059),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079542875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799019611,
        "f": 83886081
      },
      "n": "LongHandler",
      "d": 327771,
      "h": 120259412059,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259412059),
//--TRIMMABLE-BOUNDARY-START(51539935323),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Single).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899673691,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619150427,
        "f": 83886081
      },
      "n": "FloatHandler",
      "d": 327771,
      "h": 51539935323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539935323),
//--TRIMMABLE-BOUNDARY-START(47244968027),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Double).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309739099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029215835,
        "f": 83886081
      },
      "n": "DoubleHandler",
      "d": 327771,
      "h": 47244968027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968027),
//--TRIMMABLE-BOUNDARY-START(42950000731),
    {
      "p": $.$sdd.SDM.MeasurementCallback$$($.$$.S.Decimal).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719804507,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439281243,
        "f": 83886081
      },
      "n": "DecimalHandler",
      "d": 327771,
      "h": 42950000731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000731)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360066139),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327771,
      "h": 34360066139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066139)
  ],
  "h": 327771
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}MeasurementHandlers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327771)
        
        

        //--TRIMMABLE-BOUNDARY-START(458843)
        $asm.$cls(`$meda.MEDM.MetricsBuilderExtensions`, ($self) => class MetricsBuilderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590393435)
            static /*IMetricsBuilder */ AddListener$1(T, /*this IMetricsBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable(builder.MEDM$IMetricsBuilder$Services, $.$mxdi.MED.ServiceDescriptor.Singleton$3($.$meda.MEDM.IMetricsListener, T));
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393435)
            
            //--TRIMMABLE-BOUNDARY-START(4295426139)
            static /*IMetricsBuilder */ AddListener(/*this IMetricsBuilder*/ builder, /*IMetricsListener*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddEnumerable(builder.MEDM$IMetricsBuilder$Services, $.$mxdi.MED.ServiceDescriptor.Singleton$6($.$meda.MEDM.IMetricsListener, listener));
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426139)
            
            //--TRIMMABLE-BOUNDARY-START(17180328027)
            static /*IMetricsBuilder */ ClearListeners(/*this IMetricsBuilder*/ builder)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.RemoveAll$1($.$meda.MEDM.IMetricsListener, builder.MEDM$IMetricsBuilder$Services);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328027)
            
            //--TRIMMABLE-BOUNDARY-START(47245099099)
            static /*IMetricsBuilder */ EnableMetrics$1(/*this IMetricsBuilder*/ builder, /*string?*/ meterName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245099099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$$.S.Action$$($.$meda.MEDM.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$meda.MEDM.MetricsBuilderExtensions.EnableMetrics$3(options, meterName);
                    }, $LBjOSh ??= {"r":65537,"p":[{"n":"options","p":524379}],"n":"","d":458843,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245099099)
            
            //--TRIMMABLE-BOUNDARY-START(42950131803)
            static /*IMetricsBuilder */ EnableMetrics(/*this IMetricsBuilder*/ builder, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950131803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$$.S.Action$$($.$meda.MEDM.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$meda.MEDM.MetricsBuilderExtensions.EnableMetrics$2(options, meterName, instrumentName, listenerName, scopes);
                    }, $UdhmQj ??= {"r":65537,"p":[{"n":"options","p":524379}],"n":"","d":458843,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131803)
            
            //--TRIMMABLE-BOUNDARY-START(55835033691)
            static /*MetricsOptions */ EnableMetrics$3(/*this MetricsOptions*/ options, /*string?*/ meterName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.EnableMetrics$2(options, meterName, null, null, 3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835033691)
            
            //--TRIMMABLE-BOUNDARY-START(51540066395)
            static /*MetricsOptions */ EnableMetrics$2(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540066395);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.AddRule(options, meterName, instrumentName, listenerName, scopes, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540066395)
            
            //--TRIMMABLE-BOUNDARY-START(30065229915)
            static /*IMetricsBuilder */ DisableMetrics$1(/*this IMetricsBuilder*/ builder, /*string?*/ meterName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$$.S.Action$$($.$meda.MEDM.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$meda.MEDM.MetricsBuilderExtensions.DisableMetrics$3(options, meterName);
                    }, $RehDLj ??= {"r":65537,"p":[{"n":"options","p":524379}],"n":"","d":458843,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065229915)
            
            //--TRIMMABLE-BOUNDARY-START(25770262619)
            static /*IMetricsBuilder */ DisableMetrics(/*this IMetricsBuilder*/ builder, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$$.S.Action$$($.$meda.MEDM.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                    {
                        return $.$meda.MEDM.MetricsBuilderExtensions.DisableMetrics$2(options, meterName, instrumentName, listenerName, scopes);
                    }, $XrBRVh ??= {"r":65537,"p":[{"n":"options","p":524379}],"n":"","d":458843,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262619)
            
            //--TRIMMABLE-BOUNDARY-START(38655164507)
            static /*MetricsOptions */ DisableMetrics$3(/*this MetricsOptions*/ options, /*string?*/ meterName)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.DisableMetrics$2(options, meterName, null, null, 3);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655164507)
            
            //--TRIMMABLE-BOUNDARY-START(34360197211)
            static /*MetricsOptions */ DisableMetrics$2(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.MEDM.MetricsBuilderExtensions.AddRule(options, meterName, instrumentName, listenerName, scopes, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360197211)
            
            //--TRIMMABLE-BOUNDARY-START(21475295323)
            static /*IMetricsBuilder */ ConfigureRule(/*this IMetricsBuilder*/ builder, /*Action<MetricsOptions>*/ configureOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$meda.MEDM.MetricsOptions, builder.MEDM$IMetricsBuilder$Services, configureOptions);
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295323)
            
            //--TRIMMABLE-BOUNDARY-START(12885360731)
            static /*MetricsOptions */ AddRule(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes, /*bool*/ enable)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(options, "options");
                options.Rules.SCG$ICollection$$$Add(new $.$meda.MEDM.InstrumentRule().$ctor$1(meterName, instrumentName, listenerName, scopes, enable));
                return options;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360731)
            
            static $h = 458843;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393435),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        }
      ],
      "g": [
        "T"
      ],
      "n": "AddListener",
      "o": "@$1",
      "d": 458843,
      "h": 8590393435,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590393435),
//--TRIMMABLE-BOUNDARY-START(4295426139),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "listener",
          "p": 131163
        }
      ],
      "n": "AddListener",
      "d": 458843,
      "h": 4295426139,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426139),
//--TRIMMABLE-BOUNDARY-START(17180328027),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        }
      ],
      "n": "ClearListeners",
      "d": 458843,
      "h": 17180328027,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180328027),
//--TRIMMABLE-BOUNDARY-START(47245099099),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "meterName",
          "p": 1310721
        }
      ],
      "n": "EnableMetrics",
      "o": "@$1",
      "d": 458843,
      "h": 47245099099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245099099),
//--TRIMMABLE-BOUNDARY-START(42950131803),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "listenerName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "scopes",
          "p": 393307,
          "f": 65,
          "v": 3
        }
      ],
      "n": "EnableMetrics",
      "d": 458843,
      "h": 42950131803,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950131803),
//--TRIMMABLE-BOUNDARY-START(55835033691),
    {
      "r": 524379,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterName",
          "p": 1310721
        }
      ],
      "n": "EnableMetrics",
      "o": "@$3",
      "d": 458843,
      "h": 55835033691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835033691),
//--TRIMMABLE-BOUNDARY-START(51540066395),
    {
      "r": 524379,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "listenerName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "scopes",
          "p": 393307,
          "f": 65,
          "v": 3
        }
      ],
      "n": "EnableMetrics",
      "o": "@$2",
      "d": 458843,
      "h": 51540066395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540066395),
//--TRIMMABLE-BOUNDARY-START(30065229915),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "meterName",
          "p": 1310721
        }
      ],
      "n": "DisableMetrics",
      "o": "@$1",
      "d": 458843,
      "h": 30065229915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065229915),
//--TRIMMABLE-BOUNDARY-START(25770262619),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "listenerName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "scopes",
          "p": 393307,
          "f": 65,
          "v": 3
        }
      ],
      "n": "DisableMetrics",
      "d": 458843,
      "h": 25770262619,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770262619),
//--TRIMMABLE-BOUNDARY-START(38655164507),
    {
      "r": 524379,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterName",
          "p": 1310721
        }
      ],
      "n": "DisableMetrics",
      "o": "@$3",
      "d": 458843,
      "h": 38655164507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655164507),
//--TRIMMABLE-BOUNDARY-START(34360197211),
    {
      "r": 524379,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "listenerName",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "scopes",
          "p": 393307,
          "f": 65,
          "v": 3
        }
      ],
      "n": "DisableMetrics",
      "o": "@$2",
      "d": 458843,
      "h": 34360197211,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360197211),
//--TRIMMABLE-BOUNDARY-START(21475295323),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "configureOptions",
          "p": $.$$.S.Action$$($.$meda.MEDM.MetricsOptions).$h
        }
      ],
      "n": "ConfigureRule",
      "d": 458843,
      "h": 21475295323,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475295323),
//--TRIMMABLE-BOUNDARY-START(12885360731),
    {
      "r": 524379,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721
        },
        {
          "n": "listenerName",
          "p": 1310721
        },
        {
          "n": "scopes",
          "p": 393307
        },
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": "AddRule",
      "d": 458843,
      "h": 12885360731,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885360731)
  ],
  "h": 458843
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}MetricsBuilderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458843)
        
        

        //--TRIMMABLE-BOUNDARY-START(524379)
        $asm.$cls(`$meda.MEDM.MetricsOptions`, ($self) => class MetricsOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475360859)
            /*IList<InstrumentRule>*/ Rules = null;
            //--TRIMMABLE-BOUNDARY-END(21475360859)
            
            //--TRIMMABLE-BOUNDARY-START(8590458971)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458971)
            
            //--TRIMMABLE-BOUNDARY-START(8590458971)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458971)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475360859)
                this.Rules = new ($.$$.SCG.List$$($.$meda.MEDM.InstrumentRule))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(21475360859)
                
            }
            static $h = 524379;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360859),
    {
      "p": $.$$.SCG.IList$$($.$meda.MEDM.InstrumentRule).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393563,
        "f": 50331649
      },
      "n": "Rules",
      "d": 524379,
      "h": 21475360859,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360859)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458971),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524379,
      "h": 8590458971,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458971)
  ],
  "h": 524379
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}MetricsOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524379)
        
        

        //--TRIMMABLE-BOUNDARY-START(196699)
        $asm.$cls(`$meda.MEDM.InstrumentRule`, ($self) => class InstrumentRule extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85899542619)
            /*string?*/ MeterName = null;
            //--TRIMMABLE-BOUNDARY-END(85899542619)
            
            //--TRIMMABLE-BOUNDARY-START(77309608027)
            /*string?*/ InstrumentName = null;
            //--TRIMMABLE-BOUNDARY-END(77309608027)
            
            //--TRIMMABLE-BOUNDARY-START(81604575323)
            /*string?*/ ListenerName = null;
            //--TRIMMABLE-BOUNDARY-END(81604575323)
            
            //--TRIMMABLE-BOUNDARY-START(90194509915)
            /*MeterScope*/ Scopes = 0;
            //--TRIMMABLE-BOUNDARY-END(90194509915)
            
            //--TRIMMABLE-BOUNDARY-START(30064967771)
            /*bool*/ Enable = false;
            //--TRIMMABLE-BOUNDARY-END(30064967771)
            
            //Begin primary constructor
            /*string?*/ meterName = null;
            /*string?*/ instrumentName = null;
            /*string?*/ listenerName = null;
            /*MeterScope*/ scopes = 0;
            /*bool*/ enable = false;
            $ctor$1(/*string?*/meterName, /*string?*/instrumentName, /*string?*/listenerName, /*MeterScope*/scopes, /*bool*/enable)
            {
                this.meterName = meterName;
                this.instrumentName = instrumentName;
                this.listenerName = listenerName;
                this.scopes = scopes;
                this.enable = enable;
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(85899542619)
                //depends on primary constructor parameter
                this.MeterName = this.meterName;
                //--TRIMMABLE-BOUNDARY-END(85899542619)
                
                //--TRIMMABLE-BOUNDARY-START(77309608027)
                //depends on primary constructor parameter
                this.InstrumentName = this.instrumentName;
                //--TRIMMABLE-BOUNDARY-END(77309608027)
                
                //--TRIMMABLE-BOUNDARY-START(81604575323)
                //depends on primary constructor parameter
                this.ListenerName = this.listenerName;
                //--TRIMMABLE-BOUNDARY-END(81604575323)
                
                //--TRIMMABLE-BOUNDARY-START(90194509915)
                //depends on primary constructor parameter
                this.Scopes = this.scopes === 0/*MeterScope.None*/ ? (() =>
                {
        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("scopes", $.$box(this.scopes, $.$meda.MEDM.MeterScope), "The MeterScope must be Global, Local, or both.")        })() : this.scopes;
                //--TRIMMABLE-BOUNDARY-END(90194509915)
                
                //--TRIMMABLE-BOUNDARY-START(30064967771)
                //depends on primary constructor parameter
                this.Enable = this.enable;
                //--TRIMMABLE-BOUNDARY-END(30064967771)
                
                return this
            }
            //End primary constructor
            static $h = 196699;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899542619),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424706139,
        "f": 50331649
      },
      "n": "MeterName",
      "d": 196699,
      "h": 85899542619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899542619),
//--TRIMMABLE-BOUNDARY-START(77309608027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836955,
        "f": 50331649
      },
      "n": "InstrumentName",
      "d": 196699,
      "h": 77309608027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309608027),
//--TRIMMABLE-BOUNDARY-START(81604575323),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834771547,
        "f": 50331649
      },
      "n": "ListenerName",
      "d": 196699,
      "h": 81604575323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604575323),
//--TRIMMABLE-BOUNDARY-START(90194509915),
    {
      "p": 393307,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014640731,
        "f": 50331649
      },
      "n": "Scopes",
      "d": 196699,
      "h": 90194509915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194509915),
//--TRIMMABLE-BOUNDARY-START(30064967771),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902363,
        "f": 50331649
      },
      "n": "Enable",
      "d": 196699,
      "h": 30064967771,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064967771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770000475),
    {
      "p": [
        {
          "n": "meterName",
          "p": 1310721
        },
        {
          "n": "instrumentName",
          "p": 1310721
        },
        {
          "n": "listenerName",
          "p": 1310721
        },
        {
          "n": "scopes",
          "p": 393307
        },
        {
          "n": "enable",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196699,
      "h": 25770000475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000475)
  ],
  "h": 196699
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}InstrumentRule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196699)
        
        

        //--TRIMMABLE-BOUNDARY-START(393307)
        $asm.$str(`$meda.MEDM.MeterScope`, ($self) => class MeterScope extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Global = 1;
            static Local = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Global": 1n,
                    "Local": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295360603)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360603)
            
            //--TRIMMABLE-BOUNDARY-START(4295360603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360603)
            
            static $h = 393307;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180262491),
    {
      "t": 393307,
      "n": "None",
      "d": 393307,
      "h": 17180262491,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262491),
//--TRIMMABLE-BOUNDARY-START(8590327899),
    {
      "t": 393307,
      "n": "Global",
      "d": 393307,
      "h": 8590327899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327899),
//--TRIMMABLE-BOUNDARY-START(12885295195),
    {
      "t": 393307,
      "n": "Local",
      "d": 393307,
      "h": 12885295195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295195)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360603),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393307,
      "h": 4295360603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360603)
  ],
  "h": 393307,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Diagnostics.Metrics.MeterScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Diagnostics${separator}Metrics${separator}MeterScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393307)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"));
})();
//--TRIMMABLE-BOUNDARY-END(91)
