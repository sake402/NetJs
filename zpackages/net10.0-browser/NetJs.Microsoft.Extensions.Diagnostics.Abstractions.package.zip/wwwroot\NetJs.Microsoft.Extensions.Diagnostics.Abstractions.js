
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $mep, $sr, $scc, $scn, $scm, $so, $srw, $srn, $ssc, $sris, $stc, $srsf, $scp, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $scs, $sdp, $sicb, $sci, $sdd, $sdts, $srm, $snnr, $sds, $sre, $sns, $sscr, $sle, $str, $snn, $snsc, $mxdi, $snq, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", 
    {"h":25,"f":"Microsoft.Extensions.Diagnostics.Abstractions","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Diagnostics.Abstractions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Diagnostics.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener", ($self) => class IMetricsListener
        {
            static $h = 131097;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590065689,"f":257},"n":"Name","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Name","d":131097,"h":4295098393,"f":257}],"m":[{"r":65537,"p":[{"n":"source","p":262169}],"n":"Initialize","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Initialize","d":131097,"h":12885032985,"f":257},{"r":262145,"p":[{"n":"instrument","p":5505068},{"n":"userState","p":131073,"f":2}],"n":"InstrumentPublished","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$InstrumentPublished","d":131097,"h":17180000281,"f":257},{"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"userState","p":131073}],"n":"MeasurementsCompleted","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted","d":131097,"h":21474967577,"f":257},{"r":327705,"n":"GetMeasurementHandlers","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$GetMeasurementHandlers","d":131097,"h":25769934873,"f":257}],"h":131097}; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder", ($self) => class IMetricsBuilder
        {
            static $h = 65561;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":786435,"g":{"r":0,"d":0,"h":8590000153,"f":257},"n":"Services","o":"Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services","d":65561,"h":4295032857,"f":257}],"h":65561}; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource", ($self) => class IObservableInstrumentsSource
        {
            static $h = 262169;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"RecordObservableInstruments","o":"Microsoft$Extensions$Diagnostics$Metrics$IObservableInstrumentsSource$RecordObservableInstruments","d":262169,"h":4295229465,"f":257}],"h":262169}; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers", ($self) => class MeasurementHandlers extends $.$spc.System.Object
        {
            /*MeasurementCallback<byte>?*/ ByteHandler = null;
            /*MeasurementCallback<short>?*/ ShortHandler = null;
            /*MeasurementCallback<int>?*/ IntHandler = null;
            /*MeasurementCallback<long>?*/ LongHandler = null;
            /*MeasurementCallback<float>?*/ FloatHandler = null;
            /*MeasurementCallback<double>?*/ DoubleHandler = null;
            /*MeasurementCallback<decimal>?*/ DecimalHandler = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327705;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":12885229593,"f":1},"s":{"r":0,"d":0,"h":17180196889,"f":1},"n":"ByteHandler","d":327705,"h":8590262297,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int16).$h,"g":{"r":0,"d":0,"h":30065098777,"f":1},"s":{"r":0,"d":0,"h":34360066073,"f":1},"n":"ShortHandler","d":327705,"h":25770131481,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":47244967961,"f":1},"s":{"r":0,"d":0,"h":51539935257,"f":1},"n":"IntHandler","d":327705,"h":42950000665,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int64).$h,"g":{"r":0,"d":0,"h":64424837145,"f":1},"s":{"r":0,"d":0,"h":68719804441,"f":1},"n":"LongHandler","d":327705,"h":60129869849,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Single).$h,"g":{"r":0,"d":0,"h":81604706329,"f":1},"s":{"r":0,"d":0,"h":85899673625,"f":1},"n":"FloatHandler","d":327705,"h":77309739033,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Double).$h,"g":{"r":0,"d":0,"h":98784575513,"f":1},"s":{"r":0,"d":0,"h":103079542809,"f":1},"n":"DoubleHandler","d":327705,"h":94489608217,"f":1},{"p":$.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Decimal).$h,"g":{"r":0,"d":0,"h":115964444697,"f":1},"s":{"r":0,"d":0,"h":120259411993,"f":1},"n":"DecimalHandler","d":327705,"h":111669477401,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":327705,"h":124554379289,"f":1}],"h":327705}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers`; }
        });
        
        $asm.$cls("$meda.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$meda.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Diagnostics.Abstractions", $.$meda.System.SR.$type.Assembly);
                    $.$meda.System.SR.s_resourceManager = temp;
                }
                return $.$meda.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$meda.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$meda.System.SR.resourceCulture = value;
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$meda.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$meda.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$meda.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meda.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$meda.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$meda.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$meda.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 720921;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":720921}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Internal.TypeNameHelper", ($self) => class TypeNameHelper
        {
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                return item === null ? null : $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1($.$spc.System.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), type, $.$ref(() => new $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions().$ctor$2(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                const $t2 = builder;
                return name ?? $.$ifnn($t2, ($t) => $.$spc.System.Text.StringBuilder.ToString.call($t)) ?? $.$spc.System.String.Empty;
            }
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*string?*/ let builtInName;
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$meda.Microsoft.Extensions.Internal.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$spc.System.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$2(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$2(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$spc.System.String.Replace$2.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$2(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace$5(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$7(/*[*/ 91);
                    builder.Append(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$7(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$7(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$spc.System.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$2(type.Namespace);
                        builder.Append$7(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$spc.System.String.IndexOf.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$2(type.Name);
                    return;
                }
                builder.Append$3(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$7(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$meda.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), $.$spc.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$7(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$spc.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$7(/* */ 32);
                        }
                    }
                    builder.Append$7(/*>*/ 62);
                }
            }
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                let $cls = $.$meda.Microsoft.Extensions.Internal.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr("$meda.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions", ($self) => class DisplayNameOptions extends $.$spc.System.ValueType
                {
                    $ctor$2(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    /*bool*/ FullName = false;
                    /*bool*/ IncludeGenericParameters = false;
                    /*bool*/ IncludeGenericParameterNames = false;
                    /*char*/ NestedTypeDelimiter = 0;
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.FullName = false;
                        this.IncludeGenericParameters = false;
                        this.IncludeGenericParameterNames = false;
                    }
                    static $h = 655385;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180524569,"f":1},"n":"FullName","d":655385,"h":12885557273,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065426457,"f":1},"n":"IncludeGenericParameters","d":655385,"h":25770459161,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950328345,"f":1},"n":"IncludeGenericParameterNames","d":655385,"h":38655361049,"f":1},{"p":458753,"g":{"r":0,"d":0,"h":55835230233,"f":1},"n":"NestedTypeDelimiter","d":655385,"h":51540262937,"f":1}],"c":[{"p":[{"n":"fullName","p":262145},{"n":"includeGenericParameterNames","p":262145},{"n":"includeGenericParameters","p":262145},{"n":"nestedTypeDelimiter","p":458753}],"n":".ctor","o":"$ctor$2","d":655385,"h":4295622681,"f":1},{"n":".ctor","o":"$ctor$3","d":655385,"h":60130197529,"f":1}],"d":589849,"h":655385}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String)()
                        const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$spc.System.Void.$type, "void");
                        $i1.Add($.$spc.System.Boolean.$type, "bool");
                        $i1.Add($.$spc.System.Byte.$type, "byte");
                        $i1.Add($.$spc.System.Char.$type, "char");
                        $i1.Add($.$spc.System.Decimal.$type, "decimal");
                        $i1.Add($.$spc.System.Double.$type, "double");
                        $i1.Add($.$spc.System.Single.$type, "float");
                        $i1.Add($.$spc.System.Int32.$type, "int");
                        $i1.Add($.$spc.System.Int64.$type, "long");
                        $i1.Add($.$spc.System.Object.$type, "object");
                        $i1.Add($.$spc.System.SByte.$type, "sbyte");
                        $i1.Add($.$spc.System.Int16.$type, "short");
                        $i1.Add($.$spc.System.String.$type, "string");
                        $i1.Add($.$spc.System.UInt32.$type, "uint");
                        $i1.Add($.$spc.System.UInt64.$type, "ulong");
                        $i1.Add($.$spc.System.UInt16.$type, "ushort");
                        return $i1;
                    })();
                }
            }
            static $h = 589849;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"item","p":131073},{"n":"fullName","p":262145,"f":65,"v":true}],"n":"GetTypeDisplayName","d":589849,"h":12885491737,"f":33},{"r":1310721,"p":[{"n":"type","p":142606337},{"n":"fullName","p":262145,"f":65,"v":true},{"n":"includeGenericParameterNames","p":262145,"f":65,"v":false},{"n":"includeGenericParameters","p":262145,"f":65,"v":true},{"n":"nestedTypeDelimiter","p":458753,"f":65,"v":"\u002B"}],"n":"GetTypeDisplayName","o":"@$1","d":589849,"h":17180459033,"f":33},{"r":1310721,"p":[{"n":"builder","p":122945537,"f":4},{"n":"type","p":142606337},{"n":"options","p":655385,"f":8}],"n":"ProcessType","d":589849,"h":21475426329,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"options","p":655385,"f":8}],"n":"ProcessArrayType","d":589849,"h":25770393625,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"genericArguments","p":0},{"n":"length","p":655361},{"n":"options","p":655385,"f":8}],"n":"ProcessGenericType","d":589849,"h":30065360921,"f":34}],"l":[{"t":458753,"n":"DefaultNestedTypeDelimiter","d":589849,"h":4295557145,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String).$h,"n":"_builtInTypeNames","d":589849,"h":8590524441,"f":34}],"j":[655385],"h":589849}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions", ($self) => class MetricsBuilderExtensions
        {
            static /*IMetricsBuilder */ AddListener(T, /*this IMetricsBuilder*/ builder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable(builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, T));
                return builder;
            }
            static /*IMetricsBuilder */ AddListener$1(/*this IMetricsBuilder*/ builder, /*IMetricsListener*/ listener)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddEnumerable(builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceDescriptor.Singleton$5($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, listener));
                return builder;
            }
            static /*IMetricsBuilder */ ClearListeners(/*this IMetricsBuilder*/ builder)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.RemoveAll($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services);
                return builder;
            }
            static /*IMetricsBuilder */ EnableMetrics(/*this IMetricsBuilder*/ builder, /*string?*/ meterName)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.EnableMetrics$2(options, meterName);
                }));
            }
            static /*IMetricsBuilder */ EnableMetrics$1(/*this IMetricsBuilder*/ builder, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.EnableMetrics$3(options, meterName, instrumentName, listenerName, scopes);
                }));
            }
            static /*MetricsOptions */ EnableMetrics$2(/*this MetricsOptions*/ options, /*string?*/ meterName)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.EnableMetrics$3(options, meterName, null, null, 3);
            }
            static /*MetricsOptions */ EnableMetrics$3(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.AddRule(options, meterName, instrumentName, listenerName, scopes, true);
            }
            static /*IMetricsBuilder */ DisableMetrics(/*this IMetricsBuilder*/ builder, /*string?*/ meterName)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.DisableMetrics$2(options, meterName);
                }));
            }
            static /*IMetricsBuilder */ DisableMetrics$1(/*this IMetricsBuilder*/ builder, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.ConfigureRule(builder, new ($.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this,  (/*options*/ options) =>
                {
                    return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.DisableMetrics$3(options, meterName, instrumentName, listenerName, scopes);
                }));
            }
            static /*MetricsOptions */ DisableMetrics$2(/*this MetricsOptions*/ options, /*string?*/ meterName)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.DisableMetrics$3(options, meterName, null, null, 3);
            }
            static /*MetricsOptions */ DisableMetrics$3(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.AddRule(options, meterName, instrumentName, listenerName, scopes, false);
            }
            static /*IMetricsBuilder */ ConfigureRule(/*this IMetricsBuilder*/ builder, /*Action<MetricsOptions>*/ configureOptions)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions, builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, configureOptions);
                return builder;
            }
            static /*MetricsOptions */ AddRule(/*this MetricsOptions*/ options, /*string?*/ meterName, /*string?*/ instrumentName, /*string?*/ listenerName, /*MeterScope*/ scopes, /*bool*/ enable)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule().$ctor$1(meterName, instrumentName, listenerName, scopes, enable), [$.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule]);
                return options;
            }
            static $h = 458777;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65561,"p":[{"n":"builder","p":65561}],"g":["T"],"n":"AddListener","d":458777,"h":4295426073,"f":131105},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"listener","p":131097}],"n":"AddListener","o":"@$1","d":458777,"h":8590393369,"f":33},{"r":65561,"p":[{"n":"builder","p":65561}],"n":"ClearListeners","d":458777,"h":12885360665,"f":33},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"meterName","p":1310721}],"n":"EnableMetrics","d":458777,"h":17180327961,"f":33},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721,"f":65},{"n":"listenerName","p":1310721,"f":65},{"n":"scopes","p":393241,"f":65,"v":3}],"n":"EnableMetrics","o":"@$1","d":458777,"h":21475295257,"f":33},{"r":524313,"p":[{"n":"options","p":524313},{"n":"meterName","p":1310721}],"n":"EnableMetrics","o":"@$2","d":458777,"h":25770262553,"f":33},{"r":524313,"p":[{"n":"options","p":524313},{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721,"f":65},{"n":"listenerName","p":1310721,"f":65},{"n":"scopes","p":393241,"f":65,"v":3}],"n":"EnableMetrics","o":"@$3","d":458777,"h":30065229849,"f":33},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"meterName","p":1310721}],"n":"DisableMetrics","d":458777,"h":34360197145,"f":33},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721,"f":65},{"n":"listenerName","p":1310721,"f":65},{"n":"scopes","p":393241,"f":65,"v":3}],"n":"DisableMetrics","o":"@$1","d":458777,"h":38655164441,"f":33},{"r":524313,"p":[{"n":"options","p":524313},{"n":"meterName","p":1310721}],"n":"DisableMetrics","o":"@$2","d":458777,"h":42950131737,"f":33},{"r":524313,"p":[{"n":"options","p":524313},{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721,"f":65},{"n":"listenerName","p":1310721,"f":65},{"n":"scopes","p":393241,"f":65,"v":3}],"n":"DisableMetrics","o":"@$3","d":458777,"h":47245099033,"f":33},{"r":65561,"p":[{"n":"builder","p":65561},{"n":"configureOptions","p":$.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions).$h}],"n":"ConfigureRule","d":458777,"h":51540066329,"f":34},{"r":524313,"p":[{"n":"options","p":524313},{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721},{"n":"listenerName","p":1310721},{"n":"scopes","p":393241},{"n":"enable","p":262145}],"n":"AddRule","d":458777,"h":55835033625,"f":34}],"h":458777}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions", ($self) => class MetricsOptions extends $.$spc.System.Object
        {
            /*IList<InstrumentRule>*/ Rules = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Rules = new ($.$spc.System.Collections.Generic.List$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule))().$ctor$1();
            }
            static $h = 524313;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule).$h,"g":{"r":0,"d":0,"h":12885426201,"f":1},"n":"Rules","d":524313,"h":8590458905,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":524313,"h":17180393497,"f":1}],"h":524313}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions`; }
        });
        
        $asm.$cls("$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule", ($self) => class InstrumentRule extends $.$spc.System.Object
        {
            /*string?*/ MeterName = null;
            /*string?*/ InstrumentName = null;
            /*string?*/ ListenerName = null;
            /*MeterScope*/ Scopes = 0;
            /*bool*/ Enable = false;
            //Begin primary constructor
            /*string?*/ meterName = null;
            /*string?*/ instrumentName = null;
            /*string?*/ listenerName = null;
            /*MeterScope*/ scopes = 0;
            /*bool*/ enable = false;
            $ctor$1(/*string?*/$meterName, /*string?*/$instrumentName, /*string?*/$listenerName, /*MeterScope*/$scopes, /*bool*/$enable)
            {
                this.meterName = $meterName;
                this.instrumentName = $instrumentName;
                this.listenerName = $listenerName;
                this.scopes = $scopes;
                this.enable = $enable;
                //depends on primary constructor parameter
                this.MeterName = this.meterName;
                //depends on primary constructor parameter
                this.InstrumentName = this.instrumentName;
                //depends on primary constructor parameter
                this.ListenerName = this.listenerName;
                //depends on primary constructor parameter
                this.Scopes = this.scopes === 0/*MeterScope.None*/ ? (() =>
                {
        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("scopes", $.$box(this.scopes, $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MeterScope), "The MeterScope must be Global, Local, or both.")        })() : this.scopes;
                //depends on primary constructor parameter
                this.Enable = this.enable;
                return this
            }
            //End primary constructor
            static $h = 196633;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180065817,"f":1},"n":"MeterName","d":196633,"h":12885098521,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30064967705,"f":1},"n":"InstrumentName","d":196633,"h":25770000409,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42949869593,"f":1},"n":"ListenerName","d":196633,"h":38654902297,"f":1},{"p":393241,"g":{"r":0,"d":0,"h":55834771481,"f":1},"n":"Scopes","d":196633,"h":51539804185,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719673369,"f":1},"n":"Enable","d":196633,"h":64424706073,"f":1}],"c":[{"p":[{"n":"meterName","p":1310721},{"n":"instrumentName","p":1310721},{"n":"listenerName","p":1310721},{"n":"scopes","p":393241},{"n":"enable","p":262145}],"n":".ctor","o":"$ctor$1","d":196633,"h":4295163929,"f":1}],"h":196633}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule`; }
        });
        
        $asm.$str("$meda.Microsoft.Extensions.Diagnostics.Metrics.MeterScope", ($self) => class MeterScope extends $.$spc.System.Enum
        {
            static None = 0;
            static Global = 1;
            static Local = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Global": 1n,
                    "Local": 2n
                };
            }
            static $h = 393241;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":393241,"n":"None","d":393241,"h":4295360537,"f":33},{"t":393241,"n":"Global","d":393241,"h":8590327833,"f":33},{"t":393241,"n":"Local","d":393241,"h":12885295129,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":393241,"h":17180262425,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":393241,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MeterScope`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))