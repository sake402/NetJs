
//--TRIMMABLE-BOUNDARY-START(92)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $meca, $mec, $scn, $scm, $scp, $scs, $sdp, $mwp, $scsl, $sttp, $sdd, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $mxdi, $sca, $meo, $meda, $meoc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Diagnostics", 
    {
  "h": 92,
  "f": "Microsoft.Extensions.Diagnostics",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Diagnostics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Diagnostics",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327772)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory", ($self) => class IMetricListenerConfigurationFactory
        {
            static $h = 327772;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295068),
    {
      "r": 393310,
      "p": [
        {
          "n": "listenerName",
          "p": 1310721
        }
      ],
      "n": "GetConfiguration",
      "o": "Microsoft$Extensions$Diagnostics$Metrics$Configuration$IMetricListenerConfigurationFactory$GetConfiguration",
      "d": 327772,
      "h": 4295295068,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295068)
  ],
  "h": 327772
}; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327772)
        
        
        //--TRIMMABLE-BOUNDARY-START(983132)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConsoleExtensions", ($self) => class MetricsBuilderConsoleExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295950428)
            static /*IMetricsBuilder */ AddDebugConsole(/*this IMetricsBuilder*/ builder)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.AddListener$1($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener, builder);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950428)
            
            static $h = 983132;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950428),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        }
      ],
      "n": "AddDebugConsole",
      "d": 983132,
      "h": 4295950428,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295950428)
  ],
  "h": 983132
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConsoleExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983132)
        
        
        //--TRIMMABLE-BOUNDARY-START(458844)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration", ($self) => class MetricsConfiguration extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426140)
            $ctor$1(/*IConfiguration*/ configuration)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Configuration = $.$firstOf(configuration, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("configuration") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426140)
            
            //--TRIMMABLE-BOUNDARY-START(12885360732)
            /*IConfiguration*/ Configuration = null;
            //--TRIMMABLE-BOUNDARY-END(12885360732)
            
            static $h = 458844;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885360732),
    {
      "p": 393310,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475295324,
        "f": 50331649
      },
      "n": "Configuration",
      "d": 458844,
      "h": 12885360732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885360732)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426140),
    {
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458844,
      "h": 4295426140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426140)
  ],
  "h": 458844
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458844)
        
        
        //--TRIMMABLE-BOUNDARY-START(917596)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConfigurationExtensions", ($self) => class MetricsBuilderConfigurationExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295884892)
            static /*IMetricsBuilder */ AddConfiguration(/*this IMetricsBuilder*/ builder, /*IConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(builder, "builder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configuration, "configuration");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions), builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions().$ctor$1(configuration));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions), builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor$2(configuration));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$7($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration, builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration().$ctor$1(configuration));
                return builder;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884892)
            
            static $h = 917596;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295884892),
    {
      "r": 65627,
      "p": [
        {
          "n": "builder",
          "p": 65627
        },
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "n": "AddConfiguration",
      "d": 917596,
      "h": 4295884892,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295884892)
  ],
  "h": 917596
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConfigurationExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917596)
        
        
        //--TRIMMABLE-BOUNDARY-START(589916)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics", ($self) => class ConsoleMetrics
        {
            //--TRIMMABLE-BOUNDARY-START(4295557212)
            static /*string */ get DebugListenerName()
            {
                return "DebugConsole";
            }
            //--TRIMMABLE-BOUNDARY-END(4295557212)
            
            static $h = 589916;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295557212),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885491804,
        "f": 50331681
      },
      "n": "DebugListenerName",
      "d": 589916,
      "h": 4295557212,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295557212)
  ],
  "h": 589916
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589916)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245276)
        $asm.$cls("$mxdg.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(111670394972)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(111670394972)
            
            //--TRIMMABLE-BOUNDARY-START(103080460380)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(103080460380)
            
            //--TRIMMABLE-BOUNDARY-START(107375427676)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mxdg.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Diagnostics", $.$mxdg.System.SR.$type.Assembly);
                    $.$mxdg.System.SR.s_resourceManager = temp;
                }
                return $.$mxdg.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(107375427676)
            
            //--TRIMMABLE-BOUNDARY-START(8591179868)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mxdg.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555296860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdg.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179868)
            
            //--TRIMMABLE-BOUNDARY-START(94490525788)
            static /*string */ get InvalidScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The meter factory does not allow a custom scope value when creating a meter.";
            }
            //--TRIMMABLE-BOUNDARY-END(94490525788)
            
            //--TRIMMABLE-BOUNDARY-START(98785493084)
            static /*string */ get MoreThanOneWildcard()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720722012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only one wildcard character is allowed in category name.";
            }
            //--TRIMMABLE-BOUNDARY-END(98785493084)
            
            //--TRIMMABLE-BOUNDARY-START(115965362268)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(115965362268)
            
            //--TRIMMABLE-BOUNDARY-START(90195558492)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195558492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195558492)
            
            //--TRIMMABLE-BOUNDARY-START(128850264156)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850264156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mxdg.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850264156)
            
            //--TRIMMABLE-BOUNDARY-START(81605623900)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mxdg.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81605623900)
            
            //--TRIMMABLE-BOUNDARY-START(85900591196)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mxdg.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85900591196)
            
            //--TRIMMABLE-BOUNDARY-START(12886147164)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886147164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(12886147164)
            
            //--TRIMMABLE-BOUNDARY-START(17181114460)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17181114460)
            
            //--TRIMMABLE-BOUNDARY-START(21476081756)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(21476081756)
            
            //--TRIMMABLE-BOUNDARY-START(25771049052)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771049052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdg.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25771049052)
            
            //--TRIMMABLE-BOUNDARY-START(30066016348)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(30066016348)
            
            //--TRIMMABLE-BOUNDARY-START(34360983644)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360983644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34360983644)
            
            //--TRIMMABLE-BOUNDARY-START(38655950940)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655950940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(38655950940)
            
            //--TRIMMABLE-BOUNDARY-START(42950918236)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mxdg.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42950918236)
            
            //--TRIMMABLE-BOUNDARY-START(4296212572)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(115965362268)
                    this.s_usingResourceKeys = $.$mxdg.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(115965362268)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296212572)
            
            static $h = 1245276;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1245276
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245276)
        
        
        //--TRIMMABLE-BOUNDARY-START(65628)
        $asm.$cls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions", ($self) => class MetricsServiceExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295032924)
            static /*IServiceCollection */ AddMetrics$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$sdd.System.Diagnostics.Metrics.IMeterFactory, $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$6($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager, services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions, $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$2($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions, services));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions), $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory, $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory, services);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032924)
            
            //--TRIMMABLE-BOUNDARY-START(8590000220)
            static /*IServiceCollection */ AddMetrics(/*this IServiceCollection*/ services, /*Action<IMetricsBuilder>*/ configure)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(configure, "configure");
                $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.AddMetrics$1(services);
                /*var*/ let builder = new $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder().$ctor$1(services);
                configure.Invoke(builder);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000220)
            
            //--TRIMMABLE-BOUNDARY-START(131164)
            static $_MetricsBuilder;
            static get MetricsBuilder()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_MetricsBuilder ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder", ($self) => class MetricsBuilder extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967644)
                    /*IServiceCollection*/ Services = null;
                    //--TRIMMABLE-BOUNDARY-END(21474967644)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590000219)
                    //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder.Services.get
                    get Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12884967515);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Services;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590000219)
                    
                    //Begin primary constructor
                    /*IServiceCollection*/ services = null;
                    $ctor$1(/*IServiceCollection*/services)
                    {
                        this.services = services;
                        //depends on primary constructor parameter
                        this.Services = this.services;
                        return this
                    }
                    //End primary constructor
                    static $h = 131164;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967644),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000348,
        "f": 50331649
      },
      "n": "Services",
      "d": 131164,
      "h": 21474967644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967644)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098460),
    {
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131164,
      "h": 4295098460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098460)
  ],
  "i": [65627
  ],
  "d": 65628,
  "h": 131164
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder ]; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder`; }
                }, $cls, ($v) => $cls.$_MetricsBuilder = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131164)
            
            //--TRIMMABLE-BOUNDARY-START(196700)
            static $_NoOpOptions;
            static get NoOpOptions()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_NoOpOptions ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions", ($self) => class NoOpOptions extends $.$$.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 196700;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163996),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196700,
      "h": 4295163996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163996)
  ],
  "d": 65628,
  "h": 196700
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions`; }
                }, $cls, ($v) => $cls.$_NoOpOptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196700)
            
            //--TRIMMABLE-BOUNDARY-START(262236)
            static $_SubscriptionActivator;
            static get SubscriptionActivator()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_SubscriptionActivator ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator", ($self) => class SubscriptionActivator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164124)
                    /*void */ Configure(/*NoOpOptions*/ options)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885164124);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.manager.Initialize();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164124)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295688279)
                    //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions>.Configure(Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions)
                    Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295688279);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Configure(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295688279)
                    
                    //Begin primary constructor
                    /*MetricsSubscriptionManager*/ manager = null;
                    $ctor$1(/*MetricsSubscriptionManager*/manager)
                    {
                        this.manager = manager;
                        return this
                    }
                    //End primary constructor
                    static $h = 262236;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164124),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 196700
        }
      ],
      "n": "Configure",
      "d": 262236,
      "h": 12885164124,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164124)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196828),
    {
      "t": 1048668,
      "n": "\u003Cmanager\u003EP",
      "d": 262236,
      "h": 8590196828,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196828)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229532),
    {
      "p": [
        {
          "n": "manager",
          "p": 1048668
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262236,
      "h": 4295229532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229532)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions).$h
  ],
  "d": 65628,
  "h": 262236
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions) ]; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator`; }
                }, $cls, ($v) => $cls.$_SubscriptionActivator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262236)
            
            static $h = 65628;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032924),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddMetrics",
      "o": "@$1",
      "d": 65628,
      "h": 4295032924,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032924),
//--TRIMMABLE-BOUNDARY-START(8590000220),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "configure",
          "p": $.$$.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder).$h
        }
      ],
      "n": "AddMetrics",
      "d": 65628,
      "h": 8590000220,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000220)
  ],
  "j": [131164,196700,262236
  ],
  "h": 65628
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65628)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179740)
        $asm.$cls("$mxdg.System.Diagnostics.DiagnosticsHelper", ($self) => class DiagnosticsHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4296147036)
            static /*bool */ CompareTags(/*IList<KeyValuePair<string, object?>>?*/ sortedTags, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296147036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sortedTags === tags2)
                {
                    return true;
                }
                if (sortedTags === null || tags2 === null)
                {
                    return false;
                }
                /*int*/ let count = sortedTags.System$Collections$Generic$ICollection$$$Count;
                /*int*/ let size = (($.trunc(count / ((($.$$.System.UInt64.$z * 8) | 0))) + 1) | 0);
                /*BitMapper*/ let bitMapper = new $.$mxdg.System.Diagnostics.BitMapper().$ctor$3((size >>> 0) <= 100 ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.UInt64, size, null) : $.$$.System.Span$$($.$$.System.UInt64).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.UInt64), null, [size], null)));
                let tagsCol;
                if ($.$is(tags2, $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), { set $v(v){ tagsCol = v; } }))
                {
                    if (tagsCol.System$Collections$Generic$ICollection$$$Count !== count)
                    {
                        return false;
                    }
                    let secondList;
                    if ($.$is(tagsCol, $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), { set $v(v){ secondList = v; } }))
                    {
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*KeyValuePair<string, object?>*/ let pair = secondList.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                            for(/*int*/ let j = 0; j < count; j++)
                            {
                                if (bitMapper.IsSet(j))
                                {
                                    continue;
                                }
                                /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                                /*int*/ let compareResult = $.$$.System.String.CompareOrdinal$2(pair.Key, pair1.Key);
                                if (compareResult === 0 && $.$$.System.Object.Equals(pair.Value, pair1.Value))
                                {
                                    bitMapper.SetBit(j);
                                    break;
                                }
                                if (compareResult < 0 || j === ((count - 1) | 0))
                                {
                                    return false;
                                }
                            }
                        }
                        return true;
                    }
                }
                /*int*/ let listCount = 0;
                let enumerator = null;
                try
                {
                    enumerator = tags2.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                    while(enumerator.System$Collections$IEnumerator$MoveNext())
                    {
                        listCount++;
                        if (listCount > sortedTags.System$Collections$Generic$ICollection$$$Count)
                        {
                            return false;
                        }
                        /*KeyValuePair<string, object?>*/ let pair = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                        for(/*int*/ let j = 0; j < count; j++)
                        {
                            if (bitMapper.IsSet(j))
                            {
                                continue;
                            }
                            /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)]);
                            /*int*/ let compareResult = $.$$.System.String.CompareOrdinal$2(pair.Key, pair1.Key);
                            if (compareResult === 0 && $.$$.System.Object.Equals(pair.Value, pair1.Value))
                            {
                                bitMapper.SetBit(j);
                                break;
                            }
                            if (compareResult < 0 || j === ((count - 1) | 0))
                            {
                                return false;
                            }
                        }
                    }
                    return listCount === sortedTags.System$Collections$Generic$ICollection$$$Count;
                }
                finally
                {
                    enumerator?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296147036)
            
            static $h = 1179740;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147036),
    {
      "r": 262145,
      "p": [
        {
          "n": "sortedTags",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h
        },
        {
          "n": "tags2",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h
        }
      ],
      "n": "CompareTags",
      "d": 1179740,
      "h": 4296147036,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296147036)
  ],
  "h": 1179740
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticsHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179740)
        
        
        //--TRIMMABLE-BOUNDARY-START(393308)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory", ($self) => class MetricListenerConfigurationFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360604)
            /*IEnumerable<MetricsConfiguration>*/ _configurations = null;
            //--TRIMMABLE-BOUNDARY-END(4295360604)
            
            //--TRIMMABLE-BOUNDARY-START(8590327900)
            $ctor$1(/*IEnumerable<MetricsConfiguration>*/ configurations)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327900);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._configurations = $.$firstOf(configurations, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("configurations") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327900)
            
            //--TRIMMABLE-BOUNDARY-START(12885295196)
            /*IConfiguration */ GetConfiguration(/*string*/ listenerName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(listenerName, "listenerName");
                /*var*/ let configurationBuilder = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationBuilder().$ctor$1();
                var $en2 = this._configurations.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var configuration = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let section = configuration.Configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(listenerName);
                        $.$mec.Microsoft.Extensions.Configuration.ChainedBuilderExtensions.AddConfiguration$1(configurationBuilder, section);
                    }
                }
                return configurationBuilder.Build();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295196)
            
            //--TRIMMABLE-BOUNDARY-START(4295295068)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory.GetConfiguration(string)
            Microsoft$Extensions$Diagnostics$Metrics$Configuration$IMetricListenerConfigurationFactory$GetConfiguration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetConfiguration(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295068)
            
            static $h = 393308;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295196),
    {
      "r": 393310,
      "p": [
        {
          "n": "listenerName",
          "p": 1310721
        }
      ],
      "n": "GetConfiguration",
      "d": 393308,
      "h": 12885295196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295196)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360604),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration).$h,
      "n": "_configurations",
      "d": 393308,
      "h": 4295360604,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360604)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327900),
    {
      "p": [
        {
          "n": "configurations",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393308,
      "h": 8590327900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327900)
  ],
  "i": [327772
  ],
  "h": 393308
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393308)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048668)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager", ($self) => class MetricsSubscriptionManager extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885950556)
            /*ListenerSubscription[]*/ _listeners = null;
            //--TRIMMABLE-BOUNDARY-END(12885950556)
            
            //--TRIMMABLE-BOUNDARY-START(4296015964)
            /*IDisposable?*/ _changeTokenRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(4296015964)
            
            //--TRIMMABLE-BOUNDARY-START(8590983260)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590983260)
            
            //--TRIMMABLE-BOUNDARY-START(17180917852)
            $ctor$1(/*IEnumerable<IMetricsListener>*/ listeners, /*IOptionsMonitor<MetricsOptions>*/ options, /*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180917852);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*var*/ let list = $.$sl.System.Linq.Enumerable.ToList($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, listeners);
                    this._listeners = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription), null, [list.Count], null);
                    for(/*int*/ let i = 0; i < this._listeners.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(this._listeners, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription().$ctor$1(list.get_Item(i), meterFactory), i);
                    }
                    this._changeTokenRegistration = $.$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions.OnChange($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions, options, new ($.$$.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this, this.UpdateRules));
                    this.UpdateRules(options.Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180917852)
            
            //--TRIMMABLE-BOUNDARY-START(25770852444)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.Initialize();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770852444)
            
            //--TRIMMABLE-BOUNDARY-START(30065819740)
            /*void */ UpdateRules(/*MetricsOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return;
                }
                /*var*/ let rules = options.Rules;
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.UpdateRules(rules);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065819740)
            
            //--TRIMMABLE-BOUNDARY-START(21475885148)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._disposed)
                {
                    return;
                }
                this._disposed = true;
                this._changeTokenRegistration?.System$IDisposable$Dispose();
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475885148)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 1048668;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770852444),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1048668,
      "h": 25770852444,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770852444),
//--TRIMMABLE-BOUNDARY-START(30065819740),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 524379
        }
      ],
      "n": "UpdateRules",
      "d": 1048668,
      "h": 30065819740,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065819740),
//--TRIMMABLE-BOUNDARY-START(21475885148),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1048668,
      "h": 21475885148,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885148)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950556),
    {
      "t": $.$typeArray($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription).$h,
      "n": "_listeners",
      "d": 1048668,
      "h": 12885950556,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885950556),
//--TRIMMABLE-BOUNDARY-START(4296015964),
    {
      "t": 90177537,
      "n": "_changeTokenRegistration",
      "d": 1048668,
      "h": 4296015964,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015964),
//--TRIMMABLE-BOUNDARY-START(8590983260),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1048668,
      "h": 8590983260,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983260)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180917852),
    {
      "p": [
        {
          "n": "listeners",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener).$h
        },
        {
          "n": "options",
          "p": $.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions).$h
        },
        {
          "n": "meterFactory",
          "p": 5439534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048668,
      "h": 17180917852,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917852)
  ],
  "i": [90177537
  ],
  "h": 1048668
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048668)
        
        
        //--TRIMMABLE-BOUNDARY-START(720988)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory", ($self) => class DefaultMeterFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688284)
            /*Dictionary<string, List<FactoryMeter>>*/ _cachedMeters = null;
            //--TRIMMABLE-BOUNDARY-END(4295688284)
            
            //--TRIMMABLE-BOUNDARY-START(8590655580)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590655580)
            
            //--TRIMMABLE-BOUNDARY-START(12885622876)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622876);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622876)
            
            //--TRIMMABLE-BOUNDARY-START(17180590172)
            /*Meter */ Create(/*MeterOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(options, "options");
                if (!(options.Scope === null) && !$.$$.System.Object.ReferenceEquals(options.Scope, this))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdg.System.SR.InvalidScope);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(options.Name === null), "options.Name is not null");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._cachedMeters)
                    {
                        if (this._disposed)
                        {
                            throw new $.$$.System.ObjectDisposedException().$ctor$17("DefaultMeterFactory");
                        }
                        /*List<FactoryMeter>?*/ let meterList;
                        if (this._cachedMeters.TryGetValue(options.Name, $.$ref(() => meterList, ($v) => meterList = $v, $.$$.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter))))
                        {
                            var $en5 = meterList.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var meter = $en5.Current;
                                {
                                    if ($.$$.System.String.op_Equality(meter.Version, options.Version) && $.$mxdg.System.Diagnostics.DiagnosticsHelper.CompareTags($.$as(meter.Tags, $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))), options.Tags))
                                    {
                                        return meter;
                                    }
                                }
                            }
                        }
                        else 
                        {
                            meterList = new ($.$$.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter))().$ctor$1();
                            this._cachedMeters.Add(options.Name, meterList);
                        }
                        /*object?*/ let scope = options.Scope;
                        options.Scope = this;
                        /*FactoryMeter*/ let m = new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter().$ctor$5(options);
                        options.Scope = scope;
                        meterList.Add(m);
                        return m;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._cachedMeters)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180590172)
            
            //--TRIMMABLE-BOUNDARY-START(21475557468)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._cachedMeters)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        var $en4 = this._cachedMeters.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var meterList = $en4.Current;
                            {
                                var $en6 = meterList.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var meter = $en6.Current;
                                    {
                                        meter.Release();
                                    }
                                }
                            }
                        }
                        this._cachedMeters.Clear();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._cachedMeters)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475557468)
            
            //--TRIMMABLE-BOUNDARY-START(4300406830)
            //Generated interface implemetation for System.Diagnostics.Metrics.IMeterFactory.Create(System.Diagnostics.Metrics.MeterOptions)
            System$Diagnostics$Metrics$IMeterFactory$Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4300406830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4300406830)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295688284)
                this._cachedMeters = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295688284)
                
            }
            static $h = 720988;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590172),
    {
      "r": 6553646,
      "p": [
        {
          "n": "options",
          "p": 6750254
        }
      ],
      "n": "Create",
      "d": 720988,
      "h": 17180590172,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590172),
//--TRIMMABLE-BOUNDARY-START(21475557468),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720988,
      "h": 21475557468,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557468)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688284),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter)).$h,
      "n": "_cachedMeters",
      "d": 720988,
      "h": 4295688284,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688284),
//--TRIMMABLE-BOUNDARY-START(8590655580),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 720988,
      "h": 8590655580,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622876),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720988,
      "h": 12885622876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622876)
  ],
  "i": [5439534,90177537
  ],
  "h": 720988
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IMeterFactory, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720988)
        
        
        //--TRIMMABLE-BOUNDARY-START(655452)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener", ($self) => class DebugConsoleMetricListener extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885557340)
            /*Timer*/ _timer = null;
            //--TRIMMABLE-BOUNDARY-END(12885557340)
            
            //--TRIMMABLE-BOUNDARY-START(17180524636)
            /*int*/ _timerStarted = 0;
            //--TRIMMABLE-BOUNDARY-END(17180524636)
            
            //--TRIMMABLE-BOUNDARY-START(4295622748)
            /*IObservableInstrumentsSource?*/ _source = null;
            //--TRIMMABLE-BOUNDARY-END(4295622748)
            
            //--TRIMMABLE-BOUNDARY-START(8590590044)
            /*TextWriter?*/ _textWriter = null;
            //--TRIMMABLE-BOUNDARY-END(8590590044)
            
            //--TRIMMABLE-BOUNDARY-START(21475491932)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475491932);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._timer = new $.$$.System.Threading.Timer().$ctor$3(new $.$$.System.Threading.TimerCallback().$ctor(this, this.OnTimer), null, -1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475491932)
            
            //--TRIMMABLE-BOUNDARY-START(60130197596)
            /*string */ get Name()
            {
                return $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics.DebugListenerName;
            }
            //--TRIMMABLE-BOUNDARY-END(60130197596)
            
            //--TRIMMABLE-BOUNDARY-START(47245295708)
            /*bool */ InstrumentPublished(/*Instrument*/ instrument, /*out object?*/ userState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245295708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (instrument.IsObservable && $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._timerStarted, ($v) => this._timerStarted = $v, $.$$.System.Int32), 1) === 0)
                {
                    this._timer.Change$2($.$$.System.TimeSpan.FromSeconds$2(1n), $.$$.System.TimeSpan.FromSeconds$2(1n));
                }
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} Started; Description: ${instrument.Description}.`);
                userState.$v = this;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(47245295708)
            
            //--TRIMMABLE-BOUNDARY-START(55835230300)
            /*void */ MeasurementsCompleted(/*Instrument*/ instrument, /*object?*/ userState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835230300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(userState === this, "userState == this");
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} Stopped.`);
            }
            //--TRIMMABLE-BOUNDARY-END(55835230300)
            
            //--TRIMMABLE-BOUNDARY-START(42950328412)
            /*void */ Initialize(/*IObservableInstrumentsSource*/ source)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950328412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._source = source;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950328412)
            
            //--TRIMMABLE-BOUNDARY-START(38655361116)
            /*MeasurementHandlers */ GetMeasurementHandlers()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655361116);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        //new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers()
                        const $t1 = $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.ByteHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Byte))().$ctor(this, this.MeasurementHandler);
                        $i1.ShortHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Int16))().$ctor(this, this.MeasurementHandler);
                        $i1.IntHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Int32))().$ctor(this, this.MeasurementHandler);
                        $i1.LongHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Int64))().$ctor(this, this.MeasurementHandler);
                        $i1.FloatHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Single))().$ctor(this, this.MeasurementHandler);
                        $i1.DoubleHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Double))().$ctor(this, this.MeasurementHandler);
                        $i1.DecimalHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$$.System.Decimal))().$ctor(this, this.MeasurementHandler);
                        return $i1;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655361116)
            
            //--TRIMMABLE-BOUNDARY-START(51540263004)
            /*void */ MeasurementHandler(T, /*Instrument*/ instrument, /*T*/ measurement, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ tags, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540263004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(state === this, "state == this");
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} ${$.$dsp(measurement, T, ($t) => $t$.$$.System.Object.ToString)} ${instrument.Unit}`);
            }
            //--TRIMMABLE-BOUNDARY-END(51540263004)
            
            //--TRIMMABLE-BOUNDARY-START(68720132188)
            /*void */ WriteLine(/*string*/ output)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let writer = this._textWriter ?? $.$scsl.System.Console.Out;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(writer)
                    {
                        writer.WriteLine$17(output);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(writer)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720132188)
            
            //--TRIMMABLE-BOUNDARY-START(64425164892)
            /*void */ OnTimer(/*object?*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425164892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._source?.Microsoft$Extensions$Diagnostics$Metrics$IObservableInstrumentsSource$RecordObservableInstruments();
            }
            //--TRIMMABLE-BOUNDARY-END(64425164892)
            
            //--TRIMMABLE-BOUNDARY-START(25770459228)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770459228);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._timer.Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770459228)
            
            //--TRIMMABLE-BOUNDARY-START(8590065755)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.Name.get
            get Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065755)
            
            //--TRIMMABLE-BOUNDARY-START(17180000347)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.Initialize(Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Initialize(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000347)
            
            //--TRIMMABLE-BOUNDARY-START(21474967643)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.InstrumentPublished(System.Diagnostics.Metrics.Instrument, out object?)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$InstrumentPublished()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InstrumentPublished(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967643)
            
            //--TRIMMABLE-BOUNDARY-START(25769934939)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.MeasurementsCompleted(System.Diagnostics.Metrics.Instrument, object?)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.MeasurementsCompleted(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25769934939)
            
            //--TRIMMABLE-BOUNDARY-START(12885033051)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.GetMeasurementHandlers()
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$GetMeasurementHandlers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885033051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetMeasurementHandlers(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885033051)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            static $h = 655452;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130197596),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393820,
        "f": 50331649
      },
      "n": "Name",
      "d": 655452,
      "h": 60130197596,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130197596)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245295708),
    {
      "r": 262145,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "userState",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "InstrumentPublished",
      "d": 655452,
      "h": 47245295708,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295708),
//--TRIMMABLE-BOUNDARY-START(55835230300),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "userState",
          "p": 131073
        }
      ],
      "n": "MeasurementsCompleted",
      "d": 655452,
      "h": 55835230300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835230300),
//--TRIMMABLE-BOUNDARY-START(42950328412),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 262235
        }
      ],
      "n": "Initialize",
      "d": 655452,
      "h": 42950328412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328412),
//--TRIMMABLE-BOUNDARY-START(38655361116),
    {
      "r": 327771,
      "n": "GetMeasurementHandlers",
      "d": 655452,
      "h": 38655361116,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655361116),
//--TRIMMABLE-BOUNDARY-START(51540263004),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "measurement",
          "p": (T) => T.$h
        },
        {
          "n": "tags",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "g": [
        "T"
      ],
      "n": "MeasurementHandler",
      "d": 655452,
      "h": 51540263004,
      "f": 16908290
    },
//--TRIMMABLE-BOUNDARY-END(51540263004),
//--TRIMMABLE-BOUNDARY-START(68720132188),
    {
      "r": 65537,
      "p": [
        {
          "n": "output",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "d": 655452,
      "h": 68720132188,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720132188),
//--TRIMMABLE-BOUNDARY-START(64425164892),
    {
      "r": 65537,
      "p": [
        {
          "n": "_",
          "p": 131073
        }
      ],
      "n": "OnTimer",
      "d": 655452,
      "h": 64425164892,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425164892),
//--TRIMMABLE-BOUNDARY-START(25770459228),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655452,
      "h": 25770459228,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459228)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885557340),
    {
      "t": 182845441,
      "n": "_timer",
      "d": 655452,
      "h": 12885557340,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557340),
//--TRIMMABLE-BOUNDARY-START(17180524636),
    {
      "t": 655361,
      "n": "_timerStarted",
      "d": 655452,
      "h": 17180524636,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524636),
//--TRIMMABLE-BOUNDARY-START(4295622748),
    {
      "t": 262235,
      "n": "_source",
      "d": 655452,
      "h": 4295622748,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622748),
//--TRIMMABLE-BOUNDARY-START(8590590044),
    {
      "t": 95682561,
      "n": "_textWriter",
      "d": 655452,
      "h": 8590590044,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590590044)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475491932),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655452,
      "h": 21475491932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475491932)
  ],
  "i": [131163,90177537
  ],
  "h": 655452
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655452)
        
        
        //--TRIMMABLE-BOUNDARY-START(852060)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription", ($self) => class ListenerSubscription extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475688540)
            /*MeterListener*/ _meterListener = null;
            //--TRIMMABLE-BOUNDARY-END(21475688540)
            
            //--TRIMMABLE-BOUNDARY-START(25770655836)
            /*IMetricsListener*/ _metricsListener = null;
            //--TRIMMABLE-BOUNDARY-END(25770655836)
            
            //--TRIMMABLE-BOUNDARY-START(17180721244)
            /*IMeterFactory*/ _meterFactory = null;
            //--TRIMMABLE-BOUNDARY-END(17180721244)
            
            //--TRIMMABLE-BOUNDARY-START(12885753948)
            /*Dictionary<Instrument, object?>*/ _instruments = null;
            //--TRIMMABLE-BOUNDARY-END(12885753948)
            
            //--TRIMMABLE-BOUNDARY-START(30065623132)
            /*IList<InstrumentRule>*/ _rules = null;
            //--TRIMMABLE-BOUNDARY-END(30065623132)
            
            //--TRIMMABLE-BOUNDARY-START(4295819356)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(4295819356)
            
            //--TRIMMABLE-BOUNDARY-START(8590786652)
            /*bool*/ _disposing = false;
            //--TRIMMABLE-BOUNDARY-END(8590786652)
            
            //--TRIMMABLE-BOUNDARY-START(34360590428)
            $ctor$1(/*IMetricsListener*/ metricsListener, /*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360590428);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._metricsListener = metricsListener;
                    this._meterFactory = meterFactory;
                    this._meterListener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360590428)
            
            //--TRIMMABLE-BOUNDARY-START(47245492316)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._meterListener.InstrumentPublished = new ($.$$.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this, this.InstrumentPublished);
                this._meterListener.MeasurementsCompleted = new ($.$$.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$$.System.Object))().$ctor(this, this.MeasurementsCompleted);
                /*var*/ let handlers = this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$GetMeasurementHandlers();
                this._meterListener.SetMeasurementEventCallback($.$$.System.Byte, handlers.ByteHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Int16, handlers.ShortHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Int32, handlers.IntHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Int64, handlers.LongHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Single, handlers.FloatHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Double, handlers.DoubleHandler);
                this._meterListener.SetMeasurementEventCallback($.$$.System.Decimal, handlers.DecimalHandler);
                this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Initialize(this);
                this._meterListener.Start();
            }
            //--TRIMMABLE-BOUNDARY-END(47245492316)
            
            //--TRIMMABLE-BOUNDARY-START(51540459612)
            /*void */ InstrumentPublished(/*Instrument*/ instrument, /*MeterListener*/ _)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540459612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._instruments)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        if (this._instruments.ContainsKey(instrument))
                        {
                            $.$$.System.Diagnostics.Debug.Fail$1("InstrumentPublished called for an instrument we're already listening to.");
                            return;
                        }
                        this.RefreshInstrument(instrument);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459612)
            
            //--TRIMMABLE-BOUNDARY-START(60130394204)
            /*void */ MeasurementsCompleted(/*Instrument*/ instrument, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._instruments)
                    {
                        if (this._disposed && !this._disposing)
                        {
                            return;
                        }
                        /*var*/ let listenerState;
                        if (this._instruments.TryGetValue(instrument, $.$ref(() => listenerState, ($v) => listenerState = $v, $.$$.System.Object)))
                        {
                            this._instruments.Remove$1(instrument);
                            this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted(instrument, listenerState);
                            this._meterListener.DisableMeasurementEvents(instrument);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130394204)
            
            //--TRIMMABLE-BOUNDARY-START(77310263388)
            /*void */ UpdateRules(/*IList<InstrumentRule>*/ rules)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this._instruments)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._rules = rules;
                        /*var*/ let tempListener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                        try
                        {
                            tempListener.InstrumentPublished = new ($.$$.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this,  (/*instrument*/ instrument, /**/ _1) =>
                            {
                                return this.RefreshInstrument(instrument);
                            }, {
  "r": 65537,
  "p": [
    {
      "n": "instrument",
      "p": 5505070
    },
    {
      "n": "_",
      "p": 6684718
    }
  ],
  "n": "",
  "d": 852060,
  "h": 0,
  "f": 17825794
});
                            tempListener.Start();
                        }
                        finally
                        {
                            tempListener?.System$IDisposable$Dispose();
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310263388)
            
            //--TRIMMABLE-BOUNDARY-START(68720328796)
            /*void */ RefreshInstrument(/*Instrument*/ instrument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let state;
                /*var*/ let alreadyEnabled = this._instruments.TryGetValue(instrument, $.$ref(() => state, ($v) => state = $v, $.$$.System.Object));
                /*var*/ let enable = false;
                /*var*/ let rule = this.GetMostSpecificRule(instrument);
                if (rule !== null)
                {
                    enable = rule.Enable;
                }
                if (!enable && alreadyEnabled)
                {
                    this._instruments.Remove$1(instrument);
                    this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted(instrument, state);
                    this._meterListener.DisableMeasurementEvents(instrument);
                }
                else if (enable && !alreadyEnabled)
                {
                    if (this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$InstrumentPublished(instrument, $.$ref(() => state, ($v) => state = $v, $.$$.System.Object)))
                    {
                        this._instruments.Add(instrument, state);
                        this._meterListener.EnableMeasurementEvents(instrument, state);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720328796)
            
            //--TRIMMABLE-BOUNDARY-START(42950525020)
            /*InstrumentRule? */ GetMostSpecificRule(/*Instrument*/ instrument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950525020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*InstrumentRule?*/ let best = null;
                var $en2 = this._rules.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var rule = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription.RuleMatches(rule, instrument, this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Name, this._meterFactory) && $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription.IsMoreSpecific(rule, best, instrument.Meter.Scope === this._meterFactory))
                        {
                            best = rule;
                        }
                    }
                }
                return best;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525020)
            
            //--TRIMMABLE-BOUNDARY-START(73015296092)
            static /*bool */ RuleMatches(/*InstrumentRule*/ rule, /*Instrument*/ instrument, /*string*/ listenerName, /*IMeterFactory*/ meterFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015296092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(rule.ListenerName) && !$.$$.System.String.Equals$2(rule.ListenerName, listenerName, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!$.$$.System.String.IsNullOrEmpty(rule.InstrumentName) && !$.$$.System.String.Equals$2(rule.InstrumentName, instrument.Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!(((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && instrument.Meter.Scope === null) && !(((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && instrument.Meter.Scope === meterFactory))
                {
                    return false;
                }
                /*var*/ let meterName = rule.MeterName;
                if ($.$$.System.String.op_Inequality(meterName, null))
                {
                    /*char*/ let WildcardChar = /***/ 42;
                    /*int*/ let wildcardIndex = $.$$.System.String.IndexOf$3.call(meterName, WildcardChar);
                    if (wildcardIndex >= 0 && $.$$.System.String.IndexOf$1.call(meterName, WildcardChar, ((wildcardIndex + 1) | 0)) >= 0)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mxdg.System.SR.MoreThanOneWildcard);
                    }
                    /*ReadOnlySpan<char>*/ let prefix, suffix;
                    if (wildcardIndex < 0)
                    {
                        prefix = $.$$.System.MemoryExtensions.AsSpan$4(meterName);
                        suffix = new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))();
                    }
                    else 
                    {
                        prefix = $.$$.System.MemoryExtensions.AsSpan$1(meterName, 0, wildcardIndex);
                        suffix = $.$$.System.MemoryExtensions.AsSpan$2(meterName, ((wildcardIndex + 1) | 0));
                    }
                    if (!$.$$.System.MemoryExtensions.StartsWith($.$$.System.MemoryExtensions.AsSpan$4(instrument.Meter.Name), prefix, 5/*StringComparison.OrdinalIgnoreCase*/) || !$.$$.System.MemoryExtensions.EndsWith($.$$.System.MemoryExtensions.AsSpan$4(instrument.Meter.Name), suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(73015296092)
            
            //--TRIMMABLE-BOUNDARY-START(55835426908)
            static /*bool */ IsMoreSpecific(/*InstrumentRule*/ rule, /*InstrumentRule?*/ best, /*bool*/ isLocalScope)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (best === null)
                {
                    return true;
                }
                if (!$.$$.System.String.IsNullOrEmpty(rule.ListenerName) && $.$$.System.String.IsNullOrEmpty(best.ListenerName))
                {
                    return true;
                }
                else if ($.$$.System.String.IsNullOrEmpty(rule.ListenerName) && !$.$$.System.String.IsNullOrEmpty(best.ListenerName))
                {
                    return false;
                }
                if (!$.$$.System.String.IsNullOrEmpty(rule.MeterName))
                {
                    if ($.$$.System.String.IsNullOrEmpty(best.MeterName))
                    {
                        return true;
                    }
                    if (rule.MeterName.length !== best.MeterName.length)
                    {
                        return rule.MeterName.length > best.MeterName.length;
                    }
                }
                else if (!$.$$.System.String.IsNullOrEmpty(best.MeterName))
                {
                    return false;
                }
                if (!$.$$.System.String.IsNullOrEmpty(rule.InstrumentName) && $.$$.System.String.IsNullOrEmpty(best.InstrumentName))
                {
                    return true;
                }
                else if ($.$$.System.String.IsNullOrEmpty(rule.InstrumentName) && !$.$$.System.String.IsNullOrEmpty(best.InstrumentName))
                {
                    return false;
                }
                if (isLocalScope)
                {
                    if (!((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && ((best.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)))
                    {
                        return true;
                    }
                    else if (((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && !((best.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)))
                    {
                        return false;
                    }
                }
                else 
                {
                    if (!((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && ((best.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)))
                    {
                        return true;
                    }
                    else if (((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && !((best.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55835426908)
            
            //--TRIMMABLE-BOUNDARY-START(64425361500)
            /*void */ RecordObservableInstruments()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361500);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._meterListener.RecordObservableInstruments();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425361500)
            
            //--TRIMMABLE-BOUNDARY-START(38655557724)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._disposing = true;
                this._disposed = true;
                this._meterListener.Dispose();
                this._disposing = false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655557724)
            
            //--TRIMMABLE-BOUNDARY-START(4295229531)
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource.RecordObservableInstruments()
            Microsoft$Extensions$Diagnostics$Metrics$IObservableInstrumentsSource$RecordObservableInstruments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RecordObservableInstruments(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229531)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885753948)
                this._instruments = new ($.$$.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$$.System.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885753948)
                
                //--TRIMMABLE-BOUNDARY-START(30065623132)
                this._rules = $.$$.System.Array.Empty($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule);
                //--TRIMMABLE-BOUNDARY-END(30065623132)
                
            }
            static $h = 852060;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245492316),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 852060,
      "h": 47245492316,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245492316),
//--TRIMMABLE-BOUNDARY-START(51540459612),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "_",
          "p": 6684718
        }
      ],
      "n": "InstrumentPublished",
      "d": 852060,
      "h": 51540459612,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540459612),
//--TRIMMABLE-BOUNDARY-START(60130394204),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "MeasurementsCompleted",
      "d": 852060,
      "h": 60130394204,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130394204),
//--TRIMMABLE-BOUNDARY-START(77310263388),
    {
      "r": 65537,
      "p": [
        {
          "n": "rules",
          "p": $.$$.System.Collections.Generic.IList$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule).$h
        }
      ],
      "n": "UpdateRules",
      "d": 852060,
      "h": 77310263388,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77310263388),
//--TRIMMABLE-BOUNDARY-START(68720328796),
    {
      "r": 65537,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        }
      ],
      "n": "RefreshInstrument",
      "d": 852060,
      "h": 68720328796,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720328796),
//--TRIMMABLE-BOUNDARY-START(42950525020),
    {
      "r": 196699,
      "p": [
        {
          "n": "instrument",
          "p": 5505070
        }
      ],
      "n": "GetMostSpecificRule",
      "d": 852060,
      "h": 42950525020,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950525020),
//--TRIMMABLE-BOUNDARY-START(73015296092),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 196699
        },
        {
          "n": "instrument",
          "p": 5505070
        },
        {
          "n": "listenerName",
          "p": 1310721
        },
        {
          "n": "meterFactory",
          "p": 5439534
        }
      ],
      "n": "RuleMatches",
      "d": 852060,
      "h": 73015296092,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015296092),
//--TRIMMABLE-BOUNDARY-START(55835426908),
    {
      "r": 262145,
      "p": [
        {
          "n": "rule",
          "p": 196699
        },
        {
          "n": "best",
          "p": 196699
        },
        {
          "n": "isLocalScope",
          "p": 262145
        }
      ],
      "n": "IsMoreSpecific",
      "d": 852060,
      "h": 55835426908,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835426908),
//--TRIMMABLE-BOUNDARY-START(64425361500),
    {
      "r": 65537,
      "n": "RecordObservableInstruments",
      "d": 852060,
      "h": 64425361500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425361500),
//--TRIMMABLE-BOUNDARY-START(38655557724),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 852060,
      "h": 38655557724,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655557724)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475688540),
    {
      "t": 6684718,
      "n": "_meterListener",
      "d": 852060,
      "h": 21475688540,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688540),
//--TRIMMABLE-BOUNDARY-START(25770655836),
    {
      "t": 131163,
      "n": "_metricsListener",
      "d": 852060,
      "h": 25770655836,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655836),
//--TRIMMABLE-BOUNDARY-START(17180721244),
    {
      "t": 5439534,
      "n": "_meterFactory",
      "d": 852060,
      "h": 17180721244,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721244),
//--TRIMMABLE-BOUNDARY-START(12885753948),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$$.System.Object).$h,
      "n": "_instruments",
      "d": 852060,
      "h": 12885753948,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753948),
//--TRIMMABLE-BOUNDARY-START(30065623132),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule).$h,
      "n": "_rules",
      "d": 852060,
      "h": 30065623132,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065623132),
//--TRIMMABLE-BOUNDARY-START(4295819356),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 852060,
      "h": 4295819356,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819356),
//--TRIMMABLE-BOUNDARY-START(8590786652),
    {
      "t": 262145,
      "n": "_disposing",
      "d": 852060,
      "h": 8590786652,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786652)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360590428),
    {
      "p": [
        {
          "n": "metricsListener",
          "p": 131163
        },
        {
          "n": "meterFactory",
          "p": 5439534
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852060,
      "h": 34360590428,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360590428)
  ],
  "i": [262235,90177537
  ],
  "h": 852060
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852060)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114204)
        $asm.$str("$mxdg.System.Diagnostics.BitMapper", ($self) => class BitMapper extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591048796)
            /*int*/  get _maxIndex() { return this.$getField(0, 4); }
            /*int*/  set _maxIndex(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591048796)
            
            //--TRIMMABLE-BOUNDARY-START(4296081500)
            /*Span<ulong>*/  get _bitMap() { return this.$getField(4, 12); }
            /*Span<ulong>*/  set _bitMap(value) { this.$setField(4, 12, value); }
            //--TRIMMABLE-BOUNDARY-END(4296081500)
            
            //--TRIMMABLE-BOUNDARY-START(12886016092)
            $ctor$3(/*Span<ulong>*/ bitMap)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886016092);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._bitMap = bitMap;
                    this._bitMap.Clear();
                    this._maxIndex = ((((bitMap.Length * $.$$.System.UInt64.$z) | 0) * 8) | 0);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016092)
            
            //--TRIMMABLE-BOUNDARY-START(38655819868)
            /*int */ get MaxIndex()
            {
                return this._maxIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(38655819868)
            
            //--TRIMMABLE-BOUNDARY-START(30065885276)
            static /*void */ GetIndexAndMask(/*int*/ index, /*out int*/ bitIndex, /*out ulong*/ mask)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                bitIndex.$v = index >> 6;
                /*int*/ let bit = index & ((((($.$$.System.UInt64.$z * 8) | 0) - 1) | 0));
                mask.$v = BigInt.asUintN(64, 1n << BigInt(bit));
            }
            //--TRIMMABLE-BOUNDARY-END(30065885276)
            
            //--TRIMMABLE-BOUNDARY-START(42950787164)
            /*bool */ SetBit(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0, "index >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$mxdg.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$$.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$$.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                this._bitMap.get_Item(bitIndex).$v = value | mask;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(42950787164)
            
            //--TRIMMABLE-BOUNDARY-START(34360852572)
            /*bool */ IsSet(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(index >= 0, "index >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$mxdg.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$$.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$$.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                return ((value & mask) !== 0n);
            }
            //--TRIMMABLE-BOUNDARY-END(34360852572)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._maxIndex = this._maxIndex;
                copy._bitMap = this._bitMap.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591048796)
                this._maxIndex = 0;
                //--TRIMMABLE-BOUNDARY-END(8591048796)
                
                //--TRIMMABLE-BOUNDARY-START(4296081500)
                this._bitMap = $.$default($.$$.System.Span$$($.$$.System.UInt64));
                //--TRIMMABLE-BOUNDARY-END(4296081500)
                
            }
            static $h = 1114204;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655819868),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770917980,
        "f": 50331649
      },
      "n": "MaxIndex",
      "d": 1114204,
      "h": 38655819868,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819868)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065885276),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "bitIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "mask",
          "p": 983041,
          "f": 2
        }
      ],
      "n": "GetIndexAndMask",
      "d": 1114204,
      "h": 30065885276,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065885276),
//--TRIMMABLE-BOUNDARY-START(42950787164),
    {
      "r": 262145,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "SetBit",
      "d": 1114204,
      "h": 42950787164,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950787164),
//--TRIMMABLE-BOUNDARY-START(34360852572),
    {
      "r": 262145,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "IsSet",
      "d": 1114204,
      "h": 34360852572,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360852572)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591048796),
    {
      "t": 655361,
      "n": "_maxIndex",
      "d": 1114204,
      "h": 8591048796,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048796),
//--TRIMMABLE-BOUNDARY-START(4296081500),
    {
      "t": $.$$.System.Span$$($.$$.System.UInt64).$h,
      "n": "_bitMap",
      "d": 1114204,
      "h": 4296081500,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081500)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016092),
    {
      "p": [
        {
          "n": "bitMap",
          "p": $.$$.System.Span$$($.$$.System.UInt64).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114204,
      "h": 12886016092,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016092),
//--TRIMMABLE-BOUNDARY-START(17180983388),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114204,
      "h": 17180983388,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983388)
  ],
  "h": 1114204
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.BitMapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114204)
        
        
        //--TRIMMABLE-BOUNDARY-START(524380)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions", ($self) => class MetricsConfigureOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065295452)
            /*string*/ static EnabledMetricsKey = null;
            //--TRIMMABLE-BOUNDARY-END(30065295452)
            
            //--TRIMMABLE-BOUNDARY-START(21475360860)
            /*string*/ static EnabledGlobalMetricsKey = null;
            //--TRIMMABLE-BOUNDARY-END(21475360860)
            
            //--TRIMMABLE-BOUNDARY-START(25770328156)
            /*string*/ static EnabledLocalMetricsKey = null;
            //--TRIMMABLE-BOUNDARY-END(25770328156)
            
            //--TRIMMABLE-BOUNDARY-START(17180393564)
            /*string*/ static DefaultKey = null;
            //--TRIMMABLE-BOUNDARY-END(17180393564)
            
            //--TRIMMABLE-BOUNDARY-START(4295491676)
            /*IConfiguration*/ _configuration = null;
            //--TRIMMABLE-BOUNDARY-END(4295491676)
            
            //--TRIMMABLE-BOUNDARY-START(8590458972)
            $ctor$1(/*IConfiguration*/ configuration)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458972);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._configuration = $.$firstOf(configuration, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("configuration") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458972)
            
            //--TRIMMABLE-BOUNDARY-START(12885426268)
            /*void */ Configure(/*MetricsOptions*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.LoadConfig(options);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426268)
            
            //--TRIMMABLE-BOUNDARY-START(34360262748)
            /*void */ LoadConfig(/*MetricsOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._configuration.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var configurationSection = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.Equals$4.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledMetrics"/*EnabledMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 1/*MeterScope.Global*/ | 2/*MeterScope.Local*/, null);
                        }
                        else if ($.$$.System.String.Equals$4.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledGlobalMetrics"/*EnabledGlobalMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 1/*MeterScope.Global*/, null);
                        }
                        else if ($.$$.System.String.Equals$4.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledLocalMetrics"/*EnabledLocalMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 2/*MeterScope.Local*/, null);
                        }
                        else 
                        {
                            /*var*/ let listenerName = configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            /*var*/ let enabledMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledMetrics"/*EnabledMetricsKey*/);
                            if (enabledMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledMetricsSection, 1/*MeterScope.Global*/ | 2/*MeterScope.Local*/, listenerName);
                            }
                            /*var*/ let enabledGlobalMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledGlobalMetrics"/*EnabledGlobalMetricsKey*/);
                            if (enabledGlobalMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledGlobalMetricsSection, 1/*MeterScope.Global*/, listenerName);
                            }
                            /*var*/ let enabledLocalMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledLocalMetrics"/*EnabledLocalMetricsKey*/);
                            if (enabledLocalMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledLocalMetricsSection, 2/*MeterScope.Local*/, listenerName);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262748)
            
            //--TRIMMABLE-BOUNDARY-START(42950197340)
            static /*void */ LoadMeterRules(/*MetricsOptions*/ options, /*IConfigurationSection*/ configurationSection, /*MeterScope*/ scopes, /*string?*/ listenerName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var meterSection = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let meterEnabled;
                        if ($.$sl.System.Linq.Enumerable.Any$1($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, meterSection.Microsoft$Extensions$Configuration$IConfiguration$GetChildren()))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadInstrumentRules(options, meterSection, scopes, listenerName);
                        }
                        else if ($.$$.System.Boolean.TryParse$1(meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Value, $.$ref(() => meterEnabled, ($v) => meterEnabled = $v, $.$$.System.Boolean)))
                        {
                            /*var*/ let meterName = meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            if ($.$$.System.String.Equals$2("Default"/*DefaultKey*/, meterName, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                meterName = null;
                            }
                            options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule().$ctor$1(meterName, null, listenerName, scopes, meterEnabled), [$.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule]);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950197340)
            
            //--TRIMMABLE-BOUNDARY-START(38655230044)
            static /*void */ LoadInstrumentRules(/*MetricsOptions*/ options, /*IConfigurationSection*/ meterSection, /*MeterScope*/ scopes, /*string?*/ listenerName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.AsEnumerable(meterSection, true).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var instrumentPair = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let instrumentEnabled;
                        if ($.$$.System.Boolean.TryParse$1(instrumentPair.Value, $.$ref(() => instrumentEnabled, ($v) => instrumentEnabled = $v, $.$$.System.Boolean)))
                        {
                            /*var*/ let instrumentName = instrumentPair.Key;
                            if ($.$$.System.String.Equals$2("Default"/*DefaultKey*/, instrumentName, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                instrumentName = null;
                            }
                            options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule().$ctor$1(meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, instrumentName, listenerName, scopes, instrumentEnabled), [$.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule]);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655230044)
            
            //--TRIMMABLE-BOUNDARY-START(4295688279)
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions>.Configure(Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Configure(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295688279)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295452)
                    this.EnabledMetricsKey = "EnabledMetrics";
                    //--TRIMMABLE-BOUNDARY-END(30065295452)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475360860)
                    this.EnabledGlobalMetricsKey = "EnabledGlobalMetrics";
                    //--TRIMMABLE-BOUNDARY-END(21475360860)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328156)
                    this.EnabledLocalMetricsKey = "EnabledLocalMetrics";
                    //--TRIMMABLE-BOUNDARY-END(25770328156)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180393564)
                    this.DefaultKey = "Default";
                    //--TRIMMABLE-BOUNDARY-END(17180393564)
                    
                }
            }
            static $h = 524380;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885426268),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 524379
        }
      ],
      "n": "Configure",
      "d": 524380,
      "h": 12885426268,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426268),
//--TRIMMABLE-BOUNDARY-START(34360262748),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 524379
        }
      ],
      "n": "LoadConfig",
      "d": 524380,
      "h": 34360262748,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360262748),
//--TRIMMABLE-BOUNDARY-START(42950197340),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "configurationSection",
          "p": 720990
        },
        {
          "n": "scopes",
          "p": 393307
        },
        {
          "n": "listenerName",
          "p": 1310721
        }
      ],
      "n": "LoadMeterRules",
      "d": 524380,
      "h": 42950197340,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950197340),
//--TRIMMABLE-BOUNDARY-START(38655230044),
    {
      "r": 65537,
      "p": [
        {
          "n": "options",
          "p": 524379
        },
        {
          "n": "meterSection",
          "p": 720990
        },
        {
          "n": "scopes",
          "p": 393307
        },
        {
          "n": "listenerName",
          "p": 1310721
        }
      ],
      "n": "LoadInstrumentRules",
      "d": 524380,
      "h": 38655230044,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655230044)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065295452),
    {
      "t": 1310721,
      "n": "EnabledMetricsKey",
      "d": 524380,
      "h": 30065295452,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065295452),
//--TRIMMABLE-BOUNDARY-START(21475360860),
    {
      "t": 1310721,
      "n": "EnabledGlobalMetricsKey",
      "d": 524380,
      "h": 21475360860,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475360860),
//--TRIMMABLE-BOUNDARY-START(25770328156),
    {
      "t": 1310721,
      "n": "EnabledLocalMetricsKey",
      "d": 524380,
      "h": 25770328156,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770328156),
//--TRIMMABLE-BOUNDARY-START(17180393564),
    {
      "t": 1310721,
      "n": "DefaultKey",
      "d": 524380,
      "h": 17180393564,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180393564),
//--TRIMMABLE-BOUNDARY-START(4295491676),
    {
      "t": 393310,
      "n": "_configuration",
      "d": 524380,
      "h": 4295491676,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458972),
    {
      "p": [
        {
          "n": "configuration",
          "p": 393310
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524380,
      "h": 8590458972,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458972)
  ],
  "i": [$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions).$h
  ],
  "h": 524380
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524380)
        
        
        //--TRIMMABLE-BOUNDARY-START(786524)
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter", ($self) => class FactoryMeter extends $.$sdd.System.Diagnostics.Metrics.Meter
        {
            //--TRIMMABLE-BOUNDARY-START(4295753820)
            $ctor$5(/*MeterOptions*/ options)
            {
                super.$ctor$4(options);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753820)
            
            //--TRIMMABLE-BOUNDARY-START(12885688412)
            /*void */ Release()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688412);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return super.Dispose$1(true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885688412)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590721116, 193280081966)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590721116, 193280081966)
            
            static $h = 786524;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 6553646,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885688412),
    {
      "r": 65537,
      "n": "Release",
      "d": 786524,
      "h": 12885688412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688412),
//--TRIMMABLE-BOUNDARY-START(ALL, 8590721116, 193280081966),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 786524,
      "h": 8590721116,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590721116, 193280081966)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753820),
    {
      "p": [
        {
          "n": "options",
          "p": 6750254
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786524,
      "h": 4295753820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753820)
  ],
  "i": [90177537
  ],
  "h": 786524
}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Meter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786524)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions"))
//--TRIMMABLE-BOUNDARY-END(92)
