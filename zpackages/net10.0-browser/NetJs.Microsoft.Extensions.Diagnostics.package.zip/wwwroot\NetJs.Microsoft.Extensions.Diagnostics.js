
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $mep, $sr, $scc, $scn, $scm, $so, $srw, $srn, $ssc, $sris, $stc, $srsf, $scp, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $scs, $sdp, $sicb, $sci, $sdd, $sdts, $srm, $snnr, $sds, $sre, $sns, $sscr, $sle, $str, $snn, $snsc, $meca, $mxdi, $snq, $mec, $snh, $spx, $spxl, $sxxd, $sct, $mecb, $sca, $meo, $meda, $meoc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Diagnostics", 
    {"h":24,"f":"Microsoft.Extensions.Diagnostics","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Diagnostics","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Diagnostics","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory", ($self) => class IMetricListenerConfigurationFactory
        {
            static $h = 327704;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":262158,"p":[{"n":"listenerName","p":1310721}],"n":"GetConfiguration","o":"Microsoft$Extensions$Diagnostics$Metrics$Configuration$IMetricListenerConfigurationFactory$GetConfiguration","d":327704,"h":4295295000,"f":257}],"h":327704}; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics", ($self) => class ConsoleMetrics
        {
            static /*string */ get DebugListenerName()
            {
                return "DebugConsole";
            }
            static $h = 589848;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590524440,"f":33},"n":"DebugListenerName","d":589848,"h":4295557144,"f":33}],"h":589848}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics`; }
        });
        
        $asm.$cls("$mxdg.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mxdg.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Diagnostics", $.$mxdg.System.SR.$type.Assembly);
                    $.$mxdg.System.SR.s_resourceManager = temp;
                }
                return $.$mxdg.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mxdg.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mxdg.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidScope()
            {
                return "The meter factory does not allow a custom scope value when creating a meter.";
            }
            static /*string */ get MoreThanOneWildcard()
            {
                return "Only one wildcard character is allowed in category name.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mxdg.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mxdg.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mxdg.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mxdg.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mxdg.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mxdg.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mxdg.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1245208;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1245208}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConsoleExtensions", ($self) => class MetricsBuilderConsoleExtensions
        {
            static /*IMetricsBuilder */ AddDebugConsole(/*this IMetricsBuilder*/ builder)
            {
                return $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderExtensions.AddListener($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener, builder);
            }
            static $h = 983064;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65561,"p":[{"n":"builder","p":65561}],"n":"AddDebugConsole","d":983064,"h":4295950360,"f":33}],"h":983064}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConsoleExtensions`; }
        });
        
        $asm.$cls("$mxdg.System.Diagnostics.DiagnosticsHelper", ($self) => class DiagnosticsHelper
        {
            static /*bool */ CompareTags(/*IList<KeyValuePair<string, object?>>?*/ sortedTags, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags2)
            {
                if (sortedTags === tags2)
                {
                    return true;
                }
                if (sortedTags === null || tags2 === null)
                {
                    return false;
                }
                /*int*/ let count = sortedTags.System$Collections$Generic$ICollection$$$Count;
                /*int*/ let size = (($.trunc(count / ((($.$spc.System.UInt64.$z * 8) | 0))) + 1) | 0);
                /*BitMapper*/ let bitMapper = new $.$mxdg.System.Diagnostics.BitMapper().$ctor$2((size >>> 0) <= 100 ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, size, null) : $.$spc.System.Span$$($.$spc.System.UInt64).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt64), null, [size], null)));
                let tagsCol;
                if ($.$is(tags2, $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), { set $v(v){ tagsCol = v; } }))
                {
                    if (tagsCol.System$Collections$Generic$ICollection$$$Count !== count)
                    {
                        return false;
                    }
                    let secondList;
                    if ($.$is(tagsCol, $.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), { set $v(v){ secondList = v; } }))
                    {
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*KeyValuePair<string, object?>*/ let pair = secondList.System$Collections$Generic$IList$$$get_Item(i, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                            for(/*int*/ let j = 0; j < count; j++)
                            {
                                if (bitMapper.IsSet(j))
                                {
                                    continue;
                                }
                                /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                                /*int*/ let compareResult = $.$spc.System.String.CompareOrdinal(pair.Key, pair1.Key);
                                if (compareResult === 0 && $.$spc.System.Object.Equals$1(pair.Value, pair1.Value))
                                {
                                    bitMapper.SetBit(j);
                                    break;
                                }
                                if (compareResult < 0 || j === ((count - 1) | 0))
                                {
                                    return false;
                                }
                            }
                        }
                        return true;
                    }
                }
                /*int*/ let listCount = 0;
                let enumerator = null;
                try
                {
                    enumerator = tags2.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                    while(enumerator.System$Collections$IEnumerator$MoveNext())
                    {
                        listCount++;
                        if (listCount > sortedTags.System$Collections$Generic$ICollection$$$Count)
                        {
                            return false;
                        }
                        /*KeyValuePair<string, object?>*/ let pair = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                        for(/*int*/ let j = 0; j < count; j++)
                        {
                            if (bitMapper.IsSet(j))
                            {
                                continue;
                            }
                            /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                            /*int*/ let compareResult = $.$spc.System.String.CompareOrdinal(pair.Key, pair1.Key);
                            if (compareResult === 0 && $.$spc.System.Object.Equals$1(pair.Value, pair1.Value))
                            {
                                bitMapper.SetBit(j);
                                break;
                            }
                            if (compareResult < 0 || j === ((count - 1) | 0))
                            {
                                return false;
                            }
                        }
                    }
                    return listCount === sortedTags.System$Collections$Generic$ICollection$$$Count;
                }
                finally
                {
                    enumerator?.System$IDisposable$Dispose();
                }
            }
            static $h = 1179672;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"sortedTags","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"tags2","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h}],"n":"CompareTags","d":1179672,"h":4296146968,"f":40}],"h":1179672}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticsHelper`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions", ($self) => class MetricsServiceExtensions
        {
            static /*IServiceCollection */ AddMetrics(/*this IServiceCollection*/ services)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$4($.$sdd.System.Diagnostics.Metrics.IMeterFactory, $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager, services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsBuilderExtensions.ValidateOnStart($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions, $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions$1($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions, services));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$4($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions), $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$4($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory, $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory, services);
                return services;
            }
            static /*IServiceCollection */ AddMetrics$1(/*this IServiceCollection*/ services, /*Action<IMetricsBuilder>*/ configure)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(configure, "configure");
                $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.AddMetrics(services);
                /*var*/ let builder = new $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder().$ctor$1(services);
                configure.Invoke(builder);
                return services;
            }
            static $_MetricsBuilder;
            static get MetricsBuilder()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_MetricsBuilder ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder", ($self) => class MetricsBuilder extends $.$spc.System.Object
                {
                    /*IServiceCollection*/ Services = null;
                    //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder.Services.get
                    get Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services()
                    {
                        return this.Services;
                    }
                    //Begin primary constructor
                    /*IServiceCollection*/ services = null;
                    $ctor$1(/*IServiceCollection*/$services)
                    {
                        this.services = $services;
                        //depends on primary constructor parameter
                        this.Services = this.services;
                        return this
                    }
                    //End primary constructor
                    static $h = 131096;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":786435,"g":{"r":0,"d":0,"h":17180000280,"f":1},"n":"Services","d":131096,"h":12885032984,"f":1}],"c":[{"p":[{"n":"services","p":786435}],"n":".ctor","o":"$ctor$1","d":131096,"h":4295098392,"f":1}],"i":[65561],"d":65560,"h":131096}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder ]; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.MetricsBuilder`; }
                }, $cls, ($v) => $cls.$_MetricsBuilder = $v);
            }
            static $_NoOpOptions;
            static get NoOpOptions()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_NoOpOptions ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions", ($self) => class NoOpOptions extends $.$spc.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 196632;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"c":[{"n":".ctor","o":"$ctor$1","d":196632,"h":4295163928,"f":1}],"d":65560,"h":196632}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions`; }
                }, $cls, ($v) => $cls.$_NoOpOptions = $v);
            }
            static $_SubscriptionActivator;
            static get SubscriptionActivator()
            {
                let $cls = $.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions;
                return $cls.$_SubscriptionActivator ??= $asm.$ncls("$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator", ($self) => class SubscriptionActivator extends $.$spc.System.Object
                {
                    /*void */ Configure(/*NoOpOptions*/ options)
                    {
                        return this.manager.Initialize();
                    }
                    //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions>.Configure(Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions)
                    Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
                    {
                        return this.Configure(...arguments);
                    }
                    //Begin primary constructor
                    /*MetricsSubscriptionManager*/ manager = null;
                    $ctor$1(/*MetricsSubscriptionManager*/$manager)
                    {
                        this.manager = $manager;
                        return this
                    }
                    //End primary constructor
                    static $h = 262168;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"options","p":196632}],"n":"Configure","d":262168,"h":12885164056,"f":1}],"l":[{"t":1048600,"n":"\u003Cmanager\u003EP","d":262168,"h":8590196760,"f":2}],"c":[{"p":[{"n":"manager","p":1048600}],"n":".ctor","o":"$ctor$1","d":262168,"h":4295229464,"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions).$h],"d":65560,"h":262168}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$mxdg.Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.NoOpOptions) ]; }
                    static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions.SubscriptionActivator`; }
                }, $cls, ($v) => $cls.$_SubscriptionActivator = $v);
            }
            static $h = 65560;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddMetrics","d":65560,"h":4295032856,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"configure","p":$.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsBuilder).$h}],"n":"AddMetrics","o":"@$1","d":65560,"h":8590000152,"f":33}],"j":[131096,196632,262168],"h":65560}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.DependencyInjection.MetricsServiceExtensions`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConfigurationExtensions", ($self) => class MetricsBuilderConfigurationExtensions
        {
            static /*IMetricsBuilder */ AddConfiguration(/*this IMetricsBuilder*/ builder, /*IConfiguration*/ configuration)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(builder, "builder");
                $.$spc.System.ArgumentNullException.ThrowIfNull(configuration, "configuration");
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions), builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions().$ctor$1(configuration));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$meo.Microsoft.Extensions.Options.IOptionsChangeTokenSource$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions), builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new ($.$meoc.Microsoft.Extensions.Options.ConfigurationChangeTokenSource$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor$1(configuration));
                $.$mxdi.Microsoft.Extensions.DependencyInjection.ServiceCollectionServiceExtensions.AddSingleton$8($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration, builder.Microsoft$Extensions$Diagnostics$Metrics$IMetricsBuilder$Services, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration().$ctor$1(configuration));
                return builder;
            }
            static $h = 917528;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65561,"p":[{"n":"builder","p":65561},{"n":"configuration","p":262158}],"n":"AddConfiguration","d":917528,"h":4295884824,"f":33}],"h":917528}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsBuilderConfigurationExtensions`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration", ($self) => class MetricsConfiguration extends $.$spc.System.Object
        {
            $ctor$1(/*IConfiguration*/ configuration)
            {
                super.$ctor();
                {
                    this.Configuration = $.$firstOf(configuration, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("configuration") });
                }
                return this;
            }
            /*IConfiguration*/ Configuration = null;
            static $h = 458776;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262158,"g":{"r":0,"d":0,"h":17180327960,"f":1},"n":"Configuration","d":458776,"h":12885360664,"f":1}],"c":[{"p":[{"n":"configuration","p":262158}],"n":".ctor","o":"$ctor$1","d":458776,"h":4295426072,"f":1}],"h":458776}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager", ($self) => class MetricsSubscriptionManager extends $.$spc.System.Object
        {
            /*ListenerSubscription[]*/ _listeners = null;
            /*IDisposable?*/ _changeTokenRegistration = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*IEnumerable<IMetricsListener>*/ listeners, /*IOptionsMonitor<MetricsOptions>*/ options, /*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    /*var*/ let list = $.$sl.System.Linq.Enumerable.ToList($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, listeners);
                    this._listeners = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription), null, [list.Count], null);
                    for(/*int*/ let i = 0; i < this._listeners.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(this._listeners, new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription().$ctor$1(list.get_Item(i), meterFactory), i);
                    }
                    this._changeTokenRegistration = $.$meo.Microsoft.Extensions.Options.OptionsMonitorExtensions.OnChange($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions, options, new ($.$spc.System.Action$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions))().$ctor(this, this.UpdateRules));
                    this.UpdateRules(options.Microsoft$Extensions$Options$IOptionsMonitor$$$CurrentValue);
                }
                return this;
            }
            /*void */ Initialize()
            {
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.Initialize();
                }
            }
            /*void */ UpdateRules(/*MetricsOptions*/ options)
            {
                if (this._disposed)
                {
                    return;
                }
                /*var*/ let rules = options.Rules;
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.UpdateRules(rules);
                }
            }
            /*void */ Dispose()
            {
                if (this._disposed)
                {
                    return;
                }
                this._disposed = true;
                this._changeTokenRegistration?.System$IDisposable$Dispose();
                let $i1 = 0;
                let $arr1 = this._listeners;
                while ($i1 < $arr1.length)
                {
                    let listener = $arr1[$i1++];
                    listener.Dispose();
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1048600;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Initialize","d":1048600,"h":21475885080,"f":1},{"r":65537,"p":[{"n":"options","p":524313}],"n":"UpdateRules","d":1048600,"h":25770852376,"f":2},{"r":65537,"n":"Dispose","d":1048600,"h":30065819672,"f":1}],"l":[{"t":0,"n":"_listeners","d":1048600,"h":4296015896,"f":2},{"t":57475073,"n":"_changeTokenRegistration","d":1048600,"h":8590983192,"f":2},{"t":262145,"n":"_disposed","d":1048600,"h":12885950488,"f":2}],"c":[{"p":[{"n":"listeners","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener).$h},{"n":"options","p":$.$meo.Microsoft.Extensions.Options.IOptionsMonitor$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions).$h},{"n":"meterFactory","p":5439532}],"n":".ctor","o":"$ctor$1","d":1048600,"h":17180917784,"f":1}],"i":[57475073],"h":1048600}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.MetricsSubscriptionManager`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory", ($self) => class MetricListenerConfigurationFactory extends $.$spc.System.Object
        {
            /*IEnumerable<MetricsConfiguration>*/ _configurations = null;
            $ctor$1(/*IEnumerable<MetricsConfiguration>*/ configurations)
            {
                super.$ctor();
                {
                    this._configurations = $.$firstOf(configurations, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("configurations") });
                }
                return this;
            }
            /*IConfiguration */ GetConfiguration(/*string*/ listenerName)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(listenerName, "listenerName");
                /*var*/ let configurationBuilder = new $.$mec.Microsoft.Extensions.Configuration.ConfigurationBuilder().$ctor$1();
                var $en2 = this._configurations.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var configuration = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let section = configuration.Configuration.Microsoft$Extensions$Configuration$IConfiguration$GetSection(listenerName);
                        $.$mec.Microsoft.Extensions.Configuration.ChainedBuilderExtensions.AddConfiguration(configurationBuilder, section);
                    }
                }
                return configurationBuilder.Build();
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory.GetConfiguration(string)
            Microsoft$Extensions$Diagnostics$Metrics$Configuration$IMetricListenerConfigurationFactory$GetConfiguration()
            {
                return this.GetConfiguration(...arguments);
            }
            static $h = 393240;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262158,"p":[{"n":"listenerName","p":1310721}],"n":"GetConfiguration","d":393240,"h":12885295128,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration).$h,"n":"_configurations","d":393240,"h":4295360536,"f":2}],"c":[{"p":[{"n":"configurations","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfiguration).$h}],"n":".ctor","o":"$ctor$1","d":393240,"h":8590327832,"f":1}],"i":[327704],"h":393240}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.IMetricListenerConfigurationFactory ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricListenerConfigurationFactory`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription", ($self) => class ListenerSubscription extends $.$spc.System.Object
        {
            /*MeterListener*/ _meterListener = null;
            /*IMetricsListener*/ _metricsListener = null;
            /*IMeterFactory*/ _meterFactory = null;
            /*Dictionary<Instrument, object?>*/ _instruments = null;
            /*IList<InstrumentRule>*/ _rules = null;
            /*bool*/ _disposed = false;
            /*bool*/ _disposing = false;
            $ctor$1(/*IMetricsListener*/ metricsListener, /*IMeterFactory*/ meterFactory)
            {
                super.$ctor();
                {
                    this._metricsListener = metricsListener;
                    this._meterFactory = meterFactory;
                    this._meterListener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                }
                return this;
            }
            /*void */ Initialize()
            {
                this._meterListener.InstrumentPublished = new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this, this.InstrumentPublished);
                this._meterListener.MeasurementsCompleted = new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object))().$ctor(this, this.MeasurementsCompleted);
                /*var*/ let handlers = this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$GetMeasurementHandlers();
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Byte, handlers.ByteHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Int16, handlers.ShortHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Int32, handlers.IntHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Int64, handlers.LongHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Single, handlers.FloatHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Double, handlers.DoubleHandler);
                this._meterListener.SetMeasurementEventCallback($.$spc.System.Decimal, handlers.DecimalHandler);
                this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Initialize(this);
                this._meterListener.Start();
            }
            /*void */ InstrumentPublished(/*Instrument*/ instrument, /*MeterListener*/ _)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._instruments)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        if (this._instruments.ContainsKey(instrument))
                        {
                            $.$spc.System.Diagnostics.Debug.Fail("InstrumentPublished called for an instrument we're already listening to.");
                            return;
                        }
                        this.RefreshInstrument(instrument);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            /*void */ MeasurementsCompleted(/*Instrument*/ instrument, /*object?*/ state)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._instruments)
                    {
                        if (this._disposed && !this._disposing)
                        {
                            return;
                        }
                        /*var*/ let listenerState;
                        if (this._instruments.TryGetValue(instrument, $.$ref(() => listenerState, ($v) => listenerState = $v, $.$spc.System.Object)))
                        {
                            this._instruments.Remove(instrument);
                            this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted(instrument, listenerState);
                            this._meterListener.DisableMeasurementEvents(instrument);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            /*void */ UpdateRules(/*IList<InstrumentRule>*/ rules)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._instruments)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._rules = rules;
                        /*var*/ let tempListener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                        try
                        {
                            tempListener.InstrumentPublished = new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this,  (/*instrument*/ instrument, /*_*/ _1) =>
                            {
                                return this.RefreshInstrument(instrument);
                            });
                            tempListener.Start();
                        }
                        finally
                        {
                            tempListener?.System$IDisposable$Dispose();
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._instruments)
                }
            }
            /*void */ RefreshInstrument(/*Instrument*/ instrument)
            {
                /*var*/ let state;
                /*var*/ let alreadyEnabled = this._instruments.TryGetValue(instrument, $.$ref(() => state, ($v) => state = $v, $.$spc.System.Object));
                /*var*/ let enable = false;
                /*var*/ let rule = this.GetMostSpecificRule(instrument);
                if (rule !== null)
                {
                    enable = rule.Enable;
                }
                if (!enable && alreadyEnabled)
                {
                    this._instruments.Remove(instrument);
                    this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted(instrument, state);
                    this._meterListener.DisableMeasurementEvents(instrument);
                }
                else if (enable && !alreadyEnabled)
                {
                    if (this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$InstrumentPublished(instrument, $.$ref(() => state, ($v) => state = $v, $.$spc.System.Object)))
                    {
                        this._instruments.Add(instrument, state);
                        this._meterListener.EnableMeasurementEvents(instrument, state);
                    }
                }
            }
            /*InstrumentRule? */ GetMostSpecificRule(/*Instrument*/ instrument)
            {
                /*InstrumentRule?*/ let best = null;
                var $en2 = this._rules.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var rule = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription.RuleMatches(rule, instrument, this._metricsListener.Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Name, this._meterFactory) && $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription.IsMoreSpecific(rule, best, instrument.Meter.Scope === this._meterFactory))
                        {
                            best = rule;
                        }
                    }
                }
                return best;
            }
            static /*bool */ RuleMatches(/*InstrumentRule*/ rule, /*Instrument*/ instrument, /*string*/ listenerName, /*IMeterFactory*/ meterFactory)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(rule.ListenerName) && !$.$spc.System.String.Equals$5(rule.ListenerName, listenerName, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!$.$spc.System.String.IsNullOrEmpty(rule.InstrumentName) && !$.$spc.System.String.Equals$5(rule.InstrumentName, instrument.Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!(((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && instrument.Meter.Scope === null) && !(((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && instrument.Meter.Scope === meterFactory))
                {
                    return false;
                }
                /*var*/ let meterName = rule.MeterName;
                if ($.$spc.System.String.op_Inequality(meterName, null))
                {
                    /*char*/ let WildcardChar = /***/ 42;
                    /*int*/ let wildcardIndex = $.$spc.System.String.IndexOf.call(meterName, WildcardChar);
                    if (wildcardIndex >= 0 && $.$spc.System.String.IndexOf$1.call(meterName, WildcardChar, ((wildcardIndex + 1) | 0)) >= 0)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdg.System.SR.MoreThanOneWildcard);
                    }
                    /*ReadOnlySpan<char>*/ let prefix, suffix;
                    if (wildcardIndex < 0)
                    {
                        prefix = $.$spc.System.MemoryExtensions.AsSpan$3(meterName);
                        suffix = new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))();
                    }
                    else 
                    {
                        prefix = $.$spc.System.MemoryExtensions.AsSpan$7(meterName, 0, wildcardIndex);
                        suffix = $.$spc.System.MemoryExtensions.AsSpan$4(meterName, ((wildcardIndex + 1) | 0));
                    }
                    if (!$.$spc.System.MemoryExtensions.StartsWith$5($.$spc.System.MemoryExtensions.AsSpan$3(instrument.Meter.Name), prefix, 5/*StringComparison.OrdinalIgnoreCase*/) || !$.$spc.System.MemoryExtensions.EndsWith$5($.$spc.System.MemoryExtensions.AsSpan$3(instrument.Meter.Name), suffix, 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return false;
                    }
                }
                return true;
            }
            static /*bool */ IsMoreSpecific(/*InstrumentRule*/ rule, /*InstrumentRule?*/ best, /*bool*/ isLocalScope)
            {
                if (best === null)
                {
                    return true;
                }
                if (!$.$spc.System.String.IsNullOrEmpty(rule.ListenerName) && $.$spc.System.String.IsNullOrEmpty(best.ListenerName))
                {
                    return true;
                }
                else if ($.$spc.System.String.IsNullOrEmpty(rule.ListenerName) && !$.$spc.System.String.IsNullOrEmpty(best.ListenerName))
                {
                    return false;
                }
                if (!$.$spc.System.String.IsNullOrEmpty(rule.MeterName))
                {
                    if ($.$spc.System.String.IsNullOrEmpty(best.MeterName))
                    {
                        return true;
                    }
                    if (rule.MeterName.length !== best.MeterName.length)
                    {
                        return rule.MeterName.length > best.MeterName.length;
                    }
                }
                else if (!$.$spc.System.String.IsNullOrEmpty(best.MeterName))
                {
                    return false;
                }
                if (!$.$spc.System.String.IsNullOrEmpty(rule.InstrumentName) && $.$spc.System.String.IsNullOrEmpty(best.InstrumentName))
                {
                    return true;
                }
                else if ($.$spc.System.String.IsNullOrEmpty(rule.InstrumentName) && !$.$spc.System.String.IsNullOrEmpty(best.InstrumentName))
                {
                    return false;
                }
                if (isLocalScope)
                {
                    if (!((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && ((best.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)))
                    {
                        return true;
                    }
                    else if (((rule.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)) && !((best.Scopes & (1/*MeterScope.Global*/)) == (1/*MeterScope.Global*/)))
                    {
                        return false;
                    }
                }
                else 
                {
                    if (!((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && ((best.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)))
                    {
                        return true;
                    }
                    else if (((rule.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)) && !((best.Scopes & (2/*MeterScope.Local*/)) == (2/*MeterScope.Local*/)))
                    {
                        return false;
                    }
                }
                return true;
            }
            /*void */ RecordObservableInstruments()
            {
                return this._meterListener.RecordObservableInstruments();
            }
            /*void */ Dispose()
            {
                this._disposing = true;
                this._disposed = true;
                this._meterListener.Dispose();
                this._disposing = false;
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource.RecordObservableInstruments()
            Microsoft$Extensions$Diagnostics$Metrics$IObservableInstrumentsSource$RecordObservableInstruments()
            {
                return this.RecordObservableInstruments(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._instruments = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object))().$ctor$1();
                this._rules = $.$spc.System.Array.Empty($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule);
            }
            static $h = 851992;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"Initialize","d":851992,"h":38655557656,"f":1},{"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"_","p":6684716}],"n":"InstrumentPublished","d":851992,"h":42950524952,"f":2},{"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"state","p":131073}],"n":"MeasurementsCompleted","d":851992,"h":47245492248,"f":2},{"r":65537,"p":[{"n":"rules","p":$.$spc.System.Collections.Generic.IList$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule).$h}],"n":"UpdateRules","d":851992,"h":51540459544,"f":8},{"r":65537,"p":[{"n":"instrument","p":5505068}],"n":"RefreshInstrument","d":851992,"h":55835426840,"f":2},{"r":196633,"p":[{"n":"instrument","p":5505068}],"n":"GetMostSpecificRule","d":851992,"h":60130394136,"f":2},{"r":262145,"p":[{"n":"rule","p":196633},{"n":"instrument","p":5505068},{"n":"listenerName","p":1310721},{"n":"meterFactory","p":5439532}],"n":"RuleMatches","d":851992,"h":64425361432,"f":40},{"r":262145,"p":[{"n":"rule","p":196633},{"n":"best","p":196633},{"n":"isLocalScope","p":262145}],"n":"IsMoreSpecific","d":851992,"h":68720328728,"f":40},{"r":65537,"n":"RecordObservableInstruments","d":851992,"h":73015296024,"f":1},{"r":65537,"n":"Dispose","d":851992,"h":77310263320,"f":1}],"l":[{"t":6684716,"n":"_meterListener","d":851992,"h":4295819288,"f":2},{"t":131097,"n":"_metricsListener","d":851992,"h":8590786584,"f":2},{"t":5439532,"n":"_meterFactory","d":851992,"h":12885753880,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object).$h,"n":"_instruments","d":851992,"h":17180721176,"f":2},{"t":$.$spc.System.Collections.Generic.IList$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule).$h,"n":"_rules","d":851992,"h":21475688472,"f":2},{"t":262145,"n":"_disposed","d":851992,"h":25770655768,"f":2},{"t":262145,"n":"_disposing","d":851992,"h":30065623064,"f":2}],"c":[{"p":[{"n":"metricsListener","p":131097},{"n":"meterFactory","p":5439532}],"n":".ctor","o":"$ctor$1","d":851992,"h":34360590360,"f":8}],"i":[262169,57475073],"h":851992}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.ListenerSubscription`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory", ($self) => class DefaultMeterFactory extends $.$spc.System.Object
        {
            /*Dictionary<string, List<FactoryMeter>>*/ _cachedMeters = null;
            /*bool*/ _disposed = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Meter */ Create(/*MeterOptions*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                if (!(options.Scope === null) && !$.$spc.System.Object.ReferenceEquals(options.Scope, this))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mxdg.System.SR.InvalidScope);
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(options.Name === null), "options.Name is not null");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._cachedMeters)
                    {
                        if (this._disposed)
                        {
                            throw new $.$spc.System.ObjectDisposedException().$ctor$14("DefaultMeterFactory");
                        }
                        /*List<FactoryMeter>?*/ let meterList;
                        if (this._cachedMeters.TryGetValue(options.Name, $.$ref(() => meterList, ($v) => meterList = $v, $.$spc.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter))))
                        {
                            var $en5 = meterList.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var meter = $en5.Current;
                                {
                                    if ($.$spc.System.String.op_Equality(meter.Version, options.Version) && $.$mxdg.System.Diagnostics.DiagnosticsHelper.CompareTags($.$as(meter.Tags, $.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))), options.Tags))
                                    {
                                        return meter;
                                    }
                                }
                            }
                        }
                        else 
                        {
                            meterList = new ($.$spc.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter))().$ctor$1();
                            this._cachedMeters.Add(options.Name, meterList);
                        }
                        /*object?*/ let scope = options.Scope;
                        options.Scope = this;
                        /*FactoryMeter*/ let m = new $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter().$ctor$5(options);
                        options.Scope = scope;
                        meterList.Add(m);
                        return m;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._cachedMeters)
                }
            }
            /*void */ Dispose()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._cachedMeters)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        var $en4 = this._cachedMeters.Values.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var meterList = $en4.Current;
                            {
                                var $en6 = meterList.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var meter = $en6.Current;
                                    {
                                        meter.Release();
                                    }
                                }
                            }
                        }
                        this._cachedMeters.Clear();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._cachedMeters)
                }
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IMeterFactory.Create(System.Diagnostics.Metrics.MeterOptions)
            System$Diagnostics$Metrics$IMeterFactory$Create()
            {
                return this.Create(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._cachedMeters = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter)))().$ctor$1();
            }
            static $h = 720920;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":6553644,"p":[{"n":"options","p":6750252}],"n":"Create","d":720920,"h":17180590104,"f":1},{"r":65537,"n":"Dispose","d":720920,"h":21475557400,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.List$$($.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter)).$h,"n":"_cachedMeters","d":720920,"h":4295688216,"f":2},{"t":262145,"n":"_disposed","d":720920,"h":8590655512,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":720920,"h":12885622808,"f":1}],"i":[5439532,57475073],"h":720920}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IMeterFactory, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.DefaultMeterFactory`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener", ($self) => class DebugConsoleMetricListener extends $.$spc.System.Object
        {
            /*Timer*/ _timer = null;
            /*int*/ _timerStarted = 0;
            /*IObservableInstrumentsSource?*/ _source = null;
            /*TextWriter?*/ _textWriter = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._timer = new $.$spc.System.Threading.Timer().$ctor$2(new $.$spc.System.Threading.TimerCallback().$ctor(this, this.OnTimer), null, -1/*Timeout.Infinite*/, -1/*Timeout.Infinite*/);
                }
                return this;
            }
            /*string */ get Name()
            {
                return $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.ConsoleMetrics.DebugListenerName;
            }
            /*bool */ InstrumentPublished(/*Instrument*/ instrument, /*out object?*/ userState)
            {
                if (instrument.IsObservable && $.$spc.System.Threading.Interlocked.Exchange($.$ref(() => this._timerStarted, ($v) => this._timerStarted = $v, $.$spc.System.Int32), 1) === 0)
                {
                    this._timer.Change$1($.$spc.System.TimeSpan.FromSeconds(1n), $.$spc.System.TimeSpan.FromSeconds(1n));
                }
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} Started; Description: ${instrument.Description}.`);
                userState.$v = this;
                return true;
            }
            /*void */ MeasurementsCompleted(/*Instrument*/ instrument, /*object?*/ userState)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(userState === this, "userState == this");
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} Stopped.`);
            }
            /*void */ Initialize(/*IObservableInstrumentsSource*/ source)
            {
                return this._source = source;
            }
            /*MeasurementHandlers */ GetMeasurementHandlers()
            {
                return (() =>
                {
                    //new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers()
                    const $t1 = $.$meda.Microsoft.Extensions.Diagnostics.Metrics.MeasurementHandlers;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.ByteHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Byte))().$ctor(this, this.MeasurementHandler);
                    $i1.ShortHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int16))().$ctor(this, this.MeasurementHandler);
                    $i1.IntHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int32))().$ctor(this, this.MeasurementHandler);
                    $i1.LongHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int64))().$ctor(this, this.MeasurementHandler);
                    $i1.FloatHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Single))().$ctor(this, this.MeasurementHandler);
                    $i1.DoubleHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Double))().$ctor(this, this.MeasurementHandler);
                    $i1.DecimalHandler = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Decimal))().$ctor(this, this.MeasurementHandler);
                    return $i1;
                })();
            }
            /*void */ MeasurementHandler(T, /*Instrument*/ instrument, /*T*/ measurement, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ tags, /*object?*/ state)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(state === this, "state == this");
                this.WriteLine(`${instrument.Meter.Name}-${instrument.Name} ${$.$dsp(measurement, T, ($t) => $t.ToString)} ${instrument.Unit}`);
            }
            /*void */ WriteLine(/*string*/ output)
            {
                /*var*/ let writer = this._textWriter ?? $.$scsl.System.Console.Out;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(writer)
                    {
                        writer.WriteLine$13(output);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(writer)
                }
            }
            /*void */ OnTimer(/*object?*/ _)
            {
                this._source?.Microsoft$Extensions$Diagnostics$Metrics$IObservableInstrumentsSource$RecordObservableInstruments();
            }
            /*void */ Dispose()
            {
                return this._timer.Dispose$1();
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.Name.get
            get Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.Initialize(Microsoft.Extensions.Diagnostics.Metrics.IObservableInstrumentsSource)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$Initialize()
            {
                return this.Initialize(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.InstrumentPublished(System.Diagnostics.Metrics.Instrument, out object?)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$InstrumentPublished()
            {
                return this.InstrumentPublished(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.MeasurementsCompleted(System.Diagnostics.Metrics.Instrument, object?)
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$MeasurementsCompleted()
            {
                return this.MeasurementsCompleted(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener.GetMeasurementHandlers()
            Microsoft$Extensions$Diagnostics$Metrics$IMetricsListener$GetMeasurementHandlers()
            {
                return this.GetMeasurementHandlers(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 655384;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065426456,"f":1},"n":"Name","d":655384,"h":25770459160,"f":1}],"m":[{"r":262145,"p":[{"n":"instrument","p":5505068},{"n":"userState","p":131073,"f":2}],"n":"InstrumentPublished","d":655384,"h":34360393752,"f":1},{"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"userState","p":131073}],"n":"MeasurementsCompleted","d":655384,"h":38655361048,"f":1},{"r":65537,"p":[{"n":"source","p":262169}],"n":"Initialize","d":655384,"h":42950328344,"f":1},{"r":327705,"n":"GetMeasurementHandlers","d":655384,"h":47245295640,"f":1},{"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":47248244736},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"g":["T"],"n":"MeasurementHandler","d":655384,"h":51540262936,"f":131074},{"r":65537,"p":[{"n":"output","p":1310721}],"n":"WriteLine","d":655384,"h":55835230232,"f":2},{"r":65537,"p":[{"n":"_","p":131073}],"n":"OnTimer","d":655384,"h":60130197528,"f":2},{"r":65537,"n":"Dispose","d":655384,"h":64425164824,"f":1}],"l":[{"t":138543105,"n":"_timer","d":655384,"h":4295622680,"f":2},{"t":655361,"n":"_timerStarted","d":655384,"h":8590589976,"f":2},{"t":262169,"n":"_source","d":655384,"h":12885557272,"f":2},{"t":62980097,"n":"_textWriter","d":655384,"h":17180524568,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":655384,"h":21475491864,"f":1}],"i":[131097,57475073],"h":655384}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meda.Microsoft.Extensions.Diagnostics.Metrics.IMetricsListener, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.DebugConsoleMetricListener`; }
        });
        
        $asm.$str("$mxdg.System.Diagnostics.BitMapper", ($self) => class BitMapper extends $.$spc.System.ValueType
        {
            /*int*/  get _maxIndex() { return this.$getField(0, 4); }
            /*int*/  set _maxIndex(value) { this.$setField(0, 4, value); }
            /*Span<ulong>*/  get _bitMap() { return this.$getField(4, 12); }
            /*Span<ulong>*/  set _bitMap(value) { this.$setField(4, 12, value); }
            $ctor$2(/*Span<ulong>*/ bitMap)
            {
                super.$ctor$1();
                {
                    this._bitMap = bitMap;
                    this._bitMap.Clear();
                    this._maxIndex = ((((bitMap.Length * $.$spc.System.UInt64.$z) | 0) * 8) | 0);
                }
                return this;
            }
            /*int */ get MaxIndex()
            {
                return this._maxIndex;
            }
            static /*void */ GetIndexAndMask(/*int*/ index, /*out int*/ bitIndex, /*out ulong*/ mask)
            {
                bitIndex.$v = index >> 6;
                /*int*/ let bit = index & ((((($.$spc.System.UInt64.$z * 8) | 0) - 1) | 0));
                mask.$v = BigInt.asUintN(64, 1n << BigInt(bit));
            }
            /*bool */ SetBit(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$mxdg.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$spc.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$spc.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                this._bitMap.get_Item(bitIndex).$v = value | mask;
                return true;
            }
            /*bool */ IsSet(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$mxdg.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$spc.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$spc.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                return ((value & mask) !== 0n);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._maxIndex = this._maxIndex;
                copy._bitMap = this._bitMap.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._maxIndex = 0;
                this._bitMap = $.$default($.$spc.System.Span$$($.$spc.System.UInt64));
            }
            static $h = 1114136;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475950616,"f":1},"n":"MaxIndex","d":1114136,"h":17180983320,"f":1}],"m":[{"r":65537,"p":[{"n":"index","p":655361},{"n":"bitIndex","p":655361,"f":2},{"n":"mask","p":983041,"f":2}],"n":"GetIndexAndMask","d":1114136,"h":25770917912,"f":34},{"r":262145,"p":[{"n":"index","p":655361}],"n":"SetBit","d":1114136,"h":30065885208,"f":1},{"r":262145,"p":[{"n":"index","p":655361}],"n":"IsSet","d":1114136,"h":34360852504,"f":1}],"l":[{"t":655361,"n":"_maxIndex","d":1114136,"h":4296081432,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.UInt64).$h,"n":"_bitMap","d":1114136,"h":8591048728,"f":2}],"c":[{"p":[{"n":"bitMap","p":$.$spc.System.Span$$($.$spc.System.UInt64).$h}],"n":".ctor","o":"$ctor$2","d":1114136,"h":12886016024,"f":1},{"n":".ctor","o":"$ctor$3","d":1114136,"h":38655819800,"f":1}],"h":1114136}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.BitMapper`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions", ($self) => class MetricsConfigureOptions extends $.$spc.System.Object
        {
            /*string*/ static EnabledMetricsKey = null;
            /*string*/ static EnabledGlobalMetricsKey = null;
            /*string*/ static EnabledLocalMetricsKey = null;
            /*string*/ static DefaultKey = null;
            /*IConfiguration*/ _configuration = null;
            $ctor$1(/*IConfiguration*/ configuration)
            {
                super.$ctor();
                {
                    this._configuration = $.$firstOf(configuration, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("configuration") });
                }
                return this;
            }
            /*void */ Configure(/*MetricsOptions*/ options)
            {
                return this.LoadConfig(options);
            }
            /*void */ LoadConfig(/*MetricsOptions*/ options)
            {
                var $en2 = this._configuration.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var configurationSection = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$spc.System.String.Equals$3.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledMetrics"/*EnabledMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 1/*MeterScope.Global*/ | 2/*MeterScope.Local*/, null);
                        }
                        else if ($.$spc.System.String.Equals$3.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledGlobalMetrics"/*EnabledGlobalMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 1/*MeterScope.Global*/, null);
                        }
                        else if ($.$spc.System.String.Equals$3.call(configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, "EnabledLocalMetrics"/*EnabledLocalMetricsKey*/, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, configurationSection, 2/*MeterScope.Local*/, null);
                        }
                        else 
                        {
                            /*var*/ let listenerName = configurationSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            /*var*/ let enabledMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledMetrics"/*EnabledMetricsKey*/);
                            if (enabledMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledMetricsSection, 1/*MeterScope.Global*/ | 2/*MeterScope.Local*/, listenerName);
                            }
                            /*var*/ let enabledGlobalMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledGlobalMetrics"/*EnabledGlobalMetricsKey*/);
                            if (enabledGlobalMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledGlobalMetricsSection, 1/*MeterScope.Global*/, listenerName);
                            }
                            /*var*/ let enabledLocalMetricsSection = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetSection("EnabledLocalMetrics"/*EnabledLocalMetricsKey*/);
                            if (enabledLocalMetricsSection !== null)
                            {
                                $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadMeterRules(options, enabledLocalMetricsSection, 2/*MeterScope.Local*/, listenerName);
                            }
                        }
                    }
                }
            }
            static /*void */ LoadMeterRules(/*MetricsOptions*/ options, /*IConfigurationSection*/ configurationSection, /*MeterScope*/ scopes, /*string?*/ listenerName)
            {
                var $en2 = configurationSection.Microsoft$Extensions$Configuration$IConfiguration$GetChildren().System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var meterSection = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let meterEnabled;
                        if ($.$sl.System.Linq.Enumerable.Any($.$meca.Microsoft.Extensions.Configuration.IConfigurationSection, meterSection.Microsoft$Extensions$Configuration$IConfiguration$GetChildren()))
                        {
                            $.$mxdg.Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions.LoadInstrumentRules(options, meterSection, scopes, listenerName);
                        }
                        else if ($.$spc.System.Boolean.TryParse(meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Value, $.$ref(() => meterEnabled, ($v) => meterEnabled = $v, $.$spc.System.Boolean)))
                        {
                            /*var*/ let meterName = meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key;
                            if ($.$spc.System.String.Equals$5("Default"/*DefaultKey*/, meterName, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                meterName = null;
                            }
                            options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule().$ctor$1(meterName, null, listenerName, scopes, meterEnabled), [$.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule]);
                        }
                    }
                }
            }
            static /*void */ LoadInstrumentRules(/*MetricsOptions*/ options, /*IConfigurationSection*/ meterSection, /*MeterScope*/ scopes, /*string?*/ listenerName)
            {
                var $en2 = $.$meca.Microsoft.Extensions.Configuration.ConfigurationExtensions.AsEnumerable$1(meterSection, true).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var instrumentPair = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*var*/ let instrumentEnabled;
                        if ($.$spc.System.Boolean.TryParse(instrumentPair.Value, $.$ref(() => instrumentEnabled, ($v) => instrumentEnabled = $v, $.$spc.System.Boolean)))
                        {
                            /*var*/ let instrumentName = instrumentPair.Key;
                            if ($.$spc.System.String.Equals$5("Default"/*DefaultKey*/, instrumentName, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                instrumentName = null;
                            }
                            options.Rules.System$Collections$Generic$ICollection$$$Add(new $.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule().$ctor$1(meterSection.Microsoft$Extensions$Configuration$IConfigurationSection$Key, instrumentName, listenerName, scopes, instrumentEnabled), [$.$meda.Microsoft.Extensions.Diagnostics.Metrics.InstrumentRule]);
                        }
                    }
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.Options.IConfigureOptions<Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions>.Configure(Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions)
            Microsoft$Extensions$Options$IConfigureOptions$$$Configure()
            {
                return this.Configure(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EnabledMetricsKey = "EnabledMetrics";
                }
                {
                    this.EnabledGlobalMetricsKey = "EnabledGlobalMetrics";
                }
                {
                    this.EnabledLocalMetricsKey = "EnabledLocalMetrics";
                }
                {
                    this.DefaultKey = "Default";
                }
            }
            static $h = 524312;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"options","p":524313}],"n":"Configure","d":524312,"h":30065295384,"f":1},{"r":65537,"p":[{"n":"options","p":524313}],"n":"LoadConfig","d":524312,"h":34360262680,"f":2},{"r":65537,"p":[{"n":"options","p":524313},{"n":"configurationSection","p":589838},{"n":"scopes","p":393241},{"n":"listenerName","p":1310721}],"n":"LoadMeterRules","d":524312,"h":38655229976,"f":40},{"r":65537,"p":[{"n":"options","p":524313},{"n":"meterSection","p":589838},{"n":"scopes","p":393241},{"n":"listenerName","p":1310721}],"n":"LoadInstrumentRules","d":524312,"h":42950197272,"f":40}],"l":[{"t":1310721,"n":"EnabledMetricsKey","d":524312,"h":4295491608,"f":34},{"t":1310721,"n":"EnabledGlobalMetricsKey","d":524312,"h":8590458904,"f":34},{"t":1310721,"n":"EnabledLocalMetricsKey","d":524312,"h":12885426200,"f":34},{"t":1310721,"n":"DefaultKey","d":524312,"h":17180393496,"f":34},{"t":262158,"n":"_configuration","d":524312,"h":21475360792,"f":2}],"c":[{"p":[{"n":"configuration","p":262158}],"n":".ctor","o":"$ctor$1","d":524312,"h":25770328088,"f":1}],"i":[$.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions).$h],"h":524312}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$meo.Microsoft.Extensions.Options.IConfigureOptions$$($.$meda.Microsoft.Extensions.Diagnostics.Metrics.MetricsOptions) ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.Configuration.MetricsConfigureOptions`; }
        });
        
        $asm.$cls("$mxdg.Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter", ($self) => class FactoryMeter extends $.$sdd.System.Diagnostics.Metrics.Meter
        {
            $ctor$5(/*MeterOptions*/ options)
            {
                super.$ctor$1(options);
                {
                }
                return this;
            }
            /*void */ Release()
            {
                return super.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static $h = 786456;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6553644,"m":[{"r":65537,"n":"Release","d":786456,"h":8590721048,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":786456,"h":12885688344,"f":32772}],"c":[{"p":[{"n":"options","p":6750252}],"n":".ctor","o":"$ctor$5","d":786456,"h":4295753752,"f":1}],"i":[57475073],"h":786456}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Meter; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Diagnostics.Metrics.FactoryMeter`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.Microsoft.Extensions.Configuration.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.Net.Quic", "NetJs.Microsoft.Extensions.Configuration", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.Microsoft.Extensions.Configuration.Binder", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Diagnostics.Abstractions", "NetJs.Microsoft.Extensions.Options.ConfigurationExtensions"))