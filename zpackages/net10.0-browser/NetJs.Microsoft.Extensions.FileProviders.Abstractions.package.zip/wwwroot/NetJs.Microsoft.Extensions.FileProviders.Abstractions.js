
//--TRIMMABLE-BOUNDARY-START(99)
(function ($global, $, $$, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sri, $sl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Abstractions", 
    {
  "h": 99,
  "f": "Microsoft.Extensions.FileProviders.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262243)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IFileProvider", ($self) => class IFileProvider
        {
            static $h = 262243;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196835),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "o": "Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo",
      "d": 262243,
      "h": 8590196835,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590196835),
//--TRIMMABLE-BOUNDARY-START(4295229539),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "o": "Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents",
      "d": 262243,
      "h": 4295229539,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229539),
//--TRIMMABLE-BOUNDARY-START(12885164131),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "o": "Microsoft$Extensions$FileProviders$IFileProvider$Watch",
      "d": 262243,
      "h": 12885164131,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885164131)
  ],
  "h": 262243
}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262243)
        
        
        //--TRIMMABLE-BOUNDARY-START(196707)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IFileInfo", ($self) => class IFileInfo
        {
            static $h = 196707;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590131299),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180065891,
        "f": 50331905
      },
      "n": "Exists",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$Exists",
      "d": 196707,
      "h": 8590131299,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590131299),
//--TRIMMABLE-BOUNDARY-START(73014640739),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869667,
        "f": 50331905
      },
      "n": "Length",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$Length",
      "d": 196707,
      "h": 73014640739,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73014640739),
//--TRIMMABLE-BOUNDARY-START(81604575331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738851,
        "f": 50331905
      },
      "n": "PhysicalPath",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath",
      "d": 196707,
      "h": 81604575331,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81604575331),
//--TRIMMABLE-BOUNDARY-START(77309608035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804259,
        "f": 50331905
      },
      "n": "Name",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$Name",
      "d": 196707,
      "h": 77309608035,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77309608035),
//--TRIMMABLE-BOUNDARY-START(68719673443),
    {
      "p": 65339393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935075,
        "f": 50331905
      },
      "n": "LastModified",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$LastModified",
      "d": 196707,
      "h": 68719673443,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68719673443),
//--TRIMMABLE-BOUNDARY-START(64424706147),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770000483,
        "f": 50331905
      },
      "n": "IsDirectory",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory",
      "d": 196707,
      "h": 64424706147,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64424706147)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164003),
    {
      "r": 94830593,
      "n": "CreateReadStream",
      "o": "Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream",
      "d": 196707,
      "h": 4295164003,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164003)
  ],
  "h": 196707
}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196707)
        
        
        //--TRIMMABLE-BOUNDARY-START(131171)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents", ($self) => class IDirectoryContents
        {
            static $h = 131171;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295098467),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885033059,
        "f": 50331905
      },
      "n": "Exists",
      "o": "Microsoft$Extensions$FileProviders$IDirectoryContents$Exists",
      "d": 131171,
      "h": 4295098467,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295098467)
  ],
  "i": [$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,62521345
  ],
  "h": 131171
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131171)
        
        
        //--TRIMMABLE-BOUNDARY-START(589923)
        $asm.$cls("$mefa.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103079805027)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(103079805027)
            
            //--TRIMMABLE-BOUNDARY-START(94489870435)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(94489870435)
            
            //--TRIMMABLE-BOUNDARY-START(98784837731)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mefa.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Abstractions", $.$mefa.System.SR.$type.Assembly);
                    $.$mefa.System.SR.s_resourceManager = temp;
                }
                return $.$mefa.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(98784837731)
            
            //--TRIMMABLE-BOUNDARY-START(8590524515)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefa.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mefa.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524515)
            
            //--TRIMMABLE-BOUNDARY-START(12885491811)
            static /*string */ get FileNotExists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file {0} does not exist.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885491811)
            
            //--TRIMMABLE-BOUNDARY-START(51540197475)
            static /*string */ FormatFileNotExists(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The file {0} does not exist.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197475)
            
            //--TRIMMABLE-BOUNDARY-START(107374772323)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(107374772323)
            
            //--TRIMMABLE-BOUNDARY-START(90194903139)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194903139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903139)
            
            //--TRIMMABLE-BOUNDARY-START(120259674211)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259674211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259674211)
            
            //--TRIMMABLE-BOUNDARY-START(81604968547)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefa.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968547)
            
            //--TRIMMABLE-BOUNDARY-START(85899935843)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mefa.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935843)
            
            //--TRIMMABLE-BOUNDARY-START(17180459107)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459107)
            
            //--TRIMMABLE-BOUNDARY-START(21475426403)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426403)
            
            //--TRIMMABLE-BOUNDARY-START(25770393699)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393699)
            
            //--TRIMMABLE-BOUNDARY-START(30065360995)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360995)
            
            //--TRIMMABLE-BOUNDARY-START(34360328291)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(34360328291)
            
            //--TRIMMABLE-BOUNDARY-START(38655295587)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655295587)
            
            //--TRIMMABLE-BOUNDARY-START(42950262883)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262883)
            
            //--TRIMMABLE-BOUNDARY-START(47245230179)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230179)
            
            //--TRIMMABLE-BOUNDARY-START(4295557219)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(107374772323)
                    this.s_usingResourceKeys = $.$mefa.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(107374772323)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295557219)
            
            static $h = 589923;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 589923
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589923)
        
        
        //--TRIMMABLE-BOUNDARY-START(65635)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064836707)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30064836707)
            
            //--TRIMMABLE-BOUNDARY-START(8590000227)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000227);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000227)
            
            //--TRIMMABLE-BOUNDARY-START(17179934819)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17179934819)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //--TRIMMABLE-BOUNDARY-START(4295032931)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032931)
            
            static $h = 65635;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836707),
    {
      "p": 65635,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869411,
        "f": 50331681
      },
      "n": "Instance",
      "d": 65635,
      "h": 30064836707,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836707)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934819),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 65635,
      "h": 17179934819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000227),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65635,
      "h": 8590000227,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590000227)
  ],
  "i": [90177537
  ],
  "h": 65635
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65635)
        
        
        //--TRIMMABLE-BOUNDARY-START(524387)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NullFileProvider", ($self) => class NullFileProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590458979)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458979)
            
            //--TRIMMABLE-BOUNDARY-START(12885426275)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426275)
            
            //--TRIMMABLE-BOUNDARY-START(17180393571)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393571)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            Microsoft$Extensions$FileProviders$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 524387;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458979),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 524387,
      "h": 8590458979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458979),
//--TRIMMABLE-BOUNDARY-START(12885426275),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 524387,
      "h": 12885426275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426275),
//--TRIMMABLE-BOUNDARY-START(17180393571),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 524387,
      "h": 17180393571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491683),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524387,
      "h": 4295491683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491683)
  ],
  "i": [262243
  ],
  "h": 524387
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NullFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524387)
        
        
        //--TRIMMABLE-BOUNDARY-START(458851)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NullChangeToken", ($self) => class NullChangeToken extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835033699)
            /*NullChangeToken*/ static Singleton = null;
            //--TRIMMABLE-BOUNDARY-END(55835033699)
            
            //--TRIMMABLE-BOUNDARY-START(8590393443)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393443)
            
            //--TRIMMABLE-BOUNDARY-START(47245099107)
            /*bool */ get HasChanged()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099107)
            
            //--TRIMMABLE-BOUNDARY-START(17180328035)
            /*bool */ get ActiveChangeCallbacks()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328035)
            
            //--TRIMMABLE-BOUNDARY-START(51540066403)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066403)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //--TRIMMABLE-BOUNDARY-START(4295426147)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Singleton = new $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426147)
            
            static $h = 458851;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835033699),
    {
      "p": 458851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950131811,
        "f": 50331681
      },
      "n": "Singleton",
      "d": 458851,
      "h": 55835033699,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835033699),
//--TRIMMABLE-BOUNDARY-START(47245099107),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360197219,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 458851,
      "h": 47245099107,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245099107),
//--TRIMMABLE-BOUNDARY-START(17180328035),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262627,
        "f": 50331649
      },
      "n": "ActiveChangeCallbacks",
      "d": 458851,
      "h": 17180328035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180328035)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540066403),
    {
      "r": 90177537,
      "p": [
        {
          "n": "callback",
          "p": $.$$.System.Action$$($.$$.System.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 458851,
      "h": 51540066403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393443),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458851,
      "h": 8590393443,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590393443)
  ],
  "i": [720981
  ],
  "h": 458851
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NullChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458851)
        
        
        //--TRIMMABLE-BOUNDARY-START(393315)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo", ($self) => class NotFoundFileInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360611)
            $ctor$1(/*string*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360611);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360611)
            
            //--TRIMMABLE-BOUNDARY-START(17180262499)
            /*bool */ get Exists()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262499)
            
            //--TRIMMABLE-BOUNDARY-START(73014837347)
            /*bool */ get IsDirectory()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73014837347)
            
            //--TRIMMABLE-BOUNDARY-START(77309804643)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.System.DateTimeOffset.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804643)
            
            //--TRIMMABLE-BOUNDARY-START(81604771939)
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            //--TRIMMABLE-BOUNDARY-END(81604771939)
            
            //--TRIMMABLE-BOUNDARY-START(85899739235)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(85899739235)
            
            //--TRIMMABLE-BOUNDARY-START(90194706531)
            /*string? */ get PhysicalPath()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(90194706531)
            
            //--TRIMMABLE-BOUNDARY-START(12885295203)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.IO.FileNotFoundException().$ctor$19($.$mefa.System.SR.Format$6($.$mefa.System.SR.FileNotExists, this.Name));
            }
            //--TRIMMABLE-BOUNDARY-END(12885295203)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            static $h = 393315;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180262499),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197091,
        "f": 50331649
      },
      "n": "Exists",
      "d": 393315,
      "h": 17180262499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180262499),
//--TRIMMABLE-BOUNDARY-START(73014837347),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131683,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 393315,
      "h": 73014837347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014837347),
//--TRIMMABLE-BOUNDARY-START(77309804643),
    {
      "p": 65339393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066275,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 393315,
      "h": 77309804643,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309804643),
//--TRIMMABLE-BOUNDARY-START(81604771939),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000867,
        "f": 50331649
      },
      "n": "Length",
      "d": 393315,
      "h": 81604771939,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771939),
//--TRIMMABLE-BOUNDARY-START(85899739235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129935459,
        "f": 50331649
      },
      "n": "Name",
      "d": 393315,
      "h": 85899739235,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899739235),
//--TRIMMABLE-BOUNDARY-START(90194706531),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719870051,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 393315,
      "h": 90194706531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194706531)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295203),
    {
      "r": 94830593,
      "n": "CreateReadStream",
      "d": 393315,
      "h": 12885295203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360611),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393315,
      "h": 4295360611,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360611)
  ],
  "i": [196707
  ],
  "h": 393315
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NotFoundFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393315)
        
        
        //--TRIMMABLE-BOUNDARY-START(327779)
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents", ($self) => class NotFoundDirectoryContents extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42950000739)
            /*NotFoundDirectoryContents*/ static Singleton = null;
            //--TRIMMABLE-BOUNDARY-END(42950000739)
            
            //--TRIMMABLE-BOUNDARY-START(17180196963)
            /*bool */ get Exists()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196963)
            
            //--TRIMMABLE-BOUNDARY-START(38655033443)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.System.Linq.Enumerable.Empty($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033443)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47244968035, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244968035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47244968035, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-START(4295295075)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Singleton = new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295295075)
            
            static $h = 327779;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950000739),
    {
      "p": 327779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066147,
        "f": 50331681
      },
      "n": "Singleton",
      "d": 327779,
      "h": 42950000739,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950000739),
//--TRIMMABLE-BOUNDARY-START(17180196963),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131555,
        "f": 50331649
      },
      "n": "Exists",
      "d": 327779,
      "h": 17180196963,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180196963)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033443),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 327779,
      "h": 38655033443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590262371),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327779,
      "h": 8590262371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262371)
  ],
  "i": [131171,$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,62521345
  ],
  "h": 327779
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NotFoundDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327779)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq"))
//--TRIMMABLE-BOUNDARY-END(99)
