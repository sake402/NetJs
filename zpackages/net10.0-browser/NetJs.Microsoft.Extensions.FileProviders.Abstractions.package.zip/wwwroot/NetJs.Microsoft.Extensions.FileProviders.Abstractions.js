
//--TRIMMABLE-BOUNDARY-START(99)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $sdt, $st, $scc, $snv, $spu, $sr, $sris, $sl) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Abstractions", 
    {
  "h": 99,
  "f": "Microsoft.Extensions.FileProviders.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196707)
        $asm.$cls(`$mefa.MEF.IFileInfo`, ($self) => class IFileInfo
        {
            static $h = 196707;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590131299),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180065891,
        "f": 50331905
      },
      "n": "Exists",
      "o": "MEF$IFileInfo$Exists",
      "d": 196707,
      "h": 8590131299,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590131299),
//--TRIMMABLE-BOUNDARY-START(73014640739),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869667,
        "f": 50331905
      },
      "n": "Length",
      "o": "MEF$IFileInfo$Length",
      "d": 196707,
      "h": 73014640739,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(73014640739),
//--TRIMMABLE-BOUNDARY-START(81604575331),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738851,
        "f": 50331905
      },
      "n": "PhysicalPath",
      "o": "MEF$IFileInfo$PhysicalPath",
      "d": 196707,
      "h": 81604575331,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81604575331),
//--TRIMMABLE-BOUNDARY-START(77309608035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804259,
        "f": 50331905
      },
      "n": "Name",
      "o": "MEF$IFileInfo$Name",
      "d": 196707,
      "h": 77309608035,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(77309608035),
//--TRIMMABLE-BOUNDARY-START(68719673443),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935075,
        "f": 50331905
      },
      "n": "LastModified",
      "o": "MEF$IFileInfo$LastModified",
      "d": 196707,
      "h": 68719673443,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68719673443),
//--TRIMMABLE-BOUNDARY-START(64424706147),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770000483,
        "f": 50331905
      },
      "n": "IsDirectory",
      "o": "MEF$IFileInfo$IsDirectory",
      "d": 196707,
      "h": 64424706147,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64424706147)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295164003),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "o": "MEF$IFileInfo$CreateReadStream",
      "d": 196707,
      "h": 4295164003,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295164003)
  ],
  "h": 196707
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.IFileInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}IFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196707)
        
        

        //--TRIMMABLE-BOUNDARY-START(262243)
        $asm.$cls(`$mefa.MEF.IFileProvider`, ($self) => class IFileProvider
        {
            static $h = 262243;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196835),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "o": "MEF$IFileProvider$GetFileInfo",
      "d": 262243,
      "h": 8590196835,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590196835),
//--TRIMMABLE-BOUNDARY-START(4295229539),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "o": "MEF$IFileProvider$GetDirectoryContents",
      "d": 262243,
      "h": 4295229539,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229539),
//--TRIMMABLE-BOUNDARY-START(12885164131),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "o": "MEF$IFileProvider$Watch",
      "d": 262243,
      "h": 12885164131,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885164131)
  ],
  "h": 262243
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.IFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}IFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262243)
        
        

        //--TRIMMABLE-BOUNDARY-START(131171)
        $asm.$cls(`$mefa.MEF.IDirectoryContents`, ($self) => class IDirectoryContents
        {
            static $h = 131171;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295098467),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885033059,
        "f": 50331905
      },
      "n": "Exists",
      "o": "MEF$IDirectoryContents$Exists",
      "d": 131171,
      "h": 4295098467,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295098467)
  ],
  "h": 131171
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.IDirectoryContents`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}IDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131171)
        
        

        //--TRIMMABLE-BOUNDARY-START(589923)
        $asm.$cls(`$mefa.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(103079805027)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(103079805027)
            
            //--TRIMMABLE-BOUNDARY-START(94489870435)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(94489870435)
            
            //--TRIMMABLE-BOUNDARY-START(98784837731)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mefa.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Abstractions", $.$mefa.S.SR.$type.Assembly);
                    $.$mefa.S.SR.s_resourceManager = temp;
                }
                return $.$mefa.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(98784837731)
            
            //--TRIMMABLE-BOUNDARY-START(8590524515)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefa.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mefa.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524515)
            
            //--TRIMMABLE-BOUNDARY-START(12885491811)
            static /*string */ get FileNotExists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file {0} does not exist.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885491811)
            
            //--TRIMMABLE-BOUNDARY-START(51540197475)
            static /*string */ FormatFileNotExists(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The file {0} does not exist.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540197475)
            
            //--TRIMMABLE-BOUNDARY-START(107374772323)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(107374772323)
            
            //--TRIMMABLE-BOUNDARY-START(90194903139)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194903139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903139)
            
            //--TRIMMABLE-BOUNDARY-START(120259674211)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259674211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259674211)
            
            //--TRIMMABLE-BOUNDARY-START(85899935843)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefa.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935843)
            
            //--TRIMMABLE-BOUNDARY-START(81604968547)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mefa.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968547)
            
            //--TRIMMABLE-BOUNDARY-START(42950262883)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950262883)
            
            //--TRIMMABLE-BOUNDARY-START(38655295587)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655295587)
            
            //--TRIMMABLE-BOUNDARY-START(34360328291)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328291);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360328291)
            
            //--TRIMMABLE-BOUNDARY-START(47245230179)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefa.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230179)
            
            //--TRIMMABLE-BOUNDARY-START(25770393699)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393699)
            
            //--TRIMMABLE-BOUNDARY-START(21475426403)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475426403)
            
            //--TRIMMABLE-BOUNDARY-START(17180459107)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459107);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefa.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180459107)
            
            //--TRIMMABLE-BOUNDARY-START(30065360995)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefa.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360995)
            
            //--TRIMMABLE-BOUNDARY-START(4295557219)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(107374772323)
                    this.s_usingResourceKeys = $.$mefa.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(107374772323)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295557219)
            
            static $h = 589923;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 589923
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589923)
        
        

        //--TRIMMABLE-BOUNDARY-START(65635)
        $asm.$cls(`$mefa.MEF.EmptyDisposable`, ($self) => class EmptyDisposable extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064836707)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30064836707)
            
            //--TRIMMABLE-BOUNDARY-START(12884967523)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967523);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967523)
            
            //--TRIMMABLE-BOUNDARY-START(17179934819)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17179934819)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12884967523)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967523)
            
            //--TRIMMABLE-BOUNDARY-START(8590000227)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836707)
                    this.Instance = new $.$mefa.MEF.EmptyDisposable().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30064836707)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000227)
            
            static $h = 65635;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836707),
    {
      "p": 65635,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869411,
        "f": 50331681
      },
      "n": "Instance",
      "d": 65635,
      "h": 30064836707,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836707)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934819),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 65635,
      "h": 17179934819,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934819)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967523),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65635,
      "h": 12884967523,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967523)
  ],
  "h": 65635
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65635)
        
        

        //--TRIMMABLE-BOUNDARY-START(458851)
        $asm.$cls(`$mefa.MEF.NullChangeToken`, ($self) => class NullChangeToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(55835033699)
            /*NullChangeToken*/ static Singleton = null;
            //--TRIMMABLE-BOUNDARY-END(55835033699)
            
            //--TRIMMABLE-BOUNDARY-START(12885360739)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360739)
            
            //--TRIMMABLE-BOUNDARY-START(47245099107)
            /*bool */ get HasChanged()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099107)
            
            //--TRIMMABLE-BOUNDARY-START(17180328035)
            /*bool */ get ActiveChangeCallbacks()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328035)
            
            //--TRIMMABLE-BOUNDARY-START(51540066403)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefa.MEF.EmptyDisposable.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066403)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            MEP$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //--TRIMMABLE-BOUNDARY-START(12885360739)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360739)
            
            //--TRIMMABLE-BOUNDARY-START(8590393443)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(55835033699)
                    this.Singleton = new $.$mefa.MEF.NullChangeToken().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(55835033699)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393443)
            
            static $h = 458851;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835033699),
    {
      "p": 458851,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950131811,
        "f": 50331681
      },
      "n": "Singleton",
      "d": 458851,
      "h": 55835033699,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835033699),
//--TRIMMABLE-BOUNDARY-START(47245099107),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360197219,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 458851,
      "h": 47245099107,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245099107),
//--TRIMMABLE-BOUNDARY-START(17180328035),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262627,
        "f": 50331649
      },
      "n": "ActiveChangeCallbacks",
      "d": 458851,
      "h": 17180328035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180328035)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540066403),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 458851,
      "h": 51540066403,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066403)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360739),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458851,
      "h": 12885360739,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885360739)
  ],
  "h": 458851
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.NullChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}NullChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458851)
        
        

        //--TRIMMABLE-BOUNDARY-START(524387)
        $asm.$cls(`$mefa.MEF.NullFileProvider`, ($self) => class NullFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590458979)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458979);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.MEF.NotFoundDirectoryContents.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458979)
            
            //--TRIMMABLE-BOUNDARY-START(12885426275)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426275);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mefa.MEF.NotFoundFileInfo().$ctor$1(subpath);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426275)
            
            //--TRIMMABLE-BOUNDARY-START(17180393571)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393571);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefa.MEF.NullChangeToken.Singleton;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393571)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //--TRIMMABLE-BOUNDARY-START(4295491683)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491683)
            
            //--TRIMMABLE-BOUNDARY-START(4295491683)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491683)
            
            static $h = 524387;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458979),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 524387,
      "h": 8590458979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458979),
//--TRIMMABLE-BOUNDARY-START(12885426275),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 524387,
      "h": 12885426275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426275),
//--TRIMMABLE-BOUNDARY-START(17180393571),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 524387,
      "h": 17180393571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393571)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491683),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524387,
      "h": 4295491683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491683)
  ],
  "h": 524387
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.NullFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}NullFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524387)
        
        

        //--TRIMMABLE-BOUNDARY-START(393315)
        $asm.$cls(`$mefa.MEF.NotFoundFileInfo`, ($self) => class NotFoundFileInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590327907)
            $ctor$1(/*string*/ name)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327907)
            
            //--TRIMMABLE-BOUNDARY-START(17180262499)
            /*bool */ get Exists()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262499)
            
            //--TRIMMABLE-BOUNDARY-START(73014837347)
            /*bool */ get IsDirectory()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73014837347)
            
            //--TRIMMABLE-BOUNDARY-START(77309804643)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.S.DateTimeOffset.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804643)
            
            //--TRIMMABLE-BOUNDARY-START(81604771939)
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            //--TRIMMABLE-BOUNDARY-END(81604771939)
            
            //--TRIMMABLE-BOUNDARY-START(85899739235)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(85899739235)
            
            //--TRIMMABLE-BOUNDARY-START(90194706531)
            /*string? */ get PhysicalPath()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(90194706531)
            
            //--TRIMMABLE-BOUNDARY-START(12885295203)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.SI.FileNotFoundException().$ctor$19($.$mefa.S.SR.Format$6($.$mefa.S.SR.FileNotExists, this.Name));
            }
            //--TRIMMABLE-BOUNDARY-END(12885295203)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get MEF$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get MEF$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get MEF$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get MEF$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get MEF$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get MEF$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            MEF$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            static $h = 393315;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180262499),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197091,
        "f": 50331649
      },
      "n": "Exists",
      "d": 393315,
      "h": 17180262499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180262499),
//--TRIMMABLE-BOUNDARY-START(73014837347),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131683,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 393315,
      "h": 73014837347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014837347),
//--TRIMMABLE-BOUNDARY-START(77309804643),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066275,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 393315,
      "h": 77309804643,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309804643),
//--TRIMMABLE-BOUNDARY-START(81604771939),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000867,
        "f": 50331649
      },
      "n": "Length",
      "d": 393315,
      "h": 81604771939,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771939),
//--TRIMMABLE-BOUNDARY-START(85899739235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129935459,
        "f": 50331649
      },
      "n": "Name",
      "d": 393315,
      "h": 85899739235,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899739235),
//--TRIMMABLE-BOUNDARY-START(90194706531),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719870051,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 393315,
      "h": 90194706531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194706531)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295203),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 393315,
      "h": 12885295203,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295203)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327907),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393315,
      "h": 8590327907,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327907)
  ],
  "h": 393315
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.NotFoundFileInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}NotFoundFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393315)
        
        

        //--TRIMMABLE-BOUNDARY-START(327779)
        $asm.$cls(`$mefa.MEF.NotFoundDirectoryContents`, ($self) => class NotFoundDirectoryContents extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(42950000739)
            /*NotFoundDirectoryContents*/ static Singleton = null;
            //--TRIMMABLE-BOUNDARY-END(42950000739)
            
            //--TRIMMABLE-BOUNDARY-START(17180196963)
            /*bool */ get Exists()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196963)
            
            //--TRIMMABLE-BOUNDARY-START(38655033443)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.Empty($.$mefa.MEF.IFileInfo).SCG$IEnumerable$$$GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655033443)
            
            //--TRIMMABLE-BOUNDARY-START(47244968035)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244968035);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244968035)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get MEF$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(12885229667)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229667)
            
            //--TRIMMABLE-BOUNDARY-START(12885229667)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12885229667)
            
            //--TRIMMABLE-BOUNDARY-START(8590262371)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(42950000739)
                    this.Singleton = new $.$mefa.MEF.NotFoundDirectoryContents().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(42950000739)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262371)
            
            static $h = 327779;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950000739),
    {
      "p": 327779,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066147,
        "f": 50331681
      },
      "n": "Singleton",
      "d": 327779,
      "h": 42950000739,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950000739),
//--TRIMMABLE-BOUNDARY-START(17180196963),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131555,
        "f": 50331649
      },
      "n": "Exists",
      "d": 327779,
      "h": 17180196963,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180196963)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033443),
    {
      "r": $.$$.SCG.IEnumerator$$($.$mefa.MEF.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 327779,
      "h": 38655033443,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033443)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229667),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327779,
      "h": 12885229667,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229667)
  ],
  "h": 327779
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IDirectoryContents, $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.NotFoundDirectoryContents`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}NotFoundDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327779)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq"));
})();
//--TRIMMABLE-BOUNDARY-END(99)
