
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $st, $mep, $sr, $scc, $sris, $sl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Abstractions", 
    {"h":26,"f":"Microsoft.Extensions.FileProviders.Abstractions","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Abstractions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IFileInfo", ($self) => class IFileInfo
        {
            static $h = 196634;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590131226,"f":257},"n":"Exists","o":"Microsoft$Extensions$FileProviders$IFileInfo$Exists","d":196634,"h":4295163930,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":17180065818,"f":257},"n":"Length","o":"Microsoft$Extensions$FileProviders$IFileInfo$Length","d":196634,"h":12885098522,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":25770000410,"f":257},"n":"PhysicalPath","o":"Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath","d":196634,"h":21475033114,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":34359935002,"f":257},"n":"Name","o":"Microsoft$Extensions$FileProviders$IFileInfo$Name","d":196634,"h":30064967706,"f":257},{"p":34340865,"g":{"r":0,"d":0,"h":42949869594,"f":257},"n":"LastModified","o":"Microsoft$Extensions$FileProviders$IFileInfo$LastModified","d":196634,"h":38654902298,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":51539804186,"f":257},"n":"IsDirectory","o":"Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory","d":196634,"h":47244836890,"f":257}],"m":[{"r":62128129,"n":"CreateReadStream","o":"Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream","d":196634,"h":55834771482,"f":257}],"h":196634}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IFileInfo`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IFileProvider", ($self) => class IFileProvider
        {
            static $h = 262170;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":196634,"p":[{"n":"subpath","p":1310721}],"n":"GetFileInfo","o":"Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo","d":262170,"h":4295229466,"f":257},{"r":131098,"p":[{"n":"subpath","p":1310721}],"n":"GetDirectoryContents","o":"Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents","d":262170,"h":8590196762,"f":257},{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"Watch","o":"Microsoft$Extensions$FileProviders$IFileProvider$Watch","d":262170,"h":12885164058,"f":257}],"h":262170}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IFileProvider`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents", ($self) => class IDirectoryContents
        {
            static $h = 131098;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590065690,"f":257},"n":"Exists","o":"Microsoft$Extensions$FileProviders$IDirectoryContents$Exists","d":131098,"h":4295098394,"f":257}],"i":[$.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31588353],"h":131098}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IDirectoryContents`; }
        });
        
        $asm.$cls("$mefa.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mefa.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Abstractions", $.$mefa.System.SR.$type.Assembly);
                    $.$mefa.System.SR.s_resourceManager = temp;
                }
                return $.$mefa.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mefa.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mefa.System.SR.resourceCulture = value;
            }
            static /*string */ get FileNotExists()
            {
                return "The file {0} does not exist.";
            }
            static /*string */ FormatFileNotExists(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file {0} does not exist.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mefa.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefa.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mefa.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefa.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefa.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mefa.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 589850;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":589850}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo", ($self) => class NotFoundFileInfo extends $.$spc.System.Object
        {
            $ctor$1(/*string*/ name)
            {
                super.$ctor();
                {
                    this.Name = name;
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return false;
            }
            /*bool */ get IsDirectory()
            {
                return false;
            }
            /*DateTimeOffset */ get LastModified()
            {
                return $.$spc.System.DateTimeOffset.MinValue;
            }
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            /*string*/ Name = null;
            /*string? */ get PhysicalPath()
            {
                return null;
            }
            /*Stream */ CreateReadStream()
            {
                throw new $.$spc.System.IO.FileNotFoundException().$ctor$15($.$mefa.System.SR.Format($.$mefa.System.SR.FileNotExists, this.Name));
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                return this.Length;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                return this.PhysicalPath;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                return this.IsDirectory;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                return this.CreateReadStream(...arguments);
            }
            static $h = 393242;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885295130,"f":1},"n":"Exists","d":393242,"h":8590327834,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475229722,"f":1},"n":"IsDirectory","d":393242,"h":17180262426,"f":1},{"p":34340865,"g":{"r":0,"d":0,"h":30065164314,"f":1},"n":"LastModified","d":393242,"h":25770197018,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":38655098906,"f":1},"n":"Length","d":393242,"h":34360131610,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540000794,"f":1},"n":"Name","d":393242,"h":47245033498,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60129935386,"f":1},"n":"PhysicalPath","d":393242,"h":55834968090,"f":1}],"m":[{"r":62128129,"n":"CreateReadStream","d":393242,"h":64424902682,"f":1}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$1","d":393242,"h":4295360538,"f":1}],"i":[196634],"h":393242}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NotFoundFileInfo`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NullChangeToken", ($self) => class NullChangeToken extends $.$spc.System.Object
        {
            /*NullChangeToken*/ static Singleton = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get HasChanged()
            {
                return false;
            }
            /*bool */ get ActiveChangeCallbacks()
            {
                return false;
            }
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                return $.$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Singleton = new $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken().$ctor$1();
                }
            }
            static $h = 458778;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":458778,"g":{"r":0,"d":0,"h":12885360666,"f":33},"n":"Singleton","d":458778,"h":8590393370,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":25770262554,"f":1},"n":"HasChanged","d":458778,"h":21475295258,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360197146,"f":1},"n":"ActiveChangeCallbacks","d":458778,"h":30065229850,"f":1}],"m":[{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":458778,"h":38655164442,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":458778,"h":17180327962,"f":2}],"i":[720898],"h":458778}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NullChangeToken`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$spc.System.Object
        {
            /*EmptyDisposable*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefa.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            static $h = 65562;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":65562,"g":{"r":0,"d":0,"h":12884967450,"f":33},"n":"Instance","d":65562,"h":8590000154,"f":33}],"m":[{"r":65537,"n":"Dispose","d":65562,"h":21474902042,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":65562,"h":17179934746,"f":2}],"i":[57475073],"h":65562}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NullFileProvider", ($self) => class NullFileProvider extends $.$spc.System.Object
        {
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
            }
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
            }
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo()
            {
                return this.GetFileInfo(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents()
            {
                return this.GetDirectoryContents(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            Microsoft$Extensions$FileProviders$IFileProvider$Watch()
            {
                return this.Watch(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 524314;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131098,"p":[{"n":"subpath","p":1310721}],"n":"GetDirectoryContents","d":524314,"h":4295491610,"f":1},{"r":196634,"p":[{"n":"subpath","p":1310721}],"n":"GetFileInfo","d":524314,"h":8590458906,"f":1},{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"Watch","d":524314,"h":12885426202,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":524314,"h":17180393498,"f":1}],"i":[262170],"h":524314}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NullFileProvider`; }
        });
        
        $asm.$cls("$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents", ($self) => class NotFoundDirectoryContents extends $.$spc.System.Object
        {
            /*NotFoundDirectoryContents*/ static Singleton = null;
            /*bool */ get Exists()
            {
                return false;
            }
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                return $.$sl.System.Linq.Enumerable.Empty($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Singleton = new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents().$ctor$1();
                }
            }
            static $h = 327706;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":327706,"g":{"r":0,"d":0,"h":12885229594,"f":33},"n":"Singleton","d":327706,"h":8590262298,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":21475164186,"f":1},"n":"Exists","d":327706,"h":17180196890,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"GetEnumerator","d":327706,"h":25770131482,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":327706,"h":34360066074,"f":1}],"i":[131098,$.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31588353],"h":327706}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.NotFoundDirectoryContents`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq"))