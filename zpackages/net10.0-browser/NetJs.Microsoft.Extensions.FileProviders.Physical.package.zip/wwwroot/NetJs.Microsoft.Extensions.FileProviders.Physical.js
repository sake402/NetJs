
//--TRIMMABLE-BOUNDARY-START(100)
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mefa, $mef, $mwp, $sci, $scn, $scm, $so, $scp, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $sto, $sifw, $snp, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Physical", 
    {
  "h": 100,
  "f": "Microsoft.Extensions.FileProviders.Physical",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.FileProviders.Physical.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Physical",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Physical",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(458852)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.IClock", ($self) => class IClock
        {
            static $h = 458852;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885360740),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590393444,
        "f": 50331905
      },
      "n": "UtcNow",
      "o": "Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow",
      "d": 458852,
      "h": 12885360740,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885360740)
  ],
  "h": 458852
}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.IClock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458852)
        
        
        //--TRIMMABLE-BOUNDARY-START(196708)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken", ($self) => class IPollingChangeToken
        {
            static $h = 196708;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295164004),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098596,
        "f": 50331905
      },
      "n": "CancellationTokenSource",
      "o": "Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource",
      "d": 196708,
      "h": 4295164004,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295164004)
  ],
  "i": [720981
  ],
  "h": 196708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IPollingChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196708)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114212)
        $asm.$cls("$mefp.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(197569609828)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(197569609828)
            
            //--TRIMMABLE-BOUNDARY-START(180389740644)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389740644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389740644)
            
            //--TRIMMABLE-BOUNDARY-START(214749479012)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749479012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefp.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749479012)
            
            //--TRIMMABLE-BOUNDARY-START(176094773348)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094773348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(176094773348)
            
            //--TRIMMABLE-BOUNDARY-START(171799806052)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799806052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mefp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(171799806052)
            
            //--TRIMMABLE-BOUNDARY-START(68720590948)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720590948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(68720590948)
            
            //--TRIMMABLE-BOUNDARY-START(64425623652)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425623652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425623652)
            
            //--TRIMMABLE-BOUNDARY-START(60130656356)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130656356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(60130656356)
            
            //--TRIMMABLE-BOUNDARY-START(73015558244)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015558244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73015558244)
            
            //--TRIMMABLE-BOUNDARY-START(51540721764)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540721764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540721764)
            
            //--TRIMMABLE-BOUNDARY-START(47245754468)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245754468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754468)
            
            //--TRIMMABLE-BOUNDARY-START(42950787172)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950787172)
            
            //--TRIMMABLE-BOUNDARY-START(55835689060)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835689060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55835689060)
            
            //--TRIMMABLE-BOUNDARY-START(193274642532)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(193274642532)
            
            //--TRIMMABLE-BOUNDARY-START(184684707940)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(184684707940)
            
            //--TRIMMABLE-BOUNDARY-START(188979675236)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914904164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mefp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Physical", $.$mefp.System.SR.$type.Assembly);
                    $.$mefp.System.SR.s_resourceManager = temp;
                }
                return $.$mefp.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(188979675236)
            
            //--TRIMMABLE-BOUNDARY-START(30065885284)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145100388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159544420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mefp.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885284)
            
            //--TRIMMABLE-BOUNDARY-START(8591048804)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195427428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591048804)
            
            //--TRIMMABLE-BOUNDARY-START(12886016100)
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785362020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886016100)
            
            //--TRIMMABLE-BOUNDARY-START(34360852580)
            static /*string */ get Error_FileSystemWatcherRequiredWithoutPolling()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735034980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The fileSystemWatcher parameter must be non-null when pollForChanges is false.";
            }
            //--TRIMMABLE-BOUNDARY-END(34360852580)
            
            //--TRIMMABLE-BOUNDARY-START(17180983396)
            static /*string */ get CannotCreateStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375296612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create a stream for a directory.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180983396)
            
            //--TRIMMABLE-BOUNDARY-START(21475950692)
            static /*string */ get CannotModifyWhenFileWatcherInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965231204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot modify {0} once file watcher has been initialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475950692)
            
            //--TRIMMABLE-BOUNDARY-START(77310525540)
            static /*string */ FormatCannotModifyWhenFileWatcherInitialized(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot modify {0} once file watcher has been initialized.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310525540)
            
            //--TRIMMABLE-BOUNDARY-START(25770917988)
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555165796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The hash algorithm name cannot be null or empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770917988)
            
            //--TRIMMABLE-BOUNDARY-START(210454511716)
            static /*string */ get UnexpectedFileSystemInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504838756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unexpected type of FileSystemInfo";
            }
            //--TRIMMABLE-BOUNDARY-END(210454511716)
            
            //--TRIMMABLE-BOUNDARY-START(38655819876)
            static /*string */ get FileSystemWatcher_PlatformNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324969572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type '{0}' is not supported on this platform, use polling instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(38655819876)
            
            //--TRIMMABLE-BOUNDARY-START(81605492836)
            static /*string */ FormatFileSystemWatcher_PlatformNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605492836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The type '{0}' is not supported on this platform, use polling instead.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81605492836)
            
            //--TRIMMABLE-BOUNDARY-START(4296081508)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(197569609828)
                    this.s_usingResourceKeys = $.$mefp.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(197569609828)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081508)
            
            static $h = 1114212;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1114212
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114212)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048676)
        $asm.$cls("$mefp.Microsoft.Extensions.Internal.NonCapturingTimer", ($self) => class NonCapturingTimer
        {
            //--TRIMMABLE-BOUNDARY-START(4296015972)
            static /*Timer */ Create(/*TimerCallback*/ callback, /*object*/ state, /*TimeSpan*/ dueTime, /*TimeSpan*/ period)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                /*bool*/ let restoreFlow = false;
                try
                {
                    if (!$.$$.System.Threading.ExecutionContext.IsFlowSuppressed())
                    {
                        $.$$.System.Threading.ExecutionContext.SuppressFlow();
                        restoreFlow = true;
                    }
                    return new $.$$.System.Threading.Timer().$ctor$5(callback, state, dueTime, period);
                }
                finally
                {
                    {
                        if (restoreFlow)
                        {
                            $.$$.System.Threading.ExecutionContext.RestoreFlow();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015972)
            
            static $h = 1048676;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015972),
    {
      "r": 182976513,
      "p": [
        {
          "n": "callback",
          "p": 183042049
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "dueTime",
          "p": 185860097
        },
        {
          "n": "period",
          "p": 185860097
        }
      ],
      "n": "Create",
      "d": 1048676,
      "h": 4296015972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296015972)
  ],
  "h": 1048676
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.NonCapturingTimer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048676)
        
        
        //--TRIMMABLE-BOUNDARY-START(393316)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper", ($self) => class FileSystemInfoHelper
        {
            //--TRIMMABLE-BOUNDARY-START(12885295204)
            static /*bool */ IsExcluded(/*FileSystemInfo*/ fileSystemInfo, /*ExclusionFilters*/ filters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (filters === 0/*ExclusionFilters.None*/)
                {
                    return false;
                }
                else if ($.$$.System.String.StartsWith$2.call(fileSystemInfo.Name, ".", 4/*StringComparison.Ordinal*/) && (filters & 1/*ExclusionFilters.DotPrefixed*/) !== 0)
                {
                    return true;
                }
                else if (fileSystemInfo.Exists && (((fileSystemInfo.Attributes & 2/*FileAttributes.Hidden*/) !== 0 && (filters & 2/*ExclusionFilters.Hidden*/) !== 0) || ((fileSystemInfo.Attributes & 4/*FileAttributes.System*/) !== 0 && (filters & 4/*ExclusionFilters.System*/) !== 0)))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295204)
            
            //--TRIMMABLE-BOUNDARY-START(8590327908)
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc$1(/*string*/ filePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let fileInfo = new $.$$.System.IO.FileInfo().$ctor$6(filePath);
                if (fileInfo.Exists)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(fileInfo);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327908)
            
            //--TRIMMABLE-BOUNDARY-START(4295360612)
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc(/*FileInfo*/ fileInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(fileInfo.Exists, "fileInfo.Exists");
                if ($.$$.System.String.op_Inequality(fileInfo.LinkTarget, null))
                {
                    try
                    {
                        /*FileSystemInfo?*/ let targetInfo = fileInfo.ResolveLinkTarget(true);
                        if (targetInfo !== null && targetInfo.Exists)
                        {
                            return targetInfo.LastWriteTimeUtc;
                        }
                    }
                    catch(ex)
                    {
                    }
                    return $.$$.System.DateTime.MinValue;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360612)
            
            static $h = 393316;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295204),
    {
      "r": 262145,
      "p": [
        {
          "n": "fileSystemInfo",
          "p": 93323265
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": "IsExcluded",
      "d": 393316,
      "h": 12885295204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295204),
//--TRIMMABLE-BOUNDARY-START(8590327908),
    {
      "r": $.$typeNullable($.$$.System.DateTime).$h,
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": "GetFileLinkTargetLastWriteTimeUtc",
      "o": "@$1",
      "d": 393316,
      "h": 8590327908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327908),
//--TRIMMABLE-BOUNDARY-START(4295360612),
    {
      "r": $.$typeNullable($.$$.System.DateTime).$h,
      "p": [
        {
          "n": "fileInfo",
          "p": 92667905
        }
      ],
      "n": "GetFileLinkTargetLastWriteTimeUtc",
      "d": 393316,
      "h": 4295360612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360612)
  ],
  "h": 393316
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393316)
        
        
        //--TRIMMABLE-BOUNDARY-START(524388)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils", ($self) => class PathUtils
        {
            //--TRIMMABLE-BOUNDARY-START(25770328164)
            static /*char[] */ GetInvalidFileNameChars()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Char, $.$sl.System.Linq.Enumerable.Where($.$$.System.Char, $.$$.System.IO.Path.GetInvalidFileNameChars(), new ($.$$.System.Func$$$($.$$.System.Char, $.$$.System.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c !== $.$$.System.IO.Path.DirectorySeparatorChar && c !== $.$$.System.IO.Path.AltDirectorySeparatorChar;
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "c",
      "p": 458753
    }
  ],
  "n": "",
  "d": 524388,
  "h": 0,
  "f": 17825794
})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328164)
            
            //--TRIMMABLE-BOUNDARY-START(30065295460)
            static /*char[] */ GetInvalidFilterChars()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295460);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Char, $.$sl.System.Linq.Enumerable.Where($.$$.System.Char, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars(), new ($.$$.System.Func$$$($.$$.System.Char, $.$$.System.Boolean))().$ctor(this,  (/**/ c) =>
                    {
                        return c !== /***/ 42 && c !== /*|*/ 124 && c !== /*?*/ 63;
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "c",
      "p": 458753
    }
  ],
  "n": "",
  "d": 524388,
  "h": 0,
  "f": 17825794
})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295460)
            
            //--TRIMMABLE-BOUNDARY-START(4295491684)
            /*SearchValues<char>*/ static _invalidFileNameChars = null;
            //--TRIMMABLE-BOUNDARY-END(4295491684)
            
            //--TRIMMABLE-BOUNDARY-START(8590458980)
            /*SearchValues<char>*/ static _invalidFilterChars = null;
            //--TRIMMABLE-BOUNDARY-END(8590458980)
            
            //--TRIMMABLE-BOUNDARY-START(38655230052)
            static /*bool */ HasInvalidPathChars(/*string*/ path)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655230052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFileNameChars);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655230052)
            
            //--TRIMMABLE-BOUNDARY-START(34360262756)
            static /*bool */ HasInvalidFilterChars(/*string*/ path)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFilterChars);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262756)
            
            //--TRIMMABLE-BOUNDARY-START(12885426276)
            /*char[]*/ static _pathSeparators = null;
            //--TRIMMABLE-BOUNDARY-END(12885426276)
            
            //--TRIMMABLE-BOUNDARY-START(21475360868)
            static /*string */ EnsureTrailingSlash(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.String.IsNullOrEmpty(path) && $.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) !== $.$$.System.IO.Path.DirectorySeparatorChar)
                {
                    return path + $.$$.System.IO.Path.DirectorySeparatorChar;
                }
                return path;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360868)
            
            //--TRIMMABLE-BOUNDARY-START(42950197348)
            static /*bool */ PathNavigatesAboveRoot(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tokenizer = new $.$mep.Microsoft.Extensions.Primitives.StringTokenizer().$ctor$3(path, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._pathSeparators);
                /*int*/ let depth = 0;
                var $en2 = tokenizer.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var segment = $en2.Current;
                    {
                        if (segment.Equals$3(".") || segment.Equals$3(""))
                        {
                            continue;
                        }
                        else if (segment.Equals$3(".."))
                        {
                            depth--;
                            if (depth === -1)
                            {
                                return true;
                            }
                        }
                        else 
                        {
                            depth++;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197348)
            
            //--TRIMMABLE-BOUNDARY-START(17180393572)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295491684)
                    this._invalidFileNameChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars()));
                    //--TRIMMABLE-BOUNDARY-END(4295491684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590458980)
                    this._invalidFilterChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFilterChars()));
                    //--TRIMMABLE-BOUNDARY-END(8590458980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426276)
                    this._pathSeparators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [$.$$.System.IO.Path.DirectorySeparatorChar, $.$$.System.IO.Path.AltDirectorySeparatorChar], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12885426276)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393572)
            
            static $h = 524388;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770328164),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "n": "GetInvalidFileNameChars",
      "d": 524388,
      "h": 25770328164,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770328164),
//--TRIMMABLE-BOUNDARY-START(30065295460),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "n": "GetInvalidFilterChars",
      "d": 524388,
      "h": 30065295460,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065295460),
//--TRIMMABLE-BOUNDARY-START(38655230052),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "HasInvalidPathChars",
      "d": 524388,
      "h": 38655230052,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655230052),
//--TRIMMABLE-BOUNDARY-START(34360262756),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "HasInvalidFilterChars",
      "d": 524388,
      "h": 34360262756,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360262756),
//--TRIMMABLE-BOUNDARY-START(21475360868),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "EnsureTrailingSlash",
      "d": 524388,
      "h": 21475360868,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475360868),
//--TRIMMABLE-BOUNDARY-START(42950197348),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "PathNavigatesAboveRoot",
      "d": 524388,
      "h": 42950197348,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950197348)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491684),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "_invalidFileNameChars",
      "d": 524388,
      "h": 4295491684,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295491684),
//--TRIMMABLE-BOUNDARY-START(8590458980),
    {
      "t": $.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,
      "n": "_invalidFilterChars",
      "d": 524388,
      "h": 8590458980,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590458980),
//--TRIMMABLE-BOUNDARY-START(12885426276),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_pathSeparators",
      "d": 524388,
      "h": 12885426276,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885426276)
  ],
  "h": 524388
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524388)
        
        
        //--TRIMMABLE-BOUNDARY-START(262244)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Clock", ($self) => class Clock extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098724)
            /*Clock*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(21475098724)
            
            //--TRIMMABLE-BOUNDARY-START(8590196836)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196836)
            
            //--TRIMMABLE-BOUNDARY-START(25770066020)
            /*DateTime */ get UtcNow()
            {
                return $.$$.System.DateTime.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066020)
            
            //--TRIMMABLE-BOUNDARY-START(8590393444)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.Physical.IClock.UtcNow.get
            get Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393444)
            
            //--TRIMMABLE-BOUNDARY-START(4295229540)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098724)
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21475098724)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229540)
            
            static $h = 262244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770066020),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180131428,
        "f": 50331649
      },
      "n": "UtcNow",
      "d": 262244,
      "h": 25770066020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770066020)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475098724),
    {
      "t": 262244,
      "n": "Instance",
      "d": 262244,
      "h": 21475098724,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262244,
      "h": 8590196836,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590196836)
  ],
  "i": [458852
  ],
  "h": 262244
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.Physical.IClock ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Clock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262244)
        
        
        //--TRIMMABLE-BOUNDARY-START(65636)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064836708)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30064836708)
            
            //--TRIMMABLE-BOUNDARY-START(12884967524)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967524)
            
            //--TRIMMABLE-BOUNDARY-START(17179934820)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17179934820)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(8590000228)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000228)
            
            static $h = 65636;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836708),
    {
      "p": 65636,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869412,
        "f": 50331681
      },
      "n": "Instance",
      "d": 65636,
      "h": 30064836708,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836708)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934820),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 65636,
      "h": 17179934820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65636,
      "h": 12884967524,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967524)
  ],
  "i": [90308609
  ],
  "h": 65636
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65636)
        
        
        //--TRIMMABLE-BOUNDARY-START(655460)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo", ($self) => class PhysicalFileInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622756)
            /*FileInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(4295622756)
            
            //--TRIMMABLE-BOUNDARY-START(8590590052)
            $ctor$1(/*FileInfo*/ info)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590052)
            
            //--TRIMMABLE-BOUNDARY-START(17180524644)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524644)
            
            //--TRIMMABLE-BOUNDARY-START(81605034084)
            /*long */ get Length()
            {
                return this._info.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(81605034084)
            
            //--TRIMMABLE-BOUNDARY-START(90194968676)
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(90194968676)
            
            //--TRIMMABLE-BOUNDARY-START(85900001380)
            /*string */ get Name()
            {
                return this._info.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(85900001380)
            
            //--TRIMMABLE-BOUNDARY-START(77310066788)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            //--TRIMMABLE-BOUNDARY-END(77310066788)
            
            //--TRIMMABLE-BOUNDARY-START(73015099492)
            /*bool */ get IsDirectory()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73015099492)
            
            //--TRIMMABLE-BOUNDARY-START(12885557348)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bufferSize = 1;
                return new $.$$.System.IO.FileStream().$ctor$12(this.PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, bufferSize, 1073741824/*FileOptions.Asynchronous*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(12885557348)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            static $h = 655460;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524644),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459236,
        "f": 50331649
      },
      "n": "Exists",
      "d": 655460,
      "h": 17180524644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524644),
//--TRIMMABLE-BOUNDARY-START(81605034084),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263012,
        "f": 50331649
      },
      "n": "Length",
      "d": 655460,
      "h": 81605034084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605034084),
//--TRIMMABLE-BOUNDARY-START(90194968676),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132196,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 655460,
      "h": 90194968676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194968676),
//--TRIMMABLE-BOUNDARY-START(85900001380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197604,
        "f": 50331649
      },
      "n": "Name",
      "d": 655460,
      "h": 85900001380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900001380),
//--TRIMMABLE-BOUNDARY-START(77310066788),
    {
      "p": 65470465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328420,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 655460,
      "h": 77310066788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310066788),
//--TRIMMABLE-BOUNDARY-START(73015099492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393828,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 655460,
      "h": 73015099492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015099492)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885557348),
    {
      "r": 94961665,
      "n": "CreateReadStream",
      "d": 655460,
      "h": 12885557348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557348)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622756),
    {
      "t": 92667905,
      "n": "_info",
      "d": 655460,
      "h": 4295622756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590052),
    {
      "p": [
        {
          "n": "info",
          "p": 92667905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655460,
      "h": 8590590052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590052)
  ],
  "i": [196707
  ],
  "h": 655460
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655460)
        
        
        //--TRIMMABLE-BOUNDARY-START(720996)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher", ($self) => class PhysicalFilesWatcher extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688292)
            /*Action<object?>*/ static _cancelTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(4295688292)
            
            //--TRIMMABLE-BOUNDARY-START(94490001508)
            /*TimeSpan*/ static DefaultPollingInterval;
            //--TRIMMABLE-BOUNDARY-END(94490001508)
            
            //--TRIMMABLE-BOUNDARY-START(12885622884)
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _filePathTokenLookup = null;
            //--TRIMMABLE-BOUNDARY-END(12885622884)
            
            //--TRIMMABLE-BOUNDARY-START(51540328548)
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _wildcardTokenLookup = null;
            //--TRIMMABLE-BOUNDARY-END(51540328548)
            
            //--TRIMMABLE-BOUNDARY-START(17180590180)
            /*FileSystemWatcher?*/ _fileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(17180590180)
            
            //--TRIMMABLE-BOUNDARY-START(21475557476)
            /*object*/ _fileWatcherLock = null;
            //--TRIMMABLE-BOUNDARY-END(21475557476)
            
            //--TRIMMABLE-BOUNDARY-START(30065492068)
            /*string*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(30065492068)
            
            //--TRIMMABLE-BOUNDARY-START(25770524772)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(25770524772)
            
            //--TRIMMABLE-BOUNDARY-START(34360459364)
            /*Timer?*/ _timer = null;
            //--TRIMMABLE-BOUNDARY-END(34360459364)
            
            //--TRIMMABLE-BOUNDARY-START(42950393956)
            /*bool*/ _timerInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(42950393956)
            
            //--TRIMMABLE-BOUNDARY-START(47245361252)
            /*object*/ _timerLock = null;
            //--TRIMMABLE-BOUNDARY-END(47245361252)
            
            //--TRIMMABLE-BOUNDARY-START(38655426660)
            /*Func<Timer>*/ _timerFactory = null;
            //--TRIMMABLE-BOUNDARY-END(38655426660)
            
            //--TRIMMABLE-BOUNDARY-START(8590655588)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590655588)
            
            //--TRIMMABLE-BOUNDARY-START(81605099620)
            $ctor$2(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges)
            {
                this.$ctor$1(root, fileSystemWatcher, pollForChanges, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605099620);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099620)
            
            //--TRIMMABLE-BOUNDARY-START(77310132324)
            $ctor$1(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310132324);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (fileSystemWatcher === null && !pollForChanges)
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$18("fileSystemWatcher", $.$mefp.System.SR.Error_FileSystemWatcherRequiredWithoutPolling);
                    }
                    this._root = root;
                    if (fileSystemWatcher !== null)
                    {
                        if ($.$$.System.OperatingSystem.IsBrowser() || $.$$.System.OperatingSystem.IsWasi() || ($.$$.System.OperatingSystem.IsIOS() && !$.$$.System.OperatingSystem.IsMacCatalyst()) || $.$$.System.OperatingSystem.IsTvOS())
                        {
                            throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$mefp.System.SR.Format$6($.$mefp.System.SR.FileSystemWatcher_PlatformNotSupported, $.$sifw.System.IO.FileSystemWatcher.$type));
                        }
                        this._fileWatcher = fileSystemWatcher;
                        this._fileWatcher.IncludeSubdirectories = true;
                        this._fileWatcher.add_Created(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Changed(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Renamed(new $.$sifw.System.IO.RenamedEventHandler().$ctor(this, this.OnRenamed));
                        this._fileWatcher.add_Deleted(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Error(new $.$sifw.System.IO.ErrorEventHandler().$ctor(this, this.OnError));
                    }
                    this.PollForChanges = pollForChanges;
                    this._filters = filters;
                    this.PollingChangeTokens = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken))().$ctor$1();
                    this._timerFactory = new ($.$$.System.Func$$($.$$.System.Threading.Timer))().$ctor(this,  () =>
                    {
                        return $.$mefp.Microsoft.Extensions.Internal.NonCapturingTimer.Create(new $.$$.System.Threading.TimerCallback().$ctor($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.RaiseChangeEvents), this.PollingChangeTokens, $.$$.System.TimeSpan.Zero, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval);
                    }, {
  "r": 182976513,
  "n": "",
  "d": 720996,
  "h": 0,
  "f": 17825794
});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132324)
            
            //--TRIMMABLE-BOUNDARY-START(171799412836)
            /*bool*/ PollForChanges = false;
            //--TRIMMABLE-BOUNDARY-END(171799412836)
            
            //--TRIMMABLE-BOUNDARY-START(206159151204)
            /*bool*/ UseActivePolling = false;
            //--TRIMMABLE-BOUNDARY-END(206159151204)
            
            //--TRIMMABLE-BOUNDARY-START(176094380132)
            /*ConcurrentDictionary<IPollingChangeToken, IPollingChangeToken>*/ PollingChangeTokens = null;
            //--TRIMMABLE-BOUNDARY-END(176094380132)
            
            //--TRIMMABLE-BOUNDARY-START(90195034212)
            /*IChangeToken */ CreateFileChangeToken(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(filter, "filter");
                filter = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(filter);
                if ($.$$.System.IO.Path.IsPathRooted$1(filter) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                /*IChangeToken*/ let changeToken = this.GetOrAddChangeToken(filter);
                this.TryEnableFileSystemWatcher();
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034212)
            
            //--TRIMMABLE-BOUNDARY-START(133144707172)
            /*IChangeToken */ GetOrAddChangeToken(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UseActivePolling)
                {
                    $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$$.System.Threading.Timer, $.$ref(() => this._timer, ($v) => this._timer = $v, $.$$.System.Threading.Timer), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._timerInitialized, ($v) => this._timerInitialized = $v, null), $.$ref(() => this._timerLock, ($v) => this._timerLock = $v, $.$$.System.Object), this._timerFactory);
                }
                /*IChangeToken*/ let changeToken;
                /*bool*/ let isWildCard = $.$$.System.String.Contains$1.call(pattern, /***/ 42);
                if (isWildCard || $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.IsDirectoryPath(pattern))
                {
                    changeToken = this.GetOrAddWildcardChangeToken(pattern);
                }
                else 
                {
                    changeToken = this.GetOrAddFilePathChangeToken(pattern);
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(133144707172)
            
            //--TRIMMABLE-BOUNDARY-START(137439674468)
            /*IChangeToken */ GetOrAddFilePathChangeToken(/*string*/ filePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._filePathTokenLookup.TryGetValue(filePath, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$4(cancellationTokenSource, cancellationChangeToken);
                    tokenInfo = this._filePathTokenLookup.GetOrAdd$1(filePath, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken().$ctor$1(new $.$$.System.IO.FileInfo().$ctor$6($.$$.System.IO.Path.Combine$3(this._root, filePath)));
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(137439674468)
            
            //--TRIMMABLE-BOUNDARY-START(141734641764)
            /*IChangeToken */ GetOrAddWildcardChangeToken(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._wildcardTokenLookup.TryGetValue(pattern, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    /*var*/ let matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    matcher.AddInclude(pattern);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$3(cancellationTokenSource, cancellationChangeToken, matcher);
                    tokenInfo = this._wildcardTokenLookup.GetOrAdd$1(pattern, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken().$ctor$1(this._root, pattern);
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(141734641764)
            
            //--TRIMMABLE-BOUNDARY-START(98784968804)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(98784968804)
            
            //--TRIMMABLE-BOUNDARY-START(103079936100)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                        this._timer?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936100)
            
            //--TRIMMABLE-BOUNDARY-START(167504445540)
            /*void */ OnRenamed(/*object*/ sender, /*RenamedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504445540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFileSystemEntryChange(e.OldFullPath);
                this.OnFileSystemEntryChange(e.FullPath);
                if ($.$$.System.IO.Directory.Exists(e.FullPath))
                {
                    try
                    {
                        var $en4 = $.$$.System.IO.Directory.EnumerateFileSystemEntries$1(e.FullPath, "*", 1/*SearchOption.AllDirectories*/).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var newLocation = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*string*/ let oldLocation = $.$$.System.IO.Path.Combine$3(e.OldFullPath, $.$$.System.String.Substring$1.call(newLocation, ((e.FullPath.length + 1) | 0)));
                                this.OnFileSystemEntryChange(oldLocation);
                                this.OnFileSystemEntryChange(newLocation);
                            }
                        }
                    }
                    catch(ex)
                    {
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504445540)
            
            //--TRIMMABLE-BOUNDARY-START(154619543652)
            /*void */ OnChanged(/*object*/ sender, /*FileSystemEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619543652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFileSystemEntryChange(e.FullPath);
            }
            //--TRIMMABLE-BOUNDARY-END(154619543652)
            
            //--TRIMMABLE-BOUNDARY-START(158914510948)
            /*void */ OnError(/*object*/ sender, /*ErrorEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._filePathTokenLookup.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var path = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.ReportChangeForMatchedEntries(path);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914510948)
            
            //--TRIMMABLE-BOUNDARY-START(163209478244)
            /*void */ OnFileSystemEntryChange(/*string*/ fullPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209478244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let fileSystemInfo = new $.$$.System.IO.FileInfo().$ctor$6(fullPath);
                    if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileSystemInfo, this._filters))
                    {
                        return;
                    }
                    /*string*/ let relativePath = $.$$.System.String.Substring$1.call(fullPath, this._root.length);
                    this.ReportChangeForMatchedEntries(relativePath);
                }
                catch(ex)
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209478244)
            
            //--TRIMMABLE-BOUNDARY-START(184684314724)
            /*void */ ReportChangeForMatchedEntries(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684314724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(path))
                {
                    return;
                }
                path = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(path);
                /*bool*/ let matched = false;
                /*ChangeTokenInfo*/ let matchInfo;
                if (this._filePathTokenLookup.TryRemove$1(path, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                    matched = true;
                }
                var $en2 = this._wildcardTokenLookup.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var wildCardEntry = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*PatternMatchingResult*/ let matchResult = $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$3(wildCardEntry.Value.Matcher, path);
                        if (matchResult.HasMatches && this._wildcardTokenLookup.TryRemove$1(wildCardEntry.Key, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                        {
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                            matched = true;
                        }
                    }
                }
                if (matched)
                {
                    this.TryDisableFileSystemWatcher();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684314724)
            
            //--TRIMMABLE-BOUNDARY-START(197569216612)
            /*void */ TryDisableFileSystemWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if (this._filePathTokenLookup.IsEmpty && this._wildcardTokenLookup.IsEmpty && this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569216612)
            
            //--TRIMMABLE-BOUNDARY-START(201864183908)
            /*void */ TryEnableFileSystemWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if ((!this._filePathTokenLookup.IsEmpty || !this._wildcardTokenLookup.IsEmpty) && !this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864183908)
            
            //--TRIMMABLE-BOUNDARY-START(150324576356)
            static /*string */ NormalizePath(/*string*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324576356);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Replace.call(filter, /*\\*/ 92, /*/*/ 47);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324576356)
            
            //--TRIMMABLE-BOUNDARY-START(146029609060)
            static /*bool */ IsDirectoryPath(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029609060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return path.length > 0 && ($.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.System.IO.Path.DirectorySeparatorChar || $.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.System.IO.Path.AltDirectorySeparatorChar);
            }
            //--TRIMMABLE-BOUNDARY-END(146029609060)
            
            //--TRIMMABLE-BOUNDARY-START(85900066916)
            static /*void */ CancelToken(/*ChangeTokenInfo*/ matchInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (matchInfo.TokenSource.IsCancellationRequested)
                {
                    return;
                }
                $.$$.System.Threading.Tasks.Task.Factory.StartNew$4($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher._cancelTokenSource, matchInfo.TokenSource, $.$$.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.System.Threading.Tasks.TaskScheduler.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(85900066916)
            
            //--TRIMMABLE-BOUNDARY-START(180389347428)
            static /*void */ RaiseChangeEvents(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(state !== null, "state != null");
                /*var*/ let changeTokens = $.$cast(state, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken));
                var $en2 = changeTokens.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*IPollingChangeToken*/ let token = item.Key;
                        if (!token.Microsoft$Extensions$Primitives$IChangeToken$HasChanged)
                        {
                            continue;
                        }
                        if (!changeTokens.TryRemove$1(token, $.$discardRef()))
                        {
                            continue;
                        }
                        try
                        {
                            token.Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389347428)
            
            //--TRIMMABLE-BOUNDARY-START(786532)
            static $_ChangeTokenInfo;
            static get ChangeTokenInfo()
            {
                let $cls = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                return $cls.$_ChangeTokenInfo ??= $asm.$nstr("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo", ($self) => class ChangeTokenInfo extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770590308)
                    $ctor$4(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken)
                    {
                        this.$ctor$3(tokenSource, changeToken, null);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770590308);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590308)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623012)
                    $ctor$3(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken, /*Matcher?*/ matcher)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475623012);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.TokenSource = tokenSource;
                            this.ChangeToken = changeToken;
                            this.Matcher = matcher;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475623012)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425295972)
                    /*CancellationTokenSource*/ TokenSource = null;
                    //--TRIMMABLE-BOUNDARY-END(64425295972)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065557604)
                    /*CancellationChangeToken*/ ChangeToken = null;
                    //--TRIMMABLE-BOUNDARY-END(30065557604)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130328676)
                    /*Matcher?*/ Matcher = null;
                    //--TRIMMABLE-BOUNDARY-END(60130328676)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655716)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655716)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TokenSource = this.TokenSource;
                        copy.ChangeToken = this.ChangeToken;
                        copy.Matcher = this.Matcher;
                        return copy;
                    }
                    static $h = 786532;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425295972),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361380,
        "f": 50331649
      },
      "n": "TokenSource",
      "d": 786532,
      "h": 64425295972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425295972),
//--TRIMMABLE-BOUNDARY-START(30065557604),
    {
      "p": 196693,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492196,
        "f": 50331649
      },
      "n": "ChangeToken",
      "d": 786532,
      "h": 30065557604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065557604),
//--TRIMMABLE-BOUNDARY-START(60130328676),
    {
      "p": 2424933,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426788,
        "f": 50331649
      },
      "n": "Matcher",
      "d": 786532,
      "h": 60130328676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590308),
    {
      "p": [
        {
          "n": "tokenSource",
          "p": 170196993
        },
        {
          "n": "changeToken",
          "p": 196693
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786532,
      "h": 25770590308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590308),
//--TRIMMABLE-BOUNDARY-START(21475623012),
    {
      "p": [
        {
          "n": "tokenSource",
          "p": 170196993
        },
        {
          "n": "changeToken",
          "p": 196693
        },
        {
          "n": "matcher",
          "p": 2424933
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786532,
      "h": 21475623012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623012),
//--TRIMMABLE-BOUNDARY-START(17180655716),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786532,
      "h": 17180655716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655716)
  ],
  "d": 720996,
  "h": 786532
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo`; }
                }, $cls, ($v) => $cls.$_ChangeTokenInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786532)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885622884)
                this._filePathTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(12885622884)
                
                //--TRIMMABLE-BOUNDARY-START(51540328548)
                this._wildcardTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(51540328548)
                
                //--TRIMMABLE-BOUNDARY-START(21475557476)
                this._fileWatcherLock = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(21475557476)
                
                //--TRIMMABLE-BOUNDARY-START(47245361252)
                this._timerLock = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(47245361252)
                
            }
            //--TRIMMABLE-BOUNDARY-START(73015165028)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688292)
                    this._cancelTokenSource = new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$$.System.Threading.CancellationTokenSource)).Cancel();
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "state",
      "p": 131073
    }
  ],
  "n": "",
  "d": 720996,
  "h": 0,
  "f": 17825794
});
                    //--TRIMMABLE-BOUNDARY-END(4295688292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001508)
                    this.DefaultPollingInterval = $.$$.System.TimeSpan.FromSeconds$2(4n);
                    //--TRIMMABLE-BOUNDARY-END(94490001508)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015165028)
            
            static $h = 720996;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799412836),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669870692,
        "f": 50331656
      },
      "n": "PollForChanges",
      "d": 720996,
      "h": 171799412836,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171799412836),
//--TRIMMABLE-BOUNDARY-START(206159151204),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849739876,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274249316,
        "f": 83886088
      },
      "n": "UseActivePolling",
      "d": 720996,
      "h": 206159151204,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(206159151204),
//--TRIMMABLE-BOUNDARY-START(176094380132),
    {
      "p": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259805284,
        "f": 50331656
      },
      "n": "PollingChangeTokens",
      "d": 720996,
      "h": 176094380132,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(176094380132)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195034212),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "CreateFileChangeToken",
      "d": 720996,
      "h": 90195034212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195034212),
//--TRIMMABLE-BOUNDARY-START(133144707172),
    {
      "r": 720981,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "GetOrAddChangeToken",
      "d": 720996,
      "h": 133144707172,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707172),
//--TRIMMABLE-BOUNDARY-START(137439674468),
    {
      "r": 720981,
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": "GetOrAddFilePathChangeToken",
      "d": 720996,
      "h": 137439674468,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(137439674468),
//--TRIMMABLE-BOUNDARY-START(141734641764),
    {
      "r": 720981,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "GetOrAddWildcardChangeToken",
      "d": 720996,
      "h": 141734641764,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(141734641764),
//--TRIMMABLE-BOUNDARY-START(98784968804),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720996,
      "h": 98784968804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784968804),
//--TRIMMABLE-BOUNDARY-START(103079936100),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 720996,
      "h": 103079936100,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(103079936100),
//--TRIMMABLE-BOUNDARY-START(167504445540),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 524370
        }
      ],
      "n": "OnRenamed",
      "d": 720996,
      "h": 167504445540,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(167504445540),
//--TRIMMABLE-BOUNDARY-START(154619543652),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "OnChanged",
      "d": 720996,
      "h": 154619543652,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619543652),
//--TRIMMABLE-BOUNDARY-START(158914510948),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 65618
        }
      ],
      "n": "OnError",
      "d": 720996,
      "h": 158914510948,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914510948),
//--TRIMMABLE-BOUNDARY-START(163209478244),
    {
      "r": 65537,
      "p": [
        {
          "n": "fullPath",
          "p": 1310721
        }
      ],
      "n": "OnFileSystemEntryChange",
      "d": 720996,
      "h": 163209478244,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209478244),
//--TRIMMABLE-BOUNDARY-START(184684314724),
    {
      "r": 65537,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "ReportChangeForMatchedEntries",
      "d": 720996,
      "h": 184684314724,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684314724),
//--TRIMMABLE-BOUNDARY-START(197569216612),
    {
      "r": 65537,
      "n": "TryDisableFileSystemWatcher",
      "d": 720996,
      "h": 197569216612,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569216612),
//--TRIMMABLE-BOUNDARY-START(201864183908),
    {
      "r": 65537,
      "n": "TryEnableFileSystemWatcher",
      "d": 720996,
      "h": 201864183908,
      "f": 16777218,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864183908),
//--TRIMMABLE-BOUNDARY-START(150324576356),
    {
      "r": 1310721,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "NormalizePath",
      "d": 720996,
      "h": 150324576356,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(150324576356),
//--TRIMMABLE-BOUNDARY-START(146029609060),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "IsDirectoryPath",
      "d": 720996,
      "h": 146029609060,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146029609060),
//--TRIMMABLE-BOUNDARY-START(85900066916),
    {
      "r": 65537,
      "p": [
        {
          "n": "matchInfo",
          "p": 786532
        }
      ],
      "n": "CancelToken",
      "d": 720996,
      "h": 85900066916,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(85900066916),
//--TRIMMABLE-BOUNDARY-START(180389347428),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RaiseChangeEvents",
      "d": 720996,
      "h": 180389347428,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(180389347428)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688292),
    {
      "t": $.$$.System.Action$$($.$$.System.Object).$h,
      "n": "_cancelTokenSource",
      "d": 720996,
      "h": 4295688292,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295688292),
//--TRIMMABLE-BOUNDARY-START(94490001508),
    {
      "t": 185860097,
      "n": "DefaultPollingInterval",
      "d": 720996,
      "h": 94490001508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490001508),
//--TRIMMABLE-BOUNDARY-START(12885622884),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,
      "n": "_filePathTokenLookup",
      "d": 720996,
      "h": 12885622884,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622884),
//--TRIMMABLE-BOUNDARY-START(51540328548),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,
      "n": "_wildcardTokenLookup",
      "d": 720996,
      "h": 51540328548,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540328548),
//--TRIMMABLE-BOUNDARY-START(17180590180),
    {
      "t": 327762,
      "n": "_fileWatcher",
      "d": 720996,
      "h": 17180590180,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590180),
//--TRIMMABLE-BOUNDARY-START(21475557476),
    {
      "t": 131073,
      "n": "_fileWatcherLock",
      "d": 720996,
      "h": 21475557476,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557476),
//--TRIMMABLE-BOUNDARY-START(30065492068),
    {
      "t": 1310721,
      "n": "_root",
      "d": 720996,
      "h": 30065492068,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065492068),
//--TRIMMABLE-BOUNDARY-START(25770524772),
    {
      "t": 327780,
      "n": "_filters",
      "d": 720996,
      "h": 25770524772,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524772),
//--TRIMMABLE-BOUNDARY-START(34360459364),
    {
      "t": 182976513,
      "n": "_timer",
      "d": 720996,
      "h": 34360459364,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360459364),
//--TRIMMABLE-BOUNDARY-START(42950393956),
    {
      "t": 262145,
      "n": "_timerInitialized",
      "d": 720996,
      "h": 42950393956,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950393956),
//--TRIMMABLE-BOUNDARY-START(47245361252),
    {
      "t": 131073,
      "n": "_timerLock",
      "d": 720996,
      "h": 47245361252,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245361252),
//--TRIMMABLE-BOUNDARY-START(38655426660),
    {
      "t": $.$$.System.Func$$($.$$.System.Threading.Timer).$h,
      "n": "_timerFactory",
      "d": 720996,
      "h": 38655426660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655426660),
//--TRIMMABLE-BOUNDARY-START(8590655588),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 720996,
      "h": 8590655588,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655588)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(81605099620),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "fileSystemWatcher",
          "p": 327762
        },
        {
          "n": "pollForChanges",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720996,
      "h": 81605099620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605099620),
//--TRIMMABLE-BOUNDARY-START(77310132324),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "fileSystemWatcher",
          "p": 327762
        },
        {
          "n": "pollForChanges",
          "p": 262145
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720996,
      "h": 77310132324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310132324)
  ],
  "i": [90308609
  ],
  "j": [786532
  ],
  "h": 720996
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720996)
        
        
        //--TRIMMABLE-BOUNDARY-START(852068)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken", ($self) => class PollingFileChangeToken extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590786660)
            /*FileInfo*/ _fileInfo = null;
            //--TRIMMABLE-BOUNDARY-END(8590786660)
            
            //--TRIMMABLE-BOUNDARY-START(21475688548)
            /*DateTime*/ _previousWriteTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(21475688548)
            
            //--TRIMMABLE-BOUNDARY-START(17180721252)
            /*DateTime*/ _lastCheckedTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(17180721252)
            
            //--TRIMMABLE-BOUNDARY-START(12885753956)
            /*bool*/ _hasChanged = false;
            //--TRIMMABLE-BOUNDARY-END(12885753956)
            
            //--TRIMMABLE-BOUNDARY-START(25770655844)
            /*CancellationTokenSource?*/ _tokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(25770655844)
            
            //--TRIMMABLE-BOUNDARY-START(4295819364)
            /*CancellationChangeToken?*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295819364)
            
            //--TRIMMABLE-BOUNDARY-START(42950525028)
            $ctor$1(/*FileInfo*/ fileInfo)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950525028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fileInfo = fileInfo;
                    this._previousWriteTimeUtc = this.GetLastWriteTimeUtc();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525028)
            
            //--TRIMMABLE-BOUNDARY-START(111670001764)
            /*TimeSpan*/ static PollingInterval;
            //--TRIMMABLE-BOUNDARY-END(111670001764)
            
            //--TRIMMABLE-BOUNDARY-START(90195165284)
            /*DateTime */ GetLastWriteTimeUtc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._fileInfo.Refresh();
                if (!this._fileInfo.Exists)
                {
                    return $.$$.System.DateTime.MinValue;
                }
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(this._fileInfo) ?? this._fileInfo.LastWriteTimeUtc;
            }
            //--TRIMMABLE-BOUNDARY-END(90195165284)
            
            //--TRIMMABLE-BOUNDARY-START(47245492324)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(47245492324)
            
            //--TRIMMABLE-BOUNDARY-START(51540459620)
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(51540459620)
            
            //--TRIMMABLE-BOUNDARY-START(98785099876)
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099876)
            
            //--TRIMMABLE-BOUNDARY-START(94490132580)
            /*bool */ get HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._hasChanged)
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let currentTime = $.$$.System.DateTime.UtcNow;
                if ($.$$.System.TimeSpan.op_LessThan($.$$.System.DateTime.op_Subtraction(currentTime, this._lastCheckedTimeUtc), $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken.PollingInterval))
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteTimeUtc();
                if ($.$$.System.DateTime.op_Inequality(this._previousWriteTimeUtc, lastWriteTimeUtc))
                {
                    this._previousWriteTimeUtc = lastWriteTimeUtc;
                    this._hasChanged = true;
                }
                this._lastCheckedTimeUtc = currentTime;
                return this._hasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132580)
            
            //--TRIMMABLE-BOUNDARY-START(115964969060)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(115964969060)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475688548)
                this._previousWriteTimeUtc = $.$default($.$$.System.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475688548)
                
                //--TRIMMABLE-BOUNDARY-START(17180721252)
                this._lastCheckedTimeUtc = $.$default($.$$.System.DateTime);
                //--TRIMMABLE-BOUNDARY-END(17180721252)
                
            }
            //--TRIMMABLE-BOUNDARY-START(38655557732)
            //Static Initializer
            static $sinit()
            {
                {
                    this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557732)
            
            static $h = 852068;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670001764),
    {
      "p": 185860097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900197988,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734772836,
        "f": 83886120
      },
      "n": "PollingInterval",
      "d": 852068,
      "h": 111670001764,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111670001764),
//--TRIMMABLE-BOUNDARY-START(47245492324),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394212,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554903652,
        "f": 83886088
      },
      "n": "ActiveChangeCallbacks",
      "d": 852068,
      "h": 47245492324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245492324),
//--TRIMMABLE-BOUNDARY-START(51540459620),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328804,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144838244,
        "f": 83886088
      },
      "n": "CancellationTokenSource",
      "d": 852068,
      "h": 51540459620,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540459620),
//--TRIMMABLE-BOUNDARY-START(98785099876),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375034468,
        "f": 50331650
      },
      "n": "{196708}.CancellationTokenSource",
      "o": "Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource",
      "d": 852068,
      "h": 98785099876,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98785099876),
//--TRIMMABLE-BOUNDARY-START(94490132580),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263396,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 852068,
      "h": 94490132580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490132580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195165284),
    {
      "r": 65273857,
      "n": "GetLastWriteTimeUtc",
      "d": 852068,
      "h": 90195165284,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195165284),
//--TRIMMABLE-BOUNDARY-START(115964969060),
    {
      "r": 90308609,
      "p": [
        {
          "n": "callback",
          "p": $.$$.System.Action$$($.$$.System.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 852068,
      "h": 115964969060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964969060)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786660),
    {
      "t": 92667905,
      "n": "_fileInfo",
      "d": 852068,
      "h": 8590786660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786660),
//--TRIMMABLE-BOUNDARY-START(21475688548),
    {
      "t": 65273857,
      "n": "_previousWriteTimeUtc",
      "d": 852068,
      "h": 21475688548,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688548),
//--TRIMMABLE-BOUNDARY-START(17180721252),
    {
      "t": 65273857,
      "n": "_lastCheckedTimeUtc",
      "d": 852068,
      "h": 17180721252,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721252),
//--TRIMMABLE-BOUNDARY-START(12885753956),
    {
      "t": 262145,
      "n": "_hasChanged",
      "d": 852068,
      "h": 12885753956,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753956),
//--TRIMMABLE-BOUNDARY-START(25770655844),
    {
      "t": 170196993,
      "n": "_tokenSource",
      "d": 852068,
      "h": 25770655844,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655844),
//--TRIMMABLE-BOUNDARY-START(4295819364),
    {
      "t": 196693,
      "n": "_changeToken",
      "d": 852068,
      "h": 4295819364,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950525028),
    {
      "p": [
        {
          "n": "fileInfo",
          "p": 92667905
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852068,
      "h": 42950525028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950525028)
  ],
  "i": [196708,720981
  ],
  "h": 852068
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852068)
        
        
        //--TRIMMABLE-BOUNDARY-START(983140)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider", ($self) => class PhysicalFileProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(128850002020)
            /*string*/ static PollingEnvironmentKey = null;
            //--TRIMMABLE-BOUNDARY-END(128850002020)
            
            //--TRIMMABLE-BOUNDARY-START(30065754212)
            /*char[]*/ static _pathSeparators = null;
            //--TRIMMABLE-BOUNDARY-END(30065754212)
            
            //--TRIMMABLE-BOUNDARY-START(25770786916)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(25770786916)
            
            //--TRIMMABLE-BOUNDARY-START(12885885028)
            /*Func<PhysicalFilesWatcher>*/ _fileWatcherFactory = null;
            //--TRIMMABLE-BOUNDARY-END(12885885028)
            
            //--TRIMMABLE-BOUNDARY-START(8590917732)
            /*PhysicalFilesWatcher?*/ _fileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(8590917732)
            
            //--TRIMMABLE-BOUNDARY-START(17180852324)
            /*bool*/ _fileWatcherInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(17180852324)
            
            //--TRIMMABLE-BOUNDARY-START(21475819620)
            /*object*/ _fileWatcherLock = null;
            //--TRIMMABLE-BOUNDARY-END(21475819620)
            
            //--TRIMMABLE-BOUNDARY-START(38655688804)
            /*bool?*/ _usePollingFileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(38655688804)
            
            //--TRIMMABLE-BOUNDARY-START(34360721508)
            /*bool?*/ _useActivePolling = null;
            //--TRIMMABLE-BOUNDARY-END(34360721508)
            
            //--TRIMMABLE-BOUNDARY-START(4295950436)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(4295950436)
            
            //--TRIMMABLE-BOUNDARY-START(55835557988)
            $ctor$2(/*string*/ root)
            {
                this.$ctor$1(root, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835557988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835557988)
            
            //--TRIMMABLE-BOUNDARY-START(51540590692)
            $ctor$1(/*string*/ root, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540590692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.System.IO.Path.IsPathRooted$1(root))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("The path must be absolute.", "root");
                    }
                    /*string*/ let fullRoot = $.$$.System.IO.Path.GetFullPath$1(root);
                    this.Root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash(fullRoot);
                    if (!$.$$.System.IO.Directory.Exists(this.Root))
                    {
                        throw new $.$$.System.IO.DirectoryNotFoundException().$ctor$17(this.Root);
                    }
                    this._filters = filters;
                    this._fileWatcherFactory = new ($.$$.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher))().$ctor(this, this.CreateFileWatcher);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590692)
            
            //--TRIMMABLE-BOUNDARY-START(171799674980)
            /*bool */ get UsePollingFileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    return false;
                }
                if (this._usePollingFileWatcher === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return this._usePollingFileWatcher ?? false;
            }
            /*bool */ set UsePollingFileWatcher(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209740388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.Format$6($.$mefp.System.SR.CannotModifyWhenFileWatcherInitialized, "UsePollingFileWatcher"));
                }
                this._usePollingFileWatcher = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171799674980)
            
            //--TRIMMABLE-BOUNDARY-START(167504707684)
            /*bool */ get UseActivePolling()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._useActivePolling === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(this._useActivePolling);
            }
            /*bool */ set UseActivePolling(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._useActivePolling = value;
            }
            //--TRIMMABLE-BOUNDARY-END(167504707684)
            
            //--TRIMMABLE-BOUNDARY-START(73015427172)
            /*PhysicalFilesWatcher */ get FileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher, $.$ref(() => this._fileWatcher, ($v) => this._fileWatcher = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._fileWatcherInitialized, ($v) => this._fileWatcherInitialized = $v, null), $.$ref(() => this._fileWatcherLock, ($v) => this._fileWatcherLock = $v, $.$$.System.Object), this._fileWatcherFactory);
            }
            /*PhysicalFilesWatcher */ set FileWatcher(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!this._fileWatcherInitialized, "!_fileWatcherInitialized");
                this._fileWatcherInitialized = true;
                this._fileWatcher = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73015427172)
            
            //--TRIMMABLE-BOUNDARY-START(60130525284)
            /*PhysicalFilesWatcher */ CreateFileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash($.$$.System.IO.Path.GetFullPath$1(this.Root));
                /*FileSystemWatcher?*/ let watcher;
                if ($.$$.System.OperatingSystem.IsBrowser() || $.$$.System.OperatingSystem.IsWasi() || ($.$$.System.OperatingSystem.IsIOS() && !$.$$.System.OperatingSystem.IsMacCatalyst()) || $.$$.System.OperatingSystem.IsTvOS())
                {
                    this.UsePollingFileWatcher = true;
                    this.UseActivePolling = true;
                    watcher = null;
                }
                else 
                {
                    watcher = this.UsePollingFileWatcher && this.UseActivePolling ? null : new $.$sifw.System.IO.FileSystemWatcher().$ctor$5(root);
                }
                return (() =>
                {
                    //new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher()
                    const $t1 = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                    const $i1 = new $t1();
                    $i1.$ctor$1(root, watcher, this.UsePollingFileWatcher, this._filters);
                    $i1.UseActivePolling = this.UseActivePolling;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525284)
            
            //--TRIMMABLE-BOUNDARY-START(133144969316)
            /*void */ ReadPollingEnvironmentVariables()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let environmentValue = $.$$.System.Environment.GetEnvironmentVariable$1("DOTNET_USE_POLLING_FILE_WATCHER"/*PollingEnvironmentKey*/);
                /*bool*/ let pollForChanges = $.$$.System.String.Equals$2(environmentValue, "1", 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$2(environmentValue, "true", 5/*StringComparison.OrdinalIgnoreCase*/);
                this._usePollingFileWatcher = pollForChanges;
                this._useActivePolling = pollForChanges;
            }
            //--TRIMMABLE-BOUNDARY-END(133144969316)
            
            //--TRIMMABLE-BOUNDARY-START(64425492580)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(64425492580)
            
            //--TRIMMABLE-BOUNDARY-START(68720459876)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720459876)
            
            //--TRIMMABLE-BOUNDARY-START(137439936612)
            /*string*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(137439936612)
            
            //--TRIMMABLE-BOUNDARY-START(120260067428)
            /*string? */ GetFullPath(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(path))
                {
                    return null;
                }
                /*string*/ let fullPath;
                try
                {
                    fullPath = $.$$.System.IO.Path.GetFullPath$1($.$$.System.IO.Path.Combine$3(this.Root, path));
                }
                catch($e)
                {
                    return null;
                }
                if (!this.IsUnderneathRoot(fullPath))
                {
                    return null;
                }
                return fullPath;
            }
            //--TRIMMABLE-BOUNDARY-END(120260067428)
            
            //--TRIMMABLE-BOUNDARY-START(124555034724)
            /*bool */ IsUnderneathRoot(/*string*/ fullPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.StartsWith$2.call(fullPath, this.Root, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034724)
            
            //--TRIMMABLE-BOUNDARY-START(115965100132)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(subpath) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                subpath = $.$$.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                if ($.$$.System.IO.Path.IsPathRooted$1(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*string?*/ let fullPath = this.GetFullPath(subpath);
                if ($.$$.System.String.op_Equality(fullPath, null))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*var*/ let fileInfo = new $.$$.System.IO.FileInfo().$ctor$6(fullPath);
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileInfo, this._filters))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(fileInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(115965100132)
            
            //--TRIMMABLE-BOUNDARY-START(111670132836)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670132836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if ($.$$.System.String.op_Equality(subpath, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    subpath = $.$$.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                    if ($.$$.System.IO.Path.IsPathRooted$1(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    /*string?*/ let fullPath = this.GetFullPath(subpath);
                    if ($.$$.System.String.op_Equality(fullPath, null) || !$.$$.System.IO.Directory.Exists(fullPath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    return new $.$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents().$ctor$1(fullPath, this._filters);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.IO.DirectoryNotFoundException)
                    {
                    }
                    else if ($e instanceof $.$$.System.IO.IOException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
            }
            //--TRIMMABLE-BOUNDARY-END(111670132836)
            
            //--TRIMMABLE-BOUNDARY-START(176094642276)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094642276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(filter, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidFilterChars(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                filter = $.$$.System.String.TrimStart$2.call(filter, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                return this.FileWatcher.CreateFileChangeToken(filter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094642276)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            Microsoft$Extensions$FileProviders$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475819620)
                this._fileWatcherLock = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(21475819620)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47245623396)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(128850002020)
                    this.PollingEnvironmentKey = "DOTNET_USE_POLLING_FILE_WATCHER";
                    //--TRIMMABLE-BOUNDARY-END(128850002020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065754212)
                    this._pathSeparators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [$.$$.System.IO.Path.DirectorySeparatorChar, $.$$.System.IO.Path.AltDirectorySeparatorChar], null, null);
                    //--TRIMMABLE-BOUNDARY-END(30065754212)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245623396)
            
            static $h = 983140;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799674980),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375165540,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209740388,
        "f": 83886081
      },
      "n": "UsePollingFileWatcher",
      "d": 983140,
      "h": 171799674980,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799674980),
//--TRIMMABLE-BOUNDARY-START(167504707684),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785230948,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619805796,
        "f": 83886081
      },
      "n": "UseActivePolling",
      "d": 983140,
      "h": 167504707684,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504707684),
//--TRIMMABLE-BOUNDARY-START(73015427172),
    {
      "p": 720996,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361764,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029871204,
        "f": 83886088
      },
      "n": "FileWatcher",
      "d": 983140,
      "h": 73015427172,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(73015427172),
//--TRIMMABLE-BOUNDARY-START(137439936612),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195296356,
        "f": 50331649
      },
      "n": "Root",
      "d": 983140,
      "h": 137439936612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439936612)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130525284),
    {
      "r": 720996,
      "n": "CreateFileWatcher",
      "d": 983140,
      "h": 60130525284,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60130525284),
//--TRIMMABLE-BOUNDARY-START(133144969316),
    {
      "r": 65537,
      "n": "ReadPollingEnvironmentVariables",
      "d": 983140,
      "h": 133144969316,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144969316),
//--TRIMMABLE-BOUNDARY-START(64425492580),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 983140,
      "h": 64425492580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425492580),
//--TRIMMABLE-BOUNDARY-START(68720459876),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 983140,
      "h": 68720459876,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720459876),
//--TRIMMABLE-BOUNDARY-START(120260067428),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetFullPath",
      "d": 983140,
      "h": 120260067428,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260067428),
//--TRIMMABLE-BOUNDARY-START(124555034724),
    {
      "r": 262145,
      "p": [
        {
          "n": "fullPath",
          "p": 1310721
        }
      ],
      "n": "IsUnderneathRoot",
      "d": 983140,
      "h": 124555034724,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555034724),
//--TRIMMABLE-BOUNDARY-START(115965100132),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 983140,
      "h": 115965100132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965100132),
//--TRIMMABLE-BOUNDARY-START(111670132836),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 983140,
      "h": 111670132836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670132836),
//--TRIMMABLE-BOUNDARY-START(176094642276),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 983140,
      "h": 176094642276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094642276)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128850002020),
    {
      "t": 1310721,
      "n": "PollingEnvironmentKey",
      "d": 983140,
      "h": 128850002020,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128850002020),
//--TRIMMABLE-BOUNDARY-START(30065754212),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_pathSeparators",
      "d": 983140,
      "h": 30065754212,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065754212),
//--TRIMMABLE-BOUNDARY-START(25770786916),
    {
      "t": 327780,
      "n": "_filters",
      "d": 983140,
      "h": 25770786916,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786916),
//--TRIMMABLE-BOUNDARY-START(12885885028),
    {
      "t": $.$$.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher).$h,
      "n": "_fileWatcherFactory",
      "d": 983140,
      "h": 12885885028,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885028),
//--TRIMMABLE-BOUNDARY-START(8590917732),
    {
      "t": 720996,
      "n": "_fileWatcher",
      "d": 983140,
      "h": 8590917732,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917732),
//--TRIMMABLE-BOUNDARY-START(17180852324),
    {
      "t": 262145,
      "n": "_fileWatcherInitialized",
      "d": 983140,
      "h": 17180852324,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852324),
//--TRIMMABLE-BOUNDARY-START(21475819620),
    {
      "t": 131073,
      "n": "_fileWatcherLock",
      "d": 983140,
      "h": 21475819620,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819620),
//--TRIMMABLE-BOUNDARY-START(38655688804),
    {
      "t": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "_usePollingFileWatcher",
      "d": 983140,
      "h": 38655688804,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655688804),
//--TRIMMABLE-BOUNDARY-START(34360721508),
    {
      "t": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "_useActivePolling",
      "d": 983140,
      "h": 34360721508,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360721508),
//--TRIMMABLE-BOUNDARY-START(4295950436),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 983140,
      "h": 4295950436,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835557988),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983140,
      "h": 55835557988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835557988),
//--TRIMMABLE-BOUNDARY-START(51540590692),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983140,
      "h": 51540590692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590692)
  ],
  "i": [262243,90308609
  ],
  "h": 983140
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.PhysicalFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983140)
        
        
        //--TRIMMABLE-BOUNDARY-START(917604)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken", ($self) => class PollingWildCardChangeToken extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180786788)
            /*object*/ _enumerationLock = null;
            //--TRIMMABLE-BOUNDARY-END(17180786788)
            
            //--TRIMMABLE-BOUNDARY-START(12885819492)
            /*DirectoryInfoBase*/ _directoryInfo = null;
            //--TRIMMABLE-BOUNDARY-END(12885819492)
            
            //--TRIMMABLE-BOUNDARY-START(25770721380)
            /*Matcher*/ _matcher = null;
            //--TRIMMABLE-BOUNDARY-END(25770721380)
            
            //--TRIMMABLE-BOUNDARY-START(4295884900)
            /*bool*/ _changed = false;
            //--TRIMMABLE-BOUNDARY-END(4295884900)
            
            //--TRIMMABLE-BOUNDARY-START(21475754084)
            /*DateTime*/ _lastScanTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(21475754084)
            
            //--TRIMMABLE-BOUNDARY-START(30065688676)
            /*byte[]?*/ _previousHash = null;
            //--TRIMMABLE-BOUNDARY-END(30065688676)
            
            //--TRIMMABLE-BOUNDARY-START(34360655972)
            /*CancellationTokenSource?*/ _tokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(34360655972)
            
            //--TRIMMABLE-BOUNDARY-START(8590852196)
            /*CancellationChangeToken?*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(8590852196)
            
            //--TRIMMABLE-BOUNDARY-START(51540525156)
            $ctor$1(/*string*/ root, /*string*/ pattern)
            {
                this.$ctor$2(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(new $.$$.System.IO.DirectoryInfo().$ctor$5(root)), pattern, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock.Instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540525156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525156)
            
            //--TRIMMABLE-BOUNDARY-START(55835492452)
            $ctor$2(/*DirectoryInfoBase*/ directoryInfo, /*string*/ pattern, /*IClock*/ clock)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835492452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._directoryInfo = directoryInfo;
                    this.Clock = clock;
                    this._matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    this._matcher.AddInclude(pattern);
                    this.CalculateChanges();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492452)
            
            //--TRIMMABLE-BOUNDARY-START(60130459748)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(60130459748)
            
            //--TRIMMABLE-BOUNDARY-START(150324772964)
            /*TimeSpan*/ PollingInterval;
            //--TRIMMABLE-BOUNDARY-END(150324772964)
            
            //--TRIMMABLE-BOUNDARY-START(68720394340)
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504642148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(68720394340)
            
            //--TRIMMABLE-BOUNDARY-START(133144903780)
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            //--TRIMMABLE-BOUNDARY-END(133144903780)
            
            //--TRIMMABLE-BOUNDARY-START(73015361636)
            /*IClock*/ Clock = null;
            //--TRIMMABLE-BOUNDARY-END(73015361636)
            
            //--TRIMMABLE-BOUNDARY-START(128849936484)
            /*bool */ get HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670067300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._changed)
                {
                    return true;
                }
                if (ShouldRefresh.call(this))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._enumerationLock)
                        {
                            if (!this._changed && ShouldRefresh.call(this))
                            {
                                this._changed = this.CalculateChanges();
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._enumerationLock)
                    }
                }
                return this._changed;
                /*bool*/  function ShouldRefresh()
                {
                    {
                        return $.$$.System.TimeSpan.op_GreaterThanOrEqual($.$$.System.DateTime.op_Subtraction(this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow, this._lastScanTimeUtc), this.PollingInterval);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849936484)
            
            //--TRIMMABLE-BOUNDARY-START(64425427044)
            /*bool */ CalculateChanges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425427044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PatternMatchingResult*/ let result = this._matcher.Execute(this._directoryInfo);
                /*IOrderedEnumerable<FilePatternMatch>*/ let files = $.$sl.System.Linq.Enumerable.OrderBy($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$$.System.String, result.Files, new ($.$$.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$$.System.String))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Path;
                }, {
  "r": 1310721,
  "p": [
    {
      "n": "f",
      "p": 393317
    }
  ],
  "n": "",
  "d": 917604,
  "h": 0,
  "f": 17825794
}), $.$$.System.StringComparer.Ordinal);
                let sha256 = null;
                try
                {
                    sha256 = $.$sscr.System.Security.Cryptography.IncrementalHash.CreateHash($.$sscr.System.Security.Cryptography.HashAlgorithmName.SHA256);
                    var $en3 = files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var file = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteUtc(file.Path);
                            if (this._lastScanTimeUtc.Ticks !== 0n && $.$$.System.DateTime.op_LessThan(this._lastScanTimeUtc, lastWriteTimeUtc))
                            {
                                return true;
                            }
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken.ComputeHash(sha256, file.Path, lastWriteTimeUtc);
                        }
                    }
                    /*Span<byte>*/ let currentHash = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.trunc(256 / 8), null);
                    sha256.GetHashAndReset$1(currentHash);
                    if (this._previousHash === null)
                    {
                        this._previousHash = currentHash.ToArray();
                    }
                    else if (!$.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, this._previousHash)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit(currentHash)))
                    {
                        return true;
                    }
                    this._lastScanTimeUtc = this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow;
                }
                finally
                {
                    sha256?.System$IDisposable$Dispose();
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64425427044)
            
            //--TRIMMABLE-BOUNDARY-START(124554969188)
            /*DateTime */ GetLastWriteUtc(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554969188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let filePath = $.$$.System.IO.Path.Combine$3(this._directoryInfo.FullName, path);
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc$1(filePath) ?? $.$$.System.IO.File.GetLastWriteTimeUtc$1(filePath);
            }
            //--TRIMMABLE-BOUNDARY-END(124554969188)
            
            //--TRIMMABLE-BOUNDARY-START(77310328932)
            static /*void */ ComputeHash(/*IncrementalHash*/ sha256, /*string*/ path, /*DateTime*/ lastChangedUtc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310328932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sha256.AppendData$2($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path)));
                sha256.AppendData$2($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.DateTime, $.$$.System.ReadOnlySpan$$($.$$.System.DateTime).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.DateTime), [lastChangedUtc], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(77310328932)
            
            //--TRIMMABLE-BOUNDARY-START(146029805668)
            /*IDisposable */ Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029805668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(146029805668)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180786788)
                this._enumerationLock = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(17180786788)
                
                //--TRIMMABLE-BOUNDARY-START(21475754084)
                this._lastScanTimeUtc = $.$default($.$$.System.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475754084)
                
                this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
            }
            static $h = 917604;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130459748),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900263524,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914707556,
        "f": 83886088
      },
      "n": "ActiveChangeCallbacks",
      "d": 917604,
      "h": 60130459748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459748),
//--TRIMMABLE-BOUNDARY-START(150324772964),
    {
      "p": 185860097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260001892,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094576740,
        "f": 83886088
      },
      "n": "PollingInterval",
      "d": 917604,
      "h": 150324772964,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(150324772964),
//--TRIMMABLE-BOUNDARY-START(68720394340),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490198116,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504642148,
        "f": 83886088
      },
      "n": "CancellationTokenSource",
      "d": 917604,
      "h": 68720394340,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68720394340),
//--TRIMMABLE-BOUNDARY-START(133144903780),
    {
      "p": 170196993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734838372,
        "f": 50331650
      },
      "n": "{196708}.CancellationTokenSource",
      "o": "Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource",
      "d": 917604,
      "h": 133144903780,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133144903780),
//--TRIMMABLE-BOUNDARY-START(73015361636),
    {
      "p": 458852,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080132708,
        "f": 50331650
      },
      "n": "Clock",
      "d": 917604,
      "h": 73015361636,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(73015361636),
//--TRIMMABLE-BOUNDARY-START(128849936484),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670067300,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 917604,
      "h": 128849936484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849936484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425427044),
    {
      "r": 262145,
      "n": "CalculateChanges",
      "d": 917604,
      "h": 64425427044,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425427044),
//--TRIMMABLE-BOUNDARY-START(124554969188),
    {
      "r": 65273857,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetLastWriteUtc",
      "d": 917604,
      "h": 124554969188,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(124554969188),
//--TRIMMABLE-BOUNDARY-START(77310328932),
    {
      "r": 65537,
      "p": [
        {
          "n": "sha256",
          "p": 12386334
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "lastChangedUtc",
          "p": 65273857
        }
      ],
      "n": "ComputeHash",
      "d": 917604,
      "h": 77310328932,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310328932)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786788),
    {
      "t": 131073,
      "n": "_enumerationLock",
      "d": 917604,
      "h": 17180786788,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180786788),
//--TRIMMABLE-BOUNDARY-START(12885819492),
    {
      "t": 65637,
      "n": "_directoryInfo",
      "d": 917604,
      "h": 12885819492,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819492),
//--TRIMMABLE-BOUNDARY-START(25770721380),
    {
      "t": 2424933,
      "n": "_matcher",
      "d": 917604,
      "h": 25770721380,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770721380),
//--TRIMMABLE-BOUNDARY-START(4295884900),
    {
      "t": 262145,
      "n": "_changed",
      "d": 917604,
      "h": 4295884900,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884900),
//--TRIMMABLE-BOUNDARY-START(21475754084),
    {
      "t": 65273857,
      "n": "_lastScanTimeUtc",
      "d": 917604,
      "h": 21475754084,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475754084),
//--TRIMMABLE-BOUNDARY-START(30065688676),
    {
      "t": $.$typeArray($.$$.System.Byte).$h,
      "n": "_previousHash",
      "d": 917604,
      "h": 30065688676,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065688676),
//--TRIMMABLE-BOUNDARY-START(34360655972),
    {
      "t": 170196993,
      "n": "_tokenSource",
      "d": 917604,
      "h": 34360655972,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360655972),
//--TRIMMABLE-BOUNDARY-START(8590852196),
    {
      "t": 196693,
      "n": "_changeToken",
      "d": 917604,
      "h": 8590852196,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51540525156),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917604,
      "h": 51540525156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525156),
//--TRIMMABLE-BOUNDARY-START(55835492452),
    {
      "p": [
        {
          "n": "directoryInfo",
          "p": 65637
        },
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "clock",
          "p": 458852
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917604,
      "h": 55835492452,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55835492452)
  ],
  "i": [196708,720981
  ],
  "h": 917604
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917604)
        
        
        //--TRIMMABLE-BOUNDARY-START(131172)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents", ($self) => class PhysicalDirectoryContents extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098468)
            /*PhysicalDirectoryInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(4295098468)
            
            //--TRIMMABLE-BOUNDARY-START(12885033060)
            $ctor$2(/*string*/ directory)
            {
                this.$ctor$1(directory, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033060);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033060)
            
            //--TRIMMABLE-BOUNDARY-START(8590065764)
            $ctor$1(/*string*/ directory, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(directory, "directory");
                    this._info = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$1(new $.$$.System.IO.DirectoryInfo().$ctor$5(directory), filters);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065764)
            
            //--TRIMMABLE-BOUNDARY-START(17180000356)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000356)
            
            //--TRIMMABLE-BOUNDARY-START(30064902244)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064902244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._info.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064902244)
            
            //--TRIMMABLE-BOUNDARY-START(34359869540)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359869540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._info.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869540)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 131172;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000356),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769934948,
        "f": 50331649
      },
      "n": "Exists",
      "d": 131172,
      "h": 17180000356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000356)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064902244),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 131172,
      "h": 30064902244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064902244)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098468),
    {
      "t": 589924,
      "n": "_info",
      "d": 131172,
      "h": 4295098468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098468)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033060),
    {
      "p": [
        {
          "n": "directory",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131172,
      "h": 12885033060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033060),
//--TRIMMABLE-BOUNDARY-START(8590065764),
    {
      "p": [
        {
          "n": "directory",
          "p": 1310721
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131172,
      "h": 8590065764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065764)
  ],
  "i": [131171,$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,62652417
  ],
  "h": 131172
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131172)
        
        
        //--TRIMMABLE-BOUNDARY-START(589924)
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo", ($self) => class PhysicalDirectoryInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885491812)
            /*DirectoryInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(12885491812)
            
            //--TRIMMABLE-BOUNDARY-START(4295557220)
            /*IEnumerable<IFileInfo>?*/ _entries = null;
            //--TRIMMABLE-BOUNDARY-END(4295557220)
            
            //--TRIMMABLE-BOUNDARY-START(8590524516)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(8590524516)
            
            //--TRIMMABLE-BOUNDARY-START(21475426404)
            $ctor$2(/*DirectoryInfo*/ info)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426404)
            
            //--TRIMMABLE-BOUNDARY-START(17180459108)
            $ctor$1(/*DirectoryInfo*/ info, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                    this._filters = filters;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459108)
            
            //--TRIMMABLE-BOUNDARY-START(34360328292)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328292)
            
            //--TRIMMABLE-BOUNDARY-START(103079805028)
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079805028)
            
            //--TRIMMABLE-BOUNDARY-START(111669739620)
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(111669739620)
            
            //--TRIMMABLE-BOUNDARY-START(107374772324)
            /*string */ get Name()
            {
                return this._info.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772324)
            
            //--TRIMMABLE-BOUNDARY-START(98784837732)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837732)
            
            //--TRIMMABLE-BOUNDARY-START(94489870436)
            /*bool */ get IsDirectory()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(94489870436)
            
            //--TRIMMABLE-BOUNDARY-START(25770393700)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.CannotCreateStream);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393700)
            
            //--TRIMMABLE-BOUNDARY-START(90194903140)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            //--TRIMMABLE-BOUNDARY-END(90194903140)
            
            //--TRIMMABLE-BOUNDARY-START(115964706916)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            //--TRIMMABLE-BOUNDARY-END(115964706916)
            
            //--TRIMMABLE-BOUNDARY-START(30065360996)
            /*void */ EnsureInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$sl.System.Linq.Enumerable.Where($.$$.System.IO.FileSystemInfo, this._info.EnumerateFileSystemInfos(), new ($.$$.System.Func$$$($.$$.System.IO.FileSystemInfo, $.$$.System.Boolean))().$ctor(this,  (/*info*/ info) =>
                    {
                        return !$.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(info, this._filters);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "info",
      "p": 93323265
    }
  ],
  "n": "",
  "d": 589924,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo))().$ctor(this,  (/*info*/ info) =>
                    {
                        return (() =>
                        {
                            {
                                let file;
                                if ((file = info, $.$is(file, $.$$.System.IO.FileInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(file);
                                }
                            }
                            {
                                let dir;
                                if ((dir = info, $.$is(dir, $.$$.System.IO.DirectoryInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$2(dir);
                                }
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.UnexpectedFileSystemInfo);
                        })();
                    }, {
  "r": 196707,
  "p": [
    {
      "n": "info",
      "p": 93323265
    }
  ],
  "n": "",
  "d": 589924,
  "h": 0,
  "f": 17825794
}));
                }
                catch(ex)
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Empty($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065360996)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 589924;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360328292),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262884,
        "f": 50331649
      },
      "n": "Exists",
      "d": 589924,
      "h": 34360328292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328292),
//--TRIMMABLE-BOUNDARY-START(103079805028),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066660,
        "f": 50331649
      },
      "n": "Length",
      "d": 589924,
      "h": 103079805028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079805028),
//--TRIMMABLE-BOUNDARY-START(111669739620),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899935844,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 589924,
      "h": 111669739620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669739620),
//--TRIMMABLE-BOUNDARY-START(107374772324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310001252,
        "f": 50331649
      },
      "n": "Name",
      "d": 589924,
      "h": 107374772324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374772324),
//--TRIMMABLE-BOUNDARY-START(98784837732),
    {
      "p": 65470465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132068,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 589924,
      "h": 98784837732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784837732),
//--TRIMMABLE-BOUNDARY-START(94489870436),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197476,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 589924,
      "h": 94489870436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489870436)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770393700),
    {
      "r": 94961665,
      "n": "CreateReadStream",
      "d": 589924,
      "h": 25770393700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393700),
//--TRIMMABLE-BOUNDARY-START(90194903140),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 589924,
      "h": 90194903140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194903140),
//--TRIMMABLE-BOUNDARY-START(30065360996),
    {
      "r": 65537,
      "n": "EnsureInitialized",
      "d": 589924,
      "h": 30065360996,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065360996)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491812),
    {
      "t": 91488257,
      "n": "_info",
      "d": 589924,
      "h": 12885491812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491812),
//--TRIMMABLE-BOUNDARY-START(4295557220),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,
      "n": "_entries",
      "d": 589924,
      "h": 4295557220,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557220),
//--TRIMMABLE-BOUNDARY-START(8590524516),
    {
      "t": 327780,
      "n": "_filters",
      "d": 589924,
      "h": 8590524516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426404),
    {
      "p": [
        {
          "n": "info",
          "p": 91488257
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589924,
      "h": 21475426404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426404),
//--TRIMMABLE-BOUNDARY-START(17180459108),
    {
      "p": [
        {
          "n": "info",
          "p": 91488257
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589924,
      "h": 17180459108,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180459108)
  ],
  "i": [196707,131171,$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,62652417
  ],
  "h": 589924
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589924)
        
        
        //--TRIMMABLE-BOUNDARY-START(327780)
        $asm.$str("$mefp.Microsoft.Extensions.FileProviders.Physical.ExclusionFilters", ($self) => class ExclusionFilters extends $.$$.System.Enum
        {
            static Sensitive = 7;
            static DotPrefixed = 1;
            static Hidden = 2;
            static System = 4;
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Sensitive": 7n,
                    "DotPrefixed": 1n,
                    "Hidden": 2n,
                    "System": 4n,
                    "None": 0n
                };
            }
            static $h = 327780;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475164260),
    {
      "t": 327780,
      "n": "Sensitive",
      "d": 327780,
      "h": 21475164260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164260),
//--TRIMMABLE-BOUNDARY-START(8590262372),
    {
      "t": 327780,
      "n": "DotPrefixed",
      "d": 327780,
      "h": 8590262372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262372),
//--TRIMMABLE-BOUNDARY-START(12885229668),
    {
      "t": 327780,
      "n": "Hidden",
      "d": 327780,
      "h": 12885229668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229668),
//--TRIMMABLE-BOUNDARY-START(25770131556),
    {
      "t": 327780,
      "n": "System",
      "d": 327780,
      "h": 25770131556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131556),
//--TRIMMABLE-BOUNDARY-START(17180196964),
    {
      "t": 327780,
      "n": "None",
      "d": 327780,
      "h": 17180196964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196964)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295076),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327780,
      "h": 4295295076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295076)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 327780,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.ExclusionFilters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327780)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"))
//--TRIMMABLE-BOUNDARY-END(100)
