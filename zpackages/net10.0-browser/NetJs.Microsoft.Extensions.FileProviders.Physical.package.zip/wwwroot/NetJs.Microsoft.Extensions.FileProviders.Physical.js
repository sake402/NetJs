
//--TRIMMABLE-BOUNDARY-START(100)
(async function () {
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $mefa, $mef, $mwp, $sci, $scn, $scm, $so, $scp, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $sto, $sifw, $snp, $sscr) {
    "use strict";
    let _;
    let $Ghuloh;
    let $HJzEkf;
    let $FTzZSa;
    let $FYecWe;
    let $wWKNfl;
    let $uKuZca;
    let $BLlLui;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Physical", 
    {
  "h": 100,
  "f": "Microsoft.Extensions.FileProviders.Physical",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.FileProviders.Physical.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Physical",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileProviders.Physical",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(458852)
        $asm.$cls(`$mefp.MEFP.IClock`, ($self) => class IClock
        {
            static $h = 458852;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885360740),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590393444,
        "f": 50331905
      },
      "n": "UtcNow",
      "o": "MEFP$IClock$UtcNow",
      "d": 458852,
      "h": 12885360740,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885360740)
  ],
  "h": 458852
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.IClock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}IClock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458852)
        
        

        //--TRIMMABLE-BOUNDARY-START(196708)
        $asm.$cls(`$mefp.MEF.IPollingChangeToken`, ($self) => class IPollingChangeToken
        {
            static $h = 196708;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295164004),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885098596,
        "f": 50331905
      },
      "n": "CancellationTokenSource",
      "o": "MEF$IPollingChangeToken$CancellationTokenSource",
      "d": 196708,
      "h": 4295164004,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295164004)
  ],
  "h": 196708
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.IPollingChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}IPollingChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196708)
        
        

        //--TRIMMABLE-BOUNDARY-START(393316)
        $asm.$cls(`$mefp.MEFP.FileSystemInfoHelper`, ($self) => class FileSystemInfoHelper
        {
            //--TRIMMABLE-BOUNDARY-START(12885295204)
            static /*bool */ IsExcluded(/*FileSystemInfo*/ fileSystemInfo, /*ExclusionFilters*/ filters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (filters === 0/*ExclusionFilters.None*/)
                {
                    return false;
                }
                else if ($.$$.S.String.StartsWith$2.call(fileSystemInfo.Name, ".", 4/*StringComparison.Ordinal*/) && (filters & 1/*ExclusionFilters.DotPrefixed*/) !== 0)
                {
                    return true;
                }
                else if (fileSystemInfo.Exists && (((fileSystemInfo.Attributes & 2/*FileAttributes.Hidden*/) !== 0 && (filters & 2/*ExclusionFilters.Hidden*/) !== 0) || ((fileSystemInfo.Attributes & 4/*FileAttributes.System*/) !== 0 && (filters & 4/*ExclusionFilters.System*/) !== 0)))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295204)
            
            //--TRIMMABLE-BOUNDARY-START(8590327908)
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc$1(/*string*/ filePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let fileInfo = new $.$$.SI.FileInfo().$ctor$6(filePath);
                if (fileInfo.Exists)
                {
                    return $.$mefp.MEFP.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(fileInfo);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327908)
            
            //--TRIMMABLE-BOUNDARY-START(4295360612)
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc(/*FileInfo*/ fileInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(fileInfo.Exists, "fileInfo.Exists");
                if (fileInfo.LinkTarget !== null)
                {
                    try
                    {
                        /*FileSystemInfo?*/ let targetInfo = fileInfo.ResolveLinkTarget(true);
                        if (targetInfo !== null && targetInfo.Exists)
                        {
                            return targetInfo.LastWriteTimeUtc;
                        }
                    }
                    catch(ex)
                    {
                    }
                    return $.$$.S.DateTime.MinValue;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360612)
            
            static $h = 393316;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295204),
    {
      "r": 262145,
      "p": [
        {
          "n": "fileSystemInfo",
          "p": 94109697
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": "IsExcluded",
      "d": 393316,
      "h": 12885295204,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885295204),
//--TRIMMABLE-BOUNDARY-START(8590327908),
    {
      "r": $.$typeNullable($.$$.S.DateTime).$h,
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": "GetFileLinkTargetLastWriteTimeUtc",
      "o": "@$1",
      "d": 393316,
      "h": 8590327908,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327908),
//--TRIMMABLE-BOUNDARY-START(4295360612),
    {
      "r": $.$typeNullable($.$$.S.DateTime).$h,
      "p": [
        {
          "n": "fileInfo",
          "p": 93454337
        }
      ],
      "n": "GetFileLinkTargetLastWriteTimeUtc",
      "d": 393316,
      "h": 4295360612,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295360612)
  ],
  "h": 393316
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}FileSystemInfoHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393316)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114212)
        $asm.$cls(`$mefp.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(193274642532)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(193274642532)
            
            //--TRIMMABLE-BOUNDARY-START(184684707940)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(184684707940)
            
            //--TRIMMABLE-BOUNDARY-START(188979675236)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914904164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mefp.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Physical", $.$mefp.S.SR.$type.Assembly);
                    $.$mefp.S.SR.s_resourceManager = temp;
                }
                return $.$mefp.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(188979675236)
            
            //--TRIMMABLE-BOUNDARY-START(30065885284)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145100388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mefp.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159544420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mefp.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30065885284)
            
            //--TRIMMABLE-BOUNDARY-START(8591048804)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195427428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591048804)
            
            //--TRIMMABLE-BOUNDARY-START(12886016100)
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785362020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Non-negative number required.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886016100)
            
            //--TRIMMABLE-BOUNDARY-START(34360852580)
            static /*string */ get Error_FileSystemWatcherRequiredWithoutPolling()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735034980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The fileSystemWatcher parameter must be non-null when pollForChanges is false.";
            }
            //--TRIMMABLE-BOUNDARY-END(34360852580)
            
            //--TRIMMABLE-BOUNDARY-START(17180983396)
            static /*string */ get CannotCreateStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375296612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create a stream for a directory.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180983396)
            
            //--TRIMMABLE-BOUNDARY-START(21475950692)
            static /*string */ get CannotModifyWhenFileWatcherInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965231204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot modify {0} once file watcher has been initialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(21475950692)
            
            //--TRIMMABLE-BOUNDARY-START(77310525540)
            static /*string */ FormatCannotModifyWhenFileWatcherInitialized(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot modify {0} once file watcher has been initialized.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310525540)
            
            //--TRIMMABLE-BOUNDARY-START(25770917988)
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555165796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The hash algorithm name cannot be null or empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(25770917988)
            
            //--TRIMMABLE-BOUNDARY-START(210454511716)
            static /*string */ get UnexpectedFileSystemInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504838756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unexpected type of FileSystemInfo";
            }
            //--TRIMMABLE-BOUNDARY-END(210454511716)
            
            //--TRIMMABLE-BOUNDARY-START(38655819876)
            static /*string */ get FileSystemWatcher_PlatformNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324969572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type '{0}' is not supported on this platform, use polling instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(38655819876)
            
            //--TRIMMABLE-BOUNDARY-START(81605492836)
            static /*string */ FormatFileSystemWatcher_PlatformNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605492836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The type '{0}' is not supported on this platform, use polling instead.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81605492836)
            
            //--TRIMMABLE-BOUNDARY-START(197569609828)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(197569609828)
            
            //--TRIMMABLE-BOUNDARY-START(180389740644)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(180389740644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389740644)
            
            //--TRIMMABLE-BOUNDARY-START(214749479012)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749479012);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mefp.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749479012)
            
            //--TRIMMABLE-BOUNDARY-START(176094773348)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094773348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefp.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(176094773348)
            
            //--TRIMMABLE-BOUNDARY-START(171799806052)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799806052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mefp.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(171799806052)
            
            //--TRIMMABLE-BOUNDARY-START(68720590948)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720590948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(68720590948)
            
            //--TRIMMABLE-BOUNDARY-START(64425623652)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425623652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425623652)
            
            //--TRIMMABLE-BOUNDARY-START(60130656356)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130656356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(60130656356)
            
            //--TRIMMABLE-BOUNDARY-START(73015558244)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015558244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefp.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73015558244)
            
            //--TRIMMABLE-BOUNDARY-START(51540721764)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540721764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540721764)
            
            //--TRIMMABLE-BOUNDARY-START(47245754468)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245754468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754468)
            
            //--TRIMMABLE-BOUNDARY-START(42950787172)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950787172)
            
            //--TRIMMABLE-BOUNDARY-START(55835689060)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835689060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mefp.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55835689060)
            
            //--TRIMMABLE-BOUNDARY-START(4296081508)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(197569609828)
                    this.s_usingResourceKeys = $.$mefp.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(197569609828)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296081508)
            
            static $h = 1114212;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1114212
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114212)
        
        

        //--TRIMMABLE-BOUNDARY-START(524388)
        $asm.$cls(`$mefp.MEFPI.PathUtils`, ($self) => class PathUtils
        {
            //--TRIMMABLE-BOUNDARY-START(25770328164)
            static /*char[] */ GetInvalidFileNameChars()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328164);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToArray($.$$.S.Char, $.$sl.SL.Enumerable.Where($.$$.S.Char, $.$$.SI.Path.GetInvalidFileNameChars(), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c !== $.$$.SI.Path.DirectorySeparatorChar && c !== $.$$.SI.Path.AltDirectorySeparatorChar;
                    }, $FTzZSa ??= {"r":262145,"p":[{"n":"c","p":458753}],"n":"","d":524388,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770328164)
            
            //--TRIMMABLE-BOUNDARY-START(30065295460)
            static /*char[] */ GetInvalidFilterChars()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295460);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sl.SL.Enumerable.ToArray($.$$.S.Char, $.$sl.SL.Enumerable.Where($.$$.S.Char, $.$mefp.MEFPI.PathUtils.GetInvalidFileNameChars(), new ($.$$.S.Func$$$($.$$.S.Char, $.$$.S.Boolean))().$ctor(this,  (/*c*/ c) =>
                    {
                        return c !== /***/ 42 && c !== /*|*/ 124 && c !== /*?*/ 63;
                    }, $FYecWe ??= {"r":262145,"p":[{"n":"c","p":458753}],"n":"","d":524388,"h":0,"f":17825794})));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295460)
            
            //--TRIMMABLE-BOUNDARY-START(4295491684)
            /*SearchValues<char>*/ static _invalidFileNameChars = null;
            //--TRIMMABLE-BOUNDARY-END(4295491684)
            
            //--TRIMMABLE-BOUNDARY-START(8590458980)
            /*SearchValues<char>*/ static _invalidFilterChars = null;
            //--TRIMMABLE-BOUNDARY-END(8590458980)
            
            //--TRIMMABLE-BOUNDARY-START(38655230052)
            static /*bool */ HasInvalidPathChars(/*string*/ path)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655230052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.MemoryExtensions.ContainsAny$2($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(path), $.$mefp.MEFPI.PathUtils._invalidFileNameChars);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655230052)
            
            //--TRIMMABLE-BOUNDARY-START(34360262756)
            static /*bool */ HasInvalidFilterChars(/*string*/ path)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262756);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.MemoryExtensions.ContainsAny$2($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(path), $.$mefp.MEFPI.PathUtils._invalidFilterChars);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262756)
            
            //--TRIMMABLE-BOUNDARY-START(12885426276)
            /*char[]*/ static _pathSeparators = null;
            //--TRIMMABLE-BOUNDARY-END(12885426276)
            
            //--TRIMMABLE-BOUNDARY-START(21475360868)
            static /*string */ EnsureTrailingSlash(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.String.IsNullOrEmpty(path) && $.$$.S.String.get_Chars.call(path, ((path.length - 1) | 0)) !== $.$$.SI.Path.DirectorySeparatorChar)
                {
                    return path + $.$$.SI.Path.DirectorySeparatorChar;
                }
                return path;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360868)
            
            //--TRIMMABLE-BOUNDARY-START(42950197348)
            static /*bool */ PathNavigatesAboveRoot(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let tokenizer = new $.$mep.MEP.StringTokenizer().$ctor$4(path, $.$mefp.MEFPI.PathUtils._pathSeparators);
                /*int*/ let depth = 0;
                let $en1 = tokenizer.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let segment = $en1.Current;
                    {
                        if (segment.Equals$3(".") || segment.Equals$3(""))
                        {
                            continue;
                        }
                        else if (segment.Equals$3(".."))
                        {
                            depth--;
                            if (depth === -1)
                            {
                                return true;
                            }
                        }
                        else 
                        {
                            depth++;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197348)
            
            //--TRIMMABLE-BOUNDARY-START(17180393572)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295491684)
                    this._invalidFileNameChars = $.$$.SB.SearchValues.Create$1($.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$mefp.MEFPI.PathUtils.GetInvalidFileNameChars()));
                    //--TRIMMABLE-BOUNDARY-END(4295491684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590458980)
                    this._invalidFilterChars = $.$$.SB.SearchValues.Create$1($.$$.S.ReadOnlySpan$$($.$$.S.Char).op_Implicit$1($.$mefp.MEFPI.PathUtils.GetInvalidFilterChars()));
                    //--TRIMMABLE-BOUNDARY-END(8590458980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426276)
                    this._pathSeparators = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [$.$$.SI.Path.DirectorySeparatorChar, $.$$.SI.Path.AltDirectorySeparatorChar], null, null);
                    //--TRIMMABLE-BOUNDARY-END(12885426276)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393572)
            
            static $h = 524388;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770328164),
    {
      "r": $.$typeArray($.$$.S.Char).$h,
      "n": "GetInvalidFileNameChars",
      "d": 524388,
      "h": 25770328164,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770328164),
//--TRIMMABLE-BOUNDARY-START(30065295460),
    {
      "r": $.$typeArray($.$$.S.Char).$h,
      "n": "GetInvalidFilterChars",
      "d": 524388,
      "h": 30065295460,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065295460),
//--TRIMMABLE-BOUNDARY-START(38655230052),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "HasInvalidPathChars",
      "d": 524388,
      "h": 38655230052,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38655230052),
//--TRIMMABLE-BOUNDARY-START(34360262756),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "HasInvalidFilterChars",
      "d": 524388,
      "h": 34360262756,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(34360262756),
//--TRIMMABLE-BOUNDARY-START(21475360868),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "EnsureTrailingSlash",
      "d": 524388,
      "h": 21475360868,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475360868),
//--TRIMMABLE-BOUNDARY-START(42950197348),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "PathNavigatesAboveRoot",
      "d": 524388,
      "h": 42950197348,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950197348)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295491684),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "_invalidFileNameChars",
      "d": 524388,
      "h": 4295491684,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295491684),
//--TRIMMABLE-BOUNDARY-START(8590458980),
    {
      "t": $.$$.SB.SearchValues$$($.$$.S.Char).$h,
      "n": "_invalidFilterChars",
      "d": 524388,
      "h": 8590458980,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590458980),
//--TRIMMABLE-BOUNDARY-START(12885426276),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_pathSeparators",
      "d": 524388,
      "h": 12885426276,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885426276)
  ],
  "h": 524388
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}Internal${separator}PathUtils`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524388)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048676)
        $asm.$cls(`$mefp.MEI.NonCapturingTimer`, ($self) => class NonCapturingTimer
        {
            //--TRIMMABLE-BOUNDARY-START(4296015972)
            static /*Timer */ Create(/*TimerCallback*/ callback, /*object*/ state, /*TimeSpan*/ dueTime, /*TimeSpan*/ period)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                /*bool*/ let restoreFlow = false;
                try
                {
                    if (!$.$$.ST$1.ExecutionContext.IsFlowSuppressed())
                    {
                        $.$$.ST$1.ExecutionContext.SuppressFlow();
                        restoreFlow = true;
                    }
                    return new $.$$.ST$1.Timer().$ctor$5(callback, state, dueTime, period);
                }
                finally
                {
                    {
                        if (restoreFlow)
                        {
                            $.$$.ST$1.ExecutionContext.RestoreFlow();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015972)
            
            static $h = 1048676;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015972),
    {
      "r": 183762945,
      "p": [
        {
          "n": "callback",
          "p": 183828481
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "dueTime",
          "p": 186646529
        },
        {
          "n": "period",
          "p": 186646529
        }
      ],
      "n": "Create",
      "d": 1048676,
      "h": 4296015972,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296015972)
  ],
  "h": 1048676
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Internal.NonCapturingTimer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Internal${separator}NonCapturingTimer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048676)
        
        

        //--TRIMMABLE-BOUNDARY-START(65636)
        $asm.$cls(`$mefp.MEF.EmptyDisposable`, ($self) => class EmptyDisposable extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30064836708)
            /*EmptyDisposable*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30064836708)
            
            //--TRIMMABLE-BOUNDARY-START(12884967524)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967524);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967524)
            
            //--TRIMMABLE-BOUNDARY-START(17179934820)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17179934820)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12884967524)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967524)
            
            //--TRIMMABLE-BOUNDARY-START(8590000228)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(30064836708)
                    this.Instance = new $.$mefp.MEF.EmptyDisposable().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(30064836708)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000228)
            
            static $h = 65636;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064836708),
    {
      "p": 65636,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869412,
        "f": 50331681
      },
      "n": "Instance",
      "d": 65636,
      "h": 30064836708,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836708)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934820),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 65636,
      "h": 17179934820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934820)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967524),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65636,
      "h": 12884967524,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12884967524)
  ],
  "h": 65636
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}EmptyDisposable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65636)
        
        

        //--TRIMMABLE-BOUNDARY-START(262244)
        $asm.$cls(`$mefp.MEFP.Clock`, ($self) => class Clock extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475098724)
            /*Clock*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(21475098724)
            
            //--TRIMMABLE-BOUNDARY-START(8590196836)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196836);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196836)
            
            //--TRIMMABLE-BOUNDARY-START(25770066020)
            /*DateTime */ get UtcNow()
            {
                return $.$$.S.DateTime.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(25770066020)
            
            //--TRIMMABLE-BOUNDARY-START(8590393444)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.Physical.IClock.UtcNow.get
            get MEFP$IClock$UtcNow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UtcNow;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393444)
            
            //--TRIMMABLE-BOUNDARY-START(8590196836)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590196836)
            
            //--TRIMMABLE-BOUNDARY-START(4295229540)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098724)
                    this.Instance = new $.$mefp.MEFP.Clock().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21475098724)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229540)
            
            static $h = 262244;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770066020),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180131428,
        "f": 50331649
      },
      "n": "UtcNow",
      "d": 262244,
      "h": 25770066020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770066020)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475098724),
    {
      "t": 262244,
      "n": "Instance",
      "d": 262244,
      "h": 21475098724,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098724)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196836),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262244,
      "h": 8590196836,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590196836)
  ],
  "h": 262244
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.MEFP.IClock ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.Clock`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}Clock`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262244)
        
        

        //--TRIMMABLE-BOUNDARY-START(655460)
        $asm.$cls(`$mefp.MEFP.PhysicalFileInfo`, ($self) => class PhysicalFileInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622756)
            /*FileInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(4295622756)
            
            //--TRIMMABLE-BOUNDARY-START(8590590052)
            $ctor$1(/*FileInfo*/ info)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590052)
            
            //--TRIMMABLE-BOUNDARY-START(17180524644)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180524644)
            
            //--TRIMMABLE-BOUNDARY-START(81605034084)
            /*long */ get Length()
            {
                return this._info.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(81605034084)
            
            //--TRIMMABLE-BOUNDARY-START(90194968676)
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(90194968676)
            
            //--TRIMMABLE-BOUNDARY-START(85900001380)
            /*string */ get Name()
            {
                return this._info.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(85900001380)
            
            //--TRIMMABLE-BOUNDARY-START(77310066788)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.S.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            //--TRIMMABLE-BOUNDARY-END(77310066788)
            
            //--TRIMMABLE-BOUNDARY-START(73015099492)
            /*bool */ get IsDirectory()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(73015099492)
            
            //--TRIMMABLE-BOUNDARY-START(12885557348)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let bufferSize = 1;
                return new $.$$.SI.FileStream().$ctor$12(this.PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, bufferSize, 1073741824/*FileOptions.Asynchronous*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(12885557348)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get MEF$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get MEF$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get MEF$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get MEF$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get MEF$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get MEF$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            MEF$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            static $h = 655460;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524644),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770459236,
        "f": 50331649
      },
      "n": "Exists",
      "d": 655460,
      "h": 17180524644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524644),
//--TRIMMABLE-BOUNDARY-START(81605034084),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540263012,
        "f": 50331649
      },
      "n": "Length",
      "d": 655460,
      "h": 81605034084,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605034084),
//--TRIMMABLE-BOUNDARY-START(90194968676),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132196,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 655460,
      "h": 90194968676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194968676),
//--TRIMMABLE-BOUNDARY-START(85900001380),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197604,
        "f": 50331649
      },
      "n": "Name",
      "d": 655460,
      "h": 85900001380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900001380),
//--TRIMMABLE-BOUNDARY-START(77310066788),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328420,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 655460,
      "h": 77310066788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310066788),
//--TRIMMABLE-BOUNDARY-START(73015099492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393828,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 655460,
      "h": 73015099492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015099492)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885557348),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 655460,
      "h": 12885557348,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557348)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622756),
    {
      "t": 93454337,
      "n": "_info",
      "d": 655460,
      "h": 4295622756,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622756)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590052),
    {
      "p": [
        {
          "n": "info",
          "p": 93454337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655460,
      "h": 8590590052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590052)
  ],
  "h": 655460
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PhysicalFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655460)
        
        

        //--TRIMMABLE-BOUNDARY-START(720996)
        $asm.$cls(`$mefp.MEFP.PhysicalFilesWatcher`, ($self) => class PhysicalFilesWatcher extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688292)
            /*Action<object?>*/ static _cancelTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(4295688292)
            
            //--TRIMMABLE-BOUNDARY-START(90195034212)
            /*TimeSpan*/ static DefaultPollingInterval;
            //--TRIMMABLE-BOUNDARY-END(90195034212)
            
            //--TRIMMABLE-BOUNDARY-START(12885622884)
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _filePathTokenLookup = null;
            //--TRIMMABLE-BOUNDARY-END(12885622884)
            
            //--TRIMMABLE-BOUNDARY-START(51540328548)
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _wildcardTokenLookup = null;
            //--TRIMMABLE-BOUNDARY-END(51540328548)
            
            //--TRIMMABLE-BOUNDARY-START(17180590180)
            /*FileSystemWatcher?*/ _fileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(17180590180)
            
            //--TRIMMABLE-BOUNDARY-START(21475557476)
            /*object*/ _fileWatcherLock = null;
            //--TRIMMABLE-BOUNDARY-END(21475557476)
            
            //--TRIMMABLE-BOUNDARY-START(30065492068)
            /*string*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(30065492068)
            
            //--TRIMMABLE-BOUNDARY-START(25770524772)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(25770524772)
            
            //--TRIMMABLE-BOUNDARY-START(34360459364)
            /*Timer?*/ _timer = null;
            //--TRIMMABLE-BOUNDARY-END(34360459364)
            
            //--TRIMMABLE-BOUNDARY-START(42950393956)
            /*bool*/ _timerInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(42950393956)
            
            //--TRIMMABLE-BOUNDARY-START(47245361252)
            /*object*/ _timerLock = null;
            //--TRIMMABLE-BOUNDARY-END(47245361252)
            
            //--TRIMMABLE-BOUNDARY-START(38655426660)
            /*Func<Timer>*/ _timerFactory = null;
            //--TRIMMABLE-BOUNDARY-END(38655426660)
            
            //--TRIMMABLE-BOUNDARY-START(8590655588)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(8590655588)
            
            //--TRIMMABLE-BOUNDARY-START(77310132324)
            $ctor$2(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges)
            {
                this.$ctor$1(root, fileSystemWatcher, pollForChanges, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310132324);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132324)
            
            //--TRIMMABLE-BOUNDARY-START(73015165028)
            $ctor$1(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015165028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (fileSystemWatcher === null && !pollForChanges)
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$18("fileSystemWatcher", $.$mefp.S.SR.Error_FileSystemWatcherRequiredWithoutPolling);
                    }
                    this._root = root;
                    if (fileSystemWatcher !== null)
                    {
                        if ($.$$.S.OperatingSystem.IsBrowser() || $.$$.S.OperatingSystem.IsWasi() || ($.$$.S.OperatingSystem.IsIOS() && !$.$$.S.OperatingSystem.IsMacCatalyst()) || $.$$.S.OperatingSystem.IsTvOS())
                        {
                            throw new $.$$.S.PlatformNotSupportedException().$ctor$16($.$mefp.S.SR.Format$6($.$mefp.S.SR.FileSystemWatcher_PlatformNotSupported, $.$sifw.SI.FileSystemWatcher.$type));
                        }
                        this._fileWatcher = fileSystemWatcher;
                        this._fileWatcher.IncludeSubdirectories = true;
                        this._fileWatcher.add_Created(new $.$sifw.SI.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Changed(new $.$sifw.SI.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Renamed(new $.$sifw.SI.RenamedEventHandler().$ctor(this, this.OnRenamed));
                        this._fileWatcher.add_Deleted(new $.$sifw.SI.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Error(new $.$sifw.SI.ErrorEventHandler().$ctor(this, this.OnError));
                    }
                    this.PollForChanges = pollForChanges;
                    this._filters = filters;
                    this.PollingChangeTokens = new ($.$scc.SCC.ConcurrentDictionary$$$($.$mefp.MEF.IPollingChangeToken, $.$mefp.MEF.IPollingChangeToken))().$ctor$1();
                    this._timerFactory = new ($.$$.S.Func$$($.$$.ST$1.Timer))().$ctor(this,  () =>
                    {
                        return $.$mefp.MEI.NonCapturingTimer.Create(new $.$$.ST$1.TimerCallback().$ctor($.$mefp.MEFP.PhysicalFilesWatcher, $.$mefp.MEFP.PhysicalFilesWatcher.RaiseChangeEvents), this.PollingChangeTokens, $.$$.S.TimeSpan.Zero, $.$mefp.MEFP.PhysicalFilesWatcher.DefaultPollingInterval);
                    }, $uKuZca ??= {"r":183762945,"n":"","d":720996,"h":0,"f":17825794});
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015165028)
            
            //--TRIMMABLE-BOUNDARY-START(167504445540)
            /*bool*/ PollForChanges = false;
            //--TRIMMABLE-BOUNDARY-END(167504445540)
            
            //--TRIMMABLE-BOUNDARY-START(201864183908)
            /*bool*/ UseActivePolling = false;
            //--TRIMMABLE-BOUNDARY-END(201864183908)
            
            //--TRIMMABLE-BOUNDARY-START(171799412836)
            /*ConcurrentDictionary<IPollingChangeToken, IPollingChangeToken>*/ PollingChangeTokens = null;
            //--TRIMMABLE-BOUNDARY-END(171799412836)
            
            //--TRIMMABLE-BOUNDARY-START(85900066916)
            /*IChangeToken */ CreateFileChangeToken(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(filter, "filter");
                filter = $.$mefp.MEFP.PhysicalFilesWatcher.NormalizePath(filter);
                if ($.$$.SI.Path.IsPathRooted$1(filter) || $.$mefp.MEFPI.PathUtils.PathNavigatesAboveRoot(filter))
                {
                    return $.$mefa.MEF.NullChangeToken.Singleton;
                }
                /*IChangeToken*/ let changeToken = this.GetOrAddChangeToken(filter);
                this.TryEnableFileSystemWatcher();
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066916)
            
            //--TRIMMABLE-BOUNDARY-START(128849739876)
            /*IChangeToken */ GetOrAddChangeToken(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849739876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.UseActivePolling)
                {
                    $.$$.ST$1.LazyInitializer.EnsureInitialized($.$$.ST$1.Timer, $.$ref(() => this._timer, ($v) => this._timer = $v, $.$$.ST$1.Timer), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._timerInitialized, ($v) => this._timerInitialized = $v, null, true), $.$ref(() => this._timerLock, ($v) => this._timerLock = $v, $.$$.S.Object), this._timerFactory);
                }
                /*IChangeToken*/ let changeToken;
                /*bool*/ let isWildCard = pattern.includes("*");
                if (isWildCard || $.$mefp.MEFP.PhysicalFilesWatcher.IsDirectoryPath(pattern))
                {
                    changeToken = this.GetOrAddWildcardChangeToken(pattern);
                }
                else 
                {
                    changeToken = this.GetOrAddFilePathChangeToken(pattern);
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(128849739876)
            
            //--TRIMMABLE-BOUNDARY-START(133144707172)
            /*IChangeToken */ GetOrAddFilePathChangeToken(/*string*/ filePath)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._filePathTokenLookup.TryGetValue(filePath, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.MEP.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    tokenInfo = new $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$4(cancellationTokenSource, cancellationChangeToken);
                    tokenInfo = this._filePathTokenLookup.GetOrAdd$1(filePath, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.MEFP.PollingFileChangeToken().$ctor$1(new $.$$.SI.FileInfo().$ctor$6($.$$.SI.Path.Combine$3(this._root, filePath)));
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.MEP.CompositeChangeToken().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mep.MEP.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(133144707172)
            
            //--TRIMMABLE-BOUNDARY-START(137439674468)
            /*IChangeToken */ GetOrAddWildcardChangeToken(/*string*/ pattern)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._wildcardTokenLookup.TryGetValue(pattern, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.MEP.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    /*var*/ let matcher = new $.$mef.MEF.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    matcher.AddInclude(pattern);
                    tokenInfo = new $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$3(cancellationTokenSource, cancellationChangeToken, matcher);
                    tokenInfo = this._wildcardTokenLookup.GetOrAdd$1(pattern, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.MEFP.PollingWildCardChangeToken().$ctor$2(this._root, pattern);
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.MEP.CompositeChangeToken().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$mep.MEP.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            //--TRIMMABLE-BOUNDARY-END(137439674468)
            
            //--TRIMMABLE-BOUNDARY-START(94490001508)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(94490001508)
            
            //--TRIMMABLE-BOUNDARY-START(98784968804)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                        this._timer?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784968804)
            
            //--TRIMMABLE-BOUNDARY-START(163209478244)
            /*void */ OnRenamed(/*object*/ sender, /*RenamedEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209478244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFileSystemEntryChange(e.OldFullPath);
                this.OnFileSystemEntryChange(e.FullPath);
                if ($.$$.SI.Directory.Exists(e.FullPath))
                {
                    try
                    {
                        let $en6 = $.$$.SI.Directory.EnumerateFileSystemEntries$1(e.FullPath, "*", 1/*SearchOption.AllDirectories*/).SCG$IEnumerable$$$GetEnumerator();
                        while ($en6.SC$1$IEnumerator$MoveNext())
                        {
                            let newLocation = $en6.SCG$IEnumerator$$$Current;
                            {
                                /*string*/ let oldLocation = $.$$.SI.Path.Combine$3(e.OldFullPath, newLocation.slice(((e.FullPath.length + 1) | 0)));
                                this.OnFileSystemEntryChange(oldLocation);
                                this.OnFileSystemEntryChange(newLocation);
                            }
                        }
                    }
                    catch(ex)
                    {
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209478244)
            
            //--TRIMMABLE-BOUNDARY-START(150324576356)
            /*void */ OnChanged(/*object*/ sender, /*FileSystemEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnFileSystemEntryChange(e.FullPath);
            }
            //--TRIMMABLE-BOUNDARY-END(150324576356)
            
            //--TRIMMABLE-BOUNDARY-START(154619543652)
            /*void */ OnError(/*object*/ sender, /*ErrorEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619543652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en7 = this._filePathTokenLookup.Keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en7.SC$1$IEnumerator$MoveNext())
                {
                    let path = $en7.SCG$IEnumerator$$$Current;
                    {
                        this.ReportChangeForMatchedEntries(path);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619543652)
            
            //--TRIMMABLE-BOUNDARY-START(158914510948)
            /*void */ OnFileSystemEntryChange(/*string*/ fullPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let fileSystemInfo = new $.$$.SI.FileInfo().$ctor$6(fullPath);
                    if ($.$mefp.MEFP.FileSystemInfoHelper.IsExcluded(fileSystemInfo, this._filters))
                    {
                        return;
                    }
                    /*string*/ let relativePath = fullPath.slice(this._root.length);
                    this.ReportChangeForMatchedEntries(relativePath);
                }
                catch(ex)
                {
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914510948)
            
            //--TRIMMABLE-BOUNDARY-START(180389347428)
            /*void */ ReportChangeForMatchedEntries(/*string*/ path)
            {
                /*ChangeTokenInfo*/ let matchInfo;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(path))
                {
                    return;
                }
                path = $.$mefp.MEFP.PhysicalFilesWatcher.NormalizePath(path);
                /*bool*/ let matched = false;
                if (this._filePathTokenLookup.TryRemove$1(path, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    $.$mefp.MEFP.PhysicalFilesWatcher.CancelToken(matchInfo);
                    matched = true;
                }
                let $en9 = this._wildcardTokenLookup.GetEnumerator();
                while ($en9.SC$1$IEnumerator$MoveNext())
                {
                    let wildCardEntry = $en9.SCG$IEnumerator$$$Current;
                    {
                        /*PatternMatchingResult*/ let matchResult = $.$mef.MEF.MatcherExtensions.Match$3(wildCardEntry.Value.Matcher, path);
                        if (matchResult.HasMatches && this._wildcardTokenLookup.TryRemove$1(wildCardEntry.Key, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo)))
                        {
                            $.$mefp.MEFP.PhysicalFilesWatcher.CancelToken(matchInfo);
                            matched = true;
                        }
                    }
                }
                if (matched)
                {
                    this.TryDisableFileSystemWatcher();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389347428)
            
            //--TRIMMABLE-BOUNDARY-START(193274249316)
            /*void */ TryDisableFileSystemWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274249316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    //lock(_fileWatcherLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if (this._filePathTokenLookup.IsEmpty && this._wildcardTokenLookup.IsEmpty && this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274249316)
            
            //--TRIMMABLE-BOUNDARY-START(197569216612)
            /*void */ TryEnableFileSystemWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    //lock(_fileWatcherLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if ((!this._filePathTokenLookup.IsEmpty || !this._wildcardTokenLookup.IsEmpty) && !this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569216612)
            
            //--TRIMMABLE-BOUNDARY-START(146029609060)
            static /*string */ NormalizePath(/*string*/ filter)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029609060);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.String.Replace.call(filter, /*\\*/ 92, /*/*/ 47);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029609060)
            
            //--TRIMMABLE-BOUNDARY-START(141734641764)
            static /*bool */ IsDirectoryPath(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return path.length > 0 && ($.$$.S.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.SI.Path.DirectorySeparatorChar || $.$$.S.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.SI.Path.AltDirectorySeparatorChar);
            }
            //--TRIMMABLE-BOUNDARY-END(141734641764)
            
            //--TRIMMABLE-BOUNDARY-START(81605099620)
            static /*void */ CancelToken(/*ChangeTokenInfo*/ matchInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (matchInfo.TokenSource.IsCancellationRequested)
                {
                    return;
                }
                $.$$.STT.Task.Factory.StartNew$4($.$mefp.MEFP.PhysicalFilesWatcher._cancelTokenSource, matchInfo.TokenSource, $.$$.ST$1.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.STT.TaskScheduler.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(81605099620)
            
            //--TRIMMABLE-BOUNDARY-START(176094380132)
            static /*void */ RaiseChangeEvents(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(state !== null, "state != null");
                /*var*/ let changeTokens = $.$cast(state, $.$scc.SCC.ConcurrentDictionary$$$($.$mefp.MEF.IPollingChangeToken, $.$mefp.MEF.IPollingChangeToken));
                let $en11 = changeTokens.GetEnumerator();
                while ($en11.SC$1$IEnumerator$MoveNext())
                {
                    let item = $en11.SCG$IEnumerator$$$Current;
                    {
                        /*IPollingChangeToken*/ let token = item.Key;
                        if (!token.MEP$IChangeToken$HasChanged)
                        {
                            continue;
                        }
                        if (!changeTokens.TryRemove$1(token, $.$discardRef()))
                        {
                            continue;
                        }
                        try
                        {
                            token.MEF$IPollingChangeToken$CancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094380132)
            
            //--TRIMMABLE-BOUNDARY-START(786532)
            static $_ChangeTokenInfo;
            static get ChangeTokenInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mefp.MEFP.PhysicalFilesWatcher;
                return $cls.$_ChangeTokenInfo ??= $asm.$nstr(`$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo`, ($self) => class ChangeTokenInfo extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25770590308)
                    $ctor$4(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken)
                    {
                        this.$ctor$3(tokenSource, changeToken, null);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770590308);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590308)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475623012)
                    $ctor$3(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken, /*Matcher?*/ matcher)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475623012);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.TokenSource = tokenSource;
                            this.ChangeToken = changeToken;
                            this.Matcher = matcher;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475623012)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425295972)
                    /*CancellationTokenSource*/ TokenSource = null;
                    //--TRIMMABLE-BOUNDARY-END(64425295972)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065557604)
                    /*CancellationChangeToken*/ ChangeToken = null;
                    //--TRIMMABLE-BOUNDARY-END(30065557604)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130328676)
                    /*Matcher?*/ Matcher = null;
                    //--TRIMMABLE-BOUNDARY-END(60130328676)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655716)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655716);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655716)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655716)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655716)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TokenSource = this.TokenSource;
                        copy.ChangeToken = this.ChangeToken;
                        copy.Matcher = this.Matcher;
                        return copy;
                    }
                    static $h = 786532;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425295972),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361380,
        "f": 50331649
      },
      "n": "TokenSource",
      "d": 786532,
      "h": 64425295972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425295972),
//--TRIMMABLE-BOUNDARY-START(30065557604),
    {
      "p": 196693,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492196,
        "f": 50331649
      },
      "n": "ChangeToken",
      "d": 786532,
      "h": 30065557604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065557604),
//--TRIMMABLE-BOUNDARY-START(60130328676),
    {
      "p": 2424933,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426788,
        "f": 50331649
      },
      "n": "Matcher",
      "d": 786532,
      "h": 60130328676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130328676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590308),
    {
      "p": [
        {
          "n": "tokenSource",
          "p": 170983425
        },
        {
          "n": "changeToken",
          "p": 196693
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786532,
      "h": 25770590308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590308),
//--TRIMMABLE-BOUNDARY-START(21475623012),
    {
      "p": [
        {
          "n": "tokenSource",
          "p": 170983425
        },
        {
          "n": "changeToken",
          "p": 196693
        },
        {
          "n": "matcher",
          "p": 2424933
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786532,
      "h": 21475623012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623012),
//--TRIMMABLE-BOUNDARY-START(17180655716),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786532,
      "h": 17180655716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655716)
  ],
  "d": 720996,
  "h": 786532
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher+ChangeTokenInfo`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PhysicalFilesWatcher${separator}ChangeTokenInfo`; }
                }, $cls, ($v) => $cls.$_ChangeTokenInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786532)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885622884)
                this._filePathTokenLookup = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.S.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(12885622884)
                
                //--TRIMMABLE-BOUNDARY-START(51540328548)
                this._wildcardTokenLookup = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.S.StringComparer.OrdinalIgnoreCase);
                //--TRIMMABLE-BOUNDARY-END(51540328548)
                
                //--TRIMMABLE-BOUNDARY-START(21475557476)
                this._fileWatcherLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(21475557476)
                
                //--TRIMMABLE-BOUNDARY-START(47245361252)
                this._timerLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(47245361252)
                
            }
            //--TRIMMABLE-BOUNDARY-START(68720197732)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688292)
                    this._cancelTokenSource = new ($.$$.S.Action$$($.$$.S.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$$.ST$1.CancellationTokenSource)).Cancel();
                    }, $BLlLui ??= {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":720996,"h":0,"f":17825794});
                    //--TRIMMABLE-BOUNDARY-END(4295688292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034212)
                    this.DefaultPollingInterval = $.$$.S.TimeSpan.FromSeconds$2(4n);
                    //--TRIMMABLE-BOUNDARY-END(90195034212)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720197732)
            
            static $h = 720996;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(167504445540),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903396,
        "f": 50331656
      },
      "n": "PollForChanges",
      "d": 720996,
      "h": 167504445540,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(167504445540),
//--TRIMMABLE-BOUNDARY-START(201864183908),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554772580,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979282020,
        "f": 83886088
      },
      "n": "UseActivePolling",
      "d": 720996,
      "h": 201864183908,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(201864183908),
//--TRIMMABLE-BOUNDARY-START(171799412836),
    {
      "p": $.$scc.SCC.ConcurrentDictionary$$$($.$mefp.MEF.IPollingChangeToken, $.$mefp.MEF.IPollingChangeToken).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837988,
        "f": 50331656
      },
      "n": "PollingChangeTokens",
      "d": 720996,
      "h": 171799412836,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(171799412836)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900066916),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "CreateFileChangeToken",
      "d": 720996,
      "h": 85900066916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900066916),
//--TRIMMABLE-BOUNDARY-START(128849739876),
    {
      "r": 720981,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "GetOrAddChangeToken",
      "d": 720996,
      "h": 128849739876,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849739876),
//--TRIMMABLE-BOUNDARY-START(133144707172),
    {
      "r": 720981,
      "p": [
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": "GetOrAddFilePathChangeToken",
      "d": 720996,
      "h": 133144707172,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(133144707172),
//--TRIMMABLE-BOUNDARY-START(137439674468),
    {
      "r": 720981,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "GetOrAddWildcardChangeToken",
      "d": 720996,
      "h": 137439674468,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(137439674468),
//--TRIMMABLE-BOUNDARY-START(94490001508),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 720996,
      "h": 94490001508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490001508),
//--TRIMMABLE-BOUNDARY-START(98784968804),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 720996,
      "h": 98784968804,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(98784968804),
//--TRIMMABLE-BOUNDARY-START(163209478244),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 524370
        }
      ],
      "n": "OnRenamed",
      "d": 720996,
      "h": 163209478244,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(163209478244),
//--TRIMMABLE-BOUNDARY-START(150324576356),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 196690
        }
      ],
      "n": "OnChanged",
      "d": 720996,
      "h": 150324576356,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324576356),
//--TRIMMABLE-BOUNDARY-START(154619543652),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 65618
        }
      ],
      "n": "OnError",
      "d": 720996,
      "h": 154619543652,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154619543652),
//--TRIMMABLE-BOUNDARY-START(158914510948),
    {
      "r": 65537,
      "p": [
        {
          "n": "fullPath",
          "p": 1310721
        }
      ],
      "n": "OnFileSystemEntryChange",
      "d": 720996,
      "h": 158914510948,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158914510948),
//--TRIMMABLE-BOUNDARY-START(180389347428),
    {
      "r": 65537,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "ReportChangeForMatchedEntries",
      "d": 720996,
      "h": 180389347428,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(180389347428),
//--TRIMMABLE-BOUNDARY-START(193274249316),
    {
      "r": 65537,
      "n": "TryDisableFileSystemWatcher",
      "d": 720996,
      "h": 193274249316,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274249316),
//--TRIMMABLE-BOUNDARY-START(197569216612),
    {
      "r": 65537,
      "n": "TryEnableFileSystemWatcher",
      "d": 720996,
      "h": 197569216612,
      "f": 16777218,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "wasi",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569216612),
//--TRIMMABLE-BOUNDARY-START(146029609060),
    {
      "r": 1310721,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "NormalizePath",
      "d": 720996,
      "h": 146029609060,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(146029609060),
//--TRIMMABLE-BOUNDARY-START(141734641764),
    {
      "r": 262145,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "IsDirectoryPath",
      "d": 720996,
      "h": 141734641764,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141734641764),
//--TRIMMABLE-BOUNDARY-START(81605099620),
    {
      "r": 65537,
      "p": [
        {
          "n": "matchInfo",
          "p": 786532
        }
      ],
      "n": "CancelToken",
      "d": 720996,
      "h": 81605099620,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81605099620),
//--TRIMMABLE-BOUNDARY-START(176094380132),
    {
      "r": 65537,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RaiseChangeEvents",
      "d": 720996,
      "h": 176094380132,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(176094380132)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688292),
    {
      "t": $.$$.S.Action$$($.$$.S.Object).$h,
      "n": "_cancelTokenSource",
      "d": 720996,
      "h": 4295688292,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295688292),
//--TRIMMABLE-BOUNDARY-START(90195034212),
    {
      "t": 186646529,
      "n": "DefaultPollingInterval",
      "d": 720996,
      "h": 90195034212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195034212),
//--TRIMMABLE-BOUNDARY-START(12885622884),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo).$h,
      "n": "_filePathTokenLookup",
      "d": 720996,
      "h": 12885622884,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622884),
//--TRIMMABLE-BOUNDARY-START(51540328548),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo).$h,
      "n": "_wildcardTokenLookup",
      "d": 720996,
      "h": 51540328548,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51540328548),
//--TRIMMABLE-BOUNDARY-START(17180590180),
    {
      "t": 327762,
      "n": "_fileWatcher",
      "d": 720996,
      "h": 17180590180,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590180),
//--TRIMMABLE-BOUNDARY-START(21475557476),
    {
      "t": 131073,
      "n": "_fileWatcherLock",
      "d": 720996,
      "h": 21475557476,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557476),
//--TRIMMABLE-BOUNDARY-START(30065492068),
    {
      "t": 1310721,
      "n": "_root",
      "d": 720996,
      "h": 30065492068,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065492068),
//--TRIMMABLE-BOUNDARY-START(25770524772),
    {
      "t": 327780,
      "n": "_filters",
      "d": 720996,
      "h": 25770524772,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524772),
//--TRIMMABLE-BOUNDARY-START(34360459364),
    {
      "t": 183762945,
      "n": "_timer",
      "d": 720996,
      "h": 34360459364,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360459364),
//--TRIMMABLE-BOUNDARY-START(42950393956),
    {
      "t": 262145,
      "n": "_timerInitialized",
      "d": 720996,
      "h": 42950393956,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950393956),
//--TRIMMABLE-BOUNDARY-START(47245361252),
    {
      "t": 131073,
      "n": "_timerLock",
      "d": 720996,
      "h": 47245361252,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47245361252),
//--TRIMMABLE-BOUNDARY-START(38655426660),
    {
      "t": $.$$.S.Func$$($.$$.ST$1.Timer).$h,
      "n": "_timerFactory",
      "d": 720996,
      "h": 38655426660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655426660),
//--TRIMMABLE-BOUNDARY-START(8590655588),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 720996,
      "h": 8590655588,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655588)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77310132324),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "fileSystemWatcher",
          "p": 327762
        },
        {
          "n": "pollForChanges",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720996,
      "h": 77310132324,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310132324),
//--TRIMMABLE-BOUNDARY-START(73015165028),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "fileSystemWatcher",
          "p": 327762
        },
        {
          "n": "pollForChanges",
          "p": 262145
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720996,
      "h": 73015165028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015165028)
  ],
  "h": 720996
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mefp.MEFP.PhysicalFilesWatcher.ChangeTokenInfo ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PhysicalFilesWatcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720996)
        
        

        //--TRIMMABLE-BOUNDARY-START(852068)
        $asm.$cls(`$mefp.MEFP.PollingFileChangeToken`, ($self) => class PollingFileChangeToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590786660)
            /*FileInfo*/ _fileInfo = null;
            //--TRIMMABLE-BOUNDARY-END(8590786660)
            
            //--TRIMMABLE-BOUNDARY-START(21475688548)
            /*DateTime*/ _previousWriteTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(21475688548)
            
            //--TRIMMABLE-BOUNDARY-START(17180721252)
            /*DateTime*/ _lastCheckedTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(17180721252)
            
            //--TRIMMABLE-BOUNDARY-START(12885753956)
            /*bool*/ _hasChanged = false;
            //--TRIMMABLE-BOUNDARY-END(12885753956)
            
            //--TRIMMABLE-BOUNDARY-START(25770655844)
            /*CancellationTokenSource?*/ _tokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(25770655844)
            
            //--TRIMMABLE-BOUNDARY-START(4295819364)
            /*CancellationChangeToken?*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(4295819364)
            
            //--TRIMMABLE-BOUNDARY-START(42950525028)
            $ctor$1(/*FileInfo*/ fileInfo)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950525028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._fileInfo = fileInfo;
                    this._previousWriteTimeUtc = this.GetLastWriteTimeUtc();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950525028)
            
            //--TRIMMABLE-BOUNDARY-START(111670001764)
            /*TimeSpan*/ static PollingInterval;
            //--TRIMMABLE-BOUNDARY-END(111670001764)
            
            //--TRIMMABLE-BOUNDARY-START(90195165284)
            /*DateTime */ GetLastWriteTimeUtc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._fileInfo.Refresh();
                if (!this._fileInfo.Exists)
                {
                    return $.$$.S.DateTime.MinValue;
                }
                return $.$mefp.MEFP.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(this._fileInfo) ?? this._fileInfo.LastWriteTimeUtc;
            }
            //--TRIMMABLE-BOUNDARY-END(90195165284)
            
            //--TRIMMABLE-BOUNDARY-START(47245492324)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(47245492324)
            
            //--TRIMMABLE-BOUNDARY-START(51540459620)
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.MEP.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(51540459620)
            
            //--TRIMMABLE-BOUNDARY-START(98785099876)
            /*CancellationTokenSource? */ get MEF$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099876)
            
            //--TRIMMABLE-BOUNDARY-START(94490132580)
            /*bool */ get HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._hasChanged)
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let currentTime = $.$$.S.DateTime.UtcNow;
                if ($.$$.S.TimeSpan.op_LessThan($.$$.S.DateTime.op_Subtraction$1(currentTime, this._lastCheckedTimeUtc), $.$mefp.MEFP.PollingFileChangeToken.PollingInterval))
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteTimeUtc();
                if ($.$$.S.DateTime.op_Inequality(this._previousWriteTimeUtc, lastWriteTimeUtc))
                {
                    this._previousWriteTimeUtc = lastWriteTimeUtc;
                    this._hasChanged = true;
                }
                this._lastCheckedTimeUtc = currentTime;
                return this._hasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132580)
            
            //--TRIMMABLE-BOUNDARY-START(115964969060)
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.MEF.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(115964969060)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //--TRIMMABLE-BOUNDARY-START(30065492053)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            MEP$IChangeToken$RegisterChangeCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RegisterChangeCallback(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492053)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475688548)
                this._previousWriteTimeUtc = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475688548)
                
                //--TRIMMABLE-BOUNDARY-START(17180721252)
                this._lastCheckedTimeUtc = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(17180721252)
                
            }
            //--TRIMMABLE-BOUNDARY-START(38655557732)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(111670001764)
                    this.PollingInterval = $.$mefp.MEFP.PhysicalFilesWatcher.DefaultPollingInterval;
                    //--TRIMMABLE-BOUNDARY-END(111670001764)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557732)
            
            static $h = 852068;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(111670001764),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900197988,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734772836,
        "f": 83886120
      },
      "n": "PollingInterval",
      "d": 852068,
      "h": 111670001764,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(111670001764),
//--TRIMMABLE-BOUNDARY-START(47245492324),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394212,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554903652,
        "f": 83886088
      },
      "n": "ActiveChangeCallbacks",
      "d": 852068,
      "h": 47245492324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245492324),
//--TRIMMABLE-BOUNDARY-START(51540459620),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328804,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144838244,
        "f": 83886088
      },
      "n": "CancellationTokenSource",
      "d": 852068,
      "h": 51540459620,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51540459620),
//--TRIMMABLE-BOUNDARY-START(98785099876),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375034468,
        "f": 50331650
      },
      "n": "{196708}.CancellationTokenSource",
      "o": "MEF$IPollingChangeToken$CancellationTokenSource",
      "d": 852068,
      "h": 98785099876,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(98785099876),
//--TRIMMABLE-BOUNDARY-START(94490132580),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263396,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 852068,
      "h": 94490132580,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490132580)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90195165284),
    {
      "r": 65994753,
      "n": "GetLastWriteTimeUtc",
      "d": 852068,
      "h": 90195165284,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195165284),
//--TRIMMABLE-BOUNDARY-START(115964969060),
    {
      "r": 91095041,
      "p": [
        {
          "n": "callback",
          "p": $.$$.S.Action$$($.$$.S.Object).$h
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "RegisterChangeCallback",
      "d": 852068,
      "h": 115964969060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964969060)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786660),
    {
      "t": 93454337,
      "n": "_fileInfo",
      "d": 852068,
      "h": 8590786660,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786660),
//--TRIMMABLE-BOUNDARY-START(21475688548),
    {
      "t": 65994753,
      "n": "_previousWriteTimeUtc",
      "d": 852068,
      "h": 21475688548,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688548),
//--TRIMMABLE-BOUNDARY-START(17180721252),
    {
      "t": 65994753,
      "n": "_lastCheckedTimeUtc",
      "d": 852068,
      "h": 17180721252,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721252),
//--TRIMMABLE-BOUNDARY-START(12885753956),
    {
      "t": 262145,
      "n": "_hasChanged",
      "d": 852068,
      "h": 12885753956,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753956),
//--TRIMMABLE-BOUNDARY-START(25770655844),
    {
      "t": 170983425,
      "n": "_tokenSource",
      "d": 852068,
      "h": 25770655844,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655844),
//--TRIMMABLE-BOUNDARY-START(4295819364),
    {
      "t": 196693,
      "n": "_changeToken",
      "d": 852068,
      "h": 4295819364,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819364)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950525028),
    {
      "p": [
        {
          "n": "fileInfo",
          "p": 93454337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852068,
      "h": 42950525028,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950525028)
  ],
  "h": 852068
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.MEF.IPollingChangeToken, $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PollingFileChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852068)
        
        

        //--TRIMMABLE-BOUNDARY-START(917604)
        $asm.$cls(`$mefp.MEFP.PollingWildCardChangeToken`, ($self) => class PollingWildCardChangeToken extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180786788)
            /*object*/ _enumerationLock = null;
            //--TRIMMABLE-BOUNDARY-END(17180786788)
            
            //--TRIMMABLE-BOUNDARY-START(12885819492)
            /*DirectoryInfoBase*/ _directoryInfo = null;
            //--TRIMMABLE-BOUNDARY-END(12885819492)
            
            //--TRIMMABLE-BOUNDARY-START(25770721380)
            /*Matcher*/ _matcher = null;
            //--TRIMMABLE-BOUNDARY-END(25770721380)
            
            //--TRIMMABLE-BOUNDARY-START(4295884900)
            /*bool*/ _changed = false;
            //--TRIMMABLE-BOUNDARY-END(4295884900)
            
            //--TRIMMABLE-BOUNDARY-START(21475754084)
            /*DateTime*/ _lastScanTimeUtc;
            //--TRIMMABLE-BOUNDARY-END(21475754084)
            
            //--TRIMMABLE-BOUNDARY-START(30065688676)
            /*byte[]?*/ _previousHash = null;
            //--TRIMMABLE-BOUNDARY-END(30065688676)
            
            //--TRIMMABLE-BOUNDARY-START(34360655972)
            /*CancellationTokenSource?*/ _tokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(34360655972)
            
            //--TRIMMABLE-BOUNDARY-START(8590852196)
            /*CancellationChangeToken?*/ _changeToken = null;
            //--TRIMMABLE-BOUNDARY-END(8590852196)
            
            //--TRIMMABLE-BOUNDARY-START(55835492452)
            $ctor$2(/*string*/ root, /*string*/ pattern)
            {
                this.$ctor$1(new $.$mef.MEFA.DirectoryInfoWrapper().$ctor$4(new $.$$.SI.DirectoryInfo().$ctor$5(root)), pattern, $.$mefp.MEFP.Clock.Instance);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835492452);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492452)
            
            //--TRIMMABLE-BOUNDARY-START(51540525156)
            $ctor$1(/*DirectoryInfoBase*/ directoryInfo, /*string*/ pattern, /*IClock*/ clock)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540525156);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._directoryInfo = directoryInfo;
                    this.Clock = clock;
                    this._matcher = new $.$mef.MEF.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    this._matcher.AddInclude(pattern);
                    this.CalculateChanges();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540525156)
            
            //--TRIMMABLE-BOUNDARY-START(60130459748)
            /*bool*/ ActiveChangeCallbacks = false;
            //--TRIMMABLE-BOUNDARY-END(60130459748)
            
            //--TRIMMABLE-BOUNDARY-START(150324772964)
            /*TimeSpan*/ PollingInterval;
            //--TRIMMABLE-BOUNDARY-END(150324772964)
            
            //--TRIMMABLE-BOUNDARY-START(68720394340)
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490198116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504642148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.MEP.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            //--TRIMMABLE-BOUNDARY-END(68720394340)
            
            //--TRIMMABLE-BOUNDARY-START(133144903780)
            /*CancellationTokenSource? */ get MEF$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            //--TRIMMABLE-BOUNDARY-END(133144903780)
            
            //--TRIMMABLE-BOUNDARY-START(73015361636)
            /*IClock*/ Clock = null;
            //--TRIMMABLE-BOUNDARY-END(73015361636)
            
            //--TRIMMABLE-BOUNDARY-START(128849936484)
            /*bool */ get HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670067300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._changed)
                {
                    return true;
                }
                if (ShouldRefresh.call(this))
                {
                    //lock(_enumerationLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this._enumerationLock)
                        {
                            if (!this._changed && ShouldRefresh.call(this))
                            {
                                this._changed = this.CalculateChanges();
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this._enumerationLock)
                    }
                }
                return this._changed;
                /*bool*/  function ShouldRefresh()
                {
                    {
                        return $.$$.S.TimeSpan.op_GreaterThanOrEqual($.$$.S.DateTime.op_Subtraction$1(this.Clock.MEFP$IClock$UtcNow, this._lastScanTimeUtc), this.PollingInterval);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849936484)
            
            //--TRIMMABLE-BOUNDARY-START(64425427044)
            /*bool */ CalculateChanges()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425427044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PatternMatchingResult*/ let result = this._matcher.Execute(this._directoryInfo);
                /*IOrderedEnumerable<FilePatternMatch>*/ let files = $.$sl.SL.Enumerable.OrderBy($.$mef.MEF.FilePatternMatch, $.$$.S.String, result.Files, new ($.$$.S.Func$$$($.$mef.MEF.FilePatternMatch, $.$$.S.String))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Path;
                }, $wWKNfl ??= {"r":1310721,"p":[{"n":"f","p":393317}],"n":"","d":917604,"h":0,"f":17825794}), $.$$.S.StringComparer.Ordinal);
                let sha256 = null;
                try
                {
                    sha256 = $.$sscr.SSC.IncrementalHash.CreateHash($.$sscr.SSC.HashAlgorithmName.SHA256);
                    let $en1 = files.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let file = $en1.SCG$IEnumerator$$$Current;
                        {
                            /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteUtc(file.Path);
                            if (this._lastScanTimeUtc.Ticks !== 0n && $.$$.S.DateTime.op_LessThan(this._lastScanTimeUtc, lastWriteTimeUtc))
                            {
                                return true;
                            }
                            $.$mefp.MEFP.PollingWildCardChangeToken.ComputeHash(sha256, file.Path, lastWriteTimeUtc);
                        }
                    }
                    /*Span<byte>*/ let currentHash = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Byte, $.trunc(256 / 8), null);
                    sha256.GetHashAndReset$1(currentHash);
                    if (this._previousHash === null)
                    {
                        this._previousHash = currentHash.ToArray();
                    }
                    else if (!$.$$.S.MemoryExtensions.SequenceEqual$1($.$$.S.Byte, $.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Byte, this._previousHash)), $.$$.S.Span$$($.$$.S.Byte).op_Implicit(currentHash)))
                    {
                        return true;
                    }
                    this._lastScanTimeUtc = this.Clock.MEFP$IClock$UtcNow;
                }
                finally
                {
                    sha256?.S$IDisposable$Dispose();
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(64425427044)
            
            //--TRIMMABLE-BOUNDARY-START(124554969188)
            /*DateTime */ GetLastWriteUtc(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554969188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let filePath = $.$$.SI.Path.Combine$3(this._directoryInfo.FullName, path);
                return $.$mefp.MEFP.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc$1(filePath) ?? $.$$.SI.File.GetLastWriteTimeUtc$1(filePath);
            }
            //--TRIMMABLE-BOUNDARY-END(124554969188)
            
            //--TRIMMABLE-BOUNDARY-START(77310328932)
            static /*void */ ComputeHash(/*IncrementalHash*/ sha256, /*string*/ path, /*DateTime*/ lastChangedUtc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310328932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sha256.AppendData$2($.$$.SRI.MemoryMarshal.AsBytes($.$$.S.Char, $.$$.S.MemoryExtensions.AsSpan$4(path)));
                sha256.AppendData$2($.$$.SRI.MemoryMarshal.AsBytes($.$$.S.DateTime, $.$$.S.ReadOnlySpan$$($.$$.S.DateTime).op_Implicit$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.DateTime), [lastChangedUtc], null, null))));
            }
            //--TRIMMABLE-BOUNDARY-END(77310328932)
            
            //--TRIMMABLE-BOUNDARY-START(146029805668)
            /*IDisposable */ MEP$IChangeToken$RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029805668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.MEF.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //--TRIMMABLE-BOUNDARY-END(146029805668)
            
            //--TRIMMABLE-BOUNDARY-START(21475557461)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get MEP$IChangeToken$HasChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.HasChanged;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557461)
            
            //--TRIMMABLE-BOUNDARY-START(12885622869)
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get MEP$IChangeToken$ActiveChangeCallbacks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ActiveChangeCallbacks;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622869)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180786788)
                this._enumerationLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(17180786788)
                
                //--TRIMMABLE-BOUNDARY-START(21475754084)
                this._lastScanTimeUtc = $.$default($.$$.S.DateTime);
                //--TRIMMABLE-BOUNDARY-END(21475754084)
                
                //--TRIMMABLE-BOUNDARY-START(150324772964)
                this.PollingInterval = $.$mefp.MEFP.PhysicalFilesWatcher.DefaultPollingInterval;
                //--TRIMMABLE-BOUNDARY-END(150324772964)
                
            }
            static $h = 917604;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130459748),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900263524,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914707556,
        "f": 83886088
      },
      "n": "ActiveChangeCallbacks",
      "d": 917604,
      "h": 60130459748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459748),
//--TRIMMABLE-BOUNDARY-START(150324772964),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260001892,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094576740,
        "f": 83886088
      },
      "n": "PollingInterval",
      "d": 917604,
      "h": 150324772964,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(150324772964),
//--TRIMMABLE-BOUNDARY-START(68720394340),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490198116,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167504642148,
        "f": 83886088
      },
      "n": "CancellationTokenSource",
      "d": 917604,
      "h": 68720394340,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(68720394340),
//--TRIMMABLE-BOUNDARY-START(133144903780),
    {
      "p": 170983425,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734838372,
        "f": 50331650
      },
      "n": "{196708}.CancellationTokenSource",
      "o": "MEF$IPollingChangeToken$CancellationTokenSource",
      "d": 917604,
      "h": 133144903780,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133144903780),
//--TRIMMABLE-BOUNDARY-START(73015361636),
    {
      "p": 458852,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080132708,
        "f": 50331650
      },
      "n": "Clock",
      "d": 917604,
      "h": 73015361636,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(73015361636),
//--TRIMMABLE-BOUNDARY-START(128849936484),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670067300,
        "f": 50331649
      },
      "n": "HasChanged",
      "d": 917604,
      "h": 128849936484,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849936484)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425427044),
    {
      "r": 262145,
      "n": "CalculateChanges",
      "d": 917604,
      "h": 64425427044,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425427044),
//--TRIMMABLE-BOUNDARY-START(124554969188),
    {
      "r": 65994753,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetLastWriteUtc",
      "d": 917604,
      "h": 124554969188,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(124554969188),
//--TRIMMABLE-BOUNDARY-START(77310328932),
    {
      "r": 65537,
      "p": [
        {
          "n": "sha256",
          "p": 12386334
        },
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "lastChangedUtc",
          "p": 65994753
        }
      ],
      "n": "ComputeHash",
      "d": 917604,
      "h": 77310328932,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77310328932)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786788),
    {
      "t": 131073,
      "n": "_enumerationLock",
      "d": 917604,
      "h": 17180786788,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180786788),
//--TRIMMABLE-BOUNDARY-START(12885819492),
    {
      "t": 65637,
      "n": "_directoryInfo",
      "d": 917604,
      "h": 12885819492,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819492),
//--TRIMMABLE-BOUNDARY-START(25770721380),
    {
      "t": 2424933,
      "n": "_matcher",
      "d": 917604,
      "h": 25770721380,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770721380),
//--TRIMMABLE-BOUNDARY-START(4295884900),
    {
      "t": 262145,
      "n": "_changed",
      "d": 917604,
      "h": 4295884900,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884900),
//--TRIMMABLE-BOUNDARY-START(21475754084),
    {
      "t": 65994753,
      "n": "_lastScanTimeUtc",
      "d": 917604,
      "h": 21475754084,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475754084),
//--TRIMMABLE-BOUNDARY-START(30065688676),
    {
      "t": $.$typeArray($.$$.S.Byte).$h,
      "n": "_previousHash",
      "d": 917604,
      "h": 30065688676,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065688676),
//--TRIMMABLE-BOUNDARY-START(34360655972),
    {
      "t": 170983425,
      "n": "_tokenSource",
      "d": 917604,
      "h": 34360655972,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360655972),
//--TRIMMABLE-BOUNDARY-START(8590852196),
    {
      "t": 196693,
      "n": "_changeToken",
      "d": 917604,
      "h": 8590852196,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835492452),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917604,
      "h": 55835492452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835492452),
//--TRIMMABLE-BOUNDARY-START(51540525156),
    {
      "p": [
        {
          "n": "directoryInfo",
          "p": 65637
        },
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "clock",
          "p": 458852
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917604,
      "h": 51540525156,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540525156)
  ],
  "h": 917604
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.MEF.IPollingChangeToken, $.$mep.MEP.IChangeToken ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PollingWildCardChangeToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917604)
        
        

        //--TRIMMABLE-BOUNDARY-START(983140)
        $asm.$cls(`$mefp.MEF.PhysicalFileProvider`, ($self) => class PhysicalFileProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(128850002020)
            /*string*/ static PollingEnvironmentKey = null;
            //--TRIMMABLE-BOUNDARY-END(128850002020)
            
            //--TRIMMABLE-BOUNDARY-START(30065754212)
            /*char[]*/ static _pathSeparators = null;
            //--TRIMMABLE-BOUNDARY-END(30065754212)
            
            //--TRIMMABLE-BOUNDARY-START(25770786916)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(25770786916)
            
            //--TRIMMABLE-BOUNDARY-START(12885885028)
            /*Func<PhysicalFilesWatcher>*/ _fileWatcherFactory = null;
            //--TRIMMABLE-BOUNDARY-END(12885885028)
            
            //--TRIMMABLE-BOUNDARY-START(8590917732)
            /*PhysicalFilesWatcher?*/ _fileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(8590917732)
            
            //--TRIMMABLE-BOUNDARY-START(17180852324)
            /*bool*/ _fileWatcherInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(17180852324)
            
            //--TRIMMABLE-BOUNDARY-START(21475819620)
            /*object*/ _fileWatcherLock = null;
            //--TRIMMABLE-BOUNDARY-END(21475819620)
            
            //--TRIMMABLE-BOUNDARY-START(38655688804)
            /*bool?*/ _usePollingFileWatcher = null;
            //--TRIMMABLE-BOUNDARY-END(38655688804)
            
            //--TRIMMABLE-BOUNDARY-START(34360721508)
            /*bool?*/ _useActivePolling = null;
            //--TRIMMABLE-BOUNDARY-END(34360721508)
            
            //--TRIMMABLE-BOUNDARY-START(4295950436)
            /*bool*/ _disposed = false;
            //--TRIMMABLE-BOUNDARY-END(4295950436)
            
            //--TRIMMABLE-BOUNDARY-START(55835557988)
            $ctor$2(/*string*/ root)
            {
                this.$ctor$1(root, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835557988);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835557988)
            
            //--TRIMMABLE-BOUNDARY-START(51540590692)
            $ctor$1(/*string*/ root, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540590692);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.SI.Path.IsPathRooted$1(root))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13("The path must be absolute.", "root");
                    }
                    /*string*/ let fullRoot = $.$$.SI.Path.GetFullPath$1(root);
                    this.Root = $.$mefp.MEFPI.PathUtils.EnsureTrailingSlash(fullRoot);
                    if (!$.$$.SI.Directory.Exists(this.Root))
                    {
                        throw new $.$$.SI.DirectoryNotFoundException().$ctor$17(this.Root);
                    }
                    this._filters = filters;
                    this._fileWatcherFactory = new ($.$$.S.Func$$($.$mefp.MEFP.PhysicalFilesWatcher))().$ctor(this, this.CreateFileWatcher);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590692)
            
            //--TRIMMABLE-BOUNDARY-START(171799674980)
            /*bool */ get UsePollingFileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    return false;
                }
                if (this._usePollingFileWatcher === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return this._usePollingFileWatcher ?? false;
            }
            /*bool */ set UsePollingFileWatcher(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209740388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._fileWatcher !== null)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$mefp.S.SR.Format$6($.$mefp.S.SR.CannotModifyWhenFileWatcherInitialized, "UsePollingFileWatcher"));
                }
                this._usePollingFileWatcher = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171799674980)
            
            //--TRIMMABLE-BOUNDARY-START(167504707684)
            /*bool */ get UseActivePolling()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._useActivePolling === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return $.$$.S.Nullable$$($.$$.S.Boolean).Value$get.call(this._useActivePolling);
            }
            /*bool */ set UseActivePolling(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._useActivePolling = value;
            }
            //--TRIMMABLE-BOUNDARY-END(167504707684)
            
            //--TRIMMABLE-BOUNDARY-START(73015427172)
            /*PhysicalFilesWatcher */ get FileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.ST$1.LazyInitializer.EnsureInitialized($.$mefp.MEFP.PhysicalFilesWatcher, $.$ref(() => this._fileWatcher, ($v) => this._fileWatcher = $v, $.$mefp.MEFP.PhysicalFilesWatcher), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => this._fileWatcherInitialized, ($v) => this._fileWatcherInitialized = $v, null, true), $.$ref(() => this._fileWatcherLock, ($v) => this._fileWatcherLock = $v, $.$$.S.Object), this._fileWatcherFactory);
            }
            /*PhysicalFilesWatcher */ set FileWatcher(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!this._fileWatcherInitialized, "!_fileWatcherInitialized");
                this._fileWatcherInitialized = true;
                this._fileWatcher = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73015427172)
            
            //--TRIMMABLE-BOUNDARY-START(60130525284)
            /*PhysicalFilesWatcher */ CreateFileWatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let root = $.$mefp.MEFPI.PathUtils.EnsureTrailingSlash($.$$.SI.Path.GetFullPath$1(this.Root));
                /*FileSystemWatcher?*/ let watcher;
                if ($.$$.S.OperatingSystem.IsBrowser() || $.$$.S.OperatingSystem.IsWasi() || ($.$$.S.OperatingSystem.IsIOS() && !$.$$.S.OperatingSystem.IsMacCatalyst()) || $.$$.S.OperatingSystem.IsTvOS())
                {
                    this.UsePollingFileWatcher = true;
                    this.UseActivePolling = true;
                    watcher = null;
                }
                else 
                {
                    watcher = this.UsePollingFileWatcher && this.UseActivePolling ? null : new $.$sifw.SI.FileSystemWatcher().$ctor$5(root);
                }
                return (() =>
                {
                    //new $.$mefp.MEFP.PhysicalFilesWatcher()
                    const $t4 = $.$mefp.MEFP.PhysicalFilesWatcher;
                    const $i4 = new $t4();
                    $i4.$ctor$1(root, watcher, this.UsePollingFileWatcher, this._filters);
                    $i4.UseActivePolling = this.UseActivePolling;
                    return $i4;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525284)
            
            //--TRIMMABLE-BOUNDARY-START(133144969316)
            /*void */ ReadPollingEnvironmentVariables()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let environmentValue = $.$$.S.Environment.GetEnvironmentVariable$1("DOTNET_USE_POLLING_FILE_WATCHER"/*PollingEnvironmentKey*/);
                /*bool*/ let pollForChanges = $.$$.S.String.Equals$3(environmentValue, "1", 4/*StringComparison.Ordinal*/) || $.$$.S.String.Equals$3(environmentValue, "true", 5/*StringComparison.OrdinalIgnoreCase*/);
                this._usePollingFileWatcher = pollForChanges;
                this._useActivePolling = pollForChanges;
            }
            //--TRIMMABLE-BOUNDARY-END(133144969316)
            
            //--TRIMMABLE-BOUNDARY-START(64425492580)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(64425492580)
            
            //--TRIMMABLE-BOUNDARY-START(68720459876)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720459876)
            
            //--TRIMMABLE-BOUNDARY-START(137439936612)
            /*string*/ Root = null;
            //--TRIMMABLE-BOUNDARY-END(137439936612)
            
            //--TRIMMABLE-BOUNDARY-START(120260067428)
            /*string? */ GetFullPath(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mefp.MEFPI.PathUtils.PathNavigatesAboveRoot(path))
                {
                    return null;
                }
                /*string*/ let fullPath;
                try
                {
                    fullPath = $.$$.SI.Path.GetFullPath$1($.$$.SI.Path.Combine$3(this.Root, path));
                }
                catch($e)
                {
                    return null;
                }
                if (!this.IsUnderneathRoot(fullPath))
                {
                    return null;
                }
                return fullPath;
            }
            //--TRIMMABLE-BOUNDARY-END(120260067428)
            
            //--TRIMMABLE-BOUNDARY-START(124555034724)
            /*bool */ IsUnderneathRoot(/*string*/ fullPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.StartsWith$2.call(fullPath, this.Root, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034724)
            
            //--TRIMMABLE-BOUNDARY-START(115965100132)
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(subpath) || $.$mefp.MEFPI.PathUtils.HasInvalidPathChars(subpath))
                {
                    return new $.$mefa.MEF.NotFoundFileInfo().$ctor$1(subpath);
                }
                subpath = $.$$.S.String.TrimStart$2.call(subpath, $.$mefp.MEF.PhysicalFileProvider._pathSeparators);
                if ($.$$.SI.Path.IsPathRooted$1(subpath))
                {
                    return new $.$mefa.MEF.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*string?*/ let fullPath = this.GetFullPath(subpath);
                if (fullPath === null)
                {
                    return new $.$mefa.MEF.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*var*/ let fileInfo = new $.$$.SI.FileInfo().$ctor$6(fullPath);
                if ($.$mefp.MEFP.FileSystemInfoHelper.IsExcluded(fileInfo, this._filters))
                {
                    return new $.$mefa.MEF.NotFoundFileInfo().$ctor$1(subpath);
                }
                return new $.$mefp.MEFP.PhysicalFileInfo().$ctor$1(fileInfo);
            }
            //--TRIMMABLE-BOUNDARY-END(115965100132)
            
            //--TRIMMABLE-BOUNDARY-START(111670132836)
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670132836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    if (subpath === null || $.$mefp.MEFPI.PathUtils.HasInvalidPathChars(subpath))
                    {
                        return $.$mefa.MEF.NotFoundDirectoryContents.Singleton;
                    }
                    subpath = $.$$.S.String.TrimStart$2.call(subpath, $.$mefp.MEF.PhysicalFileProvider._pathSeparators);
                    if ($.$$.SI.Path.IsPathRooted$1(subpath))
                    {
                        return $.$mefa.MEF.NotFoundDirectoryContents.Singleton;
                    }
                    /*string?*/ let fullPath = this.GetFullPath(subpath);
                    if (fullPath === null || !$.$$.SI.Directory.Exists(fullPath))
                    {
                        return $.$mefa.MEF.NotFoundDirectoryContents.Singleton;
                    }
                    return new $.$mefp.MEFI.PhysicalDirectoryContents().$ctor$1(fullPath, this._filters);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.SI.DirectoryNotFoundException)
                    {
                    }
                    else if ($e instanceof $.$$.SI.IOException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return $.$mefa.MEF.NotFoundDirectoryContents.Singleton;
            }
            //--TRIMMABLE-BOUNDARY-END(111670132836)
            
            //--TRIMMABLE-BOUNDARY-START(176094642276)
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094642276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (filter === null || $.$mefp.MEFPI.PathUtils.HasInvalidFilterChars(filter))
                {
                    return $.$mefa.MEF.NullChangeToken.Singleton;
                }
                filter = $.$$.S.String.TrimStart$2.call(filter, $.$mefp.MEF.PhysicalFileProvider._pathSeparators);
                return this.FileWatcher.CreateFileChangeToken(filter);
            }
            //--TRIMMABLE-BOUNDARY-END(176094642276)
            
            //--TRIMMABLE-BOUNDARY-START(8590196835)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            MEF$IFileProvider$GetFileInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetFileInfo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196835)
            
            //--TRIMMABLE-BOUNDARY-START(4295229539)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            MEF$IFileProvider$GetDirectoryContents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetDirectoryContents(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229539)
            
            //--TRIMMABLE-BOUNDARY-START(12885164131)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            MEF$IFileProvider$Watch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Watch(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164131)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475819620)
                this._fileWatcherLock = new $.$$.S.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(21475819620)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47245623396)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(128850002020)
                    this.PollingEnvironmentKey = "DOTNET_USE_POLLING_FILE_WATCHER";
                    //--TRIMMABLE-BOUNDARY-END(128850002020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065754212)
                    this._pathSeparators = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [$.$$.SI.Path.DirectorySeparatorChar, $.$$.SI.Path.AltDirectorySeparatorChar], null, null);
                    //--TRIMMABLE-BOUNDARY-END(30065754212)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245623396)
            
            static $h = 983140;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799674980),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375165540,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209740388,
        "f": 83886081
      },
      "n": "UsePollingFileWatcher",
      "d": 983140,
      "h": 171799674980,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799674980),
//--TRIMMABLE-BOUNDARY-START(167504707684),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785230948,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619805796,
        "f": 83886081
      },
      "n": "UseActivePolling",
      "d": 983140,
      "h": 167504707684,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504707684),
//--TRIMMABLE-BOUNDARY-START(73015427172),
    {
      "p": 720996,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361764,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029871204,
        "f": 83886088
      },
      "n": "FileWatcher",
      "d": 983140,
      "h": 73015427172,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(73015427172),
//--TRIMMABLE-BOUNDARY-START(137439936612),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195296356,
        "f": 50331649
      },
      "n": "Root",
      "d": 983140,
      "h": 137439936612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439936612)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130525284),
    {
      "r": 720996,
      "n": "CreateFileWatcher",
      "d": 983140,
      "h": 60130525284,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60130525284),
//--TRIMMABLE-BOUNDARY-START(133144969316),
    {
      "r": 65537,
      "n": "ReadPollingEnvironmentVariables",
      "d": 983140,
      "h": 133144969316,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144969316),
//--TRIMMABLE-BOUNDARY-START(64425492580),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 983140,
      "h": 64425492580,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425492580),
//--TRIMMABLE-BOUNDARY-START(68720459876),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 983140,
      "h": 68720459876,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720459876),
//--TRIMMABLE-BOUNDARY-START(120260067428),
    {
      "r": 1310721,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetFullPath",
      "d": 983140,
      "h": 120260067428,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120260067428),
//--TRIMMABLE-BOUNDARY-START(124555034724),
    {
      "r": 262145,
      "p": [
        {
          "n": "fullPath",
          "p": 1310721
        }
      ],
      "n": "IsUnderneathRoot",
      "d": 983140,
      "h": 124555034724,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555034724),
//--TRIMMABLE-BOUNDARY-START(115965100132),
    {
      "r": 196707,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetFileInfo",
      "d": 983140,
      "h": 115965100132,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115965100132),
//--TRIMMABLE-BOUNDARY-START(111670132836),
    {
      "r": 131171,
      "p": [
        {
          "n": "subpath",
          "p": 1310721
        }
      ],
      "n": "GetDirectoryContents",
      "d": 983140,
      "h": 111670132836,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670132836),
//--TRIMMABLE-BOUNDARY-START(176094642276),
    {
      "r": 720981,
      "p": [
        {
          "n": "filter",
          "p": 1310721
        }
      ],
      "n": "Watch",
      "d": 983140,
      "h": 176094642276,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094642276)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(128850002020),
    {
      "t": 1310721,
      "n": "PollingEnvironmentKey",
      "d": 983140,
      "h": 128850002020,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128850002020),
//--TRIMMABLE-BOUNDARY-START(30065754212),
    {
      "t": $.$typeArray($.$$.S.Char).$h,
      "n": "_pathSeparators",
      "d": 983140,
      "h": 30065754212,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065754212),
//--TRIMMABLE-BOUNDARY-START(25770786916),
    {
      "t": 327780,
      "n": "_filters",
      "d": 983140,
      "h": 25770786916,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786916),
//--TRIMMABLE-BOUNDARY-START(12885885028),
    {
      "t": $.$$.S.Func$$($.$mefp.MEFP.PhysicalFilesWatcher).$h,
      "n": "_fileWatcherFactory",
      "d": 983140,
      "h": 12885885028,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885028),
//--TRIMMABLE-BOUNDARY-START(8590917732),
    {
      "t": 720996,
      "n": "_fileWatcher",
      "d": 983140,
      "h": 8590917732,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917732),
//--TRIMMABLE-BOUNDARY-START(17180852324),
    {
      "t": 262145,
      "n": "_fileWatcherInitialized",
      "d": 983140,
      "h": 17180852324,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852324),
//--TRIMMABLE-BOUNDARY-START(21475819620),
    {
      "t": 131073,
      "n": "_fileWatcherLock",
      "d": 983140,
      "h": 21475819620,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819620),
//--TRIMMABLE-BOUNDARY-START(38655688804),
    {
      "t": $.$typeNullable($.$$.S.Boolean).$h,
      "n": "_usePollingFileWatcher",
      "d": 983140,
      "h": 38655688804,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655688804),
//--TRIMMABLE-BOUNDARY-START(34360721508),
    {
      "t": $.$typeNullable($.$$.S.Boolean).$h,
      "n": "_useActivePolling",
      "d": 983140,
      "h": 34360721508,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360721508),
//--TRIMMABLE-BOUNDARY-START(4295950436),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 983140,
      "h": 4295950436,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950436)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835557988),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983140,
      "h": 55835557988,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835557988),
//--TRIMMABLE-BOUNDARY-START(51540590692),
    {
      "p": [
        {
          "n": "root",
          "p": 1310721
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983140,
      "h": 51540590692,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590692)
  ],
  "h": 983140
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileProvider, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.PhysicalFileProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}PhysicalFileProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983140)
        
        

        //--TRIMMABLE-BOUNDARY-START(131172)
        $asm.$cls(`$mefp.MEFI.PhysicalDirectoryContents`, ($self) => class PhysicalDirectoryContents extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098468)
            /*PhysicalDirectoryInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(4295098468)
            
            //--TRIMMABLE-BOUNDARY-START(12885033060)
            $ctor$2(/*string*/ directory)
            {
                this.$ctor$1(directory, 7/*ExclusionFilters.Sensitive*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033060);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033060)
            
            //--TRIMMABLE-BOUNDARY-START(8590065764)
            $ctor$1(/*string*/ directory, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065764);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(directory, "directory");
                    this._info = new $.$mefp.MEFP.PhysicalDirectoryInfo().$ctor$1(new $.$$.SI.DirectoryInfo().$ctor$5(directory), filters);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065764)
            
            //--TRIMMABLE-BOUNDARY-START(17180000356)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000356)
            
            //--TRIMMABLE-BOUNDARY-START(30064902244)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064902244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._info.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064902244)
            
            //--TRIMMABLE-BOUNDARY-START(34359869540)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359869540);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._info.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359869540)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get MEF$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            static $h = 131172;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000356),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769934948,
        "f": 50331649
      },
      "n": "Exists",
      "d": 131172,
      "h": 17180000356,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000356)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30064902244),
    {
      "r": $.$$.SCG.IEnumerator$$($.$mefa.MEF.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 131172,
      "h": 30064902244,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064902244)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098468),
    {
      "t": 589924,
      "n": "_info",
      "d": 131172,
      "h": 4295098468,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098468)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033060),
    {
      "p": [
        {
          "n": "directory",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131172,
      "h": 12885033060,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033060),
//--TRIMMABLE-BOUNDARY-START(8590065764),
    {
      "p": [
        {
          "n": "directory",
          "p": 1310721
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131172,
      "h": 8590065764,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065764)
  ],
  "h": 131172
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IDirectoryContents, $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Internal${separator}PhysicalDirectoryContents`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131172)
        
        

        //--TRIMMABLE-BOUNDARY-START(589924)
        $asm.$cls(`$mefp.MEFP.PhysicalDirectoryInfo`, ($self) => class PhysicalDirectoryInfo extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885491812)
            /*DirectoryInfo*/ _info = null;
            //--TRIMMABLE-BOUNDARY-END(12885491812)
            
            //--TRIMMABLE-BOUNDARY-START(4295557220)
            /*IEnumerable<IFileInfo>?*/ _entries = null;
            //--TRIMMABLE-BOUNDARY-END(4295557220)
            
            //--TRIMMABLE-BOUNDARY-START(8590524516)
            /*ExclusionFilters*/ _filters = 0;
            //--TRIMMABLE-BOUNDARY-END(8590524516)
            
            //--TRIMMABLE-BOUNDARY-START(21475426404)
            $ctor$2(/*DirectoryInfo*/ info)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426404);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426404)
            
            //--TRIMMABLE-BOUNDARY-START(17180459108)
            $ctor$1(/*DirectoryInfo*/ info, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._info = info;
                    this._filters = filters;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459108)
            
            //--TRIMMABLE-BOUNDARY-START(34360328292)
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328292)
            
            //--TRIMMABLE-BOUNDARY-START(103079805028)
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            //--TRIMMABLE-BOUNDARY-END(103079805028)
            
            //--TRIMMABLE-BOUNDARY-START(111669739620)
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(111669739620)
            
            //--TRIMMABLE-BOUNDARY-START(107374772324)
            /*string */ get Name()
            {
                return this._info.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(107374772324)
            
            //--TRIMMABLE-BOUNDARY-START(98784837732)
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.S.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            //--TRIMMABLE-BOUNDARY-END(98784837732)
            
            //--TRIMMABLE-BOUNDARY-START(94489870436)
            /*bool */ get IsDirectory()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(94489870436)
            
            //--TRIMMABLE-BOUNDARY-START(25770393700)
            /*Stream */ CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$mefp.S.SR.CannotCreateStream);
            }
            //--TRIMMABLE-BOUNDARY-END(25770393700)
            
            //--TRIMMABLE-BOUNDARY-START(90194903140)
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureInitialized();
                return this._entries.SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(90194903140)
            
            //--TRIMMABLE-BOUNDARY-START(115964706916)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureInitialized();
                return this._entries.SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(115964706916)
            
            //--TRIMMABLE-BOUNDARY-START(30065360996)
            /*void */ EnsureInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this._entries = $.$sl.SL.Enumerable.Select$1($.$$.SI.FileSystemInfo, $.$mefa.MEF.IFileInfo, $.$sl.SL.Enumerable.Where($.$$.SI.FileSystemInfo, this._info.EnumerateFileSystemInfos(), new ($.$$.S.Func$$$($.$$.SI.FileSystemInfo, $.$$.S.Boolean))().$ctor(this,  (/*info*/ info) =>
                    {
                        return !$.$mefp.MEFP.FileSystemInfoHelper.IsExcluded(info, this._filters);
                    }, $Ghuloh ??= {"r":262145,"p":[{"n":"info","p":94109697}],"n":"","d":589924,"h":0,"f":17825794})), new ($.$$.S.Func$$$($.$$.SI.FileSystemInfo, $.$mefa.MEF.IFileInfo))().$ctor(this,  (/*info*/ info) =>
                    {
                        return (() =>
                        {
                            {
                                let file;
                                if ((file = info, $.$is(file, $.$$.SI.FileInfo)))
                                {
                                    return new $.$mefp.MEFP.PhysicalFileInfo().$ctor$1(file);
                                }
                            }
                            {
                                let dir;
                                if ((dir = info, $.$is(dir, $.$$.SI.DirectoryInfo)))
                                {
                                    return new $.$mefp.MEFP.PhysicalDirectoryInfo().$ctor$2(dir);
                                }
                            }
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$mefp.S.SR.UnexpectedFileSystemInfo);
                        })();
                    }, $HJzEkf ??= {"r":196707,"p":[{"n":"info","p":94109697}],"n":"","d":589924,"h":0,"f":17825794}));
                }
                catch(ex)
                {
                    this._entries = $.$sl.SL.Enumerable.Empty($.$mefa.MEF.IFileInfo);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065360996)
            
            //--TRIMMABLE-BOUNDARY-START(17180065891)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get MEF$IFileInfo$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065891)
            
            //--TRIMMABLE-BOUNDARY-START(42949869667)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get MEF$IFileInfo$Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869667)
            
            //--TRIMMABLE-BOUNDARY-START(60129738851)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get MEF$IFileInfo$PhysicalPath()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PhysicalPath;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738851)
            
            //--TRIMMABLE-BOUNDARY-START(51539804259)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get MEF$IFileInfo$Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804259)
            
            //--TRIMMABLE-BOUNDARY-START(34359935075)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get MEF$IFileInfo$LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.LastModified;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935075)
            
            //--TRIMMABLE-BOUNDARY-START(25770000483)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get MEF$IFileInfo$IsDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsDirectory;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000483)
            
            //--TRIMMABLE-BOUNDARY-START(4295164003)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            MEF$IFileInfo$CreateReadStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateReadStream(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295164003)
            
            //--TRIMMABLE-BOUNDARY-START(12885033059)
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get MEF$IDirectoryContents$Exists()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Exists;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033059)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            static $h = 589924;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360328292),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262884,
        "f": 50331649
      },
      "n": "Exists",
      "d": 589924,
      "h": 34360328292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328292),
//--TRIMMABLE-BOUNDARY-START(103079805028),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066660,
        "f": 50331649
      },
      "n": "Length",
      "d": 589924,
      "h": 103079805028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079805028),
//--TRIMMABLE-BOUNDARY-START(111669739620),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899935844,
        "f": 50331649
      },
      "n": "PhysicalPath",
      "d": 589924,
      "h": 111669739620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669739620),
//--TRIMMABLE-BOUNDARY-START(107374772324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310001252,
        "f": 50331649
      },
      "n": "Name",
      "d": 589924,
      "h": 107374772324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374772324),
//--TRIMMABLE-BOUNDARY-START(98784837732),
    {
      "p": 66191361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132068,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 589924,
      "h": 98784837732,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784837732),
//--TRIMMABLE-BOUNDARY-START(94489870436),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197476,
        "f": 50331649
      },
      "n": "IsDirectory",
      "d": 589924,
      "h": 94489870436,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489870436)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770393700),
    {
      "r": 95748097,
      "n": "CreateReadStream",
      "d": 589924,
      "h": 25770393700,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770393700),
//--TRIMMABLE-BOUNDARY-START(90194903140),
    {
      "r": $.$$.SCG.IEnumerator$$($.$mefa.MEF.IFileInfo).$h,
      "n": "GetEnumerator",
      "d": 589924,
      "h": 90194903140,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194903140),
//--TRIMMABLE-BOUNDARY-START(30065360996),
    {
      "r": 65537,
      "n": "EnsureInitialized",
      "d": 589924,
      "h": 30065360996,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065360996)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491812),
    {
      "t": 92274689,
      "n": "_info",
      "d": 589924,
      "h": 12885491812,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491812),
//--TRIMMABLE-BOUNDARY-START(4295557220),
    {
      "t": $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo).$h,
      "n": "_entries",
      "d": 589924,
      "h": 4295557220,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557220),
//--TRIMMABLE-BOUNDARY-START(8590524516),
    {
      "t": 327780,
      "n": "_filters",
      "d": 589924,
      "h": 8590524516,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524516)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426404),
    {
      "p": [
        {
          "n": "info",
          "p": 92274689
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589924,
      "h": 21475426404,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426404),
//--TRIMMABLE-BOUNDARY-START(17180459108),
    {
      "p": [
        {
          "n": "info",
          "p": 92274689
        },
        {
          "n": "filters",
          "p": 327780
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589924,
      "h": 17180459108,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180459108)
  ],
  "h": 589924
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.MEF.IFileInfo, $.$mefa.MEF.IDirectoryContents, $.$$.SCG.IEnumerable$$($.$mefa.MEF.IFileInfo), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}PhysicalDirectoryInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589924)
        
        

        //--TRIMMABLE-BOUNDARY-START(327780)
        $asm.$str(`$mefp.MEFP.ExclusionFilters`, ($self) => class ExclusionFilters extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Sensitive = 7;
            static DotPrefixed = 1;
            static Hidden = 2;
            static System = 4;
            static None = 0;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Sensitive": 7n,
                    "DotPrefixed": 1n,
                    "Hidden": 2n,
                    "System": 4n,
                    "None": 0n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295295076)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295076)
            
            //--TRIMMABLE-BOUNDARY-START(4295295076)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295076)
            
            static $h = 327780;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475164260),
    {
      "t": 327780,
      "n": "Sensitive",
      "d": 327780,
      "h": 21475164260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164260),
//--TRIMMABLE-BOUNDARY-START(8590262372),
    {
      "t": 327780,
      "n": "DotPrefixed",
      "d": 327780,
      "h": 8590262372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262372),
//--TRIMMABLE-BOUNDARY-START(12885229668),
    {
      "t": 327780,
      "n": "Hidden",
      "d": 327780,
      "h": 12885229668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229668),
//--TRIMMABLE-BOUNDARY-START(25770131556),
    {
      "t": 327780,
      "n": "System",
      "d": 327780,
      "h": 25770131556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131556),
//--TRIMMABLE-BOUNDARY-START(17180196964),
    {
      "t": 327780,
      "n": "None",
      "d": 327780,
      "h": 17180196964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196964)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295076),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327780,
      "h": 4295295076,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295076)
  ],
  "h": 327780,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.FileProviders.Physical.ExclusionFilters`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}FileProviders${separator}Physical${separator}ExclusionFilters`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327780)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"));
})();
//--TRIMMABLE-BOUNDARY-END(100)
