
(function ($global, $, $$, $sm, $mep, $sc, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mefa, $mef, $mwp, $sci, $scn, $scm, $so, $scp, $sic, $stt, $sim, $stee, $srm, $sds, $srn, $sfa, $sto, $sifw, $snp, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Physical", 
    {"h":27,"f":"Microsoft.Extensions.FileProviders.Physical","v":"1.0.35.0","a":[{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.FileProviders.Physical.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Physical","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Physical","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.IClock", ($self) => class IClock
        {
            static $h = 458779;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":34275329,"g":{"r":0,"d":0,"h":8590393371,"f":50331905},"n":"UtcNow","o":"Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow","d":458779,"h":4295426075,"f":2097409}],"h":458779}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.IClock`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken", ($self) => class IPollingChangeToken
        {
            static $h = 196635;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":125960193,"g":{"r":0,"d":0,"h":8590131227,"f":50331905},"n":"CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":196635,"h":4295163931,"f":2097409}],"i":[720898],"h":196635}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IPollingChangeToken`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.Internal.NonCapturingTimer", ($self) => class NonCapturingTimer
        {
            static /*Timer */ Create(/*TimerCallback*/ callback, /*object*/ state, /*TimeSpan*/ dueTime, /*TimeSpan*/ period)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(callback, "callback");
                /*bool*/ let restoreFlow = false;
                try
                {
                    if (!$.$$.System.Threading.ExecutionContext.IsFlowSuppressed())
                    {
                        $.$$.System.Threading.ExecutionContext.SuppressFlow();
                        restoreFlow = true;
                    }
                    return new $.$$.System.Threading.Timer().$ctor$5(callback, state, dueTime, period);
                }
                finally
                {
                    {
                        if (restoreFlow)
                        {
                            $.$$.System.Threading.ExecutionContext.RestoreFlow();
                        }
                    }
                }
            }
            static $h = 1048603;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":138412033,"p":[{"n":"callback","p":138477569},{"n":"state","p":131073},{"n":"dueTime","p":140574721},{"n":"period","p":140574721}],"n":"Create","d":1048603,"h":4296015899,"f":16777249}],"h":1048603}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.NonCapturingTimer`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper", ($self) => class FileSystemInfoHelper
        {
            static /*bool */ IsExcluded(/*FileSystemInfo*/ fileSystemInfo, /*ExclusionFilters*/ filters)
            {
                if (filters === 0/*ExclusionFilters.None*/)
                {
                    return false;
                }
                else if ($.$$.System.String.StartsWith$2.call(fileSystemInfo.Name, ".", 4/*StringComparison.Ordinal*/) && (filters & 1/*ExclusionFilters.DotPrefixed*/) !== 0)
                {
                    return true;
                }
                else if (fileSystemInfo.Exists && (((fileSystemInfo.Attributes & 2/*FileAttributes.Hidden*/) !== 0 && (filters & 2/*ExclusionFilters.Hidden*/) !== 0) || ((fileSystemInfo.Attributes & 4/*FileAttributes.System*/) !== 0 && (filters & 4/*ExclusionFilters.System*/) !== 0)))
                {
                    return true;
                }
                return false;
            }
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc$1(/*string*/ filePath)
            {
                /*var*/ let fileInfo = new $.$$.System.IO.FileInfo().$ctor$6(filePath);
                if (fileInfo.Exists)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(fileInfo);
                }
                return null;
            }
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc(/*FileInfo*/ fileInfo)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(fileInfo.Exists, "fileInfo.Exists");
                if ($.$$.System.String.op_Inequality(fileInfo.LinkTarget, null))
                {
                    try
                    {
                        /*FileSystemInfo?*/ let targetInfo = fileInfo.ResolveLinkTarget(true);
                        if (targetInfo !== null && targetInfo.Exists)
                        {
                            return targetInfo.LastWriteTimeUtc;
                        }
                    }
                    catch(ex)
                    {
                    }
                    return $.$$.System.DateTime.MinValue;
                }
                return null;
            }
            static $h = 393243;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"fileSystemInfo","p":60555265},{"n":"filters","p":327707}],"n":"IsExcluded","d":393243,"h":4295360539,"f":16777249},{"r":$.$typeNullable($.$$.System.DateTime).$h,"p":[{"n":"filePath","p":1310721}],"n":"GetFileLinkTargetLastWriteTimeUtc","o":"@$1","d":393243,"h":8590327835,"f":16777249},{"r":$.$typeNullable($.$$.System.DateTime).$h,"p":[{"n":"fileInfo","p":59899905}],"n":"GetFileLinkTargetLastWriteTimeUtc","d":393243,"h":12885295131,"f":16777249}],"h":393243}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper`; }
        });
        
        $asm.$cls("$mefp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mefp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Physical", $.$mefp.System.SR.$type.Assembly);
                    $.$mefp.System.SR.s_resourceManager = temp;
                }
                return $.$mefp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mefp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mefp.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Error_FileSystemWatcherRequiredWithoutPolling()
            {
                return "The fileSystemWatcher parameter must be non-null when pollForChanges is false.";
            }
            static /*string */ get CannotCreateStream()
            {
                return "Cannot create a stream for a directory.";
            }
            static /*string */ get CannotModifyWhenFileWatcherInitialized()
            {
                return "Cannot modify {0} once file watcher has been initialized.";
            }
            static /*string */ FormatCannotModifyWhenFileWatcherInitialized(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot modify {0} once file watcher has been initialized.", arg1);
            }
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                return "The hash algorithm name cannot be null or empty.";
            }
            static /*string */ get UnexpectedFileSystemInfo()
            {
                return "Unexpected type of FileSystemInfo";
            }
            static /*string */ get FileSystemWatcher_PlatformNotSupported()
            {
                return "The type '{0}' is not supported on this platform, use polling instead.";
            }
            static /*string */ FormatFileSystemWatcher_PlatformNotSupported(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The type '{0}' is not supported on this platform, use polling instead.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mefp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mefp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mefp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1114139;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1114139}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils", ($self) => class PathUtils
        {
            static /*char[] */ GetInvalidFileNameChars()
            {
                return $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Char, $.$sl.System.Linq.Enumerable.Where($.$$.System.Char, $.$$.System.IO.Path.GetInvalidFileNameChars(), new ($.$$.System.Func$$$($.$$.System.Char, $.$$.System.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c !== $.$$.System.IO.Path.DirectorySeparatorChar && c !== $.$$.System.IO.Path.AltDirectorySeparatorChar;
                }, {"r":262145,"p":[{"n":"c","p":458753}],"n":"","d":524315,"h":0,"f":17825794})));
            }
            static /*char[] */ GetInvalidFilterChars()
            {
                return $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Char, $.$sl.System.Linq.Enumerable.Where($.$$.System.Char, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars(), new ($.$$.System.Func$$$($.$$.System.Char, $.$$.System.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c !== /***/ 42 && c !== /*|*/ 124 && c !== /*?*/ 63;
                }, {"r":262145,"p":[{"n":"c","p":458753}],"n":"","d":524315,"h":0,"f":17825794})));
            }
            /*SearchValues<char>*/ static _invalidFileNameChars = null;
            /*SearchValues<char>*/ static _invalidFilterChars = null;
            static /*bool */ HasInvalidPathChars(/*string*/ path)
            {
                return $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFileNameChars);
            }
            static /*bool */ HasInvalidFilterChars(/*string*/ path)
            {
                return $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFilterChars);
            }
            /*char[]*/ static _pathSeparators = null;
            static /*string */ EnsureTrailingSlash(/*string*/ path)
            {
                if (!$.$$.System.String.IsNullOrEmpty(path) && $.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) !== $.$$.System.IO.Path.DirectorySeparatorChar)
                {
                    return path + $.$$.System.IO.Path.DirectorySeparatorChar;
                }
                return path;
            }
            static /*bool */ PathNavigatesAboveRoot(/*string*/ path)
            {
                /*var*/ let tokenizer = new $.$mep.Microsoft.Extensions.Primitives.StringTokenizer().$ctor$3(path, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._pathSeparators);
                /*int*/ let depth = 0;
                var $en2 = tokenizer.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var segment = $en2.Current;
                    {
                        if (segment.Equals$3(".") || segment.Equals$3(""))
                        {
                            continue;
                        }
                        else if (segment.Equals$3(".."))
                        {
                            depth--;
                            if (depth === -1)
                            {
                                return true;
                            }
                        }
                        else 
                        {
                            depth++;
                        }
                    }
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._invalidFileNameChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars()));
                }
                {
                    this._invalidFilterChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.ReadOnlySpan$$($.$$.System.Char).op_Implicit$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFilterChars()));
                }
                {
                    this._pathSeparators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [$.$$.System.IO.Path.DirectorySeparatorChar, $.$$.System.IO.Path.AltDirectorySeparatorChar], null, null);
                }
            }
            static $h = 524315;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typeArray($.$$.System.Char).$h,"n":"GetInvalidFileNameChars","d":524315,"h":4295491611,"f":16777250},{"r":$.$typeArray($.$$.System.Char).$h,"n":"GetInvalidFilterChars","d":524315,"h":8590458907,"f":16777250},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"HasInvalidPathChars","d":524315,"h":21475360795,"f":16777256},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"HasInvalidFilterChars","d":524315,"h":25770328091,"f":16777256},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"EnsureTrailingSlash","d":524315,"h":34360262683,"f":16777256},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"PathNavigatesAboveRoot","d":524315,"h":38655229979,"f":16777256}],"l":[{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"_invalidFileNameChars","d":524315,"h":12885426203,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"_invalidFilterChars","d":524315,"h":17180393499,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"_pathSeparators","d":524315,"h":30065295387,"f":4194338}],"h":524315}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$$.System.Object
        {
            /*EmptyDisposable*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            static $h = 65563;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":65563,"g":{"r":0,"d":0,"h":12884967451,"f":50331681},"n":"Instance","d":65563,"h":8590000155,"f":2097185}],"m":[{"r":65537,"n":"Dispose","d":65563,"h":21474902043,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":65563,"h":17179934747,"f":16777218}],"i":[57540609],"h":65563}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Clock", ($self) => class Clock extends $.$$.System.Object
        {
            /*Clock*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*DateTime */ get UtcNow()
            {
                return $.$$.System.DateTime.UtcNow;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.Physical.IClock.UtcNow.get
            get Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow()
            {
                return this.UtcNow;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock().$ctor$1();
                }
            }
            static $h = 262171;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34275329,"g":{"r":0,"d":0,"h":17180131355,"f":50331649},"n":"UtcNow","d":262171,"h":12885164059,"f":2097153}],"l":[{"t":262171,"n":"Instance","d":262171,"h":4295229467,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":262171,"h":8590196763,"f":16777218}],"i":[458779],"h":262171}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.Physical.IClock ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Clock`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo", ($self) => class PhysicalFileInfo extends $.$$.System.Object
        {
            /*FileInfo*/ _info = null;
            $ctor$1(/*FileInfo*/ info)
            {
                super.$ctor();
                {
                    this._info = info;
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*long */ get Length()
            {
                return this._info.Length;
            }
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            /*string */ get Name()
            {
                return this._info.Name;
            }
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            /*bool */ get IsDirectory()
            {
                return false;
            }
            /*Stream */ CreateReadStream()
            {
                /*int*/ let bufferSize = 1;
                return new $.$$.System.IO.FileStream().$ctor$12(this.PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, bufferSize, 1073741824/*FileOptions.Asynchronous*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                return this.Length;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                return this.PhysicalPath;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                return this.IsDirectory;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                return this.CreateReadStream(...arguments);
            }
            static $h = 655387;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180524571,"f":50331649},"n":"Exists","d":655387,"h":12885557275,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":25770459163,"f":50331649},"n":"Length","d":655387,"h":21475491867,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360393755,"f":50331649},"n":"PhysicalPath","d":655387,"h":30065426459,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950328347,"f":50331649},"n":"Name","d":655387,"h":38655361051,"f":2097153},{"p":34471937,"g":{"r":0,"d":0,"h":51540262939,"f":50331649},"n":"LastModified","d":655387,"h":47245295643,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60130197531,"f":50331649},"n":"IsDirectory","d":655387,"h":55835230235,"f":2097153}],"m":[{"r":62193665,"n":"CreateReadStream","d":655387,"h":64425164827,"f":16777217}],"l":[{"t":59899905,"n":"_info","d":655387,"h":4295622683,"f":4194306}],"c":[{"p":[{"n":"info","p":59899905}],"n":".ctor","o":"$ctor$1","d":655387,"h":8590589979,"f":16777217}],"i":[196634],"h":655387}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher", ($self) => class PhysicalFilesWatcher extends $.$$.System.Object
        {
            /*Action<object?>*/ static _cancelTokenSource = null;
            /*TimeSpan*/ static DefaultPollingInterval;
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _filePathTokenLookup = null;
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _wildcardTokenLookup = null;
            /*FileSystemWatcher?*/ _fileWatcher = null;
            /*object*/ _fileWatcherLock = null;
            /*string*/ _root = null;
            /*ExclusionFilters*/ _filters = 0;
            /*Timer?*/ _timer = null;
            /*bool*/ _timerInitialized = false;
            /*object*/ _timerLock = null;
            /*Func<Timer>*/ _timerFactory = null;
            /*bool*/ _disposed = false;
            $ctor$2(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges)
            {
                this.$ctor$1(root, fileSystemWatcher, pollForChanges, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    if (fileSystemWatcher === null && !pollForChanges)
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$18("fileSystemWatcher", $.$mefp.System.SR.Error_FileSystemWatcherRequiredWithoutPolling);
                    }
                    this._root = root;
                    if (fileSystemWatcher !== null)
                    {
                        if ($.$$.System.OperatingSystem.IsBrowser() || $.$$.System.OperatingSystem.IsWasi() || ($.$$.System.OperatingSystem.IsIOS() && !$.$$.System.OperatingSystem.IsMacCatalyst()) || $.$$.System.OperatingSystem.IsTvOS())
                        {
                            throw new $.$$.System.PlatformNotSupportedException().$ctor$16($.$mefp.System.SR.Format$6($.$mefp.System.SR.FileSystemWatcher_PlatformNotSupported, $.$sifw.System.IO.FileSystemWatcher.$type));
                        }
                        this._fileWatcher = fileSystemWatcher;
                        this._fileWatcher.IncludeSubdirectories = true;
                        this._fileWatcher.add_Created(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Changed(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Renamed(new $.$sifw.System.IO.RenamedEventHandler().$ctor(this, this.OnRenamed));
                        this._fileWatcher.add_Deleted(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.add_Error(new $.$sifw.System.IO.ErrorEventHandler().$ctor(this, this.OnError));
                    }
                    this.PollForChanges = pollForChanges;
                    this._filters = filters;
                    this.PollingChangeTokens = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken))().$ctor$1();
                    this._timerFactory = new ($.$$.System.Func$$($.$$.System.Threading.Timer))().$ctor(this,  () =>
                    {
                        return $.$mefp.Microsoft.Extensions.Internal.NonCapturingTimer.Create(new $.$$.System.Threading.TimerCallback().$ctor($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.RaiseChangeEvents), this.PollingChangeTokens, $.$$.System.TimeSpan.Zero, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval);
                    }, {"r":138412033,"n":"","d":720923,"h":0,"f":17825794});
                }
                return this;
            }
            /*bool*/ PollForChanges = false;
            /*bool*/ UseActivePolling = false;
            /*ConcurrentDictionary<IPollingChangeToken, IPollingChangeToken>*/ PollingChangeTokens = null;
            /*IChangeToken */ CreateFileChangeToken(/*string*/ filter)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(filter, "filter");
                filter = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(filter);
                if ($.$$.System.IO.Path.IsPathRooted$1(filter) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                /*IChangeToken*/ let changeToken = this.GetOrAddChangeToken(filter);
                this.TryEnableFileSystemWatcher();
                return changeToken;
            }
            /*IChangeToken */ GetOrAddChangeToken(/*string*/ pattern)
            {
                if (this.UseActivePolling)
                {
                    $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$$.System.Threading.Timer, $.$ref(() => this._timer, ($v) => this._timer = $v, $.$$.System.Threading.Timer), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._timerInitialized, ($v) => this._timerInitialized = $v, null), $.$ref(() => this._timerLock, ($v) => this._timerLock = $v, $.$$.System.Object), this._timerFactory);
                }
                /*IChangeToken*/ let changeToken;
                /*bool*/ let isWildCard = $.$$.System.String.Contains$1.call(pattern, /***/ 42);
                if (isWildCard || $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.IsDirectoryPath(pattern))
                {
                    changeToken = this.GetOrAddWildcardChangeToken(pattern);
                }
                else 
                {
                    changeToken = this.GetOrAddFilePathChangeToken(pattern);
                }
                return changeToken;
            }
            /*IChangeToken */ GetOrAddFilePathChangeToken(/*string*/ filePath)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._filePathTokenLookup.TryGetValue(filePath, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$4(cancellationTokenSource, cancellationChangeToken);
                    tokenInfo = this._filePathTokenLookup.GetOrAdd$1(filePath, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken().$ctor$1(new $.$$.System.IO.FileInfo().$ctor$6($.$$.System.IO.Path.Combine$3(this._root, filePath)));
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            /*IChangeToken */ GetOrAddWildcardChangeToken(/*string*/ pattern)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._wildcardTokenLookup.TryGetValue(pattern, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    /*var*/ let matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    matcher.AddInclude(pattern);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$3(cancellationTokenSource, cancellationChangeToken, matcher);
                    tokenInfo = this._wildcardTokenLookup.GetOrAdd$1(pattern, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken().$ctor$1(this._root, pattern);
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                        this._timer?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            /*void */ OnRenamed(/*object*/ sender, /*RenamedEventArgs*/ e)
            {
                this.OnFileSystemEntryChange(e.OldFullPath);
                this.OnFileSystemEntryChange(e.FullPath);
                if ($.$$.System.IO.Directory.Exists(e.FullPath))
                {
                    try
                    {
                        var $en4 = $.$$.System.IO.Directory.EnumerateFileSystemEntries$1(e.FullPath, "*", 1/*SearchOption.AllDirectories*/).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var newLocation = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*string*/ let oldLocation = $.$$.System.IO.Path.Combine$3(e.OldFullPath, $.$$.System.String.Substring$1.call(newLocation, ((e.FullPath.length + 1) | 0)));
                                this.OnFileSystemEntryChange(oldLocation);
                                this.OnFileSystemEntryChange(newLocation);
                            }
                        }
                    }
                    catch(ex)
                    {
                    }
                }
            }
            /*void */ OnChanged(/*object*/ sender, /*FileSystemEventArgs*/ e)
            {
                this.OnFileSystemEntryChange(e.FullPath);
            }
            /*void */ OnError(/*object*/ sender, /*ErrorEventArgs*/ e)
            {
                var $en2 = this._filePathTokenLookup.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var path = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.ReportChangeForMatchedEntries(path);
                    }
                }
            }
            /*void */ OnFileSystemEntryChange(/*string*/ fullPath)
            {
                try
                {
                    /*var*/ let fileSystemInfo = new $.$$.System.IO.FileInfo().$ctor$6(fullPath);
                    if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileSystemInfo, this._filters))
                    {
                        return;
                    }
                    /*string*/ let relativePath = $.$$.System.String.Substring$1.call(fullPath, this._root.length);
                    this.ReportChangeForMatchedEntries(relativePath);
                }
                catch(ex)
                {
                }
            }
            /*void */ ReportChangeForMatchedEntries(/*string*/ path)
            {
                if ($.$$.System.String.IsNullOrEmpty(path))
                {
                    return;
                }
                path = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(path);
                /*bool*/ let matched = false;
                /*ChangeTokenInfo*/ let matchInfo;
                if (this._filePathTokenLookup.TryRemove$1(path, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                    matched = true;
                }
                var $en2 = this._wildcardTokenLookup.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var wildCardEntry = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*PatternMatchingResult*/ let matchResult = $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$3(wildCardEntry.Value.Matcher, path);
                        if (matchResult.HasMatches && this._wildcardTokenLookup.TryRemove$1(wildCardEntry.Key, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                        {
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                            matched = true;
                        }
                    }
                }
                if (matched)
                {
                    this.TryDisableFileSystemWatcher();
                }
            }
            /*void */ TryDisableFileSystemWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if (this._filePathTokenLookup.IsEmpty && this._wildcardTokenLookup.IsEmpty && this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            /*void */ TryEnableFileSystemWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._fileWatcherLock)
                        {
                            if ((!this._filePathTokenLookup.IsEmpty || !this._wildcardTokenLookup.IsEmpty) && !this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            static /*string */ NormalizePath(/*string*/ filter)
            {
                return $.$$.System.String.Replace.call(filter, /*\\*/ 92, /*/*/ 47);
            }
            static /*bool */ IsDirectoryPath(/*string*/ path)
            {
                return path.length > 0 && ($.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.System.IO.Path.DirectorySeparatorChar || $.$$.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$$.System.IO.Path.AltDirectorySeparatorChar);
            }
            static /*void */ CancelToken(/*ChangeTokenInfo*/ matchInfo)
            {
                if (matchInfo.TokenSource.IsCancellationRequested)
                {
                    return;
                }
                $.$$.System.Threading.Tasks.Task.Factory.StartNew$4($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher._cancelTokenSource, matchInfo.TokenSource, $.$$.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$$.System.Threading.Tasks.TaskScheduler.Default);
            }
            static /*void */ RaiseChangeEvents(/*object?*/ state)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(state !== null, "state != null");
                /*var*/ let changeTokens = $.$cast(state, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken));
                var $en2 = changeTokens.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*IPollingChangeToken*/ let token = item.Key;
                        if (!token.Microsoft$Extensions$Primitives$IChangeToken$HasChanged)
                        {
                            continue;
                        }
                        if (!changeTokens.TryRemove$1(token, $.$discardRef()))
                        {
                            continue;
                        }
                        try
                        {
                            token.Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
            }
            static $_ChangeTokenInfo;
            static get ChangeTokenInfo()
            {
                let $cls = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                return $cls.$_ChangeTokenInfo ??= $asm.$nstr("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo", ($self) => class ChangeTokenInfo extends $.$$.System.ValueType
                {
                    $ctor$4(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken)
                    {
                        this.$ctor$3(tokenSource, changeToken, null);
                        {
                        }
                        return this;
                    }
                    $ctor$3(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken, /*Matcher?*/ matcher)
                    {
                        super.$ctor$1();
                        {
                            this.TokenSource = tokenSource;
                            this.ChangeToken = changeToken;
                            this.Matcher = matcher;
                        }
                        return this;
                    }
                    /*CancellationTokenSource*/ TokenSource = null;
                    /*CancellationChangeToken*/ ChangeToken = null;
                    /*Matcher?*/ Matcher = null;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TokenSource = this.TokenSource;
                        copy.ChangeToken = this.ChangeToken;
                        copy.Matcher = this.Matcher;
                        return copy;
                    }
                    static $h = 786459;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":125960193,"g":{"r":0,"d":0,"h":21475622939,"f":50331649},"n":"TokenSource","d":786459,"h":17180655643,"f":2097153},{"p":196610,"g":{"r":0,"d":0,"h":34360524827,"f":50331649},"n":"ChangeToken","d":786459,"h":30065557531,"f":2097153},{"p":2424860,"g":{"r":0,"d":0,"h":47245426715,"f":50331649},"n":"Matcher","d":786459,"h":42950459419,"f":2097153}],"c":[{"p":[{"n":"tokenSource","p":125960193},{"n":"changeToken","p":196610}],"n":".ctor","o":"$ctor$4","d":786459,"h":4295753755,"f":16777217},{"p":[{"n":"tokenSource","p":125960193},{"n":"changeToken","p":196610},{"n":"matcher","p":2424860}],"n":".ctor","o":"$ctor$3","d":786459,"h":8590721051,"f":16777217},{"n":".ctor","o":"$ctor$2","d":786459,"h":51540394011,"f":16777217}],"d":720923,"h":786459}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo`; }
                }, $cls, ($v) => $cls.$_ChangeTokenInfo = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._filePathTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                this._wildcardTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$$.System.StringComparer.OrdinalIgnoreCase);
                this._fileWatcherLock = new $.$$.System.Object().$ctor();
                this._timerLock = new $.$$.System.Object().$ctor();
                this.PollForChanges = false;
                this.UseActivePolling = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._cancelTokenSource = new ($.$$.System.Action$$($.$$.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$$.System.Threading.CancellationTokenSource)).Cancel();
                    }, {"r":65537,"p":[{"n":"state","p":131073}],"n":"","d":720923,"h":0,"f":17825794});
                }
                {
                    this.DefaultPollingInterval = $.$$.System.TimeSpan.FromSeconds$2(4n);
                }
            }
            static $h = 720923;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":77310132251,"f":50331656},"n":"PollForChanges","d":720923,"h":73015164955,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":90195034139,"f":50331656},"s":{"r":0,"d":0,"h":94490001435,"f":83886088},"n":"UseActivePolling","d":720923,"h":85900066843,"f":2097160},{"p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken).$h,"g":{"r":0,"d":0,"h":107374903323,"f":50331656},"n":"PollingChangeTokens","d":720923,"h":103079936027,"f":2097160}],"m":[{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"CreateFileChangeToken","d":720923,"h":111669870619,"f":16777217},{"r":720898,"p":[{"n":"pattern","p":1310721}],"n":"GetOrAddChangeToken","d":720923,"h":115964837915,"f":16777218},{"r":720898,"p":[{"n":"filePath","p":1310721}],"n":"GetOrAddFilePathChangeToken","d":720923,"h":120259805211,"f":16777224},{"r":720898,"p":[{"n":"pattern","p":1310721}],"n":"GetOrAddWildcardChangeToken","d":720923,"h":124554772507,"f":16777224},{"r":65537,"n":"Dispose","d":720923,"h":128849739803,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":720923,"h":133144707099,"f":16777348},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":565611}],"n":"OnRenamed","d":720923,"h":137439674395,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":237931}],"n":"OnChanged","d":720923,"h":141734641691,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":106859}],"n":"OnError","d":720923,"h":146029608987,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"fullPath","p":1310721}],"n":"OnFileSystemEntryChange","d":720923,"h":150324576283,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"path","p":1310721}],"n":"ReportChangeForMatchedEntries","d":720923,"h":154619543579,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"TryDisableFileSystemWatcher","d":720923,"h":158914510875,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"TryEnableFileSystemWatcher","d":720923,"h":163209478171,"f":16777218,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"wasi","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":1310721,"p":[{"n":"filter","p":1310721}],"n":"NormalizePath","d":720923,"h":167504445467,"f":16777250},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"IsDirectoryPath","d":720923,"h":171799412763,"f":16777250},{"r":65537,"p":[{"n":"matchInfo","p":786459}],"n":"CancelToken","d":720923,"h":176094380059,"f":16777250},{"r":65537,"p":[{"n":"state","p":131073}],"n":"RaiseChangeEvents","d":720923,"h":180389347355,"f":16777256}],"l":[{"t":$.$$.System.Action$$($.$$.System.Object).$h,"n":"_cancelTokenSource","d":720923,"h":4295688219,"f":4194338},{"t":140574721,"n":"DefaultPollingInterval","d":720923,"h":8590655515,"f":4194344},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,"n":"_filePathTokenLookup","d":720923,"h":12885622811,"f":4194306},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,"n":"_wildcardTokenLookup","d":720923,"h":17180590107,"f":4194306},{"t":369003,"n":"_fileWatcher","d":720923,"h":21475557403,"f":4194306},{"t":131073,"n":"_fileWatcherLock","d":720923,"h":25770524699,"f":4194306},{"t":1310721,"n":"_root","d":720923,"h":30065491995,"f":4194306},{"t":327707,"n":"_filters","d":720923,"h":34360459291,"f":4194306},{"t":138412033,"n":"_timer","d":720923,"h":38655426587,"f":4194306},{"t":262145,"n":"_timerInitialized","d":720923,"h":42950393883,"f":4194306},{"t":131073,"n":"_timerLock","d":720923,"h":47245361179,"f":4194306},{"t":$.$$.System.Func$$($.$$.System.Threading.Timer).$h,"n":"_timerFactory","d":720923,"h":51540328475,"f":4194306},{"t":262145,"n":"_disposed","d":720923,"h":55835295771,"f":4194306}],"c":[{"p":[{"n":"root","p":1310721},{"n":"fileSystemWatcher","p":369003},{"n":"pollForChanges","p":262145}],"n":".ctor","o":"$ctor$2","d":720923,"h":60130263067,"f":16777217},{"p":[{"n":"root","p":1310721},{"n":"fileSystemWatcher","p":369003},{"n":"pollForChanges","p":262145},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$1","d":720923,"h":64425230363,"f":16777217}],"i":[57540609],"j":[786459],"h":720923}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken", ($self) => class PollingFileChangeToken extends $.$$.System.Object
        {
            /*FileInfo*/ _fileInfo = null;
            /*DateTime*/ _previousWriteTimeUtc;
            /*DateTime*/ _lastCheckedTimeUtc;
            /*bool*/ _hasChanged = false;
            /*CancellationTokenSource?*/ _tokenSource = null;
            /*CancellationChangeToken?*/ _changeToken = null;
            $ctor$1(/*FileInfo*/ fileInfo)
            {
                super.$ctor();
                {
                    this._fileInfo = fileInfo;
                    this._previousWriteTimeUtc = this.GetLastWriteTimeUtc();
                }
                return this;
            }
            /*TimeSpan*/ static PollingInterval;
            /*DateTime */ GetLastWriteTimeUtc()
            {
                this._fileInfo.Refresh();
                if (!this._fileInfo.Exists)
                {
                    return $.$$.System.DateTime.MinValue;
                }
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(this._fileInfo) ?? this._fileInfo.LastWriteTimeUtc;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            /*bool */ get HasChanged()
            {
                if (this._hasChanged)
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let currentTime = $.$$.System.DateTime.UtcNow;
                if ($.$$.System.TimeSpan.op_LessThan($.$$.System.DateTime.op_Subtraction(currentTime, this._lastCheckedTimeUtc), $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken.PollingInterval))
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteTimeUtc();
                if ($.$$.System.DateTime.op_Inequality(this._previousWriteTimeUtc, lastWriteTimeUtc))
                {
                    this._previousWriteTimeUtc = lastWriteTimeUtc;
                    this._hasChanged = true;
                }
                this._lastCheckedTimeUtc = currentTime;
                return this._hasChanged;
            }
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._previousWriteTimeUtc = $.$default($.$$.System.DateTime);
                this._lastCheckedTimeUtc = $.$default($.$$.System.DateTime);
                this.ActiveChangeCallbacks = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
                }
            }
            static $h = 851995;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140574721,"g":{"r":0,"d":0,"h":42950524955,"f":50331688},"s":{"r":0,"d":0,"h":47245492251,"f":83886120},"n":"PollingInterval","d":851995,"h":38655557659,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":64425361435,"f":50331649},"s":{"r":0,"d":0,"h":68720328731,"f":83886088},"n":"ActiveChangeCallbacks","d":851995,"h":60130394139,"f":2097153},{"p":125960193,"g":{"r":0,"d":0,"h":77310263323,"f":50331656},"s":{"r":0,"d":0,"h":81605230619,"f":83886088},"n":"CancellationTokenSource","d":851995,"h":73015296027,"f":2097160},{"p":125960193,"g":{"r":0,"d":0,"h":90195165211,"f":50331650},"n":"{196635}.CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":851995,"h":85900197915,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":98785099803,"f":50331649},"n":"HasChanged","d":851995,"h":94490132507,"f":2097153}],"m":[{"r":34275329,"n":"GetLastWriteTimeUtc","d":851995,"h":51540459547,"f":16777218},{"r":57540609,"p":[{"n":"callback","p":$.$$.System.Action$$($.$$.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":851995,"h":103080067099,"f":16777217}],"l":[{"t":59899905,"n":"_fileInfo","d":851995,"h":4295819291,"f":4194306},{"t":34275329,"n":"_previousWriteTimeUtc","d":851995,"h":8590786587,"f":4194306},{"t":34275329,"n":"_lastCheckedTimeUtc","d":851995,"h":12885753883,"f":4194306},{"t":262145,"n":"_hasChanged","d":851995,"h":17180721179,"f":4194306},{"t":125960193,"n":"_tokenSource","d":851995,"h":21475688475,"f":4194306},{"t":196610,"n":"_changeToken","d":851995,"h":25770655771,"f":4194306}],"c":[{"p":[{"n":"fileInfo","p":59899905}],"n":".ctor","o":"$ctor$1","d":851995,"h":30065623067,"f":16777217}],"i":[196635,720898],"h":851995}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider", ($self) => class PhysicalFileProvider extends $.$$.System.Object
        {
            /*string*/ static PollingEnvironmentKey = null;
            /*char[]*/ static _pathSeparators = null;
            /*ExclusionFilters*/ _filters = 0;
            /*Func<PhysicalFilesWatcher>*/ _fileWatcherFactory = null;
            /*PhysicalFilesWatcher?*/ _fileWatcher = null;
            /*bool*/ _fileWatcherInitialized = false;
            /*object*/ _fileWatcherLock = null;
            /*bool?*/ _usePollingFileWatcher = null;
            /*bool?*/ _useActivePolling = null;
            /*bool*/ _disposed = false;
            $ctor$2(/*string*/ root)
            {
                this.$ctor$1(root, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ root, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    if (!$.$$.System.IO.Path.IsPathRooted$1(root))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13("The path must be absolute.", "root");
                    }
                    /*string*/ let fullRoot = $.$$.System.IO.Path.GetFullPath$1(root);
                    this.Root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash(fullRoot);
                    if (!$.$$.System.IO.Directory.Exists(this.Root))
                    {
                        throw new $.$$.System.IO.DirectoryNotFoundException().$ctor$17(this.Root);
                    }
                    this._filters = filters;
                    this._fileWatcherFactory = new ($.$$.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher))().$ctor(this, this.CreateFileWatcher);
                }
                return this;
            }
            /*bool */ get UsePollingFileWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    return false;
                }
                if (this._usePollingFileWatcher === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return this._usePollingFileWatcher ?? false;
            }
            /*bool */ set UsePollingFileWatcher(value)
            {
                if (this._fileWatcher !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.Format$6($.$mefp.System.SR.CannotModifyWhenFileWatcherInitialized, "UsePollingFileWatcher"));
                }
                this._usePollingFileWatcher = value;
            }
            /*bool */ get UseActivePolling()
            {
                if (this._useActivePolling === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return $.$$.System.Nullable$$($.$$.System.Boolean).Value$get.call(this._useActivePolling);
            }
            /*bool */ set UseActivePolling(value)
            {
                this._useActivePolling = value;
            }
            /*PhysicalFilesWatcher */ get FileWatcher()
            {
                return $.$$.System.Threading.LazyInitializer.EnsureInitialized$1($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher, $.$ref(() => this._fileWatcher, ($v) => this._fileWatcher = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => this._fileWatcherInitialized, ($v) => this._fileWatcherInitialized = $v, null), $.$ref(() => this._fileWatcherLock, ($v) => this._fileWatcherLock = $v, $.$$.System.Object), this._fileWatcherFactory);
            }
            /*PhysicalFilesWatcher */ set FileWatcher(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!this._fileWatcherInitialized, "!_fileWatcherInitialized");
                this._fileWatcherInitialized = true;
                this._fileWatcher = value;
            }
            /*PhysicalFilesWatcher */ CreateFileWatcher()
            {
                /*string*/ let root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash($.$$.System.IO.Path.GetFullPath$1(this.Root));
                /*FileSystemWatcher?*/ let watcher;
                if ($.$$.System.OperatingSystem.IsBrowser() || $.$$.System.OperatingSystem.IsWasi() || ($.$$.System.OperatingSystem.IsIOS() && !$.$$.System.OperatingSystem.IsMacCatalyst()) || $.$$.System.OperatingSystem.IsTvOS())
                {
                    this.UsePollingFileWatcher = true;
                    this.UseActivePolling = true;
                    watcher = null;
                }
                else 
                {
                    watcher = this.UsePollingFileWatcher && this.UseActivePolling ? null : new $.$sifw.System.IO.FileSystemWatcher().$ctor$5(root);
                }
                return (() =>
                {
                    //new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher()
                    const $t1 = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                    const $i1 = new $t1();
                    $i1.$ctor$1(root, watcher, this.UsePollingFileWatcher, this._filters);
                    $i1.UseActivePolling = this.UseActivePolling;
                    return $i1;
                })();
            }
            /*void */ ReadPollingEnvironmentVariables()
            {
                /*string?*/ let environmentValue = $.$$.System.Environment.GetEnvironmentVariable$1("DOTNET_USE_POLLING_FILE_WATCHER"/*PollingEnvironmentKey*/);
                /*bool*/ let pollForChanges = $.$$.System.String.Equals$2(environmentValue, "1", 4/*StringComparison.Ordinal*/) || $.$$.System.String.Equals$2(environmentValue, "true", 5/*StringComparison.OrdinalIgnoreCase*/);
                this._usePollingFileWatcher = pollForChanges;
                this._useActivePolling = pollForChanges;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            /*string*/ Root = null;
            /*string? */ GetFullPath(/*string*/ path)
            {
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(path))
                {
                    return null;
                }
                /*string*/ let fullPath;
                try
                {
                    fullPath = $.$$.System.IO.Path.GetFullPath$1($.$$.System.IO.Path.Combine$3(this.Root, path));
                }
                catch($e)
                {
                    return null;
                }
                if (!this.IsUnderneathRoot(fullPath))
                {
                    return null;
                }
                return fullPath;
            }
            /*bool */ IsUnderneathRoot(/*string*/ fullPath)
            {
                return $.$$.System.String.StartsWith$2.call(fullPath, this.Root, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                if ($.$$.System.String.IsNullOrEmpty(subpath) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                subpath = $.$$.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                if ($.$$.System.IO.Path.IsPathRooted$1(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*string?*/ let fullPath = this.GetFullPath(subpath);
                if ($.$$.System.String.op_Equality(fullPath, null))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*var*/ let fileInfo = new $.$$.System.IO.FileInfo().$ctor$6(fullPath);
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileInfo, this._filters))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(fileInfo);
            }
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                try
                {
                    if ($.$$.System.String.op_Equality(subpath, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    subpath = $.$$.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                    if ($.$$.System.IO.Path.IsPathRooted$1(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    /*string?*/ let fullPath = this.GetFullPath(subpath);
                    if ($.$$.System.String.op_Equality(fullPath, null) || !$.$$.System.IO.Directory.Exists(fullPath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    return new $.$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents().$ctor$1(fullPath, this._filters);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.IO.DirectoryNotFoundException)
                    {
                    }
                    else if ($e instanceof $.$$.System.IO.IOException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
            }
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                if ($.$$.System.String.op_Equality(filter, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidFilterChars(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                filter = $.$$.System.String.TrimStart$2.call(filter, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                return this.FileWatcher.CreateFileChangeToken(filter);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo()
            {
                return this.GetFileInfo(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents()
            {
                return this.GetDirectoryContents(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            Microsoft$Extensions$FileProviders$IFileProvider$Watch()
            {
                return this.Watch(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._fileWatcherLock = new $.$$.System.Object().$ctor();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PollingEnvironmentKey = "DOTNET_USE_POLLING_FILE_WATCHER";
                }
                {
                    this._pathSeparators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [$.$$.System.IO.Path.DirectorySeparatorChar, $.$$.System.IO.Path.AltDirectorySeparatorChar], null, null);
                }
            }
            static $h = 983067;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":60130525211,"f":50331649},"s":{"r":0,"d":0,"h":64425492507,"f":83886081},"n":"UsePollingFileWatcher","d":983067,"h":55835557915,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73015427099,"f":50331649},"s":{"r":0,"d":0,"h":77310394395,"f":83886081},"n":"UseActivePolling","d":983067,"h":68720459803,"f":2097153},{"p":720923,"g":{"r":0,"d":0,"h":85900328987,"f":50331656},"s":{"r":0,"d":0,"h":90195296283,"f":83886088},"n":"FileWatcher","d":983067,"h":81605361691,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":120260067355,"f":50331649},"n":"Root","d":983067,"h":115965100059,"f":2097153}],"m":[{"r":720923,"n":"CreateFileWatcher","d":983067,"h":94490263579,"f":16777224},{"r":65537,"n":"ReadPollingEnvironmentVariables","d":983067,"h":98785230875,"f":16777218},{"r":65537,"n":"Dispose","d":983067,"h":103080198171,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":983067,"h":107375165467,"f":16777348},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFullPath","d":983067,"h":124555034651,"f":16777218},{"r":262145,"p":[{"n":"fullPath","p":1310721}],"n":"IsUnderneathRoot","d":983067,"h":128850001947,"f":16777218},{"r":196634,"p":[{"n":"subpath","p":1310721}],"n":"GetFileInfo","d":983067,"h":133144969243,"f":16777217},{"r":131098,"p":[{"n":"subpath","p":1310721}],"n":"GetDirectoryContents","d":983067,"h":137439936539,"f":16777217},{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"Watch","d":983067,"h":141734903835,"f":16777217}],"l":[{"t":1310721,"n":"PollingEnvironmentKey","d":983067,"h":4295950363,"f":4194338},{"t":$.$typeArray($.$$.System.Char).$h,"n":"_pathSeparators","d":983067,"h":8590917659,"f":4194338},{"t":327707,"n":"_filters","d":983067,"h":12885884955,"f":4194306},{"t":$.$$.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher).$h,"n":"_fileWatcherFactory","d":983067,"h":17180852251,"f":4194306},{"t":720923,"n":"_fileWatcher","d":983067,"h":21475819547,"f":4194306},{"t":262145,"n":"_fileWatcherInitialized","d":983067,"h":25770786843,"f":4194306},{"t":131073,"n":"_fileWatcherLock","d":983067,"h":30065754139,"f":4194306},{"t":$.$typeNullable($.$$.System.Boolean).$h,"n":"_usePollingFileWatcher","d":983067,"h":34360721435,"f":4194306},{"t":$.$typeNullable($.$$.System.Boolean).$h,"n":"_useActivePolling","d":983067,"h":38655688731,"f":4194306},{"t":262145,"n":"_disposed","d":983067,"h":42950656027,"f":4194306}],"c":[{"p":[{"n":"root","p":1310721}],"n":".ctor","o":"$ctor$2","d":983067,"h":47245623323,"f":16777217},{"p":[{"n":"root","p":1310721},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$1","d":983067,"h":51540590619,"f":16777217}],"i":[262170,57540609],"h":983067}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.PhysicalFileProvider`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken", ($self) => class PollingWildCardChangeToken extends $.$$.System.Object
        {
            /*object*/ _enumerationLock = null;
            /*DirectoryInfoBase*/ _directoryInfo = null;
            /*Matcher*/ _matcher = null;
            /*bool*/ _changed = false;
            /*DateTime*/ _lastScanTimeUtc;
            /*byte[]?*/ _previousHash = null;
            /*CancellationTokenSource?*/ _tokenSource = null;
            /*CancellationChangeToken?*/ _changeToken = null;
            $ctor$1(/*string*/ root, /*string*/ pattern)
            {
                this.$ctor$2(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(new $.$$.System.IO.DirectoryInfo().$ctor$5(root)), pattern, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock.Instance);
                {
                }
                return this;
            }
            $ctor$2(/*DirectoryInfoBase*/ directoryInfo, /*string*/ pattern, /*IClock*/ clock)
            {
                super.$ctor();
                {
                    this._directoryInfo = directoryInfo;
                    this.Clock = clock;
                    this._matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/);
                    this._matcher.AddInclude(pattern);
                    this.CalculateChanges();
                }
                return this;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*TimeSpan*/ PollingInterval;
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            /*IClock*/ Clock = null;
            /*bool */ get HasChanged()
            {
                if (this._changed)
                {
                    return true;
                }
                if (ShouldRefresh.call(this))
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._enumerationLock)
                        {
                            if (!this._changed && ShouldRefresh.call(this))
                            {
                                this._changed = this.CalculateChanges();
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._enumerationLock)
                    }
                }
                return this._changed;
                /*bool*/  function ShouldRefresh()
                {
                    return $.$$.System.TimeSpan.op_GreaterThanOrEqual($.$$.System.DateTime.op_Subtraction(this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow, this._lastScanTimeUtc), this.PollingInterval);
                }
            }
            /*bool */ CalculateChanges()
            {
                /*PatternMatchingResult*/ let result = this._matcher.Execute(this._directoryInfo);
                /*IOrderedEnumerable<FilePatternMatch>*/ let files = $.$sl.System.Linq.Enumerable.OrderBy($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$$.System.String, result.Files, new ($.$$.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$$.System.String))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Path;
                }, {"r":1310721,"p":[{"n":"f","p":393244}],"n":"","d":917531,"h":0,"f":17825794}), $.$$.System.StringComparer.Ordinal);
                let sha256 = null;
                try
                {
                    sha256 = $.$sscr.System.Security.Cryptography.IncrementalHash.CreateHash($.$sscr.System.Security.Cryptography.HashAlgorithmName.SHA256);
                    var $en3 = files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var file = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteUtc(file.Path);
                            if (this._lastScanTimeUtc.Ticks !== 0n && $.$$.System.DateTime.op_LessThan(this._lastScanTimeUtc, lastWriteTimeUtc))
                            {
                                return true;
                            }
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken.ComputeHash(sha256, file.Path, lastWriteTimeUtc);
                        }
                    }
                    /*Span<byte>*/ let currentHash = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, $.trunc(256 / 8), null);
                    sha256.GetHashAndReset$1(currentHash);
                    if (this._previousHash === null)
                    {
                        this._previousHash = currentHash.ToArray();
                    }
                    else if (!$.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, this._previousHash)), $.$$.System.Span$$($.$$.System.Byte).op_Implicit(currentHash)))
                    {
                        return true;
                    }
                    this._lastScanTimeUtc = this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow;
                }
                finally
                {
                    sha256?.System$IDisposable$Dispose();
                }
                return false;
            }
            /*DateTime */ GetLastWriteUtc(/*string*/ path)
            {
                /*string*/ let filePath = $.$$.System.IO.Path.Combine$3(this._directoryInfo.FullName, path);
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc$1(filePath) ?? $.$$.System.IO.File.GetLastWriteTimeUtc$1(filePath);
            }
            static /*void */ ComputeHash(/*IncrementalHash*/ sha256, /*string*/ path, /*DateTime*/ lastChangedUtc)
            {
                sha256.AppendData$2($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(path)));
                sha256.AppendData$2($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.DateTime, $.$$.System.ReadOnlySpan$$($.$$.System.DateTime).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.DateTime), [lastChangedUtc], null, null))));
            }
            /*IDisposable */ Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //default member initializer
            constructor()
            {
                super();
                this._enumerationLock = new $.$$.System.Object().$ctor();
                this._lastScanTimeUtc = $.$default($.$$.System.DateTime);
                this.ActiveChangeCallbacks = false;
                this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
            }
            static $h = 917531;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":55835492379,"f":50331649},"s":{"r":0,"d":0,"h":60130459675,"f":83886088},"n":"ActiveChangeCallbacks","d":917531,"h":51540525083,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":73015361563,"f":50331656},"s":{"r":0,"d":0,"h":77310328859,"f":83886088},"n":"PollingInterval","d":917531,"h":68720394267,"f":2097160},{"p":125960193,"g":{"r":0,"d":0,"h":85900263451,"f":50331656},"s":{"r":0,"d":0,"h":90195230747,"f":83886088},"n":"CancellationTokenSource","d":917531,"h":81605296155,"f":2097160},{"p":125960193,"g":{"r":0,"d":0,"h":98785165339,"f":50331650},"n":"{196635}.CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":917531,"h":94490198043,"f":2097154},{"p":458779,"g":{"r":0,"d":0,"h":111670067227,"f":50331650},"n":"Clock","d":917531,"h":107375099931,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":120260001819,"f":50331649},"n":"HasChanged","d":917531,"h":115965034523,"f":2097153}],"m":[{"r":262145,"n":"CalculateChanges","d":917531,"h":124554969115,"f":16777218},{"r":34275329,"p":[{"n":"path","p":1310721}],"n":"GetLastWriteUtc","d":917531,"h":128849936411,"f":16777348},{"r":65537,"p":[{"n":"sha256","p":12432143},{"n":"path","p":1310721},{"n":"lastChangedUtc","p":34275329}],"n":"ComputeHash","d":917531,"h":133144903707,"f":16777250}],"l":[{"t":131073,"n":"_enumerationLock","d":917531,"h":4295884827,"f":4194306},{"t":65564,"n":"_directoryInfo","d":917531,"h":8590852123,"f":4194306},{"t":2424860,"n":"_matcher","d":917531,"h":12885819419,"f":4194306},{"t":262145,"n":"_changed","d":917531,"h":17180786715,"f":4194306},{"t":34275329,"n":"_lastScanTimeUtc","d":917531,"h":21475754011,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_previousHash","d":917531,"h":25770721307,"f":4194306},{"t":125960193,"n":"_tokenSource","d":917531,"h":30065688603,"f":4194306},{"t":196610,"n":"_changeToken","d":917531,"h":34360655899,"f":4194306}],"c":[{"p":[{"n":"root","p":1310721},{"n":"pattern","p":1310721}],"n":".ctor","o":"$ctor$1","d":917531,"h":38655623195,"f":16777217},{"p":[{"n":"directoryInfo","p":65564},{"n":"pattern","p":1310721},{"n":"clock","p":458779}],"n":".ctor","o":"$ctor$2","d":917531,"h":42950590491,"f":16777224}],"i":[196635,720898],"h":917531}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents", ($self) => class PhysicalDirectoryContents extends $.$$.System.Object
        {
            /*PhysicalDirectoryInfo*/ _info = null;
            $ctor$2(/*string*/ directory)
            {
                this.$ctor$1(directory, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ directory, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(directory, "directory");
                    this._info = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$1(new $.$$.System.IO.DirectoryInfo().$ctor$5(directory), filters);
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                return this._info.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this._info.GetEnumerator();
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 131099;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21474967579,"f":50331649},"n":"Exists","d":131099,"h":17180000283,"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"GetEnumerator","d":131099,"h":25769934875,"f":16777217}],"l":[{"t":589851,"n":"_info","d":131099,"h":4295098395,"f":4194306}],"c":[{"p":[{"n":"directory","p":1310721}],"n":".ctor","o":"$ctor$2","d":131099,"h":8590065691,"f":16777217},{"p":[{"n":"directory","p":1310721},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$1","d":131099,"h":12885032987,"f":16777217}],"i":[131098,$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31719425],"h":131099}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo", ($self) => class PhysicalDirectoryInfo extends $.$$.System.Object
        {
            /*DirectoryInfo*/ _info = null;
            /*IEnumerable<IFileInfo>?*/ _entries = null;
            /*ExclusionFilters*/ _filters = 0;
            $ctor$2(/*DirectoryInfo*/ info)
            {
                super.$ctor();
                {
                    this._info = info;
                }
                return this;
            }
            $ctor$1(/*DirectoryInfo*/ info, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    this._info = info;
                    this._filters = filters;
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            /*string */ get Name()
            {
                return this._info.Name;
            }
            /*DateTimeOffset */ get LastModified()
            {
                return $.$$.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            /*bool */ get IsDirectory()
            {
                return true;
            }
            /*Stream */ CreateReadStream()
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.CannotCreateStream);
            }
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            /*void */ EnsureInitialized()
            {
                try
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$sl.System.Linq.Enumerable.Where($.$$.System.IO.FileSystemInfo, this._info.EnumerateFileSystemInfos(), new ($.$$.System.Func$$$($.$$.System.IO.FileSystemInfo, $.$$.System.Boolean))().$ctor(this,  (/*info*/ info) =>
                    {
                        return !$.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(info, this._filters);
                    }, {"r":262145,"p":[{"n":"info","p":60555265}],"n":"","d":589851,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo))().$ctor(this,  (/*info*/ info) =>
                    {
                        return (() =>
                        {
                            {
                                let file;
                                if ((file = info, $.$is(file, $.$$.System.IO.FileInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(file);
                                }
                            }
                            {
                                let dir;
                                if ((dir = info, $.$is(dir, $.$$.System.IO.DirectoryInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$2(dir);
                                }
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$mefp.System.SR.UnexpectedFileSystemInfo);
                        })();
                    }, {"r":196634,"p":[{"n":"info","p":60555265}],"n":"","d":589851,"h":0,"f":17825794}));
                }
                catch(ex)
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Empty($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo);
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                return this.Length;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                return this.PhysicalPath;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                return this.IsDirectory;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                return this.CreateReadStream(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 589851;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065360923,"f":50331649},"n":"Exists","d":589851,"h":25770393627,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":38655295515,"f":50331649},"n":"Length","d":589851,"h":34360328219,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47245230107,"f":50331649},"n":"PhysicalPath","d":589851,"h":42950262811,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55835164699,"f":50331649},"n":"Name","d":589851,"h":51540197403,"f":2097153},{"p":34471937,"g":{"r":0,"d":0,"h":64425099291,"f":50331649},"n":"LastModified","d":589851,"h":60130131995,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73015033883,"f":50331649},"n":"IsDirectory","d":589851,"h":68720066587,"f":2097153}],"m":[{"r":62193665,"n":"CreateReadStream","d":589851,"h":77310001179,"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"GetEnumerator","d":589851,"h":81604968475,"f":16777217},{"r":65537,"n":"EnsureInitialized","d":589851,"h":90194903067,"f":16777218}],"l":[{"t":58720257,"n":"_info","d":589851,"h":4295557147,"f":4194306},{"t":$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"_entries","d":589851,"h":8590524443,"f":4194306},{"t":327707,"n":"_filters","d":589851,"h":12885491739,"f":4194306}],"c":[{"p":[{"n":"info","p":58720257}],"n":".ctor","o":"$ctor$2","d":589851,"h":17180459035,"f":16777217},{"p":[{"n":"info","p":58720257},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$1","d":589851,"h":21475426331,"f":16777224}],"i":[196634,131098,$.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31719425],"h":589851}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$$.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo`; }
        });
        
        $asm.$str("$mefp.Microsoft.Extensions.FileProviders.Physical.ExclusionFilters", ($self) => class ExclusionFilters extends $.$$.System.Enum
        {
            static Sensitive = 7;
            static DotPrefixed = 1;
            static Hidden = 2;
            static System = 4;
            static None = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Sensitive": 7n,
                    "DotPrefixed": 1n,
                    "Hidden": 2n,
                    "System": 4n,
                    "None": 0n
                };
            }
            static $h = 327707;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":327707,"n":"Sensitive","d":327707,"h":4295295003,"f":4194337},{"t":327707,"n":"DotPrefixed","d":327707,"h":8590262299,"f":4194337},{"t":327707,"n":"Hidden","d":327707,"h":12885229595,"f":4194337},{"t":327707,"n":"System","d":327707,"h":17180196891,"f":4194337},{"t":327707,"n":"None","d":327707,"h":21475164187,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":327707,"h":25770131483,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":327707,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.ExclusionFilters`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.FileSystem.Watcher", "NetJs.System.Net.Primitives", "NetJs.System.Security.Cryptography"))