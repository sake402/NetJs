
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $mep, $sr, $scc, $scn, $scm, $so, $srn, $sris, $scp, $sfa, $sic, $sim, $sl, $snp, $sifw, $mefa, $mef, $sci, $srm, $sds, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileProviders.Physical", 
    {"h":27,"f":"Microsoft.Extensions.FileProviders.Physical","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.FileProviders.Physical.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"DynamicProxyGenAssembly2, PublicKey=0024000004800000940000000602000000240000525341310004000001000100c547cac37abd99c8db225ef2f6c8a3602f3b3606cc9891605d02baa56104f4cfc0734aa39b93bf7852f7d9266654753cc297e7d2edfe0bac1cdcf9f717241550e0a7b191195b7667bb4f64bcb8e2121380fd1d9d46ad2d92d2d15605093924cceaf74c4861eff62abf69b9291ed0a340e113be11e6a7d3113e92484cf7045cc7","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Physical","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.FileProviders.Physical","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.IClock", ($self) => class IClock
        {
            static $h = 458779;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":34144257,"g":{"r":0,"d":0,"h":8590393371,"f":257},"n":"UtcNow","o":"Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow","d":458779,"h":4295426075,"f":257}],"h":458779}; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.IClock`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken", ($self) => class IPollingChangeToken
        {
            static $h = 196635;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":126091265,"g":{"r":0,"d":0,"h":8590131227,"f":257},"n":"CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":196635,"h":4295163931,"f":257}],"i":[720898],"h":196635}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.IPollingChangeToken`; }
        });
        
        $asm.$cls("$mefp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mefp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileProviders.Physical", $.$mefp.System.SR.$type.Assembly);
                    $.$mefp.System.SR.s_resourceManager = temp;
                }
                return $.$mefp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mefp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mefp.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get ArgumentOutOfRange_NeedNonNegNum()
            {
                return "Non-negative number required.";
            }
            static /*string */ get Error_FileSystemWatcherRequiredWithoutPolling()
            {
                return "The fileSystemWatcher parameter must be non-null when pollForChanges is false.";
            }
            static /*string */ get CannotCreateStream()
            {
                return "Cannot create a stream for a directory.";
            }
            static /*string */ get CannotModifyWhenFileWatcherInitialized()
            {
                return "Cannot modify {0} once file watcher has been initialized.";
            }
            static /*string */ FormatCannotModifyWhenFileWatcherInitialized(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot modify {0} once file watcher has been initialized.", arg1);
            }
            static /*string */ get Cryptography_HashAlgorithmNameNullOrEmpty()
            {
                return "The hash algorithm name cannot be null or empty.";
            }
            static /*string */ get UnexpectedFileSystemInfo()
            {
                return "Unexpected type of FileSystemInfo";
            }
            static /*string */ get FileSystemWatcher_PlatformNotSupported()
            {
                return "The type '{0}' is not supported on this platform, use polling instead.";
            }
            static /*string */ FormatFileSystemWatcher_PlatformNotSupported(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The type '{0}' is not supported on this platform, use polling instead.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mefp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mefp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mefp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mefp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mefp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mefp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1114139;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1114139}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.Internal.NonCapturingTimer", ($self) => class NonCapturingTimer
        {
            static /*Timer */ Create(/*TimerCallback*/ callback, /*object*/ state, /*TimeSpan*/ dueTime, /*TimeSpan*/ period)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(callback, "callback");
                /*bool*/ let restoreFlow = false;
                try
                {
                    if (!$.$spc.System.Threading.ExecutionContext.IsFlowSuppressed())
                    {
                        $.$spc.System.Threading.ExecutionContext.SuppressFlow();
                        restoreFlow = true;
                    }
                    return new $.$spc.System.Threading.Timer().$ctor$4(callback, state, dueTime, period);
                }
                finally
                {
                    {
                        if (restoreFlow)
                        {
                            $.$spc.System.Threading.ExecutionContext.RestoreFlow();
                        }
                    }
                }
            }
            static $h = 1048603;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":138543105,"p":[{"n":"callback","p":138608641},{"n":"state","p":131073},{"n":"dueTime","p":140705793},{"n":"period","p":140705793}],"n":"Create","d":1048603,"h":4296015899,"f":33}],"h":1048603}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.NonCapturingTimer`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper", ($self) => class FileSystemInfoHelper
        {
            static /*bool */ IsExcluded(/*FileSystemInfo*/ fileSystemInfo, /*ExclusionFilters*/ filters)
            {
                if (filters === 0/*ExclusionFilters.None*/)
                {
                    return false;
                }
                else if ($.$spc.System.String.StartsWith$1.call(fileSystemInfo.Name, ".", 4/*StringComparison.Ordinal*/) && (filters & 1/*ExclusionFilters.DotPrefixed*/) !== 0)
                {
                    return true;
                }
                else if (fileSystemInfo.Exists && (((fileSystemInfo.Attributes & 2/*FileAttributes.Hidden*/) !== 0 && (filters & 2/*ExclusionFilters.Hidden*/) !== 0) || ((fileSystemInfo.Attributes & 4/*FileAttributes.System*/) !== 0 && (filters & 4/*ExclusionFilters.System*/) !== 0)))
                {
                    return true;
                }
                return false;
            }
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc(/*string*/ filePath)
            {
                /*var*/ let fileInfo = new $.$spc.System.IO.FileInfo().$ctor$5(filePath);
                if (fileInfo.Exists)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc$1(fileInfo);
                }
                return null;
            }
            static /*DateTime? */ GetFileLinkTargetLastWriteTimeUtc$1(/*FileInfo*/ fileInfo)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(fileInfo.Exists, "fileInfo.Exists");
                if ($.$spc.System.String.op_Inequality(fileInfo.LinkTarget, null))
                {
                    try
                    {
                        /*FileSystemInfo?*/ let targetInfo = fileInfo.ResolveLinkTarget(true);
                        if (targetInfo !== null && targetInfo.Exists)
                        {
                            return targetInfo.LastWriteTimeUtc;
                        }
                    }
                    catch(ex)
                    {
                    }
                    return $.$spc.System.DateTime.MinValue;
                }
                return null;
            }
            static $h = 393243;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"fileSystemInfo","p":60489729},{"n":"filters","p":327707}],"n":"IsExcluded","d":393243,"h":4295360539,"f":33},{"r":$.$typeNullable($.$spc.System.DateTime).$h,"p":[{"n":"filePath","p":1310721}],"n":"GetFileLinkTargetLastWriteTimeUtc","d":393243,"h":8590327835,"f":33},{"r":$.$typeNullable($.$spc.System.DateTime).$h,"p":[{"n":"fileInfo","p":59834369}],"n":"GetFileLinkTargetLastWriteTimeUtc","o":"@$1","d":393243,"h":12885295131,"f":33}],"h":393243}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils", ($self) => class PathUtils
        {
            static /*char[] */ GetInvalidFileNameChars()
            {
                return $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Char, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Char, $.$spc.System.IO.Path.GetInvalidFileNameChars(), new ($.$spc.System.Func$$$($.$spc.System.Char, $.$spc.System.Boolean))().$ctor(this,  (/*c*/ c) =>
                {
                    return c !== $.$spc.System.IO.Path.DirectorySeparatorChar && c !== $.$spc.System.IO.Path.AltDirectorySeparatorChar;
                })));
            }
            static /*char[] */ GetInvalidFilterChars()
            {
                return $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Char, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Char, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars(), new ($.$spc.System.Func$$$($.$spc.System.Char, $.$spc.System.Boolean))().$ctor(this,  (/**/ c) =>
                {
                    return c !== /***/ 42 && c !== /*|*/ 124 && c !== /*?*/ 63;
                })));
            }
            /*SearchValues<char>*/ static _invalidFileNameChars = null;
            /*SearchValues<char>*/ static _invalidFilterChars = null;
            static /*bool */ HasInvalidPathChars(/*string*/ path)
            {
                return $.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFileNameChars);
            }
            static /*bool */ HasInvalidFilterChars(/*string*/ path)
            {
                return $.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(path), $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._invalidFilterChars);
            }
            /*char[]*/ static _pathSeparators = null;
            static /*string */ EnsureTrailingSlash(/*string*/ path)
            {
                if (!$.$spc.System.String.IsNullOrEmpty(path) && $.$spc.System.String.get_Chars.call(path, ((path.length - 1) | 0)) !== $.$spc.System.IO.Path.DirectorySeparatorChar)
                {
                    return path + $.$spc.System.IO.Path.DirectorySeparatorChar;
                }
                return path;
            }
            static /*bool */ PathNavigatesAboveRoot(/*string*/ path)
            {
                /*var*/ let tokenizer = new $.$mep.Microsoft.Extensions.Primitives.StringTokenizer().$ctor$2(path, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils._pathSeparators);
                /*int*/ let depth = 0;
                var $en2 = tokenizer.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var segment = $en2.Current;
                    {
                        if (segment.Equals$5(".") || segment.Equals$5(""))
                        {
                            continue;
                        }
                        else if (segment.Equals$5(".."))
                        {
                            depth--;
                            if (depth === -1)
                            {
                                return true;
                            }
                        }
                        else 
                        {
                            depth++;
                        }
                    }
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._invalidFileNameChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFileNameChars()));
                }
                {
                    this._invalidFilterChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).op_Implicit($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.GetInvalidFilterChars()));
                }
                {
                    this._pathSeparators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [$.$spc.System.IO.Path.DirectorySeparatorChar, $.$spc.System.IO.Path.AltDirectorySeparatorChar], null, null);
                }
            }
            static $h = 524315;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":0,"n":"GetInvalidFileNameChars","d":524315,"h":4295491611,"f":34},{"r":0,"n":"GetInvalidFilterChars","d":524315,"h":8590458907,"f":34},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"HasInvalidPathChars","d":524315,"h":21475360795,"f":40},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"HasInvalidFilterChars","d":524315,"h":25770328091,"f":40},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"EnsureTrailingSlash","d":524315,"h":34360262683,"f":40},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"PathNavigatesAboveRoot","d":524315,"h":38655229979,"f":40}],"l":[{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"_invalidFileNameChars","d":524315,"h":12885426203,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"_invalidFilterChars","d":524315,"h":17180393499,"f":34},{"t":0,"n":"_pathSeparators","d":524315,"h":30065295387,"f":34}],"h":524315}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable", ($self) => class EmptyDisposable extends $.$spc.System.Object
        {
            /*EmptyDisposable*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable().$ctor$1();
                }
            }
            static $h = 65563;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":65563,"g":{"r":0,"d":0,"h":12884967451,"f":33},"n":"Instance","d":65563,"h":8590000155,"f":33}],"m":[{"r":65537,"n":"Dispose","d":65563,"h":21474902043,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":65563,"h":17179934747,"f":2}],"i":[57475073],"h":65563}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.EmptyDisposable`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo", ($self) => class PhysicalFileInfo extends $.$spc.System.Object
        {
            /*FileInfo*/ _info = null;
            $ctor$1(/*FileInfo*/ info)
            {
                super.$ctor();
                {
                    this._info = info;
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*long */ get Length()
            {
                return this._info.Length;
            }
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            /*string */ get Name()
            {
                return this._info.Name;
            }
            /*DateTimeOffset */ get LastModified()
            {
                return $.$spc.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            /*bool */ get IsDirectory()
            {
                return false;
            }
            /*Stream */ CreateReadStream()
            {
                /*int*/ let bufferSize = 1;
                return new $.$spc.System.IO.FileStream().$ctor$15(this.PhysicalPath, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 3/*FileShare.ReadWrite*/, bufferSize, 1073741824/*FileOptions.Asynchronous*/ | 134217728/*FileOptions.SequentialScan*/);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                return this.Length;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                return this.PhysicalPath;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                return this.IsDirectory;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                return this.CreateReadStream(...arguments);
            }
            static $h = 655387;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180524571,"f":1},"n":"Exists","d":655387,"h":12885557275,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25770459163,"f":1},"n":"Length","d":655387,"h":21475491867,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360393755,"f":1},"n":"PhysicalPath","d":655387,"h":30065426459,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950328347,"f":1},"n":"Name","d":655387,"h":38655361051,"f":1},{"p":34340865,"g":{"r":0,"d":0,"h":51540262939,"f":1},"n":"LastModified","d":655387,"h":47245295643,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60130197531,"f":1},"n":"IsDirectory","d":655387,"h":55835230235,"f":1}],"m":[{"r":62128129,"n":"CreateReadStream","d":655387,"h":64425164827,"f":1}],"l":[{"t":59834369,"n":"_info","d":655387,"h":4295622683,"f":2}],"c":[{"p":[{"n":"info","p":59834369}],"n":".ctor","o":"$ctor$1","d":655387,"h":8590589979,"f":1}],"i":[196634],"h":655387}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher", ($self) => class PhysicalFilesWatcher extends $.$spc.System.Object
        {
            /*Action<object?>*/ static _cancelTokenSource = null;
            /*TimeSpan*/ static DefaultPollingInterval;
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _filePathTokenLookup = null;
            /*ConcurrentDictionary<string, ChangeTokenInfo>*/ _wildcardTokenLookup = null;
            /*FileSystemWatcher?*/ _fileWatcher = null;
            /*object*/ _fileWatcherLock = null;
            /*string*/ _root = null;
            /*ExclusionFilters*/ _filters = 0;
            /*Timer?*/ _timer = null;
            /*bool*/ _timerInitialized = false;
            /*object*/ _timerLock = null;
            /*Func<Timer>*/ _timerFactory = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges)
            {
                this.$ctor$2(root, fileSystemWatcher, pollForChanges, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ root, /*FileSystemWatcher?*/ fileSystemWatcher, /*bool*/ pollForChanges, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    if (fileSystemWatcher === null && !pollForChanges)
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$18("fileSystemWatcher", $.$mefp.System.SR.Error_FileSystemWatcherRequiredWithoutPolling);
                    }
                    this._root = root;
                    if (fileSystemWatcher !== null)
                    {
                        if ($.$spc.System.OperatingSystem.IsBrowser() || $.$spc.System.OperatingSystem.IsWasi() || ($.$spc.System.OperatingSystem.IsIOS() && !$.$spc.System.OperatingSystem.IsMacCatalyst()) || $.$spc.System.OperatingSystem.IsTvOS())
                        {
                            throw new $.$spc.System.PlatformNotSupportedException().$ctor$14($.$mefp.System.SR.Format($.$mefp.System.SR.FileSystemWatcher_PlatformNotSupported, $.$sifw.System.IO.FileSystemWatcher.$type));
                        }
                        this._fileWatcher = fileSystemWatcher;
                        this._fileWatcher.IncludeSubdirectories = true;
                        this._fileWatcher.Created$add(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.Changed$add(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.Renamed$add(new $.$sifw.System.IO.RenamedEventHandler().$ctor(this, this.OnRenamed));
                        this._fileWatcher.Deleted$add(new $.$sifw.System.IO.FileSystemEventHandler().$ctor(this, this.OnChanged));
                        this._fileWatcher.Error$add(new $.$sifw.System.IO.ErrorEventHandler().$ctor(this, this.OnError));
                    }
                    this.PollForChanges = pollForChanges;
                    this._filters = filters;
                    this.PollingChangeTokens = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken))().$ctor$1();
                    this._timerFactory = new ($.$spc.System.Func$$($.$spc.System.Threading.Timer))().$ctor(this,  () =>
                    {
                        return $.$mefp.Microsoft.Extensions.Internal.NonCapturingTimer.Create(new $.$spc.System.Threading.TimerCallback().$ctor(null, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.RaiseChangeEvents), this.PollingChangeTokens, $.$spc.System.TimeSpan.Zero, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval);
                    });
                }
                return this;
            }
            /*bool*/ PollForChanges = false;
            /*bool*/ UseActivePolling = false;
            /*ConcurrentDictionary<IPollingChangeToken, IPollingChangeToken>*/ PollingChangeTokens = null;
            /*IChangeToken */ CreateFileChangeToken(/*string*/ filter)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(filter, "filter");
                filter = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(filter);
                if ($.$spc.System.IO.Path.IsPathRooted(filter) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                /*IChangeToken*/ let changeToken = this.GetOrAddChangeToken(filter);
                this.TryEnableFileSystemWatcher();
                return changeToken;
            }
            /*IChangeToken */ GetOrAddChangeToken(/*string*/ pattern)
            {
                if (this.UseActivePolling)
                {
                    $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$spc.System.Threading.Timer, $.$ref(() => this._timer, ($v) => this._timer = $v, $.$spc.System.Threading.Timer), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._timerInitialized, ($v) => this._timerInitialized = $v, null), $.$ref(() => this._timerLock, ($v) => this._timerLock = $v, $.$spc.System.Object), this._timerFactory);
                }
                /*IChangeToken*/ let changeToken;
                /*bool*/ let isWildCard = $.$spc.System.String.Contains$2.call(pattern, /***/ 42);
                if (isWildCard || $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.IsDirectoryPath(pattern))
                {
                    changeToken = this.GetOrAddWildcardChangeToken(pattern);
                }
                else 
                {
                    changeToken = this.GetOrAddFilePathChangeToken(pattern);
                }
                return changeToken;
            }
            /*IChangeToken */ GetOrAddFilePathChangeToken(/*string*/ filePath)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._filePathTokenLookup.TryGetValue(filePath, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$2(cancellationTokenSource, cancellationChangeToken);
                    tokenInfo = this._filePathTokenLookup.GetOrAdd$2(filePath, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken().$ctor$1(new $.$spc.System.IO.FileInfo().$ctor$5($.$spc.System.IO.Path.Combine(this._root, filePath)));
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            /*IChangeToken */ GetOrAddWildcardChangeToken(/*string*/ pattern)
            {
                /*ChangeTokenInfo*/ let tokenInfo;
                if (!this._wildcardTokenLookup.TryGetValue(pattern, $.$ref(() => tokenInfo, ($v) => tokenInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    /*var*/ let cancellationTokenSource = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                    /*var*/ let cancellationChangeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(cancellationTokenSource.Token);
                    /*var*/ let matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$2(5/*StringComparison.OrdinalIgnoreCase*/);
                    matcher.AddInclude(pattern);
                    tokenInfo = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo().$ctor$3(cancellationTokenSource, cancellationChangeToken, matcher);
                    tokenInfo = this._wildcardTokenLookup.GetOrAdd$2(pattern, tokenInfo);
                }
                /*IChangeToken*/ let changeToken = tokenInfo.ChangeToken;
                if (this.PollForChanges)
                {
                    /*var*/ let pollingChangeToken = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken().$ctor$1(this._root, pattern);
                    if (this.UseActivePolling)
                    {
                        pollingChangeToken.ActiveChangeCallbacks = true;
                        pollingChangeToken.CancellationTokenSource = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                        this.PollingChangeTokens.TryAdd(pollingChangeToken, pollingChangeToken);
                    }
                    changeToken = new $.$mep.Microsoft.Extensions.Primitives.CompositeChangeToken().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$mep.Microsoft.Extensions.Primitives.IChangeToken), [changeToken, pollingChangeToken], null, null));
                }
                return changeToken;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                        this._timer?.Dispose$1();
                    }
                    this._disposed = true;
                }
            }
            /*void */ OnRenamed(/*object*/ sender, /*RenamedEventArgs*/ e)
            {
                this.OnFileSystemEntryChange(e.OldFullPath);
                this.OnFileSystemEntryChange(e.FullPath);
                if ($.$spc.System.IO.Directory.Exists(e.FullPath))
                {
                    try
                    {
                        var $en4 = $.$spc.System.IO.Directory.EnumerateFileSystemEntries$2(e.FullPath, "*", 1/*SearchOption.AllDirectories*/).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var newLocation = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*string*/ let oldLocation = $.$spc.System.IO.Path.Combine(e.OldFullPath, $.$spc.System.String.Substring.call(newLocation, ((e.FullPath.length + 1) | 0)));
                                this.OnFileSystemEntryChange(oldLocation);
                                this.OnFileSystemEntryChange(newLocation);
                            }
                        }
                    }
                    catch(ex)
                    {
                    }
                }
            }
            /*void */ OnChanged(/*object*/ sender, /*FileSystemEventArgs*/ e)
            {
                this.OnFileSystemEntryChange(e.FullPath);
            }
            /*void */ OnError(/*object*/ sender, /*ErrorEventArgs*/ e)
            {
                var $en2 = this._filePathTokenLookup.Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var path = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.ReportChangeForMatchedEntries(path);
                    }
                }
            }
            /*void */ OnFileSystemEntryChange(/*string*/ fullPath)
            {
                try
                {
                    /*var*/ let fileSystemInfo = new $.$spc.System.IO.FileInfo().$ctor$5(fullPath);
                    if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileSystemInfo, this._filters))
                    {
                        return;
                    }
                    /*string*/ let relativePath = $.$spc.System.String.Substring.call(fullPath, this._root.length);
                    this.ReportChangeForMatchedEntries(relativePath);
                }
                catch(ex)
                {
                }
            }
            /*void */ ReportChangeForMatchedEntries(/*string*/ path)
            {
                if ($.$spc.System.String.IsNullOrEmpty(path))
                {
                    return;
                }
                path = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.NormalizePath(path);
                /*bool*/ let matched = false;
                /*ChangeTokenInfo*/ let matchInfo;
                if (this._filePathTokenLookup.TryRemove(path, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                {
                    $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                    matched = true;
                }
                var $en2 = this._wildcardTokenLookup.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var wildCardEntry = $en2.Current;
                    {
                        /*PatternMatchingResult*/ let matchResult = $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match(wildCardEntry.Value.Matcher, path);
                        if (matchResult.HasMatches && this._wildcardTokenLookup.TryRemove(wildCardEntry.Key, $.$ref(() => matchInfo, ($v) => matchInfo = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo)))
                        {
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.CancelToken(matchInfo);
                            matched = true;
                        }
                    }
                }
                if (matched)
                {
                    this.TryDisableFileSystemWatcher();
                }
            }
            /*void */ TryDisableFileSystemWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._fileWatcherLock)
                        {
                            if (this._filePathTokenLookup.IsEmpty && this._wildcardTokenLookup.IsEmpty && this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            /*void */ TryEnableFileSystemWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._fileWatcherLock)
                        {
                            if ((!this._filePathTokenLookup.IsEmpty || !this._wildcardTokenLookup.IsEmpty) && !this._fileWatcher.EnableRaisingEvents)
                            {
                                this._fileWatcher.EnableRaisingEvents = true;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._fileWatcherLock)
                    }
                }
            }
            static /*string */ NormalizePath(/*string*/ filter)
            {
                return $.$spc.System.String.Replace$2.call(filter, /*\\*/ 92, /*/*/ 47);
            }
            static /*bool */ IsDirectoryPath(/*string*/ path)
            {
                return path.length > 0 && ($.$spc.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$spc.System.IO.Path.DirectorySeparatorChar || $.$spc.System.String.get_Chars.call(path, ((path.length - 1) | 0)) === $.$spc.System.IO.Path.AltDirectorySeparatorChar);
            }
            static /*void */ CancelToken(/*ChangeTokenInfo*/ matchInfo)
            {
                if (matchInfo.TokenSource.IsCancellationRequested)
                {
                    return;
                }
                $.$spc.System.Threading.Tasks.Task.Factory.StartNew$7($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher._cancelTokenSource, matchInfo.TokenSource, $.$spc.System.Threading.CancellationToken.None, 8/*TaskCreationOptions.DenyChildAttach*/, $.$spc.System.Threading.Tasks.TaskScheduler.Default);
            }
            static /*void */ RaiseChangeEvents(/*object?*/ state)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(state !== null, "state != null");
                /*var*/ let changeTokens = $.$cast(state, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken));
                var $en2 = changeTokens.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*IPollingChangeToken*/ let token = item.Key;
                        if (!token.Microsoft$Extensions$Primitives$IChangeToken$HasChanged)
                        {
                            continue;
                        }
                        if (!changeTokens.TryRemove(token, $.$discardRef()))
                        {
                            continue;
                        }
                        try
                        {
                            token.Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource.Cancel();
                        }
                        catch($e)
                        {
                        }
                    }
                }
            }
            static $_ChangeTokenInfo;
            static get ChangeTokenInfo()
            {
                let $cls = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                return $cls.$_ChangeTokenInfo ??= $asm.$nstr("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo", ($self) => class ChangeTokenInfo extends $.$spc.System.ValueType
                {
                    $ctor$2(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken)
                    {
                        this.$ctor$3(tokenSource, changeToken, null);
                        {
                        }
                        return this;
                    }
                    $ctor$3(/*CancellationTokenSource*/ tokenSource, /*CancellationChangeToken*/ changeToken, /*Matcher?*/ matcher)
                    {
                        super.$ctor$1();
                        {
                            this.TokenSource = tokenSource;
                            this.ChangeToken = changeToken;
                            this.Matcher = matcher;
                        }
                        return this;
                    }
                    /*CancellationTokenSource*/ TokenSource = null;
                    /*CancellationChangeToken*/ ChangeToken = null;
                    /*Matcher?*/ Matcher = null;
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.TokenSource = this.TokenSource;
                        copy.ChangeToken = this.ChangeToken;
                        copy.Matcher = this.Matcher;
                        return copy;
                    }
                    static $h = 786459;
                    static $z = 12;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":126091265,"g":{"r":0,"d":0,"h":21475622939,"f":1},"n":"TokenSource","d":786459,"h":17180655643,"f":1},{"p":196610,"g":{"r":0,"d":0,"h":34360524827,"f":1},"n":"ChangeToken","d":786459,"h":30065557531,"f":1},{"p":2424860,"g":{"r":0,"d":0,"h":47245426715,"f":1},"n":"Matcher","d":786459,"h":42950459419,"f":1}],"c":[{"p":[{"n":"tokenSource","p":126091265},{"n":"changeToken","p":196610}],"n":".ctor","o":"$ctor$2","d":786459,"h":4295753755,"f":1},{"p":[{"n":"tokenSource","p":126091265},{"n":"changeToken","p":196610},{"n":"matcher","p":2424860}],"n":".ctor","o":"$ctor$3","d":786459,"h":8590721051,"f":1},{"n":".ctor","o":"$ctor$4","d":786459,"h":51540394011,"f":1}],"d":720923,"h":786459}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo`; }
                }, $cls, ($v) => $cls.$_ChangeTokenInfo = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._filePathTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$spc.System.StringComparer.OrdinalIgnoreCase);
                this._wildcardTokenLookup = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo))().$ctor$4($.$spc.System.StringComparer.OrdinalIgnoreCase);
                this._fileWatcherLock = new $.$spc.System.Object().$ctor();
                this._timerLock = new $.$spc.System.Object().$ctor();
                this.PollForChanges = false;
                this.UseActivePolling = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._cancelTokenSource = new ($.$spc.System.Action$$($.$spc.System.Object))().$ctor(this,  (/*state*/ state) =>
                    {
                        return ($.$cast(state, $.$spc.System.Threading.CancellationTokenSource)).Cancel();
                    });
                }
                {
                    this.DefaultPollingInterval = $.$spc.System.TimeSpan.FromSeconds(4n);
                }
            }
            static $h = 720923;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":77310132251,"f":8},"n":"PollForChanges","d":720923,"h":73015164955,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":90195034139,"f":8},"s":{"r":0,"d":0,"h":94490001435,"f":8},"n":"UseActivePolling","d":720923,"h":85900066843,"f":8},{"p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken).$h,"g":{"r":0,"d":0,"h":107374903323,"f":8},"n":"PollingChangeTokens","d":720923,"h":103079936027,"f":8}],"m":[{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"CreateFileChangeToken","d":720923,"h":111669870619,"f":1},{"r":720898,"p":[{"n":"pattern","p":1310721}],"n":"GetOrAddChangeToken","d":720923,"h":115964837915,"f":2},{"r":720898,"p":[{"n":"filePath","p":1310721}],"n":"GetOrAddFilePathChangeToken","d":720923,"h":120259805211,"f":8},{"r":720898,"p":[{"n":"pattern","p":1310721}],"n":"GetOrAddWildcardChangeToken","d":720923,"h":124554772507,"f":8},{"r":65537,"n":"Dispose","d":720923,"h":128849739803,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":720923,"h":133144707099,"f":132},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":560677}],"n":"OnRenamed","d":720923,"h":137439674395,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":232997}],"n":"OnChanged","d":720923,"h":141734641691,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":101925}],"n":"OnError","d":720923,"h":146029608987,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"fullPath","p":1310721}],"n":"OnFileSystemEntryChange","d":720923,"h":150324576283,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"path","p":1310721}],"n":"ReportChangeForMatchedEntries","d":720923,"h":154619543579,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"TryDisableFileSystemWatcher","d":720923,"h":158914510875,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"TryEnableFileSystemWatcher","d":720923,"h":163209478171,"f":2,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"wasi","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":1310721,"p":[{"n":"filter","p":1310721}],"n":"NormalizePath","d":720923,"h":167504445467,"f":34},{"r":262145,"p":[{"n":"path","p":1310721}],"n":"IsDirectoryPath","d":720923,"h":171799412763,"f":34},{"r":65537,"p":[{"n":"matchInfo","p":786459}],"n":"CancelToken","d":720923,"h":176094380059,"f":34},{"r":65537,"p":[{"n":"state","p":131073}],"n":"RaiseChangeEvents","d":720923,"h":180389347355,"f":40}],"l":[{"t":$.$spc.System.Action$$($.$spc.System.Object).$h,"n":"_cancelTokenSource","d":720923,"h":4295688219,"f":34},{"t":140705793,"n":"DefaultPollingInterval","d":720923,"h":8590655515,"f":40},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,"n":"_filePathTokenLookup","d":720923,"h":12885622811,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.ChangeTokenInfo).$h,"n":"_wildcardTokenLookup","d":720923,"h":17180590107,"f":2},{"t":364069,"n":"_fileWatcher","d":720923,"h":21475557403,"f":2},{"t":131073,"n":"_fileWatcherLock","d":720923,"h":25770524699,"f":2},{"t":1310721,"n":"_root","d":720923,"h":30065491995,"f":2},{"t":327707,"n":"_filters","d":720923,"h":34360459291,"f":2},{"t":138543105,"n":"_timer","d":720923,"h":38655426587,"f":2},{"t":262145,"n":"_timerInitialized","d":720923,"h":42950393883,"f":2},{"t":131073,"n":"_timerLock","d":720923,"h":47245361179,"f":2},{"t":$.$spc.System.Func$$($.$spc.System.Threading.Timer).$h,"n":"_timerFactory","d":720923,"h":51540328475,"f":2},{"t":262145,"n":"_disposed","d":720923,"h":55835295771,"f":2}],"c":[{"p":[{"n":"root","p":1310721},{"n":"fileSystemWatcher","p":364069},{"n":"pollForChanges","p":262145}],"n":".ctor","o":"$ctor$1","d":720923,"h":60130263067,"f":1},{"p":[{"n":"root","p":1310721},{"n":"fileSystemWatcher","p":364069},{"n":"pollForChanges","p":262145},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$2","d":720923,"h":64425230363,"f":1}],"i":[57475073],"j":[786459],"h":720923}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.Clock", ($self) => class Clock extends $.$spc.System.Object
        {
            /*Clock*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*DateTime */ get UtcNow()
            {
                return $.$spc.System.DateTime.UtcNow;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.Physical.IClock.UtcNow.get
            get Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow()
            {
                return this.UtcNow;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock().$ctor$1();
                }
            }
            static $h = 262171;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34144257,"g":{"r":0,"d":0,"h":17180131355,"f":1},"n":"UtcNow","d":262171,"h":12885164059,"f":1}],"l":[{"t":262171,"n":"Instance","d":262171,"h":4295229467,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":262171,"h":8590196763,"f":2}],"i":[458779],"h":262171}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.Physical.IClock ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.Clock`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider", ($self) => class PhysicalFileProvider extends $.$spc.System.Object
        {
            /*string*/ static PollingEnvironmentKey = null;
            /*char[]*/ static _pathSeparators = null;
            /*ExclusionFilters*/ _filters = 0;
            /*Func<PhysicalFilesWatcher>*/ _fileWatcherFactory = null;
            /*PhysicalFilesWatcher?*/ _fileWatcher = null;
            /*bool*/ _fileWatcherInitialized = false;
            /*object*/ _fileWatcherLock = null;
            /*bool?*/ _usePollingFileWatcher = null;
            /*bool?*/ _useActivePolling = null;
            /*bool*/ _disposed = false;
            $ctor$1(/*string*/ root)
            {
                this.$ctor$2(root, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ root, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    if (!$.$spc.System.IO.Path.IsPathRooted(root))
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13("The path must be absolute.", "root");
                    }
                    /*string*/ let fullRoot = $.$spc.System.IO.Path.GetFullPath(root);
                    this.Root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash(fullRoot);
                    if (!$.$spc.System.IO.Directory.Exists(this.Root))
                    {
                        throw new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15(this.Root);
                    }
                    this._filters = filters;
                    this._fileWatcherFactory = new ($.$spc.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher))().$ctor(this, this.CreateFileWatcher);
                }
                return this;
            }
            /*bool */ get UsePollingFileWatcher()
            {
                if (this._fileWatcher !== null)
                {
                    return false;
                }
                if (this._usePollingFileWatcher === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return this._usePollingFileWatcher ?? false;
            }
            /*bool */ set UsePollingFileWatcher(value)
            {
                if (this._fileWatcher !== null)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mefp.System.SR.Format($.$mefp.System.SR.CannotModifyWhenFileWatcherInitialized, "UsePollingFileWatcher"));
                }
                this._usePollingFileWatcher = value;
            }
            /*bool */ get UseActivePolling()
            {
                if (this._useActivePolling === null)
                {
                    this.ReadPollingEnvironmentVariables();
                }
                return $.$spc.System.Nullable$$($.$spc.System.Boolean).Value$get.call(this._useActivePolling);
            }
            /*bool */ set UseActivePolling(value)
            {
                this._useActivePolling = value;
            }
            /*PhysicalFilesWatcher */ get FileWatcher()
            {
                return $.$spc.System.Threading.LazyInitializer.EnsureInitialized$3($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher, $.$ref(() => this._fileWatcher, ($v) => this._fileWatcher = $v, $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => this._fileWatcherInitialized, ($v) => this._fileWatcherInitialized = $v, null), $.$ref(() => this._fileWatcherLock, ($v) => this._fileWatcherLock = $v, $.$spc.System.Object), this._fileWatcherFactory);
            }
            /*PhysicalFilesWatcher */ set FileWatcher(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this._fileWatcherInitialized, "!_fileWatcherInitialized");
                this._fileWatcherInitialized = true;
                this._fileWatcher = value;
            }
            /*PhysicalFilesWatcher */ CreateFileWatcher()
            {
                /*string*/ let root = $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.EnsureTrailingSlash($.$spc.System.IO.Path.GetFullPath(this.Root));
                /*FileSystemWatcher?*/ let watcher;
                if ($.$spc.System.OperatingSystem.IsBrowser() || $.$spc.System.OperatingSystem.IsWasi() || ($.$spc.System.OperatingSystem.IsIOS() && !$.$spc.System.OperatingSystem.IsMacCatalyst()) || $.$spc.System.OperatingSystem.IsTvOS())
                {
                    this.UsePollingFileWatcher = true;
                    this.UseActivePolling = true;
                    watcher = null;
                }
                else 
                {
                    watcher = this.UsePollingFileWatcher && this.UseActivePolling ? null : new $.$sifw.System.IO.FileSystemWatcher().$ctor$4(root);
                }
                return (() =>
                {
                    //new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher()
                    const $t1 = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher;
                    const $i1 = new $t1();
                    $i1.$ctor$2(root, watcher, this.UsePollingFileWatcher, this._filters);
                    $i1.UseActivePolling = this.UseActivePolling;
                    return $i1;
                })();
            }
            /*void */ ReadPollingEnvironmentVariables()
            {
                /*string?*/ let environmentValue = $.$spc.System.Environment.GetEnvironmentVariable("DOTNET_USE_POLLING_FILE_WATCHER"/*PollingEnvironmentKey*/);
                /*bool*/ let pollForChanges = $.$spc.System.String.Equals$5(environmentValue, "1", 4/*StringComparison.Ordinal*/) || $.$spc.System.String.Equals$5(environmentValue, "true", 5/*StringComparison.OrdinalIgnoreCase*/);
                this._usePollingFileWatcher = pollForChanges;
                this._useActivePolling = pollForChanges;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._disposed)
                {
                    if (disposing)
                    {
                        this._fileWatcher?.Dispose();
                    }
                    this._disposed = true;
                }
            }
            /*string*/ Root = null;
            /*string? */ GetFullPath(/*string*/ path)
            {
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.PathNavigatesAboveRoot(path))
                {
                    return null;
                }
                /*string*/ let fullPath;
                try
                {
                    fullPath = $.$spc.System.IO.Path.GetFullPath($.$spc.System.IO.Path.Combine(this.Root, path));
                }
                catch($e)
                {
                    return null;
                }
                if (!this.IsUnderneathRoot(fullPath))
                {
                    return null;
                }
                return fullPath;
            }
            /*bool */ IsUnderneathRoot(/*string*/ fullPath)
            {
                return $.$spc.System.String.StartsWith$1.call(fullPath, this.Root, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            /*IFileInfo */ GetFileInfo(/*string*/ subpath)
            {
                if ($.$spc.System.String.IsNullOrEmpty(subpath) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                subpath = $.$spc.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                if ($.$spc.System.IO.Path.IsPathRooted(subpath))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*string?*/ let fullPath = this.GetFullPath(subpath);
                if ($.$spc.System.String.op_Equality(fullPath, null))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                /*var*/ let fileInfo = new $.$spc.System.IO.FileInfo().$ctor$5(fullPath);
                if ($.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(fileInfo, this._filters))
                {
                    return new $.$mefa.Microsoft.Extensions.FileProviders.NotFoundFileInfo().$ctor$1(subpath);
                }
                return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(fileInfo);
            }
            /*IDirectoryContents */ GetDirectoryContents(/*string*/ subpath)
            {
                try
                {
                    if ($.$spc.System.String.op_Equality(subpath, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidPathChars(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    subpath = $.$spc.System.String.TrimStart$2.call(subpath, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                    if ($.$spc.System.IO.Path.IsPathRooted(subpath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    /*string?*/ let fullPath = this.GetFullPath(subpath);
                    if ($.$spc.System.String.op_Equality(fullPath, null) || !$.$spc.System.IO.Directory.Exists(fullPath))
                    {
                        return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
                    }
                    return new $.$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents().$ctor$2(fullPath, this._filters);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.IO.DirectoryNotFoundException)
                    {
                    }
                    else if ($e instanceof $.$spc.System.IO.IOException)
                    {
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return $.$mefa.Microsoft.Extensions.FileProviders.NotFoundDirectoryContents.Singleton;
            }
            /*IChangeToken */ Watch(/*string*/ filter)
            {
                if ($.$spc.System.String.op_Equality(filter, null) || $.$mefp.Microsoft.Extensions.FileProviders.Physical.Internal.PathUtils.HasInvalidFilterChars(filter))
                {
                    return $.$mefa.Microsoft.Extensions.FileProviders.NullChangeToken.Singleton;
                }
                filter = $.$spc.System.String.TrimStart$2.call(filter, $.$mefp.Microsoft.Extensions.FileProviders.PhysicalFileProvider._pathSeparators);
                return this.FileWatcher.CreateFileChangeToken(filter);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetFileInfo(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetFileInfo()
            {
                return this.GetFileInfo(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.GetDirectoryContents(string)
            Microsoft$Extensions$FileProviders$IFileProvider$GetDirectoryContents()
            {
                return this.GetDirectoryContents(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileProvider.Watch(string)
            Microsoft$Extensions$FileProviders$IFileProvider$Watch()
            {
                return this.Watch(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._fileWatcherLock = new $.$spc.System.Object().$ctor();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PollingEnvironmentKey = "DOTNET_USE_POLLING_FILE_WATCHER";
                }
                {
                    this._pathSeparators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [$.$spc.System.IO.Path.DirectorySeparatorChar, $.$spc.System.IO.Path.AltDirectorySeparatorChar], null, null);
                }
            }
            static $h = 983067;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":60130525211,"f":1},"s":{"r":0,"d":0,"h":64425492507,"f":1},"n":"UsePollingFileWatcher","d":983067,"h":55835557915,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015427099,"f":1},"s":{"r":0,"d":0,"h":77310394395,"f":1},"n":"UseActivePolling","d":983067,"h":68720459803,"f":1},{"p":720923,"g":{"r":0,"d":0,"h":85900328987,"f":8},"s":{"r":0,"d":0,"h":90195296283,"f":8},"n":"FileWatcher","d":983067,"h":81605361691,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":120260067355,"f":1},"n":"Root","d":983067,"h":115965100059,"f":1}],"m":[{"r":720923,"n":"CreateFileWatcher","d":983067,"h":94490263579,"f":8},{"r":65537,"n":"ReadPollingEnvironmentVariables","d":983067,"h":98785230875,"f":2},{"r":65537,"n":"Dispose","d":983067,"h":103080198171,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":983067,"h":107375165467,"f":132},{"r":1310721,"p":[{"n":"path","p":1310721}],"n":"GetFullPath","d":983067,"h":124555034651,"f":2},{"r":262145,"p":[{"n":"fullPath","p":1310721}],"n":"IsUnderneathRoot","d":983067,"h":128850001947,"f":2},{"r":196634,"p":[{"n":"subpath","p":1310721}],"n":"GetFileInfo","d":983067,"h":133144969243,"f":1},{"r":131098,"p":[{"n":"subpath","p":1310721}],"n":"GetDirectoryContents","d":983067,"h":137439936539,"f":1},{"r":720898,"p":[{"n":"filter","p":1310721}],"n":"Watch","d":983067,"h":141734903835,"f":1}],"l":[{"t":1310721,"n":"PollingEnvironmentKey","d":983067,"h":4295950363,"f":34},{"t":0,"n":"_pathSeparators","d":983067,"h":8590917659,"f":34},{"t":327707,"n":"_filters","d":983067,"h":12885884955,"f":2},{"t":$.$spc.System.Func$$($.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher).$h,"n":"_fileWatcherFactory","d":983067,"h":17180852251,"f":2},{"t":720923,"n":"_fileWatcher","d":983067,"h":21475819547,"f":2},{"t":262145,"n":"_fileWatcherInitialized","d":983067,"h":25770786843,"f":2},{"t":131073,"n":"_fileWatcherLock","d":983067,"h":30065754139,"f":2},{"t":$.$typeNullable($.$spc.System.Boolean).$h,"n":"_usePollingFileWatcher","d":983067,"h":34360721435,"f":2},{"t":$.$typeNullable($.$spc.System.Boolean).$h,"n":"_useActivePolling","d":983067,"h":38655688731,"f":2},{"t":262145,"n":"_disposed","d":983067,"h":42950656027,"f":2}],"c":[{"p":[{"n":"root","p":1310721}],"n":".ctor","o":"$ctor$1","d":983067,"h":47245623323,"f":1},{"p":[{"n":"root","p":1310721},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$2","d":983067,"h":51540590619,"f":1}],"i":[262170,57475073],"h":983067}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileProvider, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.PhysicalFileProvider`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken", ($self) => class PollingFileChangeToken extends $.$spc.System.Object
        {
            /*FileInfo*/ _fileInfo = null;
            /*DateTime*/ _previousWriteTimeUtc;
            /*DateTime*/ _lastCheckedTimeUtc;
            /*bool*/ _hasChanged = false;
            /*CancellationTokenSource?*/ _tokenSource = null;
            /*CancellationChangeToken?*/ _changeToken = null;
            $ctor$1(/*FileInfo*/ fileInfo)
            {
                super.$ctor();
                {
                    this._fileInfo = fileInfo;
                    this._previousWriteTimeUtc = this.GetLastWriteTimeUtc();
                }
                return this;
            }
            /*TimeSpan*/ static PollingInterval;
            /*DateTime */ GetLastWriteTimeUtc()
            {
                this._fileInfo.Refresh();
                if (!this._fileInfo.Exists)
                {
                    return $.$spc.System.DateTime.MinValue;
                }
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc$1(this._fileInfo) ?? this._fileInfo.LastWriteTimeUtc;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            /*bool */ get HasChanged()
            {
                if (this._hasChanged)
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let currentTime = $.$spc.System.DateTime.UtcNow;
                if ($.$spc.System.TimeSpan.op_LessThan($.$spc.System.DateTime.op_Subtraction$1(currentTime, this._lastCheckedTimeUtc), $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken.PollingInterval))
                {
                    return this._hasChanged;
                }
                /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteTimeUtc();
                if ($.$spc.System.DateTime.op_Inequality(this._previousWriteTimeUtc, lastWriteTimeUtc))
                {
                    this._previousWriteTimeUtc = lastWriteTimeUtc;
                    this._hasChanged = true;
                }
                this._lastCheckedTimeUtc = currentTime;
                return this._hasChanged;
            }
            /*IDisposable */ RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.RegisterChangeCallback(System.Action<object?>, object?)
            Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback()
            {
                return this.RegisterChangeCallback(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._previousWriteTimeUtc = $.$default($.$spc.System.DateTime);
                this._lastCheckedTimeUtc = $.$default($.$spc.System.DateTime);
                this.ActiveChangeCallbacks = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
                }
            }
            static $h = 851995;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":140705793,"g":{"r":0,"d":0,"h":42950524955,"f":40},"s":{"r":0,"d":0,"h":47245492251,"f":40},"n":"PollingInterval","d":851995,"h":38655557659,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":64425361435,"f":1},"s":{"r":0,"d":0,"h":68720328731,"f":8},"n":"ActiveChangeCallbacks","d":851995,"h":60130394139,"f":1},{"p":126091265,"g":{"r":0,"d":0,"h":77310263323,"f":8},"s":{"r":0,"d":0,"h":81605230619,"f":8},"n":"CancellationTokenSource","d":851995,"h":73015296027,"f":8},{"p":126091265,"g":{"r":0,"d":0,"h":90195165211,"f":2},"n":"{196635}.CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":851995,"h":85900197915,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":98785099803,"f":1},"n":"HasChanged","d":851995,"h":94490132507,"f":1}],"m":[{"r":34144257,"n":"GetLastWriteTimeUtc","d":851995,"h":51540459547,"f":2},{"r":57475073,"p":[{"n":"callback","p":$.$spc.System.Action$$($.$spc.System.Object).$h},{"n":"state","p":131073}],"n":"RegisterChangeCallback","d":851995,"h":103080067099,"f":1}],"l":[{"t":59834369,"n":"_fileInfo","d":851995,"h":4295819291,"f":2},{"t":34144257,"n":"_previousWriteTimeUtc","d":851995,"h":8590786587,"f":2},{"t":34144257,"n":"_lastCheckedTimeUtc","d":851995,"h":12885753883,"f":2},{"t":262145,"n":"_hasChanged","d":851995,"h":17180721179,"f":2},{"t":126091265,"n":"_tokenSource","d":851995,"h":21475688475,"f":2},{"t":196610,"n":"_changeToken","d":851995,"h":25770655771,"f":2}],"c":[{"p":[{"n":"fileInfo","p":59834369}],"n":".ctor","o":"$ctor$1","d":851995,"h":30065623067,"f":1}],"i":[196635,720898],"h":851995}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingFileChangeToken`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken", ($self) => class PollingWildCardChangeToken extends $.$spc.System.Object
        {
            /*object*/ _enumerationLock = null;
            /*DirectoryInfoBase*/ _directoryInfo = null;
            /*Matcher*/ _matcher = null;
            /*bool*/ _changed = false;
            /*DateTime*/ _lastScanTimeUtc;
            /*byte[]?*/ _previousHash = null;
            /*CancellationTokenSource?*/ _tokenSource = null;
            /*CancellationChangeToken?*/ _changeToken = null;
            $ctor$1(/*string*/ root, /*string*/ pattern)
            {
                this.$ctor$2(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(new $.$spc.System.IO.DirectoryInfo().$ctor$4(root)), pattern, $.$mefp.Microsoft.Extensions.FileProviders.Physical.Clock.Instance);
                {
                }
                return this;
            }
            $ctor$2(/*DirectoryInfoBase*/ directoryInfo, /*string*/ pattern, /*IClock*/ clock)
            {
                super.$ctor();
                {
                    this._directoryInfo = directoryInfo;
                    this.Clock = clock;
                    this._matcher = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher().$ctor$2(5/*StringComparison.OrdinalIgnoreCase*/);
                    this._matcher.AddInclude(pattern);
                    this.CalculateChanges();
                }
                return this;
            }
            /*bool*/ ActiveChangeCallbacks = false;
            /*TimeSpan*/ PollingInterval;
            /*CancellationTokenSource? */ get CancellationTokenSource()
            {
                return this._tokenSource;
            }
            /*CancellationTokenSource? */ set CancellationTokenSource(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._tokenSource === null, "We expect CancellationTokenSource to be initialized exactly once.");
                this._tokenSource = value;
                this._changeToken = new $.$mep.Microsoft.Extensions.Primitives.CancellationChangeToken().$ctor$1(this._tokenSource.Token);
            }
            /*CancellationTokenSource? */ get Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource()
            {
                return this.CancellationTokenSource;
            }
            /*IClock*/ Clock = null;
            /*bool */ get HasChanged()
            {
                if (this._changed)
                {
                    return true;
                }
                if (ShouldRefresh.call(this))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this._enumerationLock)
                        {
                            if (!this._changed && ShouldRefresh.call(this))
                            {
                                this._changed = this.CalculateChanges();
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this._enumerationLock)
                    }
                }
                return this._changed;
                /*bool*/  function ShouldRefresh()
                {
                    return $.$spc.System.TimeSpan.op_GreaterThanOrEqual($.$spc.System.DateTime.op_Subtraction$1(this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow, this._lastScanTimeUtc), this.PollingInterval);
                }
            }
            /*bool */ CalculateChanges()
            {
                /*PatternMatchingResult*/ let result = this._matcher.Execute(this._directoryInfo);
                /*IOrderedEnumerable<FilePatternMatch>*/ let files = $.$sl.System.Linq.Enumerable.OrderBy$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$spc.System.String, result.Files, new ($.$spc.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, $.$spc.System.String))().$ctor(this,  (/*f*/ f) =>
                {
                    return f.Path;
                }), $.$spc.System.StringComparer.Ordinal);
                let sha256 = null;
                try
                {
                    sha256 = $.$sscr.System.Security.Cryptography.IncrementalHash.CreateHash($.$sscr.System.Security.Cryptography.HashAlgorithmName.SHA256);
                    var $en3 = files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var file = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*DateTime*/ let lastWriteTimeUtc = this.GetLastWriteUtc(file.Path);
                            if (this._lastScanTimeUtc.Ticks !== 0n && $.$spc.System.DateTime.op_LessThan(this._lastScanTimeUtc, lastWriteTimeUtc))
                            {
                                return true;
                            }
                            $.$mefp.Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken.ComputeHash(sha256, file.Path, lastWriteTimeUtc);
                        }
                    }
                    /*Span<byte>*/ let currentHash = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, $.trunc(256 / 8), null);
                    sha256.GetHashAndReset$1(currentHash);
                    if (this._previousHash === null)
                    {
                        this._previousHash = currentHash.ToArray();
                    }
                    else if (!$.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Byte, this._previousHash)), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(currentHash)))
                    {
                        return true;
                    }
                    this._lastScanTimeUtc = this.Clock.Microsoft$Extensions$FileProviders$Physical$IClock$UtcNow;
                }
                finally
                {
                    sha256?.System$IDisposable$Dispose();
                }
                return false;
            }
            /*DateTime */ GetLastWriteUtc(/*string*/ path)
            {
                /*string*/ let filePath = $.$spc.System.IO.Path.Combine(this._directoryInfo.FullName, path);
                return $.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.GetFileLinkTargetLastWriteTimeUtc(filePath) ?? $.$spc.System.IO.File.GetLastWriteTimeUtc(filePath);
            }
            static /*void */ ComputeHash(/*IncrementalHash*/ sha256, /*string*/ path, /*DateTime*/ lastChangedUtc)
            {
                sha256.AppendData$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(path)));
                sha256.AppendData$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$spc.System.DateTime, $.$spc.System.ReadOnlySpan$$($.$spc.System.DateTime).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.DateTime), [lastChangedUtc], null, null))));
            }
            /*IDisposable */ Microsoft$Extensions$Primitives$IChangeToken$RegisterChangeCallback(/*Action<object?>*/ callback, /*object?*/ state)
            {
                if (!this.ActiveChangeCallbacks)
                {
                    return $.$mefp.Microsoft.Extensions.FileProviders.EmptyDisposable.Instance;
                }
                return this._changeToken.RegisterChangeCallback(callback, state);
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.HasChanged.get
            get Microsoft$Extensions$Primitives$IChangeToken$HasChanged()
            {
                return this.HasChanged;
            }
            //Generated interface implemetation for Microsoft.Extensions.Primitives.IChangeToken.ActiveChangeCallbacks.get
            get Microsoft$Extensions$Primitives$IChangeToken$ActiveChangeCallbacks()
            {
                return this.ActiveChangeCallbacks;
            }
            //default member initializer
            constructor()
            {
                super();
                this._enumerationLock = new $.$spc.System.Object().$ctor();
                this._lastScanTimeUtc = $.$default($.$spc.System.DateTime);
                this.ActiveChangeCallbacks = false;
                this.PollingInterval = $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFilesWatcher.DefaultPollingInterval;
            }
            static $h = 917531;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":55835492379,"f":1},"s":{"r":0,"d":0,"h":60130459675,"f":8},"n":"ActiveChangeCallbacks","d":917531,"h":51540525083,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015361563,"f":8},"s":{"r":0,"d":0,"h":77310328859,"f":8},"n":"PollingInterval","d":917531,"h":68720394267,"f":8},{"p":126091265,"g":{"r":0,"d":0,"h":85900263451,"f":8},"s":{"r":0,"d":0,"h":90195230747,"f":8},"n":"CancellationTokenSource","d":917531,"h":81605296155,"f":8},{"p":126091265,"g":{"r":0,"d":0,"h":98785165339,"f":2},"n":"{196635}.CancellationTokenSource","o":"Microsoft$Extensions$FileProviders$IPollingChangeToken$CancellationTokenSource","d":917531,"h":94490198043,"f":2},{"p":458779,"g":{"r":0,"d":0,"h":111670067227,"f":2},"n":"Clock","d":917531,"h":107375099931,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":120260001819,"f":1},"n":"HasChanged","d":917531,"h":115965034523,"f":1}],"m":[{"r":262145,"n":"CalculateChanges","d":917531,"h":124554969115,"f":2},{"r":34144257,"p":[{"n":"path","p":1310721}],"n":"GetLastWriteUtc","d":917531,"h":128849936411,"f":132},{"r":65537,"p":[{"n":"sha256","p":12445886},{"n":"path","p":1310721},{"n":"lastChangedUtc","p":34144257}],"n":"ComputeHash","d":917531,"h":133144903707,"f":34}],"l":[{"t":131073,"n":"_enumerationLock","d":917531,"h":4295884827,"f":2},{"t":65564,"n":"_directoryInfo","d":917531,"h":8590852123,"f":2},{"t":2424860,"n":"_matcher","d":917531,"h":12885819419,"f":2},{"t":262145,"n":"_changed","d":917531,"h":17180786715,"f":2},{"t":34144257,"n":"_lastScanTimeUtc","d":917531,"h":21475754011,"f":2},{"t":0,"n":"_previousHash","d":917531,"h":25770721307,"f":2},{"t":126091265,"n":"_tokenSource","d":917531,"h":30065688603,"f":2},{"t":196610,"n":"_changeToken","d":917531,"h":34360655899,"f":2}],"c":[{"p":[{"n":"root","p":1310721},{"n":"pattern","p":1310721}],"n":".ctor","o":"$ctor$1","d":917531,"h":38655623195,"f":1},{"p":[{"n":"directoryInfo","p":65564},{"n":"pattern","p":1310721},{"n":"clock","p":458779}],"n":".ctor","o":"$ctor$2","d":917531,"h":42950590491,"f":8}],"i":[196635,720898],"h":917531}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefp.Microsoft.Extensions.FileProviders.IPollingChangeToken, $.$mep.Microsoft.Extensions.Primitives.IChangeToken ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PollingWildCardChangeToken`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents", ($self) => class PhysicalDirectoryContents extends $.$spc.System.Object
        {
            /*PhysicalDirectoryInfo*/ _info = null;
            $ctor$1(/*string*/ directory)
            {
                this.$ctor$2(directory, 7/*ExclusionFilters.Sensitive*/);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ directory, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(directory, "directory");
                    this._info = new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$2(new $.$spc.System.IO.DirectoryInfo().$ctor$4(directory), filters);
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                return this._info.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this._info.GetEnumerator();
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 131099;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21474967579,"f":1},"n":"Exists","d":131099,"h":17180000283,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"GetEnumerator","d":131099,"h":25769934875,"f":1}],"l":[{"t":589851,"n":"_info","d":131099,"h":4295098395,"f":2}],"c":[{"p":[{"n":"directory","p":1310721}],"n":".ctor","o":"$ctor$1","d":131099,"h":8590065691,"f":1},{"p":[{"n":"directory","p":1310721},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$2","d":131099,"h":12885032987,"f":1}],"i":[131098,$.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31588353],"h":131099}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Internal.PhysicalDirectoryContents`; }
        });
        
        $asm.$cls("$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo", ($self) => class PhysicalDirectoryInfo extends $.$spc.System.Object
        {
            /*DirectoryInfo*/ _info = null;
            /*IEnumerable<IFileInfo>?*/ _entries = null;
            /*ExclusionFilters*/ _filters = 0;
            $ctor$1(/*DirectoryInfo*/ info)
            {
                super.$ctor();
                {
                    this._info = info;
                }
                return this;
            }
            $ctor$2(/*DirectoryInfo*/ info, /*ExclusionFilters*/ filters)
            {
                super.$ctor();
                {
                    this._info = info;
                    this._filters = filters;
                }
                return this;
            }
            /*bool */ get Exists()
            {
                return this._info.Exists;
            }
            /*long */ get Length()
            {
                return BigInt(-1);
            }
            /*string */ get PhysicalPath()
            {
                return this._info.FullName;
            }
            /*string */ get Name()
            {
                return this._info.Name;
            }
            /*DateTimeOffset */ get LastModified()
            {
                return $.$spc.System.DateTimeOffset.op_Implicit(this._info.LastWriteTimeUtc);
            }
            /*bool */ get IsDirectory()
            {
                return true;
            }
            /*Stream */ CreateReadStream()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mefp.System.SR.CannotCreateStream);
            }
            /*IEnumerator<IFileInfo> */ GetEnumerator()
            {
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                this.EnsureInitialized();
                return this._entries.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$mefa.Microsoft.Extensions.FileProviders.IFileInfo]);
            }
            /*void */ EnsureInitialized()
            {
                try
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Select($.$spc.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$sl.System.Linq.Enumerable.Where($.$spc.System.IO.FileSystemInfo, this._info.EnumerateFileSystemInfos(), new ($.$spc.System.Func$$$($.$spc.System.IO.FileSystemInfo, $.$spc.System.Boolean))().$ctor(this,  (/*info*/ info) =>
                    {
                        return !$.$mefp.Microsoft.Extensions.FileProviders.Physical.FileSystemInfoHelper.IsExcluded(info, this._filters);
                    })), new ($.$spc.System.Func$$$($.$spc.System.IO.FileSystemInfo, $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo))().$ctor(this,  (/**/ info) =>
                    {
                        return (() =>
                        {
                            {
                                let file;
                                if ((file = info, $.$is(file, $.$spc.System.IO.FileInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalFileInfo().$ctor$1(file);
                                }
                            }
                            {
                                let dir;
                                if ((dir = info, $.$is(dir, $.$spc.System.IO.DirectoryInfo)))
                                {
                                    return new $.$mefp.Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo().$ctor$1(dir);
                                }
                            }
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mefp.System.SR.UnexpectedFileSystemInfo);
                        })();
                    }));
                }
                catch(ex)
                {
                    this._entries = $.$sl.System.Linq.Enumerable.Empty($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo);
                }
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Exists.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Length.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Length()
            {
                return this.Length;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.PhysicalPath.get
            get Microsoft$Extensions$FileProviders$IFileInfo$PhysicalPath()
            {
                return this.PhysicalPath;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.Name.get
            get Microsoft$Extensions$FileProviders$IFileInfo$Name()
            {
                return this.Name;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.LastModified.get
            get Microsoft$Extensions$FileProviders$IFileInfo$LastModified()
            {
                return this.LastModified;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.IsDirectory.get
            get Microsoft$Extensions$FileProviders$IFileInfo$IsDirectory()
            {
                return this.IsDirectory;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IFileInfo.CreateReadStream()
            Microsoft$Extensions$FileProviders$IFileInfo$CreateReadStream()
            {
                return this.CreateReadStream(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileProviders.IDirectoryContents.Exists.get
            get Microsoft$Extensions$FileProviders$IDirectoryContents$Exists()
            {
                return this.Exists;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<Microsoft.Extensions.FileProviders.IFileInfo>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 589851;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065360923,"f":1},"n":"Exists","d":589851,"h":25770393627,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":38655295515,"f":1},"n":"Length","d":589851,"h":34360328219,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47245230107,"f":1},"n":"PhysicalPath","d":589851,"h":42950262811,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835164699,"f":1},"n":"Name","d":589851,"h":51540197403,"f":1},{"p":34340865,"g":{"r":0,"d":0,"h":64425099291,"f":1},"n":"LastModified","d":589851,"h":60130131995,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015033883,"f":1},"n":"IsDirectory","d":589851,"h":68720066587,"f":1}],"m":[{"r":62128129,"n":"CreateReadStream","d":589851,"h":77310001179,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"GetEnumerator","d":589851,"h":81604968475,"f":1},{"r":65537,"n":"EnsureInitialized","d":589851,"h":90194903067,"f":2}],"l":[{"t":58654721,"n":"_info","d":589851,"h":4295557147,"f":2},{"t":$.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,"n":"_entries","d":589851,"h":8590524443,"f":2},{"t":327707,"n":"_filters","d":589851,"h":12885491739,"f":2}],"c":[{"p":[{"n":"info","p":58654721}],"n":".ctor","o":"$ctor$1","d":589851,"h":17180459035,"f":1},{"p":[{"n":"info","p":58654721},{"n":"filters","p":327707}],"n":".ctor","o":"$ctor$2","d":589851,"h":21475426331,"f":8}],"i":[196634,131098,$.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo).$h,31588353],"h":589851}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mefa.Microsoft.Extensions.FileProviders.IFileInfo, $.$mefa.Microsoft.Extensions.FileProviders.IDirectoryContents, $.$spc.System.Collections.Generic.IEnumerable$$($.$mefa.Microsoft.Extensions.FileProviders.IFileInfo), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.PhysicalDirectoryInfo`; }
        });
        
        $asm.$str("$mefp.Microsoft.Extensions.FileProviders.Physical.ExclusionFilters", ($self) => class ExclusionFilters extends $.$spc.System.Enum
        {
            static Sensitive = 7;
            static DotPrefixed = 1;
            static Hidden = 2;
            static System = 4;
            static None = 0;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Sensitive": 7n,
                    "DotPrefixed": 1n,
                    "Hidden": 2n,
                    "System": 4n,
                    "None": 0n
                };
            }
            static $h = 327707;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":327707,"n":"Sensitive","d":327707,"h":4295295003,"f":33},{"t":327707,"n":"DotPrefixed","d":327707,"h":8590262299,"f":33},{"t":327707,"n":"Hidden","d":327707,"h":12885229595,"f":33},{"t":327707,"n":"System","d":327707,"h":17180196891,"f":33},{"t":327707,"n":"None","d":327707,"h":21475164187,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":327707,"h":25770131483,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":327707,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.FileProviders.Physical.ExclusionFilters`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.Numerics", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.IO.FileSystem.Watcher", "NetJs.Microsoft.Extensions.FileProviders.Abstractions", "NetJs.Microsoft.Extensions.FileSystemGlobbing", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Security.Cryptography"))