
//--TRIMMABLE-BOUNDARY-START(101)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileSystemGlobbing", 
    {
  "h": 101,
  "f": "Microsoft.Extensions.FileSystemGlobbing",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129564673,
      "c": 4424531969,
      "a": [
        {
          "v": "Microsoft.Extensions.FileSystemGlobbing.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileSystemGlobbing",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.FileSystemGlobbing",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(720997)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment", ($self) => class IPathSegment
        {
            static $h = 720997;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295688293),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885622885,
        "f": 50331905
      },
      "n": "CanProduceStem",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem",
      "d": 720997,
      "h": 4295688293,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295688293)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590181),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match",
      "d": 720997,
      "h": 17180590181,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180590181)
  ],
  "h": 720997
}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720997)
        
        
        //--TRIMMABLE-BOUNDARY-START(852069)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext", ($self) => class IPatternContext
        {
            static $h = 852069;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819365),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare",
      "d": 852069,
      "h": 4295819365,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295819365),
//--TRIMMABLE-BOUNDARY-START(17180721253),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test",
      "d": 852069,
      "h": 17180721253,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180721253),
//--TRIMMABLE-BOUNDARY-START(21475688549),
    {
      "r": 2359397,
      "p": [
        {
          "n": "file",
          "p": 196709
        }
      ],
      "n": "Test",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1",
      "d": 852069,
      "h": 21475688549,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475688549),
//--TRIMMABLE-BOUNDARY-START(12885753957),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory",
      "d": 852069,
      "h": 12885753957,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885753957),
//--TRIMMABLE-BOUNDARY-START(8590786661),
    {
      "r": 65537,
      "n": "PopDirectory",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory",
      "d": 852069,
      "h": 8590786661,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590786661)
  ],
  "h": 852069
}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852069)
        
        
        //--TRIMMABLE-BOUNDARY-START(786533)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern", ($self) => class IPattern
        {
            static $h = 786533;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590721125),
    {
      "r": 852069,
      "n": "CreatePatternContextForInclude",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude",
      "d": 786533,
      "h": 8590721125,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590721125),
//--TRIMMABLE-BOUNDARY-START(4295753829),
    {
      "r": 852069,
      "n": "CreatePatternContextForExclude",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude",
      "d": 786533,
      "h": 4295753829,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295753829)
  ],
  "h": 786533
}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786533)
        
        
        //--TRIMMABLE-BOUNDARY-START(917605)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern", ($self) => class IRaggedPattern
        {
            static $h = 917605;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245557861),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655973,
        "f": 50331905
      },
      "n": "Segments",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Segments",
      "d": 917605,
      "h": 47245557861,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47245557861),
//--TRIMMABLE-BOUNDARY-START(51540525157),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590565,
        "f": 50331905
      },
      "n": "StartsWith",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith",
      "d": 917605,
      "h": 51540525157,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540525157),
//--TRIMMABLE-BOUNDARY-START(4295884901),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180786789,
        "f": 50331905
      },
      "n": "Contains",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains",
      "d": 917605,
      "h": 4295884901,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295884901),
//--TRIMMABLE-BOUNDARY-START(8590852197),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721381,
        "f": 50331905
      },
      "n": "EndsWith",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith",
      "d": 917605,
      "h": 8590852197,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590852197)
  ],
  "i": [786533
  ],
  "h": 917605
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917605)
        
        
        //--TRIMMABLE-BOUNDARY-START(524389)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern", ($self) => class ILinearPattern
        {
            static $h = 524389;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426277),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590458981,
        "f": 50331905
      },
      "n": "Segments",
      "o": "Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments",
      "d": 524389,
      "h": 12885426277,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885426277)
  ],
  "i": [786533
  ],
  "h": 524389
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524389)
        
        
        //--TRIMMABLE-BOUNDARY-START(327781)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase", ($self) => class FileSystemInfoBase extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327781;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655033445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131557,
        "f": 50331905
      },
      "n": "Name",
      "d": 327781,
      "h": 38655033445,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655033445),
//--TRIMMABLE-BOUNDARY-START(8590262373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196965,
        "f": 50331905
      },
      "n": "FullName",
      "d": 327781,
      "h": 8590262373,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590262373),
//--TRIMMABLE-BOUNDARY-START(42950000741),
    {
      "p": 65637,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066149,
        "f": 50331905
      },
      "n": "ParentDirectory",
      "d": 327781,
      "h": 42950000741,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42950000741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295077),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327781,
      "h": 4295295077,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295077)
  ],
  "h": 327781
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327781)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507429)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<>", (TFrame) => $asm.$gt("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<>", [TFrame], ($self) => class PatternContext$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474725)
            /*Stack<TFrame>*/ _stack = null;
            //--TRIMMABLE-BOUNDARY-END(4296474725)
            
            //--TRIMMABLE-BOUNDARY-START(17181376613)
            /*TFrame*/ Frame = $.$default(TFrame);
            //--TRIMMABLE-BOUNDARY-END(17181376613)
            
            //--TRIMMABLE-BOUNDARY-START(12886409317)
            /*void */ Declare(/*Action<IPathSegment, bool>*/ declare)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886409317)
            
            //--TRIMMABLE-BOUNDARY-START(25771311205)
            /*void */ PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Frame = this._stack.Pop();
            }
            //--TRIMMABLE-BOUNDARY-END(25771311205)
            
            //--TRIMMABLE-BOUNDARY-START(30066278501)
            /*void */ PushDataFrame(/*TFrame*/ frame)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._stack.Push(this.Frame);
                this.Frame = frame;
            }
            //--TRIMMABLE-BOUNDARY-END(30066278501)
            
            //--TRIMMABLE-BOUNDARY-START(21476343909)
            /*bool */ IsStackEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._stack.Count === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343909)
            
            //--TRIMMABLE-BOUNDARY-START(4295819365)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Declare(System.Action<Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, bool>)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Declare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819365)
            
            //--TRIMMABLE-BOUNDARY-START(17180721253)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Test(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721253)
            
            //--TRIMMABLE-BOUNDARY-START(21475688549)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Test$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475688549)
            
            //--TRIMMABLE-BOUNDARY-START(12885753957)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PushDirectory(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PushDirectory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753957)
            
            //--TRIMMABLE-BOUNDARY-START(8590786661)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PopDirectory()
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PopDirectory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786661)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474725)
                this._stack = new ($.$sc.System.Collections.Generic.Stack$$(TFrame))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296474725)
                
                //--TRIMMABLE-BOUNDARY-START(17181376613)
                this.Frame = $.$default(TFrame);
                //--TRIMMABLE-BOUNDARY-END(17181376613)
                
            }
            static $h = 1507429;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886409317),
    {
      "r": 65537,
      "p": [
        {
          "n": "declare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886409317),
//--TRIMMABLE-BOUNDARY-START(38656213093),
    {
      "r": 2359397,
      "p": [
        {
          "n": "file",
          "p": 196709
        }
      ],
      "n": "Test",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38656213093),
//--TRIMMABLE-BOUNDARY-START(42951180389),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42951180389),
//--TRIMMABLE-BOUNDARY-START(34361245797),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34361245797),
//--TRIMMABLE-BOUNDARY-START(25771311205),
    {
      "r": 65537,
      "n": "PopDirectory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771311205),
//--TRIMMABLE-BOUNDARY-START(30066278501),
    {
      "r": 65537,
      "p": [
        {
          "n": "frame",
          "p": TFrame?.$h??1507328
        }
      ],
      "n": "PushDataFrame",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30066278501),
//--TRIMMABLE-BOUNDARY-START(21476343909),
    {
      "r": 262145,
      "n": "IsStackEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21476343909)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474725),
    {
      "t": $.$sc.System.Collections.Generic.Stack$$(TFrame).$h,
      "n": "_stack",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474725),
//--TRIMMABLE-BOUNDARY-START(17181376613),
    {
      "t": TFrame?.$h??1507328,
      "n": "Frame",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(17181376613)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591442021),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591442021)
  ],
  "i": [852069
  ],
  "g": [TFrame?.$h??1507328
  ],
  "s": [
    {
      "n": "TFrame",
      "f": 2
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<${TFrame?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507429)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376357)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext", ($self) => class CompositePatternContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771180133)
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771180133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.MatchPatternContexts($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, directory, new ($.$$.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult))().$ctor($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext, /*static*/ (/*context*/ context, /**/ dir) =>
                    {
                        return context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test(dir) ? $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success($.$$.System.String.Empty) : $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                    }, {
  "r": 2359397,
  "p": [
    {
      "n": "context",
      "p": 852069
    },
    {
      "n": "dir",
      "p": 65637
    }
  ],
  "n": "",
  "d": 1376357,
  "h": 0,
  "f": 17825826
})).IsSuccessful;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771180133)
            
            //--TRIMMABLE-BOUNDARY-START(30066147429)
            /*PatternTestResult */ Test$1(/*FileInfoBase*/ file)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066147429);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.MatchPatternContexts($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, file, new ($.$$.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult))().$ctor($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext, /*static*/ (/*context*/ context, /*fileInfo*/ fileInfo) =>
                    {
                        return context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1(fileInfo);
                    }, {
  "r": 2359397,
  "p": [
    {
      "n": "context",
      "p": 852069
    },
    {
      "n": "fileInfo",
      "p": 196709
    }
  ],
  "n": "",
  "d": 1376357,
  "h": 0,
  "f": 17825826
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066147429)
            
            //--TRIMMABLE-BOUNDARY-START(4295819365)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Declare(System.Action<Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, bool>)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Declare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819365)
            
            //--TRIMMABLE-BOUNDARY-START(17180721253)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Test(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180721253)
            
            //--TRIMMABLE-BOUNDARY-START(21475688549)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475688549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Test$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475688549)
            
            //--TRIMMABLE-BOUNDARY-START(12885753957)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PushDirectory(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PushDirectory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753957)
            
            //--TRIMMABLE-BOUNDARY-START(8590786661)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PopDirectory()
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.PopDirectory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786661)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1376357;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310949),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": 1376357,
      "h": 8591310949,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591310949),
//--TRIMMABLE-BOUNDARY-START(17181245541),
    {
      "r": 65537,
      "n": "PopDirectory",
      "d": 1376357,
      "h": 17181245541,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17181245541),
//--TRIMMABLE-BOUNDARY-START(21476212837),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": 1376357,
      "h": 21476212837,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476212837),
//--TRIMMABLE-BOUNDARY-START(12886278245),
    {
      "r": 2359397,
      "p": [
        {
          "n": "fileInfo",
          "p": (TFileInfoBase) => TFileInfoBase.$h
        },
        {
          "n": "test",
          "p": (TFileInfoBase) => $.$$.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h
        }
      ],
      "g": [
        "TFileInfoBase"
      ],
      "n": "MatchPatternContexts",
      "d": 1376357,
      "h": 12886278245,
      "f": 16908560
    },
//--TRIMMABLE-BOUNDARY-END(12886278245),
//--TRIMMABLE-BOUNDARY-START(25771180133),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": 1376357,
      "h": 25771180133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180133),
//--TRIMMABLE-BOUNDARY-START(30066147429),
    {
      "r": 2359397,
      "p": [
        {
          "n": "file",
          "p": 196709
        }
      ],
      "n": "Test",
      "o": "@$1",
      "d": 1376357,
      "h": 30066147429,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066147429)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343653),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376357,
      "h": 4296343653,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296343653)
  ],
  "i": [852069
  ],
  "h": 1376357
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376357)
        
        
        //--TRIMMABLE-BOUNDARY-START(196709)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase", ($self) => class FileInfoBase extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 196709;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 327781,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164005),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196709,
      "h": 4295164005,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295164005)
  ],
  "h": 196709
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196709)
        
        
        //--TRIMMABLE-BOUNDARY-START(65637)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase", ($self) => class DirectoryInfoBase extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 65637;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 327781,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000229),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,
      "n": "EnumerateFileSystemInfos",
      "d": 65637,
      "h": 8590000229,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590000229),
//--TRIMMABLE-BOUNDARY-START(12884967525),
    {
      "r": 65637,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetDirectory",
      "d": 65637,
      "h": 12884967525,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12884967525),
//--TRIMMABLE-BOUNDARY-START(17179934821),
    {
      "r": 196709,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetFile",
      "d": 65637,
      "h": 17179934821,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17179934821)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032933),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65637,
      "h": 4295032933,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295032933)
  ],
  "h": 65637
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65637)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572965)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear", ($self) => class PatternContextLinear extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($self.$itype$FrameData)
        {
            //--TRIMMABLE-BOUNDARY-START(4296540261)
            $ctor$2(/*ILinearPattern*/ pattern)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296540261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(pattern, "pattern");
                    this.Pattern = pattern;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540261)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951245925, 38656213093)
            /*PatternTestResult */ Test$1(/*FileInfoBase*/ file)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestFile);
                }
                if (!this.Frame.IsNotApplicable && this.IsLastSegment() && this.TestMatchingSegment(file.Name))
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success(this.CalculateStem(file));
                }
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951245925, 38656213093)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38656278629, 34361245797)
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*FrameData*/ let frame = this.Frame;
                if (this.IsStackEmpty() || this.Frame.IsNotApplicable)
                {
                }
                else if (!this.TestMatchingSegment(directory.Name))
                {
                    frame.IsNotApplicable = true;
                }
                else 
                {
                    /*IPathSegment*/ let segment = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]);
                    if (frame.InStem || segment.Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem)
                    {
                        frame.InStem = true;
                        frame.StemItems.System$Collections$Generic$ICollection$$$Add(directory.Name, [$.$$.System.String]);
                    }
                    frame.SegmentIndex++;
                }
                this.PushDataFrame(frame.Clone());
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38656278629, 34361245797)
            
            //--TRIMMABLE-BOUNDARY-START(1638501)
            static $_FrameData;
            static get FrameData()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear;
                return $cls.$_FrameData ??= $asm.$nstr("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData", ($self) => class FrameData extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34361376869)
                    /*bool*/  get IsNotApplicable() { return this.$getField(0, 1); }
                    /*bool*/  set IsNotApplicable(value) { this.$setField(0, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(34361376869)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656344165)
                    /*int*/  get SegmentIndex() { return this.$getField(1, 4); }
                    /*int*/  set SegmentIndex(value) { this.$setField(1, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(38656344165)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066409573)
                    /*bool*/  get InStem() { return this.$getField(5, 1); }
                    /*bool*/  set InStem(value) { this.$setField(5, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(30066409573)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296605797)
                    /*IList<string>?*/  get _stemItems() { return this.$getField(6, 4); }
                    /*IList<string>?*/  set _stemItems(value) { this.$setField(6, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296605797)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246278757)
                    /*IList<string> */ get StemItems()
                    {
                        return this._stemItems ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246278757)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951311461)
                    /*string? */ get Stem()
                    {
                        return this._stemItems === null ? null : $.$$.System.String.Join$5("/", this._stemItems);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951311461)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsNotApplicable = this.IsNotApplicable;
                        copy.SegmentIndex = this.SegmentIndex;
                        copy.InStem = this.InStem;
                        copy._stemItems = this._stemItems;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(34361376869)
                        this.IsNotApplicable = false;
                        //--TRIMMABLE-BOUNDARY-END(34361376869)
                        
                        //--TRIMMABLE-BOUNDARY-START(38656344165)
                        this.SegmentIndex = 0;
                        //--TRIMMABLE-BOUNDARY-END(38656344165)
                        
                        //--TRIMMABLE-BOUNDARY-START(30066409573)
                        this.InStem = false;
                        //--TRIMMABLE-BOUNDARY-END(30066409573)
                        
                        //--TRIMMABLE-BOUNDARY-START(4296605797)
                        this._stemItems = null;
                        //--TRIMMABLE-BOUNDARY-END(4296605797)
                        
                    }
                    static $h = 1638501;
                    static $z = 10;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246278757),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771442277,
        "f": 50331649
      },
      "n": "StemItems",
      "d": 1638501,
      "h": 47246278757,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246278757),
//--TRIMMABLE-BOUNDARY-START(42951311461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181507685,
        "f": 50331649
      },
      "n": "Stem",
      "d": 1638501,
      "h": 42951311461,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951311461)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361376869),
    {
      "t": 262145,
      "n": "IsNotApplicable",
      "d": 1638501,
      "h": 34361376869,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(34361376869),
//--TRIMMABLE-BOUNDARY-START(38656344165),
    {
      "t": 655361,
      "n": "SegmentIndex",
      "d": 1638501,
      "h": 38656344165,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38656344165),
//--TRIMMABLE-BOUNDARY-START(30066409573),
    {
      "t": 262145,
      "n": "InStem",
      "d": 1638501,
      "h": 30066409573,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(30066409573),
//--TRIMMABLE-BOUNDARY-START(4296605797),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "n": "_stemItems",
      "d": 1638501,
      "h": 4296605797,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605797)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573093),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638501,
      "h": 8591573093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591573093)
  ],
  "d": 1572965,
  "h": 1638501
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData`; }
                }, $cls, ($v) => $cls.$_FrameData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1638501)
            
            //--TRIMMABLE-BOUNDARY-START(34361311333)
            /*ILinearPattern*/ Pattern = null;
            //--TRIMMABLE-BOUNDARY-END(34361311333)
            
            //--TRIMMABLE-BOUNDARY-START(30066344037)
            /*bool */ IsLastSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066344037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Frame.SegmentIndex === ((this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count - 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30066344037)
            
            //--TRIMMABLE-BOUNDARY-START(47246213221)
            /*bool */ TestMatchingSegment(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Frame.SegmentIndex >= this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                return this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]).Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(value);
            }
            //--TRIMMABLE-BOUNDARY-END(47246213221)
            
            //--TRIMMABLE-BOUNDARY-START(12886474853)
            /*string */ CalculateStem(/*FileInfoBase*/ matchedFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(this.Frame.Stem, matchedFile.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(12886474853)
            
            static $h = 1572965;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361311333),
    {
      "p": 524389,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771376741,
        "f": 50331652
      },
      "n": "Pattern",
      "d": 1572965,
      "h": 34361311333,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(34361311333)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 42951245925, 38656213093),
    {
      "r": 2359397,
      "p": [
        {
          "n": "file",
          "p": 196709
        }
      ],
      "n": "Test",
      "o": "@$1",
      "d": 1572965,
      "h": 42951245925,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951245925, 38656213093),
//--TRIMMABLE-BOUNDARY-START(ALL, 38656278629, 34361245797),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": 1572965,
      "h": 38656278629,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38656278629, 34361245797),
//--TRIMMABLE-BOUNDARY-START(30066344037),
    {
      "r": 262145,
      "n": "IsLastSegment",
      "d": 1572965,
      "h": 30066344037,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30066344037),
//--TRIMMABLE-BOUNDARY-START(47246213221),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "TestMatchingSegment",
      "d": 1572965,
      "h": 47246213221,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47246213221),
//--TRIMMABLE-BOUNDARY-START(12886474853),
    {
      "r": 1310721,
      "p": [
        {
          "n": "matchedFile",
          "p": 196709
        }
      ],
      "n": "CalculateStem",
      "d": 1572965,
      "h": 12886474853,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886474853)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540261),
    {
      "p": [
        {
          "n": "pattern",
          "p": 524389
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572965,
      "h": 4296540261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540261)
  ],
  "i": [852069
  ],
  "j": [1638501
  ],
  "h": 1572965
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572965)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835109)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged", ($self) => class PatternContextRagged extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($self.$itype$FrameData)
        {
            //--TRIMMABLE-BOUNDARY-START(4296802405)
            $ctor$2(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296802405);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(pattern, "pattern");
                    this.Pattern = pattern;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296802405)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51541442661, 38656213093)
            /*PatternTestResult */ Test$1(/*FileInfoBase*/ file)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541442661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestFile);
                }
                if (!this.Frame.IsNotApplicable && this.IsEndingGroup() && this.TestMatchingGroup(file))
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success(this.CalculateStem(file));
                }
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 51541442661, 38656213093)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47246475365, 34361245797)
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246475365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*FrameData*/ let frame = this.Frame;
                if (this.IsStackEmpty())
                {
                    frame.SegmentGroupIndex = -1;
                    frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith;
                }
                else if (this.Frame.IsNotApplicable)
                {
                }
                else if (this.IsStartingGroup())
                {
                    if (!this.TestMatchingSegment(directory.Name))
                    {
                        frame.IsNotApplicable = true;
                    }
                    else 
                    {
                        frame.SegmentIndex += 1;
                    }
                }
                else if (!this.IsStartingGroup() && $.$$.System.String.op_Equality(directory.Name, ".."))
                {
                    frame.IsNotApplicable = true;
                }
                else if (!this.IsStartingGroup() && !this.IsEndingGroup() && this.TestMatchingGroup(directory))
                {
                    frame.SegmentIndex = this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count;
                    frame.BacktrackAvailable = 0;
                }
                else 
                {
                    frame.BacktrackAvailable += 1;
                }
                if (frame.InStem)
                {
                    frame.StemItems.System$Collections$Generic$ICollection$$$Add(directory.Name, [$.$$.System.String]);
                }
                while(frame.SegmentIndex === frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count && frame.SegmentGroupIndex !== this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count)
                {
                    frame.SegmentGroupIndex += 1;
                    frame.SegmentIndex = 0;
                    if (frame.SegmentGroupIndex < this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count)
                    {
                        frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$IList$$$get_Item(frame.SegmentGroupIndex, [$.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)]);
                    }
                    else 
                    {
                        frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith;
                    }
                    frame.InStem = true;
                }
                this.PushDataFrame(frame.Clone());
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47246475365, 34361245797)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42951508069, 25771311205)
            /*void */ PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951508069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                super.PopDirectory();
                if (this.Frame.StemItems.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    this.Frame.StemItems.System$Collections$Generic$IList$$$RemoveAt(((this.Frame.StemItems.System$Collections$Generic$ICollection$$$Count - 1) | 0), [$.$$.System.String]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42951508069, 25771311205)
            
            //--TRIMMABLE-BOUNDARY-START(1900645)
            static $_FrameData;
            static get FrameData()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged;
                return $cls.$_FrameData ??= $asm.$nstr("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData", ($self) => class FrameData extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(38656606309)
                    /*bool*/  get IsNotApplicable() { return this.$getField(0, 1); }
                    /*bool*/  set IsNotApplicable(value) { this.$setField(0, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(38656606309)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540901)
                    /*int*/  get SegmentGroupIndex() { return this.$getField(1, 4); }
                    /*int*/  set SegmentGroupIndex(value) { this.$setField(1, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(47246540901)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951573605)
                    /*IList<IPathSegment>*/  get SegmentGroup() { return this.$getField(5, 4); }
                    /*IList<IPathSegment>*/  set SegmentGroup(value) { this.$setField(5, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(42951573605)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802533)
                    /*int*/  get BacktrackAvailable() { return this.$getField(9, 4); }
                    /*int*/  set BacktrackAvailable(value) { this.$setField(9, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886802533)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541508197)
                    /*int*/  get SegmentIndex() { return this.$getField(13, 4); }
                    /*int*/  set SegmentIndex(value) { this.$setField(13, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(51541508197)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361639013)
                    /*bool*/  get InStem() { return this.$getField(17, 1); }
                    /*bool*/  set InStem(value) { this.$setField(17, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(34361639013)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867941)
                    /*IList<string>?*/  get _stemItems() { return this.$getField(18, 4); }
                    /*IList<string>?*/  set _stemItems(value) { this.$setField(18, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296867941)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131442789)
                    /*IList<string> */ get StemItems()
                    {
                        return this._stemItems ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131442789)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836475493)
                    /*string? */ get Stem()
                    {
                        return this._stemItems === null ? null : $.$$.System.String.Join$5("/", this._stemItems);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836475493)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsNotApplicable = this.IsNotApplicable;
                        copy.SegmentGroupIndex = this.SegmentGroupIndex;
                        copy.SegmentGroup = this.SegmentGroup;
                        copy.BacktrackAvailable = this.BacktrackAvailable;
                        copy.SegmentIndex = this.SegmentIndex;
                        copy.InStem = this.InStem;
                        copy._stemItems = this._stemItems;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(38656606309)
                        this.IsNotApplicable = false;
                        //--TRIMMABLE-BOUNDARY-END(38656606309)
                        
                        //--TRIMMABLE-BOUNDARY-START(47246540901)
                        this.SegmentGroupIndex = 0;
                        //--TRIMMABLE-BOUNDARY-END(47246540901)
                        
                        //--TRIMMABLE-BOUNDARY-START(42951573605)
                        this.SegmentGroup = null;
                        //--TRIMMABLE-BOUNDARY-END(42951573605)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886802533)
                        this.BacktrackAvailable = 0;
                        //--TRIMMABLE-BOUNDARY-END(12886802533)
                        
                        //--TRIMMABLE-BOUNDARY-START(51541508197)
                        this.SegmentIndex = 0;
                        //--TRIMMABLE-BOUNDARY-END(51541508197)
                        
                        //--TRIMMABLE-BOUNDARY-START(34361639013)
                        this.InStem = false;
                        //--TRIMMABLE-BOUNDARY-END(34361639013)
                        
                        //--TRIMMABLE-BOUNDARY-START(4296867941)
                        this._stemItems = null;
                        //--TRIMMABLE-BOUNDARY-END(4296867941)
                        
                    }
                    static $h = 1900645;
                    static $z = 22;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131442789),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671717,
        "f": 50331649
      },
      "n": "StemItems",
      "d": 1900645,
      "h": 60131442789,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131442789),
//--TRIMMABLE-BOUNDARY-START(55836475493),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476737125,
        "f": 50331649
      },
      "n": "Stem",
      "d": 1900645,
      "h": 55836475493,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836475493)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656606309),
    {
      "t": 262145,
      "n": "IsNotApplicable",
      "d": 1900645,
      "h": 38656606309,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(38656606309),
//--TRIMMABLE-BOUNDARY-START(47246540901),
    {
      "t": 655361,
      "n": "SegmentGroupIndex",
      "d": 1900645,
      "h": 47246540901,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(47246540901),
//--TRIMMABLE-BOUNDARY-START(42951573605),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "n": "SegmentGroup",
      "d": 1900645,
      "h": 42951573605,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(42951573605),
//--TRIMMABLE-BOUNDARY-START(12886802533),
    {
      "t": 655361,
      "n": "BacktrackAvailable",
      "d": 1900645,
      "h": 12886802533,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12886802533),
//--TRIMMABLE-BOUNDARY-START(51541508197),
    {
      "t": 655361,
      "n": "SegmentIndex",
      "d": 1900645,
      "h": 51541508197,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(51541508197),
//--TRIMMABLE-BOUNDARY-START(34361639013),
    {
      "t": 262145,
      "n": "InStem",
      "d": 1900645,
      "h": 34361639013,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(34361639013),
//--TRIMMABLE-BOUNDARY-START(4296867941),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "n": "_stemItems",
      "d": 1900645,
      "h": 4296867941,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867941)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591835237),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900645,
      "h": 8591835237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591835237)
  ],
  "d": 1835109,
  "h": 1900645
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData`; }
                }, $cls, ($v) => $cls.$_FrameData = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900645)
            
            //--TRIMMABLE-BOUNDARY-START(38656540773)
            /*IRaggedPattern*/ Pattern = null;
            //--TRIMMABLE-BOUNDARY-END(38656540773)
            
            //--TRIMMABLE-BOUNDARY-START(34361573477)
            /*bool */ IsStartingGroup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Frame.SegmentGroupIndex === -1;
            }
            //--TRIMMABLE-BOUNDARY-END(34361573477)
            
            //--TRIMMABLE-BOUNDARY-START(30066606181)
            /*bool */ IsEndingGroup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066606181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Frame.SegmentGroupIndex === this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30066606181)
            
            //--TRIMMABLE-BOUNDARY-START(60131377253)
            /*bool */ TestMatchingSegment(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131377253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Frame.SegmentIndex >= this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                return this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]).Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(value);
            }
            //--TRIMMABLE-BOUNDARY-END(60131377253)
            
            //--TRIMMABLE-BOUNDARY-START(55836409957)
            /*bool */ TestMatchingGroup(/*FileSystemInfoBase*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836409957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let groupLength = this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count;
                /*int*/ let backtrackLength = ((this.Frame.BacktrackAvailable + 1) | 0);
                if (backtrackLength < groupLength)
                {
                    return false;
                }
                /*FileSystemInfoBase?*/ let scan = value;
                for(/*int*/ let index = 0; index !== groupLength; ++index)
                {
                    /*IPathSegment*/ let segment = this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(((((groupLength - index) | 0) - 1) | 0), [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]);
                    if (scan === null || !segment.Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(scan.Name))
                    {
                        return false;
                    }
                    scan = scan.ParentDirectory;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55836409957)
            
            //--TRIMMABLE-BOUNDARY-START(12886736997)
            /*string */ CalculateStem(/*FileInfoBase*/ matchedFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886736997);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(this.Frame.Stem, matchedFile.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(12886736997)
            
            static $h = 1835109;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656540773),
    {
      "p": 917605,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771638885,
        "f": 50331652
      },
      "n": "Pattern",
      "d": 1835109,
      "h": 38656540773,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(38656540773)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 51541442661, 38656213093),
    {
      "r": 2359397,
      "p": [
        {
          "n": "file",
          "p": 196709
        }
      ],
      "n": "Test",
      "o": "@$1",
      "d": 1835109,
      "h": 51541442661,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51541442661, 38656213093),
//--TRIMMABLE-BOUNDARY-START(ALL, 47246475365, 34361245797),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": 1835109,
      "h": 47246475365,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47246475365, 34361245797),
//--TRIMMABLE-BOUNDARY-START(ALL, 42951508069, 25771311205),
    {
      "r": 65537,
      "n": "PopDirectory",
      "d": 1835109,
      "h": 42951508069,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42951508069, 25771311205),
//--TRIMMABLE-BOUNDARY-START(34361573477),
    {
      "r": 262145,
      "n": "IsStartingGroup",
      "d": 1835109,
      "h": 34361573477,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34361573477),
//--TRIMMABLE-BOUNDARY-START(30066606181),
    {
      "r": 262145,
      "n": "IsEndingGroup",
      "d": 1835109,
      "h": 30066606181,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(30066606181),
//--TRIMMABLE-BOUNDARY-START(60131377253),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "TestMatchingSegment",
      "d": 1835109,
      "h": 60131377253,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(60131377253),
//--TRIMMABLE-BOUNDARY-START(55836409957),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 327781
        }
      ],
      "n": "TestMatchingGroup",
      "d": 1835109,
      "h": 55836409957,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(55836409957),
//--TRIMMABLE-BOUNDARY-START(12886736997),
    {
      "r": 1310721,
      "p": [
        {
          "n": "matchedFile",
          "p": 196709
        }
      ],
      "n": "CalculateStem",
      "d": 1835109,
      "h": 12886736997,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12886736997)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802405),
    {
      "p": [
        {
          "n": "pattern",
          "p": 917605
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1835109,
      "h": 4296802405,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802405)
  ],
  "i": [852069
  ],
  "j": [1900645
  ],
  "h": 1835109
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835109)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621541)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper", ($self) => class StringComparisonHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4297588837)
            static /*StringComparer */ GetStringComparer(/*StringComparison*/ comparisonType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297588837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (comparisonType === 0/*StringComparison.CurrentCulture*/)
                        {
                            return $.$$.System.StringComparer.CurrentCulture;
                        }
                        if (comparisonType === 1/*StringComparison.CurrentCultureIgnoreCase*/)
                        {
                            return $.$$.System.StringComparer.CurrentCultureIgnoreCase;
                        }
                        if (comparisonType === 4/*StringComparison.Ordinal*/)
                        {
                            return $.$$.System.StringComparer.Ordinal;
                        }
                        if (comparisonType === 5/*StringComparison.OrdinalIgnoreCase*/)
                        {
                            return $.$$.System.StringComparer.OrdinalIgnoreCase;
                        }
                        if (comparisonType === 2/*StringComparison.InvariantCulture*/)
                        {
                            return $.$$.System.StringComparer.InvariantCulture;
                        }
                        if (comparisonType === 3/*StringComparison.InvariantCultureIgnoreCase*/)
                        {
                            return $.$$.System.StringComparer.InvariantCultureIgnoreCase;
                        }
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.Format$6($.$mef.System.SR.UnexpectedStringComparisonType, $.$box(comparisonType, $.$$.System.StringComparison)));
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297588837)
            
            static $h = 2621541;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297588837),
    {
      "r": 163381249,
      "p": [
        {
          "n": "comparisonType",
          "p": 163446785
        }
      ],
      "n": "GetStringComparer",
      "d": 2621541,
      "h": 4297588837,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297588837)
  ],
  "h": 2621541
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621541)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687077)
        $asm.$cls("$mef.System.Numerics.Hashing.HashHelpers", ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(4297654373)
            static /*int */ Combine(/*int*/ h1, /*int*/ h2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297654373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let rol5 = (((h1 >>> 0) << 5) >>> 0) | ((h1 >>> 0) >>> 27);
                return ((((rol5 | 0) + h1) | 0)) ^ h2;
            }
            //--TRIMMABLE-BOUNDARY-END(4297654373)
            
            static $h = 2687077;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297654373),
    {
      "r": 655361,
      "p": [
        {
          "n": "h1",
          "p": 655361
        },
        {
          "n": "h2",
          "p": 655361
        }
      ],
      "n": "Combine",
      "d": 2687077,
      "h": 4297654373,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297654373)
  ],
  "h": 2687077
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Numerics.Hashing.HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687077)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752613)
        $asm.$cls("$mef.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(150326607973)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(150326607973)
            
            //--TRIMMABLE-BOUNDARY-START(141736673381)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(141736673381)
            
            //--TRIMMABLE-BOUNDARY-START(146031640677)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376935013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mef.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileSystemGlobbing", $.$mef.System.SR.$type.Assembly);
                    $.$mef.System.SR.s_resourceManager = temp;
                }
                return $.$mef.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(146031640677)
            
            //--TRIMMABLE-BOUNDARY-START(21477589093)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787000421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211509861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mef.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21477589093)
            
            //--TRIMMABLE-BOUNDARY-START(8592687205)
            static /*string */ get CannotDeclarePathSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017196645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot declare path segment before entering a directory.";
            }
            //--TRIMMABLE-BOUNDARY-END(8592687205)
            
            //--TRIMMABLE-BOUNDARY-START(12887654501)
            static /*string */ get CannotTestDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607131237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot test directory before entering a directory.";
            }
            //--TRIMMABLE-BOUNDARY-END(12887654501)
            
            //--TRIMMABLE-BOUNDARY-START(17182621797)
            static /*string */ get CannotTestFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197065829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot test file before entering a directory.";
            }
            //--TRIMMABLE-BOUNDARY-END(17182621797)
            
            //--TRIMMABLE-BOUNDARY-START(167506477157)
            static /*string */ get StringComparisonTypeShouldBeOrdinal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966869605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unexpected StringComparison type: '{0}'. Only 'Ordinal' and 'OrdinalIgnoreCase' are supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(167506477157)
            
            //--TRIMMABLE-BOUNDARY-START(60132294757)
            static /*string */ FormatStringComparisonTypeShouldBeOrdinal(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132294757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unexpected StringComparison type: '{0}'. Only 'Ordinal' and 'OrdinalIgnoreCase' are supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(60132294757)
            
            //--TRIMMABLE-BOUNDARY-START(171801444453)
            static /*string */ get UnexpectedStringComparisonType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556804197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unexpected StringComparison type: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(171801444453)
            
            //--TRIMMABLE-BOUNDARY-START(64427262053)
            static /*string */ FormatUnexpectedStringComparisonType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427262053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Unexpected StringComparison type: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64427262053)
            
            //--TRIMMABLE-BOUNDARY-START(154621575269)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(154621575269)
            
            //--TRIMMABLE-BOUNDARY-START(137441706085)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137441706085);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137441706085)
            
            //--TRIMMABLE-BOUNDARY-START(176096411749)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176096411749);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mef.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176096411749)
            
            //--TRIMMABLE-BOUNDARY-START(128851771493)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851771493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mef.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(128851771493)
            
            //--TRIMMABLE-BOUNDARY-START(133146738789)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146738789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mef.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(133146738789)
            
            //--TRIMMABLE-BOUNDARY-START(25772556389)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772556389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25772556389)
            
            //--TRIMMABLE-BOUNDARY-START(30067523685)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067523685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(30067523685)
            
            //--TRIMMABLE-BOUNDARY-START(34362490981)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362490981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34362490981)
            
            //--TRIMMABLE-BOUNDARY-START(38657458277)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657458277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mef.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(38657458277)
            
            //--TRIMMABLE-BOUNDARY-START(42952425573)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952425573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42952425573)
            
            //--TRIMMABLE-BOUNDARY-START(47247392869)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247392869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47247392869)
            
            //--TRIMMABLE-BOUNDARY-START(51542360165)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542360165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51542360165)
            
            //--TRIMMABLE-BOUNDARY-START(55837327461)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837327461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mef.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55837327461)
            
            //--TRIMMABLE-BOUNDARY-START(4297719909)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(154621575269)
                    this.s_usingResourceKeys = $.$mef.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(154621575269)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297719909)
            
            static $h = 2752613;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 2752613
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752613)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490469)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions", ($self) => class MatcherExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4297457765)
            static /*void */ AddExcludePatterns(/*this Matcher*/ matcher, /*params IEnumerable<string>[]*/ excludePatternsGroups)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297457765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = excludePatternsGroups;
                while ($i1 < $arr1.length)
                {
                    let group = $arr1[$i1++];
                    var $en3 = group.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pattern = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            matcher.AddExclude(pattern);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297457765)
            
            //--TRIMMABLE-BOUNDARY-START(8592425061)
            static /*void */ AddIncludePatterns(/*this Matcher*/ matcher, /*params IEnumerable<string>[]*/ includePatternsGroups)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592425061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = includePatternsGroups;
                while ($i1 < $arr1.length)
                {
                    let group = $arr1[$i1++];
                    var $en3 = group.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pattern = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            matcher.AddInclude(pattern);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592425061)
            
            //--TRIMMABLE-BOUNDARY-START(12887392357)
            static /*IEnumerable<string> */ GetResultsInFullPath(/*this Matcher*/ matcher, /*string*/ directoryPath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887392357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PatternMatchingResult*/ let patternMatchingResult = matcher.Execute(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(new $.$$.System.IO.DirectoryInfo().$ctor$5(directoryPath)));
                if (!patternMatchingResult.HasMatches)
                {
                    return $.$$.System.Array.Empty($.$$.System.String);
                }
                /*IEnumerable<FilePatternMatch>*/ let matches = patternMatchingResult.Files;
                let matchCollection;
                /*List<string>*/ let result = $.$is(matches, $.$$.System.Collections.ICollection, { set $v(v){ matchCollection = v; } }) ? new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3(matchCollection.System$Collections$ICollection$Count) : new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                var $en2 = matches.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var match = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        result.Add($.$$.System.IO.Path.GetFullPath$1($.$$.System.IO.Path.Combine$3(directoryPath, match.Path)));
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(12887392357)
            
            //--TRIMMABLE-BOUNDARY-START(17182359653)
            static /*PatternMatchingResult */ Match$3(/*this Matcher*/ matcher, /*string*/ file)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182359653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$1(matcher, $.$$.System.IO.Directory.GetCurrentDirectory(), (() =>
                {
                    //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                    const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add(file);
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(17182359653)
            
            //--TRIMMABLE-BOUNDARY-START(21477326949)
            static /*PatternMatchingResult */ Match$2(/*this Matcher*/ matcher, /*string*/ rootDir, /*string*/ file)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477326949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$1(matcher, rootDir, (() =>
                {
                    //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                    const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add(file);
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(21477326949)
            
            //--TRIMMABLE-BOUNDARY-START(25772294245)
            static /*PatternMatchingResult */ Match(/*this Matcher*/ matcher, /*IEnumerable<string>?*/ files)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772294245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$1(matcher, $.$$.System.IO.Directory.GetCurrentDirectory(), files);
            }
            //--TRIMMABLE-BOUNDARY-END(25772294245)
            
            //--TRIMMABLE-BOUNDARY-START(30067261541)
            static /*PatternMatchingResult */ Match$1(/*this Matcher*/ matcher, /*string*/ rootDir, /*IEnumerable<string>?*/ files)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067261541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(matcher, "matcher");
                return matcher.Execute(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$4(rootDir, files));
            }
            //--TRIMMABLE-BOUNDARY-END(30067261541)
            
            static $h = 2490469;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4297457765),
    {
      "r": 65537,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "excludePatternsGroups",
          "p": $.$typeArray($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String)).$h,
          "f": 16
        }
      ],
      "n": "AddExcludePatterns",
      "d": 2490469,
      "h": 4297457765,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4297457765),
//--TRIMMABLE-BOUNDARY-START(8592425061),
    {
      "r": 65537,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "includePatternsGroups",
          "p": $.$typeArray($.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String)).$h,
          "f": 16
        }
      ],
      "n": "AddIncludePatterns",
      "d": 2490469,
      "h": 8592425061,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8592425061),
//--TRIMMABLE-BOUNDARY-START(12887392357),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "directoryPath",
          "p": 1310721
        }
      ],
      "n": "GetResultsInFullPath",
      "d": 2490469,
      "h": 12887392357,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12887392357),
//--TRIMMABLE-BOUNDARY-START(17182359653),
    {
      "r": 2556005,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "file",
          "p": 1310721
        }
      ],
      "n": "Match",
      "o": "@$3",
      "d": 2490469,
      "h": 17182359653,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17182359653),
//--TRIMMABLE-BOUNDARY-START(21477326949),
    {
      "r": 2556005,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "rootDir",
          "p": 1310721
        },
        {
          "n": "file",
          "p": 1310721
        }
      ],
      "n": "Match",
      "o": "@$2",
      "d": 2490469,
      "h": 21477326949,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477326949),
//--TRIMMABLE-BOUNDARY-START(25772294245),
    {
      "r": 2556005,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Match",
      "d": 2490469,
      "h": 25772294245,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772294245),
//--TRIMMABLE-BOUNDARY-START(30067261541),
    {
      "r": 2556005,
      "p": [
        {
          "n": "matcher",
          "p": 2424933
        },
        {
          "n": "rootDir",
          "p": 1310721
        },
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Match",
      "o": "@$1",
      "d": 2490469,
      "h": 30067261541,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30067261541)
  ],
  "h": 2490469
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490469)
        
        
        //--TRIMMABLE-BOUNDARY-START(2556005)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult", ($self) => class PatternMatchingResult extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297523301)
            $ctor$2(/*IEnumerable<FilePatternMatch>*/ files)
            {
                this.$ctor$1(files, $.$sl.System.Linq.Enumerable.Any$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, files));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297523301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Files = files;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297523301)
            
            //--TRIMMABLE-BOUNDARY-START(8592490597)
            $ctor$1(/*IEnumerable<FilePatternMatch>*/ files, /*bool*/ hasMatches)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592490597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(files, "files");
                    this.Files = files;
                    this.HasMatches = hasMatches;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592490597)
            
            //--TRIMMABLE-BOUNDARY-START(21477392485)
            /*IEnumerable<FilePatternMatch>*/ Files = null;
            //--TRIMMABLE-BOUNDARY-END(21477392485)
            
            //--TRIMMABLE-BOUNDARY-START(42952228965)
            /*bool*/ HasMatches = false;
            //--TRIMMABLE-BOUNDARY-END(42952228965)
            
            static $h = 2556005;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477392485),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067327077,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51542163557,
        "f": 83886081
      },
      "n": "Files",
      "d": 2556005,
      "h": 21477392485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477392485),
//--TRIMMABLE-BOUNDARY-START(42952228965),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657261669,
        "f": 50331649
      },
      "n": "HasMatches",
      "d": 2556005,
      "h": 42952228965,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42952228965)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523301),
    {
      "p": [
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2556005,
      "h": 4297523301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523301),
//--TRIMMABLE-BOUNDARY-START(8592490597),
    {
      "p": [
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h
        },
        {
          "n": "hasMatches",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2556005,
      "h": 8592490597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592490597)
  ],
  "h": 2556005
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2556005)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424933)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher", ($self) => class Matcher extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21477261413)
            /*List<IPattern>?*/ _includePatterns = null;
            //--TRIMMABLE-BOUNDARY-END(21477261413)
            
            //--TRIMMABLE-BOUNDARY-START(12887326821)
            /*List<IPattern>?*/ _excludePatterns = null;
            //--TRIMMABLE-BOUNDARY-END(12887326821)
            
            //--TRIMMABLE-BOUNDARY-START(17182294117)
            /*List<IncludeOrExcludeValue<IPattern>>?*/ _includeOrExcludePatterns = null;
            //--TRIMMABLE-BOUNDARY-END(17182294117)
            
            //--TRIMMABLE-BOUNDARY-START(4297392229)
            /*PatternBuilder*/ _builder = null;
            //--TRIMMABLE-BOUNDARY-END(4297392229)
            
            //--TRIMMABLE-BOUNDARY-START(8592359525)
            /*StringComparison*/ _comparison = 0;
            //--TRIMMABLE-BOUNDARY-END(8592359525)
            
            //--TRIMMABLE-BOUNDARY-START(25772228709)
            /*bool*/ _preserveFilterOrder = false;
            //--TRIMMABLE-BOUNDARY-END(25772228709)
            
            //--TRIMMABLE-BOUNDARY-START(30067196005)
            $ctor$1()
            {
                this.$ctor$2(5/*StringComparison.OrdinalIgnoreCase*/, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067196005);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067196005)
            
            //--TRIMMABLE-BOUNDARY-START(34362163301)
            $ctor$3(/*StringComparison*/ comparisonType)
            {
                this.$ctor$2(comparisonType, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362163301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362163301)
            
            //--TRIMMABLE-BOUNDARY-START(38657130597)
            $ctor$2(/*StringComparison*/ comparisonType, /*bool*/ preserveFilterOrder)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657130597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._comparison = comparisonType;
                    this._builder = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder().$ctor$2(comparisonType);
                    this._preserveFilterOrder = preserveFilterOrder;
                    if (preserveFilterOrder)
                    {
                        this._includeOrExcludePatterns = (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)))().$ctor$1();
                            return $t1;
                        })();
                    }
                    else 
                    {
                        this._includePatterns = (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern))().$ctor$1();
                            return $t1;
                        })();
                        this._excludePatterns = (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern))().$ctor$1();
                            return $t1;
                        })();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657130597)
            
            //--TRIMMABLE-BOUNDARY-START(47247065189)
            /*Matcher */ AddInclude(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._preserveFilterOrder)
                {
                    this._includeOrExcludePatterns.Add((() =>
                    {
                        //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)()
                        const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern);
                        const $i1 = new $t1();
                        $i1.Value = this._builder.Build(pattern);
                        $i1.IsInclude = true;
                        return $i1;
                    })());
                }
                else 
                {
                    this._includePatterns.Add(this._builder.Build(pattern));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47247065189)
            
            //--TRIMMABLE-BOUNDARY-START(42952097893)
            /*Matcher */ AddExclude(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952097893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._preserveFilterOrder)
                {
                    this._includeOrExcludePatterns.Add((() =>
                    {
                        //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)()
                        const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern);
                        const $i1 = new $t1();
                        $i1.Value = this._builder.Build(pattern);
                        $i1.IsInclude = false;
                        return $i1;
                    })());
                }
                else 
                {
                    this._excludePatterns.Add(this._builder.Build(pattern));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952097893)
            
            //--TRIMMABLE-BOUNDARY-START(51542032485)
            /*PatternMatchingResult */ Execute(/*DirectoryInfoBase*/ directoryInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542032485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(directoryInfo, "directoryInfo");
                return this._preserveFilterOrder ? new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext().$ctor$2(this._includeOrExcludePatterns, directoryInfo, this._comparison).Execute() : new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext().$ctor$1(this._includePatterns, this._excludePatterns, directoryInfo, this._comparison).Execute();
            }
            //--TRIMMABLE-BOUNDARY-END(51542032485)
            
            static $h = 2424933;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47247065189),
    {
      "r": 2424933,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "AddInclude",
      "d": 2424933,
      "h": 47247065189,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47247065189),
//--TRIMMABLE-BOUNDARY-START(42952097893),
    {
      "r": 2424933,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "AddExclude",
      "d": 2424933,
      "h": 42952097893,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42952097893),
//--TRIMMABLE-BOUNDARY-START(51542032485),
    {
      "r": 2556005,
      "p": [
        {
          "n": "directoryInfo",
          "p": 65637
        }
      ],
      "n": "Execute",
      "d": 2424933,
      "h": 51542032485,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51542032485)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21477261413),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h,
      "n": "_includePatterns",
      "d": 2424933,
      "h": 21477261413,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21477261413),
//--TRIMMABLE-BOUNDARY-START(12887326821),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h,
      "n": "_excludePatterns",
      "d": 2424933,
      "h": 12887326821,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887326821),
//--TRIMMABLE-BOUNDARY-START(17182294117),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)).$h,
      "n": "_includeOrExcludePatterns",
      "d": 2424933,
      "h": 17182294117,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17182294117),
//--TRIMMABLE-BOUNDARY-START(4297392229),
    {
      "t": 2162789,
      "n": "_builder",
      "d": 2424933,
      "h": 4297392229,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297392229),
//--TRIMMABLE-BOUNDARY-START(8592359525),
    {
      "t": 163446785,
      "n": "_comparison",
      "d": 2424933,
      "h": 8592359525,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592359525),
//--TRIMMABLE-BOUNDARY-START(25772228709),
    {
      "t": 262145,
      "n": "_preserveFilterOrder",
      "d": 2424933,
      "h": 25772228709,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25772228709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30067196005),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424933,
      "h": 30067196005,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067196005),
//--TRIMMABLE-BOUNDARY-START(34362163301),
    {
      "p": [
        {
          "n": "comparisonType",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2424933,
      "h": 34362163301,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362163301),
//--TRIMMABLE-BOUNDARY-START(38657130597),
    {
      "p": [
        {
          "n": "comparisonType",
          "p": 163446785,
          "f": 65,
          "v": 5
        },
        {
          "n": "preserveFilterOrder",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2424933,
      "h": 38657130597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657130597)
  ],
  "h": 2424933
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Matcher`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424933)
        
        
        //--TRIMMABLE-BOUNDARY-START(983141)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext", ($self) => class MatcherContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065754213)
            /*DirectoryInfoBase*/ _root = null;
            //--TRIMMABLE-BOUNDARY-END(30065754213)
            
            //--TRIMMABLE-BOUNDARY-START(25770786917)
            /*IPatternContext*/ _patternContext = null;
            //--TRIMMABLE-BOUNDARY-END(25770786917)
            
            //--TRIMMABLE-BOUNDARY-START(21475819621)
            /*List<FilePatternMatch>*/ _files = null;
            //--TRIMMABLE-BOUNDARY-END(21475819621)
            
            //--TRIMMABLE-BOUNDARY-START(8590917733)
            /*HashSet<string>*/ _declaredLiteralFolderSegmentInString = null;
            //--TRIMMABLE-BOUNDARY-END(8590917733)
            
            //--TRIMMABLE-BOUNDARY-START(4295950437)
            /*HashSet<LiteralPathSegment>*/ _declaredLiteralFileSegments = null;
            //--TRIMMABLE-BOUNDARY-END(4295950437)
            
            //--TRIMMABLE-BOUNDARY-START(12885885029)
            /*bool*/ _declaredParentPathSegment = false;
            //--TRIMMABLE-BOUNDARY-END(12885885029)
            
            //--TRIMMABLE-BOUNDARY-START(17180852325)
            /*bool*/ _declaredWildcardPathSegment = false;
            //--TRIMMABLE-BOUNDARY-END(17180852325)
            
            //--TRIMMABLE-BOUNDARY-START(34360721509)
            $ctor$1(/*IEnumerable<IPattern>*/ includePatterns, /*IEnumerable<IPattern>*/ excludePatterns, /*DirectoryInfoBase*/ directoryInfo, /*StringComparison*/ comparison)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360721509);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._root = directoryInfo;
                    this._files = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch))().$ctor$1();
                        return $t1;
                    })();
                    this._declaredLiteralFolderSegmentInString = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$4($.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(comparison));
                    /*IPatternContext[]*/ let includePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$sl.System.Linq.Enumerable.Select$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, includePatterns, new ($.$$.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext))().$ctor(this,  (/*pattern*/ pattern) =>
                    {
                        return pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude();
                    }, {
  "r": 852069,
  "p": [
    {
      "n": "pattern",
      "p": 786533
    }
  ],
  "n": "",
  "d": 983141,
  "h": 0,
  "f": 17825794
})));
                    /*IPatternContext[]*/ let excludePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$sl.System.Linq.Enumerable.Select$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, excludePatterns, new ($.$$.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext))().$ctor(this,  (/**/ pattern) =>
                    {
                        return pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude();
                    }, {
  "r": 852069,
  "p": [
    {
      "n": "pattern",
      "p": 786533
    }
  ],
  "n": "",
  "d": 983141,
  "h": 0,
  "f": 17825794
})));
                    this._patternContext = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext().$ctor$2(includePatternContexts, excludePatternContexts);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721509)
            
            //--TRIMMABLE-BOUNDARY-START(38655688805)
            $ctor$2(/*List<IncludeOrExcludeValue<IPattern>>*/ orderedPatterns, /*DirectoryInfoBase*/ directoryInfo, /*StringComparison*/ comparison)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655688805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._root = directoryInfo;
                    this._files = (() =>
                    {
                        let $t1 = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch))().$ctor$1();
                        return $t1;
                    })();
                    this._declaredLiteralFolderSegmentInString = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$4($.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(comparison));
                    /*IncludeOrExcludeValue<IPatternContext>[]*/ let includeOrExcludePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext), $.$sl.System.Linq.Enumerable.Select$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern), $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext), orderedPatterns, new ($.$$.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern), $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)))().$ctor(this,  (/*item*/ item) =>
                    {
                        return (() =>
                        {
                            //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)()
                            const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext);
                            const $i1 = new $t1();
                            $i1.Value = item.IsInclude ? item.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude() : item.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude();
                            $i1.IsInclude = item.IsInclude;
                            return $i1;
                        })();
                    }, {
  "r": $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext).$h,
  "p": [
    {
      "n": "item",
      "p": $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h
    }
  ],
  "n": "",
  "d": 983141,
  "h": 0,
  "f": 17825794
})));
                    this._patternContext = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext().$ctor$2(includeOrExcludePatternContexts);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688805)
            
            //--TRIMMABLE-BOUNDARY-START(55835557989)
            /*PatternMatchingResult */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._files.Clear();
                this.Match(this._root, null);
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult().$ctor$1(this._files, this._files.Count > 0);
            }
            //--TRIMMABLE-BOUNDARY-END(55835557989)
            
            //--TRIMMABLE-BOUNDARY-START(60130525285)
            /*void */ Match(/*DirectoryInfoBase*/ directory, /*string?*/ parentRelativePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130525285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                this.Declare();
                /*var*/ let entities = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase))().$ctor$1();
                if (this._declaredWildcardPathSegment || this._declaredLiteralFileSegments.Count !== 0)
                {
                    entities.AddRange(directory.EnumerateFileSystemInfos());
                }
                else 
                {
                    /*IEnumerable<FileSystemInfoBase>*/ let candidates = directory.EnumerateFileSystemInfos();
                    var $en3 = candidates.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var candidate = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$is(candidate, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase) && this._declaredLiteralFolderSegmentInString.Contains(candidate.Name))
                            {
                                entities.Add(candidate);
                            }
                        }
                    }
                }
                if (this._declaredParentPathSegment)
                {
                    entities.Add(directory.GetDirectory(".."));
                }
                /*var*/ let subDirectories = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase))().$ctor$1();
                var $en2 = entities.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entity = $en2.Current;
                    {
                        let fileInfo;
                        if ($.$is(entity, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, { set $v(v){ fileInfo = v; } }))
                        {
                            /*PatternTestResult*/ let result = this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1(fileInfo);
                            if (result.IsSuccessful)
                            {
                                this._files.Add(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch().$ctor$3($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(parentRelativePath, fileInfo.Name), result.Stem));
                            }
                            continue;
                        }
                        let directoryInfo;
                        if ($.$is(entity, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, { set $v(v){ directoryInfo = v; } }))
                        {
                            if (this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test(directoryInfo))
                            {
                                subDirectories.Add(directoryInfo);
                            }
                            continue;
                        }
                    }
                }
                var $en2 = subDirectories.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var subDir = $en2.Current;
                    {
                        /*string*/ let relativePath = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(parentRelativePath, subDir.Name);
                        this.Match(subDir, relativePath);
                    }
                }
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525285)
            
            //--TRIMMABLE-BOUNDARY-START(47245623397)
            /*void */ Declare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._declaredLiteralFileSegments.Clear();
                this._declaredParentPathSegment = false;
                this._declaredWildcardPathSegment = false;
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(new ($.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean))().$ctor(this, this.DeclareInclude));
            }
            //--TRIMMABLE-BOUNDARY-END(47245623397)
            
            //--TRIMMABLE-BOUNDARY-START(51540590693)
            /*void */ DeclareInclude(/*IPathSegment*/ patternSegment, /*bool*/ isLastSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let literalSegment;
                if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment, { set $v(v){ literalSegment = v; } }))
                {
                    if (isLastSegment)
                    {
                        this._declaredLiteralFileSegments.Add(literalSegment);
                    }
                    else 
                    {
                        this._declaredLiteralFolderSegmentInString.Add(literalSegment.Value);
                    }
                }
                else if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment))
                {
                    this._declaredParentPathSegment = true;
                }
                else if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment))
                {
                    this._declaredWildcardPathSegment = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540590693)
            
            //--TRIMMABLE-BOUNDARY-START(42950656101)
            static /*string */ CombinePath(/*string?*/ left, /*string*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(left))
                {
                    return right;
                }
                else 
                {
                    return `${left}/${right}`;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950656101)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295950437)
                this._declaredLiteralFileSegments = new ($.$$.System.Collections.Generic.HashSet$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295950437)
                
            }
            static $h = 983141;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835557989),
    {
      "r": 2556005,
      "n": "Execute",
      "d": 983141,
      "h": 55835557989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835557989),
//--TRIMMABLE-BOUNDARY-START(60130525285),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        },
        {
          "n": "parentRelativePath",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 983141,
      "h": 60130525285,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130525285),
//--TRIMMABLE-BOUNDARY-START(47245623397),
    {
      "r": 65537,
      "n": "Declare",
      "d": 983141,
      "h": 47245623397,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245623397),
//--TRIMMABLE-BOUNDARY-START(51540590693),
    {
      "r": 65537,
      "p": [
        {
          "n": "patternSegment",
          "p": 720997
        },
        {
          "n": "isLastSegment",
          "p": 262145
        }
      ],
      "n": "DeclareInclude",
      "d": 983141,
      "h": 51540590693,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540590693),
//--TRIMMABLE-BOUNDARY-START(42950656101),
    {
      "r": 1310721,
      "p": [
        {
          "n": "left",
          "p": 1310721
        },
        {
          "n": "right",
          "p": 1310721
        }
      ],
      "n": "CombinePath",
      "d": 983141,
      "h": 42950656101,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950656101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065754213),
    {
      "t": 65637,
      "n": "_root",
      "d": 983141,
      "h": 30065754213,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065754213),
//--TRIMMABLE-BOUNDARY-START(25770786917),
    {
      "t": 852069,
      "n": "_patternContext",
      "d": 983141,
      "h": 25770786917,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786917),
//--TRIMMABLE-BOUNDARY-START(21475819621),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h,
      "n": "_files",
      "d": 983141,
      "h": 21475819621,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819621),
//--TRIMMABLE-BOUNDARY-START(8590917733),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$$.System.String).$h,
      "n": "_declaredLiteralFolderSegmentInString",
      "d": 983141,
      "h": 8590917733,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917733),
//--TRIMMABLE-BOUNDARY-START(4295950437),
    {
      "t": $.$$.System.Collections.Generic.HashSet$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment).$h,
      "n": "_declaredLiteralFileSegments",
      "d": 983141,
      "h": 4295950437,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950437),
//--TRIMMABLE-BOUNDARY-START(12885885029),
    {
      "t": 262145,
      "n": "_declaredParentPathSegment",
      "d": 983141,
      "h": 12885885029,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885885029),
//--TRIMMABLE-BOUNDARY-START(17180852325),
    {
      "t": 262145,
      "n": "_declaredWildcardPathSegment",
      "d": 983141,
      "h": 17180852325,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852325)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360721509),
    {
      "p": [
        {
          "n": "includePatterns",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h
        },
        {
          "n": "excludePatterns",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h
        },
        {
          "n": "directoryInfo",
          "p": 65637
        },
        {
          "n": "comparison",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983141,
      "h": 34360721509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360721509),
//--TRIMMABLE-BOUNDARY-START(38655688805),
    {
      "p": [
        {
          "n": "orderedPatterns",
          "p": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)).$h
        },
        {
          "n": "directoryInfo",
          "p": 65637
        },
        {
          "n": "comparison",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983141,
      "h": 38655688805,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655688805)
  ],
  "h": 983141
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983141)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162789)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder", ($self) => class PatternBuilder extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297130085)
            /*char[]*/ static _slashes = null;
            //--TRIMMABLE-BOUNDARY-END(4297130085)
            
            //--TRIMMABLE-BOUNDARY-START(8592097381)
            /*char[]*/ static _star = null;
            //--TRIMMABLE-BOUNDARY-END(8592097381)
            
            //--TRIMMABLE-BOUNDARY-START(17182031973)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182031973);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ComparisonType = 5/*StringComparison.OrdinalIgnoreCase*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182031973)
            
            //--TRIMMABLE-BOUNDARY-START(21476999269)
            $ctor$2(/*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476999269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ComparisonType = comparisonType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476999269)
            
            //--TRIMMABLE-BOUNDARY-START(34361901157)
            /*StringComparison*/ ComparisonType = 0;
            //--TRIMMABLE-BOUNDARY-END(34361901157)
            
            //--TRIMMABLE-BOUNDARY-START(30066933861)
            /*IPattern */ Build(/*string*/ pattern)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(pattern, "pattern");
                pattern = $.$$.System.String.TrimStart$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes);
                if ($.$$.System.String.TrimEnd$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes).length < pattern.length)
                {
                    pattern = $.$$.System.String.TrimEnd$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes) + "/**";
                }
                /*var*/ let allSegments = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                /*bool*/ let isParentSegmentLegal = true;
                /*List<IPathSegment>?*/ let segmentsPatternStartsWith = null;
                /*List<IList<IPathSegment>>?*/ let segmentsPatternContains = null;
                /*List<IPathSegment>?*/ let segmentsPatternEndsWith = null;
                /*int*/ let endPattern = pattern.length;
                for(/*int*/ let scanPattern = 0; scanPattern < endPattern; )
                {
                    /*int*/ let beginSegment = scanPattern;
                    /*int*/ let endSegment = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.NextIndex(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes, scanPattern, endPattern);
                    /*IPathSegment?*/ let segment = null;
                    if (segment === null && ((endSegment - beginSegment) | 0) === 3)
                    {
                        if ($.$$.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /*.*/ 46 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 2) | 0)) === /***/ 42)
                        {
                            beginSegment += 2;
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) === 2)
                    {
                        if ($.$$.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /***/ 42)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment().$ctor$1();
                        }
                        else if ($.$$.System.String.get_Chars.call(pattern, beginSegment) === /*.*/ 46 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /*.*/ 46)
                        {
                            if (!isParentSegmentLegal)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$14("\"..\" can be only added at the beginning of the pattern.");
                            }
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment().$ctor$1();
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) === 1)
                    {
                        if ($.$$.System.String.get_Chars.call(pattern, beginSegment) === /*.*/ 46)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment().$ctor$1();
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) > 2)
                    {
                        if ($.$$.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /***/ 42 && $.$$.System.String.get_Chars.call(pattern, ((beginSegment + 2) | 0)) === /*.*/ 46)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment().$ctor$1();
                            endSegment = beginSegment;
                        }
                    }
                    if (segment === null)
                    {
                        /*string*/ let beginsWith = $.$$.System.String.Empty;
                        /*var*/ let contains = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                        /*string*/ let endsWith = $.$$.System.String.Empty;
                        for(/*int*/ let scanSegment = beginSegment; scanSegment < endSegment; )
                        {
                            /*int*/ let beginLiteral = scanSegment;
                            /*int*/ let endLiteral = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.NextIndex(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._star, scanSegment, endSegment);
                            if (beginLiteral === beginSegment)
                            {
                                if (endLiteral === endSegment)
                                {
                                    segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment().$ctor$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral), this.ComparisonType);
                                }
                                else 
                                {
                                    beginsWith = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral);
                                }
                            }
                            else if (endLiteral === endSegment)
                            {
                                endsWith = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral);
                            }
                            else 
                            {
                                if (beginLiteral !== endLiteral)
                                {
                                    contains.Add($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral));
                                }
                                else 
                                {
                                }
                            }
                            scanSegment = ((endLiteral + 1) | 0);
                        }
                        segment ??= new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment().$ctor$1(beginsWith, contains, endsWith, this.ComparisonType);
                    }
                    if (!(segment !== null && ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment))))
                    {
                        isParentSegmentLegal = false;
                    }
                    if ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment))
                    {
                    }
                    else 
                    {
                        if ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment))
                        {
                            if (segmentsPatternStartsWith === null)
                            {
                                segmentsPatternStartsWith = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$2(allSegments);
                                segmentsPatternEndsWith = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                                segmentsPatternContains = new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)))().$ctor$1();
                            }
                            else if (segmentsPatternEndsWith.Count !== 0)
                            {
                                segmentsPatternContains.Add(segmentsPatternEndsWith);
                                segmentsPatternEndsWith = new ($.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                            }
                        }
                        else 
                        {
                            segmentsPatternEndsWith?.Add(segment);
                        }
                        allSegments.Add(segment);
                    }
                    scanPattern = ((endSegment + 1) | 0);
                }
                if (segmentsPatternStartsWith === null)
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern().$ctor$1(allSegments);
                }
                else 
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern().$ctor$1(allSegments, segmentsPatternStartsWith, segmentsPatternEndsWith, segmentsPatternContains);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066933861)
            
            //--TRIMMABLE-BOUNDARY-START(51541770341)
            static /*int */ NextIndex(/*string*/ pattern, /*char[]*/ anyOf, /*int*/ beginIndex, /*int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541770341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = $.$$.System.String.IndexOfAny.call(pattern, anyOf, beginIndex, ((endIndex - beginIndex) | 0));
                return index === -1 ? endIndex : index;
            }
            //--TRIMMABLE-BOUNDARY-END(51541770341)
            
            //--TRIMMABLE-BOUNDARY-START(55836737637)
            static /*string */ Portion(/*string*/ pattern, /*int*/ beginIndex, /*int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Substring.call(pattern, beginIndex, ((endIndex - beginIndex) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(55836737637)
            
            //--TRIMMABLE-BOUNDARY-START(2228325)
            static $_LinearPattern;
            static get LinearPattern()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder;
                return $cls.$_LinearPattern ??= $asm.$ncls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern", ($self) => class LinearPattern extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4297195621)
                    $ctor$1(/*List<IPathSegment>*/ allSegments)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297195621);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Segments = allSegments;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297195621)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066999397)
                    /*IList<IPathSegment>*/ Segments = null;
                    //--TRIMMABLE-BOUNDARY-END(30066999397)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182097509)
                    /*IPatternContext */ CreatePatternContextForInclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182097509);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude().$ctor$3(this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182097509)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887130213)
                    /*IPatternContext */ CreatePatternContextForExclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887130213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude().$ctor$3(this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887130213)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458981)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern.Segments.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885426277);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Segments;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458981)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721125)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForInclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590721125);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreatePatternContextForInclude(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721125)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753829)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForExclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295753829);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreatePatternContextForExclude(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295753829)
                    
                    static $h = 2228325;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066999397),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772032101,
        "f": 50331649
      },
      "n": "Segments",
      "d": 2228325,
      "h": 30066999397,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066999397)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182097509),
    {
      "r": 852069,
      "n": "CreatePatternContextForInclude",
      "d": 2228325,
      "h": 17182097509,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182097509),
//--TRIMMABLE-BOUNDARY-START(12887130213),
    {
      "r": 852069,
      "n": "CreatePatternContextForExclude",
      "d": 2228325,
      "h": 12887130213,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887130213)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195621),
    {
      "p": [
        {
          "n": "allSegments",
          "p": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228325,
      "h": 4297195621,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297195621)
  ],
  "i": [524389,786533
  ],
  "d": 2162789,
  "h": 2228325
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern`; }
                }, $cls, ($v) => $cls.$_LinearPattern = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2228325)
            
            //--TRIMMABLE-BOUNDARY-START(2293861)
            static $_RaggedPattern;
            static get RaggedPattern()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder;
                return $cls.$_RaggedPattern ??= $asm.$ncls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern", ($self) => class RaggedPattern extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4297261157)
                    $ctor$1(/*List<IPathSegment>*/ allSegments, /*IList<IPathSegment>*/ segmentsPatternStartsWith, /*IList<IPathSegment>*/ segmentsPatternEndsWith, /*IList<IList<IPathSegment>>*/ segmentsPatternContains)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297261157);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Segments = allSegments;
                            this.StartsWith = segmentsPatternStartsWith;
                            this.Contains = segmentsPatternContains;
                            this.EndsWith = segmentsPatternEndsWith;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297261157)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772097637)
                    /*IList<IList<IPathSegment>>*/ Contains = null;
                    //--TRIMMABLE-BOUNDARY-END(25772097637)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656999525)
                    /*IList<IPathSegment>*/ EndsWith = null;
                    //--TRIMMABLE-BOUNDARY-END(38656999525)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311705189)
                    /*IList<IPathSegment>*/ Segments = null;
                    //--TRIMMABLE-BOUNDARY-END(77311705189)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606672485)
                    /*IList<IPathSegment>*/ StartsWith = null;
                    //--TRIMMABLE-BOUNDARY-END(81606672485)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362032229)
                    /*IPatternContext */ CreatePatternContextForInclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362032229);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude().$ctor$3(this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362032229)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067064933)
                    /*IPatternContext */ CreatePatternContextForExclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067064933);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude().$ctor$3(this);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067064933)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655973)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.Segments.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Segments()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245557861);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Segments;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360655973)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950590565)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.StartsWith.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540525157);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.StartsWith;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950590565)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786789)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.Contains.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295884901);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786789)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770721381)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.EndsWith.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590852197);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.EndsWith;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770721381)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721125)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForInclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590721125);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreatePatternContextForInclude(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721125)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753829)
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForExclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295753829);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CreatePatternContextForExclude(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295753829)
                    
                    static $h = 2293861;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772097637),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246934117,
        "f": 50331649
      },
      "n": "Contains",
      "d": 2293861,
      "h": 25772097637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772097637),
//--TRIMMABLE-BOUNDARY-START(38656999525),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836868709,
        "f": 50331649
      },
      "n": "EndsWith",
      "d": 2293861,
      "h": 38656999525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656999525),
//--TRIMMABLE-BOUNDARY-START(77311705189),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426803301,
        "f": 50331649
      },
      "n": "Segments",
      "d": 2293861,
      "h": 77311705189,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311705189),
//--TRIMMABLE-BOUNDARY-START(81606672485),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016737893,
        "f": 50331649
      },
      "n": "StartsWith",
      "d": 2293861,
      "h": 81606672485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606672485)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34362032229),
    {
      "r": 852069,
      "n": "CreatePatternContextForInclude",
      "d": 2293861,
      "h": 34362032229,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362032229),
//--TRIMMABLE-BOUNDARY-START(30067064933),
    {
      "r": 852069,
      "n": "CreatePatternContextForExclude",
      "d": 2293861,
      "h": 30067064933,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067064933)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261157),
    {
      "p": [
        {
          "n": "allSegments",
          "p": $.$$.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h
        },
        {
          "n": "segmentsPatternStartsWith",
          "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h
        },
        {
          "n": "segmentsPatternEndsWith",
          "p": $.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h
        },
        {
          "n": "segmentsPatternContains",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2293861,
      "h": 4297261157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261157)
  ],
  "i": [917605,786533
  ],
  "d": 2162789,
  "h": 2293861
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern`; }
                }, $cls, ($v) => $cls.$_RaggedPattern = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293861)
            
            //--TRIMMABLE-BOUNDARY-START(12887064677)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4297130085)
                    this._slashes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*/*/ 47, /*\\*/ 92], null, null);
                    //--TRIMMABLE-BOUNDARY-END(4297130085)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8592097381)
                    this._star = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/***/ 42], null, null);
                    //--TRIMMABLE-BOUNDARY-END(8592097381)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12887064677)
            
            static $h = 2162789;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361901157),
    {
      "p": 163446785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951835749,
        "f": 50331649
      },
      "n": "ComparisonType",
      "d": 2162789,
      "h": 34361901157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361901157)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066933861),
    {
      "r": 786533,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": "Build",
      "d": 2162789,
      "h": 30066933861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066933861),
//--TRIMMABLE-BOUNDARY-START(51541770341),
    {
      "r": 655361,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "anyOf",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "beginIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "NextIndex",
      "d": 2162789,
      "h": 51541770341,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51541770341),
//--TRIMMABLE-BOUNDARY-START(55836737637),
    {
      "r": 1310721,
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        },
        {
          "n": "beginIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "Portion",
      "d": 2162789,
      "h": 55836737637,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55836737637)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297130085),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_slashes",
      "d": 2162789,
      "h": 4297130085,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4297130085),
//--TRIMMABLE-BOUNDARY-START(8592097381),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_star",
      "d": 2162789,
      "h": 8592097381,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8592097381)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182031973),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162789,
      "h": 17182031973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182031973),
//--TRIMMABLE-BOUNDARY-START(21476999269),
    {
      "p": [
        {
          "n": "comparisonType",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2162789,
      "h": 21476999269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476999269)
  ],
  "j": [2228325,2293861
  ],
  "h": 2162789
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162789)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245285)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment", ($self) => class RecursiveWildcardSegment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591179877)
            /*bool */ get CanProduceStem()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179877)
            
            //--TRIMMABLE-BOUNDARY-START(21476081765)
            /*bool */ Match(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476081765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476081765)
            
            //--TRIMMABLE-BOUNDARY-START(12885622885)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProduceStem;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622885)
            
            //--TRIMMABLE-BOUNDARY-START(17180590181)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Match(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590181)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1245285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591179877),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181114469,
        "f": 50331649
      },
      "n": "CanProduceStem",
      "d": 1245285,
      "h": 8591179877,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591179877)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476081765),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 1245285,
      "h": 21476081765,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476081765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212581),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245285,
      "h": 4296212581,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212581)
  ],
  "i": [720997
  ],
  "h": 1245285
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245285)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048677)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment", ($self) => class CurrentPathSegment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983269)
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983269)
            
            //--TRIMMABLE-BOUNDARY-START(21475885157)
            /*bool */ Match(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475885157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475885157)
            
            //--TRIMMABLE-BOUNDARY-START(12885622885)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProduceStem;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622885)
            
            //--TRIMMABLE-BOUNDARY-START(17180590181)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Match(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590181)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1048677;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590983269),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180917861,
        "f": 50331649
      },
      "n": "CanProduceStem",
      "d": 1048677,
      "h": 8590983269,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590983269)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475885157),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 1048677,
      "h": 21475885157,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885157)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015973),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048677,
      "h": 4296015973,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015973)
  ],
  "i": [720997
  ],
  "h": 1048677
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048677)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179749)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment", ($self) => class ParentPathSegment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476016229)
            /*string*/ static LiteralParent = null;
            //--TRIMMABLE-BOUNDARY-END(21476016229)
            
            //--TRIMMABLE-BOUNDARY-START(8591114341)
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114341)
            
            //--TRIMMABLE-BOUNDARY-START(25770983525)
            /*bool */ Match(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770983525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Equals$2(".."/*LiteralParent*/, value, 4/*StringComparison.Ordinal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25770983525)
            
            //--TRIMMABLE-BOUNDARY-START(12885622885)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProduceStem;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622885)
            
            //--TRIMMABLE-BOUNDARY-START(17180590181)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Match(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590181)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21476016229)
                    this.LiteralParent = "..";
                    //--TRIMMABLE-BOUNDARY-END(21476016229)
                    
                }
            }
            static $h = 1179749;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591114341),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181048933,
        "f": 50331649
      },
      "n": "CanProduceStem",
      "d": 1179749,
      "h": 8591114341,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591114341)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770983525),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 1179749,
      "h": 25770983525,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983525)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476016229),
    {
      "t": 1310721,
      "n": "LiteralParent",
      "d": 1179749,
      "h": 21476016229,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476016229)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296147045),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179749,
      "h": 4296147045,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296147045)
  ],
  "i": [720997
  ],
  "h": 1179749
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179749)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114213)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment", ($self) => class LiteralPathSegment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296081509)
            /*StringComparison*/ _comparisonType = 0;
            //--TRIMMABLE-BOUNDARY-END(4296081509)
            
            //--TRIMMABLE-BOUNDARY-START(17180983397)
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983397)
            
            //--TRIMMABLE-BOUNDARY-START(8591048805)
            $ctor$1(/*string*/ value, /*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591048805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                    this.Value = value;
                    this._comparisonType = comparisonType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048805)
            
            //--TRIMMABLE-BOUNDARY-START(51540721765)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(51540721765)
            
            //--TRIMMABLE-BOUNDARY-START(47245754469)
            /*bool */ Match(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245754469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Equals$2(this.Value, value, this._comparisonType);
            }
            //--TRIMMABLE-BOUNDARY-END(47245754469)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475950693, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let other;
                return $.$is(obj, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment, { set $v(v){ other = v; } }) && this._comparisonType === other._comparisonType && $.$$.System.String.Equals$2(other.Value, this.Value, this._comparisonType);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475950693, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42950787173, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(this._comparisonType).GetHashCode$2(this.Value);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42950787173, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(12885622885)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProduceStem;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622885)
            
            //--TRIMMABLE-BOUNDARY-START(17180590181)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Match(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590181)
            
            static $h = 1114213;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180983397),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065885285,
        "f": 50331649
      },
      "n": "CanProduceStem",
      "d": 1114213,
      "h": 17180983397,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180983397),
//--TRIMMABLE-BOUNDARY-START(51540721765),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655819877,
        "f": 50331649
      },
      "n": "Value",
      "d": 1114213,
      "h": 51540721765,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540721765)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245754469),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 1114213,
      "h": 47245754469,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245754469),
//--TRIMMABLE-BOUNDARY-START(ALL, 21475950693, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1114213,
      "h": 21475950693,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475950693, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 42950787173, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1114213,
      "h": 42950787173,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950787173, 184683724801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081509),
    {
      "t": 163446785,
      "n": "_comparisonType",
      "d": 1114213,
      "h": 4296081509,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081509)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591048805),
    {
      "p": [
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "comparisonType",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114213,
      "h": 8591048805,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591048805)
  ],
  "i": [720997
  ],
  "h": 1114213
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114213)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310821)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment", ($self) => class WildcardPathSegment extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(85900656741)
            /*WildcardPathSegment*/ static MatchAll = null;
            //--TRIMMABLE-BOUNDARY-END(85900656741)
            
            //--TRIMMABLE-BOUNDARY-START(4296278117)
            /*StringComparison*/ _comparisonType = 0;
            //--TRIMMABLE-BOUNDARY-END(4296278117)
            
            //--TRIMMABLE-BOUNDARY-START(12886212709)
            $ctor$1(/*string*/ beginsWith, /*List<string>*/ contains, /*string*/ endsWith, /*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(beginsWith, "beginsWith");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(contains, "contains");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(endsWith, "endsWith");
                    this._comparisonType = (() =>
                    {
                        if ((comparisonType === 5/*StringComparison.OrdinalIgnoreCase*/) || (comparisonType === 4/*StringComparison.Ordinal*/))
                        {
                            return comparisonType;
                        }
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.Format$6($.$mef.System.SR.StringComparisonTypeShouldBeOrdinal, $.$box(comparisonType, $.$$.System.StringComparison)));
                    })();
                    this.BeginsWith = beginsWith;
                    this.Contains = contains;
                    this.EndsWith = endsWith;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212709)
            
            //--TRIMMABLE-BOUNDARY-START(34361049189)
            /*bool */ get CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049189)
            
            //--TRIMMABLE-BOUNDARY-START(30066081893)
            /*string*/ BeginsWith = null;
            //--TRIMMABLE-BOUNDARY-END(30066081893)
            
            //--TRIMMABLE-BOUNDARY-START(38656016485)
            /*List<string>*/ Contains = null;
            //--TRIMMABLE-BOUNDARY-END(38656016485)
            
            //--TRIMMABLE-BOUNDARY-START(42950983781)
            /*string*/ EndsWith = null;
            //--TRIMMABLE-BOUNDARY-END(42950983781)
            
            //--TRIMMABLE-BOUNDARY-START(81605689445)
            /*bool */ Match(/*string*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WildcardPathSegment*/ let wildcard = this;
                if (value.length < ((wildcard.BeginsWith.length + wildcard.EndsWith.length) | 0))
                {
                    return false;
                }
                if (!$.$$.System.String.StartsWith$2.call(value, wildcard.BeginsWith, this._comparisonType))
                {
                    return false;
                }
                if (!$.$$.System.String.EndsWith$2.call(value, wildcard.EndsWith, this._comparisonType))
                {
                    return false;
                }
                /*int*/ let beginRemaining = wildcard.BeginsWith.length;
                /*int*/ let endRemaining = ((value.length - wildcard.EndsWith.length) | 0);
                for(/*int*/ let containsIndex = 0; containsIndex !== wildcard.Contains.Count; ++containsIndex)
                {
                    /*string*/ let containsValue = wildcard.Contains.get_Item(containsIndex);
                    /*int*/ let indexOf = $.$$.System.String.IndexOf$4.call(value, containsValue, beginRemaining, ((endRemaining - beginRemaining) | 0), this._comparisonType);
                    if (indexOf === -1)
                    {
                        return false;
                    }
                    beginRemaining = ((indexOf + containsValue.length) | 0);
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81605689445)
            
            //--TRIMMABLE-BOUNDARY-START(12885622885)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688293);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CanProduceStem;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622885)
            
            //--TRIMMABLE-BOUNDARY-START(17180590181)
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Match(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180590181)
            
            //--TRIMMABLE-BOUNDARY-START(8591245413)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(85900656741)
                    this.MatchAll = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment().$ctor$1($.$$.System.String.Empty, new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1(), $.$$.System.String.Empty, 5/*StringComparison.OrdinalIgnoreCase*/);
                    //--TRIMMABLE-BOUNDARY-END(85900656741)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591245413)
            
            static $h = 1310821;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049189),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130852965,
        "f": 50331649
      },
      "n": "CanProduceStem",
      "d": 1310821,
      "h": 34361049189,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049189),
//--TRIMMABLE-BOUNDARY-START(30066081893),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918373,
        "f": 50331649
      },
      "n": "BeginsWith",
      "d": 1310821,
      "h": 30066081893,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081893),
//--TRIMMABLE-BOUNDARY-START(38656016485),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720787557,
        "f": 50331649
      },
      "n": "Contains",
      "d": 1310821,
      "h": 38656016485,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656016485),
//--TRIMMABLE-BOUNDARY-START(42950983781),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310722149,
        "f": 50331649
      },
      "n": "EndsWith",
      "d": 1310821,
      "h": 42950983781,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950983781)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81605689445),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Match",
      "d": 1310821,
      "h": 81605689445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605689445)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85900656741),
    {
      "t": 1310821,
      "n": "MatchAll",
      "d": 1310821,
      "h": 85900656741,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900656741),
//--TRIMMABLE-BOUNDARY-START(4296278117),
    {
      "t": 163446785,
      "n": "_comparisonType",
      "d": 1310821,
      "h": 4296278117,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886212709),
    {
      "p": [
        {
          "n": "beginsWith",
          "p": 1310721
        },
        {
          "n": "contains",
          "p": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h
        },
        {
          "n": "endsWith",
          "p": 1310721
        },
        {
          "n": "comparisonType",
          "p": 163446785
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310821,
      "h": 12886212709,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886212709)
  ],
  "i": [720997
  ],
  "h": 1310821
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310821)
        
        
        //--TRIMMABLE-BOUNDARY-START(589925)
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<>", (TValue) => $asm.$gt("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<>", [TValue], ($self) => class IncludeOrExcludeValue$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885491813)
            /*TValue*/  get Value() { return this.$getField(0, 4); }
            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885491813)
            
            //--TRIMMABLE-BOUNDARY-START(8590524517)
            /*bool*/  get IsInclude() { return this.$getField(4, 1); }
            /*bool*/  set IsInclude(value) { this.$setField(4, 1, value); }
            //--TRIMMABLE-BOUNDARY-END(8590524517)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value = this.Value;
                copy.IsInclude = this.IsInclude;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885491813)
                this.Value = $.$default(TValue);
                //--TRIMMABLE-BOUNDARY-END(12885491813)
                
                //--TRIMMABLE-BOUNDARY-START(8590524517)
                this.IsInclude = false;
                //--TRIMMABLE-BOUNDARY-END(8590524517)
                
            }
            static $h = 589925;
            static $g = 1;
            static $z = 5;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491813),
    {
      "t": TValue?.$h??1507328,
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885491813),
//--TRIMMABLE-BOUNDARY-START(8590524517),
    {
      "t": 262145,
      "n": "IsInclude",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590524517)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557221),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557221)
  ],
  "g": [TValue?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589925)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359397)
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult", ($self) => class PatternTestResult extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(25772163173)
            /*PatternTestResult*/ static Failed;
            //--TRIMMABLE-BOUNDARY-END(25772163173)
            
            //--TRIMMABLE-BOUNDARY-START(47246999653)
            /*bool*/ IsSuccessful = false;
            //--TRIMMABLE-BOUNDARY-END(47246999653)
            
            //--TRIMMABLE-BOUNDARY-START(51541966949)
            /*string?*/ Stem = null;
            //--TRIMMABLE-BOUNDARY-END(51541966949)
            
            //--TRIMMABLE-BOUNDARY-START(8592293989)
            $ctor$3(/*bool*/ isSuccessful, /*string?*/ stem)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592293989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.IsSuccessful = isSuccessful;
                    this.Stem = stem;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592293989)
            
            //--TRIMMABLE-BOUNDARY-START(55836934245)
            static /*PatternTestResult */ Success(/*string?*/ stem)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836934245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult().$ctor$3(true, stem);
            }
            //--TRIMMABLE-BOUNDARY-END(55836934245)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.IsSuccessful = this.IsSuccessful;
                copy.Stem = this.Stem;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(4297326693)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25772163173)
                    this.Failed = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult().$ctor$3(false, null);
                    //--TRIMMABLE-BOUNDARY-END(25772163173)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297326693)
            
            static $h = 2359397;
            static $z = 5;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246999653),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362097765,
        "f": 50331649
      },
      "n": "IsSuccessful",
      "d": 2359397,
      "h": 47246999653,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246999653),
//--TRIMMABLE-BOUNDARY-START(51541966949),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952032357,
        "f": 50331649
      },
      "n": "Stem",
      "d": 2359397,
      "h": 51541966949,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541966949)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836934245),
    {
      "r": 2359397,
      "p": [
        {
          "n": "stem",
          "p": 1310721
        }
      ],
      "n": "Success",
      "d": 2359397,
      "h": 55836934245,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836934245)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25772163173),
    {
      "t": 2359397,
      "n": "Failed",
      "d": 2359397,
      "h": 25772163173,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772163173)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592293989),
    {
      "p": [
        {
          "n": "isSuccessful",
          "p": 262145
        },
        {
          "n": "stem",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359397,
      "h": 8592293989,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8592293989),
//--TRIMMABLE-BOUNDARY-START(12887261285),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2359397,
      "h": 12887261285,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887261285)
  ],
  "h": 2359397
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359397)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097253)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext", ($self) => class PreserveOrderCompositePatternContext extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext
        {
            //--TRIMMABLE-BOUNDARY-START(4297064549)
            /*IncludeOrExcludeValue<IPatternContext>[]*/ _includeOrExcludePatternContexts = null;
            //--TRIMMABLE-BOUNDARY-END(4297064549)
            
            //--TRIMMABLE-BOUNDARY-START(8592031845)
            $ctor$2(/*IncludeOrExcludeValue<IPatternContext>[]*/ includeOrExcludePatternContexts)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592031845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._includeOrExcludePatternContexts = includeOrExcludePatternContexts;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592031845)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886999141, 8591310949)
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886999141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    if (context.IsInclude)
                    {
                        context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(onDeclare);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886999141, 8591310949)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181966437, 12886278245)
            /*PatternTestResult */ MatchPatternContexts(TFileInfoBase, /*TFileInfoBase*/ fileInfo, /*Func<IPatternContext, TFileInfoBase, PatternTestResult>*/ test)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181966437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PatternTestResult*/ let result = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    if (result.IsSuccessful !== context.IsInclude)
                    {
                        /*PatternTestResult*/ let localResult = test.Invoke(context.Value, fileInfo);
                        if (localResult.IsSuccessful)
                        {
                            result = context.IsInclude ? localResult : $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                        }
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181966437, 12886278245)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476933733, 17181245541)
            /*void */ PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476933733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476933733, 17181245541)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771901029, 21476212837)
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771901029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771901029, 21476212837)
            
            static $h = 2097253;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1376357,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12886999141, 8591310949),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": 2097253,
      "h": 12886999141,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886999141, 8591310949),
//--TRIMMABLE-BOUNDARY-START(ALL, 17181966437, 12886278245),
    {
      "r": 2359397,
      "p": [
        {
          "n": "fileInfo",
          "p": (TFileInfoBase) => TFileInfoBase.$h
        },
        {
          "n": "test",
          "p": (TFileInfoBase) => $.$$.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h
        }
      ],
      "g": [
        "TFileInfoBase"
      ],
      "n": "MatchPatternContexts",
      "d": 2097253,
      "h": 17181966437,
      "f": 16941072
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181966437, 12886278245),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476933733, 17181245541),
    {
      "r": 65537,
      "n": "PopDirectory",
      "d": 2097253,
      "h": 21476933733,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476933733, 17181245541),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771901029, 21476212837),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": 2097253,
      "h": 25771901029,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771901029, 21476212837)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297064549),
    {
      "t": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)).$h,
      "n": "_includeOrExcludePatternContexts",
      "d": 2097253,
      "h": 4297064549,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297064549)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592031845),
    {
      "p": [
        {
          "n": "includeOrExcludePatternContexts",
          "p": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2097253,
      "h": 8592031845,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592031845)
  ],
  "i": [852069
  ],
  "h": 2097253
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097253)
        
        
        //--TRIMMABLE-BOUNDARY-START(393317)
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch", ($self) => class FilePatternMatch extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55834968165)
            /*string*/ Path = null;
            //--TRIMMABLE-BOUNDARY-END(55834968165)
            
            //--TRIMMABLE-BOUNDARY-START(60129935461)
            /*string*/ Stem = null;
            //--TRIMMABLE-BOUNDARY-END(60129935461)
            
            //--TRIMMABLE-BOUNDARY-START(4295360613)
            $ctor$3(/*string*/ path, /*string*/ stem)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360613);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(path, "path");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stem, "stem");
                    this.Path = path;
                    this.Stem = stem;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360613)
            
            //--TRIMMABLE-BOUNDARY-START(21475229797)
            /*bool */ Equals$2(/*FilePatternMatch*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475229797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Equals$2(other.Path, this.Path, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.String.Equals$2(other.Stem, this.Stem, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21475229797)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770197093, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let match;
                    return $.$is(obj, $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, { set $v(v){ match = v; } }) && this.Equals$2(match);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770197093, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47245033573, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245033573);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mef.System.Numerics.Hashing.HashHelpers.Combine($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode$1(this.Path), $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode$1(this.Stem));
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47245033573, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(51540000869)
            static /*int */ GetHashCode$1(/*string?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Inequality(value, null) ? $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(value) : 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540000869)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch>.Equals(Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Path = this.Path;
                copy.Stem = this.Stem;
                return copy;
            }
            static $h = 393317;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834968165),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131685,
        "f": 50331649
      },
      "n": "Path",
      "d": 393317,
      "h": 55834968165,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834968165),
//--TRIMMABLE-BOUNDARY-START(60129935461),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066277,
        "f": 50331649
      },
      "n": "Stem",
      "d": 393317,
      "h": 60129935461,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129935461)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475229797),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 393317
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 393317,
      "h": 21475229797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229797),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770197093, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 393317,
      "h": 25770197093,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770197093, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 47245033573, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 393317,
      "h": 47245033573,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47245033573, 184683724801),
//--TRIMMABLE-BOUNDARY-START(51540000869),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 393317,
      "h": 51540000869,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540000869)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360613),
    {
      "p": [
        {
          "n": "path",
          "p": 1310721
        },
        {
          "n": "stem",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393317,
      "h": 4295360613,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360613),
//--TRIMMABLE-BOUNDARY-START(8590327909),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393317,
      "h": 8590327909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327909)
  ],
  "i": [$.$$.System.IEquatable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h
  ],
  "h": 393317
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch) ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393317)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441893)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext", ($self) => class IncludesFirstCompositePatternContext extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext
        {
            //--TRIMMABLE-BOUNDARY-START(8591376485)
            /*IPatternContext[]*/ _includePatternContexts = null;
            //--TRIMMABLE-BOUNDARY-END(8591376485)
            
            //--TRIMMABLE-BOUNDARY-START(4296409189)
            /*IPatternContext[]*/ _excludePatternContexts = null;
            //--TRIMMABLE-BOUNDARY-END(4296409189)
            
            //--TRIMMABLE-BOUNDARY-START(12886343781)
            $ctor$2(/*IPatternContext[]*/ includePatternContexts, /*IPatternContext[]*/ excludePatternContexts)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343781);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._includePatternContexts = includePatternContexts;
                    this._excludePatternContexts = excludePatternContexts;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343781)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 17181311077, 8591310949)
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let include = $arr1[$i1++];
                    include.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(onDeclare);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 17181311077, 8591310949)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21476278373, 12886278245)
            /*PatternTestResult */ MatchPatternContexts(TFileInfoBase, /*TFileInfoBase*/ fileInfo, /*Func<IPatternContext, TFileInfoBase, PatternTestResult>*/ test)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*PatternTestResult*/ let result = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    /*PatternTestResult*/ let localResult = test.Invoke(context, fileInfo);
                    if (localResult.IsSuccessful)
                    {
                        result = localResult;
                        break;
                    }
                }
                if (!result.IsSuccessful)
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                }
                let $i2 = 0;
                let $arr2 = this._excludePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    if (test.Invoke(context, fileInfo).IsSuccessful)
                    {
                        return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21476278373, 12886278245)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25771245669, 17181245541)
            /*void */ PopDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._excludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
                let $i2 = 0;
                let $arr2 = this._includePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25771245669, 17181245541)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30066212965, 21476212837)
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
                let $i2 = 0;
                let $arr2 = this._excludePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30066212965, 21476212837)
            
            static $h = 1441893;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1376357,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 17181311077, 8591310949),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": 1441893,
      "h": 17181311077,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 17181311077, 8591310949),
//--TRIMMABLE-BOUNDARY-START(ALL, 21476278373, 12886278245),
    {
      "r": 2359397,
      "p": [
        {
          "n": "fileInfo",
          "p": (TFileInfoBase) => TFileInfoBase.$h
        },
        {
          "n": "test",
          "p": (TFileInfoBase) => $.$$.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h
        }
      ],
      "g": [
        "TFileInfoBase"
      ],
      "n": "MatchPatternContexts",
      "d": 1441893,
      "h": 21476278373,
      "f": 16941072
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21476278373, 12886278245),
//--TRIMMABLE-BOUNDARY-START(ALL, 25771245669, 17181245541),
    {
      "r": 65537,
      "n": "PopDirectory",
      "d": 1441893,
      "h": 25771245669,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25771245669, 17181245541),
//--TRIMMABLE-BOUNDARY-START(ALL, 30066212965, 21476212837),
    {
      "r": 65537,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "PushDirectory",
      "d": 1441893,
      "h": 30066212965,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30066212965, 21476212837)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591376485),
    {
      "t": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext).$h,
      "n": "_includePatternContexts",
      "d": 1441893,
      "h": 8591376485,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591376485),
//--TRIMMABLE-BOUNDARY-START(4296409189),
    {
      "t": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext).$h,
      "n": "_excludePatternContexts",
      "d": 1441893,
      "h": 4296409189,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409189)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886343781),
    {
      "p": [
        {
          "n": "includePatternContexts",
          "p": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext).$h
        },
        {
          "n": "excludePatternContexts",
          "p": $.$typeArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441893,
      "h": 12886343781,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886343781)
  ],
  "i": [852069
  ],
  "h": 1441893
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441893)
        
        
        //--TRIMMABLE-BOUNDARY-START(262245)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper", ($self) => class FileInfoWrapper extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295229541)
            /*FileInfo*/ _fileInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295229541)
            
            //--TRIMMABLE-BOUNDARY-START(8590196837)
            $ctor$3(/*FileInfo*/ fileInfo)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(fileInfo, "fileInfo");
                    this._fileInfo = fileInfo;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196837)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42949935205, 38655033445)
            /*string */ get Name()
            {
                return this._fileInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42949935205, 38655033445)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885164133, 8590262373)
            /*string */ get FullName()
            {
                return this._fileInfo.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885164133, 8590262373)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47244902501, 42950000741)
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(this._fileInfo.Directory);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47244902501, 42950000741)
            
            static $h = 262245;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196709,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 42949935205, 38655033445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033317,
        "f": 50364417
      },
      "n": "Name",
      "d": 262245,
      "h": 42949935205,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42949935205, 38655033445),
//--TRIMMABLE-BOUNDARY-START(ALL, 12885164133, 8590262373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098725,
        "f": 50364417
      },
      "n": "FullName",
      "d": 262245,
      "h": 12885164133,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885164133, 8590262373),
//--TRIMMABLE-BOUNDARY-START(ALL, 47244902501, 42950000741),
    {
      "p": 65637,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967909,
        "f": 50364417
      },
      "n": "ParentDirectory",
      "d": 262245,
      "h": 47244902501,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47244902501, 42950000741)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229541),
    {
      "t": 92536833,
      "n": "_fileInfo",
      "d": 262245,
      "h": 4295229541,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229541)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196837),
    {
      "p": [
        {
          "n": "fileInfo",
          "p": 92536833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262245,
      "h": 8590196837,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196837)
  ],
  "h": 262245
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262245)
        
        
        //--TRIMMABLE-BOUNDARY-START(655461)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo", ($self) => class InMemoryFileInfo extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295622757)
            /*InMemoryDirectoryInfo*/ _parent = null;
            //--TRIMMABLE-BOUNDARY-END(4295622757)
            
            //--TRIMMABLE-BOUNDARY-START(8590590053)
            $ctor$3(/*string*/ file, /*InMemoryDirectoryInfo*/ parent)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590590053);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.FullName = file;
                    this.Name = $.$$.System.IO.Path.GetFileName$1(file);
                    this._parent = parent;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590053)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475491941, 8590262373)
            /*string*/ FullName = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475491941, 8590262373)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 51540263013, 38655033445)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 51540263013, 38655033445)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55835230309, 42950000741)
            /*DirectoryInfoBase */ get ParentDirectory()
            {
                return this._parent;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55835230309, 42950000741)
            
            static $h = 655461;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196709,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21475491941, 8590262373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426533,
        "f": 50364417
      },
      "n": "FullName",
      "d": 655461,
      "h": 21475491941,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475491941, 8590262373),
//--TRIMMABLE-BOUNDARY-START(ALL, 51540263013, 38655033445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361125,
        "f": 50364417
      },
      "n": "Name",
      "d": 655461,
      "h": 51540263013,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 51540263013, 38655033445),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835230309, 42950000741),
    {
      "p": 65637,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245295717,
        "f": 50364417
      },
      "n": "ParentDirectory",
      "d": 655461,
      "h": 55835230309,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835230309, 42950000741)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622757),
    {
      "t": 458853,
      "n": "_parent",
      "d": 655461,
      "h": 4295622757,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622757)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590590053),
    {
      "p": [
        {
          "n": "file",
          "p": 1310721
        },
        {
          "n": "parent",
          "p": 458853
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655461,
      "h": 8590590053,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590590053)
  ],
  "h": 655461
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655461)
        
        
        //--TRIMMABLE-BOUNDARY-START(131173)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper", ($self) => class DirectoryInfoWrapper extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295098469)
            /*DirectoryInfo*/ _directoryInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295098469)
            
            //--TRIMMABLE-BOUNDARY-START(8590065765)
            /*bool*/ _isParentPath = false;
            //--TRIMMABLE-BOUNDARY-END(8590065765)
            
            //--TRIMMABLE-BOUNDARY-START(12885033061)
            $ctor$4(/*DirectoryInfo*/ directoryInfo)
            {
                this.$ctor$3(directoryInfo, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033061);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033061)
            
            //--TRIMMABLE-BOUNDARY-START(17180000357)
            $ctor$3(/*DirectoryInfo*/ directoryInfo, /*bool*/ isParentPath)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._directoryInfo = directoryInfo;
                    this._isParentPath = isParentPath;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000357)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21474967653, 8590000229)
            /*IEnumerable<FileSystemInfoBase> */ EnumerateFileSystemInfos()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this._directoryInfo.Exists)
                    {
                        /*IEnumerable<FileSystemInfo>*/ let fileSystemInfos;
                        try
                        {
                            fileSystemInfos = this._directoryInfo.EnumerateFileSystemInfos$2("*", 0/*SearchOption.TopDirectoryOnly*/);
                        }
                        catch($e)
                        {
                            return;
                        }
                        var $en4 = fileSystemInfos.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var fileSystemInfo = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let directoryInfo;
                                if ($.$is(fileSystemInfo, $.$$.System.IO.DirectoryInfo, { set $v(v){ directoryInfo = v; } }))
                                {
                                    yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(directoryInfo);
                                }
                                else 
                                {
                                    yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper().$ctor$3($.$cast(fileSystemInfo, $.$$.System.IO.FileInfo));
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21474967653, 8590000229)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 55834706021, 12884967525)
            /*DirectoryInfoBase? */ GetDirectory(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isParentPath = $.$$.System.String.Equals$2(name, "..", 4/*StringComparison.Ordinal*/);
                if (isParentPath)
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(new $.$$.System.IO.DirectoryInfo().$ctor$5($.$$.System.IO.Path.Combine$3(this._directoryInfo.FullName, name)), isParentPath);
                }
                else 
                {
                    /*DirectoryInfo[]*/ let dirs = this._directoryInfo.GetDirectories$3(name);
                    if (dirs.length === 1)
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3($.$$.System.Array.$ReadT1.call(dirs, 0), isParentPath);
                    }
                    else if (dirs.length === 0)
                    {
                        return null;
                    }
                    else 
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12(`More than one sub directories are found under ${this._directoryInfo.FullName} with name ${name}.`);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 55834706021, 12884967525)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 60129673317, 17179934821)
            /*FileInfoBase */ GetFile(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129673317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper().$ctor$3(new $.$$.System.IO.FileInfo().$ctor$6($.$$.System.IO.Path.Combine$3(this._directoryInfo.FullName, name)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60129673317, 17179934821)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 64424640613, 38655033445)
            /*string */ get Name()
            {
                return this._isParentPath ? ".." : this._directoryInfo.Name;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 64424640613, 38655033445)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25769934949, 8590262373)
            /*string */ get FullName()
            {
                return this._directoryInfo.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25769934949, 8590262373)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68719607909, 42950000741)
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(this._directoryInfo.Parent);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68719607909, 42950000741)
            
            static $h = 131173;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 65637,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 64424640613, 38655033445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949804133,
        "f": 50364417
      },
      "n": "Name",
      "d": 131173,
      "h": 64424640613,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64424640613, 38655033445),
//--TRIMMABLE-BOUNDARY-START(ALL, 25769934949, 8590262373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359869541,
        "f": 50364417
      },
      "n": "FullName",
      "d": 131173,
      "h": 25769934949,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25769934949, 8590262373),
//--TRIMMABLE-BOUNDARY-START(ALL, 68719607909, 42950000741),
    {
      "p": 65637,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539738725,
        "f": 50364417
      },
      "n": "ParentDirectory",
      "d": 131173,
      "h": 68719607909,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68719607909, 42950000741)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21474967653, 8590000229),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,
      "n": "EnumerateFileSystemInfos",
      "d": 131173,
      "h": 21474967653,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21474967653, 8590000229),
//--TRIMMABLE-BOUNDARY-START(ALL, 55834706021, 12884967525),
    {
      "r": 65637,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetDirectory",
      "d": 131173,
      "h": 55834706021,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55834706021, 12884967525),
//--TRIMMABLE-BOUNDARY-START(ALL, 60129673317, 17179934821),
    {
      "r": 196709,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetFile",
      "d": 131173,
      "h": 60129673317,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60129673317, 17179934821)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098469),
    {
      "t": 91357185,
      "n": "_directoryInfo",
      "d": 131173,
      "h": 4295098469,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098469),
//--TRIMMABLE-BOUNDARY-START(8590065765),
    {
      "t": 262145,
      "n": "_isParentPath",
      "d": 131173,
      "h": 8590065765,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065765)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033061),
    {
      "p": [
        {
          "n": "directoryInfo",
          "p": 91357185
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 131173,
      "h": 12885033061,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033061),
//--TRIMMABLE-BOUNDARY-START(17180000357),
    {
      "p": [
        {
          "n": "directoryInfo",
          "p": 91357185
        },
        {
          "n": "isParentPath",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131173,
      "h": 17180000357,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180000357)
  ],
  "h": 131173
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131173)
        
        
        //--TRIMMABLE-BOUNDARY-START(458853)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo", ($self) => class InMemoryDirectoryInfo extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase
        {
            //--TRIMMABLE-BOUNDARY-START(30065229925)
            /*char[]*/ static DirectorySeparators = null;
            //--TRIMMABLE-BOUNDARY-END(30065229925)
            
            //--TRIMMABLE-BOUNDARY-START(4295426149)
            /*IEnumerable<string>*/ _files = null;
            //--TRIMMABLE-BOUNDARY-END(4295426149)
            
            //--TRIMMABLE-BOUNDARY-START(12885360741)
            $ctor$4(/*string*/ rootDir, /*IEnumerable<string>?*/ files)
            {
                this.$ctor$3(rootDir, files, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360741)
            
            //--TRIMMABLE-BOUNDARY-START(17180328037)
            $ctor$3(/*string*/ rootDir, /*IEnumerable<string>?*/ files, /*bool*/ normalized)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180328037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrEmpty(rootDir))
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("rootDir");
                    }
                    files ??= new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    this.Name = $.$$.System.IO.Path.GetFileName$1(rootDir);
                    if (normalized)
                    {
                        this._files = files;
                        this.FullName = rootDir;
                    }
                    else 
                    {
                        /*var*/ let fileList = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3($.$sl.System.Linq.Enumerable.Count$1($.$$.System.String, files));
                        /*string*/ let normalizedRoot = $.$$.System.IO.Path.GetFullPath$1($.$$.System.String.Replace.call(rootDir, $.$$.System.IO.Path.AltDirectorySeparatorChar, $.$$.System.IO.Path.DirectorySeparatorChar));
                        var $en4 = files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var file = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*string*/ let fileWithNormalSeparators = $.$$.System.String.Replace.call(file, $.$$.System.IO.Path.AltDirectorySeparatorChar, $.$$.System.IO.Path.DirectorySeparatorChar);
                                if ($.$$.System.IO.Path.IsPathRooted$1(file))
                                {
                                    fileList.Add($.$$.System.IO.Path.GetFullPath$1(fileWithNormalSeparators));
                                }
                                else 
                                {
                                    fileList.Add($.$$.System.IO.Path.GetFullPath$1($.$$.System.IO.Path.Combine$3(normalizedRoot, fileWithNormalSeparators)));
                                }
                            }
                        }
                        this._files = fileList;
                        this.FullName = normalizedRoot;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180328037)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655164517, 8590262373)
            /*string*/ FullName = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655164517, 8590262373)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604837477, 38655033445)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604837477, 38655033445)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85899804773, 42950000741)
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$3($.$$.System.IO.Path.GetDirectoryName$1(this.FullName), this._files, true);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85899804773, 42950000741)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 34360197221, 8590000229)
            /*IEnumerable<FileSystemInfoBase> */ EnumerateFileSystemInfos()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let dict = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.List$$($.$$.System.String)))().$ctor$1();
                    var $en3 = this._files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var file = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!$.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo.IsRootDirectory(this.FullName, file))
                            {
                                continue;
                            }
                            /*int*/ let endPath = file.length;
                            /*int*/ let beginSegment = ((this.FullName.length + 1) | 0);
                            /*int*/ let endSegment = $.$$.System.String.IndexOfAny.call(file, $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo.DirectorySeparators, beginSegment, ((endPath - beginSegment) | 0));
                            if (endSegment === -1)
                            {
                                yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo().$ctor$3(file, this);
                            }
                            else 
                            {
                                /*string*/ let name = $.$$.System.String.Substring.call(file, 0, endSegment);
                                /*List<string>?*/ let list;
                                if (!dict.TryGetValue(name, $.$ref(() => list, ($v) => list = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))))
                                {
                                    dict.set_Item(name, (() =>
                                    {
                                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                                        const $t2 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                                        const $i2 = new $t2();
                                        $i2.$ctor$1();
                                        $i2.Add(file);
                                        return $i2;
                                    })());
                                }
                                else 
                                {
                                    list.Add(file);
                                }
                            }
                        }
                    }
                    var $en3 = dict.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$3(item.Key, item.Value, true);
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 34360197221, 8590000229)
            
            //--TRIMMABLE-BOUNDARY-START(77309870181)
            static /*bool */ IsRootDirectory(/*string*/ rootDir, /*string*/ filePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let rootDirLength = rootDir.length;
                return $.$$.System.String.StartsWith$2.call(filePath, rootDir, 4/*StringComparison.Ordinal*/) && ($.$$.System.String.get_Chars.call(rootDir, ((rootDirLength - 1) | 0)) === $.$$.System.IO.Path.DirectorySeparatorChar || $.$$.System.String.IndexOf$1.call(filePath, $.$$.System.IO.Path.DirectorySeparatorChar, rootDirLength) === rootDirLength);
            }
            //--TRIMMABLE-BOUNDARY-END(77309870181)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68719935589, 12884967525)
            /*DirectoryInfoBase */ GetDirectory(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.Equals$2(path, "..", 4/*StringComparison.Ordinal*/))
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$3($.$$.System.IO.Path.Combine$3(this.FullName, path), this._files, true);
                }
                else 
                {
                    /*string*/ let normPath = $.$$.System.IO.Path.GetFullPath$1($.$$.System.String.Replace.call(path, $.$$.System.IO.Path.AltDirectorySeparatorChar, $.$$.System.IO.Path.DirectorySeparatorChar));
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$3(normPath, this._files, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68719935589, 12884967525)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 73014902885, 17179934821)
            /*FileInfoBase? */ GetFile(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let normPath = $.$$.System.IO.Path.GetFullPath$1($.$$.System.String.Replace.call(path, $.$$.System.IO.Path.AltDirectorySeparatorChar, $.$$.System.IO.Path.DirectorySeparatorChar));
                var $en2 = this._files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var file = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$$.System.String.Equals$3(file, normPath))
                        {
                            return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo().$ctor$3(file, this);
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 73014902885, 17179934821)
            
            //--TRIMMABLE-BOUNDARY-START(8590393445)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(30065229925)
                    this.DirectorySeparators = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [$.$$.System.IO.Path.DirectorySeparatorChar, $.$$.System.IO.Path.AltDirectorySeparatorChar], null, null);
                    //--TRIMMABLE-BOUNDARY-END(30065229925)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393445)
            
            static $h = 458853;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 65637,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 38655164517, 8590262373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099109,
        "f": 50364417
      },
      "n": "FullName",
      "d": 458853,
      "h": 38655164517,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655164517, 8590262373),
//--TRIMMABLE-BOUNDARY-START(ALL, 81604837477, 38655033445),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033701,
        "f": 50364417
      },
      "n": "Name",
      "d": 458853,
      "h": 81604837477,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81604837477, 38655033445),
//--TRIMMABLE-BOUNDARY-START(ALL, 85899804773, 42950000741),
    {
      "p": 65637,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968293,
        "f": 50364417
      },
      "n": "ParentDirectory",
      "d": 458853,
      "h": 85899804773,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85899804773, 42950000741)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 34360197221, 8590000229),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,
      "n": "EnumerateFileSystemInfos",
      "d": 458853,
      "h": 34360197221,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 34360197221, 8590000229),
//--TRIMMABLE-BOUNDARY-START(77309870181),
    {
      "r": 262145,
      "p": [
        {
          "n": "rootDir",
          "p": 1310721
        },
        {
          "n": "filePath",
          "p": 1310721
        }
      ],
      "n": "IsRootDirectory",
      "d": 458853,
      "h": 77309870181,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309870181),
//--TRIMMABLE-BOUNDARY-START(ALL, 68719935589, 12884967525),
    {
      "r": 65637,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetDirectory",
      "d": 458853,
      "h": 68719935589,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68719935589, 12884967525),
//--TRIMMABLE-BOUNDARY-START(ALL, 73014902885, 17179934821),
    {
      "r": 196709,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "GetFile",
      "d": 458853,
      "h": 73014902885,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 73014902885, 17179934821)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065229925),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "DirectorySeparators",
      "d": 458853,
      "h": 30065229925,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065229925),
//--TRIMMABLE-BOUNDARY-START(4295426149),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "n": "_files",
      "d": 458853,
      "h": 4295426149,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426149)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360741),
    {
      "p": [
        {
          "n": "rootDir",
          "p": 1310721
        },
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458853,
      "h": 12885360741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360741),
//--TRIMMABLE-BOUNDARY-START(17180328037),
    {
      "p": [
        {
          "n": "rootDir",
          "p": 1310721
        },
        {
          "n": "files",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        },
        {
          "n": "normalized",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458853,
      "h": 17180328037,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17180328037)
  ],
  "h": 458853
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458853)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031717)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude", ($self) => class PatternContextRaggedInclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged
        {
            //--TRIMMABLE-BOUNDARY-START(4296999013)
            $ctor$3(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296999013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296999013)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8591966309, 12886409317)
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591966309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotDeclarePathSegment);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return;
                }
                if (this.IsStartingGroup() && this.Frame.SegmentIndex < this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count)
                {
                    onDeclare.Invoke(this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]), false);
                }
                else 
                {
                    onDeclare.Invoke($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment.MatchAll, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8591966309, 12886409317)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886933605, 42951180389)
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886933605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                if (this.IsStartingGroup() && !this.TestMatchingSegment(directory.Name))
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886933605, 42951180389)
            
            static $h = 2031717;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1835109,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8591966309, 12886409317),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": 2031717,
      "h": 8591966309,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591966309, 12886409317),
//--TRIMMABLE-BOUNDARY-START(ALL, 12886933605, 42951180389),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": 2031717,
      "h": 12886933605,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886933605, 42951180389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296999013),
    {
      "p": [
        {
          "n": "pattern",
          "p": 917605
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031717,
      "h": 4296999013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296999013)
  ],
  "i": [852069
  ],
  "h": 2031717
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031717)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704037)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude", ($self) => class PatternContextLinearExclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear
        {
            //--TRIMMABLE-BOUNDARY-START(4296671333)
            $ctor$3(/*ILinearPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671333)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8591638629, 42951180389)
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                return this.IsLastSegment() && this.TestMatchingSegment(directory.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8591638629, 42951180389)
            
            static $h = 1704037;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1572965,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8591638629, 42951180389),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": 1704037,
      "h": 8591638629,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591638629, 42951180389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671333),
    {
      "p": [
        {
          "n": "pattern",
          "p": 524389
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1704037,
      "h": 4296671333,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671333)
  ],
  "i": [852069
  ],
  "h": 1704037
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704037)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769573)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude", ($self) => class PatternContextLinearInclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear
        {
            //--TRIMMABLE-BOUNDARY-START(4296736869)
            $ctor$3(/*ILinearPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736869);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736869)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8591704165, 12886409317)
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591704165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotDeclarePathSegment);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return;
                }
                if (this.Frame.SegmentIndex < this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count)
                {
                    onDeclare.Invoke(this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]), this.IsLastSegment());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8591704165, 12886409317)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12886671461, 42951180389)
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886671461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                return !this.IsLastSegment() && this.TestMatchingSegment(directory.Name);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12886671461, 42951180389)
            
            static $h = 1769573;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1572965,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8591704165, 12886409317),
    {
      "r": 65537,
      "p": [
        {
          "n": "onDeclare",
          "p": $.$$.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$$.System.Boolean).$h
        }
      ],
      "n": "Declare",
      "d": 1769573,
      "h": 8591704165,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591704165, 12886409317),
//--TRIMMABLE-BOUNDARY-START(ALL, 12886671461, 42951180389),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": 1769573,
      "h": 12886671461,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12886671461, 42951180389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736869),
    {
      "p": [
        {
          "n": "pattern",
          "p": 524389
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769573,
      "h": 4296736869,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736869)
  ],
  "i": [852069
  ],
  "h": 1769573
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769573)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966181)
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude", ($self) => class PatternContextRaggedExclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged
        {
            //--TRIMMABLE-BOUNDARY-START(4296933477)
            $ctor$3(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296933477);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933477)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8591900773, 42951180389)
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591900773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsStackEmpty())
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                if (this.IsEndingGroup() && this.TestMatchingGroup(directory))
                {
                    return true;
                }
                if (this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith.System$Collections$Generic$ICollection$$$Count === 0 && this.Frame.SegmentGroupIndex === ((this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count - 1) | 0) && this.TestMatchingGroup(directory))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8591900773, 42951180389)
            
            static $h = 1966181;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1835109,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8591900773, 42951180389),
    {
      "r": 262145,
      "p": [
        {
          "n": "directory",
          "p": 65637
        }
      ],
      "n": "Test",
      "d": 1966181,
      "h": 8591900773,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8591900773, 42951180389)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933477),
    {
      "p": [
        {
          "n": "pattern",
          "p": 917605
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966181,
      "h": 4296933477,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933477)
  ],
  "i": [852069
  ],
  "h": 1966181
}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966181)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq"))
//--TRIMMABLE-BOUNDARY-END(101)
