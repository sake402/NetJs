
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $st, $sr, $scc, $sris, $sl) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.FileSystemGlobbing", 
    {"h":28,"f":"Microsoft.Extensions.FileSystemGlobbing","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.FileSystemGlobbing.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.FileSystemGlobbing","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.FileSystemGlobbing","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern", ($self) => class IPattern
        {
            static $h = 786460;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":851996,"n":"CreatePatternContextForInclude","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude","d":786460,"h":4295753756,"f":257},{"r":851996,"n":"CreatePatternContextForExclude","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude","d":786460,"h":8590721052,"f":257}],"h":786460}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment", ($self) => class IPathSegment
        {
            static $h = 720924;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590655516,"f":257},"n":"CanProduceStem","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem","d":720924,"h":4295688220,"f":257}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match","d":720924,"h":12885622812,"f":257}],"h":720924}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext", ($self) => class IPatternContext
        {
            static $h = 851996;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare","d":851996,"h":4295819292,"f":257},{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test","d":851996,"h":8590786588,"f":257},{"r":2359324,"p":[{"n":"file","p":196636}],"n":"Test","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1","d":851996,"h":12885753884,"f":257},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory","d":851996,"h":17180721180,"f":257},{"r":65537,"n":"PopDirectory","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory","d":851996,"h":21475688476,"f":257}],"h":851996}; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern", ($self) => class ILinearPattern
        {
            static $h = 524316;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":8590458908,"f":257},"n":"Segments","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments","d":524316,"h":4295491612,"f":257}],"i":[786460],"h":524316}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern", ($self) => class IRaggedPattern
        {
            static $h = 917532;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":8590852124,"f":257},"n":"Segments","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Segments","d":917532,"h":4295884828,"f":257},{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":17180786716,"f":257},"n":"StartsWith","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith","d":917532,"h":12885819420,"f":257},{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h,"g":{"r":0,"d":0,"h":25770721308,"f":257},"n":"Contains","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains","d":917532,"h":21475754012,"f":257},{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":34360655900,"f":257},"n":"EndsWith","o":"Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith","d":917532,"h":30065688604,"f":257}],"i":[786460],"h":917532}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase", ($self) => class FileSystemInfoBase extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 327708;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590262300,"f":257},"n":"Name","d":327708,"h":4295295004,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":17180196892,"f":257},"n":"FullName","d":327708,"h":12885229596,"f":257},{"p":65564,"g":{"r":0,"d":0,"h":25770131484,"f":257},"n":"ParentDirectory","d":327708,"h":21475164188,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":327708,"h":30065098780,"f":4}],"h":327708}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext", ($self) => class CompositePatternContext extends $.$spc.System.Object
        {
            /*bool */ Test(/*DirectoryInfoBase*/ directory)
            {
                return this.MatchPatternContexts($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, directory, new ($.$spc.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult))().$ctor(null, /*static*/ (/**/ context, /*dir*/ dir) =>
                {
                    return context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test(dir) ? $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success($.$spc.System.String.Empty) : $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                })).IsSuccessful;
            }
            /*PatternTestResult */ Test$1(/*FileInfoBase*/ file)
            {
                return this.MatchPatternContexts($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, file, new ($.$spc.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult))().$ctor(null, /*static*/ (/**/ context, /**/ fileInfo) =>
                {
                    return context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1(fileInfo);
                }));
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Declare(System.Action<Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, bool>)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare()
            {
                return this.Declare(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test()
            {
                return this.Test(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1()
            {
                return this.Test$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PushDirectory(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory()
            {
                return this.PushDirectory(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PopDirectory()
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory()
            {
                return this.PopDirectory(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1376284;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":1376284,"h":4296343580,"f":257},{"r":65537,"n":"PopDirectory","d":1376284,"h":8591310876,"f":257},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":1376284,"h":12886278172,"f":257},{"r":2359324,"p":[{"n":"fileInfo","p":(TFileInfoBase) => TFileInfoBase.$h},{"n":"test","p":(TFileInfoBase) => $.$spc.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h}],"g":["TFileInfoBase"],"n":"MatchPatternContexts","d":1376284,"h":17181245468,"f":131344},{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","d":1376284,"h":21476212764,"f":1},{"r":2359324,"p":[{"n":"file","p":196636}],"n":"Test","o":"@$1","d":1376284,"h":25771180060,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1376284,"h":30066147356,"f":4}],"i":[851996],"h":1376284}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<>", (TFrame) => $asm.$gt("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<>", [TFrame], ($self) => class PatternContext$$ extends $.$spc.System.Object
        {
            /*Stack<TFrame>*/ _stack = null;
            /*TFrame*/ Frame = $.$default(TFrame);
            /*void */ Declare(/*Action<IPathSegment, bool>*/ declare)
            {
            }
            /*void */ PopDirectory()
            {
                this.Frame = this._stack.Pop();
            }
            /*void */ PushDataFrame(/*TFrame*/ frame)
            {
                this._stack.Push(this.Frame);
                this.Frame = frame;
            }
            /*bool */ IsStackEmpty()
            {
                return this._stack.Count === 0;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Declare(System.Action<Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, bool>)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare()
            {
                return this.Declare(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test()
            {
                return this.Test$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.Test(Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1()
            {
                return this.Test(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PushDirectory(Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory()
            {
                return this.PushDirectory(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext.PopDirectory()
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory()
            {
                return this.PopDirectory(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._stack = new ($.$sc.System.Collections.Generic.Stack$$(TFrame))().$ctor$1();
                this.Frame = $.$default(TFrame);
            }
            static $h = 1507356;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"declare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"r":2359324,"p":[{"n":"file","p":196636}],"n":"Test","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":257},{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":257},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":257},{"r":65537,"n":"PopDirectory","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":129},{"r":65537,"p":[{"n":"frame","p":TFrame?.$h??1507328}],"n":"PushDataFrame","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4},{"r":262145,"n":"IsStackEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4}],"l":[{"t":$.$sc.System.Collections.Generic.Stack$$(TFrame).$h,"n":"_stack","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":TFrame?.$h??1507328,"n":"Frame","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":4}],"i":[851996],"g":[TFrame?.$h??1507328],"s":[{"n":"TFrame","f":2}],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext<${TFrame?.$fullName}>`; }
        }));
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase", ($self) => class DirectoryInfoBase extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 65564;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327708,"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,"n":"EnumerateFileSystemInfos","d":65564,"h":4295032860,"f":257},{"r":65564,"p":[{"n":"path","p":1310721}],"n":"GetDirectory","d":65564,"h":8590000156,"f":257},{"r":196636,"p":[{"n":"path","p":1310721}],"n":"GetFile","d":65564,"h":12884967452,"f":257}],"c":[{"n":".ctor","o":"$ctor$2","d":65564,"h":17179934748,"f":4}],"h":65564}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase", ($self) => class FileInfoBase extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 196636;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327708,"c":[{"n":".ctor","o":"$ctor$2","d":196636,"h":4295163932,"f":4}],"h":196636}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear", ($self) => class PatternContextLinear extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($self.$itype$FrameData)
        {
            $ctor$2(/*ILinearPattern*/ pattern)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(pattern, "pattern");
                    this.Pattern = pattern;
                }
                return this;
            }
            /*PatternTestResult */ Test(/*FileInfoBase*/ file)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestFile);
                }
                if (!this.Frame.IsNotApplicable && this.IsLastSegment() && this.TestMatchingSegment(file.Name))
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success(this.CalculateStem(file));
                }
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
            }
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                /*FrameData*/ let frame = this.Frame;
                if (this.IsStackEmpty() || this.Frame.IsNotApplicable)
                {
                }
                else if (!this.TestMatchingSegment(directory.Name))
                {
                    frame.IsNotApplicable = true;
                }
                else 
                {
                    /*IPathSegment*/ let segment = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]);
                    if (frame.InStem || segment.Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem)
                    {
                        frame.InStem = true;
                        frame.StemItems.System$Collections$Generic$ICollection$$$Add(directory.Name, [$.$spc.System.String]);
                    }
                    frame.SegmentIndex++;
                }
                this.PushDataFrame(frame.Clone());
            }
            static $_FrameData;
            static get FrameData()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear;
                return $cls.$_FrameData ??= $asm.$nstr("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData", ($self) => class FrameData extends $.$spc.System.ValueType
                {
                    /*bool*/  get IsNotApplicable() { return this.$getField(0, 1); }
                    /*bool*/  set IsNotApplicable(value) { this.$setField(0, 1, value); }
                    /*int*/  get SegmentIndex() { return this.$getField(1, 4); }
                    /*int*/  set SegmentIndex(value) { this.$setField(1, 4, value); }
                    /*bool*/  get InStem() { return this.$getField(5, 1); }
                    /*bool*/  set InStem(value) { this.$setField(5, 1, value); }
                    /*IList<string>?*/  get _stemItems() { return this.$getField(6, 4); }
                    /*IList<string>?*/  set _stemItems(value) { this.$setField(6, 4, value); }
                    /*IList<string> */ get StemItems()
                    {
                        return this._stemItems ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    }
                    /*string? */ get Stem()
                    {
                        return this._stemItems === null ? null : $.$spc.System.String.Join$6("/", this._stemItems);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsNotApplicable = this.IsNotApplicable;
                        copy.SegmentIndex = this.SegmentIndex;
                        copy.InStem = this.InStem;
                        copy._stemItems = this._stemItems;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsNotApplicable = false;
                        this.SegmentIndex = 0;
                        this.InStem = false;
                        this._stemItems = null;
                    }
                    static $h = 1638428;
                    static $z = 10;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25771442204,"f":1},"n":"StemItems","d":1638428,"h":21476474908,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361376796,"f":1},"n":"Stem","d":1638428,"h":30066409500,"f":1}],"l":[{"t":262145,"n":"IsNotApplicable","d":1638428,"h":4296605724,"f":1},{"t":655361,"n":"SegmentIndex","d":1638428,"h":8591573020,"f":1},{"t":262145,"n":"InStem","d":1638428,"h":12886540316,"f":1},{"t":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"n":"_stemItems","d":1638428,"h":17181507612,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1638428,"h":38656344092,"f":1}],"d":1572892,"h":1638428}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData`; }
                }, $cls, ($v) => $cls.$_FrameData = $v);
            }
            /*ILinearPattern*/ Pattern = null;
            /*bool */ IsLastSegment()
            {
                return this.Frame.SegmentIndex === ((this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count - 1) | 0);
            }
            /*bool */ TestMatchingSegment(/*string*/ value)
            {
                if (this.Frame.SegmentIndex >= this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                return this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]).Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(value);
            }
            /*string */ CalculateStem(/*FileInfoBase*/ matchedFile)
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(this.Frame.Stem, matchedFile.Name);
            }
            static $h = 1572892;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":524316,"g":{"r":0,"d":0,"h":30066343964,"f":4},"n":"Pattern","d":1572892,"h":25771376668,"f":4}],"m":[{"r":2359324,"p":[{"n":"file","p":196636}],"n":"Test","d":1572892,"h":8591507484,"f":32769},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":1572892,"h":12886474780,"f":32769},{"r":262145,"n":"IsLastSegment","d":1572892,"h":34361311260,"f":4},{"r":262145,"p":[{"n":"value","p":1310721}],"n":"TestMatchingSegment","d":1572892,"h":38656278556,"f":4},{"r":1310721,"p":[{"n":"matchedFile","p":196636}],"n":"CalculateStem","d":1572892,"h":42951245852,"f":4}],"c":[{"p":[{"n":"pattern","p":524316}],"n":".ctor","o":"$ctor$2","d":1572892,"h":4296540188,"f":1}],"i":[851996],"j":[1638428],"h":1572892}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear.FrameData); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged", ($self) => class PatternContextRagged extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($self.$itype$FrameData)
        {
            $ctor$2(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(pattern, "pattern");
                    this.Pattern = pattern;
                }
                return this;
            }
            /*PatternTestResult */ Test(/*FileInfoBase*/ file)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestFile);
                }
                if (!this.Frame.IsNotApplicable && this.IsEndingGroup() && this.TestMatchingGroup(file))
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Success(this.CalculateStem(file));
                }
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
            }
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                /*FrameData*/ let frame = this.Frame;
                if (this.IsStackEmpty())
                {
                    frame.SegmentGroupIndex = -1;
                    frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith;
                }
                else if (this.Frame.IsNotApplicable)
                {
                }
                else if (this.IsStartingGroup())
                {
                    if (!this.TestMatchingSegment(directory.Name))
                    {
                        frame.IsNotApplicable = true;
                    }
                    else 
                    {
                        frame.SegmentIndex += 1;
                    }
                }
                else if (!this.IsStartingGroup() && $.$spc.System.String.op_Equality(directory.Name, ".."))
                {
                    frame.IsNotApplicable = true;
                }
                else if (!this.IsStartingGroup() && !this.IsEndingGroup() && this.TestMatchingGroup(directory))
                {
                    frame.SegmentIndex = this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count;
                    frame.BacktrackAvailable = 0;
                }
                else 
                {
                    frame.BacktrackAvailable += 1;
                }
                if (frame.InStem)
                {
                    frame.StemItems.System$Collections$Generic$ICollection$$$Add(directory.Name, [$.$spc.System.String]);
                }
                while(frame.SegmentIndex === frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count && frame.SegmentGroupIndex !== this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count)
                {
                    frame.SegmentGroupIndex += 1;
                    frame.SegmentIndex = 0;
                    if (frame.SegmentGroupIndex < this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count)
                    {
                        frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$IList$$$get_Item(frame.SegmentGroupIndex, [$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)]);
                    }
                    else 
                    {
                        frame.SegmentGroup = this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith;
                    }
                    frame.InStem = true;
                }
                this.PushDataFrame(frame.Clone());
            }
            /*void */ PopDirectory()
            {
                super.PopDirectory();
                if (this.Frame.StemItems.System$Collections$Generic$ICollection$$$Count > 0)
                {
                    this.Frame.StemItems.System$Collections$Generic$IList$$$RemoveAt(((this.Frame.StemItems.System$Collections$Generic$ICollection$$$Count - 1) | 0), [$.$spc.System.String]);
                }
            }
            static $_FrameData;
            static get FrameData()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged;
                return $cls.$_FrameData ??= $asm.$nstr("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData", ($self) => class FrameData extends $.$spc.System.ValueType
                {
                    /*bool*/  get IsNotApplicable() { return this.$getField(0, 1); }
                    /*bool*/  set IsNotApplicable(value) { this.$setField(0, 1, value); }
                    /*int*/  get SegmentGroupIndex() { return this.$getField(1, 4); }
                    /*int*/  set SegmentGroupIndex(value) { this.$setField(1, 4, value); }
                    /*IList<IPathSegment>*/  get SegmentGroup() { return this.$getField(5, 4); }
                    /*IList<IPathSegment>*/  set SegmentGroup(value) { this.$setField(5, 4, value); }
                    /*int*/  get BacktrackAvailable() { return this.$getField(9, 4); }
                    /*int*/  set BacktrackAvailable(value) { this.$setField(9, 4, value); }
                    /*int*/  get SegmentIndex() { return this.$getField(13, 4); }
                    /*int*/  set SegmentIndex(value) { this.$setField(13, 4, value); }
                    /*bool*/  get InStem() { return this.$getField(17, 1); }
                    /*bool*/  set InStem(value) { this.$setField(17, 1, value); }
                    /*IList<string>?*/  get _stemItems() { return this.$getField(18, 4); }
                    /*IList<string>?*/  set _stemItems(value) { this.$setField(18, 4, value); }
                    /*IList<string> */ get StemItems()
                    {
                        return this._stemItems ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    }
                    /*string? */ get Stem()
                    {
                        return this._stemItems === null ? null : $.$spc.System.String.Join$6("/", this._stemItems);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.IsNotApplicable = this.IsNotApplicable;
                        copy.SegmentGroupIndex = this.SegmentGroupIndex;
                        copy.SegmentGroup = this.SegmentGroup;
                        copy.BacktrackAvailable = this.BacktrackAvailable;
                        copy.SegmentIndex = this.SegmentIndex;
                        copy.InStem = this.InStem;
                        copy._stemItems = this._stemItems;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.IsNotApplicable = false;
                        this.SegmentGroupIndex = 0;
                        this.SegmentGroup = null;
                        this.BacktrackAvailable = 0;
                        this.SegmentIndex = 0;
                        this.InStem = false;
                        this._stemItems = null;
                    }
                    static $h = 1900572;
                    static $z = 22;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":38656606236,"f":1},"n":"StemItems","d":1900572,"h":34361638940,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":47246540828,"f":1},"n":"Stem","d":1900572,"h":42951573532,"f":1}],"l":[{"t":262145,"n":"IsNotApplicable","d":1900572,"h":4296867868,"f":1},{"t":655361,"n":"SegmentGroupIndex","d":1900572,"h":8591835164,"f":1},{"t":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"n":"SegmentGroup","d":1900572,"h":12886802460,"f":1},{"t":655361,"n":"BacktrackAvailable","d":1900572,"h":17181769756,"f":1},{"t":655361,"n":"SegmentIndex","d":1900572,"h":21476737052,"f":1},{"t":262145,"n":"InStem","d":1900572,"h":25771704348,"f":1},{"t":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"n":"_stemItems","d":1900572,"h":30066671644,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1900572,"h":51541508124,"f":1}],"d":1835036,"h":1900572}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData`; }
                }, $cls, ($v) => $cls.$_FrameData = $v);
            }
            /*IRaggedPattern*/ Pattern = null;
            /*bool */ IsStartingGroup()
            {
                return this.Frame.SegmentGroupIndex === -1;
            }
            /*bool */ IsEndingGroup()
            {
                return this.Frame.SegmentGroupIndex === this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count;
            }
            /*bool */ TestMatchingSegment(/*string*/ value)
            {
                if (this.Frame.SegmentIndex >= this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count)
                {
                    return false;
                }
                return this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]).Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(value);
            }
            /*bool */ TestMatchingGroup(/*FileSystemInfoBase*/ value)
            {
                /*int*/ let groupLength = this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count;
                /*int*/ let backtrackLength = ((this.Frame.BacktrackAvailable + 1) | 0);
                if (backtrackLength < groupLength)
                {
                    return false;
                }
                /*FileSystemInfoBase?*/ let scan = value;
                for(/*int*/ let index = 0; index !== groupLength; ++index)
                {
                    /*IPathSegment*/ let segment = this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(((((groupLength - index) | 0) - 1) | 0), [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]);
                    if (scan === null || !segment.Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match(scan.Name))
                    {
                        return false;
                    }
                    scan = scan.ParentDirectory;
                }
                return true;
            }
            /*string */ CalculateStem(/*FileInfoBase*/ matchedFile)
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(this.Frame.Stem, matchedFile.Name);
            }
            static $h = 1835036;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":917532,"g":{"r":0,"d":0,"h":34361573404,"f":4},"n":"Pattern","d":1835036,"h":30066606108,"f":4}],"m":[{"r":2359324,"p":[{"n":"file","p":196636}],"n":"Test","d":1835036,"h":8591769628,"f":32769},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":1835036,"h":12886736924,"f":98305},{"r":65537,"n":"PopDirectory","d":1835036,"h":17181704220,"f":32769},{"r":262145,"n":"IsStartingGroup","d":1835036,"h":38656540700,"f":4},{"r":262145,"n":"IsEndingGroup","d":1835036,"h":42951507996,"f":4},{"r":262145,"p":[{"n":"value","p":1310721}],"n":"TestMatchingSegment","d":1835036,"h":47246475292,"f":4},{"r":262145,"p":[{"n":"value","p":327708}],"n":"TestMatchingGroup","d":1835036,"h":51541442588,"f":4},{"r":1310721,"p":[{"n":"matchedFile","p":196636}],"n":"CalculateStem","d":1835036,"h":55836409884,"f":4}],"c":[{"p":[{"n":"pattern","p":917532}],"n":".ctor","o":"$ctor$2","d":1835036,"h":4296802332,"f":1}],"i":[851996],"j":[1900572],"h":1835036}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContext$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged.FrameData); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged`; }
        });
        
        $asm.$cls("$mef.System.Numerics.Hashing.HashHelpers", ($self) => class HashHelpers
        {
            static /*int */ Combine(/*int*/ h1, /*int*/ h2)
            {
                /*uint*/ let rol5 = (((h1 >>> 0) << 5) >>> 0) | ((h1 >>> 0) >>> 27);
                return ((((rol5 | 0) + h1) | 0)) ^ h2;
            }
            static $h = 2687004;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"h1","p":655361},{"n":"h2","p":655361}],"n":"Combine","d":2687004,"h":4297654300,"f":33}],"h":2687004}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Numerics.Hashing.HashHelpers`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult", ($self) => class PatternMatchingResult extends $.$spc.System.Object
        {
            $ctor$1(/*IEnumerable<FilePatternMatch>*/ files)
            {
                this.$ctor$2(files, $.$sl.System.Linq.Enumerable.Any($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, files));
                {
                    this.Files = files;
                }
                return this;
            }
            $ctor$2(/*IEnumerable<FilePatternMatch>*/ files, /*bool*/ hasMatches)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(files, "files");
                    this.Files = files;
                    this.HasMatches = hasMatches;
                }
                return this;
            }
            /*IEnumerable<FilePatternMatch>*/ Files = null;
            /*bool*/ HasMatches = false;
            //default member initializer
            constructor()
            {
                super();
                this.HasMatches = false;
            }
            static $h = 2555932;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h,"g":{"r":0,"d":0,"h":21477392412,"f":1},"s":{"r":0,"d":0,"h":25772359708,"f":1},"n":"Files","d":2555932,"h":17182425116,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38657261596,"f":1},"n":"HasMatches","d":2555932,"h":34362294300,"f":1}],"c":[{"p":[{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h}],"n":".ctor","o":"$ctor$1","d":2555932,"h":4297523228,"f":1},{"p":[{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h},{"n":"hasMatches","p":262145}],"n":".ctor","o":"$ctor$2","d":2555932,"h":8592490524,"f":1}],"h":2555932}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Matcher", ($self) => class Matcher extends $.$spc.System.Object
        {
            /*List<IPattern>?*/ _includePatterns = null;
            /*List<IPattern>?*/ _excludePatterns = null;
            /*List<IncludeOrExcludeValue<IPattern>>?*/ _includeOrExcludePatterns = null;
            /*PatternBuilder*/ _builder = null;
            /*StringComparison*/ _comparison = 0;
            /*bool*/ _preserveFilterOrder = false;
            $ctor$1()
            {
                this.$ctor$3(5/*StringComparison.OrdinalIgnoreCase*/, false);
                {
                }
                return this;
            }
            $ctor$2(/*StringComparison*/ comparisonType)
            {
                this.$ctor$3(comparisonType, false);
                {
                }
                return this;
            }
            $ctor$3(/*StringComparison*/ comparisonType, /*bool*/ preserveFilterOrder)
            {
                super.$ctor();
                {
                    this._comparison = comparisonType;
                    this._builder = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder().$ctor$2(comparisonType);
                    this._preserveFilterOrder = preserveFilterOrder;
                    if (preserveFilterOrder)
                    {
                        this._includeOrExcludePatterns = (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)))().$ctor$1();
                            return $t1;
                        })();
                    }
                    else 
                    {
                        this._includePatterns = (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern))().$ctor$1();
                            return $t1;
                        })();
                        this._excludePatterns = (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern))().$ctor$1();
                            return $t1;
                        })();
                    }
                }
                return this;
            }
            /*Matcher */ AddInclude(/*string*/ pattern)
            {
                if (this._preserveFilterOrder)
                {
                    this._includeOrExcludePatterns.Add((() =>
                    {
                        //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)()
                        const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern);
                        const $i1 = new $t1();
                        $i1.Value = this._builder.Build(pattern);
                        $i1.IsInclude = true;
                        return $i1;
                    })());
                }
                else 
                {
                    this._includePatterns.Add(this._builder.Build(pattern));
                }
                return this;
            }
            /*Matcher */ AddExclude(/*string*/ pattern)
            {
                if (this._preserveFilterOrder)
                {
                    this._includeOrExcludePatterns.Add((() =>
                    {
                        //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)()
                        const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern);
                        const $i1 = new $t1();
                        $i1.Value = this._builder.Build(pattern);
                        $i1.IsInclude = false;
                        return $i1;
                    })());
                }
                else 
                {
                    this._excludePatterns.Add(this._builder.Build(pattern));
                }
                return this;
            }
            /*PatternMatchingResult */ Execute(/*DirectoryInfoBase*/ directoryInfo)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(directoryInfo, "directoryInfo");
                return this._preserveFilterOrder ? new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext().$ctor$2(this._includeOrExcludePatterns, directoryInfo, this._comparison).Execute() : new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext().$ctor$1(this._includePatterns, this._excludePatterns, directoryInfo, this._comparison).Execute();
            }
            static $h = 2424860;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":2424860,"p":[{"n":"pattern","p":1310721}],"n":"AddInclude","d":2424860,"h":42952097820,"f":129},{"r":2424860,"p":[{"n":"pattern","p":1310721}],"n":"AddExclude","d":2424860,"h":47247065116,"f":129},{"r":2555932,"p":[{"n":"directoryInfo","p":65564}],"n":"Execute","d":2424860,"h":51542032412,"f":129}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h,"n":"_includePatterns","d":2424860,"h":4297392156,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h,"n":"_excludePatterns","d":2424860,"h":8592359452,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)).$h,"n":"_includeOrExcludePatterns","d":2424860,"h":12887326748,"f":2},{"t":2162716,"n":"_builder","d":2424860,"h":17182294044,"f":2},{"t":119472129,"n":"_comparison","d":2424860,"h":21477261340,"f":2},{"t":262145,"n":"_preserveFilterOrder","d":2424860,"h":25772228636,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":2424860,"h":30067195932,"f":1},{"p":[{"n":"comparisonType","p":119472129}],"n":".ctor","o":"$ctor$2","d":2424860,"h":34362163228,"f":1},{"p":[{"n":"comparisonType","p":119472129,"f":65,"v":5},{"n":"preserveFilterOrder","p":262145,"f":65,"v":false}],"n":".ctor","o":"$ctor$3","d":2424860,"h":38657130524,"f":1}],"h":2424860}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Matcher`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions", ($self) => class MatcherExtensions
        {
            static /*void */ AddExcludePatterns(/*this Matcher*/ matcher, /*params IEnumerable<string>[]*/ excludePatternsGroups)
            {
                let $i1 = 0;
                let $arr1 = excludePatternsGroups;
                while ($i1 < $arr1.length)
                {
                    let group = $arr1[$i1++];
                    var $en3 = group.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pattern = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            matcher.AddExclude(pattern);
                        }
                    }
                }
            }
            static /*void */ AddIncludePatterns(/*this Matcher*/ matcher, /*params IEnumerable<string>[]*/ includePatternsGroups)
            {
                let $i1 = 0;
                let $arr1 = includePatternsGroups;
                while ($i1 < $arr1.length)
                {
                    let group = $arr1[$i1++];
                    var $en3 = group.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pattern = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            matcher.AddInclude(pattern);
                        }
                    }
                }
            }
            static /*IEnumerable<string> */ GetResultsInFullPath(/*this Matcher*/ matcher, /*string*/ directoryPath)
            {
                /*PatternMatchingResult*/ let patternMatchingResult = matcher.Execute(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(new $.$spc.System.IO.DirectoryInfo().$ctor$4(directoryPath)));
                if (!patternMatchingResult.HasMatches)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.String);
                }
                /*IEnumerable<FilePatternMatch>*/ let matches = patternMatchingResult.Files;
                let matchCollection;
                /*List<string>*/ let result = $.$is(matches, $.$spc.System.Collections.ICollection, { set $v(v){ matchCollection = v; } }) ? new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$2(matchCollection.System$Collections$ICollection$Count) : new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                var $en2 = matches.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var match = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        result.Add($.$spc.System.IO.Path.GetFullPath($.$spc.System.IO.Path.Combine(directoryPath, match.Path)));
                    }
                }
                return result;
            }
            static /*PatternMatchingResult */ Match(/*this Matcher*/ matcher, /*string*/ file)
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$3(matcher, $.$spc.System.IO.Directory.GetCurrentDirectory(), (() =>
                {
                    //new $.$spc.System.Collections.Generic.List$$($.$spc.System.String)()
                    const $t1 = $.$spc.System.Collections.Generic.List$$($.$spc.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add(file);
                    return $i1;
                })());
            }
            static /*PatternMatchingResult */ Match$1(/*this Matcher*/ matcher, /*string*/ rootDir, /*string*/ file)
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$3(matcher, rootDir, (() =>
                {
                    //new $.$spc.System.Collections.Generic.List$$($.$spc.System.String)()
                    const $t1 = $.$spc.System.Collections.Generic.List$$($.$spc.System.String);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add(file);
                    return $i1;
                })());
            }
            static /*PatternMatchingResult */ Match$2(/*this Matcher*/ matcher, /*IEnumerable<string>?*/ files)
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions.Match$3(matcher, $.$spc.System.IO.Directory.GetCurrentDirectory(), files);
            }
            static /*PatternMatchingResult */ Match$3(/*this Matcher*/ matcher, /*string*/ rootDir, /*IEnumerable<string>?*/ files)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(matcher, "matcher");
                return matcher.Execute(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$3(rootDir, files));
            }
            static $h = 2490396;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"matcher","p":2424860},{"n":"excludePatternsGroups","p":0,"f":16}],"n":"AddExcludePatterns","d":2490396,"h":4297457692,"f":33},{"r":65537,"p":[{"n":"matcher","p":2424860},{"n":"includePatternsGroups","p":0,"f":16}],"n":"AddIncludePatterns","d":2490396,"h":8592424988,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"matcher","p":2424860},{"n":"directoryPath","p":1310721}],"n":"GetResultsInFullPath","d":2490396,"h":12887392284,"f":33},{"r":2555932,"p":[{"n":"matcher","p":2424860},{"n":"file","p":1310721}],"n":"Match","d":2490396,"h":17182359580,"f":33},{"r":2555932,"p":[{"n":"matcher","p":2424860},{"n":"rootDir","p":1310721},{"n":"file","p":1310721}],"n":"Match","o":"@$1","d":2490396,"h":21477326876,"f":33},{"r":2555932,"p":[{"n":"matcher","p":2424860},{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Match","o":"@$2","d":2490396,"h":25772294172,"f":33},{"r":2555932,"p":[{"n":"matcher","p":2424860},{"n":"rootDir","p":1310721},{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Match","o":"@$3","d":2490396,"h":30067261468,"f":33}],"h":2490396}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.MatcherExtensions`; }
        });
        
        $asm.$cls("$mef.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mef.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.FileSystemGlobbing", $.$mef.System.SR.$type.Assembly);
                    $.$mef.System.SR.s_resourceManager = temp;
                }
                return $.$mef.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mef.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mef.System.SR.resourceCulture = value;
            }
            static /*string */ get CannotDeclarePathSegment()
            {
                return "Cannot declare path segment before entering a directory.";
            }
            static /*string */ get CannotTestDirectory()
            {
                return "Cannot test directory before entering a directory.";
            }
            static /*string */ get CannotTestFile()
            {
                return "Cannot test file before entering a directory.";
            }
            static /*string */ get StringComparisonTypeShouldBeOrdinal()
            {
                return "Unexpected StringComparison type: '{0}'. Only 'Ordinal' and 'OrdinalIgnoreCase' are supported.";
            }
            static /*string */ FormatStringComparisonTypeShouldBeOrdinal(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unexpected StringComparison type: '{0}'. Only 'Ordinal' and 'OrdinalIgnoreCase' are supported.", arg1);
            }
            static /*string */ get UnexpectedStringComparisonType()
            {
                return "Unexpected StringComparison type: {0}";
            }
            static /*string */ FormatUnexpectedStringComparisonType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Unexpected StringComparison type: {0}", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mef.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mef.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mef.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mef.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mef.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mef.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mef.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2752540;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2752540}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper", ($self) => class StringComparisonHelper
        {
            static /*StringComparer */ GetStringComparer(/*StringComparison*/ comparisonType)
            {
                return (() =>
                {
                    if (comparisonType === 0/*StringComparison.CurrentCulture*/)
                    {
                        return $.$spc.System.StringComparer.CurrentCulture;
                    }
                    if (comparisonType === 1/*StringComparison.CurrentCultureIgnoreCase*/)
                    {
                        return $.$spc.System.StringComparer.CurrentCultureIgnoreCase;
                    }
                    if (comparisonType === 4/*StringComparison.Ordinal*/)
                    {
                        return $.$spc.System.StringComparer.Ordinal;
                    }
                    if (comparisonType === 5/*StringComparison.OrdinalIgnoreCase*/)
                    {
                        return $.$spc.System.StringComparer.OrdinalIgnoreCase;
                    }
                    if (comparisonType === 2/*StringComparison.InvariantCulture*/)
                    {
                        return $.$spc.System.StringComparer.InvariantCulture;
                    }
                    if (comparisonType === 3/*StringComparison.InvariantCultureIgnoreCase*/)
                    {
                        return $.$spc.System.StringComparer.InvariantCultureIgnoreCase;
                    }
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.Format($.$mef.System.SR.UnexpectedStringComparisonType, $.$box(comparisonType, $.$spc.System.StringComparison)));
                })();
            }
            static $h = 2621468;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":119406593,"p":[{"n":"comparisonType","p":119472129}],"n":"GetStringComparer","d":2621468,"h":4297588764,"f":33}],"h":2621468}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext", ($self) => class MatcherContext extends $.$spc.System.Object
        {
            /*DirectoryInfoBase*/ _root = null;
            /*IPatternContext*/ _patternContext = null;
            /*List<FilePatternMatch>*/ _files = null;
            /*HashSet<string>*/ _declaredLiteralFolderSegmentInString = null;
            /*HashSet<LiteralPathSegment>*/ _declaredLiteralFileSegments = null;
            /*bool*/ _declaredParentPathSegment = false;
            /*bool*/ _declaredWildcardPathSegment = false;
            $ctor$1(/*IEnumerable<IPattern>*/ includePatterns, /*IEnumerable<IPattern>*/ excludePatterns, /*DirectoryInfoBase*/ directoryInfo, /*StringComparison*/ comparison)
            {
                super.$ctor();
                {
                    this._root = directoryInfo;
                    this._files = (() =>
                    {
                        let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch))().$ctor$1();
                        return $t1;
                    })();
                    this._declaredLiteralFolderSegmentInString = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$2($.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(comparison));
                    /*IPatternContext[]*/ let includePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$sl.System.Linq.Enumerable.Select($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, includePatterns, new ($.$spc.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext))().$ctor(this,  (/**/ pattern) =>
                    {
                        return pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude();
                    })));
                    /*IPatternContext[]*/ let excludePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, $.$sl.System.Linq.Enumerable.Select($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, excludePatterns, new ($.$spc.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext))().$ctor(this,  (/**/ pattern) =>
                    {
                        return pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude();
                    })));
                    this._patternContext = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext().$ctor$2(includePatternContexts, excludePatternContexts);
                }
                return this;
            }
            $ctor$2(/*List<IncludeOrExcludeValue<IPattern>>*/ orderedPatterns, /*DirectoryInfoBase*/ directoryInfo, /*StringComparison*/ comparison)
            {
                super.$ctor();
                {
                    this._root = directoryInfo;
                    this._files = (() =>
                    {
                        let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch))().$ctor$1();
                        return $t1;
                    })();
                    this._declaredLiteralFolderSegmentInString = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$2($.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(comparison));
                    /*IncludeOrExcludeValue<IPatternContext>[]*/ let includeOrExcludePatternContexts = $.$sl.System.Linq.Enumerable.ToArray($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext), $.$sl.System.Linq.Enumerable.Select($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern), $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext), orderedPatterns, new ($.$spc.System.Func$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern), $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)))().$ctor(this,  (/*item*/ item) =>
                    {
                        return (() =>
                        {
                            //new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext)()
                            const $t1 = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext);
                            const $i1 = new $t1();
                            $i1.Value = item.IsInclude ? item.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude() : item.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude();
                            $i1.IsInclude = item.IsInclude;
                            return $i1;
                        })();
                    })));
                    this._patternContext = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext().$ctor$2(includeOrExcludePatternContexts);
                }
                return this;
            }
            /*PatternMatchingResult */ Execute()
            {
                this._files.Clear();
                this.Match(this._root, null);
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.PatternMatchingResult().$ctor$2(this._files, this._files.Count > 0);
            }
            /*void */ Match(/*DirectoryInfoBase*/ directory, /*string?*/ parentRelativePath)
            {
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                this.Declare();
                /*var*/ let entities = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase))().$ctor$1();
                if (this._declaredWildcardPathSegment || this._declaredLiteralFileSegments.Count !== 0)
                {
                    entities.AddRange(directory.EnumerateFileSystemInfos());
                }
                else 
                {
                    /*IEnumerable<FileSystemInfoBase>*/ let candidates = directory.EnumerateFileSystemInfos();
                    var $en3 = candidates.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var candidate = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$is(candidate, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase) && this._declaredLiteralFolderSegmentInString.Contains(candidate.Name))
                            {
                                entities.Add(candidate);
                            }
                        }
                    }
                }
                if (this._declaredParentPathSegment)
                {
                    entities.Add(directory.GetDirectory(".."));
                }
                /*var*/ let subDirectories = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase))().$ctor$1();
                var $en2 = entities.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var entity = $en2.Current;
                    {
                        let fileInfo;
                        if ($.$is(entity, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase, { set $v(v){ fileInfo = v; } }))
                        {
                            /*PatternTestResult*/ let result = this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test$1(fileInfo);
                            if (result.IsSuccessful)
                            {
                                this._files.Add(new $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch().$ctor$2($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(parentRelativePath, fileInfo.Name), result.Stem));
                            }
                            continue;
                        }
                        let directoryInfo;
                        if ($.$is(entity, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase, { set $v(v){ directoryInfo = v; } }))
                        {
                            if (this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Test(directoryInfo))
                            {
                                subDirectories.Add(directoryInfo);
                            }
                            continue;
                        }
                    }
                }
                var $en2 = subDirectories.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var subDir = $en2.Current;
                    {
                        /*string*/ let relativePath = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext.CombinePath(parentRelativePath, subDir.Name);
                        this.Match(subDir, relativePath);
                    }
                }
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
            }
            /*void */ Declare()
            {
                this._declaredLiteralFileSegments.Clear();
                this._declaredParentPathSegment = false;
                this._declaredWildcardPathSegment = false;
                this._patternContext.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(new ($.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean))().$ctor(this, this.DeclareInclude));
            }
            /*void */ DeclareInclude(/*IPathSegment*/ patternSegment, /*bool*/ isLastSegment)
            {
                let literalSegment;
                if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment, { set $v(v){ literalSegment = v; } }))
                {
                    if (isLastSegment)
                    {
                        this._declaredLiteralFileSegments.Add(literalSegment);
                    }
                    else 
                    {
                        this._declaredLiteralFolderSegmentInString.Add(literalSegment.Value);
                    }
                }
                else if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment))
                {
                    this._declaredParentPathSegment = true;
                }
                else if ($.$is(patternSegment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment))
                {
                    this._declaredWildcardPathSegment = true;
                }
            }
            static /*string */ CombinePath(/*string?*/ left, /*string*/ right)
            {
                if ($.$spc.System.String.IsNullOrEmpty(left))
                {
                    return right;
                }
                else 
                {
                    return `${left}/${right}`;
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._declaredLiteralFileSegments = new ($.$spc.System.Collections.Generic.HashSet$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment))().$ctor$1();
            }
            static $h = 983068;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":2555932,"n":"Execute","d":983068,"h":42950656028,"f":1},{"r":65537,"p":[{"n":"directory","p":65564},{"n":"parentRelativePath","p":1310721}],"n":"Match","d":983068,"h":47245623324,"f":2},{"r":65537,"n":"Declare","d":983068,"h":51540590620,"f":2},{"r":65537,"p":[{"n":"patternSegment","p":720924},{"n":"isLastSegment","p":262145}],"n":"DeclareInclude","d":983068,"h":55835557916,"f":2},{"r":1310721,"p":[{"n":"left","p":1310721},{"n":"right","p":1310721}],"n":"CombinePath","d":983068,"h":60130525212,"f":40}],"l":[{"t":65564,"n":"_root","d":983068,"h":4295950364,"f":2},{"t":851996,"n":"_patternContext","d":983068,"h":8590917660,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h,"n":"_files","d":983068,"h":12885884956,"f":2},{"t":$.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String).$h,"n":"_declaredLiteralFolderSegmentInString","d":983068,"h":17180852252,"f":2},{"t":$.$spc.System.Collections.Generic.HashSet$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment).$h,"n":"_declaredLiteralFileSegments","d":983068,"h":21475819548,"f":2},{"t":262145,"n":"_declaredParentPathSegment","d":983068,"h":25770786844,"f":2},{"t":262145,"n":"_declaredWildcardPathSegment","d":983068,"h":30065754140,"f":2}],"c":[{"p":[{"n":"includePatterns","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h},{"n":"excludePatterns","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern).$h},{"n":"directoryInfo","p":65564},{"n":"comparison","p":119472129}],"n":".ctor","o":"$ctor$1","d":983068,"h":34360721436,"f":1},{"p":[{"n":"orderedPatterns","p":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern)).$h},{"n":"directoryInfo","p":65564},{"n":"comparison","p":119472129}],"n":".ctor","o":"$ctor$2","d":983068,"h":38655688732,"f":8}],"h":983068}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.MatcherContext`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder", ($self) => class PatternBuilder extends $.$spc.System.Object
        {
            /*char[]*/ static _slashes = null;
            /*char[]*/ static _star = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.ComparisonType = 5/*StringComparison.OrdinalIgnoreCase*/;
                }
                return this;
            }
            $ctor$2(/*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    this.ComparisonType = comparisonType;
                }
                return this;
            }
            /*StringComparison*/ ComparisonType = 0;
            /*IPattern */ Build(/*string*/ pattern)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(pattern, "pattern");
                pattern = $.$spc.System.String.TrimStart$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes);
                if ($.$spc.System.String.TrimEnd$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes).length < pattern.length)
                {
                    pattern = $.$spc.System.String.TrimEnd$2.call(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes) + "/**";
                }
                /*var*/ let allSegments = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                /*bool*/ let isParentSegmentLegal = true;
                /*List<IPathSegment>?*/ let segmentsPatternStartsWith = null;
                /*List<IList<IPathSegment>>?*/ let segmentsPatternContains = null;
                /*List<IPathSegment>?*/ let segmentsPatternEndsWith = null;
                /*int*/ let endPattern = pattern.length;
                for(/*int*/ let scanPattern = 0; scanPattern < endPattern; )
                {
                    /*int*/ let beginSegment = scanPattern;
                    /*int*/ let endSegment = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.NextIndex(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._slashes, scanPattern, endPattern);
                    /*IPathSegment?*/ let segment = null;
                    if (segment === null && ((endSegment - beginSegment) | 0) === 3)
                    {
                        if ($.$spc.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /*.*/ 46 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 2) | 0)) === /***/ 42)
                        {
                            beginSegment += 2;
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) === 2)
                    {
                        if ($.$spc.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /***/ 42)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment().$ctor$1();
                        }
                        else if ($.$spc.System.String.get_Chars.call(pattern, beginSegment) === /*.*/ 46 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /*.*/ 46)
                        {
                            if (!isParentSegmentLegal)
                            {
                                throw new $.$spc.System.ArgumentException().$ctor$10("\"..\" can be only added at the beginning of the pattern.");
                            }
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment().$ctor$1();
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) === 1)
                    {
                        if ($.$spc.System.String.get_Chars.call(pattern, beginSegment) === /*.*/ 46)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment().$ctor$1();
                        }
                    }
                    if (segment === null && ((endSegment - beginSegment) | 0) > 2)
                    {
                        if ($.$spc.System.String.get_Chars.call(pattern, beginSegment) === /***/ 42 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 1) | 0)) === /***/ 42 && $.$spc.System.String.get_Chars.call(pattern, ((beginSegment + 2) | 0)) === /*.*/ 46)
                        {
                            segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment().$ctor$1();
                            endSegment = beginSegment;
                        }
                    }
                    if (segment === null)
                    {
                        /*string*/ let beginsWith = $.$spc.System.String.Empty;
                        /*var*/ let contains = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                        /*string*/ let endsWith = $.$spc.System.String.Empty;
                        for(/*int*/ let scanSegment = beginSegment; scanSegment < endSegment; )
                        {
                            /*int*/ let beginLiteral = scanSegment;
                            /*int*/ let endLiteral = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.NextIndex(pattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder._star, scanSegment, endSegment);
                            if (beginLiteral === beginSegment)
                            {
                                if (endLiteral === endSegment)
                                {
                                    segment = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment().$ctor$1($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral), this.ComparisonType);
                                }
                                else 
                                {
                                    beginsWith = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral);
                                }
                            }
                            else if (endLiteral === endSegment)
                            {
                                endsWith = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral);
                            }
                            else 
                            {
                                if (beginLiteral !== endLiteral)
                                {
                                    contains.Add($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.Portion(pattern, beginLiteral, endLiteral));
                                }
                                else 
                                {
                                }
                            }
                            scanSegment = ((endLiteral + 1) | 0);
                        }
                        segment ??= new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment().$ctor$1(beginsWith, contains, endsWith, this.ComparisonType);
                    }
                    if (!(segment !== null && ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment))))
                    {
                        isParentSegmentLegal = false;
                    }
                    if ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment))
                    {
                    }
                    else 
                    {
                        if ($.$is(segment, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment))
                        {
                            if (segmentsPatternStartsWith === null)
                            {
                                segmentsPatternStartsWith = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$3(allSegments);
                                segmentsPatternEndsWith = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                                segmentsPatternContains = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)))().$ctor$1();
                            }
                            else if (segmentsPatternEndsWith.Count !== 0)
                            {
                                segmentsPatternContains.Add(segmentsPatternEndsWith);
                                segmentsPatternEndsWith = new ($.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment))().$ctor$1();
                            }
                        }
                        else 
                        {
                            segmentsPatternEndsWith?.Add(segment);
                        }
                        allSegments.Add(segment);
                    }
                    scanPattern = ((endSegment + 1) | 0);
                }
                if (segmentsPatternStartsWith === null)
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern().$ctor$1(allSegments);
                }
                else 
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern().$ctor$1(allSegments, segmentsPatternStartsWith, segmentsPatternEndsWith, segmentsPatternContains);
                }
            }
            static /*int */ NextIndex(/*string*/ pattern, /*char[]*/ anyOf, /*int*/ beginIndex, /*int*/ endIndex)
            {
                /*int*/ let index = $.$spc.System.String.IndexOfAny$2.call(pattern, anyOf, beginIndex, ((endIndex - beginIndex) | 0));
                return index === -1 ? endIndex : index;
            }
            static /*string */ Portion(/*string*/ pattern, /*int*/ beginIndex, /*int*/ endIndex)
            {
                return $.$spc.System.String.Substring$1.call(pattern, beginIndex, ((endIndex - beginIndex) | 0));
            }
            static $_LinearPattern;
            static get LinearPattern()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder;
                return $cls.$_LinearPattern ??= $asm.$ncls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern", ($self) => class LinearPattern extends $.$spc.System.Object
                {
                    $ctor$1(/*List<IPathSegment>*/ allSegments)
                    {
                        super.$ctor();
                        {
                            this.Segments = allSegments;
                        }
                        return this;
                    }
                    /*IList<IPathSegment>*/ Segments = null;
                    /*IPatternContext */ CreatePatternContextForInclude()
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude().$ctor$3(this);
                    }
                    /*IPatternContext */ CreatePatternContextForExclude()
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude().$ctor$3(this);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern.Segments.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments()
                    {
                        return this.Segments;
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForInclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude()
                    {
                        return this.CreatePatternContextForInclude(...arguments);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForExclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude()
                    {
                        return this.CreatePatternContextForExclude(...arguments);
                    }
                    static $h = 2228252;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":17182097436,"f":1},"n":"Segments","d":2228252,"h":12887130140,"f":1}],"m":[{"r":851996,"n":"CreatePatternContextForInclude","d":2228252,"h":21477064732,"f":1},{"r":851996,"n":"CreatePatternContextForExclude","d":2228252,"h":25772032028,"f":1}],"c":[{"p":[{"n":"allSegments","p":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h}],"n":".ctor","o":"$ctor$1","d":2228252,"h":4297195548,"f":1}],"i":[524316,786460],"d":2162716,"h":2228252}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.ILinearPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.LinearPattern`; }
                }, $cls, ($v) => $cls.$_LinearPattern = $v);
            }
            static $_RaggedPattern;
            static get RaggedPattern()
            {
                let $cls = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder;
                return $cls.$_RaggedPattern ??= $asm.$ncls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern", ($self) => class RaggedPattern extends $.$spc.System.Object
                {
                    $ctor$1(/*List<IPathSegment>*/ allSegments, /*IList<IPathSegment>*/ segmentsPatternStartsWith, /*IList<IPathSegment>*/ segmentsPatternEndsWith, /*IList<IList<IPathSegment>>*/ segmentsPatternContains)
                    {
                        super.$ctor();
                        {
                            this.Segments = allSegments;
                            this.StartsWith = segmentsPatternStartsWith;
                            this.Contains = segmentsPatternContains;
                            this.EndsWith = segmentsPatternEndsWith;
                        }
                        return this;
                    }
                    /*IList<IList<IPathSegment>>*/ Contains = null;
                    /*IList<IPathSegment>*/ EndsWith = null;
                    /*IList<IPathSegment>*/ Segments = null;
                    /*IList<IPathSegment>*/ StartsWith = null;
                    /*IPatternContext */ CreatePatternContextForInclude()
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude().$ctor$3(this);
                    }
                    /*IPatternContext */ CreatePatternContextForExclude()
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude().$ctor$3(this);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.Segments.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Segments()
                    {
                        return this.Segments;
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.StartsWith.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$StartsWith()
                    {
                        return this.StartsWith;
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.Contains.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains()
                    {
                        return this.Contains;
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern.EndsWith.get
                    get Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith()
                    {
                        return this.EndsWith;
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForInclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForInclude()
                    {
                        return this.CreatePatternContextForInclude(...arguments);
                    }
                    //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern.CreatePatternContextForExclude()
                    Microsoft$Extensions$FileSystemGlobbing$Internal$IPattern$CreatePatternContextForExclude()
                    {
                        return this.CreatePatternContextForExclude(...arguments);
                    }
                    static $h = 2293788;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h,"g":{"r":0,"d":0,"h":17182162972,"f":1},"n":"Contains","d":2293788,"h":12887195676,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":30067064860,"f":1},"n":"EndsWith","d":2293788,"h":25772097564,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":42951966748,"f":1},"n":"Segments","d":2293788,"h":38656999452,"f":1},{"p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h,"g":{"r":0,"d":0,"h":55836868636,"f":1},"n":"StartsWith","d":2293788,"h":51541901340,"f":1}],"m":[{"r":851996,"n":"CreatePatternContextForInclude","d":2293788,"h":60131835932,"f":1},{"r":851996,"n":"CreatePatternContextForExclude","d":2293788,"h":64426803228,"f":1}],"c":[{"p":[{"n":"allSegments","p":$.$spc.System.Collections.Generic.List$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h},{"n":"segmentsPatternStartsWith","p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h},{"n":"segmentsPatternEndsWith","p":$.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment).$h},{"n":"segmentsPatternContains","p":$.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.IList$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment)).$h}],"n":".ctor","o":"$ctor$1","d":2293788,"h":4297261084,"f":1}],"i":[917532,786460],"d":2162716,"h":2293788}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IRaggedPattern, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPattern ]; }
                    static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder.RaggedPattern`; }
                }, $cls, ($v) => $cls.$_RaggedPattern = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this.ComparisonType = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._slashes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/*/*/ 47, /*\\*/ 92], null, null);
                }
                {
                    this._star = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/***/ 42], null, null);
                }
            }
            static $h = 2162716;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":119472129,"g":{"r":0,"d":0,"h":30066933788,"f":1},"n":"ComparisonType","d":2162716,"h":25771966492,"f":1}],"m":[{"r":786460,"p":[{"n":"pattern","p":1310721}],"n":"Build","d":2162716,"h":34361901084,"f":1},{"r":655361,"p":[{"n":"pattern","p":1310721},{"n":"anyOf","p":0},{"n":"beginIndex","p":655361},{"n":"endIndex","p":655361}],"n":"NextIndex","d":2162716,"h":38656868380,"f":34},{"r":1310721,"p":[{"n":"pattern","p":1310721},{"n":"beginIndex","p":655361},{"n":"endIndex","p":655361}],"n":"Portion","d":2162716,"h":42951835676,"f":34}],"l":[{"t":0,"n":"_slashes","d":2162716,"h":4297130012,"f":34},{"t":0,"n":"_star","d":2162716,"h":8592097308,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":2162716,"h":12887064604,"f":1},{"p":[{"n":"comparisonType","p":119472129}],"n":".ctor","o":"$ctor$2","d":2162716,"h":17182031900,"f":1}],"j":[2228252,2293788],"h":2162716}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.Patterns.PatternBuilder`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment", ($self) => class CurrentPathSegment extends $.$spc.System.Object
        {
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            /*bool */ Match(/*string*/ value)
            {
                return false;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                return this.CanProduceStem;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                return this.Match(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1048604;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590983196,"f":1},"n":"CanProduceStem","d":1048604,"h":4296015900,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","d":1048604,"h":12885950492,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1048604,"h":17180917788,"f":1}],"i":[720924],"h":1048604}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.CurrentPathSegment`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment", ($self) => class ParentPathSegment extends $.$spc.System.Object
        {
            /*string*/ static LiteralParent = null;
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            /*bool */ Match(/*string*/ value)
            {
                return $.$spc.System.String.Equals$5(".."/*LiteralParent*/, value, 4/*StringComparison.Ordinal*/);
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                return this.CanProduceStem;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                return this.Match(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.LiteralParent = "..";
                }
            }
            static $h = 1179676;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886081564,"f":1},"n":"CanProduceStem","d":1179676,"h":8591114268,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","d":1179676,"h":17181048860,"f":1}],"l":[{"t":1310721,"n":"LiteralParent","d":1179676,"h":4296146972,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1179676,"h":21476016156,"f":1}],"i":[720924],"h":1179676}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.ParentPathSegment`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment", ($self) => class WildcardPathSegment extends $.$spc.System.Object
        {
            /*WildcardPathSegment*/ static MatchAll = null;
            /*StringComparison*/ _comparisonType = 0;
            $ctor$1(/*string*/ beginsWith, /*List<string>*/ contains, /*string*/ endsWith, /*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(beginsWith, "beginsWith");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(contains, "contains");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(endsWith, "endsWith");
                    this._comparisonType = (() =>
                    {
                        if ((comparisonType === 5/*StringComparison.OrdinalIgnoreCase*/) || (comparisonType === 4/*StringComparison.Ordinal*/))
                        {
                            return comparisonType;
                        }
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.Format($.$mef.System.SR.StringComparisonTypeShouldBeOrdinal, $.$box(comparisonType, $.$spc.System.StringComparison)));
                    })();
                    this.BeginsWith = beginsWith;
                    this.Contains = contains;
                    this.EndsWith = endsWith;
                }
                return this;
            }
            /*bool */ get CanProduceStem()
            {
                return true;
            }
            /*string*/ BeginsWith = null;
            /*List<string>*/ Contains = null;
            /*string*/ EndsWith = null;
            /*bool */ Match(/*string*/ value)
            {
                /*WildcardPathSegment*/ let wildcard = this;
                if (value.length < ((wildcard.BeginsWith.length + wildcard.EndsWith.length) | 0))
                {
                    return false;
                }
                if (!$.$spc.System.String.StartsWith$1.call(value, wildcard.BeginsWith, this._comparisonType))
                {
                    return false;
                }
                if (!$.$spc.System.String.EndsWith$1.call(value, wildcard.EndsWith, this._comparisonType))
                {
                    return false;
                }
                /*int*/ let beginRemaining = wildcard.BeginsWith.length;
                /*int*/ let endRemaining = ((value.length - wildcard.EndsWith.length) | 0);
                for(/*int*/ let containsIndex = 0; containsIndex !== wildcard.Contains.Count; ++containsIndex)
                {
                    /*string*/ let containsValue = wildcard.Contains.get_Item(containsIndex);
                    /*int*/ let indexOf = $.$spc.System.String.IndexOf$9.call(value, containsValue, beginRemaining, ((endRemaining - beginRemaining) | 0), this._comparisonType);
                    if (indexOf === -1)
                    {
                        return false;
                    }
                    beginRemaining = ((indexOf + containsValue.length) | 0);
                }
                return true;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                return this.CanProduceStem;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                return this.Match(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MatchAll = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment().$ctor$1($.$spc.System.String.Empty, new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1(), $.$spc.System.String.Empty, 5/*StringComparison.OrdinalIgnoreCase*/);
                }
            }
            static $h = 1310748;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476147228,"f":1},"n":"CanProduceStem","d":1310748,"h":17181179932,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361049116,"f":1},"n":"BeginsWith","d":1310748,"h":30066081820,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47245951004,"f":1},"n":"Contains","d":1310748,"h":42950983708,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60130852892,"f":1},"n":"EndsWith","d":1310748,"h":55835885596,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","d":1310748,"h":64425820188,"f":1}],"l":[{"t":1310748,"n":"MatchAll","d":1310748,"h":4296278044,"f":33},{"t":119472129,"n":"_comparisonType","d":1310748,"h":8591245340,"f":2}],"c":[{"p":[{"n":"beginsWith","p":1310721},{"n":"contains","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h},{"n":"endsWith","p":1310721},{"n":"comparisonType","p":119472129}],"n":".ctor","o":"$ctor$1","d":1310748,"h":12886212636,"f":1}],"i":[720924],"h":1310748}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment", ($self) => class LiteralPathSegment extends $.$spc.System.Object
        {
            /*StringComparison*/ _comparisonType = 0;
            /*bool */ get CanProduceStem()
            {
                return false;
            }
            $ctor$1(/*string*/ value, /*StringComparison*/ comparisonType)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                    this.Value = value;
                    this._comparisonType = comparisonType;
                }
                return this;
            }
            /*string*/ Value = null;
            /*bool */ Match(/*string*/ value)
            {
                return $.$spc.System.String.Equals$5(this.Value, value, this._comparisonType);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment, { set $v(v){ other = v; } }) && this._comparisonType === other._comparisonType && $.$spc.System.String.Equals$5(other.Value, this.Value, this._comparisonType);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Util.StringComparisonHelper.GetStringComparer(this._comparisonType).GetHashCode$2(this.Value);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                return this.CanProduceStem;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                return this.Match(...arguments);
            }
            static $h = 1114140;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886016028,"f":1},"n":"CanProduceStem","d":1114140,"h":8591048732,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065885212,"f":1},"n":"Value","d":1114140,"h":25770917916,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","d":1114140,"h":34360852508,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1114140,"h":38655819804,"f":32769},{"r":655361,"n":"GetHashCode","d":1114140,"h":42950787100,"f":32769}],"l":[{"t":119472129,"n":"_comparisonType","d":1114140,"h":4296081436,"f":2}],"c":[{"p":[{"n":"value","p":1310721},{"n":"comparisonType","p":119472129}],"n":".ctor","o":"$ctor$1","d":1114140,"h":17180983324,"f":1}],"i":[720924],"h":1114140}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.LiteralPathSegment`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment", ($self) => class RecursiveWildcardSegment extends $.$spc.System.Object
        {
            /*bool */ get CanProduceStem()
            {
                return true;
            }
            /*bool */ Match(/*string*/ value)
            {
                return false;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.CanProduceStem.get
            get Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$CanProduceStem()
            {
                return this.CanProduceStem;
            }
            //Generated interface implemetation for Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment.Match(string)
            Microsoft$Extensions$FileSystemGlobbing$Internal$IPathSegment$Match()
            {
                return this.Match(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1245212;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8591179804,"f":1},"n":"CanProduceStem","d":1245212,"h":4296212508,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Match","d":1245212,"h":12886147100,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1245212,"h":17181114396,"f":1}],"i":[720924],"h":1245212}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.RecursiveWildcardSegment`; }
        });
        
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<>", (TValue) => $asm.$gt("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<>", [TValue], ($self) => class IncludeOrExcludeValue$$ extends $.$spc.System.ValueType
        {
            /*TValue*/  get Value() { return this.$getField(0, 4); }
            /*TValue*/  set Value(value) { this.$setField(0, 4, value); }
            /*bool*/  get IsInclude() { return this.$getField(4, 1); }
            /*bool*/  set IsInclude(value) { this.$setField(4, 1, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value = this.Value;
                copy.IsInclude = this.IsInclude;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value = $.$default(TValue);
                this.IsInclude = false;
            }
            static $h = 589852;
            static $g = 1;
            static $z = 5;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":TValue?.$h??1507328,"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":8},{"t":262145,"n":"IsInclude","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1}],"g":[TValue?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.IncludeOrExcludeValue<${TValue?.$fullName}>`; }
        }));
        
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult", ($self) => class PatternTestResult extends $.$spc.System.ValueType
        {
            /*PatternTestResult*/ static Failed;
            /*bool*/ IsSuccessful = false;
            /*string?*/ Stem = null;
            $ctor$2(/*bool*/ isSuccessful, /*string?*/ stem)
            {
                super.$ctor$1();
                {
                    this.IsSuccessful = isSuccessful;
                    this.Stem = stem;
                }
                return this;
            }
            static /*PatternTestResult */ Success(/*string?*/ stem)
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult().$ctor$2(true, stem);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.IsSuccessful = this.IsSuccessful;
                copy.Stem = this.Stem;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsSuccessful = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Failed = new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult().$ctor$2(false, null);
                }
            }
            static $h = 2359324;
            static $z = 5;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17182228508,"f":1},"n":"IsSuccessful","d":2359324,"h":12887261212,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30067130396,"f":1},"n":"Stem","d":2359324,"h":25772163100,"f":1}],"m":[{"r":2359324,"p":[{"n":"stem","p":1310721}],"n":"Success","d":2359324,"h":38657064988,"f":33}],"l":[{"t":2359324,"n":"Failed","d":2359324,"h":4297326620,"f":33}],"c":[{"p":[{"n":"isSuccessful","p":262145},{"n":"stem","p":1310721}],"n":".ctor","o":"$ctor$2","d":2359324,"h":34362097692,"f":2},{"n":".ctor","o":"$ctor$3","d":2359324,"h":42952032284,"f":1}],"h":2359324}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult`; }
        });
        
        $asm.$str("$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch", ($self) => class FilePatternMatch extends $.$spc.System.ValueType
        {
            /*string*/ Path = null;
            /*string*/ Stem = null;
            $ctor$2(/*string*/ path, /*string*/ stem)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(path, "path");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(stem, "stem");
                    this.Path = path;
                    this.Stem = stem;
                }
                return this;
            }
            /*bool */ Equals$2(/*FilePatternMatch*/ other)
            {
                return $.$spc.System.String.Equals$5(other.Path, this.Path, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.Equals$5(other.Stem, this.Stem, 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let match;
                return $.$is(obj, $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch, { set $v(v){ match = v; } }) && this.Equals$2(match);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$mef.System.Numerics.Hashing.HashHelpers.Combine($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode$1(this.Path), $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode$1(this.Stem));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch.GetHashCode.apply(this, arguments); }
            static /*int */ GetHashCode$1(/*string?*/ value)
            {
                return $.$spc.System.String.op_Inequality(value, null) ? $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(value) : 0;
            }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch>.Equals(Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Path = this.Path;
                copy.Stem = this.Stem;
                return copy;
            }
            static $h = 393244;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885295132,"f":1},"n":"Path","d":393244,"h":8590327836,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":25770197020,"f":1},"n":"Stem","d":393244,"h":21475229724,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":393244}],"n":"Equals","o":"@$2","d":393244,"h":34360131612,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":393244,"h":38655098908,"f":32769},{"r":655361,"n":"GetHashCode","d":393244,"h":42950066204,"f":32769},{"r":655361,"p":[{"n":"value","p":1310721}],"n":"GetHashCode","o":"@$1","d":393244,"h":47245033500,"f":34}],"c":[{"p":[{"n":"path","p":1310721},{"n":"stem","p":1310721}],"n":".ctor","o":"$ctor$2","d":393244,"h":30065164316,"f":1},{"n":".ctor","o":"$ctor$3","d":393244,"h":51540000796,"f":1}],"i":[$.$spc.System.IEquatable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch).$h],"h":393244}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch) ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.FilePatternMatch`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext", ($self) => class IncludesFirstCompositePatternContext extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext
        {
            /*IPatternContext[]*/ _includePatternContexts = null;
            /*IPatternContext[]*/ _excludePatternContexts = null;
            $ctor$2(/*IPatternContext[]*/ includePatternContexts, /*IPatternContext[]*/ excludePatternContexts)
            {
                super.$ctor$1();
                {
                    this._includePatternContexts = includePatternContexts;
                    this._excludePatternContexts = excludePatternContexts;
                }
                return this;
            }
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let include = $arr1[$i1++];
                    include.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(onDeclare);
                }
            }
            /*PatternTestResult */ MatchPatternContexts(TFileInfoBase, /*TFileInfoBase*/ fileInfo, /*Func<IPatternContext, TFileInfoBase, PatternTestResult>*/ test)
            {
                /*PatternTestResult*/ let result = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    /*PatternTestResult*/ let localResult = test.Invoke(context, fileInfo);
                    if (localResult.IsSuccessful)
                    {
                        result = localResult;
                        break;
                    }
                }
                if (!result.IsSuccessful)
                {
                    return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                }
                let $i2 = 0;
                let $arr2 = this._excludePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    if (test.Invoke(context, fileInfo).IsSuccessful)
                    {
                        return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                    }
                }
                return result;
            }
            /*void */ PopDirectory()
            {
                let $i1 = 0;
                let $arr1 = this._excludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
                let $i2 = 0;
                let $arr2 = this._includePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
            }
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                let $i1 = 0;
                let $arr1 = this._includePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
                let $i2 = 0;
                let $arr2 = this._excludePatternContexts;
                while ($i2 < $arr2.length)
                {
                    let context = $arr2[$i2++];
                    context.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
            }
            static $h = 1441820;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1376284,"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":1441820,"h":17181311004,"f":32769},{"r":2359324,"p":[{"n":"fileInfo","p":(TFileInfoBase) => TFileInfoBase.$h},{"n":"test","p":(TFileInfoBase) => $.$spc.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h}],"g":["TFileInfoBase"],"n":"MatchPatternContexts","d":1441820,"h":21476278300,"f":163856},{"r":65537,"n":"PopDirectory","d":1441820,"h":25771245596,"f":32769},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":1441820,"h":30066212892,"f":32769}],"l":[{"t":0,"n":"_includePatternContexts","d":1441820,"h":4296409116,"f":2},{"t":0,"n":"_excludePatternContexts","d":1441820,"h":8591376412,"f":2}],"c":[{"p":[{"n":"includePatternContexts","p":0},{"n":"excludePatternContexts","p":0}],"n":".ctor","o":"$ctor$2","d":1441820,"h":12886343708,"f":8}],"i":[851996],"h":1441820}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.IncludesFirstCompositePatternContext`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext", ($self) => class PreserveOrderCompositePatternContext extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext
        {
            /*IncludeOrExcludeValue<IPatternContext>[]*/ _includeOrExcludePatternContexts = null;
            $ctor$2(/*IncludeOrExcludeValue<IPatternContext>[]*/ includeOrExcludePatternContexts)
            {
                super.$ctor$1();
                this._includeOrExcludePatternContexts = includeOrExcludePatternContexts;
                return this;
            }
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    if (context.IsInclude)
                    {
                        context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$Declare(onDeclare);
                    }
                }
            }
            /*PatternTestResult */ MatchPatternContexts(TFileInfoBase, /*TFileInfoBase*/ fileInfo, /*Func<IPatternContext, TFileInfoBase, PatternTestResult>*/ test)
            {
                /*PatternTestResult*/ let result = $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    if (result.IsSuccessful !== context.IsInclude)
                    {
                        /*PatternTestResult*/ let localResult = test.Invoke(context.Value, fileInfo);
                        if (localResult.IsSuccessful)
                        {
                            result = context.IsInclude ? localResult : $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult.Failed;
                        }
                    }
                }
                return result;
            }
            /*void */ PopDirectory()
            {
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PopDirectory();
                }
            }
            /*void */ PushDirectory(/*DirectoryInfoBase*/ directory)
            {
                let $i1 = 0;
                let $arr1 = this._includeOrExcludePatternContexts;
                while ($i1 < $arr1.length)
                {
                    let context = $arr1[$i1++];
                    context.Value.Microsoft$Extensions$FileSystemGlobbing$Internal$IPatternContext$PushDirectory(directory);
                }
            }
            static $h = 2097180;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1376284,"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":2097180,"h":12886999068,"f":32769},{"r":2359324,"p":[{"n":"fileInfo","p":(TFileInfoBase) => TFileInfoBase.$h},{"n":"test","p":(TFileInfoBase) => $.$spc.System.Func$$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext, TFileInfoBase, $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternTestResult).$h}],"g":["TFileInfoBase"],"n":"MatchPatternContexts","d":2097180,"h":17181966364,"f":163856},{"r":65537,"n":"PopDirectory","d":2097180,"h":21476933660,"f":32769},{"r":65537,"p":[{"n":"directory","p":65564}],"n":"PushDirectory","d":2097180,"h":25771900956,"f":32769}],"l":[{"t":0,"n":"_includeOrExcludePatternContexts","d":2097180,"h":4297064476,"f":2}],"c":[{"p":[{"n":"includeOrExcludePatternContexts","p":0}],"n":".ctor","o":"$ctor$2","d":2097180,"h":8592031772,"f":8}],"i":[851996],"h":2097180}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.CompositePatternContext; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PreserveOrderCompositePatternContext`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper", ($self) => class DirectoryInfoWrapper extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase
        {
            /*DirectoryInfo*/ _directoryInfo = null;
            /*bool*/ _isParentPath = false;
            $ctor$3(/*DirectoryInfo*/ directoryInfo)
            {
                this.$ctor$4(directoryInfo, false);
                {
                }
                return this;
            }
            $ctor$4(/*DirectoryInfo*/ directoryInfo, /*bool*/ isParentPath)
            {
                super.$ctor$2();
                {
                    this._directoryInfo = directoryInfo;
                    this._isParentPath = isParentPath;
                }
                return this;
            }
            /*IEnumerable<FileSystemInfoBase> */ EnumerateFileSystemInfos()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    if (this._directoryInfo.Exists)
                    {
                        /*IEnumerable<FileSystemInfo>*/ let fileSystemInfos;
                        try
                        {
                            fileSystemInfos = this._directoryInfo.EnumerateFileSystemInfos$2("*", 0/*SearchOption.TopDirectoryOnly*/);
                        }
                        catch($e)
                        {
                            return;
                        }
                        var $en4 = fileSystemInfos.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var fileSystemInfo = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let directoryInfo;
                                if ($.$is(fileSystemInfo, $.$spc.System.IO.DirectoryInfo, { set $v(v){ directoryInfo = v; } }))
                                {
                                    yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(directoryInfo);
                                }
                                else 
                                {
                                    yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper().$ctor$3($.$cast(fileSystemInfo, $.$spc.System.IO.FileInfo));
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            /*DirectoryInfoBase? */ GetDirectory(/*string*/ name)
            {
                /*bool*/ let isParentPath = $.$spc.System.String.Equals$5(name, "..", 4/*StringComparison.Ordinal*/);
                if (isParentPath)
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4(new $.$spc.System.IO.DirectoryInfo().$ctor$4($.$spc.System.IO.Path.Combine(this._directoryInfo.FullName, name)), isParentPath);
                }
                else 
                {
                    /*DirectoryInfo[]*/ let dirs = this._directoryInfo.GetDirectories$1(name);
                    if (dirs.length === 1)
                    {
                        return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$4($.$spc.System.Array.$ReadT1.call(dirs, 0), isParentPath);
                    }
                    else if (dirs.length === 0)
                    {
                        return null;
                    }
                    else 
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10(`More than one sub directories are found under ${this._directoryInfo.FullName} with name ${name}.`);
                    }
                }
            }
            /*FileInfoBase */ GetFile(/*string*/ name)
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper().$ctor$3(new $.$spc.System.IO.FileInfo().$ctor$5($.$spc.System.IO.Path.Combine(this._directoryInfo.FullName, name)));
            }
            /*string */ get Name()
            {
                return this._isParentPath ? ".." : this._directoryInfo.Name;
            }
            /*string */ get FullName()
            {
                return this._directoryInfo.FullName;
            }
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(this._directoryInfo.Parent);
            }
            static $h = 131100;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65564,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38654836764,"f":32769},"n":"Name","d":131100,"h":34359869468,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":47244771356,"f":32769},"n":"FullName","d":131100,"h":42949804060,"f":32769},{"p":65564,"g":{"r":0,"d":0,"h":55834705948,"f":32769},"n":"ParentDirectory","d":131100,"h":51539738652,"f":32769}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,"n":"EnumerateFileSystemInfos","d":131100,"h":21474967580,"f":32769},{"r":65564,"p":[{"n":"name","p":1310721}],"n":"GetDirectory","d":131100,"h":25769934876,"f":32769},{"r":196636,"p":[{"n":"name","p":1310721}],"n":"GetFile","d":131100,"h":30064902172,"f":32769}],"l":[{"t":58654721,"n":"_directoryInfo","d":131100,"h":4295098396,"f":2},{"t":262145,"n":"_isParentPath","d":131100,"h":8590065692,"f":2}],"c":[{"p":[{"n":"directoryInfo","p":58654721}],"n":".ctor","o":"$ctor$3","d":131100,"h":12885032988,"f":1},{"p":[{"n":"directoryInfo","p":58654721},{"n":"isParentPath","p":262145}],"n":".ctor","o":"$ctor$4","d":131100,"h":17180000284,"f":2}],"h":131100}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo", ($self) => class InMemoryDirectoryInfo extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase
        {
            /*char[]*/ static DirectorySeparators = null;
            /*IEnumerable<string>*/ _files = null;
            $ctor$3(/*string*/ rootDir, /*IEnumerable<string>?*/ files)
            {
                this.$ctor$4(rootDir, files, false);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ rootDir, /*IEnumerable<string>?*/ files, /*bool*/ normalized)
            {
                super.$ctor$2();
                {
                    if ($.$spc.System.String.IsNullOrEmpty(rootDir))
                    {
                        throw new $.$spc.System.ArgumentNullException().$ctor$16("rootDir");
                    }
                    files ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    this.Name = $.$spc.System.IO.Path.GetFileName(rootDir);
                    if (normalized)
                    {
                        this._files = files;
                        this.FullName = rootDir;
                    }
                    else 
                    {
                        /*var*/ let fileList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$2($.$sl.System.Linq.Enumerable.Count($.$spc.System.String, files));
                        /*string*/ let normalizedRoot = $.$spc.System.IO.Path.GetFullPath($.$spc.System.String.Replace$2.call(rootDir, $.$spc.System.IO.Path.AltDirectorySeparatorChar, $.$spc.System.IO.Path.DirectorySeparatorChar));
                        var $en4 = files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var file = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                /*string*/ let fileWithNormalSeparators = $.$spc.System.String.Replace$2.call(file, $.$spc.System.IO.Path.AltDirectorySeparatorChar, $.$spc.System.IO.Path.DirectorySeparatorChar);
                                if ($.$spc.System.IO.Path.IsPathRooted(file))
                                {
                                    fileList.Add($.$spc.System.IO.Path.GetFullPath(fileWithNormalSeparators));
                                }
                                else 
                                {
                                    fileList.Add($.$spc.System.IO.Path.GetFullPath($.$spc.System.IO.Path.Combine(normalizedRoot, fileWithNormalSeparators)));
                                }
                            }
                        }
                        this._files = fileList;
                        this.FullName = normalizedRoot;
                    }
                }
                return this;
            }
            /*string*/ FullName = null;
            /*string*/ Name = null;
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$4($.$spc.System.IO.Path.GetDirectoryName(this.FullName), this._files, true);
            }
            /*IEnumerable<FileSystemInfoBase> */ EnumerateFileSystemInfos()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let dict = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.List$$($.$spc.System.String)))().$ctor$1();
                    var $en3 = this._files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var file = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!$.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo.IsRootDirectory(this.FullName, file))
                            {
                                continue;
                            }
                            /*int*/ let endPath = file.length;
                            /*int*/ let beginSegment = ((this.FullName.length + 1) | 0);
                            /*int*/ let endSegment = $.$spc.System.String.IndexOfAny$2.call(file, $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo.DirectorySeparators, beginSegment, ((endPath - beginSegment) | 0));
                            if (endSegment === -1)
                            {
                                yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo().$ctor$3(file, this);
                            }
                            else 
                            {
                                /*string*/ let name = $.$spc.System.String.Substring$1.call(file, 0, endSegment);
                                /*List<string>?*/ let list;
                                if (!dict.TryGetValue(name, $.$ref(() => list, ($v) => list = $v, $.$spc.System.Collections.Generic.List$$($.$spc.System.String))))
                                {
                                    dict.set_Item(name, (() =>
                                    {
                                        //new $.$spc.System.Collections.Generic.List$$($.$spc.System.String)()
                                        const $t2 = $.$spc.System.Collections.Generic.List$$($.$spc.System.String);
                                        const $i2 = new $t2();
                                        $i2.$ctor$1();
                                        $i2.Add(file);
                                        return $i2;
                                    })());
                                }
                                else 
                                {
                                    list.Add(file);
                                }
                            }
                        }
                    }
                    var $en3 = dict.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            yield new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$4(item.Key, item.Value, true);
                        }
                    }
                }.bind(this));
            }
            static /*bool */ IsRootDirectory(/*string*/ rootDir, /*string*/ filePath)
            {
                /*int*/ let rootDirLength = rootDir.length;
                return $.$spc.System.String.StartsWith$1.call(filePath, rootDir, 4/*StringComparison.Ordinal*/) && ($.$spc.System.String.get_Chars.call(rootDir, ((rootDirLength - 1) | 0)) === $.$spc.System.IO.Path.DirectorySeparatorChar || $.$spc.System.String.IndexOf$1.call(filePath, $.$spc.System.IO.Path.DirectorySeparatorChar, rootDirLength) === rootDirLength);
            }
            /*DirectoryInfoBase */ GetDirectory(/*string*/ path)
            {
                if ($.$spc.System.String.Equals$5(path, "..", 4/*StringComparison.Ordinal*/))
                {
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$4($.$spc.System.IO.Path.Combine(this.FullName, path), this._files, true);
                }
                else 
                {
                    /*string*/ let normPath = $.$spc.System.IO.Path.GetFullPath($.$spc.System.String.Replace$2.call(path, $.$spc.System.IO.Path.AltDirectorySeparatorChar, $.$spc.System.IO.Path.DirectorySeparatorChar));
                    return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo().$ctor$4(normPath, this._files, true);
                }
            }
            /*FileInfoBase? */ GetFile(/*string*/ path)
            {
                /*string*/ let normPath = $.$spc.System.IO.Path.GetFullPath($.$spc.System.String.Replace$2.call(path, $.$spc.System.IO.Path.AltDirectorySeparatorChar, $.$spc.System.IO.Path.DirectorySeparatorChar));
                var $en2 = this._files.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var file = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$spc.System.String.Equals$4(file, normPath))
                        {
                            return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo().$ctor$3(file, this);
                        }
                    }
                }
                return null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DirectorySeparators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [$.$spc.System.IO.Path.DirectorySeparatorChar, $.$spc.System.IO.Path.AltDirectorySeparatorChar], null, null);
                }
            }
            static $h = 458780;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65564,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065229852,"f":32769},"n":"FullName","d":458780,"h":25770262556,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":42950131740,"f":32769},"n":"Name","d":458780,"h":38655164444,"f":32769},{"p":65564,"g":{"r":0,"d":0,"h":51540066332,"f":32769},"n":"ParentDirectory","d":458780,"h":47245099036,"f":32769}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileSystemInfoBase).$h,"n":"EnumerateFileSystemInfos","d":458780,"h":55835033628,"f":32769},{"r":262145,"p":[{"n":"rootDir","p":1310721},{"n":"filePath","p":1310721}],"n":"IsRootDirectory","d":458780,"h":60130000924,"f":34},{"r":65564,"p":[{"n":"path","p":1310721}],"n":"GetDirectory","d":458780,"h":64424968220,"f":32769},{"r":196636,"p":[{"n":"path","p":1310721}],"n":"GetFile","d":458780,"h":68719935516,"f":32769}],"l":[{"t":0,"n":"DirectorySeparators","d":458780,"h":4295426076,"f":34},{"t":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"n":"_files","d":458780,"h":8590393372,"f":2}],"c":[{"p":[{"n":"rootDir","p":1310721},{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$3","d":458780,"h":12885360668,"f":1},{"p":[{"n":"rootDir","p":1310721},{"n":"files","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h},{"n":"normalized","p":262145}],"n":".ctor","o":"$ctor$4","d":458780,"h":17180327964,"f":2}],"h":458780}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.InMemoryDirectoryInfo`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper", ($self) => class FileInfoWrapper extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase
        {
            /*FileInfo*/ _fileInfo = null;
            $ctor$3(/*FileInfo*/ fileInfo)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(fileInfo, "fileInfo");
                    this._fileInfo = fileInfo;
                }
                return this;
            }
            /*string */ get Name()
            {
                return this._fileInfo.Name;
            }
            /*string */ get FullName()
            {
                return this._fileInfo.FullName;
            }
            /*DirectoryInfoBase? */ get ParentDirectory()
            {
                return new $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.DirectoryInfoWrapper().$ctor$3(this._fileInfo.Directory);
            }
            static $h = 262172;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196636,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180131356,"f":32769},"n":"Name","d":262172,"h":12885164060,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":25770065948,"f":32769},"n":"FullName","d":262172,"h":21475098652,"f":32769},{"p":65564,"g":{"r":0,"d":0,"h":34360000540,"f":32769},"n":"ParentDirectory","d":262172,"h":30065033244,"f":32769}],"l":[{"t":59834369,"n":"_fileInfo","d":262172,"h":4295229468,"f":2}],"c":[{"p":[{"n":"fileInfo","p":59834369}],"n":".ctor","o":"$ctor$3","d":262172,"h":8590196764,"f":1}],"h":262172}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoWrapper`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo", ($self) => class InMemoryFileInfo extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase
        {
            /*InMemoryDirectoryInfo*/ _parent = null;
            $ctor$3(/*string*/ file, /*InMemoryDirectoryInfo*/ parent)
            {
                super.$ctor$2();
                {
                    this.FullName = file;
                    this.Name = $.$spc.System.IO.Path.GetFileName(file);
                    this._parent = parent;
                }
                return this;
            }
            /*string*/ FullName = null;
            /*string*/ Name = null;
            /*DirectoryInfoBase */ get ParentDirectory()
            {
                return this._parent;
            }
            static $h = 655388;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196636,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475491868,"f":32769},"n":"FullName","d":655388,"h":17180524572,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":34360393756,"f":32769},"n":"Name","d":655388,"h":30065426460,"f":32769},{"p":65564,"g":{"r":0,"d":0,"h":42950328348,"f":32769},"n":"ParentDirectory","d":655388,"h":38655361052,"f":32769}],"l":[{"t":458780,"n":"_parent","d":655388,"h":4295622684,"f":2}],"c":[{"p":[{"n":"file","p":1310721},{"n":"parent","p":458780}],"n":".ctor","o":"$ctor$3","d":655388,"h":8590589980,"f":1}],"h":655388}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Abstractions.FileInfoBase; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.InMemoryFileInfo`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude", ($self) => class PatternContextLinearExclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear
        {
            $ctor$3(/*ILinearPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                }
                return this;
            }
            /*bool */ Test$1(/*DirectoryInfoBase*/ directory)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                return this.IsLastSegment() && this.TestMatchingSegment(directory.Name);
            }
            static $h = 1703964;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1572892,"m":[{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"@$1","d":1703964,"h":8591638556,"f":32769}],"c":[{"p":[{"n":"pattern","p":524316}],"n":".ctor","o":"$ctor$3","d":1703964,"h":4296671260,"f":1}],"i":[851996],"h":1703964}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearExclude`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude", ($self) => class PatternContextLinearInclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear
        {
            $ctor$3(/*ILinearPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                }
                return this;
            }
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotDeclarePathSegment);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return;
                }
                if (this.Frame.SegmentIndex < this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$ICollection$$$Count)
                {
                    onDeclare.Invoke(this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$ILinearPattern$Segments.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]), this.IsLastSegment());
                }
            }
            /*bool */ Test$1(/*DirectoryInfoBase*/ directory)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                return !this.IsLastSegment() && this.TestMatchingSegment(directory.Name);
            }
            static $h = 1769500;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1572892,"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":1769500,"h":8591704092,"f":32769},{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"@$1","d":1769500,"h":12886671388,"f":32769}],"c":[{"p":[{"n":"pattern","p":524316}],"n":".ctor","o":"$ctor$3","d":1769500,"h":4296736796,"f":1}],"i":[851996],"h":1769500}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinear; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextLinearInclude`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude", ($self) => class PatternContextRaggedInclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged
        {
            $ctor$3(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                }
                return this;
            }
            /*void */ Declare(/*Action<IPathSegment, bool>*/ onDeclare)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotDeclarePathSegment);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return;
                }
                if (this.IsStartingGroup() && this.Frame.SegmentIndex < this.Frame.SegmentGroup.System$Collections$Generic$ICollection$$$Count)
                {
                    onDeclare.Invoke(this.Frame.SegmentGroup.System$Collections$Generic$IList$$$get_Item(this.Frame.SegmentIndex, [$.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment]), false);
                }
                else 
                {
                    onDeclare.Invoke($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PathSegments.WildcardPathSegment.MatchAll, false);
                }
            }
            /*bool */ Test$1(/*DirectoryInfoBase*/ directory)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                if (this.IsStartingGroup() && !this.TestMatchingSegment(directory.Name))
                {
                    return false;
                }
                return true;
            }
            static $h = 2031644;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1835036,"m":[{"r":65537,"p":[{"n":"onDeclare","p":$.$spc.System.Action$$$($.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPathSegment, $.$spc.System.Boolean).$h}],"n":"Declare","d":2031644,"h":8591966236,"f":32769},{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"@$1","d":2031644,"h":12886933532,"f":32769}],"c":[{"p":[{"n":"pattern","p":917532}],"n":".ctor","o":"$ctor$3","d":2031644,"h":4296998940,"f":1}],"i":[851996],"h":2031644}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedInclude`; }
        });
        
        $asm.$cls("$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude", ($self) => class PatternContextRaggedExclude extends $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged
        {
            $ctor$3(/*IRaggedPattern*/ pattern)
            {
                super.$ctor$2(pattern);
                {
                }
                return this;
            }
            /*bool */ Test$1(/*DirectoryInfoBase*/ directory)
            {
                if (this.IsStackEmpty())
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$mef.System.SR.CannotTestDirectory);
                }
                if (this.Frame.IsNotApplicable)
                {
                    return false;
                }
                if (this.IsEndingGroup() && this.TestMatchingGroup(directory))
                {
                    return true;
                }
                if (this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$EndsWith.System$Collections$Generic$ICollection$$$Count === 0 && this.Frame.SegmentGroupIndex === ((this.Pattern.Microsoft$Extensions$FileSystemGlobbing$Internal$IRaggedPattern$Contains.System$Collections$Generic$ICollection$$$Count - 1) | 0) && this.TestMatchingGroup(directory))
                {
                    return true;
                }
                return false;
            }
            static $h = 1966108;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1835036,"m":[{"r":262145,"p":[{"n":"directory","p":65564}],"n":"Test","o":"@$1","d":1966108,"h":8591900700,"f":32769}],"c":[{"p":[{"n":"pattern","p":917532}],"n":".ctor","o":"$ctor$3","d":1966108,"h":4296933404,"f":1}],"i":[851996],"h":1966108}; }
            static get $b() { return $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRagged; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mef.Microsoft.Extensions.FileSystemGlobbing.Internal.IPatternContext ]; }
            static get $fullName() { return `Microsoft.Extensions.FileSystemGlobbing.Internal.PatternContexts.PatternContextRaggedExclude`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq"))