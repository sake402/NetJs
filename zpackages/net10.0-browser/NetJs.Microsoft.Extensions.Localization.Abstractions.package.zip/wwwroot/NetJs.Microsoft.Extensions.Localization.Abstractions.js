
//--TRIMMABLE-BOUNDARY-START(109)
(async function () {
(function ($global, $, $$) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization.Abstractions", 
    {
  "h": 109,
  "f": "Microsoft.Extensions.Localization.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Abstractions of application localization services.\nCommonly used types:\nMicrosoft.Extensions.Localization.IStringLocalizer\nMicrosoft.Extensions.Localization.IStringLocalizer\u003CT\u003E",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft .NET Extensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Localization.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131181)
        $asm.$cls(`$mela.MEL.IStringLocalizer`, ($self) => class IStringLocalizer
        {
            //--TRIMMABLE-BOUNDARY-START(30064902253)
            //--TRIMMABLE-BOUNDARY-END(30064902253)
            
            //--TRIMMABLE-BOUNDARY-START(25769934957)
            //--TRIMMABLE-BOUNDARY-END(25769934957)
            
            static $h = 131181;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064902253),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000365,
        "f": 50331905
      },
      "n": "Item",
      "o": "MEL$IStringLocalizer$Item$1",
      "d": 131181,
      "h": 30064902253,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30064902253),
//--TRIMMABLE-BOUNDARY-START(25769934957),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590065773,
        "f": 50331905
      },
      "n": "Item",
      "o": "MEL$IStringLocalizer$Item",
      "d": 131181,
      "h": 25769934957,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25769934957)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474967661),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mela.MEL.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "o": "MEL$IStringLocalizer$GetAllStrings",
      "d": 131181,
      "h": 21474967661,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474967661)
  ],
  "h": 131181
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.IStringLocalizer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}IStringLocalizer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131181)
        
        

        //--TRIMMABLE-BOUNDARY-START(262253)
        $asm.$cls(`$mela.MEL.IStringLocalizerFactory`, ($self) => class IStringLocalizerFactory
        {
            static $h = 262253;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196845),
    {
      "r": 131181,
      "p": [
        {
          "n": "resourceSource",
          "p": 188547073
        }
      ],
      "n": "Create",
      "o": "MEL$IStringLocalizerFactory$Create$1",
      "d": 262253,
      "h": 8590196845,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590196845),
//--TRIMMABLE-BOUNDARY-START(4295229549),
    {
      "r": 131181,
      "p": [
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "location",
          "p": 1310721
        }
      ],
      "n": "Create",
      "o": "MEL$IStringLocalizerFactory$Create",
      "d": 262253,
      "h": 4295229549,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229549)
  ],
  "h": 262253
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.IStringLocalizerFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}IStringLocalizerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262253)
        
        

        //--TRIMMABLE-BOUNDARY-START(196717)
        $asm.$cls(`$mela.MEL.IStringLocalizer<>`, (/*out*/ T) => $asm.$gt(`$mela.MEL.IStringLocalizer<>`, [/*out*/ T], ($self) => class IStringLocalizer$$
        {
            static $H = 196717;
            static $h = 196717;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 32
    }
  ],
  "r": 1,
  "H": 196717,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.MEL.IStringLocalizer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.IStringLocalizer<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}IStringLocalizer$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196717)
        
        

        //--TRIMMABLE-BOUNDARY-START(458861)
        $asm.$cls(`$mela.MEL.StringLocalizerExtensions`, ($self) => class StringLocalizerExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885360749)
            static /*LocalizedString */ GetString$1(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.MEL$IStringLocalizer$get_Item$1(name);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360749)
            
            //--TRIMMABLE-BOUNDARY-START(8590393453)
            static /*LocalizedString */ GetString(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name, /*params object[]*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.MEL$IStringLocalizer$get_Item(name, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393453)
            
            //--TRIMMABLE-BOUNDARY-START(4295426157)
            static /*IEnumerable<LocalizedString> */ GetAllStrings(/*this IStringLocalizer*/ stringLocalizer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                return stringLocalizer.MEL$IStringLocalizer$GetAllStrings(true);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426157)
            
            static $h = 458861;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360749),
    {
      "r": 327789,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131181
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetString",
      "o": "@$1",
      "d": 458861,
      "h": 12885360749,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885360749),
//--TRIMMABLE-BOUNDARY-START(8590393453),
    {
      "r": 327789,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131181
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "GetString",
      "d": 458861,
      "h": 8590393453,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393453),
//--TRIMMABLE-BOUNDARY-START(4295426157),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mela.MEL.LocalizedString).$h,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131181
        }
      ],
      "n": "GetAllStrings",
      "d": 458861,
      "h": 4295426157,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426157)
  ],
  "h": 458861
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.StringLocalizerExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}StringLocalizerExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458861)
        
        

        //--TRIMMABLE-BOUNDARY-START(65645)
        $asm.$cls(`$mela.MAS.ArgumentNullThrowHelper`, ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032941)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032941)
            
            //--TRIMMABLE-BOUNDARY-START(8590000237)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000237)
            
            static $h = 65645;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032941),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 65645,
      "h": 4295032941,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032941),
//--TRIMMABLE-BOUNDARY-START(8590000237),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 65645,
      "h": 8590000237,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000237)
  ],
  "h": 65645
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65645)
        
        

        //--TRIMMABLE-BOUNDARY-START(327789)
        $asm.$cls(`$mela.MEL.LocalizedString`, ($self) => class LocalizedString extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065098861)
            $ctor$3(/*string*/ name, /*string*/ value)
            {
                this.$ctor$2(name, value, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065098861);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098861)
            
            //--TRIMMABLE-BOUNDARY-START(25770131565)
            $ctor$2(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound)
            {
                this.$ctor$1(name, value, resourceNotFound, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770131565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131565)
            
            //--TRIMMABLE-BOUNDARY-START(21475164269)
            $ctor$1(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound, /*string?*/ searchedLocation)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                    $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(value, "value");
                    this.Name = name;
                    this.Value = value;
                    this.ResourceNotFound = resourceNotFound;
                    this.SearchedLocation = searchedLocation;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164269)
            
            //--TRIMMABLE-BOUNDARY-START(81604706413)
            static /*string? */ op_Implicit(/*LocalizedString*/ localizedString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return localizedString?.Value ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(81604706413)
            
            //--TRIMMABLE-BOUNDARY-START(68719804525)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68719804525)
            
            //--TRIMMABLE-BOUNDARY-START(90194641005)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(90194641005)
            
            //--TRIMMABLE-BOUNDARY-START(73014771821)
            /*bool*/ ResourceNotFound = false;
            //--TRIMMABLE-BOUNDARY-END(73014771821)
            
            //--TRIMMABLE-BOUNDARY-START(77309739117)
            /*string?*/ SearchedLocation = null;
            //--TRIMMABLE-BOUNDARY-END(77309739117)
            
            //--TRIMMABLE-BOUNDARY-START(85899673709)
            /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899673709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899673709)
            
            static $h = 327789;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719804525),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033453,
        "f": 50331649
      },
      "n": "Name",
      "d": 327789,
      "h": 68719804525,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719804525),
//--TRIMMABLE-BOUNDARY-START(90194641005),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837229,
        "f": 50331649
      },
      "n": "Value",
      "d": 327789,
      "h": 90194641005,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194641005),
//--TRIMMABLE-BOUNDARY-START(73014771821),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968045,
        "f": 50331649
      },
      "n": "ResourceNotFound",
      "d": 327789,
      "h": 73014771821,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014771821),
//--TRIMMABLE-BOUNDARY-START(77309739117),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902637,
        "f": 50331649
      },
      "n": "SearchedLocation",
      "d": 327789,
      "h": 77309739117,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309739117)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85899673709),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327789,
      "h": 85899673709,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85899673709)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065098861),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327789,
      "h": 30065098861,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098861),
//--TRIMMABLE-BOUNDARY-START(25770131565),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "resourceNotFound",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327789,
      "h": 25770131565,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770131565),
//--TRIMMABLE-BOUNDARY-START(21475164269),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "resourceNotFound",
          "p": 262145
        },
        {
          "n": "searchedLocation",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327789,
      "h": 21475164269,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164269)
  ],
  "h": 327789
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.LocalizedString`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}LocalizedString`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327789)
        
        

        //--TRIMMABLE-BOUNDARY-START(393325)
        $asm.$cls(`$mela.MEL.StringLocalizer<>`, (TResourceSource) => $asm.$gt(`$mela.MEL.StringLocalizer<>`, [TResourceSource], ($self) => class StringLocalizer$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360621)
            /*IStringLocalizer*/ _localizer = null;
            //--TRIMMABLE-BOUNDARY-END(4295360621)
            
            //--TRIMMABLE-BOUNDARY-START(8590327917)
            $ctor$1(/*IStringLocalizerFactory*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327917);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(factory, "factory");
                    this._localizer = factory.MEL$IStringLocalizerFactory$Create$1(TResourceSource.$type);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327917)
            
            //--TRIMMABLE-BOUNDARY-START(38655098989)
            /*LocalizedString*/ get_Item$2(/*string*/ name)
            {
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.MEL$IStringLocalizer$get_Item$1(name);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098989)
            
            //--TRIMMABLE-BOUNDARY-START(34360131693)
            /*LocalizedString*/ get_Item$1(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.MEL$IStringLocalizer$get_Item(name, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34360131693)
            
            //--TRIMMABLE-BOUNDARY-START(30065164397)
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164397);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._localizer.MEL$IStringLocalizer$GetAllStrings(includeParentCultures);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164397)
            
            //--TRIMMABLE-BOUNDARY-START(17180000365)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            MEL$IStringLocalizer$get_Item$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000365)
            
            //--TRIMMABLE-BOUNDARY-START(8590065773)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            MEL$IStringLocalizer$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065773)
            
            //--TRIMMABLE-BOUNDARY-START(21474967661)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            MEL$IStringLocalizer$GetAllStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllStrings(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967661)
            
            static $H = 393325;
            static $h = 393325;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655098989),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770197101,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331777
      },
      "n": "Item",
      "o": "@$2",
      "d": this.$h,
      "H": 38655098989,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(38655098989),
//--TRIMMABLE-BOUNDARY-START(34360131693),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180262509,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 34360131693,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(34360131693)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164397),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mela.MEL.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "d": this.$h,
      "H": 30065164397,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164397)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360621),
    {
      "t": 131181,
      "n": "_localizer",
      "d": this.$h,
      "H": 4295360621,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360621)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327917),
    {
      "p": [
        {
          "n": "factory",
          "p": 262253
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590327917,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327917)
  ],
  "s": [
    {
      "h": TResourceSource?.$h??1572864,
      "n": "TResourceSource"
    }
  ],
  "r": 1,
  "H": 393325,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.MEL.IStringLocalizer$$(TResourceSource), $.$mela.MEL.IStringLocalizer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.StringLocalizer<${TResourceSource?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}StringLocalizer$${TResourceSource?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393325)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib"));
})();
//--TRIMMABLE-BOUNDARY-END(109)
