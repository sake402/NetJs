
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization.Abstractions", 
    {"h":34435,"f":"Microsoft.Extensions.Localization.Abstractions","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Abstractions of application localization services.\nCommonly used types:\nMicrosoft.Extensions.Localization.IStringLocalizer\nMicrosoft.Extensions.Localization.IStringLocalizer\u003CT\u003E","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft .NET Extensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Localization.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer", ($self) => class IStringLocalizer
        {
            static $h = 165507;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":362115,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":8590100099,"f":50331905},"n":"Item","o":"Microsoft$Extensions$Localization$IStringLocalizer$Item$1","d":165507,"h":4295132803,"f":2097409},{"p":362115,"i":[{"n":"name","p":1310721},{"n":"arguments","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":{"r":0,"d":0,"h":17180034691,"f":50331905},"n":"Item","o":"Microsoft$Extensions$Localization$IStringLocalizer$Item","d":165507,"h":12885067395,"f":2097409}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","o":"Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings","d":165507,"h":21475001987,"f":16777473}],"h":165507}; }
            static get $fullName() { return `IStringLocalizer`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory", ($self) => class IStringLocalizerFactory
        {
            static $h = 296579;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":165507,"p":[{"n":"resourceSource","p":142475265}],"n":"Create","o":"Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1","d":296579,"h":4295263875,"f":16777473},{"r":165507,"p":[{"n":"baseName","p":1310721},{"n":"location","p":1310721}],"n":"Create","o":"Microsoft$Extensions$Localization$IStringLocalizerFactory$Create","d":296579,"h":8590231171,"f":16777473}],"h":296579}; }
            static get $fullName() { return `IStringLocalizerFactory`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", (/*out*/ T) => $asm.$gt("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", [/*out*/ T], ($self) => class IStringLocalizer$$
        {
            static $h = 231043;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"i":[165507],"g":[T?.$h??1507328],"s":[{"n":"T","f":32}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `IStringLocalizer<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizerExtensions", ($self) => class StringLocalizerExtensions
        {
            static /*LocalizedString */ GetString$1(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name);
            }
            static /*LocalizedString */ GetString(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name, $arguments);
            }
            static /*IEnumerable<LocalizedString> */ GetAllStrings(/*this IStringLocalizer*/ stringLocalizer)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(true);
            }
            static $h = 493187;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":362115,"p":[{"n":"stringLocalizer","p":165507},{"n":"name","p":1310721}],"n":"GetString","o":"@$1","d":493187,"h":4295460483,"f":16777249},{"r":362115,"p":[{"n":"stringLocalizer","p":165507},{"n":"name","p":1310721},{"n":"arguments","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"GetString","d":493187,"h":8590427779,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"stringLocalizer","p":165507}],"n":"GetAllStrings","d":493187,"h":12885395075,"f":16777249}],"h":493187}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StringLocalizerExtensions`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.LocalizedString", ($self) => class LocalizedString extends $.$$.System.Object
        {
            $ctor$3(/*string*/ name, /*string*/ value)
            {
                this.$ctor$2(name, value, false);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound)
            {
                this.$ctor$1(name, value, resourceNotFound, null);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound, /*string?*/ searchedLocation)
            {
                super.$ctor();
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(value, "value");
                    this.Name = name;
                    this.Value = value;
                    this.ResourceNotFound = resourceNotFound;
                    this.SearchedLocation = searchedLocation;
                }
                return this;
            }
            static /*string? */ op_Implicit(/*LocalizedString*/ localizedString)
            {
                return localizedString?.Value ?? null;
            }
            /*string*/ Name = null;
            /*string*/ Value = null;
            /*bool*/ ResourceNotFound = false;
            /*string?*/ SearchedLocation = null;
            static/*conventional*/ /*string */ ToString()
            {
                return this.Value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.Microsoft.Extensions.Localization.LocalizedString.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this.ResourceNotFound = false;
            }
            static $h = 362115;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065133187,"f":50331649},"n":"Name","d":362115,"h":25770165891,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950035075,"f":50331649},"n":"Value","d":362115,"h":38655067779,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55834936963,"f":50331649},"n":"ResourceNotFound","d":362115,"h":51539969667,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":68719838851,"f":50331649},"n":"SearchedLocation","d":362115,"h":64424871555,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":362115,"h":73014806147,"f":16809985}],"c":[{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$3","d":362115,"h":4295329411,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"resourceNotFound","p":262145}],"n":".ctor","o":"$ctor$2","d":362115,"h":8590296707,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"resourceNotFound","p":262145},{"n":"searchedLocation","p":1310721}],"n":".ctor","o":"$ctor$1","d":362115,"h":12885264003,"f":16777217}],"h":362115}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizedString`; }
        });
        
        $asm.$cls("$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            static $h = 99971;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":558723,"c":4295526019,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":99971,"h":4295067267,"f":16777249},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":558723,"c":4295526019,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":99971,"h":8590034563,"f":16777249}],"h":99971}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", (TResourceSource) => $asm.$gt("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", [TResourceSource], ($self) => class StringLocalizer$$ extends $.$$.System.Object
        {
            /*IStringLocalizer*/ _localizer = null;
            $ctor$1(/*IStringLocalizerFactory*/ factory)
            {
                super.$ctor();
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(factory, "factory");
                    this._localizer = factory.Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1(TResourceSource.$type);
                }
                return this;
            }
            /*LocalizedString*/ get_Item$1(/*string*/ name)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name);
            }
            /*LocalizedString*/ get_Item(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name, $arguments);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures)
            {
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(includeParentCultures);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                return this.get_Item$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                return this.GetAllStrings(...arguments);
            }
            static $h = 427651;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":362115,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331777},"n":"Item","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097281},{"p":362115,"i":[{"n":"name","p":1310721},{"n":"arguments","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331777},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097281}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"l":[{"t":165507,"n":"_localizer","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"factory","p":296579}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[$.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource).$h,165507],"g":[TResourceSource?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource), $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `StringLocalizer<${TResourceSource?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 558723;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180427907,"f":50331649},"n":"ParameterName","d":558723,"h":12885460611,"f":2097153}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":558723,"h":4295526019,"f":16777217}],"h":558723,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2048,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))