
//--TRIMMABLE-BOUNDARY-START(102)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization.Abstractions", 
    {
  "h": 102,
  "f": "Microsoft.Extensions.Localization.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 4402118657,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106758145,
      "c": 4401725441,
      "a": [
        {
          "v": "Abstractions of application localization services.\nCommonly used types:\nMicrosoft.Extensions.Localization.IStringLocalizer\nMicrosoft.Extensions.Localization.IStringLocalizer\u003CT\u003E",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "Microsoft .NET Extensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Localization.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131174)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer", ($self) => class IStringLocalizer
        {
            //--TRIMMABLE-BOUNDARY-START(25769934950)
            //--TRIMMABLE-BOUNDARY-END(25769934950)
            
            //--TRIMMABLE-BOUNDARY-START(30064902246)
            //--TRIMMABLE-BOUNDARY-END(30064902246)
            
            static $h = 131174;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769934950),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590065766,
        "f": 50331905
      },
      "n": "Item",
      "o": "Microsoft$Extensions$Localization$IStringLocalizer$Item$1",
      "d": 131174,
      "h": 25769934950,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25769934950),
//--TRIMMABLE-BOUNDARY-START(30064902246),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000358,
        "f": 50331905
      },
      "n": "Item",
      "o": "Microsoft$Extensions$Localization$IStringLocalizer$Item",
      "d": 131174,
      "h": 30064902246,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30064902246)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474967654),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "o": "Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings",
      "d": 131174,
      "h": 21474967654,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21474967654)
  ],
  "h": 131174
}; }
            static get $fullName() { return `IStringLocalizer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131174)
        
        
        //--TRIMMABLE-BOUNDARY-START(262246)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory", ($self) => class IStringLocalizerFactory
        {
            static $h = 262246;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229542),
    {
      "r": 131174,
      "p": [
        {
          "n": "resourceSource",
          "p": 187629569
        }
      ],
      "n": "Create",
      "o": "Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1",
      "d": 262246,
      "h": 4295229542,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229542),
//--TRIMMABLE-BOUNDARY-START(8590196838),
    {
      "r": 131174,
      "p": [
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "location",
          "p": 1310721
        }
      ],
      "n": "Create",
      "o": "Microsoft$Extensions$Localization$IStringLocalizerFactory$Create",
      "d": 262246,
      "h": 8590196838,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590196838)
  ],
  "h": 262246
}; }
            static get $fullName() { return `IStringLocalizerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262246)
        
        
        //--TRIMMABLE-BOUNDARY-START(196710)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", (/*out*/ T) => $asm.$gt("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", [/*out*/ T], ($self) => class IStringLocalizer$$
        {
            static $h = 196710;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "i": [131174
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 32
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `IStringLocalizer<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196710)
        
        
        //--TRIMMABLE-BOUNDARY-START(458854)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizerExtensions", ($self) => class StringLocalizerExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590393446)
            static /*LocalizedString */ GetString$1(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name);
            }
            //--TRIMMABLE-BOUNDARY-END(8590393446)
            
            //--TRIMMABLE-BOUNDARY-START(12885360742)
            static /*LocalizedString */ GetString(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name, /*params object[]*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360742)
            
            //--TRIMMABLE-BOUNDARY-START(4295426150)
            static /*IEnumerable<LocalizedString> */ GetAllStrings(/*this IStringLocalizer*/ stringLocalizer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(true);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426150)
            
            static $h = 458854;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393446),
    {
      "r": 327782,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131174
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetString",
      "o": "@$1",
      "d": 458854,
      "h": 8590393446,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393446),
//--TRIMMABLE-BOUNDARY-START(12885360742),
    {
      "r": 327782,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131174
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "GetString",
      "d": 458854,
      "h": 12885360742,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885360742),
//--TRIMMABLE-BOUNDARY-START(4295426150),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,
      "p": [
        {
          "n": "stringLocalizer",
          "p": 131174
        }
      ],
      "n": "GetAllStrings",
      "d": 458854,
      "h": 4295426150,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426150)
  ],
  "h": 458854
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `StringLocalizerExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458854)
        
        
        //--TRIMMABLE-BOUNDARY-START(65638)
        $asm.$cls("$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032934)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032934)
            
            //--TRIMMABLE-BOUNDARY-START(8590000230)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000230)
            
            static $h = 65638;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032934),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 524390,
              "c": 4295491686,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 65638,
      "h": 4295032934,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032934),
//--TRIMMABLE-BOUNDARY-START(8590000230),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 524390,
              "c": 4295491686,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 65638,
      "h": 8590000230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000230)
  ],
  "h": 65638
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65638)
        
        
        //--TRIMMABLE-BOUNDARY-START(327782)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.LocalizedString", ($self) => class LocalizedString extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295078)
            $ctor$3(/*string*/ name, /*string*/ value)
            {
                this.$ctor$2(name, value, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295078);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295078)
            
            //--TRIMMABLE-BOUNDARY-START(8590262374)
            $ctor$2(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound)
            {
                this.$ctor$1(name, value, resourceNotFound, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262374);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262374)
            
            //--TRIMMABLE-BOUNDARY-START(12885229670)
            $ctor$1(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound, /*string?*/ searchedLocation)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229670);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(value, "value");
                    this.Name = name;
                    this.Value = value;
                    this.ResourceNotFound = resourceNotFound;
                    this.SearchedLocation = searchedLocation;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229670)
            
            //--TRIMMABLE-BOUNDARY-START(73014771814)
            static /*string? */ op_Implicit(/*LocalizedString*/ localizedString)
            {
                return localizedString?.Value ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(73014771814)
            
            //--TRIMMABLE-BOUNDARY-START(68719804518)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(68719804518)
            
            //--TRIMMABLE-BOUNDARY-START(90194640998)
            /*string*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(90194640998)
            
            //--TRIMMABLE-BOUNDARY-START(77309739110)
            /*bool*/ ResourceNotFound = false;
            //--TRIMMABLE-BOUNDARY-END(77309739110)
            
            //--TRIMMABLE-BOUNDARY-START(81604706406)
            /*string?*/ SearchedLocation = null;
            //--TRIMMABLE-BOUNDARY-END(81604706406)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85899673702, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899673702);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Value;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.Microsoft.Extensions.Localization.LocalizedString.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85899673702, 330712612865)
            
            static $h = 327782;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719804518),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033446,
        "f": 50331649
      },
      "n": "Name",
      "d": 327782,
      "h": 68719804518,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719804518),
//--TRIMMABLE-BOUNDARY-START(90194640998),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837222,
        "f": 50331649
      },
      "n": "Value",
      "d": 327782,
      "h": 90194640998,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640998),
//--TRIMMABLE-BOUNDARY-START(77309739110),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244968038,
        "f": 50331649
      },
      "n": "ResourceNotFound",
      "d": 327782,
      "h": 77309739110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309739110),
//--TRIMMABLE-BOUNDARY-START(81604706406),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902630,
        "f": 50331649
      },
      "n": "SearchedLocation",
      "d": 327782,
      "h": 81604706406,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604706406)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 85899673702, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327782,
      "h": 85899673702,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85899673702, 330712612865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295078),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327782,
      "h": 4295295078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295078),
//--TRIMMABLE-BOUNDARY-START(8590262374),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "resourceNotFound",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327782,
      "h": 8590262374,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262374),
//--TRIMMABLE-BOUNDARY-START(12885229670),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        },
        {
          "n": "resourceNotFound",
          "p": 262145
        },
        {
          "n": "searchedLocation",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327782,
      "h": 12885229670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229670)
  ],
  "h": 327782
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizedString`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327782)
        
        
        //--TRIMMABLE-BOUNDARY-START(393318)
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", (TResourceSource) => $asm.$gt("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", [TResourceSource], ($self) => class StringLocalizer$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360614)
            /*IStringLocalizer*/ _localizer = null;
            //--TRIMMABLE-BOUNDARY-END(4295360614)
            
            //--TRIMMABLE-BOUNDARY-START(8590327910)
            $ctor$1(/*IStringLocalizerFactory*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(factory, "factory");
                    this._localizer = factory.Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1(TResourceSource.$type);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327910)
            
            //--TRIMMABLE-BOUNDARY-START(34360131686)
            /*LocalizedString*/ get_Item$1(/*string*/ name)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name);
            }
            //--TRIMMABLE-BOUNDARY-END(34360131686)
            
            //--TRIMMABLE-BOUNDARY-START(38655098982)
            /*LocalizedString*/ get_Item(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name, $arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38655098982)
            
            //--TRIMMABLE-BOUNDARY-START(30065164390)
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065164390);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(includeParentCultures);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164390)
            
            //--TRIMMABLE-BOUNDARY-START(8590065766)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065766)
            
            //--TRIMMABLE-BOUNDARY-START(17180000358)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000358)
            
            //--TRIMMABLE-BOUNDARY-START(21474967654)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllStrings(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967654)
            
            static $h = 393318;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360131686),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331777
      },
      "n": "Item",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(34360131686),
//--TRIMMABLE-BOUNDARY-START(38655098982),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331777
      },
      "n": "Item",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(38655098982)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065164390),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164390)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360614),
    {
      "t": 131174,
      "n": "_localizer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327910),
    {
      "p": [
        {
          "n": "factory",
          "p": 262246
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327910)
  ],
  "i": [$.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource).$h,131174
  ],
  "g": [TResourceSource?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource), $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `StringLocalizer<${TResourceSource?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393318)
        
        
        //--TRIMMABLE-BOUNDARY-START(524390)
        $asm.$cls("$mela.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295491686)
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterName = parameterName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491686)
            
            //--TRIMMABLE-BOUNDARY-START(21475360870)
            /*string*/ ParameterName = null;
            //--TRIMMABLE-BOUNDARY-END(21475360870)
            
            static $h = 524390;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45219841,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360870),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393574,
        "f": 50331649
      },
      "n": "ParameterName",
      "d": 524390,
      "h": 21475360870,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360870)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491686),
    {
      "p": [
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524390,
      "h": 4295491686,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491686)
  ],
  "h": 524390,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 2048,
          "t": 45285377
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524390)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(102)
