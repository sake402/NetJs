
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization.Abstractions", 
    {"h":61588,"f":"Microsoft.Extensions.Localization.Abstractions","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":74448897,"c":4369416193,"a":[{"v":"IsTrimmable","t":1310721},{"v":"True","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Abstractions of application localization services.\nCommonly used types:\nMicrosoft.Extensions.Localization.IStringLocalizer\nMicrosoft.Extensions.Localization.IStringLocalizer\u003CT\u003E","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft .NET Extensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Localization.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory", ($self) => class IStringLocalizerFactory
        {
            static $h = 323732;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":192660,"p":[{"n":"resourceSource","p":142606337}],"n":"Create","o":"Microsoft$Extensions$Localization$IStringLocalizerFactory$Create","d":323732,"h":4295291028,"f":257},{"r":192660,"p":[{"n":"baseName","p":1310721},{"n":"location","p":1310721}],"n":"Create","o":"Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1","d":323732,"h":8590258324,"f":257}],"h":323732}; }
            static get $fullName() { return `IStringLocalizerFactory`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer", ($self) => class IStringLocalizer
        {
            static $h = 192660;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":389268,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":8590127252,"f":257},"n":"Item","o":"Microsoft$Extensions$Localization$IStringLocalizer$Item","d":192660,"h":4295159956,"f":257},{"p":389268,"i":[{"n":"name","p":1310721},{"n":"arguments","p":0,"f":16}],"g":{"r":0,"d":0,"h":17180061844,"f":257},"n":"Item","o":"Microsoft$Extensions$Localization$IStringLocalizer$Item$1","d":192660,"h":12885094548,"f":257}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","o":"Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings","d":192660,"h":21475029140,"f":257}],"h":192660}; }
            static get $fullName() { return `IStringLocalizer`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", (/*out*/ T) => $asm.$gt("$mela.Microsoft.Extensions.Localization.IStringLocalizer<>", [/*out*/ T], ($self) => class IStringLocalizer$$
        {
            static $h = 258196;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"i":[192660],"g":[T?.$h??1507328],"s":[{"n":"T","f":32}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `IStringLocalizer<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizerExtensions", ($self) => class StringLocalizerExtensions
        {
            static /*LocalizedString */ GetString(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name);
            }
            static /*LocalizedString */ GetString$1(/*this IStringLocalizer*/ stringLocalizer, /*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name, $arguments);
            }
            static /*IEnumerable<LocalizedString> */ GetAllStrings(/*this IStringLocalizer*/ stringLocalizer)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(stringLocalizer, "stringLocalizer");
                return stringLocalizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(true);
            }
            static $h = 520340;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":389268,"p":[{"n":"stringLocalizer","p":192660},{"n":"name","p":1310721}],"n":"GetString","d":520340,"h":4295487636,"f":33},{"r":389268,"p":[{"n":"stringLocalizer","p":192660},{"n":"name","p":1310721},{"n":"arguments","p":0,"f":16}],"n":"GetString","o":"@$1","d":520340,"h":8590454932,"f":33},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"stringLocalizer","p":192660}],"n":"GetAllStrings","d":520340,"h":12885422228,"f":33}],"h":520340}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `StringLocalizerExtensions`; }
        });
        
        $asm.$cls("$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
                else if (argument.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13("Must not be null or empty", paramName);
                }
            }
            static /*void */ Throw(/*string?*/ paramName)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16(paramName);
            }
            static $h = 127124;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":585876,"c":4295553172,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":127124,"h":4295094420,"f":33},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":585876,"c":4295553172,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":127124,"h":8590061716,"f":33},{"r":65537,"p":[{"n":"paramName","p":1310721}],"n":"Throw","d":127124,"h":12885029012,"f":40}],"h":127124}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.LocalizedString", ($self) => class LocalizedString extends $.$spc.System.Object
        {
            $ctor$1(/*string*/ name, /*string*/ value)
            {
                this.$ctor$2(name, value, false);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound)
            {
                this.$ctor$3(name, value, resourceNotFound, null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*string*/ value, /*bool*/ resourceNotFound, /*string?*/ searchedLocation)
            {
                super.$ctor();
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(value, "value");
                    this.Name = name;
                    this.Value = value;
                    this.ResourceNotFound = resourceNotFound;
                    this.SearchedLocation = searchedLocation;
                }
                return this;
            }
            static /*string? */ op_Implicit(/*LocalizedString*/ localizedString)
            {
                return localizedString?.Value;
            }
            /*string*/ Name = null;
            /*string*/ Value = null;
            /*bool*/ ResourceNotFound = false;
            /*string?*/ SearchedLocation = null;
            static/*conventional*/ /*string */ ToString()
            {
                return this.Value;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.Microsoft.Extensions.Localization.LocalizedString.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this.ResourceNotFound = false;
            }
            static $h = 389268;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065160340,"f":1},"n":"Name","d":389268,"h":25770193044,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950062228,"f":1},"n":"Value","d":389268,"h":38655094932,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834964116,"f":1},"n":"ResourceNotFound","d":389268,"h":51539996820,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719866004,"f":1},"n":"SearchedLocation","d":389268,"h":64424898708,"f":1}],"m":[{"r":1310721,"n":"ToString","d":389268,"h":73014833300,"f":32769}],"c":[{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$1","d":389268,"h":4295356564,"f":1},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"resourceNotFound","p":262145}],"n":".ctor","o":"$ctor$2","d":389268,"h":8590323860,"f":1},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"resourceNotFound","p":262145},{"n":"searchedLocation","p":1310721}],"n":".ctor","o":"$ctor$3","d":389268,"h":12885291156,"f":1}],"h":389268}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LocalizedString`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", (TResourceSource) => $asm.$gt("$mela.Microsoft.Extensions.Localization.StringLocalizer<>", [TResourceSource], ($self) => class StringLocalizer$$ extends $.$spc.System.Object
        {
            /*IStringLocalizer*/ _localizer = null;
            $ctor$1(/*IStringLocalizerFactory*/ factory)
            {
                super.$ctor();
                {
                    $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(factory, "factory");
                    this._localizer = factory.Microsoft$Extensions$Localization$IStringLocalizerFactory$Create(TResourceSource.$type);
                }
                return this;
            }
            /*LocalizedString*/ get_Item(/*string*/ name)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item(name);
            }
            /*LocalizedString*/ get_Item$1(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mela.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1(name, $arguments);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures)
            {
                return this._localizer.Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings(includeParentCultures);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                return this.get_Item$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                return this.GetAllStrings(...arguments);
            }
            static $h = 454804;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":389268,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":129},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":129},{"p":389268,"i":[{"n":"name","p":1310721},{"n":"arguments","p":0,"f":16}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":129},"n":"Item","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":129}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"l":[{"t":192660,"n":"_localizer","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"factory","p":323732}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[$.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource).$h,192660],"g":[TResourceSource?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$(TResourceSource), $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `StringLocalizer<${TResourceSource?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 585876;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180455060,"f":1},"n":"ParameterName","d":585876,"h":12885487764,"f":1}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":585876,"h":4295553172,"f":1}],"h":585876,"a":[{"t":14680065,"c":21489516545,"a":[{"v":2048,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))