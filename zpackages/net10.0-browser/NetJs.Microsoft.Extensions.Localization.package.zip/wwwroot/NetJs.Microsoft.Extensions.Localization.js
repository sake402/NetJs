
(function ($global, $, $spc, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mela, $sttp, $sdd, $mela, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization", 
    {"h":43785,"f":"Microsoft.Extensions.Localization","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Application localization services and default implementation based on ResourceManager to load localized assembly resources.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft .NET Extensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Localization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.Localization.Tests","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceStringProvider", ($self) => class IResourceStringProvider
        {
            static $h = 437001;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"p":[{"n":"culture","p":51183617},{"n":"throwOnMissing","p":262145}],"n":"GetAllResourceStrings","o":"Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings","d":437001,"h":4295404297,"f":257}],"h":437001}; }
            static get $fullName() { return `IResourceStringProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceNamesCache", ($self) => class IResourceNamesCache
        {
            static $h = 371465;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"p":[{"n":"name","p":1310721},{"n":"valueFactory","p":$.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.Collections.Generic.IList$$($.$spc.System.String)).$h}],"n":"GetOrAdd","o":"Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd","d":371465,"h":4295338761,"f":257}],"h":371465}; }
            static get $fullName() { return `IResourceNamesCache`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.LocalizationOptions", ($self) => class LocalizationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string*/ ResourcesPath = null;
            //default member initializer
            constructor()
            {
                super();
                this.ResourcesPath = $.$spc.System.String.Empty;
            }
            static $h = 502537;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180371721,"f":1},"s":{"r":0,"d":0,"h":21475339017,"f":1},"n":"ResourcesPath","d":502537,"h":12885404425,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":502537,"h":4295469833,"f":1}],"h":502537}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LocalizationOptions`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.AssemblyWrapper", ($self) => class AssemblyWrapper extends $.$spc.System.Object
        {
            $ctor$1(/*Assembly*/ assembly)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(assembly, "assembly");
                    this.Assembly = assembly;
                }
                return this;
            }
            /*Assembly*/ Assembly = null;
            /*string */ get FullName()
            {
                return this.Assembly.FullName;
            }
            /*Stream? */ GetManifestResourceStream(/*string*/ name)
            {
                return this.Assembly.GetManifestResourceStream(name);
            }
            static $h = 305929;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":73465857,"g":{"r":0,"d":0,"h":17180175113,"f":1},"n":"Assembly","d":305929,"h":12885207817,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":25770109705,"f":129},"n":"FullName","d":305929,"h":21475142409,"f":129}],"m":[{"r":62193665,"p":[{"n":"name","p":1310721}],"n":"GetManifestResourceStream","d":305929,"h":30065077001,"f":129}],"c":[{"p":[{"n":"assembly","p":73465857}],"n":".ctor","o":"$ctor$1","d":305929,"h":4295273225,"f":1}],"h":305929}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `AssemblyWrapper`; }
        });
        
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                if (argument === null)
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.Throw(paramName);
                }
                else if (argument.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13("Must not be null or empty", paramName);
                }
            }
            static /*void */ Throw(/*string?*/ paramName)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16(paramName);
            }
            static $h = 109321;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1092361,"c":4296059657,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":109321,"h":4295076617,"f":33},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1092361,"c":4296059657,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":109321,"h":8590043913,"f":33},{"r":65537,"p":[{"n":"paramName","p":1310721}],"n":"Throw","d":109321,"h":12885011209,"f":40}],"h":109321}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions", ($self) => class LocalizationServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddLocalization(/*this IServiceCollection*/ services)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices(services);
                return services;
            }
            static /*IServiceCollection */ AddLocalization$1(/*this IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(setupAction, "setupAction");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services, setupAction);
                return services;
            }
            static /*void */ AddLocalizationServices(/*IServiceCollection*/ services)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$4($.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(services, $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$().$type, $.$mela.Microsoft.Extensions.Localization.StringLocalizer$$().$type);
            }
            static /*void */ AddLocalizationServices$1(/*IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices(services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Localization.LocalizationOptions, services, setupAction);
            }
            static $h = 240393;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddLocalization","d":240393,"h":4295207689,"f":33},{"r":786435,"p":[{"n":"services","p":786435},{"n":"setupAction","p":$.$spc.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h}],"n":"AddLocalization","o":"@$1","d":240393,"h":8590174985,"f":33},{"r":65537,"p":[{"n":"services","p":786435}],"n":"AddLocalizationServices","d":240393,"h":12885142281,"f":40},{"r":65537,"p":[{"n":"services","p":786435},{"n":"setupAction","p":$.$spc.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h}],"n":"AddLocalizationServices","o":"@$1","d":240393,"h":17180109577,"f":40}],"h":240393}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `LocalizationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper", ($self) => class ArgumentThrowHelper
        {
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                if (argument === null || $.$spc.System.String.op_Equality(argument, $.$spc.System.String.Empty))
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(argument, "argument");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.Throw(paramName);
                }
            }
            static /*void */ Throw(/*string?*/ paramName)
            {
                throw new $.$spc.System.ArgumentException().$ctor$13("The value cannot be an empty string.", paramName);
            }
            static /*void */ ThrowIfNullOrWhiteSpace(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(argument, "argument");
                if ($.$spc.System.String.IsNullOrWhiteSpace(argument))
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowNullOrWhiteSpaceException(paramName);
                }
            }
            static /*void */ ThrowNullOrWhiteSpaceException(/*string?*/ paramName)
            {
                throw new $.$spc.System.ArgumentException().$ctor$13("The value cannot be an empty or whitespace string.", paramName);
            }
            static $h = 174857;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1092361,"c":4296059657,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":174857,"h":4295142153,"f":33},{"r":65537,"p":[{"n":"paramName","p":1310721}],"n":"Throw","d":174857,"h":8590109449,"f":40},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1092361,"c":4296059657,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrWhiteSpace","d":174857,"h":12885076745,"f":33},{"r":65537,"p":[{"n":"paramName","p":1310721}],"n":"ThrowNullOrWhiteSpaceException","d":174857,"h":17180044041,"f":40}],"h":174857}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ArgumentThrowHelper`; }
        });
        
        $asm.$cls("$mel.Resources", ($self) => class Resources
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mel.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Localization", $.$mel.Resources.$type.Assembly);
                    $.$mel.Resources.s_resourceManager = temp;
                }
                return $.$mel.Resources.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mel.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mel.Resources.resourceCulture = value;
            }
            static /*string */ get Localization_MissingManifest()
            {
                return "The manifest '{0}' was not found.";
            }
            static /*string */ FormatLocalization_MissingManifest(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The manifest '{0}' was not found.", arg1);
            }
            static /*string */ get Localization_MissingManifest_Parent()
            {
                return "No manifests exist for the current culture.";
            }
            static /*string */ get Localization_TypeMustHaveTypeName()
            {
                return "Type '{0}' must have a non-null type name.";
            }
            static /*string */ FormatLocalization_TypeMustHaveTypeName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Type '{0}' must have a non-null type name.", arg1);
            }
            static $h = 1026825;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":85524481,"g":{"r":0,"d":0,"h":17180896009,"f":40},"n":"ResourceManager","d":1026825,"h":12885928713,"f":40,"a":[{"t":33226753,"c":4328194049,"a":[{"v":2,"t":33292289}]}]},{"p":51183617,"g":{"r":0,"d":0,"h":25770830601,"f":40},"s":{"r":0,"d":0,"h":30065797897,"f":40},"n":"Culture","d":1026825,"h":21475863305,"f":40,"a":[{"t":33226753,"c":4328194049,"a":[{"v":2,"t":33292289}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655732489,"f":40},"n":"Localization_MissingManifest","d":1026825,"h":34360765193,"f":40},{"p":1310721,"g":{"r":0,"d":0,"h":51540634377,"f":40},"n":"Localization_MissingManifest_Parent","d":1026825,"h":47245667081,"f":40},{"p":1310721,"g":{"r":0,"d":0,"h":60130568969,"f":40},"n":"Localization_TypeMustHaveTypeName","d":1026825,"h":55835601673,"f":40}],"m":[{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatLocalization_MissingManifest","d":1026825,"h":42950699785,"f":40},{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatLocalization_TypeMustHaveTypeName","d":1026825,"h":64425536265,"f":40}],"l":[{"t":85524481,"n":"s_resourceManager","d":1026825,"h":4295994121,"f":34},{"t":51183617,"n":"resourceCulture","d":1026825,"h":8590961417,"f":34}],"h":1026825,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"System.Resources.Tools.StronglyTypedResourceBuilder","t":1310721},{"v":"17.0.0.0","t":1310721}]},{"t":37748737,"c":4332716033},{"t":88539137,"c":4383506433}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceNamesCache", ($self) => class ResourceNamesCache extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<string, IList<string>?>*/ _cache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IList<string>? */ GetOrAdd(/*string*/ name, /*Func<string, IList<string>?>*/ valueFactory)
            {
                return this._cache.GetOrAdd(name, valueFactory);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceNamesCache.GetOrAdd(string, System.Func<string, System.Collections.Generic.IList<string>?>)
            Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd()
            {
                return this.GetOrAdd(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.IList$$($.$spc.System.String)))().$ctor$1();
            }
            static $h = 895753;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"p":[{"n":"name","p":1310721},{"n":"valueFactory","p":$.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.Collections.Generic.IList$$($.$spc.System.String)).$h}],"n":"GetOrAdd","d":895753,"h":12885797641,"f":1}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.IList$$($.$spc.System.String)).$h,"n":"_cache","d":895753,"h":4295863049,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":895753,"h":8590830345,"f":1}],"i":[371465],"h":895753}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceNamesCache ]; }
            static get $fullName() { return `ResourceNamesCache`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer", ($self) => class ResourceManagerStringLocalizer extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<string, object?>*/ _missingManifestCache = null;
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ResourceManager*/ _resourceManager = null;
            /*IResourceStringProvider*/ _resourceStringProvider = null;
            /*string*/ _resourceBaseName = null;
            /*ILogger*/ _logger = null;
            $ctor$1(/*ResourceManager*/ resourceManager, /*Assembly*/ resourceAssembly, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$2(resourceManager, new $.$mel.Microsoft.Extensions.Localization.AssemblyWrapper().$ctor$1(resourceAssembly), baseName, resourceNamesCache, logger);
                {
                }
                return this;
            }
            $ctor$2(/*ResourceManager*/ resourceManager, /*AssemblyWrapper*/ resourceAssemblyWrapper, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$3(resourceManager, new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider().$ctor$1(resourceNamesCache, resourceManager, resourceAssemblyWrapper.Assembly, baseName), baseName, resourceNamesCache, logger);
                {
                }
                return this;
            }
            $ctor$3(/*ResourceManager*/ resourceManager, /*IResourceStringProvider*/ resourceStringProvider, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceManager, "resourceManager");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceStringProvider, "resourceStringProvider");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceNamesCache, "resourceNamesCache");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    this._resourceStringProvider = resourceStringProvider;
                    this._resourceManager = resourceManager;
                    this._resourceBaseName = baseName;
                    this._resourceNamesCache = resourceNamesCache;
                    this._logger = logger;
                }
                return this;
            }
            /*LocalizedString*/ get_Item(/*string*/ name)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value = this.GetStringSafely(name, null);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$3(name, value ?? name, $.$spc.System.String.op_Equality(value, null), this._resourceBaseName);
            }
            /*LocalizedString*/ get_Item$1(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let format = this.GetStringSafely(name, null);
                /*var*/ let value = $.$spc.System.String.Format$8($.$spc.System.Globalization.CultureInfo.CurrentCulture, format ?? name, $arguments);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$3(name, value, $.$spc.System.String.op_Equality(format, null), this._resourceBaseName);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures)
            {
                return this.GetAllStrings$1(includeParentCultures, $.$spc.System.Globalization.CultureInfo.CurrentUICulture);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings$1(/*bool*/ includeParentCultures, /*CultureInfo*/ culture)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(culture, "culture");
                    /*var*/ let resourceNames = includeParentCultures ? this.GetResourceNamesFromCultureHierarchy(culture) : this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(culture, true);
                    var $en3 = resourceNames ?? $.$sl.System.Linq.Enumerable.Empty($.$spc.System.String).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var name = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*var*/ let value = this.GetStringSafely(name, culture);
                            yield new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$3(name, value ?? name, $.$spc.System.String.op_Equality(value, null), this._resourceBaseName);
                        }
                    }
                }.bind(this));
            }
            /*string? */ GetStringSafely(/*string*/ name, /*CultureInfo?*/ culture)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let keyCulture = culture ?? $.$spc.System.Globalization.CultureInfo.CurrentUICulture;
                /*var*/ let cacheKey = `name=${name}&culture=${keyCulture.Name}`;
                $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.SearchedLocation(this._logger, name, this._resourceBaseName, keyCulture);
                if (this._missingManifestCache.ContainsKey(cacheKey))
                {
                    return null;
                }
                try
                {
                    return this._resourceManager.GetString$1(name, culture);
                }
                catch($e)
                {
                    this._missingManifestCache.TryAdd(cacheKey, null);
                    return null;
                }
            }
            /*IEnumerable<string> */ GetResourceNamesFromCultureHierarchy(/*CultureInfo*/ startingCulture)
            {
                /*var*/ let currentCulture = startingCulture;
                /*var*/ let resourceNames = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$1();
                /*var*/ let hasAnyCultures = false;
                while(true)
                {
                    /*var*/ let cultureResourceNames = this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(currentCulture, false);
                    if (cultureResourceNames !== null)
                    {
                        var $en4 = cultureResourceNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var resourceName = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                resourceNames.Add(resourceName);
                            }
                        }
                        hasAnyCultures = true;
                    }
                    if (currentCulture === currentCulture.Parent)
                    {
                        break;
                    }
                    currentCulture = currentCulture.Parent;
                }
                if (!hasAnyCultures)
                {
                    throw new $.$spc.System.Resources.MissingManifestResourceException().$ctor$10($.$mel.Resources.Localization_MissingManifest_Parent);
                }
                return resourceNames;
            }
            static $_Log;
            static get Log()
            {
                let $cls = $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer;
                return $cls.$_Log ??= $asm.$ncls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log", ($self) => class Log
                {
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.String, global::System.Globalization.CultureInfo, global::System.Exception?>*/ static __SearchedLocationCallback = null;
                    static /*void */ SearchedLocation(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ key, /*global::System.String*/ locationSearched, /*global::System.Globalization.CultureInfo*/ culture)
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.__SearchedLocationCallback.Invoke(logger, key, locationSearched, culture, null);
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.__SearchedLocationCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$7($.$spc.System.String, $.$spc.System.String, $.$spc.System.Globalization.CultureInfo, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(1, "SearchedLocation"), "ResourceManagerStringLocalizer searched for '{Key}' in '{LocationSearched}' with culture '{Culture}'.", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                        }
                    }
                    static $h = 699145;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525},{"n":"key","p":1310721},{"n":"locationSearched","p":1310721},{"n":"culture","p":51183617}],"n":"SearchedLocation","d":699145,"h":4295666441,"f":33,"a":[{"t":2228245,"c":8592162837,"a":[{"v":1,"t":655361},{"v":1,"t":2293781},{"v":"ResourceManagerStringLocalizer searched for \u0027{Key}\u0027 in \u0027{LocationSearched}\u0027 with culture \u0027{Culture}\u0027.","t":1310721}],"n":[{"n":"EventName","v":"SearchedLocation","t":1310721}]},{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"l":[{"t":$.$spc.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.String, $.$spc.System.String, $.$spc.System.Globalization.CultureInfo, $.$spc.System.Exception).$h,"n":"__SearchedLocationCallback","d":699145,"h":8590633737,"f":34,"a":[{"t":23527425,"c":12908429313,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"d":633609,"h":699145}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `ResourceManagerStringLocalizer.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                return this.get_Item$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                return this.GetAllStrings(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._missingManifestCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$1();
            }
            static $h = 633609;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":367838,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":47245273865,"f":129},"n":"Item","o":"@$2","d":633609,"h":42950306569,"f":129},{"p":367838,"i":[{"n":"name","p":1310721},{"n":"arguments","p":0,"f":16}],"g":{"r":0,"d":0,"h":55835208457,"f":129},"n":"Item","o":"@$3","d":633609,"h":51540241161,"f":129}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","d":633609,"h":60130175753,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145},{"n":"culture","p":51183617}],"n":"GetAllStrings","o":"@$1","d":633609,"h":64425143049,"f":4},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"culture","p":51183617}],"n":"GetStringSafely","d":633609,"h":68720110345,"f":4},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"p":[{"n":"startingCulture","p":51183617}],"n":"GetResourceNamesFromCultureHierarchy","d":633609,"h":73015077641,"f":2}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"n":"_missingManifestCache","d":633609,"h":4295600905,"f":2},{"t":371465,"n":"_resourceNamesCache","d":633609,"h":8590568201,"f":2},{"t":85524481,"n":"_resourceManager","d":633609,"h":12885535497,"f":2},{"t":437001,"n":"_resourceStringProvider","d":633609,"h":17180502793,"f":2},{"t":1310721,"n":"_resourceBaseName","d":633609,"h":21475470089,"f":2},{"t":917525,"n":"_logger","d":633609,"h":25770437385,"f":2}],"c":[{"p":[{"n":"resourceManager","p":85524481},{"n":"resourceAssembly","p":73465857},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":371465},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$1","d":633609,"h":30065404681,"f":1},{"p":[{"n":"resourceManager","p":85524481},{"n":"resourceAssemblyWrapper","p":305929},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":371465},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$2","d":633609,"h":34360371977,"f":8},{"p":[{"n":"resourceManager","p":85524481},{"n":"resourceStringProvider","p":437001},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":371465},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$3","d":633609,"h":38655339273,"f":8}],"i":[171230],"j":[699145],"h":633609}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `ResourceManagerStringLocalizer`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider", ($self) => class ResourceManagerStringProvider extends $.$spc.System.Object
        {
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ResourceManager*/ _resourceManager = null;
            /*Assembly*/ _assembly = null;
            /*string*/ _resourceBaseName = null;
            $ctor$1(/*IResourceNamesCache*/ resourceCache, /*ResourceManager*/ resourceManager, /*Assembly*/ assembly, /*string*/ baseName)
            {
                super.$ctor();
                {
                    this._resourceManager = resourceManager;
                    this._resourceNamesCache = resourceCache;
                    this._assembly = assembly;
                    this._resourceBaseName = baseName;
                }
                return this;
            }
            /*string */ GetResourceCacheKey(/*CultureInfo*/ culture)
            {
                /*var*/ let resourceName = this._resourceManager.BaseName;
                return `Culture=${culture.Name};resourceName=${resourceName};Assembly=${this._assembly.FullName}`;
            }
            /*string */ GetResourceName(/*CultureInfo*/ culture)
            {
                /*var*/ let resourceStreamName = this._resourceBaseName;
                if (!$.$spc.System.String.IsNullOrEmpty(culture.Name))
                {
                    resourceStreamName += "." + culture.Name;
                }
                resourceStreamName += ".resources";
                return resourceStreamName;
            }
            /*IList<string>? */ GetAllResourceStrings(/*CultureInfo*/ culture, /*bool*/ throwOnMissing)
            {
                /*var*/ let cacheKey = this.GetResourceCacheKey(culture);
                return this._resourceNamesCache.Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd(cacheKey, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.Collections.Generic.IList$$($.$spc.System.String)))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let resourceSet = this._resourceManager.GetResourceSet(culture, true, false);
                    if (resourceSet === null)
                    {
                        if (throwOnMissing)
                        {
                            throw new $.$spc.System.Resources.MissingManifestResourceException().$ctor$10($.$mel.Resources.FormatLocalization_MissingManifest(this.GetResourceName(culture)));
                        }
                        else 
                        {
                            return null;
                        }
                    }
                    /*var*/ let names = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    var $en3 = resourceSet.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            let key;
                            if ($.$is((entry?.Key ?? null), $.$spc.System.String, { set $v(v){ key = v; } }))
                            {
                                names.Add(key);
                            }
                        }
                    }
                    return names;
                }, {"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"p":[{"n":"_","p":1310721}],"n":"","d":830217,"h":0,"f":1048578}));
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceStringProvider.GetAllResourceStrings(System.Globalization.CultureInfo, bool)
            Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings()
            {
                return this.GetAllResourceStrings(...arguments);
            }
            static $h = 830217;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"culture","p":51183617}],"n":"GetResourceCacheKey","d":830217,"h":25770633993,"f":2},{"r":1310721,"p":[{"n":"culture","p":51183617}],"n":"GetResourceName","d":830217,"h":30065601289,"f":2},{"r":$.$spc.System.Collections.Generic.IList$$($.$spc.System.String).$h,"p":[{"n":"culture","p":51183617},{"n":"throwOnMissing","p":262145}],"n":"GetAllResourceStrings","d":830217,"h":34360568585,"f":1}],"l":[{"t":371465,"n":"_resourceNamesCache","d":830217,"h":4295797513,"f":2},{"t":85524481,"n":"_resourceManager","d":830217,"h":8590764809,"f":2},{"t":73465857,"n":"_assembly","d":830217,"h":12885732105,"f":2},{"t":1310721,"n":"_resourceBaseName","d":830217,"h":17180699401,"f":2}],"c":[{"p":[{"n":"resourceCache","p":371465},{"n":"resourceManager","p":85524481},{"n":"assembly","p":73465857},{"n":"baseName","p":1310721}],"n":".ctor","o":"$ctor$1","d":830217,"h":21475666697,"f":1}],"i":[437001],"h":830217}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceStringProvider ]; }
            static get $fullName() { return `ResourceManagerStringProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory", ($self) => class ResourceManagerStringLocalizerFactory extends $.$spc.System.Object
        {
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ConcurrentDictionary<string, ResourceManagerStringLocalizer>*/ _localizerCache = null;
            /*string*/ _resourcesRelativePath = null;
            /*ILoggerFactory*/ _loggerFactory = null;
            $ctor$1(/*IOptions<LocalizationOptions>*/ localizationOptions, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(localizationOptions, "localizationOptions");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(loggerFactory, "loggerFactory");
                    this._resourcesRelativePath = localizationOptions.Microsoft$Extensions$Options$IOptions$$$Value.ResourcesPath ?? $.$spc.System.String.Empty;
                    this._loggerFactory = loggerFactory;
                    if (!$.$spc.System.String.IsNullOrEmpty(this._resourcesRelativePath))
                    {
                        this._resourcesRelativePath = $.$spc.System.String.Replace$2.call($.$spc.System.String.Replace$2.call(this._resourcesRelativePath, $.$spc.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46), $.$spc.System.IO.Path.DirectorySeparatorChar, /*.*/ 46) + ".";
                    }
                }
                return this;
            }
            /*string */ GetResourcePrefix(/*TypeInfo*/ typeInfo)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                return this.GetResourcePrefix$1(typeInfo, this.GetRootNamespace(typeInfo.Assembly), this.GetResourcePath(typeInfo.Assembly));
            }
            /*string */ GetResourcePrefix$1(/*TypeInfo*/ typeInfo, /*string?*/ baseNamespace, /*string?*/ resourcesRelativePath)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(typeInfo.FullName, "typeInfo.FullName");
                if ($.$spc.System.String.IsNullOrEmpty(resourcesRelativePath))
                {
                    return typeInfo.FullName;
                }
                else 
                {
                    return baseNamespace + "." + resourcesRelativePath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(typeInfo.FullName, baseNamespace + ".");
                }
            }
            /*string */ GetResourcePrefix$2(/*string*/ baseResourceName, /*string*/ baseNamespace)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseResourceName, "baseResourceName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                /*var*/ let assemblyName = new $.$spc.System.Reflection.AssemblyName().$ctor$1(baseNamespace);
                /*var*/ let assembly = $.$spc.System.Reflection.Assembly.Load$1(assemblyName);
                /*var*/ let rootNamespace = this.GetRootNamespace(assembly);
                /*var*/ let resourceLocation = this.GetResourcePath(assembly);
                /*var*/ let locationPath = rootNamespace + "." + resourceLocation;
                baseResourceName = locationPath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseResourceName, baseNamespace + ".");
                return baseResourceName;
            }
            /*IStringLocalizer */ Create(/*Type*/ resourceSource)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceSource, "resourceSource");
                /*var*/ let localizer;
                if (!this._localizerCache.TryGetValue(resourceSource.AssemblyQualifiedName, $.$ref(() => localizer, ($v) => localizer = $v, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer)))
                {
                    /*var*/ let typeInfo = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(resourceSource);
                    /*var*/ let baseName = this.GetResourcePrefix(typeInfo);
                    /*var*/ let assembly = typeInfo.Assembly;
                    localizer = this.CreateResourceManagerStringLocalizer(assembly, baseName);
                    this._localizerCache.set_Item(resourceSource.AssemblyQualifiedName, localizer);
                }
                return localizer;
            }
            /*IStringLocalizer */ Create$1(/*string*/ baseName, /*string*/ location)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(location, "location");
                return this._localizerCache.GetOrAdd(`B=${baseName},L=${location}`, new ($.$spc.System.Func$$$($.$spc.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let assemblyName = new $.$spc.System.Reflection.AssemblyName().$ctor$1(location);
                    /*var*/ let assembly = $.$spc.System.Reflection.Assembly.Load$1(assemblyName);
                    baseName = this.GetResourcePrefix$2(baseName, location);
                    return this.CreateResourceManagerStringLocalizer(assembly, baseName);
                }, {"r":633609,"p":[{"n":"_","p":1310721}],"n":"","d":764681,"h":0,"f":1048578}));
            }
            /*ResourceManagerStringLocalizer */ CreateResourceManagerStringLocalizer(/*Assembly*/ assembly, /*string*/ baseName)
            {
                return new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer().$ctor$1(new $.$spc.System.Resources.ResourceManager().$ctor$3(baseName, assembly), assembly, baseName, this._resourceNamesCache, $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger($.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer, this._loggerFactory));
            }
            /*string */ GetResourcePrefix$3(/*string*/ location, /*string*/ baseName, /*string*/ resourceLocation)
            {
                return location + "." + resourceLocation + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseName, location + ".");
            }
            /*ResourceLocationAttribute? */ GetResourceLocationAttribute(/*Assembly*/ assembly)
            {
                return $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$4($.$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute, assembly);
            }
            /*RootNamespaceAttribute? */ GetRootNamespaceAttribute(/*Assembly*/ assembly)
            {
                return $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$4($.$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute, assembly);
            }
            /*string? */ GetRootNamespace(/*Assembly*/ assembly)
            {
                /*var*/ let rootNamespaceAttribute = this.GetRootNamespaceAttribute(assembly);
                if (rootNamespaceAttribute !== null)
                {
                    return rootNamespaceAttribute.RootNamespace;
                }
                return assembly.GetName().Name;
            }
            /*string */ GetResourcePath(/*Assembly*/ assembly)
            {
                /*var*/ let resourceLocationAttribute = this.GetResourceLocationAttribute(assembly);
                /*var*/ let resourceLocation = resourceLocationAttribute === null ? this._resourcesRelativePath : resourceLocationAttribute.ResourceLocation + ".";
                resourceLocation = $.$spc.System.String.Replace$2.call($.$spc.System.String.Replace$2.call(resourceLocation, $.$spc.System.IO.Path.DirectorySeparatorChar, /*.*/ 46), $.$spc.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46);
                return resourceLocation;
            }
            static /*string? */ TrimPrefix(/*string*/ name, /*string*/ prefix)
            {
                if ($.$spc.System.String.StartsWith$1.call(name, prefix, 4/*StringComparison.Ordinal*/))
                {
                    return $.$spc.System.String.Substring.call(name, prefix.length);
                }
                return name;
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(System.Type)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create()
            {
                return this.Create(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(string, string)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1()
            {
                return this.Create$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceNamesCache = new $.$mel.Microsoft.Extensions.Localization.ResourceNamesCache().$ctor$1();
                this._localizerCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor$1();
            }
            static $h = 764681;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"typeInfo","p":84541441}],"n":"GetResourcePrefix","d":764681,"h":25770568457,"f":132},{"r":1310721,"p":[{"n":"typeInfo","p":84541441},{"n":"baseNamespace","p":1310721},{"n":"resourcesRelativePath","p":1310721}],"n":"GetResourcePrefix","o":"@$1","d":764681,"h":30065535753,"f":132},{"r":1310721,"p":[{"n":"baseResourceName","p":1310721},{"n":"baseNamespace","p":1310721}],"n":"GetResourcePrefix","o":"@$2","d":764681,"h":34360503049,"f":132},{"r":171230,"p":[{"n":"resourceSource","p":142606337}],"n":"Create","d":764681,"h":38655470345,"f":1},{"r":171230,"p":[{"n":"baseName","p":1310721},{"n":"location","p":1310721}],"n":"Create","o":"@$1","d":764681,"h":42950437641,"f":1},{"r":633609,"p":[{"n":"assembly","p":73465857},{"n":"baseName","p":1310721}],"n":"CreateResourceManagerStringLocalizer","d":764681,"h":47245404937,"f":132},{"r":1310721,"p":[{"n":"location","p":1310721},{"n":"baseName","p":1310721},{"n":"resourceLocation","p":1310721}],"n":"GetResourcePrefix","o":"@$3","d":764681,"h":51540372233,"f":132},{"r":568073,"p":[{"n":"assembly","p":73465857}],"n":"GetResourceLocationAttribute","d":764681,"h":55835339529,"f":132},{"r":961289,"p":[{"n":"assembly","p":73465857}],"n":"GetRootNamespaceAttribute","d":764681,"h":60130306825,"f":132},{"r":1310721,"p":[{"n":"assembly","p":73465857}],"n":"GetRootNamespace","d":764681,"h":64425274121,"f":2},{"r":1310721,"p":[{"n":"assembly","p":73465857}],"n":"GetResourcePath","d":764681,"h":68720241417,"f":2},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"prefix","p":1310721}],"n":"TrimPrefix","d":764681,"h":73015208713,"f":34}],"l":[{"t":371465,"n":"_resourceNamesCache","d":764681,"h":4295731977,"f":2},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer).$h,"n":"_localizerCache","d":764681,"h":8590699273,"f":2},{"t":1310721,"n":"_resourcesRelativePath","d":764681,"h":12885666569,"f":2},{"t":1048597,"n":"_loggerFactory","d":764681,"h":17180633865,"f":2}],"c":[{"p":[{"n":"localizationOptions","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h},{"n":"loggerFactory","p":1048597}],"n":".ctor","o":"$ctor$1","d":764681,"h":21475601161,"f":1}],"i":[302302],"h":764681}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory ]; }
            static get $fullName() { return `ResourceManagerStringLocalizerFactory`; }
        });
        
        $asm.$cls("$mel.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 1092361;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180961545,"f":1},"n":"ParameterName","d":1092361,"h":12885994249,"f":1}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1092361,"h":4296059657,"f":1}],"h":1092361,"a":[{"t":14680065,"c":21489516545,"a":[{"v":2048,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute", ($self) => class RootNamespaceAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ rootNamespace)
            {
                super.$ctor$1();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(rootNamespace, "rootNamespace");
                    this.RootNamespace = rootNamespace;
                }
                return this;
            }
            /*string*/ RootNamespace = null;
            static $h = 961289;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180830473,"f":1},"n":"RootNamespace","d":961289,"h":12885863177,"f":1}],"c":[{"p":[{"n":"rootNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":961289,"h":4295928585,"f":1}],"h":961289,"a":[{"t":14680065,"c":21489516545,"a":[{"v":1,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `RootNamespaceAttribute`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute", ($self) => class ResourceLocationAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ resourceLocation)
            {
                super.$ctor$1();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(resourceLocation, "resourceLocation");
                    this.ResourceLocation = resourceLocation;
                }
                return this;
            }
            /*string*/ ResourceLocation = null;
            static $h = 568073;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14548993,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180437257,"f":1},"n":"ResourceLocation","d":568073,"h":12885469961,"f":1}],"c":[{"p":[{"n":"resourceLocation","p":1310721}],"n":".ctor","o":"$ctor$2","d":568073,"h":4295535369,"f":1}],"h":568073,"a":[{"t":14680065,"c":21489516545,"a":[{"v":1,"t":14614529}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `ResourceLocationAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Localization.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))