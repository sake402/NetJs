
//--TRIMMABLE-BOUNDARY-START(103)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mela, $sttp, $sdd, $mexla, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization", 
    {
  "h": 103,
  "f": "Microsoft.Extensions.Localization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Application localization services and default implementation based on ResourceManager to load localized assembly resources.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "Microsoft .NET Extensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Localization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.Localization.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327783)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceNamesCache", ($self) => class IResourceNamesCache
        {
            static $h = 327783;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295079),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "valueFactory",
          "p": $.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h
        }
      ],
      "n": "GetOrAdd",
      "o": "Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd",
      "d": 327783,
      "h": 4295295079,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295079)
  ],
  "h": 327783
}; }
            static get $fullName() { return `IResourceNamesCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327783)
        
        
        //--TRIMMABLE-BOUNDARY-START(393319)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceStringProvider", ($self) => class IResourceStringProvider
        {
            static $h = 393319;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360615),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 83951617
        },
        {
          "n": "throwOnMissing",
          "p": 262145
        }
      ],
      "n": "GetAllResourceStrings",
      "o": "Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings",
      "d": 393319,
      "h": 4295360615,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295360615)
  ],
  "h": 393319
}; }
            static get $fullName() { return `IResourceStringProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393319)
        
        
        //--TRIMMABLE-BOUNDARY-START(458855)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.LocalizationOptions", ($self) => class LocalizationOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590393447)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393447);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393447)
            
            //--TRIMMABLE-BOUNDARY-START(21475295335)
            /*string*/ ResourcesPath = null;
            //--TRIMMABLE-BOUNDARY-END(21475295335)
            
            //default member initializer
            constructor()
            {
                super();
                this.ResourcesPath = $.$$.System.String.Empty;
            }
            static $h = 458855;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475295335),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328039,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065229927,
        "f": 83886081
      },
      "n": "ResourcesPath",
      "d": 458855,
      "h": 21475295335,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475295335)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393447),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458855,
      "h": 8590393447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393447)
  ],
  "h": 458855
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458855)
        
        
        //--TRIMMABLE-BOUNDARY-START(131175)
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper", ($self) => class ArgumentThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295098471)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098471)
            
            //--TRIMMABLE-BOUNDARY-START(8590065767)
            static /*void */ ThrowIfNullOrWhiteSpace(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(argument, "argument");
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065767)
            
            static $h = 131175;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098471),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 1048679,
              "c": 8590983271,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 131175,
      "h": 4295098471,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098471),
//--TRIMMABLE-BOUNDARY-START(8590065767),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 1048679,
              "c": 8590983271,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrWhiteSpace",
      "d": 131175,
      "h": 8590065767,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065767)
  ],
  "h": 131175
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131175)
        
        
        //--TRIMMABLE-BOUNDARY-START(65639)
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032935)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032935)
            
            //--TRIMMABLE-BOUNDARY-START(8590000231)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000231)
            
            static $h = 65639;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032935),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 1048679,
              "c": 8590983271,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 65639,
      "h": 4295032935,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032935),
//--TRIMMABLE-BOUNDARY-START(8590000231),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 1048679,
              "c": 8590983271,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 65639,
      "h": 8590000231,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000231)
  ],
  "h": 65639
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65639)
        
        
        //--TRIMMABLE-BOUNDARY-START(196711)
        $asm.$cls("$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions", ($self) => class LocalizationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590131303)
            static /*IServiceCollection */ AddLocalization$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131303);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131303)
            
            //--TRIMMABLE-BOUNDARY-START(4295164007)
            static /*IServiceCollection */ AddLocalization(/*this IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(setupAction, "setupAction");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices(services, setupAction);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295164007)
            
            //--TRIMMABLE-BOUNDARY-START(17180065895)
            static /*void */ AddLocalizationServices$1(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065895);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(services, $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$().$type, $.$mela.Microsoft.Extensions.Localization.StringLocalizer$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065895)
            
            //--TRIMMABLE-BOUNDARY-START(12885098599)
            static /*void */ AddLocalizationServices(/*IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Localization.LocalizationOptions, services, setupAction);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098599)
            
            static $h = 196711;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131303),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLocalization",
      "o": "@$1",
      "d": 196711,
      "h": 8590131303,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131303),
//--TRIMMABLE-BOUNDARY-START(4295164007),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h
        }
      ],
      "n": "AddLocalization",
      "d": 196711,
      "h": 4295164007,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164007),
//--TRIMMABLE-BOUNDARY-START(17180065895),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLocalizationServices",
      "o": "@$1",
      "d": 196711,
      "h": 17180065895,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180065895),
//--TRIMMABLE-BOUNDARY-START(12885098599),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h
        }
      ],
      "n": "AddLocalizationServices",
      "d": 196711,
      "h": 12885098599,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885098599)
  ],
  "h": 196711
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196711)
        
        
        //--TRIMMABLE-BOUNDARY-START(262247)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.AssemblyWrapper", ($self) => class AssemblyWrapper extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196839)
            $ctor$1(/*Assembly*/ assembly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196839);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(assembly, "assembly");
                    this.Assembly = assembly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196839)
            
            //--TRIMMABLE-BOUNDARY-START(12885164135)
            /*Assembly*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(12885164135)
            
            //--TRIMMABLE-BOUNDARY-START(17180131431)
            /*string */ get FullName()
            {
                return this.Assembly.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131431)
            
            //--TRIMMABLE-BOUNDARY-START(38654967911)
            /*Stream? */ GetManifestResourceStream(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654967911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Assembly.GetManifestResourceStream(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967911)
            
            static $h = 262247;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885164135),
    {
      "p": 106299393,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770066023,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 262247,
      "h": 12885164135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885164135),
//--TRIMMABLE-BOUNDARY-START(17180131431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000615,
        "f": 50331777
      },
      "n": "FullName",
      "d": 262247,
      "h": 17180131431,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17180131431)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967911),
    {
      "r": 94961665,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetManifestResourceStream",
      "d": 262247,
      "h": 38654967911,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38654967911)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196839),
    {
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262247,
      "h": 8590196839,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196839)
  ],
  "h": 262247
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AssemblyWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262247)
        
        
        //--TRIMMABLE-BOUNDARY-START(983143)
        $asm.$cls("$mel.Resources", ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(81605361767)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(81605361767)
            
            //--TRIMMABLE-BOUNDARY-START(73015427175)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(73015427175)
            
            //--TRIMMABLE-BOUNDARY-START(77310394471)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mel.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Localization", $.$mel.Resources.$type.Assembly);
                    $.$mel.Resources.s_resourceManager = temp;
                }
                return $.$mel.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(77310394471)
            
            //--TRIMMABLE-BOUNDARY-START(4295950439)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950439)
            
            //--TRIMMABLE-BOUNDARY-START(60130525287)
            static /*string */ get Localization_MissingManifest()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The manifest '{0}' was not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(60130525287)
            
            //--TRIMMABLE-BOUNDARY-START(8590917735)
            static /*string */ FormatLocalization_MissingManifest(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The manifest '{0}' was not found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917735)
            
            //--TRIMMABLE-BOUNDARY-START(64425492583)
            static /*string */ get Localization_MissingManifest_Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No manifests exist for the current culture.";
            }
            //--TRIMMABLE-BOUNDARY-END(64425492583)
            
            //--TRIMMABLE-BOUNDARY-START(68720459879)
            static /*string */ get Localization_TypeMustHaveTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type '{0}' must have a non-null type name.";
            }
            //--TRIMMABLE-BOUNDARY-END(68720459879)
            
            //--TRIMMABLE-BOUNDARY-START(12885885031)
            static /*string */ FormatLocalization_TypeMustHaveTypeName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Type '{0}' must have a non-null type name.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(12885885031)
            
            static $h = 983143;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310394471),
    {
      "p": 122814465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557991,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 983143,
      "h": 77310394471,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310394471),
//--TRIMMABLE-BOUNDARY-START(4295950439),
    {
      "p": 83951617,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819623,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195296359,
        "f": 83886120
      },
      "n": "Culture",
      "d": 983143,
      "h": 4295950439,
      "f": 2097192,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295950439),
//--TRIMMABLE-BOUNDARY-START(60130525287),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655688807,
        "f": 50331688
      },
      "n": "Localization_MissingManifest",
      "d": 983143,
      "h": 60130525287,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60130525287),
//--TRIMMABLE-BOUNDARY-START(64425492583),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754215,
        "f": 50331688
      },
      "n": "Localization_MissingManifest_Parent",
      "d": 983143,
      "h": 64425492583,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(64425492583),
//--TRIMMABLE-BOUNDARY-START(68720459879),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245623399,
        "f": 50331688
      },
      "n": "Localization_TypeMustHaveTypeName",
      "d": 983143,
      "h": 68720459879,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(68720459879)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917735),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatLocalization_MissingManifest",
      "d": 983143,
      "h": 8590917735,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590917735),
//--TRIMMABLE-BOUNDARY-START(12885885031),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatLocalization_TypeMustHaveTypeName",
      "d": 983143,
      "h": 12885885031,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885885031)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605361767),
    {
      "t": 122814465,
      "n": "s_resourceManager",
      "d": 983143,
      "h": 81605361767,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605361767),
//--TRIMMABLE-BOUNDARY-START(73015427175),
    {
      "t": 83951617,
      "n": "resourceCulture",
      "d": 983143,
      "h": 73015427175,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015427175)
  ],
  "h": 983143,
  "a": [
    {
      "t": 54329345,
      "c": 12939231233,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 70516737,
      "c": 4365484033
    },
    {
      "t": 125829121,
      "c": 4420796417
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983143)
        
        
        //--TRIMMABLE-BOUNDARY-START(852071)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceNamesCache", ($self) => class ResourceNamesCache extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819367)
            /*ConcurrentDictionary<string, IList<string>?>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4295819367)
            
            //--TRIMMABLE-BOUNDARY-START(8590786663)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590786663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786663)
            
            //--TRIMMABLE-BOUNDARY-START(12885753959)
            /*IList<string>? */ GetOrAdd(/*string*/ name, /*Func<string, IList<string>?>*/ valueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.GetOrAdd(name, valueFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753959)
            
            //--TRIMMABLE-BOUNDARY-START(4295295079)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceNamesCache.GetOrAdd(string, System.Func<string, System.Collections.Generic.IList<string>?>)
            Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295079);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOrAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295079)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295819367)
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295819367)
                
            }
            static $h = 852071;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753959),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "valueFactory",
          "p": $.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h
        }
      ],
      "n": "GetOrAdd",
      "d": 852071,
      "h": 12885753959,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885753959)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819367),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h,
      "n": "_cache",
      "d": 852071,
      "h": 4295819367,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819367)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786663),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852071,
      "h": 8590786663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786663)
  ],
  "i": [327783
  ],
  "h": 852071
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceNamesCache ]; }
            static get $fullName() { return `ResourceNamesCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852071)
        
        
        //--TRIMMABLE-BOUNDARY-START(589927)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer", ($self) => class ResourceManagerStringLocalizer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(655463)
            static $_Log;
            static get Log()
            {
                let $cls = $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer;
                return $cls.$_Log ??= $asm.$ncls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log", ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622759)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.String, global::System.Globalization.CultureInfo, global::System.Exception?>*/ static __SearchedLocationCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622759)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557351)
                    static /*void */ SearchedLocation(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ key, /*global::System.String*/ locationSearched, /*global::System.Globalization.CultureInfo*/ culture)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885557351);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.__SearchedLocationCallback.Invoke(logger, key, locationSearched, culture, null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557351)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590055)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295622759)
                            this.__SearchedLocationCallback = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$8($.$$.System.String, $.$$.System.String, $.$$.System.Globalization.CultureInfo, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mexla.Microsoft.Extensions.Logging.EventId().$ctor$3(1, "SearchedLocation"), "ResourceManagerStringLocalizer searched for '{Key}' in '{LocationSearched}' with culture '{Culture}'.", (() =>
                            {
                                //new $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mexla.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4295622759)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590590055)
                    
                    static $h = 655463;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885557351),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "locationSearched",
          "p": 1310721
        },
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "SearchedLocation",
      "d": 655463,
      "h": 12885557351,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 30066999384,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "ResourceManagerStringLocalizer searched for \u0027{Key}\u0027 in \u0027{LocationSearched}\u0027 with culture \u0027{Culture}\u0027.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "SearchedLocation",
              "t": 1310721
            }
          ]
        },
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885557351)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622759),
    {
      "t": $.$$.System.Action$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.String, $.$$.System.Globalization.CultureInfo, $.$$.System.Exception).$h,
      "n": "__SearchedLocationCallback",
      "d": 655463,
      "h": 4295622759,
      "f": 4194338,
      "a": [
        {
          "t": 54329345,
          "c": 12939231233,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295622759)
  ],
  "d": 589927,
  "h": 655463
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655463)
            
            //--TRIMMABLE-BOUNDARY-START(8590524519)
            /*ConcurrentDictionary<string, object?>*/ _missingManifestCache = null;
            //--TRIMMABLE-BOUNDARY-END(8590524519)
            
            //--TRIMMABLE-BOUNDARY-START(21475426407)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(21475426407)
            
            //--TRIMMABLE-BOUNDARY-START(17180459111)
            /*ResourceManager*/ _resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(17180459111)
            
            //--TRIMMABLE-BOUNDARY-START(25770393703)
            /*IResourceStringProvider*/ _resourceStringProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25770393703)
            
            //--TRIMMABLE-BOUNDARY-START(12885491815)
            /*string*/ _resourceBaseName = null;
            //--TRIMMABLE-BOUNDARY-END(12885491815)
            
            //--TRIMMABLE-BOUNDARY-START(4295557223)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(4295557223)
            
            //--TRIMMABLE-BOUNDARY-START(34360328295)
            $ctor$1(/*ResourceManager*/ resourceManager, /*Assembly*/ resourceAssembly, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$2(resourceManager, new $.$mel.Microsoft.Extensions.Localization.AssemblyWrapper().$ctor$1(resourceAssembly), baseName, resourceNamesCache, logger);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360328295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328295)
            
            //--TRIMMABLE-BOUNDARY-START(38655295591)
            $ctor$2(/*ResourceManager*/ resourceManager, /*AssemblyWrapper*/ resourceAssemblyWrapper, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$3(resourceManager, new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider().$ctor$1(resourceNamesCache, resourceManager, resourceAssemblyWrapper.Assembly, baseName), baseName, resourceNamesCache, logger);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655295591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655295591)
            
            //--TRIMMABLE-BOUNDARY-START(42950262887)
            $ctor$3(/*ResourceManager*/ resourceManager, /*IResourceStringProvider*/ resourceStringProvider, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950262887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceManager, "resourceManager");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceStringProvider, "resourceStringProvider");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceNamesCache, "resourceNamesCache");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    this._resourceStringProvider = resourceStringProvider;
                    this._resourceManager = resourceManager;
                    this._resourceBaseName = baseName;
                    this._resourceNamesCache = resourceNamesCache;
                    this._logger = logger;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950262887)
            
            //--TRIMMABLE-BOUNDARY-START(85899935847)
            /*LocalizedString*/ get_Item$2(/*string*/ name)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value = this.GetStringSafely(name, null);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value ?? name, $.$$.System.String.op_Equality(value, null), this._resourceBaseName);
            }
            //--TRIMMABLE-BOUNDARY-END(85899935847)
            
            //--TRIMMABLE-BOUNDARY-START(81604968551)
            /*LocalizedString*/ get_Item$1(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let format = this.GetStringSafely(name, null);
                /*var*/ let value = $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.CurrentCulture, format ?? name, $arguments);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value, $.$$.System.String.op_Equality(format, null), this._resourceBaseName);
            }
            //--TRIMMABLE-BOUNDARY-END(81604968551)
            
            //--TRIMMABLE-BOUNDARY-START(68720066663)
            /*IEnumerable<LocalizedString> */ GetAllStrings$1(/*bool*/ includeParentCultures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720066663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetAllStrings(includeParentCultures, $.$$.System.Globalization.CultureInfo.CurrentUICulture);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720066663)
            
            //--TRIMMABLE-BOUNDARY-START(64425099367)
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures, /*CultureInfo*/ culture)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(culture, "culture");
                    /*var*/ let resourceNames = includeParentCultures ? this.GetResourceNamesFromCultureHierarchy(culture) : this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(culture, true);
                    var $en3 = resourceNames ?? $.$sl.System.Linq.Enumerable.Empty($.$$.System.String).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var name = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*var*/ let value = this.GetStringSafely(name, culture);
                            yield new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value ?? name, $.$$.System.String.op_Equality(value, null), this._resourceBaseName);
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(64425099367)
            
            //--TRIMMABLE-BOUNDARY-START(77310001255)
            /*string? */ GetStringSafely(/*string*/ name, /*CultureInfo?*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let keyCulture = culture ?? $.$$.System.Globalization.CultureInfo.CurrentUICulture;
                /*var*/ let cacheKey = `name=${name}&culture=${keyCulture.Name}`;
                $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.SearchedLocation(this._logger, name, this._resourceBaseName, keyCulture);
                if (this._missingManifestCache.ContainsKey(cacheKey))
                {
                    return null;
                }
                try
                {
                    return this._resourceManager.GetString(name, culture);
                }
                catch($e)
                {
                    this._missingManifestCache.TryAdd(cacheKey, null);
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310001255)
            
            //--TRIMMABLE-BOUNDARY-START(73015033959)
            /*IEnumerable<string> */ GetResourceNamesFromCultureHierarchy(/*CultureInfo*/ startingCulture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let currentCulture = startingCulture;
                /*var*/ let resourceNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$1();
                /*var*/ let hasAnyCultures = false;
                while(true)
                {
                    /*var*/ let cultureResourceNames = this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(currentCulture, false);
                    if (cultureResourceNames !== null)
                    {
                        var $en4 = cultureResourceNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var resourceName = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                resourceNames.Add(resourceName);
                            }
                        }
                        hasAnyCultures = true;
                    }
                    if (currentCulture === currentCulture.Parent)
                    {
                        break;
                    }
                    currentCulture = currentCulture.Parent;
                }
                if (!hasAnyCultures)
                {
                    throw new $.$$.System.Resources.MissingManifestResourceException().$ctor$12($.$mel.Resources.Localization_MissingManifest_Parent);
                }
                return resourceNames;
            }
            //--TRIMMABLE-BOUNDARY-END(73015033959)
            
            //--TRIMMABLE-BOUNDARY-START(17180000358)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000358)
            
            //--TRIMMABLE-BOUNDARY-START(8590065766)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065766)
            
            //--TRIMMABLE-BOUNDARY-START(21474967654)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllStrings$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967654)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590524519)
                this._missingManifestCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590524519)
                
            }
            static $h = 589927;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899935847),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132071,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$2",
      "d": 589927,
      "h": 85899935847,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(85899935847),
//--TRIMMABLE-BOUNDARY-START(81604968551),
    {
      "p": 327782,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197479,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 589927,
      "h": 81604968551,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(81604968551)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720066663),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "o": "@$1",
      "d": 589927,
      "h": 68720066663,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720066663),
//--TRIMMABLE-BOUNDARY-START(64425099367),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        },
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "GetAllStrings",
      "d": 589927,
      "h": 64425099367,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(64425099367),
//--TRIMMABLE-BOUNDARY-START(77310001255),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "GetStringSafely",
      "d": 589927,
      "h": 77310001255,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(77310001255),
//--TRIMMABLE-BOUNDARY-START(73015033959),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "p": [
        {
          "n": "startingCulture",
          "p": 83951617
        }
      ],
      "n": "GetResourceNamesFromCultureHierarchy",
      "d": 589927,
      "h": 73015033959,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015033959)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524519),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "_missingManifestCache",
      "d": 589927,
      "h": 8590524519,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524519),
//--TRIMMABLE-BOUNDARY-START(21475426407),
    {
      "t": 327783,
      "n": "_resourceNamesCache",
      "d": 589927,
      "h": 21475426407,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426407),
//--TRIMMABLE-BOUNDARY-START(17180459111),
    {
      "t": 122814465,
      "n": "_resourceManager",
      "d": 589927,
      "h": 17180459111,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459111),
//--TRIMMABLE-BOUNDARY-START(25770393703),
    {
      "t": 393319,
      "n": "_resourceStringProvider",
      "d": 589927,
      "h": 25770393703,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770393703),
//--TRIMMABLE-BOUNDARY-START(12885491815),
    {
      "t": 1310721,
      "n": "_resourceBaseName",
      "d": 589927,
      "h": 12885491815,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491815),
//--TRIMMABLE-BOUNDARY-START(4295557223),
    {
      "t": 917592,
      "n": "_logger",
      "d": 589927,
      "h": 4295557223,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557223)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360328295),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 122814465
        },
        {
          "n": "resourceAssembly",
          "p": 106299393
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327783
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589927,
      "h": 34360328295,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360328295),
//--TRIMMABLE-BOUNDARY-START(38655295591),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 122814465
        },
        {
          "n": "resourceAssemblyWrapper",
          "p": 262247
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327783
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589927,
      "h": 38655295591,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38655295591),
//--TRIMMABLE-BOUNDARY-START(42950262887),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 122814465
        },
        {
          "n": "resourceStringProvider",
          "p": 393319
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327783
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589927,
      "h": 42950262887,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950262887)
  ],
  "i": [131174
  ],
  "j": [655463
  ],
  "h": 589927
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589927)
        
        
        //--TRIMMABLE-BOUNDARY-START(720999)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory", ($self) => class ResourceManagerStringLocalizerFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885622887)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(12885622887)
            
            //--TRIMMABLE-BOUNDARY-START(4295688295)
            /*ConcurrentDictionary<string, ResourceManagerStringLocalizer>*/ _localizerCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295688295)
            
            //--TRIMMABLE-BOUNDARY-START(17180590183)
            /*string*/ _resourcesRelativePath = null;
            //--TRIMMABLE-BOUNDARY-END(17180590183)
            
            //--TRIMMABLE-BOUNDARY-START(8590655591)
            /*ILoggerFactory*/ _loggerFactory = null;
            //--TRIMMABLE-BOUNDARY-END(8590655591)
            
            //--TRIMMABLE-BOUNDARY-START(21475557479)
            $ctor$1(/*IOptions<LocalizationOptions>*/ localizationOptions, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557479);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(localizationOptions, "localizationOptions");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(loggerFactory, "loggerFactory");
                    this._resourcesRelativePath = localizationOptions.Microsoft$Extensions$Options$IOptions$$$Value.ResourcesPath ?? $.$$.System.String.Empty;
                    this._loggerFactory = loggerFactory;
                    if (!$.$$.System.String.IsNullOrEmpty(this._resourcesRelativePath))
                    {
                        this._resourcesRelativePath = $.$$.System.String.Replace.call($.$$.System.String.Replace.call(this._resourcesRelativePath, $.$$.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46), $.$$.System.IO.Path.DirectorySeparatorChar, /*.*/ 46) + ".";
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557479)
            
            //--TRIMMABLE-BOUNDARY-START(51540328551)
            /*string */ GetResourcePrefix$1(/*TypeInfo*/ typeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                return this.GetResourcePrefix(typeInfo, this.GetRootNamespace(typeInfo.Assembly), this.GetResourcePath(typeInfo.Assembly));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328551)
            
            //--TRIMMABLE-BOUNDARY-START(47245361255)
            /*string */ GetResourcePrefix(/*TypeInfo*/ typeInfo, /*string?*/ baseNamespace, /*string?*/ resourcesRelativePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(typeInfo.FullName, "typeInfo.FullName");
                if ($.$$.System.String.IsNullOrEmpty(resourcesRelativePath))
                {
                    return typeInfo.FullName;
                }
                else 
                {
                    return baseNamespace + "." + resourcesRelativePath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(typeInfo.FullName, baseNamespace + ".");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245361255)
            
            //--TRIMMABLE-BOUNDARY-START(60130263143)
            /*string */ GetResourcePrefix$3(/*string*/ baseResourceName, /*string*/ baseNamespace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseResourceName, "baseResourceName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                /*var*/ let assemblyName = new $.$$.System.Reflection.AssemblyName().$ctor$2(baseNamespace);
                /*var*/ let assembly = $.$$.System.Reflection.Assembly.Load$3(assemblyName);
                /*var*/ let rootNamespace = this.GetRootNamespace(assembly);
                /*var*/ let resourceLocation = this.GetResourcePath(assembly);
                /*var*/ let locationPath = rootNamespace + "." + resourceLocation;
                baseResourceName = locationPath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseResourceName, baseNamespace + ".");
                return baseResourceName;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263143)
            
            //--TRIMMABLE-BOUNDARY-START(30065492071)
            /*IStringLocalizer */ Create$1(/*Type*/ resourceSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceSource, "resourceSource");
                /*var*/ let localizer;
                if (!this._localizerCache.TryGetValue(resourceSource.AssemblyQualifiedName, $.$ref(() => localizer, ($v) => localizer = $v, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer)))
                {
                    /*var*/ let typeInfo = $.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo(resourceSource);
                    /*var*/ let baseName = this.GetResourcePrefix$1(typeInfo);
                    /*var*/ let assembly = typeInfo.Assembly;
                    localizer = this.CreateResourceManagerStringLocalizer(assembly, baseName);
                    this._localizerCache.set_Item$1(resourceSource.AssemblyQualifiedName, localizer);
                }
                return localizer;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492071)
            
            //--TRIMMABLE-BOUNDARY-START(25770524775)
            /*IStringLocalizer */ Create(/*string*/ baseName, /*string*/ location)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(location, "location");
                return this._localizerCache.GetOrAdd(`B=${baseName},L=${location}`, new ($.$$.System.Func$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let assemblyName = new $.$$.System.Reflection.AssemblyName().$ctor$2(location);
                    /*var*/ let assembly = $.$$.System.Reflection.Assembly.Load$3(assemblyName);
                    baseName = this.GetResourcePrefix$3(baseName, location);
                    return this.CreateResourceManagerStringLocalizer(assembly, baseName);
                }, {
  "r": 589927,
  "p": [
    {
      "n": "_",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 720999,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770524775)
            
            //--TRIMMABLE-BOUNDARY-START(34360459367)
            /*ResourceManagerStringLocalizer */ CreateResourceManagerStringLocalizer(/*Assembly*/ assembly, /*string*/ baseName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer().$ctor$1(new $.$$.System.Resources.ResourceManager().$ctor$3(baseName, assembly), assembly, baseName, this._resourceNamesCache, $.$mexla.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger$1($.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer, this._loggerFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(34360459367)
            
            //--TRIMMABLE-BOUNDARY-START(55835295847)
            /*string */ GetResourcePrefix$2(/*string*/ location, /*string*/ baseName, /*string*/ resourceLocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return location + "." + resourceLocation + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseName, location + ".");
            }
            //--TRIMMABLE-BOUNDARY-END(55835295847)
            
            //--TRIMMABLE-BOUNDARY-START(38655426663)
            /*ResourceLocationAttribute? */ GetResourceLocationAttribute(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute, assembly);
            }
            //--TRIMMABLE-BOUNDARY-END(38655426663)
            
            //--TRIMMABLE-BOUNDARY-START(68720197735)
            /*RootNamespaceAttribute? */ GetRootNamespaceAttribute(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute, assembly);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197735)
            
            //--TRIMMABLE-BOUNDARY-START(64425230439)
            /*string? */ GetRootNamespace(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rootNamespaceAttribute = this.GetRootNamespaceAttribute(assembly);
                if (rootNamespaceAttribute !== null)
                {
                    return rootNamespaceAttribute.RootNamespace;
                }
                return assembly.GetName().Name;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230439)
            
            //--TRIMMABLE-BOUNDARY-START(42950393959)
            /*string */ GetResourcePath(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceLocationAttribute = this.GetResourceLocationAttribute(assembly);
                /*var*/ let resourceLocation = resourceLocationAttribute === null ? this._resourcesRelativePath : resourceLocationAttribute.ResourceLocation + ".";
                resourceLocation = $.$$.System.String.Replace.call($.$$.System.String.Replace.call(resourceLocation, $.$$.System.IO.Path.DirectorySeparatorChar, /*.*/ 46), $.$$.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46);
                return resourceLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393959)
            
            //--TRIMMABLE-BOUNDARY-START(73015165031)
            static /*string? */ TrimPrefix(/*string*/ name, /*string*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.StartsWith$2.call(name, prefix, 4/*StringComparison.Ordinal*/))
                {
                    return $.$$.System.String.Substring$1.call(name, prefix.length);
                }
                return name;
            }
            //--TRIMMABLE-BOUNDARY-END(73015165031)
            
            //--TRIMMABLE-BOUNDARY-START(8590196838)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(System.Type)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196838)
            
            //--TRIMMABLE-BOUNDARY-START(4295229542)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(string, string)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229542)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885622887)
                this._resourceNamesCache = new $.$mel.Microsoft.Extensions.Localization.ResourceNamesCache().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885622887)
                
                //--TRIMMABLE-BOUNDARY-START(4295688295)
                this._localizerCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295688295)
                
            }
            static $h = 720999;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540328551),
    {
      "r": 1310721,
      "p": [
        {
          "n": "typeInfo",
          "p": 121831425
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$1",
      "d": 720999,
      "h": 51540328551,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(51540328551),
//--TRIMMABLE-BOUNDARY-START(47245361255),
    {
      "r": 1310721,
      "p": [
        {
          "n": "typeInfo",
          "p": 121831425
        },
        {
          "n": "baseNamespace",
          "p": 1310721
        },
        {
          "n": "resourcesRelativePath",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "d": 720999,
      "h": 47245361255,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47245361255),
//--TRIMMABLE-BOUNDARY-START(60130263143),
    {
      "r": 1310721,
      "p": [
        {
          "n": "baseResourceName",
          "p": 1310721
        },
        {
          "n": "baseNamespace",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$3",
      "d": 720999,
      "h": 60130263143,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60130263143),
//--TRIMMABLE-BOUNDARY-START(30065492071),
    {
      "r": 131174,
      "p": [
        {
          "n": "resourceSource",
          "p": 187760641
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 720999,
      "h": 30065492071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492071),
//--TRIMMABLE-BOUNDARY-START(25770524775),
    {
      "r": 131174,
      "p": [
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "location",
          "p": 1310721
        }
      ],
      "n": "Create",
      "d": 720999,
      "h": 25770524775,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524775),
//--TRIMMABLE-BOUNDARY-START(34360459367),
    {
      "r": 589927,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        },
        {
          "n": "baseName",
          "p": 1310721
        }
      ],
      "n": "CreateResourceManagerStringLocalizer",
      "d": 720999,
      "h": 34360459367,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(34360459367),
//--TRIMMABLE-BOUNDARY-START(55835295847),
    {
      "r": 1310721,
      "p": [
        {
          "n": "location",
          "p": 1310721
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceLocation",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$2",
      "d": 720999,
      "h": 55835295847,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(55835295847),
//--TRIMMABLE-BOUNDARY-START(38655426663),
    {
      "r": 524391,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        }
      ],
      "n": "GetResourceLocationAttribute",
      "d": 720999,
      "h": 38655426663,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(38655426663),
//--TRIMMABLE-BOUNDARY-START(68720197735),
    {
      "r": 917607,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        }
      ],
      "n": "GetRootNamespaceAttribute",
      "d": 720999,
      "h": 68720197735,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720197735),
//--TRIMMABLE-BOUNDARY-START(64425230439),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        }
      ],
      "n": "GetRootNamespace",
      "d": 720999,
      "h": 64425230439,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425230439),
//--TRIMMABLE-BOUNDARY-START(42950393959),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        }
      ],
      "n": "GetResourcePath",
      "d": 720999,
      "h": 42950393959,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393959),
//--TRIMMABLE-BOUNDARY-START(73015165031),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "prefix",
          "p": 1310721
        }
      ],
      "n": "TrimPrefix",
      "d": 720999,
      "h": 73015165031,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73015165031)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622887),
    {
      "t": 327783,
      "n": "_resourceNamesCache",
      "d": 720999,
      "h": 12885622887,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622887),
//--TRIMMABLE-BOUNDARY-START(4295688295),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer).$h,
      "n": "_localizerCache",
      "d": 720999,
      "h": 4295688295,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688295),
//--TRIMMABLE-BOUNDARY-START(17180590183),
    {
      "t": 1310721,
      "n": "_resourcesRelativePath",
      "d": 720999,
      "h": 17180590183,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590183),
//--TRIMMABLE-BOUNDARY-START(8590655591),
    {
      "t": 1048664,
      "n": "_loggerFactory",
      "d": 720999,
      "h": 8590655591,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655591)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557479),
    {
      "p": [
        {
          "n": "localizationOptions",
          "p": $.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720999,
      "h": 21475557479,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557479)
  ],
  "i": [262246
  ],
  "h": 720999
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory ]; }
            static get $fullName() { return `ResourceManagerStringLocalizerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720999)
        
        
        //--TRIMMABLE-BOUNDARY-START(786535)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider", ($self) => class ResourceManagerStringProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180655719)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(17180655719)
            
            //--TRIMMABLE-BOUNDARY-START(12885688423)
            /*ResourceManager*/ _resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(12885688423)
            
            //--TRIMMABLE-BOUNDARY-START(4295753831)
            /*Assembly*/ _assembly = null;
            //--TRIMMABLE-BOUNDARY-END(4295753831)
            
            //--TRIMMABLE-BOUNDARY-START(8590721127)
            /*string*/ _resourceBaseName = null;
            //--TRIMMABLE-BOUNDARY-END(8590721127)
            
            //--TRIMMABLE-BOUNDARY-START(21475623015)
            $ctor$1(/*IResourceNamesCache*/ resourceCache, /*ResourceManager*/ resourceManager, /*Assembly*/ assembly, /*string*/ baseName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623015);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resourceManager = resourceManager;
                    this._resourceNamesCache = resourceCache;
                    this._assembly = assembly;
                    this._resourceBaseName = baseName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623015)
            
            //--TRIMMABLE-BOUNDARY-START(30065557607)
            /*string */ GetResourceCacheKey(/*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceName = this._resourceManager.BaseName;
                return `Culture=${culture.Name};resourceName=${resourceName};Assembly=${this._assembly.FullName}`;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557607)
            
            //--TRIMMABLE-BOUNDARY-START(34360524903)
            /*string */ GetResourceName(/*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceStreamName = this._resourceBaseName;
                if (!$.$$.System.String.IsNullOrEmpty(culture.Name))
                {
                    resourceStreamName += "." + culture.Name;
                }
                resourceStreamName += ".resources";
                return resourceStreamName;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524903)
            
            //--TRIMMABLE-BOUNDARY-START(25770590311)
            /*IList<string>? */ GetAllResourceStrings(/*CultureInfo*/ culture, /*bool*/ throwOnMissing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cacheKey = this.GetResourceCacheKey(culture);
                return this._resourceNamesCache.Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd(cacheKey, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let resourceSet = this._resourceManager.GetResourceSet(culture, true, false);
                    if (resourceSet === null)
                    {
                        if (throwOnMissing)
                        {
                            throw new $.$$.System.Resources.MissingManifestResourceException().$ctor$12($.$mel.Resources.FormatLocalization_MissingManifest(this.GetResourceName(culture)));
                        }
                        else 
                        {
                            return null;
                        }
                    }
                    /*var*/ let names = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    var $en3 = resourceSet.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var entry = $en3.System$Collections$IEnumerator$Current;
                        {
                            let key;
                            if ($.$is((entry?.Key ?? null), $.$$.System.String, { set $v(v){ key = v; } }))
                            {
                                names.Add(key);
                            }
                        }
                    }
                    return names;
                }, {
  "r": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
  "p": [
    {
      "n": "_",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 786535,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770590311)
            
            //--TRIMMABLE-BOUNDARY-START(4295360615)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceStringProvider.GetAllResourceStrings(System.Globalization.CultureInfo, bool)
            Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllResourceStrings(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295360615)
            
            static $h = 786535;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065557607),
    {
      "r": 1310721,
      "p": [
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "GetResourceCacheKey",
      "d": 786535,
      "h": 30065557607,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065557607),
//--TRIMMABLE-BOUNDARY-START(34360524903),
    {
      "r": 1310721,
      "p": [
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "GetResourceName",
      "d": 786535,
      "h": 34360524903,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360524903),
//--TRIMMABLE-BOUNDARY-START(25770590311),
    {
      "r": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 83951617
        },
        {
          "n": "throwOnMissing",
          "p": 262145
        }
      ],
      "n": "GetAllResourceStrings",
      "d": 786535,
      "h": 25770590311,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590311)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180655719),
    {
      "t": 327783,
      "n": "_resourceNamesCache",
      "d": 786535,
      "h": 17180655719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655719),
//--TRIMMABLE-BOUNDARY-START(12885688423),
    {
      "t": 122814465,
      "n": "_resourceManager",
      "d": 786535,
      "h": 12885688423,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688423),
//--TRIMMABLE-BOUNDARY-START(4295753831),
    {
      "t": 106299393,
      "n": "_assembly",
      "d": 786535,
      "h": 4295753831,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753831),
//--TRIMMABLE-BOUNDARY-START(8590721127),
    {
      "t": 1310721,
      "n": "_resourceBaseName",
      "d": 786535,
      "h": 8590721127,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721127)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475623015),
    {
      "p": [
        {
          "n": "resourceCache",
          "p": 327783
        },
        {
          "n": "resourceManager",
          "p": 122814465
        },
        {
          "n": "assembly",
          "p": 106299393
        },
        {
          "n": "baseName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786535,
      "h": 21475623015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623015)
  ],
  "i": [393319
  ],
  "h": 786535
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceStringProvider ]; }
            static get $fullName() { return `ResourceManagerStringProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786535)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048679)
        $asm.$cls("$mel.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590983271)
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983271);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ParameterName = parameterName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983271)
            
            //--TRIMMABLE-BOUNDARY-START(21475885159)
            /*string*/ ParameterName = null;
            //--TRIMMABLE-BOUNDARY-END(21475885159)
            
            static $h = 1048679;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475885159),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180917863,
        "f": 50331649
      },
      "n": "ParameterName",
      "d": 1048679,
      "h": 21475885159,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475885159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983271),
    {
      "p": [
        {
          "n": "parameterName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048679,
      "h": 8590983271,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983271)
  ],
  "h": 1048679,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2048,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048679)
        
        
        //--TRIMMABLE-BOUNDARY-START(524391)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute", ($self) => class ResourceLocationAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590458983)
            $ctor$2(/*string*/ resourceLocation)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458983);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(resourceLocation, "resourceLocation");
                    this.ResourceLocation = resourceLocation;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458983)
            
            //--TRIMMABLE-BOUNDARY-START(21475360871)
            /*string*/ ResourceLocation = null;
            //--TRIMMABLE-BOUNDARY-END(21475360871)
            
            static $h = 524391;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360871),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393575,
        "f": 50331649
      },
      "n": "ResourceLocation",
      "d": 524391,
      "h": 21475360871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458983),
    {
      "p": [
        {
          "n": "resourceLocation",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524391,
      "h": 8590458983,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458983)
  ],
  "h": 524391,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 1,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `ResourceLocationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524391)
        
        
        //--TRIMMABLE-BOUNDARY-START(917607)
        $asm.$cls("$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute", ($self) => class RootNamespaceAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590852199)
            $ctor$2(/*string*/ rootNamespace)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852199);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(rootNamespace, "rootNamespace");
                    this.RootNamespace = rootNamespace;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852199)
            
            //--TRIMMABLE-BOUNDARY-START(21475754087)
            /*string*/ RootNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(21475754087)
            
            static $h = 917607;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475754087),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180786791,
        "f": 50331649
      },
      "n": "RootNamespace",
      "d": 917607,
      "h": 21475754087,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475754087)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852199),
    {
      "p": [
        {
          "n": "rootNamespace",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917607,
      "h": 8590852199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852199)
  ],
  "h": 917607,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 1,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `RootNamespaceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917607)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Localization.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))
//--TRIMMABLE-BOUNDARY-END(103)
