
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mela, $sttp, $sdd, $mela, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization", 
    {"h":55469,"f":"Microsoft.Extensions.Localization","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74055681,"c":4369022977,"a":[{"v":"Application localization services and default implementation based on ResourceManager to load localized assembly resources.","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"Microsoft .NET Extensions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Localization","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":92274689,"c":4387241985,"a":[{"v":"Microsoft.Extensions.Localization.Tests","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceStringProvider", ($self) => class IResourceStringProvider
        {
            static $h = 448685;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"p":[{"n":"culture","p":51183617},{"n":"throwOnMissing","p":262145}],"n":"GetAllResourceStrings","o":"Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings","d":448685,"h":4295415981,"f":16777473}],"h":448685}; }
            static get $fullName() { return `IResourceStringProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.IResourceNamesCache", ($self) => class IResourceNamesCache
        {
            static $h = 383149;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"p":[{"n":"name","p":1310721},{"n":"valueFactory","p":$.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h}],"n":"GetOrAdd","o":"Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd","d":383149,"h":4295350445,"f":16777473}],"h":383149}; }
            static get $fullName() { return `IResourceNamesCache`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.LocalizationOptions", ($self) => class LocalizationOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string*/ ResourcesPath = null;
            //default member initializer
            constructor()
            {
                super();
                this.ResourcesPath = $.$$.System.String.Empty;
            }
            static $h = 514221;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180383405,"f":50331649},"s":{"r":0,"d":0,"h":21475350701,"f":83886081},"n":"ResourcesPath","d":514221,"h":12885416109,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":514221,"h":4295481517,"f":16777217}],"h":514221}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizationOptions`; }
        });
        
        $asm.$cls("$mel.Resources", ($self) => class Resources
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$mel.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Localization", $.$mel.Resources.$type.Assembly);
                    $.$mel.Resources.s_resourceManager = temp;
                }
                return $.$mel.Resources.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mel.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mel.Resources.resourceCulture = value;
            }
            static /*string */ get Localization_MissingManifest()
            {
                return "The manifest '{0}' was not found.";
            }
            static /*string */ FormatLocalization_MissingManifest(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The manifest '{0}' was not found.", arg1);
            }
            static /*string */ get Localization_MissingManifest_Parent()
            {
                return "No manifests exist for the current culture.";
            }
            static /*string */ get Localization_TypeMustHaveTypeName()
            {
                return "Type '{0}' must have a non-null type name.";
            }
            static /*string */ FormatLocalization_TypeMustHaveTypeName(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Type '{0}' must have a non-null type name.", arg1);
            }
            static $h = 1038509;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":85393409,"g":{"r":0,"d":0,"h":17180907693,"f":50331688},"n":"ResourceManager","d":1038509,"h":12885940397,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":51183617,"g":{"r":0,"d":0,"h":25770842285,"f":50331688},"s":{"r":0,"d":0,"h":30065809581,"f":83886120},"n":"Culture","d":1038509,"h":21475874989,"f":2097192,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655744173,"f":50331688},"n":"Localization_MissingManifest","d":1038509,"h":34360776877,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":51540646061,"f":50331688},"n":"Localization_MissingManifest_Parent","d":1038509,"h":47245678765,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":60130580653,"f":50331688},"n":"Localization_TypeMustHaveTypeName","d":1038509,"h":55835613357,"f":2097192}],"m":[{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatLocalization_MissingManifest","d":1038509,"h":42950711469,"f":16777256},{"r":1310721,"p":[{"n":"arg1","p":131073}],"n":"FormatLocalization_TypeMustHaveTypeName","d":1038509,"h":64425547949,"f":16777256}],"l":[{"t":85393409,"n":"s_resourceManager","d":1038509,"h":4296005805,"f":4194338},{"t":51183617,"n":"resourceCulture","d":1038509,"h":8590973101,"f":4194338}],"h":1038509,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"System.Resources.Tools.StronglyTypedResourceBuilder","t":1310721},{"v":"17.0.0.0","t":1310721}]},{"t":37748737,"c":4332716033},{"t":88408065,"c":4383375361}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Resources`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.AssemblyWrapper", ($self) => class AssemblyWrapper extends $.$$.System.Object
        {
            $ctor$1(/*Assembly*/ assembly)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(assembly, "assembly");
                    this.Assembly = assembly;
                }
                return this;
            }
            /*Assembly*/ Assembly = null;
            /*string */ get FullName()
            {
                return this.Assembly.FullName;
            }
            /*Stream? */ GetManifestResourceStream(/*string*/ name)
            {
                return this.Assembly.GetManifestResourceStream(name);
            }
            static $h = 317613;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":73465857,"g":{"r":0,"d":0,"h":17180186797,"f":50331649},"n":"Assembly","d":317613,"h":12885219501,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":25770121389,"f":50331777},"n":"FullName","d":317613,"h":21475154093,"f":2097281}],"m":[{"r":62193665,"p":[{"n":"name","p":1310721}],"n":"GetManifestResourceStream","d":317613,"h":30065088685,"f":16777345}],"c":[{"p":[{"n":"assembly","p":73465857}],"n":".ctor","o":"$ctor$1","d":317613,"h":4295284909,"f":16777217}],"h":317613}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `AssemblyWrapper`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions", ($self) => class LocalizationServiceCollectionExtensions
        {
            static /*IServiceCollection */ AddLocalization$1(/*this IServiceCollection*/ services)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                return services;
            }
            static /*IServiceCollection */ AddLocalization(/*this IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(setupAction, "setupAction");
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices(services, setupAction);
                return services;
            }
            static /*void */ AddLocalizationServices$1(/*IServiceCollection*/ services)
            {
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory, services);
                $.$mxdi.Microsoft.Extensions.DependencyInjection.Extensions.ServiceCollectionDescriptorExtensions.TryAddTransient$1(services, $.$mela.Microsoft.Extensions.Localization.IStringLocalizer$$().$type, $.$mela.Microsoft.Extensions.Localization.StringLocalizer$$().$type);
            }
            static /*void */ AddLocalizationServices(/*IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                $.$mel.Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                $.$meo.Microsoft.Extensions.DependencyInjection.OptionsServiceCollectionExtensions.Configure($.$mel.Microsoft.Extensions.Localization.LocalizationOptions, services, setupAction);
            }
            static $h = 252077;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":786435,"p":[{"n":"services","p":786435}],"n":"AddLocalization","o":"@$1","d":252077,"h":4295219373,"f":16777249},{"r":786435,"p":[{"n":"services","p":786435},{"n":"setupAction","p":$.$$.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h}],"n":"AddLocalization","d":252077,"h":8590186669,"f":16777249},{"r":65537,"p":[{"n":"services","p":786435}],"n":"AddLocalizationServices","o":"@$1","d":252077,"h":12885153965,"f":16777256},{"r":65537,"p":[{"n":"services","p":786435},{"n":"setupAction","p":$.$$.System.Action$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h}],"n":"AddLocalizationServices","d":252077,"h":17180121261,"f":16777256}],"h":252077}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `LocalizationServiceCollectionExtensions`; }
        });
        
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper", ($self) => class ArgumentThrowHelper
        {
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            static /*void */ ThrowIfNullOrWhiteSpace(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(argument, "argument");
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(argument, paramName);
            }
            static $h = 186541;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1104045,"c":4296071341,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":186541,"h":4295153837,"f":16777249},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1104045,"c":4296071341,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrWhiteSpace","d":186541,"h":8590121133,"f":16777249}],"h":186541}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentThrowHelper`; }
        });
        
        $asm.$cls("$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper", ($self) => class ArgumentNullThrowHelper
        {
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            static $h = 121005;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":131073},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1104045,"c":4296071341,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNull","d":121005,"h":4295088301,"f":16777249},{"r":65537,"p":[{"n":"argument","p":1310721},{"n":"paramName","p":1310721,"f":65,"a":[{"t":1104045,"c":4296071341,"a":[{"v":"argument","t":1310721}]}]}],"n":"ThrowIfNullOrEmpty","d":121005,"h":8590055597,"f":16777249}],"h":121005}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `ArgumentNullThrowHelper`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceNamesCache", ($self) => class ResourceNamesCache extends $.$$.System.Object
        {
            /*ConcurrentDictionary<string, IList<string>?>*/ _cache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IList<string>? */ GetOrAdd(/*string*/ name, /*Func<string, IList<string>?>*/ valueFactory)
            {
                return this._cache.GetOrAdd(name, valueFactory);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceNamesCache.GetOrAdd(string, System.Func<string, System.Collections.Generic.IList<string>?>)
            Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd()
            {
                return this.GetOrAdd(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._cache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)))().$ctor$1();
            }
            static $h = 907437;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"p":[{"n":"name","p":1310721},{"n":"valueFactory","p":$.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h}],"n":"GetOrAdd","d":907437,"h":12885809325,"f":16777217}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)).$h,"n":"_cache","d":907437,"h":4295874733,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":907437,"h":8590842029,"f":16777217}],"i":[383149],"h":907437}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceNamesCache ]; }
            static get $fullName() { return `ResourceNamesCache`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer", ($self) => class ResourceManagerStringLocalizer extends $.$$.System.Object
        {
            static $_Log;
            static get Log()
            {
                let $cls = $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer;
                return $cls.$_Log ??= $asm.$ncls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log", ($self) => class Log
                {
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.String, global::System.Globalization.CultureInfo, global::System.Exception?>*/ static __SearchedLocationCallback = null;
                    static /*void */ SearchedLocation(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ key, /*global::System.String*/ locationSearched, /*global::System.Globalization.CultureInfo*/ culture)
                    {
                        if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.__SearchedLocationCallback.Invoke(logger, key, locationSearched, culture, null);
                        }
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.__SearchedLocationCallback = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$8($.$$.System.String, $.$$.System.String, $.$$.System.Globalization.CultureInfo, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$3(1, "SearchedLocation"), "ResourceManagerStringLocalizer searched for '{Key}' in '{LocationSearched}' with culture '{Culture}'.", (() =>
                            {
                                //new $.$mela.Microsoft.Extensions.Logging.LogDefineOptions()
                                const $t1 = $.$mela.Microsoft.Extensions.Logging.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                        }
                    }
                    static $h = 710829;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525},{"n":"key","p":1310721},{"n":"locationSearched","p":1310721},{"n":"culture","p":51183617}],"n":"SearchedLocation","d":710829,"h":8590645421,"f":16777249,"a":[{"t":2228245,"c":8592162837,"a":[{"v":1,"t":655361},{"v":1,"t":2293781},{"v":"ResourceManagerStringLocalizer searched for \u0027{Key}\u0027 in \u0027{LocationSearched}\u0027 with culture \u0027{Culture}\u0027.","t":1310721}],"n":[{"n":"EventName","v":"SearchedLocation","t":1310721}]},{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"l":[{"t":$.$$.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$$.System.String, $.$$.System.String, $.$$.System.Globalization.CultureInfo, $.$$.System.Exception).$h,"n":"__SearchedLocationCallback","d":710829,"h":4295678125,"f":4194338,"a":[{"t":23592961,"c":12908494849,"a":[{"v":"Microsoft.Extensions.Logging.Generators","t":1310721},{"v":"42.42.42.42","t":1310721}]}]}],"d":645293,"h":710829}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            /*ConcurrentDictionary<string, object?>*/ _missingManifestCache = null;
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ResourceManager*/ _resourceManager = null;
            /*IResourceStringProvider*/ _resourceStringProvider = null;
            /*string*/ _resourceBaseName = null;
            /*ILogger*/ _logger = null;
            $ctor$1(/*ResourceManager*/ resourceManager, /*Assembly*/ resourceAssembly, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$2(resourceManager, new $.$mel.Microsoft.Extensions.Localization.AssemblyWrapper().$ctor$1(resourceAssembly), baseName, resourceNamesCache, logger);
                {
                }
                return this;
            }
            $ctor$2(/*ResourceManager*/ resourceManager, /*AssemblyWrapper*/ resourceAssemblyWrapper, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$3(resourceManager, new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider().$ctor$1(resourceNamesCache, resourceManager, resourceAssemblyWrapper.Assembly, baseName), baseName, resourceNamesCache, logger);
                {
                }
                return this;
            }
            $ctor$3(/*ResourceManager*/ resourceManager, /*IResourceStringProvider*/ resourceStringProvider, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceManager, "resourceManager");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceStringProvider, "resourceStringProvider");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceNamesCache, "resourceNamesCache");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    this._resourceStringProvider = resourceStringProvider;
                    this._resourceManager = resourceManager;
                    this._resourceBaseName = baseName;
                    this._resourceNamesCache = resourceNamesCache;
                    this._logger = logger;
                }
                return this;
            }
            /*LocalizedString*/ get_Item$1(/*string*/ name)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value = this.GetStringSafely(name, null);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value ?? name, $.$$.System.String.op_Equality(value, null), this._resourceBaseName);
            }
            /*LocalizedString*/ get_Item(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let format = this.GetStringSafely(name, null);
                /*var*/ let value = $.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.CurrentCulture, format ?? name, $arguments);
                return new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value, $.$$.System.String.op_Equality(format, null), this._resourceBaseName);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings$1(/*bool*/ includeParentCultures)
            {
                return this.GetAllStrings(includeParentCultures, $.$$.System.Globalization.CultureInfo.CurrentUICulture);
            }
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures, /*CultureInfo*/ culture)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(culture, "culture");
                    /*var*/ let resourceNames = includeParentCultures ? this.GetResourceNamesFromCultureHierarchy(culture) : this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(culture, true);
                    var $en3 = resourceNames ?? $.$sl.System.Linq.Enumerable.Empty($.$$.System.String).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var name = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*var*/ let value = this.GetStringSafely(name, culture);
                            yield new $.$mela.Microsoft.Extensions.Localization.LocalizedString().$ctor$1(name, value ?? name, $.$$.System.String.op_Equality(value, null), this._resourceBaseName);
                        }
                    }
                }.bind(this));
            }
            /*string? */ GetStringSafely(/*string*/ name, /*CultureInfo?*/ culture)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let keyCulture = culture ?? $.$$.System.Globalization.CultureInfo.CurrentUICulture;
                /*var*/ let cacheKey = `name=${name}&culture=${keyCulture.Name}`;
                $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer.Log.SearchedLocation(this._logger, name, this._resourceBaseName, keyCulture);
                if (this._missingManifestCache.ContainsKey(cacheKey))
                {
                    return null;
                }
                try
                {
                    return this._resourceManager.GetString(name, culture);
                }
                catch($e)
                {
                    this._missingManifestCache.TryAdd(cacheKey, null);
                    return null;
                }
            }
            /*IEnumerable<string> */ GetResourceNamesFromCultureHierarchy(/*CultureInfo*/ startingCulture)
            {
                /*var*/ let currentCulture = startingCulture;
                /*var*/ let resourceNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$1();
                /*var*/ let hasAnyCultures = false;
                while(true)
                {
                    /*var*/ let cultureResourceNames = this._resourceStringProvider.Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings(currentCulture, false);
                    if (cultureResourceNames !== null)
                    {
                        var $en4 = cultureResourceNames.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var resourceName = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                resourceNames.Add(resourceName);
                            }
                        }
                        hasAnyCultures = true;
                    }
                    if (currentCulture === currentCulture.Parent)
                    {
                        break;
                    }
                    currentCulture = currentCulture.Parent;
                }
                if (!hasAnyCultures)
                {
                    throw new $.$$.System.Resources.MissingManifestResourceException().$ctor$12($.$mel.Resources.Localization_MissingManifest_Parent);
                }
                return resourceNames;
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item$1()
            {
                return this.get_Item$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            Microsoft$Extensions$Localization$IStringLocalizer$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            Microsoft$Extensions$Localization$IStringLocalizer$GetAllStrings()
            {
                return this.GetAllStrings$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._missingManifestCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
            }
            static $h = 645293;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":362115,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":51540252845,"f":50331777},"n":"Item","o":"@$3","d":645293,"h":47245285549,"f":2097281},{"p":362115,"i":[{"n":"name","p":1310721},{"n":"arguments","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"g":{"r":0,"d":0,"h":60130187437,"f":50331777},"n":"Item","o":"@$2","d":645293,"h":55835220141,"f":2097281}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145}],"n":"GetAllStrings","o":"@$1","d":645293,"h":64425154733,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Localization.LocalizedString).$h,"p":[{"n":"includeParentCultures","p":262145},{"n":"culture","p":51183617}],"n":"GetAllStrings","d":645293,"h":68720122029,"f":16777220},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"culture","p":51183617}],"n":"GetStringSafely","d":645293,"h":73015089325,"f":16777220},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,"p":[{"n":"startingCulture","p":51183617}],"n":"GetResourceNamesFromCultureHierarchy","d":645293,"h":77310056621,"f":16777218}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$$.System.Object).$h,"n":"_missingManifestCache","d":645293,"h":8590579885,"f":4194306},{"t":383149,"n":"_resourceNamesCache","d":645293,"h":12885547181,"f":4194306},{"t":85393409,"n":"_resourceManager","d":645293,"h":17180514477,"f":4194306},{"t":448685,"n":"_resourceStringProvider","d":645293,"h":21475481773,"f":4194306},{"t":1310721,"n":"_resourceBaseName","d":645293,"h":25770449069,"f":4194306},{"t":917525,"n":"_logger","d":645293,"h":30065416365,"f":4194306}],"c":[{"p":[{"n":"resourceManager","p":85393409},{"n":"resourceAssembly","p":73465857},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":383149},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$1","d":645293,"h":34360383661,"f":16777217},{"p":[{"n":"resourceManager","p":85393409},{"n":"resourceAssemblyWrapper","p":317613},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":383149},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$2","d":645293,"h":38655350957,"f":16777224},{"p":[{"n":"resourceManager","p":85393409},{"n":"resourceStringProvider","p":448685},{"n":"baseName","p":1310721},{"n":"resourceNamesCache","p":383149},{"n":"logger","p":917525}],"n":".ctor","o":"$ctor$3","d":645293,"h":42950318253,"f":16777224}],"i":[165507],"j":[710829],"h":645293}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizer ]; }
            static get $fullName() { return `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringProvider", ($self) => class ResourceManagerStringProvider extends $.$$.System.Object
        {
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ResourceManager*/ _resourceManager = null;
            /*Assembly*/ _assembly = null;
            /*string*/ _resourceBaseName = null;
            $ctor$1(/*IResourceNamesCache*/ resourceCache, /*ResourceManager*/ resourceManager, /*Assembly*/ assembly, /*string*/ baseName)
            {
                super.$ctor();
                {
                    this._resourceManager = resourceManager;
                    this._resourceNamesCache = resourceCache;
                    this._assembly = assembly;
                    this._resourceBaseName = baseName;
                }
                return this;
            }
            /*string */ GetResourceCacheKey(/*CultureInfo*/ culture)
            {
                /*var*/ let resourceName = this._resourceManager.BaseName;
                return `Culture=${culture.Name};resourceName=${resourceName};Assembly=${this._assembly.FullName}`;
            }
            /*string */ GetResourceName(/*CultureInfo*/ culture)
            {
                /*var*/ let resourceStreamName = this._resourceBaseName;
                if (!$.$$.System.String.IsNullOrEmpty(culture.Name))
                {
                    resourceStreamName += "." + culture.Name;
                }
                resourceStreamName += ".resources";
                return resourceStreamName;
            }
            /*IList<string>? */ GetAllResourceStrings(/*CultureInfo*/ culture, /*bool*/ throwOnMissing)
            {
                /*var*/ let cacheKey = this.GetResourceCacheKey(culture);
                return this._resourceNamesCache.Microsoft$Extensions$Localization$IResourceNamesCache$GetOrAdd(cacheKey, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.Collections.Generic.IList$$($.$$.System.String)))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let resourceSet = this._resourceManager.GetResourceSet(culture, true, false);
                    if (resourceSet === null)
                    {
                        if (throwOnMissing)
                        {
                            throw new $.$$.System.Resources.MissingManifestResourceException().$ctor$12($.$mel.Resources.FormatLocalization_MissingManifest(this.GetResourceName(culture)));
                        }
                        else 
                        {
                            return null;
                        }
                    }
                    /*var*/ let names = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    var $en3 = resourceSet.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var entry = $en3.System$Collections$IEnumerator$Current;
                        {
                            let key;
                            if ($.$is((entry?.Key ?? null), $.$$.System.String, { set $v(v){ key = v; } }))
                            {
                                names.Add(key);
                            }
                        }
                    }
                    return names;
                }, {"r":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"p":[{"n":"_","p":1310721}],"n":"","d":841901,"h":0,"f":17825794}));
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceStringProvider.GetAllResourceStrings(System.Globalization.CultureInfo, bool)
            Microsoft$Extensions$Localization$IResourceStringProvider$GetAllResourceStrings()
            {
                return this.GetAllResourceStrings(...arguments);
            }
            static $h = 841901;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"culture","p":51183617}],"n":"GetResourceCacheKey","d":841901,"h":25770645677,"f":16777218},{"r":1310721,"p":[{"n":"culture","p":51183617}],"n":"GetResourceName","d":841901,"h":30065612973,"f":16777218},{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,"p":[{"n":"culture","p":51183617},{"n":"throwOnMissing","p":262145}],"n":"GetAllResourceStrings","d":841901,"h":34360580269,"f":16777217}],"l":[{"t":383149,"n":"_resourceNamesCache","d":841901,"h":4295809197,"f":4194306},{"t":85393409,"n":"_resourceManager","d":841901,"h":8590776493,"f":4194306},{"t":73465857,"n":"_assembly","d":841901,"h":12885743789,"f":4194306},{"t":1310721,"n":"_resourceBaseName","d":841901,"h":17180711085,"f":4194306}],"c":[{"p":[{"n":"resourceCache","p":383149},{"n":"resourceManager","p":85393409},{"n":"assembly","p":73465857},{"n":"baseName","p":1310721}],"n":".ctor","o":"$ctor$1","d":841901,"h":21475678381,"f":16777217}],"i":[448685],"h":841901}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.Microsoft.Extensions.Localization.IResourceStringProvider ]; }
            static get $fullName() { return `ResourceManagerStringProvider`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory", ($self) => class ResourceManagerStringLocalizerFactory extends $.$$.System.Object
        {
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            /*ConcurrentDictionary<string, ResourceManagerStringLocalizer>*/ _localizerCache = null;
            /*string*/ _resourcesRelativePath = null;
            /*ILoggerFactory*/ _loggerFactory = null;
            $ctor$1(/*IOptions<LocalizationOptions>*/ localizationOptions, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(localizationOptions, "localizationOptions");
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(loggerFactory, "loggerFactory");
                    this._resourcesRelativePath = localizationOptions.Microsoft$Extensions$Options$IOptions$$$Value.ResourcesPath ?? $.$$.System.String.Empty;
                    this._loggerFactory = loggerFactory;
                    if (!$.$$.System.String.IsNullOrEmpty(this._resourcesRelativePath))
                    {
                        this._resourcesRelativePath = $.$$.System.String.Replace.call($.$$.System.String.Replace.call(this._resourcesRelativePath, $.$$.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46), $.$$.System.IO.Path.DirectorySeparatorChar, /*.*/ 46) + ".";
                    }
                }
                return this;
            }
            /*string */ GetResourcePrefix$1(/*TypeInfo*/ typeInfo)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                return this.GetResourcePrefix(typeInfo, this.GetRootNamespace(typeInfo.Assembly), this.GetResourcePath(typeInfo.Assembly));
            }
            /*string */ GetResourcePrefix(/*TypeInfo*/ typeInfo, /*string?*/ baseNamespace, /*string?*/ resourcesRelativePath)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(typeInfo.FullName, "typeInfo.FullName");
                if ($.$$.System.String.IsNullOrEmpty(resourcesRelativePath))
                {
                    return typeInfo.FullName;
                }
                else 
                {
                    return baseNamespace + "." + resourcesRelativePath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(typeInfo.FullName, baseNamespace + ".");
                }
            }
            /*string */ GetResourcePrefix$3(/*string*/ baseResourceName, /*string*/ baseNamespace)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseResourceName, "baseResourceName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                /*var*/ let assemblyName = new $.$$.System.Reflection.AssemblyName().$ctor$2(baseNamespace);
                /*var*/ let assembly = $.$$.System.Reflection.Assembly.Load$3(assemblyName);
                /*var*/ let rootNamespace = this.GetRootNamespace(assembly);
                /*var*/ let resourceLocation = this.GetResourcePath(assembly);
                /*var*/ let locationPath = rootNamespace + "." + resourceLocation;
                baseResourceName = locationPath + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseResourceName, baseNamespace + ".");
                return baseResourceName;
            }
            /*IStringLocalizer */ Create$1(/*Type*/ resourceSource)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(resourceSource, "resourceSource");
                /*var*/ let localizer;
                if (!this._localizerCache.TryGetValue(resourceSource.AssemblyQualifiedName, $.$ref(() => localizer, ($v) => localizer = $v, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer)))
                {
                    /*var*/ let typeInfo = $.$$.System.Reflection.IntrospectionExtensions.GetTypeInfo(resourceSource);
                    /*var*/ let baseName = this.GetResourcePrefix$1(typeInfo);
                    /*var*/ let assembly = typeInfo.Assembly;
                    localizer = this.CreateResourceManagerStringLocalizer(assembly, baseName);
                    this._localizerCache.set_Item(resourceSource.AssemblyQualifiedName, localizer);
                }
                return localizer;
            }
            /*IStringLocalizer */ Create(/*string*/ baseName, /*string*/ location)
            {
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                $.$mel.Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper.ThrowIfNull(location, "location");
                return this._localizerCache.GetOrAdd(`B=${baseName},L=${location}`, new ($.$$.System.Func$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let assemblyName = new $.$$.System.Reflection.AssemblyName().$ctor$2(location);
                    /*var*/ let assembly = $.$$.System.Reflection.Assembly.Load$3(assemblyName);
                    baseName = this.GetResourcePrefix$3(baseName, location);
                    return this.CreateResourceManagerStringLocalizer(assembly, baseName);
                }, {"r":645293,"p":[{"n":"_","p":1310721}],"n":"","d":776365,"h":0,"f":17825794}));
            }
            /*ResourceManagerStringLocalizer */ CreateResourceManagerStringLocalizer(/*Assembly*/ assembly, /*string*/ baseName)
            {
                return new $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer().$ctor$1(new $.$$.System.Resources.ResourceManager().$ctor$3(baseName, assembly), assembly, baseName, this._resourceNamesCache, $.$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions.CreateLogger$1($.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer, this._loggerFactory));
            }
            /*string */ GetResourcePrefix$2(/*string*/ location, /*string*/ baseName, /*string*/ resourceLocation)
            {
                return location + "." + resourceLocation + $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory.TrimPrefix(baseName, location + ".");
            }
            /*ResourceLocationAttribute? */ GetResourceLocationAttribute(/*Assembly*/ assembly)
            {
                return $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute, assembly);
            }
            /*RootNamespaceAttribute? */ GetRootNamespaceAttribute(/*Assembly*/ assembly)
            {
                return $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute, assembly);
            }
            /*string? */ GetRootNamespace(/*Assembly*/ assembly)
            {
                /*var*/ let rootNamespaceAttribute = this.GetRootNamespaceAttribute(assembly);
                if (rootNamespaceAttribute !== null)
                {
                    return rootNamespaceAttribute.RootNamespace;
                }
                return assembly.GetName().Name;
            }
            /*string */ GetResourcePath(/*Assembly*/ assembly)
            {
                /*var*/ let resourceLocationAttribute = this.GetResourceLocationAttribute(assembly);
                /*var*/ let resourceLocation = resourceLocationAttribute === null ? this._resourcesRelativePath : resourceLocationAttribute.ResourceLocation + ".";
                resourceLocation = $.$$.System.String.Replace.call($.$$.System.String.Replace.call(resourceLocation, $.$$.System.IO.Path.DirectorySeparatorChar, /*.*/ 46), $.$$.System.IO.Path.AltDirectorySeparatorChar, /*.*/ 46);
                return resourceLocation;
            }
            static /*string? */ TrimPrefix(/*string*/ name, /*string*/ prefix)
            {
                if ($.$$.System.String.StartsWith$2.call(name, prefix, 4/*StringComparison.Ordinal*/))
                {
                    return $.$$.System.String.Substring$1.call(name, prefix.length);
                }
                return name;
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(System.Type)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create$1()
            {
                return this.Create$1(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(string, string)
            Microsoft$Extensions$Localization$IStringLocalizerFactory$Create()
            {
                return this.Create(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._resourceNamesCache = new $.$mel.Microsoft.Extensions.Localization.ResourceNamesCache().$ctor$1();
                this._localizerCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer))().$ctor$1();
            }
            static $h = 776365;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"typeInfo","p":84410369}],"n":"GetResourcePrefix","o":"@$1","d":776365,"h":25770580141,"f":16777348},{"r":1310721,"p":[{"n":"typeInfo","p":84410369},{"n":"baseNamespace","p":1310721},{"n":"resourcesRelativePath","p":1310721}],"n":"GetResourcePrefix","d":776365,"h":30065547437,"f":16777348},{"r":1310721,"p":[{"n":"baseResourceName","p":1310721},{"n":"baseNamespace","p":1310721}],"n":"GetResourcePrefix","o":"@$3","d":776365,"h":34360514733,"f":16777348},{"r":165507,"p":[{"n":"resourceSource","p":142475265}],"n":"Create","o":"@$1","d":776365,"h":38655482029,"f":16777217},{"r":165507,"p":[{"n":"baseName","p":1310721},{"n":"location","p":1310721}],"n":"Create","d":776365,"h":42950449325,"f":16777217},{"r":645293,"p":[{"n":"assembly","p":73465857},{"n":"baseName","p":1310721}],"n":"CreateResourceManagerStringLocalizer","d":776365,"h":47245416621,"f":16777348},{"r":1310721,"p":[{"n":"location","p":1310721},{"n":"baseName","p":1310721},{"n":"resourceLocation","p":1310721}],"n":"GetResourcePrefix","o":"@$2","d":776365,"h":51540383917,"f":16777348},{"r":579757,"p":[{"n":"assembly","p":73465857}],"n":"GetResourceLocationAttribute","d":776365,"h":55835351213,"f":16777348},{"r":972973,"p":[{"n":"assembly","p":73465857}],"n":"GetRootNamespaceAttribute","d":776365,"h":60130318509,"f":16777348},{"r":1310721,"p":[{"n":"assembly","p":73465857}],"n":"GetRootNamespace","d":776365,"h":64425285805,"f":16777218},{"r":1310721,"p":[{"n":"assembly","p":73465857}],"n":"GetResourcePath","d":776365,"h":68720253101,"f":16777218},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"prefix","p":1310721}],"n":"TrimPrefix","d":776365,"h":73015220397,"f":16777250}],"l":[{"t":383149,"n":"_resourceNamesCache","d":776365,"h":4295743661,"f":4194306},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mel.Microsoft.Extensions.Localization.ResourceManagerStringLocalizer).$h,"n":"_localizerCache","d":776365,"h":8590710957,"f":4194306},{"t":1310721,"n":"_resourcesRelativePath","d":776365,"h":12885678253,"f":4194306},{"t":1048597,"n":"_loggerFactory","d":776365,"h":17180645549,"f":4194306}],"c":[{"p":[{"n":"localizationOptions","p":$.$meo.Microsoft.Extensions.Options.IOptions$$($.$mel.Microsoft.Extensions.Localization.LocalizationOptions).$h},{"n":"loggerFactory","p":1048597}],"n":".ctor","o":"$ctor$1","d":776365,"h":21475612845,"f":16777217}],"i":[296579],"h":776365}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Localization.IStringLocalizerFactory ]; }
            static get $fullName() { return `ResourceManagerStringLocalizerFactory`; }
        });
        
        $asm.$cls("$mel.System.Runtime.CompilerServices.CallerArgumentExpressionAttribute", ($self) => class CallerArgumentExpressionAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ parameterName)
            {
                super.$ctor$1();
                {
                    this.ParameterName = parameterName;
                }
                return this;
            }
            /*string*/ ParameterName = null;
            static $h = 1104045;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180973229,"f":50331649},"n":"ParameterName","d":1104045,"h":12886005933,"f":2097153}],"c":[{"p":[{"n":"parameterName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1104045,"h":4296071341,"f":16777217}],"h":1104045,"a":[{"t":14745601,"c":21489582081,"a":[{"v":2048,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `CallerArgumentExpressionAttribute`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.ResourceLocationAttribute", ($self) => class ResourceLocationAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ resourceLocation)
            {
                super.$ctor$1();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(resourceLocation, "resourceLocation");
                    this.ResourceLocation = resourceLocation;
                }
                return this;
            }
            /*string*/ ResourceLocation = null;
            static $h = 579757;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180448941,"f":50331649},"n":"ResourceLocation","d":579757,"h":12885481645,"f":2097153}],"c":[{"p":[{"n":"resourceLocation","p":1310721}],"n":".ctor","o":"$ctor$2","d":579757,"h":4295547053,"f":16777217}],"h":579757,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `ResourceLocationAttribute`; }
        });
        
        $asm.$cls("$mel.Microsoft.Extensions.Localization.RootNamespaceAttribute", ($self) => class RootNamespaceAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ rootNamespace)
            {
                super.$ctor$1();
                {
                    $.$mel.Microsoft.AspNetCore.Shared.ArgumentThrowHelper.ThrowIfNullOrEmpty(rootNamespace, "rootNamespace");
                    this.RootNamespace = rootNamespace;
                }
                return this;
            }
            /*string*/ RootNamespace = null;
            static $h = 972973;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180842157,"f":50331649},"n":"RootNamespace","d":972973,"h":12885874861,"f":2097153}],"c":[{"p":[{"n":"rootNamespace","p":1310721}],"n":".ctor","o":"$ctor$2","d":972973,"h":4295940269,"f":16777217}],"h":972973,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `RootNamespaceAttribute`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Localization.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"))