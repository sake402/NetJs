
//--TRIMMABLE-BOUNDARY-START(110)
(async function () {
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $mela, $sttp, $sdd, $mexla, $mep, $scn, $scp, $scs, $sdp, $mwp, $scsl, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $str, $sdts, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct, $sca, $meo) {
    "use strict";
    let _;
    let $enUcVc;
    let $oqzxuj;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Localization", 
    {
  "h": 110,
  "f": "Microsoft.Extensions.Localization",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Application localization services and default implementation based on ResourceManager to load localized assembly resources.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft .NET Extensions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Localization",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "Microsoft.Extensions.Localization.Tests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(393326)
        $asm.$cls(`$mel.MEL.IResourceStringProvider`, ($self) => class IResourceStringProvider
        {
            static $h = 393326;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360622),
    {
      "r": $.$$.SCG.IList$$($.$$.S.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 84738049
        },
        {
          "n": "throwOnMissing",
          "p": 262145
        }
      ],
      "n": "GetAllResourceStrings",
      "o": "MEL$IResourceStringProvider$GetAllResourceStrings",
      "d": 393326,
      "h": 4295360622,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295360622)
  ],
  "h": 393326
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.IResourceStringProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}IResourceStringProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393326)
        
        

        //--TRIMMABLE-BOUNDARY-START(327790)
        $asm.$cls(`$mel.MEL.IResourceNamesCache`, ($self) => class IResourceNamesCache
        {
            static $h = 327790;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295086),
    {
      "r": $.$$.SCG.IList$$($.$$.S.String).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "valueFactory",
          "p": $.$$.S.Func$$$($.$$.S.String, $.$$.SCG.IList$$($.$$.S.String)).$h
        }
      ],
      "n": "GetOrAdd",
      "o": "MEL$IResourceNamesCache$GetOrAdd",
      "d": 327790,
      "h": 4295295086,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295086)
  ],
  "h": 327790
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.IResourceNamesCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}IResourceNamesCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327790)
        
        

        //--TRIMMABLE-BOUNDARY-START(131182)
        $asm.$cls(`$mel.MAS.ArgumentThrowHelper`, ($self) => class ArgumentThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295098478)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098478)
            
            //--TRIMMABLE-BOUNDARY-START(8590065774)
            static /*void */ ThrowIfNullOrWhiteSpace(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(argument, "argument");
                $.$$.S.ArgumentException.ThrowIfNullOrWhiteSpace(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065774)
            
            static $h = 131182;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098478),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 131182,
      "h": 4295098478,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098478),
//--TRIMMABLE-BOUNDARY-START(8590065774),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrWhiteSpace",
      "d": 131182,
      "h": 8590065774,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590065774)
  ],
  "h": 131182
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131182)
        
        

        //--TRIMMABLE-BOUNDARY-START(196718)
        $asm.$cls(`$mel.MED.LocalizationServiceCollectionExtensions`, ($self) => class LocalizationServiceCollectionExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8590131310)
            static /*IServiceCollection */ AddLocalization$1(/*this IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.MED.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131310)
            
            //--TRIMMABLE-BOUNDARY-START(4295164014)
            static /*IServiceCollection */ AddLocalization(/*this IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295164014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(services, "services");
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(setupAction, "setupAction");
                $.$meo.MED.OptionsServiceCollectionExtensions.AddOptions(services);
                $.$mel.MED.LocalizationServiceCollectionExtensions.AddLocalizationServices(services, setupAction);
                return services;
            }
            //--TRIMMABLE-BOUNDARY-END(4295164014)
            
            //--TRIMMABLE-BOUNDARY-START(17180065902)
            static /*void */ AddLocalizationServices$1(/*IServiceCollection*/ services)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddSingleton$3($.$mela.MEL.IStringLocalizerFactory, $.$mel.MEL.ResourceManagerStringLocalizerFactory, services);
                $.$mxdi.MEDE.ServiceCollectionDescriptorExtensions.TryAddTransient$1(services, $.$mela.MEL.IStringLocalizer$$().$type, $.$mela.MEL.StringLocalizer$$().$type);
            }
            //--TRIMMABLE-BOUNDARY-END(17180065902)
            
            //--TRIMMABLE-BOUNDARY-START(12885098606)
            static /*void */ AddLocalizationServices(/*IServiceCollection*/ services, /*Action<LocalizationOptions>*/ setupAction)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MED.LocalizationServiceCollectionExtensions.AddLocalizationServices$1(services);
                $.$meo.MED.OptionsServiceCollectionExtensions.Configure($.$mel.MEL.LocalizationOptions, services, setupAction);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098606)
            
            static $h = 196718;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131310),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLocalization",
      "o": "@$1",
      "d": 196718,
      "h": 8590131310,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590131310),
//--TRIMMABLE-BOUNDARY-START(4295164014),
    {
      "r": 786522,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.S.Action$$($.$mel.MEL.LocalizationOptions).$h
        }
      ],
      "n": "AddLocalization",
      "d": 196718,
      "h": 4295164014,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295164014),
//--TRIMMABLE-BOUNDARY-START(17180065902),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        }
      ],
      "n": "AddLocalizationServices",
      "o": "@$1",
      "d": 196718,
      "h": 17180065902,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180065902),
//--TRIMMABLE-BOUNDARY-START(12885098606),
    {
      "r": 65537,
      "p": [
        {
          "n": "services",
          "p": 786522
        },
        {
          "n": "setupAction",
          "p": $.$$.S.Action$$($.$mel.MEL.LocalizationOptions).$h
        }
      ],
      "n": "AddLocalizationServices",
      "d": 196718,
      "h": 12885098606,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885098606)
  ],
  "h": 196718
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.DependencyInjection.LocalizationServiceCollectionExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}DependencyInjection${separator}LocalizationServiceCollectionExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196718)
        
        

        //--TRIMMABLE-BOUNDARY-START(262254)
        $asm.$cls(`$mel.MEL.AssemblyWrapper`, ($self) => class AssemblyWrapper extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196846)
            $ctor$1(/*Assembly*/ assembly)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196846);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(assembly, "assembly");
                    this.Assembly = assembly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196846)
            
            //--TRIMMABLE-BOUNDARY-START(12885164142)
            /*Assembly*/ Assembly = null;
            //--TRIMMABLE-BOUNDARY-END(12885164142)
            
            //--TRIMMABLE-BOUNDARY-START(17180131438)
            /*string */ get FullName()
            {
                return this.Assembly.FullName;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131438)
            
            //--TRIMMABLE-BOUNDARY-START(38654967918)
            /*Stream? */ GetManifestResourceStream(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654967918);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Assembly.GetManifestResourceStream(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967918)
            
            static $h = 262254;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885164142),
    {
      "p": 107020289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770066030,
        "f": 50331649
      },
      "n": "Assembly",
      "d": 262254,
      "h": 12885164142,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885164142),
//--TRIMMABLE-BOUNDARY-START(17180131438),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000622,
        "f": 50331777
      },
      "n": "FullName",
      "d": 262254,
      "h": 17180131438,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17180131438)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654967918),
    {
      "r": 95748097,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetManifestResourceStream",
      "d": 262254,
      "h": 38654967918,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38654967918)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196846),
    {
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262254,
      "h": 8590196846,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196846)
  ],
  "h": 262254
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.AssemblyWrapper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}AssemblyWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262254)
        
        

        //--TRIMMABLE-BOUNDARY-START(458862)
        $asm.$cls(`$mel.MEL.LocalizationOptions`, ($self) => class LocalizationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590393454)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393454);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393454)
            
            //--TRIMMABLE-BOUNDARY-START(21475295342)
            /*string*/ ResourcesPath = null;
            //--TRIMMABLE-BOUNDARY-END(21475295342)
            
            //--TRIMMABLE-BOUNDARY-START(8590393454)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590393454)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475295342)
                this.ResourcesPath = $.$$.S.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(21475295342)
                
            }
            static $h = 458862;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475295342),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180328046,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065229934,
        "f": 83886081
      },
      "n": "ResourcesPath",
      "d": 458862,
      "h": 21475295342,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475295342)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393454),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458862,
      "h": 8590393454,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393454)
  ],
  "h": 458862
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.LocalizationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}LocalizationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458862)
        
        

        //--TRIMMABLE-BOUNDARY-START(65646)
        $asm.$cls(`$mel.MAS.ArgumentNullThrowHelper`, ($self) => class ArgumentNullThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295032942)
            static /*void */ ThrowIfNull(/*object?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(4295032942)
            
            //--TRIMMABLE-BOUNDARY-START(8590000238)
            static /*void */ ThrowIfNullOrEmpty(/*string?*/ argument, /*string?*/ paramName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(argument, paramName);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000238)
            
            static $h = 65646;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032942),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 131073
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNull",
      "d": 65646,
      "h": 4295032942,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032942),
//--TRIMMABLE-BOUNDARY-START(8590000238),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1310721
        },
        {
          "n": "paramName",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "argument",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "ThrowIfNullOrEmpty",
      "d": 65646,
      "h": 8590000238,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000238)
  ],
  "h": 65646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.AspNetCore.Shared.ArgumentNullThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}AspNetCore${separator}Shared${separator}ArgumentNullThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65646)
        
        

        //--TRIMMABLE-BOUNDARY-START(983150)
        $asm.$cls(`$mel.Resources`, ($self) => class Resources
        {
            //--TRIMMABLE-BOUNDARY-START(81605361774)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(81605361774)
            
            //--TRIMMABLE-BOUNDARY-START(73015427182)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(73015427182)
            
            //--TRIMMABLE-BOUNDARY-START(77310394478)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$mel.Resources.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("Microsoft.Extensions.Localization", $.$mel.Resources.$type.Assembly);
                    $.$mel.Resources.s_resourceManager = temp;
                }
                return $.$mel.Resources.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(77310394478)
            
            //--TRIMMABLE-BOUNDARY-START(4295950446)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mel.Resources.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296366);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.Resources.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950446)
            
            //--TRIMMABLE-BOUNDARY-START(60130525294)
            static /*string */ get Localization_MissingManifest()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The manifest '{0}' was not found.";
            }
            //--TRIMMABLE-BOUNDARY-END(60130525294)
            
            //--TRIMMABLE-BOUNDARY-START(8590917742)
            static /*string */ FormatLocalization_MissingManifest(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The manifest '{0}' was not found.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917742)
            
            //--TRIMMABLE-BOUNDARY-START(64425492590)
            static /*string */ get Localization_MissingManifest_Parent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754222);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "No manifests exist for the current culture.";
            }
            //--TRIMMABLE-BOUNDARY-END(64425492590)
            
            //--TRIMMABLE-BOUNDARY-START(68720459886)
            static /*string */ get Localization_TypeMustHaveTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Type '{0}' must have a non-null type name.";
            }
            //--TRIMMABLE-BOUNDARY-END(68720459886)
            
            //--TRIMMABLE-BOUNDARY-START(12885885038)
            static /*string */ FormatLocalization_TypeMustHaveTypeName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885885038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Type '{0}' must have a non-null type name.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(12885885038)
            
            static $h = 983150;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310394478),
    {
      "p": 123535361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557998,
        "f": 50331688
      },
      "n": "ResourceManager",
      "d": 983150,
      "h": 77310394478,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310394478),
//--TRIMMABLE-BOUNDARY-START(4295950446),
    {
      "p": 84738049,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475819630,
        "f": 50331688
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195296366,
        "f": 83886120
      },
      "n": "Culture",
      "d": 983150,
      "h": 4295950446,
      "f": 2097192,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295950446),
//--TRIMMABLE-BOUNDARY-START(60130525294),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655688814,
        "f": 50331688
      },
      "n": "Localization_MissingManifest",
      "d": 983150,
      "h": 60130525294,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60130525294),
//--TRIMMABLE-BOUNDARY-START(64425492590),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754222,
        "f": 50331688
      },
      "n": "Localization_MissingManifest_Parent",
      "d": 983150,
      "h": 64425492590,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(64425492590),
//--TRIMMABLE-BOUNDARY-START(68720459886),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245623406,
        "f": 50331688
      },
      "n": "Localization_TypeMustHaveTypeName",
      "d": 983150,
      "h": 68720459886,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(68720459886)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917742),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatLocalization_MissingManifest",
      "d": 983150,
      "h": 8590917742,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590917742),
//--TRIMMABLE-BOUNDARY-START(12885885038),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "FormatLocalization_TypeMustHaveTypeName",
      "d": 983150,
      "h": 12885885038,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885885038)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605361774),
    {
      "t": 123535361,
      "n": "s_resourceManager",
      "d": 983150,
      "h": 81605361774,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605361774),
//--TRIMMABLE-BOUNDARY-START(73015427182),
    {
      "t": 84738049,
      "n": "resourceCulture",
      "d": 983150,
      "h": 73015427182,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(73015427182)
  ],
  "h": 983150,
  "a": [
    {
      "t": 55050241,
      "c": 12939952129,
      "a": [
        {
          "v": "System.Resources.Tools.StronglyTypedResourceBuilder",
          "t": 1310721
        },
        {
          "v": "17.0.0.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71237633,
      "c": 4366204929
    },
    {
      "t": 126550017,
      "c": 4421517313
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Resources`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Resources`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983150)
        
        

        //--TRIMMABLE-BOUNDARY-START(589934)
        $asm.$cls(`$mel.MEL.ResourceManagerStringLocalizer`, ($self) => class ResourceManagerStringLocalizer extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(655470)
            static $_Log;
            static get Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$mel.MEL.ResourceManagerStringLocalizer;
                return $cls.$_Log ??= $asm.$ncls(`$mel.MEL.ResourceManagerStringLocalizer.Log`, ($self) => class Log
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622766)
                    /*global::System.Action<global::Microsoft.Extensions.Logging.ILogger, global::System.String, global::System.String, global::System.Globalization.CultureInfo, global::System.Exception?>*/ static __SearchedLocationCallback = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622766)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557358)
                    static /*void */ SearchedLocation(/*global::Microsoft.Extensions.Logging.ILogger*/ logger, /*global::System.String*/ key, /*global::System.String*/ locationSearched, /*global::System.Globalization.CultureInfo*/ culture)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885557358);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (logger.MEL$ILogger$IsEnabled(1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/))
                        {
                            $.$mel.MEL.ResourceManagerStringLocalizer.Log.__SearchedLocationCallback.Invoke(logger, key, locationSearched, culture, null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885557358)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590590062)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590590062);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295622766)
                            this.__SearchedLocationCallback = $.$mexla.MEL.LoggerMessage.Define$8($.$$.S.String, $.$$.S.String, $.$$.SG.CultureInfo, 1/*global::Microsoft.Extensions.Logging.LogLevel.Debug*/, new $.$mexla.MEL.EventId().$ctor$3(1, "SearchedLocation"), "ResourceManagerStringLocalizer searched for '{Key}' in '{LocationSearched}' with culture '{Culture}'.", (() =>
                            {
                                //new $.$mexla.MEL.LogDefineOptions()
                                const $t1 = $.$mexla.MEL.LogDefineOptions;
                                const $i1 = new $t1();
                                $i1.$ctor$1();
                                $i1.SkipEnabledCheck = true;
                                return $i1;
                            })());
                            //--TRIMMABLE-BOUNDARY-END(4295622766)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590590062)
                    
                    static $h = 655470;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885557358),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "locationSearched",
          "p": 1310721
        },
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "SearchedLocation",
      "d": 655470,
      "h": 12885557358,
      "f": 16777249,
      "a": [
        {
          "t": 2228312,
          "c": 38656933976,
          "a": [
            {
              "v": 1,
              "t": 655361
            },
            {
              "v": 1,
              "t": 2293848
            },
            {
              "v": "ResourceManagerStringLocalizer searched for \u0027{Key}\u0027 in \u0027{LocationSearched}\u0027 with culture \u0027{Culture}\u0027.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "EventName",
              "v": "SearchedLocation",
              "t": 1310721
            }
          ]
        },
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885557358)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622766),
    {
      "t": $.$$.S.Action$$$$$$($.$mexla.MEL.ILogger, $.$$.S.String, $.$$.S.String, $.$$.SG.CultureInfo, $.$$.S.Exception).$h,
      "n": "__SearchedLocationCallback",
      "d": 655470,
      "h": 4295622766,
      "f": 4194338,
      "a": [
        {
          "t": 55050241,
          "c": 12939952129,
          "a": [
            {
              "v": "Microsoft.Extensions.Logging.Generators",
              "t": 1310721
            },
            {
              "v": "42.42.42.42",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295622766)
  ],
  "d": 589934,
  "h": 655470
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer+Log`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceManagerStringLocalizer${separator}Log`; }
                }, $cls, ($v) => $cls.$_Log = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655470)
            
            //--TRIMMABLE-BOUNDARY-START(8590524526)
            /*ConcurrentDictionary<string, object?>*/ _missingManifestCache = null;
            //--TRIMMABLE-BOUNDARY-END(8590524526)
            
            //--TRIMMABLE-BOUNDARY-START(21475426414)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(21475426414)
            
            //--TRIMMABLE-BOUNDARY-START(17180459118)
            /*ResourceManager*/ _resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(17180459118)
            
            //--TRIMMABLE-BOUNDARY-START(25770393710)
            /*IResourceStringProvider*/ _resourceStringProvider = null;
            //--TRIMMABLE-BOUNDARY-END(25770393710)
            
            //--TRIMMABLE-BOUNDARY-START(12885491822)
            /*string*/ _resourceBaseName = null;
            //--TRIMMABLE-BOUNDARY-END(12885491822)
            
            //--TRIMMABLE-BOUNDARY-START(4295557230)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(4295557230)
            
            //--TRIMMABLE-BOUNDARY-START(38655295598)
            $ctor$3(/*ResourceManager*/ resourceManager, /*Assembly*/ resourceAssembly, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$1(resourceManager, new $.$mel.MEL.AssemblyWrapper().$ctor$1(resourceAssembly), baseName, resourceNamesCache, logger);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655295598);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655295598)
            
            //--TRIMMABLE-BOUNDARY-START(30065361006)
            $ctor$1(/*ResourceManager*/ resourceManager, /*AssemblyWrapper*/ resourceAssemblyWrapper, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                this.$ctor$2(resourceManager, new $.$mel.MEL.ResourceManagerStringProvider().$ctor$1(resourceNamesCache, resourceManager, resourceAssemblyWrapper.Assembly, baseName), baseName, resourceNamesCache, logger);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065361006);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065361006)
            
            //--TRIMMABLE-BOUNDARY-START(34360328302)
            $ctor$2(/*ResourceManager*/ resourceManager, /*IResourceStringProvider*/ resourceStringProvider, /*string*/ baseName, /*IResourceNamesCache*/ resourceNamesCache, /*ILogger*/ logger)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360328302);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(resourceManager, "resourceManager");
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(resourceStringProvider, "resourceStringProvider");
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(resourceNamesCache, "resourceNamesCache");
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(logger, "logger");
                    this._resourceStringProvider = resourceStringProvider;
                    this._resourceManager = resourceManager;
                    this._resourceBaseName = baseName;
                    this._resourceNamesCache = resourceNamesCache;
                    this._logger = logger;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360328302)
            
            //--TRIMMABLE-BOUNDARY-START(81604968558)
            /*LocalizedString*/ get_Item$2(/*string*/ name)
            {
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let value = this.GetStringSafely(name, null);
                return new $.$mela.MEL.LocalizedString().$ctor$1(name, value ?? name, value === null, this._resourceBaseName);
            }
            //--TRIMMABLE-BOUNDARY-END(81604968558)
            
            //--TRIMMABLE-BOUNDARY-START(77310001262)
            /*LocalizedString*/ get_Item$1(/*string*/ name, /*params object[]*/ $arguments)
            {
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let format = this.GetStringSafely(name, null);
                /*var*/ let value = $.$$.S.String.Format$5($.$$.SG.CultureInfo.CurrentCulture, format ?? name, $arguments);
                return new $.$mela.MEL.LocalizedString().$ctor$1(name, value, format === null, this._resourceBaseName);
            }
            //--TRIMMABLE-BOUNDARY-END(77310001262)
            
            //--TRIMMABLE-BOUNDARY-START(64425099374)
            /*IEnumerable<LocalizedString> */ GetAllStrings$1(/*bool*/ includeParentCultures)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425099374);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetAllStrings(includeParentCultures, $.$$.SG.CultureInfo.CurrentUICulture);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425099374)
            
            //--TRIMMABLE-BOUNDARY-START(60130132078)
            /*IEnumerable<LocalizedString> */ GetAllStrings(/*bool*/ includeParentCultures, /*CultureInfo*/ culture)
            {
                return new ($.$$.N.YieldToIterator$$($.$mela.MEL.LocalizedString))().$ctor$1(function*()
                {
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(culture, "culture");
                    /*var*/ let resourceNames = includeParentCultures ? this.GetResourceNamesFromCultureHierarchy(culture) : this._resourceStringProvider.MEL$IResourceStringProvider$GetAllResourceStrings(culture, true);
                    let $en2 = resourceNames ?? $.$sl.SL.Enumerable.Empty($.$$.S.String).SCG$IEnumerable$$$GetEnumerator();
                    while ($en2.SC$1$IEnumerator$MoveNext())
                    {
                        let name = $en2.SCG$IEnumerator$$$Current;
                        {
                            /*var*/ let value = this.GetStringSafely(name, culture);
                            yield new $.$mela.MEL.LocalizedString().$ctor$1(name, value ?? name, value === null, this._resourceBaseName);
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(60130132078)
            
            //--TRIMMABLE-BOUNDARY-START(73015033966)
            /*string? */ GetStringSafely(/*string*/ name, /*CultureInfo?*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(name, "name");
                /*var*/ let keyCulture = culture ?? $.$$.SG.CultureInfo.CurrentUICulture;
                /*var*/ let cacheKey = `name=${$.$strNN(name)}&culture=${$.$strNN(keyCulture.Name)}`;
                $.$mel.MEL.ResourceManagerStringLocalizer.Log.SearchedLocation(this._logger, name, this._resourceBaseName, keyCulture);
                if (this._missingManifestCache.ContainsKey(cacheKey))
                {
                    return null;
                }
                try
                {
                    return this._resourceManager.GetString(name, culture);
                }
                catch($e)
                {
                    this._missingManifestCache.TryAdd(cacheKey, null);
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73015033966)
            
            //--TRIMMABLE-BOUNDARY-START(68720066670)
            /*IEnumerable<string> */ GetResourceNamesFromCultureHierarchy(/*CultureInfo*/ startingCulture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let currentCulture = startingCulture;
                /*var*/ let resourceNames = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$1();
                /*var*/ let hasAnyCultures = false;
                while(true)
                {
                    /*var*/ let cultureResourceNames = this._resourceStringProvider.MEL$IResourceStringProvider$GetAllResourceStrings(currentCulture, false);
                    if (cultureResourceNames !== null)
                    {
                        let $en3 = cultureResourceNames.SCG$IEnumerable$$$GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let resourceName = $en3.SCG$IEnumerator$$$Current;
                            {
                                resourceNames.Add(resourceName);
                            }
                        }
                        hasAnyCultures = true;
                    }
                    if (currentCulture === currentCulture.Parent)
                    {
                        break;
                    }
                    currentCulture = currentCulture.Parent;
                }
                if (!hasAnyCultures)
                {
                    throw new $.$$.SR$1.MissingManifestResourceException().$ctor$12($.$mel.Resources.Localization_MissingManifest_Parent);
                }
                return resourceNames;
            }
            //--TRIMMABLE-BOUNDARY-END(68720066670)
            
            //--TRIMMABLE-BOUNDARY-START(17180000365)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string].get
            MEL$IStringLocalizer$get_Item$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180000365)
            
            //--TRIMMABLE-BOUNDARY-START(8590065773)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.this[string, params object[]].get
            MEL$IStringLocalizer$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065773)
            
            //--TRIMMABLE-BOUNDARY-START(21474967661)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizer.GetAllStrings(bool)
            MEL$IStringLocalizer$GetAllStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllStrings$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967661)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590524526)
                this._missingManifestCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590524526)
                
            }
            static $h = 589934;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604968558),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164782,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$2",
      "d": 589934,
      "h": 81604968558,
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(81604968558),
//--TRIMMABLE-BOUNDARY-START(77310001262),
    {
      "p": 327789,
      "i": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245230190,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 589934,
      "h": 77310001262,
      "f": 538968193
    },
//--TRIMMABLE-BOUNDARY-END(77310001262)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425099374),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mela.MEL.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        }
      ],
      "n": "GetAllStrings",
      "o": "@$1",
      "d": 589934,
      "h": 64425099374,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425099374),
//--TRIMMABLE-BOUNDARY-START(60130132078),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mela.MEL.LocalizedString).$h,
      "p": [
        {
          "n": "includeParentCultures",
          "p": 262145
        },
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "GetAllStrings",
      "d": 589934,
      "h": 60130132078,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(60130132078),
//--TRIMMABLE-BOUNDARY-START(73015033966),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "GetStringSafely",
      "d": 589934,
      "h": 73015033966,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(73015033966),
//--TRIMMABLE-BOUNDARY-START(68720066670),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "p": [
        {
          "n": "startingCulture",
          "p": 84738049
        }
      ],
      "n": "GetResourceNamesFromCultureHierarchy",
      "d": 589934,
      "h": 68720066670,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(68720066670)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524526),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "n": "_missingManifestCache",
      "d": 589934,
      "h": 8590524526,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524526),
//--TRIMMABLE-BOUNDARY-START(21475426414),
    {
      "t": 327790,
      "n": "_resourceNamesCache",
      "d": 589934,
      "h": 21475426414,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426414),
//--TRIMMABLE-BOUNDARY-START(17180459118),
    {
      "t": 123535361,
      "n": "_resourceManager",
      "d": 589934,
      "h": 17180459118,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180459118),
//--TRIMMABLE-BOUNDARY-START(25770393710),
    {
      "t": 393326,
      "n": "_resourceStringProvider",
      "d": 589934,
      "h": 25770393710,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770393710),
//--TRIMMABLE-BOUNDARY-START(12885491822),
    {
      "t": 1310721,
      "n": "_resourceBaseName",
      "d": 589934,
      "h": 12885491822,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491822),
//--TRIMMABLE-BOUNDARY-START(4295557230),
    {
      "t": 917592,
      "n": "_logger",
      "d": 589934,
      "h": 4295557230,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557230)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655295598),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 123535361
        },
        {
          "n": "resourceAssembly",
          "p": 107020289
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327790
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589934,
      "h": 38655295598,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295598),
//--TRIMMABLE-BOUNDARY-START(30065361006),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 123535361
        },
        {
          "n": "resourceAssemblyWrapper",
          "p": 262254
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327790
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589934,
      "h": 30065361006,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30065361006),
//--TRIMMABLE-BOUNDARY-START(34360328302),
    {
      "p": [
        {
          "n": "resourceManager",
          "p": 123535361
        },
        {
          "n": "resourceStringProvider",
          "p": 393326
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceNamesCache",
          "p": 327790
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589934,
      "h": 34360328302,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34360328302)
  ],
  "h": 589934
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.MEL.IStringLocalizer ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$mel.MEL.ResourceManagerStringLocalizer.Log ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceManagerStringLocalizer`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceManagerStringLocalizer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589934)
        
        

        //--TRIMMABLE-BOUNDARY-START(852078)
        $asm.$cls(`$mel.MEL.ResourceNamesCache`, ($self) => class ResourceNamesCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819374)
            /*ConcurrentDictionary<string, IList<string>?>*/ _cache = null;
            //--TRIMMABLE-BOUNDARY-END(4295819374)
            
            //--TRIMMABLE-BOUNDARY-START(8590786670)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590786670);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786670)
            
            //--TRIMMABLE-BOUNDARY-START(12885753966)
            /*IList<string>? */ GetOrAdd(/*string*/ name, /*Func<string, IList<string>?>*/ valueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885753966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._cache.GetOrAdd(name, valueFactory);
            }
            //--TRIMMABLE-BOUNDARY-END(12885753966)
            
            //--TRIMMABLE-BOUNDARY-START(4295295086)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceNamesCache.GetOrAdd(string, System.Func<string, System.Collections.Generic.IList<string>?>)
            MEL$IResourceNamesCache$GetOrAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetOrAdd(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295086)
            
            //--TRIMMABLE-BOUNDARY-START(8590786670)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590786670)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295819374)
                this._cache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.SCG.IList$$($.$$.S.String)))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295819374)
                
            }
            static $h = 852078;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885753966),
    {
      "r": $.$$.SCG.IList$$($.$$.S.String).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "valueFactory",
          "p": $.$$.S.Func$$$($.$$.S.String, $.$$.SCG.IList$$($.$$.S.String)).$h
        }
      ],
      "n": "GetOrAdd",
      "d": 852078,
      "h": 12885753966,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885753966)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819374),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$$.SCG.IList$$($.$$.S.String)).$h,
      "n": "_cache",
      "d": 852078,
      "h": 4295819374,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819374)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786670),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852078,
      "h": 8590786670,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786670)
  ],
  "h": 852078
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.MEL.IResourceNamesCache ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceNamesCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceNamesCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852078)
        
        

        //--TRIMMABLE-BOUNDARY-START(786542)
        $asm.$cls(`$mel.MEL.ResourceManagerStringProvider`, ($self) => class ResourceManagerStringProvider extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180655726)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(17180655726)
            
            //--TRIMMABLE-BOUNDARY-START(12885688430)
            /*ResourceManager*/ _resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(12885688430)
            
            //--TRIMMABLE-BOUNDARY-START(4295753838)
            /*Assembly*/ _assembly = null;
            //--TRIMMABLE-BOUNDARY-END(4295753838)
            
            //--TRIMMABLE-BOUNDARY-START(8590721134)
            /*string*/ _resourceBaseName = null;
            //--TRIMMABLE-BOUNDARY-END(8590721134)
            
            //--TRIMMABLE-BOUNDARY-START(21475623022)
            $ctor$1(/*IResourceNamesCache*/ resourceCache, /*ResourceManager*/ resourceManager, /*Assembly*/ assembly, /*string*/ baseName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475623022);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._resourceManager = resourceManager;
                    this._resourceNamesCache = resourceCache;
                    this._assembly = assembly;
                    this._resourceBaseName = baseName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475623022)
            
            //--TRIMMABLE-BOUNDARY-START(30065557614)
            /*string */ GetResourceCacheKey(/*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceName = this._resourceManager.BaseName;
                return `Culture=${$.$strNN(culture.Name)};resourceName=${$.$strNN(resourceName)};Assembly=${$.$strNN(this._assembly.FullName)}`;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557614)
            
            //--TRIMMABLE-BOUNDARY-START(34360524910)
            /*string */ GetResourceName(/*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceStreamName = this._resourceBaseName;
                if (!$.$$.S.String.IsNullOrEmpty(culture.Name))
                {
                    resourceStreamName += "." + $.$strNN(culture.Name);
                }
                resourceStreamName += ".resources";
                return resourceStreamName;
            }
            //--TRIMMABLE-BOUNDARY-END(34360524910)
            
            //--TRIMMABLE-BOUNDARY-START(25770590318)
            /*IList<string>? */ GetAllResourceStrings(/*CultureInfo*/ culture, /*bool*/ throwOnMissing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let cacheKey = this.GetResourceCacheKey(culture);
                return this._resourceNamesCache.MEL$IResourceNamesCache$GetOrAdd(cacheKey, new ($.$$.S.Func$$$($.$$.S.String, $.$$.SCG.IList$$($.$$.S.String)))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let resourceSet = this._resourceManager.GetResourceSet(culture, true, false);
                    if (resourceSet === null)
                    {
                        if (throwOnMissing)
                        {
                            throw new $.$$.SR$1.MissingManifestResourceException().$ctor$12($.$mel.Resources.FormatLocalization_MissingManifest(this.GetResourceName(culture)));
                        }
                        else 
                        {
                            return null;
                        }
                    }
                    /*var*/ let names = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    let $en1 = resourceSet.GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let entry = $en1.SC$1$IEnumerator$Current;
                        {
                            let key;
                            if ($.$is((entry?.Key ?? null), $.$$.S.String, { set $v($v){ key = $v; } }))
                            {
                                names.Add(key);
                            }
                        }
                    }
                    return names;
                }, $enUcVc ??= {"r":$.$$.SCG.IList$$($.$$.S.String).$h,"p":[{"n":"_","p":1310721}],"n":"","d":786542,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770590318)
            
            //--TRIMMABLE-BOUNDARY-START(4295360622)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IResourceStringProvider.GetAllResourceStrings(System.Globalization.CultureInfo, bool)
            MEL$IResourceStringProvider$GetAllResourceStrings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360622);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetAllResourceStrings(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295360622)
            
            static $h = 786542;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065557614),
    {
      "r": 1310721,
      "p": [
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "GetResourceCacheKey",
      "d": 786542,
      "h": 30065557614,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065557614),
//--TRIMMABLE-BOUNDARY-START(34360524910),
    {
      "r": 1310721,
      "p": [
        {
          "n": "culture",
          "p": 84738049
        }
      ],
      "n": "GetResourceName",
      "d": 786542,
      "h": 34360524910,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360524910),
//--TRIMMABLE-BOUNDARY-START(25770590318),
    {
      "r": $.$$.SCG.IList$$($.$$.S.String).$h,
      "p": [
        {
          "n": "culture",
          "p": 84738049
        },
        {
          "n": "throwOnMissing",
          "p": 262145
        }
      ],
      "n": "GetAllResourceStrings",
      "d": 786542,
      "h": 25770590318,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590318)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180655726),
    {
      "t": 327790,
      "n": "_resourceNamesCache",
      "d": 786542,
      "h": 17180655726,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655726),
//--TRIMMABLE-BOUNDARY-START(12885688430),
    {
      "t": 123535361,
      "n": "_resourceManager",
      "d": 786542,
      "h": 12885688430,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688430),
//--TRIMMABLE-BOUNDARY-START(4295753838),
    {
      "t": 107020289,
      "n": "_assembly",
      "d": 786542,
      "h": 4295753838,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753838),
//--TRIMMABLE-BOUNDARY-START(8590721134),
    {
      "t": 1310721,
      "n": "_resourceBaseName",
      "d": 786542,
      "h": 8590721134,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475623022),
    {
      "p": [
        {
          "n": "resourceCache",
          "p": 327790
        },
        {
          "n": "resourceManager",
          "p": 123535361
        },
        {
          "n": "assembly",
          "p": 107020289
        },
        {
          "n": "baseName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786542,
      "h": 21475623022,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475623022)
  ],
  "h": 786542
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mel.MEL.IResourceStringProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceManagerStringProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceManagerStringProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786542)
        
        

        //--TRIMMABLE-BOUNDARY-START(721006)
        $asm.$cls(`$mel.MEL.ResourceManagerStringLocalizerFactory`, ($self) => class ResourceManagerStringLocalizerFactory extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885622894)
            /*IResourceNamesCache*/ _resourceNamesCache = null;
            //--TRIMMABLE-BOUNDARY-END(12885622894)
            
            //--TRIMMABLE-BOUNDARY-START(4295688302)
            /*ConcurrentDictionary<string, ResourceManagerStringLocalizer>*/ _localizerCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295688302)
            
            //--TRIMMABLE-BOUNDARY-START(17180590190)
            /*string*/ _resourcesRelativePath = null;
            //--TRIMMABLE-BOUNDARY-END(17180590190)
            
            //--TRIMMABLE-BOUNDARY-START(8590655598)
            /*ILoggerFactory*/ _loggerFactory = null;
            //--TRIMMABLE-BOUNDARY-END(8590655598)
            
            //--TRIMMABLE-BOUNDARY-START(21475557486)
            $ctor$1(/*IOptions<LocalizationOptions>*/ localizationOptions, /*ILoggerFactory*/ loggerFactory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557486);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(localizationOptions, "localizationOptions");
                    $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(loggerFactory, "loggerFactory");
                    this._resourcesRelativePath = localizationOptions.MEO$IOptions$Microsoft$Extensions$Localization$LocalizationOptions$Value.ResourcesPath ?? $.$$.S.String.Empty;
                    this._loggerFactory = loggerFactory;
                    if (!$.$$.S.String.IsNullOrEmpty(this._resourcesRelativePath))
                    {
                        this._resourcesRelativePath = $.$strNN($.$$.S.String.Replace.call($.$$.S.String.Replace.call(this._resourcesRelativePath, $.$$.SI.Path.AltDirectorySeparatorChar, /*.*/ 46), $.$$.SI.Path.DirectorySeparatorChar, /*.*/ 46)) + ".";
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557486)
            
            //--TRIMMABLE-BOUNDARY-START(51540328558)
            /*string */ GetResourcePrefix$1(/*TypeInfo*/ typeInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                return this.GetResourcePrefix(typeInfo, this.GetRootNamespace(typeInfo.Assembly), this.GetResourcePath(typeInfo.Assembly));
            }
            //--TRIMMABLE-BOUNDARY-END(51540328558)
            
            //--TRIMMABLE-BOUNDARY-START(47245361262)
            /*string */ GetResourcePrefix(/*TypeInfo*/ typeInfo, /*string?*/ baseNamespace, /*string?*/ resourcesRelativePath)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(typeInfo, "typeInfo");
                $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(typeInfo.FullName, "typeInfo.FullName");
                if ($.$$.S.String.IsNullOrEmpty(resourcesRelativePath))
                {
                    return typeInfo.FullName;
                }
                else 
                {
                    return $.$strNN($.$strNN($.$strNN(baseNamespace) + ".") + $.$strNN(resourcesRelativePath)) + $.$strNN($.$mel.MEL.ResourceManagerStringLocalizerFactory.TrimPrefix(typeInfo.FullName, $.$strNN(baseNamespace) + "."));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245361262)
            
            //--TRIMMABLE-BOUNDARY-START(60130263150)
            /*string */ GetResourcePrefix$3(/*string*/ baseResourceName, /*string*/ baseNamespace)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseResourceName, "baseResourceName");
                $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(baseNamespace, "baseNamespace");
                /*var*/ let assemblyName = new $.$$.SR.AssemblyName().$ctor$2(baseNamespace);
                /*var*/ let assembly = $.$$.SR.Assembly.Load$3(assemblyName);
                /*var*/ let rootNamespace = this.GetRootNamespace(assembly);
                /*var*/ let resourceLocation = this.GetResourcePath(assembly);
                /*var*/ let locationPath = $.$strNN($.$strNN(rootNamespace) + ".") + $.$strNN(resourceLocation);
                baseResourceName = $.$strNN(locationPath) + $.$strNN($.$mel.MEL.ResourceManagerStringLocalizerFactory.TrimPrefix(baseResourceName, $.$strNN(baseNamespace) + "."));
                return baseResourceName;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263150)
            
            //--TRIMMABLE-BOUNDARY-START(30065492078)
            /*IStringLocalizer */ Create$1(/*Type*/ resourceSource)
            {
                /*var*/ let localizer;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492078);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(resourceSource, "resourceSource");
                if (!this._localizerCache.TryGetValue(resourceSource.AssemblyQualifiedName, $.$ref(() => localizer, ($v) => localizer = $v, $.$mel.MEL.ResourceManagerStringLocalizer)))
                {
                    /*var*/ let typeInfo = $.$$.SR.IntrospectionExtensions.GetTypeInfo(resourceSource);
                    /*var*/ let baseName = this.GetResourcePrefix$1(typeInfo);
                    /*var*/ let assembly = typeInfo.Assembly;
                    localizer = this.CreateResourceManagerStringLocalizer(assembly, baseName);
                    this._localizerCache.set_Item$1(resourceSource.AssemblyQualifiedName, localizer);
                }
                return localizer;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492078)
            
            //--TRIMMABLE-BOUNDARY-START(25770524782)
            /*IStringLocalizer */ Create(/*string*/ baseName, /*string*/ location)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(baseName, "baseName");
                $.$mel.MAS.ArgumentNullThrowHelper.ThrowIfNull(location, "location");
                return this._localizerCache.GetOrAdd(`B=${$.$strNN(baseName)},L=${$.$strNN(location)}`, new ($.$$.S.Func$$$($.$$.S.String, $.$mel.MEL.ResourceManagerStringLocalizer))().$ctor(this,  (/*_*/ _0) =>
                {
                    /*var*/ let assemblyName = new $.$$.SR.AssemblyName().$ctor$2(location);
                    /*var*/ let assembly = $.$$.SR.Assembly.Load$3(assemblyName);
                    baseName = this.GetResourcePrefix$3(baseName, location);
                    return this.CreateResourceManagerStringLocalizer(assembly, baseName);
                }, $oqzxuj ??= {"r":589934,"p":[{"n":"_","p":1310721}],"n":"","d":721006,"h":0,"f":17825794}));
            }
            //--TRIMMABLE-BOUNDARY-END(25770524782)
            
            //--TRIMMABLE-BOUNDARY-START(34360459374)
            /*ResourceManagerStringLocalizer */ CreateResourceManagerStringLocalizer(/*Assembly*/ assembly, /*string*/ baseName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$mel.MEL.ResourceManagerStringLocalizer().$ctor$3(new $.$$.SR$1.ResourceManager().$ctor$3(baseName, assembly), assembly, baseName, this._resourceNamesCache, $.$mexla.MEL.LoggerFactoryExtensions.CreateLogger$1($.$mel.MEL.ResourceManagerStringLocalizer, this._loggerFactory));
            }
            //--TRIMMABLE-BOUNDARY-END(34360459374)
            
            //--TRIMMABLE-BOUNDARY-START(55835295854)
            /*string */ GetResourcePrefix$2(/*string*/ location, /*string*/ baseName, /*string*/ resourceLocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$strNN($.$strNN($.$strNN(location) + ".") + $.$strNN(resourceLocation)) + $.$strNN($.$mel.MEL.ResourceManagerStringLocalizerFactory.TrimPrefix(baseName, $.$strNN(location) + "."));
            }
            //--TRIMMABLE-BOUNDARY-END(55835295854)
            
            //--TRIMMABLE-BOUNDARY-START(38655426670)
            /*ResourceLocationAttribute? */ GetResourceLocationAttribute(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.MEL.ResourceLocationAttribute, assembly);
            }
            //--TRIMMABLE-BOUNDARY-END(38655426670)
            
            //--TRIMMABLE-BOUNDARY-START(68720197742)
            /*RootNamespaceAttribute? */ GetRootNamespaceAttribute(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SR.CustomAttributeExtensions.GetCustomAttribute$6($.$mel.MEL.RootNamespaceAttribute, assembly);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197742)
            
            //--TRIMMABLE-BOUNDARY-START(64425230446)
            /*string? */ GetRootNamespace(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let rootNamespaceAttribute = this.GetRootNamespaceAttribute(assembly);
                if (rootNamespaceAttribute !== null)
                {
                    return rootNamespaceAttribute.RootNamespace;
                }
                return assembly.GetName().Name;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230446)
            
            //--TRIMMABLE-BOUNDARY-START(42950393966)
            /*string */ GetResourcePath(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let resourceLocationAttribute = this.GetResourceLocationAttribute(assembly);
                /*var*/ let resourceLocation = resourceLocationAttribute === null ? this._resourcesRelativePath : $.$strNN(resourceLocationAttribute.ResourceLocation) + ".";
                resourceLocation = $.$$.S.String.Replace.call($.$$.S.String.Replace.call(resourceLocation, $.$$.SI.Path.DirectorySeparatorChar, /*.*/ 46), $.$$.SI.Path.AltDirectorySeparatorChar, /*.*/ 46);
                return resourceLocation;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393966)
            
            //--TRIMMABLE-BOUNDARY-START(73015165038)
            static /*string? */ TrimPrefix(/*string*/ name, /*string*/ prefix)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.StartsWith$2.call(name, prefix, 4/*StringComparison.Ordinal*/))
                {
                    return $.$$.S.String.Substring$1.call(name, prefix.length);
                }
                return name;
            }
            //--TRIMMABLE-BOUNDARY-END(73015165038)
            
            //--TRIMMABLE-BOUNDARY-START(8590196845)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(System.Type)
            MEL$IStringLocalizerFactory$Create$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590196845)
            
            //--TRIMMABLE-BOUNDARY-START(4295229549)
            //Generated interface implemetation for Microsoft.Extensions.Localization.IStringLocalizerFactory.Create(string, string)
            MEL$IStringLocalizerFactory$Create()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Create(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295229549)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885622894)
                this._resourceNamesCache = new $.$mel.MEL.ResourceNamesCache().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(12885622894)
                
                //--TRIMMABLE-BOUNDARY-START(4295688302)
                this._localizerCache = new ($.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mel.MEL.ResourceManagerStringLocalizer))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295688302)
                
            }
            static $h = 721006;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540328558),
    {
      "r": 1310721,
      "p": [
        {
          "n": "typeInfo",
          "p": 122552321
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$1",
      "d": 721006,
      "h": 51540328558,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(51540328558),
//--TRIMMABLE-BOUNDARY-START(47245361262),
    {
      "r": 1310721,
      "p": [
        {
          "n": "typeInfo",
          "p": 122552321
        },
        {
          "n": "baseNamespace",
          "p": 1310721
        },
        {
          "n": "resourcesRelativePath",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "d": 721006,
      "h": 47245361262,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(47245361262),
//--TRIMMABLE-BOUNDARY-START(60130263150),
    {
      "r": 1310721,
      "p": [
        {
          "n": "baseResourceName",
          "p": 1310721
        },
        {
          "n": "baseNamespace",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$3",
      "d": 721006,
      "h": 60130263150,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(60130263150),
//--TRIMMABLE-BOUNDARY-START(30065492078),
    {
      "r": 131181,
      "p": [
        {
          "n": "resourceSource",
          "p": 188547073
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 721006,
      "h": 30065492078,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492078),
//--TRIMMABLE-BOUNDARY-START(25770524782),
    {
      "r": 131181,
      "p": [
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "location",
          "p": 1310721
        }
      ],
      "n": "Create",
      "d": 721006,
      "h": 25770524782,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524782),
//--TRIMMABLE-BOUNDARY-START(34360459374),
    {
      "r": 589934,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        },
        {
          "n": "baseName",
          "p": 1310721
        }
      ],
      "n": "CreateResourceManagerStringLocalizer",
      "d": 721006,
      "h": 34360459374,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(34360459374),
//--TRIMMABLE-BOUNDARY-START(55835295854),
    {
      "r": 1310721,
      "p": [
        {
          "n": "location",
          "p": 1310721
        },
        {
          "n": "baseName",
          "p": 1310721
        },
        {
          "n": "resourceLocation",
          "p": 1310721
        }
      ],
      "n": "GetResourcePrefix",
      "o": "@$2",
      "d": 721006,
      "h": 55835295854,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(55835295854),
//--TRIMMABLE-BOUNDARY-START(38655426670),
    {
      "r": 524398,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "GetResourceLocationAttribute",
      "d": 721006,
      "h": 38655426670,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(38655426670),
//--TRIMMABLE-BOUNDARY-START(68720197742),
    {
      "r": 917614,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "GetRootNamespaceAttribute",
      "d": 721006,
      "h": 68720197742,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720197742),
//--TRIMMABLE-BOUNDARY-START(64425230446),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "GetRootNamespace",
      "d": 721006,
      "h": 64425230446,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425230446),
//--TRIMMABLE-BOUNDARY-START(42950393966),
    {
      "r": 1310721,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "GetResourcePath",
      "d": 721006,
      "h": 42950393966,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393966),
//--TRIMMABLE-BOUNDARY-START(73015165038),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "prefix",
          "p": 1310721
        }
      ],
      "n": "TrimPrefix",
      "d": 721006,
      "h": 73015165038,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73015165038)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622894),
    {
      "t": 327790,
      "n": "_resourceNamesCache",
      "d": 721006,
      "h": 12885622894,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622894),
//--TRIMMABLE-BOUNDARY-START(4295688302),
    {
      "t": $.$scc.SCC.ConcurrentDictionary$$$($.$$.S.String, $.$mel.MEL.ResourceManagerStringLocalizer).$h,
      "n": "_localizerCache",
      "d": 721006,
      "h": 4295688302,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688302),
//--TRIMMABLE-BOUNDARY-START(17180590190),
    {
      "t": 1310721,
      "n": "_resourcesRelativePath",
      "d": 721006,
      "h": 17180590190,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590190),
//--TRIMMABLE-BOUNDARY-START(8590655598),
    {
      "t": 1048664,
      "n": "_loggerFactory",
      "d": 721006,
      "h": 8590655598,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557486),
    {
      "p": [
        {
          "n": "localizationOptions",
          "p": $.$meo.MEO.IOptions$$($.$mel.MEL.LocalizationOptions).$h
        },
        {
          "n": "loggerFactory",
          "p": 1048664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 721006,
      "h": 21475557486,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557486)
  ],
  "h": 721006
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.MEL.IStringLocalizerFactory ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceManagerStringLocalizerFactory`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceManagerStringLocalizerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721006)
        
        

        //--TRIMMABLE-BOUNDARY-START(524398)
        $asm.$cls(`$mel.MEL.ResourceLocationAttribute`, ($self) => class ResourceLocationAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590458990)
            $ctor$2(/*string*/ resourceLocation)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458990);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(resourceLocation, "resourceLocation");
                    this.ResourceLocation = resourceLocation;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458990)
            
            //--TRIMMABLE-BOUNDARY-START(21475360878)
            /*string*/ ResourceLocation = null;
            //--TRIMMABLE-BOUNDARY-END(21475360878)
            
            static $h = 524398;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360878),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393582,
        "f": 50331649
      },
      "n": "ResourceLocation",
      "d": 524398,
      "h": 21475360878,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458990),
    {
      "p": [
        {
          "n": "resourceLocation",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524398,
      "h": 8590458990,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458990)
  ],
  "h": 524398,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.ResourceLocationAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}ResourceLocationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524398)
        
        

        //--TRIMMABLE-BOUNDARY-START(917614)
        $asm.$cls(`$mel.MEL.RootNamespaceAttribute`, ($self) => class RootNamespaceAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590852206)
            $ctor$2(/*string*/ rootNamespace)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852206);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$mel.MAS.ArgumentThrowHelper.ThrowIfNullOrEmpty(rootNamespace, "rootNamespace");
                    this.RootNamespace = rootNamespace;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852206)
            
            //--TRIMMABLE-BOUNDARY-START(21475754094)
            /*string*/ RootNamespace = null;
            //--TRIMMABLE-BOUNDARY-END(21475754094)
            
            static $h = 917614;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475754094),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180786798,
        "f": 50331649
      },
      "n": "RootNamespace",
      "d": 917614,
      "h": 21475754094,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475754094)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852206),
    {
      "p": [
        {
          "n": "rootNamespace",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917614,
      "h": 8590852206,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852206)
  ],
  "h": 917614,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 1,
          "t": 46137345
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `Microsoft.Extensions.Localization.RootNamespaceAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `Microsoft${separator}Extensions${separator}Localization${separator}RootNamespaceAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917614)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.Localization.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Console", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options"));
})();
//--TRIMMABLE-BOUNDARY-END(110)
