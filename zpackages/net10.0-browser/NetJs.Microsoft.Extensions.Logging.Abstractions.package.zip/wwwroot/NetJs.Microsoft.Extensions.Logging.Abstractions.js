
//--TRIMMABLE-BOUNDARY-START(88)
(function ($global, $, $$, $spu, $sr, $scm, $sc, $sm, $snv, $sdt, $st, $scc, $sris, $sri, $sl, $so, $sci, $sic, $stt, $sim, $stee, $srm, $sre, $srei, $srel, $srp, $sle, $mxdi, $sttp, $sdd) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Logging.Abstractions", 
    {
  "h": 88,
  "f": "Microsoft.Extensions.Logging.Abstractions",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "Microsoft.Extensions.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.Microsoft.Extensions.Logging.Abstractions",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262232)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.IBufferedLogger", ($self) => class IBufferedLogger
        {
            static $h = 262232;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229528),
    {
      "r": 65537,
      "p": [
        {
          "n": "records",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mexla.Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord).$h
        }
      ],
      "n": "LogRecords",
      "o": "Microsoft$Extensions$Logging$Abstractions$IBufferedLogger$LogRecords",
      "d": 262232,
      "h": 4295229528,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229528)
  ],
  "h": 262232
}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.IBufferedLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262232)
        
        
        //--TRIMMABLE-BOUNDARY-START(917592)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ILogger", ($self) => class ILogger
        {
            static $h = 917592;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885819480),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "o": "Microsoft$Extensions$Logging$ILogger$Log",
      "d": 917592,
      "h": 12885819480,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(12885819480),
//--TRIMMABLE-BOUNDARY-START(8590852184),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "o": "Microsoft$Extensions$Logging$ILogger$IsEnabled",
      "d": 917592,
      "h": 8590852184,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590852184),
//--TRIMMABLE-BOUNDARY-START(4295884888),
    {
      "r": 90308609,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "o": "Microsoft$Extensions$Logging$ILogger$BeginScope",
      "d": 917592,
      "h": 4295884888,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295884888)
  ],
  "h": 917592
}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917592)
        
        
        //--TRIMMABLE-BOUNDARY-START(852056)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.IExternalScopeProvider", ($self) => class IExternalScopeProvider
        {
            static $h = 852056;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295819352),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": (TState) => $.$$.System.Action$$$($.$$.System.Object, TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "ForEachScope",
      "o": "Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope",
      "d": 852056,
      "h": 4295819352,
      "f": 16908545
    },
//--TRIMMABLE-BOUNDARY-END(4295819352),
//--TRIMMABLE-BOUNDARY-START(8590786648),
    {
      "r": 90308609,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Push",
      "o": "Microsoft$Extensions$Logging$IExternalScopeProvider$Push",
      "d": 852056,
      "h": 8590786648,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590786648)
  ],
  "h": 852056
}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.IExternalScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852056)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179736)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ILoggingBuilder", ($self) => class ILoggingBuilder
        {
            static $h = 1179736;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886081624),
    {
      "p": 786522,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8591114328,
        "f": 50331905
      },
      "n": "Services",
      "o": "Microsoft$Extensions$Logging$ILoggingBuilder$Services",
      "d": 1179736,
      "h": 12886081624,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886081624)
  ],
  "h": 1179736
}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggingBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179736)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245272)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ISupportExternalScope", ($self) => class ISupportExternalScope
        {
            static $h = 1245272;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296212568),
    {
      "r": 65537,
      "p": [
        {
          "n": "scopeProvider",
          "p": 852056
        }
      ],
      "n": "SetScopeProvider",
      "o": "Microsoft$Extensions$Logging$ISupportExternalScope$SetScopeProvider",
      "d": 1245272,
      "h": 4296212568,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296212568)
  ],
  "h": 1245272
}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ISupportExternalScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245272)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048664)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ILoggerFactory", ($self) => class ILoggerFactory
        {
            static $h = 1048664;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983256),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "o": "Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger",
      "d": 1048664,
      "h": 8590983256,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590983256),
//--TRIMMABLE-BOUNDARY-START(4296015960),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "o": "Microsoft$Extensions$Logging$ILoggerFactory$AddProvider",
      "d": 1048664,
      "h": 4296015960,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296015960)
  ],
  "i": [90308609
  ],
  "h": 1048664
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048664)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114200)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ILoggerProvider", ($self) => class ILoggerProvider
        {
            static $h = 1114200;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081496),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "o": "Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger",
      "d": 1114200,
      "h": 4296081496,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081496)
  ],
  "i": [90308609
  ],
  "h": 1114200
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114200)
        
        
        //--TRIMMABLE-BOUNDARY-START(983128)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ILogger<>", (/*out*/ TCategoryName) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.ILogger<>", [/*out*/ TCategoryName], ($self) => class ILogger$$
        {
            static $h = 983128;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "i": [917592
  ],
  "g": [TCategoryName?.$h??1507328
  ],
  "s": [
    {
      "n": "TCategoryName",
      "f": 32
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILogger<${TCategoryName?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983128)
        
        
        //--TRIMMABLE-BOUNDARY-START(196696)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord", ($self) => class BufferedLogRecord extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770000472)
            /*string? */ get Exception()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000472)
            
            //--TRIMMABLE-BOUNDARY-START(8590131288)
            /*ActivitySpanId? */ get ActivitySpanId()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131288)
            
            //--TRIMMABLE-BOUNDARY-START(12885098584)
            /*ActivityTraceId? */ get ActivityTraceId()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098584)
            
            //--TRIMMABLE-BOUNDARY-START(124554248280)
            /*int? */ get ManagedThreadId()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(124554248280)
            
            //--TRIMMABLE-BOUNDARY-START(30064967768)
            /*string? */ get FormattedMessage()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967768)
            
            //--TRIMMABLE-BOUNDARY-START(128849215576)
            /*string? */ get MessageTemplate()
            {
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(128849215576)
            
            //--TRIMMABLE-BOUNDARY-START(17180065880)
            /*IReadOnlyList<KeyValuePair<string, object?>> */ get Attributes()
            {
                return (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1();
                    return $t1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065880)
            
            //--TRIMMABLE-BOUNDARY-START(4295163992)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163992)
            
            static $h = 196696;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(133144182872),
    {
      "p": 65470465,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964313688,
        "f": 50331905
      },
      "n": "Timestamp",
      "d": 196696,
      "h": 133144182872,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144182872),
//--TRIMMABLE-BOUNDARY-START(120259280984),
    {
      "p": 2293848,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509912,
        "f": 50331905
      },
      "n": "LogLevel",
      "d": 196696,
      "h": 120259280984,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120259280984),
//--TRIMMABLE-BOUNDARY-START(21475033176),
    {
      "p": 720984,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424706136,
        "f": 50331905
      },
      "n": "EventId",
      "d": 196696,
      "h": 21475033176,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475033176),
//--TRIMMABLE-BOUNDARY-START(25770000472),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014640728,
        "f": 50331777
      },
      "n": "Exception",
      "d": 196696,
      "h": 25770000472,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770000472),
//--TRIMMABLE-BOUNDARY-START(8590131288),
    {
      "p": $.$typeNullable($.$sdd.System.Diagnostics.ActivitySpanId).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902360,
        "f": 50331777
      },
      "n": "ActivitySpanId",
      "d": 196696,
      "h": 8590131288,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8590131288),
//--TRIMMABLE-BOUNDARY-START(12885098584),
    {
      "p": $.$typeNullable($.$sdd.System.Diagnostics.ActivityTraceId).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836952,
        "f": 50331777
      },
      "n": "ActivityTraceId",
      "d": 196696,
      "h": 12885098584,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(12885098584),
//--TRIMMABLE-BOUNDARY-START(124554248280),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784444504,
        "f": 50331777
      },
      "n": "ManagedThreadId",
      "d": 196696,
      "h": 124554248280,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554248280),
//--TRIMMABLE-BOUNDARY-START(30064967768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604575320,
        "f": 50331777
      },
      "n": "FormattedMessage",
      "d": 196696,
      "h": 30064967768,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(30064967768),
//--TRIMMABLE-BOUNDARY-START(128849215576),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374379096,
        "f": 50331777
      },
      "n": "MessageTemplate",
      "d": 196696,
      "h": 128849215576,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(128849215576),
//--TRIMMABLE-BOUNDARY-START(17180065880),
    {
      "p": $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834771544,
        "f": 50331777
      },
      "n": "Attributes",
      "d": 196696,
      "h": 17180065880,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17180065880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163992),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196696,
      "h": 4295163992,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295163992)
  ],
  "h": 196696
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196696)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310808)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LogDefineOptions", ($self) => class LogDefineOptions extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30066081880)
            /*bool*/ SkipEnabledCheck = false;
            //--TRIMMABLE-BOUNDARY-END(30066081880)
            
            //--TRIMMABLE-BOUNDARY-START(8591245400)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245400)
            
            static $h = 1310808;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066081880),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181179992,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25771114584,
        "f": 83886081
      },
      "n": "SkipEnabledCheck",
      "d": 1310808,
      "h": 30066081880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245400),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310808,
      "h": 8591245400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245400)
  ],
  "h": 1310808
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogDefineOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310808)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621528)
        $asm.$cls("$mexla.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(98786869336)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(98786869336)
            
            //--TRIMMABLE-BOUNDARY-START(90196934744)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(90196934744)
            
            //--TRIMMABLE-BOUNDARY-START(94491902040)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427130968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$mexla.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Logging.Abstractions", $.$mexla.System.SR.$type.Assembly);
                    $.$mexla.System.SR.s_resourceManager = temp;
                }
                return $.$mexla.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(94491902040)
            
            //--TRIMMABLE-BOUNDARY-START(8592556120)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837196376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671771224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592556120)
            
            //--TRIMMABLE-BOUNDARY-START(115966738520)
            static /*string */ get UnexpectedNumberOfNamedParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73017065560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The format string '{0}' does not have the expected number of named parameters. Expected {1} parameter(s) but found {2} parameter(s).";
            }
            //--TRIMMABLE-BOUNDARY-END(115966738520)
            
            //--TRIMMABLE-BOUNDARY-START(47247261784)
            static /*string */ FormatUnexpectedNumberOfNamedParameters(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247261784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The format string '{0}' does not have the expected number of named parameters. Expected {1} parameter(s) but found {2} parameter(s).", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(47247261784)
            
            //--TRIMMABLE-BOUNDARY-START(103081836632)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(103081836632)
            
            //--TRIMMABLE-BOUNDARY-START(85901967448)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901967448);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901967448)
            
            //--TRIMMABLE-BOUNDARY-START(120261705816)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120261705816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261705816)
            
            //--TRIMMABLE-BOUNDARY-START(81607000152)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607000152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mexla.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(81607000152)
            
            //--TRIMMABLE-BOUNDARY-START(77312032856)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312032856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$mexla.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(77312032856)
            
            //--TRIMMABLE-BOUNDARY-START(38657327192)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657327192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38657327192)
            
            //--TRIMMABLE-BOUNDARY-START(34362359896)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362359896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34362359896)
            
            //--TRIMMABLE-BOUNDARY-START(30067392600)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067392600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30067392600)
            
            //--TRIMMABLE-BOUNDARY-START(42952294488)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952294488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mexla.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42952294488)
            
            //--TRIMMABLE-BOUNDARY-START(21477458008)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477458008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21477458008)
            
            //--TRIMMABLE-BOUNDARY-START(17182490712)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182490712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182490712)
            
            //--TRIMMABLE-BOUNDARY-START(12887523416)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887523416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mexla.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12887523416)
            
            //--TRIMMABLE-BOUNDARY-START(25772425304)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772425304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$mexla.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25772425304)
            
            //--TRIMMABLE-BOUNDARY-START(4297588824)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103081836632)
                    this.s_usingResourceKeys = $.$mexla.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(103081836632)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297588824)
            
            static $h = 2621528;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 2621528
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621528)
        
        
        //--TRIMMABLE-BOUNDARY-START(655448)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.DebuggerDisplayFormatting", ($self) => class DebuggerDisplayFormatting
        {
            //--TRIMMABLE-BOUNDARY-START(8590590040)
            static /*string */ DebuggerToString(/*string*/ name, /*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogLevel?*/ let minimumLevel = $.$mexla.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.CalculateEnabledLogLevel(logger);
                /*var*/ let debugText = `Name = \"${name}\"`;
                if (minimumLevel !== null)
                {
                    debugText += `, MinLevel = ${minimumLevel}`;
                }
                else 
                {
                    debugText += `, Enabled = false`;
                }
                return debugText;
            }
            //--TRIMMABLE-BOUNDARY-END(8590590040)
            
            //--TRIMMABLE-BOUNDARY-START(4295622744)
            static /*LogLevel? */ CalculateEnabledLogLevel(/*ILogger*/ logger)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<LogLevel>*/ let logLevels = new ($.$$.System.ReadOnlySpan$$($.$mexla.Microsoft.Extensions.Logging.LogLevel))().$ctor$4([ 5/*LogLevel.Critical*/, 4/*LogLevel.Error*/, 3/*LogLevel.Warning*/, 2/*LogLevel.Information*/, 1/*LogLevel.Debug*/, 0/*LogLevel.Trace*/ ]);
                /*LogLevel?*/ let minimumLevel = null;
                var $en2 = logLevels.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var logLevel = $en2.Current.$v;
                    {
                        if (!logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            break;
                        }
                        minimumLevel = logLevel;
                    }
                }
                return minimumLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622744)
            
            static $h = 655448;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590590040),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "DebuggerToString",
      "d": 655448,
      "h": 8590590040,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590590040),
//--TRIMMABLE-BOUNDARY-START(4295622744),
    {
      "r": $.$typeNullable($.$mexla.Microsoft.Extensions.Logging.LogLevel).$h,
      "p": [
        {
          "n": "logger",
          "p": 917592
        }
      ],
      "n": "CalculateEnabledLogLevel",
      "d": 655448,
      "h": 4295622744,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295622744)
  ],
  "h": 655448
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DebuggerDisplayFormatting`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655448)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359384)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LogValuesFormatter", ($self) => class LogValuesFormatter extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(81606738008)
            /*string*/ static NullValue = null;
            //--TRIMMABLE-BOUNDARY-END(81606738008)
            
            //--TRIMMABLE-BOUNDARY-START(8592293976)
            /*List<string>*/ _valueNames = null;
            //--TRIMMABLE-BOUNDARY-END(8592293976)
            
            //--TRIMMABLE-BOUNDARY-START(4297326680)
            /*CompositeFormat*/ _format = null;
            //--TRIMMABLE-BOUNDARY-END(4297326680)
            
            //--TRIMMABLE-BOUNDARY-START(17182228568)
            $ctor$1(/*string*/ format)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(format, "format");
                    this.OriginalFormat = format;
                    /*var*/ let vsb = new $.$mexla.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256, null));
                    /*int*/ let scanIndex = 0;
                    /*int*/ let endIndex = format.length;
                    while(scanIndex < endIndex)
                    {
                        /*int*/ let openBraceIndex = $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.FindBraceIndex(format, /*{*/ 123, scanIndex, endIndex);
                        if (scanIndex === 0 && openBraceIndex === endIndex)
                        {
                            this._format = $.$$.System.Text.CompositeFormat.Parse(format);
                            return this;
                        }
                        /*int*/ let closeBraceIndex = $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.FindBraceIndex(format, /*}*/ 125, openBraceIndex, endIndex);
                        if (closeBraceIndex === endIndex)
                        {
                            vsb.Append$2($.$$.System.MemoryExtensions.AsSpan$1(format, scanIndex, ((endIndex - scanIndex) | 0)));
                            scanIndex = endIndex;
                        }
                        else 
                        {
                            /*int*/ let formatDelimiterIndex = $.$$.System.MemoryExtensions.IndexOfAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$1(format, openBraceIndex, ((closeBraceIndex - openBraceIndex) | 0)), /*,*/ 44, /*:*/ 58);
                            formatDelimiterIndex = formatDelimiterIndex < 0 ? closeBraceIndex : ((formatDelimiterIndex + openBraceIndex) | 0);
                            vsb.Append$2($.$$.System.MemoryExtensions.AsSpan$1(format, scanIndex, ((((openBraceIndex - scanIndex) | 0) + 1) | 0)));
                            vsb.Append$3($.$$.System.Int32.ToString$1.call(this._valueNames.Count, $.$$.System.Globalization.CultureInfo.InvariantCulture));
                            this._valueNames.Add($.$$.System.String.Substring.call(format, ((openBraceIndex + 1) | 0), ((((formatDelimiterIndex - openBraceIndex) | 0) - 1) | 0)));
                            vsb.Append$2($.$$.System.MemoryExtensions.AsSpan$1(format, formatDelimiterIndex, ((((closeBraceIndex - formatDelimiterIndex) | 0) + 1) | 0)));
                            scanIndex = ((closeBraceIndex + 1) | 0);
                        }
                    }
                    this._format = $.$$.System.Text.CompositeFormat.Parse($.$mexla.System.Text.ValueStringBuilder.ToString.call(vsb));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228568)
            
            //--TRIMMABLE-BOUNDARY-START(85901705304)
            /*string*/ OriginalFormat = null;
            //--TRIMMABLE-BOUNDARY-END(85901705304)
            
            //--TRIMMABLE-BOUNDARY-START(94491639896)
            /*List<string> */ get ValueNames()
            {
                return this._valueNames;
            }
            //--TRIMMABLE-BOUNDARY-END(94491639896)
            
            //--TRIMMABLE-BOUNDARY-START(21477195864)
            static /*int */ FindBraceIndex(/*string*/ format, /*char*/ brace, /*int*/ startIndex, /*int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477195864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let braceIndex = endIndex;
                /*int*/ let scanIndex = startIndex;
                /*int*/ let braceOccurrenceCount = 0;
                while(scanIndex < endIndex)
                {
                    if (braceOccurrenceCount > 0 && $.$$.System.String.get_Chars.call(format, scanIndex) !== brace)
                    {
                        if (braceOccurrenceCount % 2 === 0)
                        {
                            braceOccurrenceCount = 0;
                            braceIndex = endIndex;
                        }
                        else 
                        {
                            break;
                        }
                    }
                    else if ($.$$.System.String.get_Chars.call(format, scanIndex) === brace)
                    {
                        if (brace === /*}*/ 125)
                        {
                            if (braceOccurrenceCount === 0)
                            {
                                braceIndex = scanIndex;
                            }
                        }
                        else 
                        {
                            braceIndex = scanIndex;
                        }
                        braceOccurrenceCount++;
                    }
                    scanIndex++;
                }
                return braceIndex;
            }
            //--TRIMMABLE-BOUNDARY-END(21477195864)
            
            //--TRIMMABLE-BOUNDARY-START(30067130456)
            /*string */ Format$1(/*object?[]?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067130456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?[]?*/ let formattedValues = values;
                if (values !== null)
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        /*object*/ let formattedValue = $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$$.System.Array.$ReadT1.call(values, i));
                        if (!$.$$.System.Object.ReferenceEquals(formattedValue, $.$$.System.Array.$ReadT1.call(values, i)))
                        {
                            formattedValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [values.length], null);
                            $.$$.System.Array.Copy(values, formattedValues, i);
                            $.$$.System.Array.$WriteT1.call(formattedValues, formattedValue, i++);
                            for(; i < values.length; i++)
                            {
                                $.$$.System.Array.$WriteT1.call(formattedValues, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$$.System.Array.$ReadT1.call(values, i)), i);
                            }
                            break;
                        }
                    }
                }
                return $.$$.System.String.Format$5($.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, formattedValues ?? $.$$.System.Array.Empty($.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(30067130456)
            
            //--TRIMMABLE-BOUNDARY-START(51541966936)
            /*string */ FormatWithOverwrite(/*object?[]?*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541966936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (values !== null)
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(values, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$$.System.Array.$ReadT1.call(values, i)), i);
                    }
                }
                return $.$$.System.String.Format$5($.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, values ?? $.$$.System.Array.Empty($.$$.System.Object));
            }
            //--TRIMMABLE-BOUNDARY-END(51541966936)
            
            //--TRIMMABLE-BOUNDARY-START(25772163160)
            /*string */ Format()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772163160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._format.Format;
            }
            //--TRIMMABLE-BOUNDARY-END(25772163160)
            
            //--TRIMMABLE-BOUNDARY-START(42952032344)
            /*string */ Format$4(TArg0, /*TArg0*/ arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952032344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let arg0String;
                return !$.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$$.System.Object)) ? $.$$.System.String.Format$15(TArg0, $.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0) : $.$$.System.String.Format$6($.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg0String ]));
            }
            //--TRIMMABLE-BOUNDARY-END(42952032344)
            
            //--TRIMMABLE-BOUNDARY-START(38657065048)
            /*string */ Format$3(TArg0, TArg1, /*TArg0*/ arg0, /*TArg1*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657065048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let arg0String;
                /*object?*/ let arg1String;
                return $.$$.System.Boolean.op_BitwiseOr($.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$$.System.Object)), $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg1, arg1, $.$ref(() => arg1String, ($v) => arg1String = $v, $.$$.System.Object))) ? $.$$.System.String.Format$6($.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg0String ?? $.$box(arg0, TArg0), arg1String ?? $.$box(arg1, TArg1) ])) : $.$$.System.String.Format$14(TArg0, TArg1, $.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0, arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(38657065048)
            
            //--TRIMMABLE-BOUNDARY-START(34362097752)
            /*string */ Format$2(TArg0, TArg1, TArg2, /*TArg0*/ arg0, /*TArg1*/ arg1, /*TArg2*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362097752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let arg0String;
                /*object?*/ let arg1String;
                /*object?*/ let arg2String;
                return $.$$.System.Boolean.op_BitwiseOr($.$$.System.Boolean.op_BitwiseOr($.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$$.System.Object)), $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg1, arg1, $.$ref(() => arg1String, ($v) => arg1String = $v, $.$$.System.Object))), $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg2, arg2, $.$ref(() => arg2String, ($v) => arg2String = $v, $.$$.System.Object))) ? $.$$.System.String.Format$6($.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg0String ?? $.$box(arg0, TArg0), arg1String ?? $.$box(arg1, TArg1), arg2String ?? $.$box(arg2, TArg2) ])) : $.$$.System.String.Format$13(TArg0, TArg1, TArg2, $.$$.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0, arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(34362097752)
            
            //--TRIMMABLE-BOUNDARY-START(73016803416)
            /*KeyValuePair<string, object?> */ GetValue(/*object?[]*/ values, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016803416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index > this._valueNames.Count)
                {
                    throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                }
                if (this._valueNames.Count > index)
                {
                    return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._valueNames.get_Item(index), $.$$.System.Array.$ReadT1.call(values, index));
                }
                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this.OriginalFormat);
            }
            //--TRIMMABLE-BOUNDARY-END(73016803416)
            
            //--TRIMMABLE-BOUNDARY-START(77311770712)
            /*IEnumerable<KeyValuePair<string, object?>> */ GetValues(/*object[]*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311770712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let valueArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), null, [((values.length + 1) | 0)], null);
                for(/*int*/ let index = 0; index !== this._valueNames.Count; ++index)
                {
                    $.$$.System.Array.$WriteT1.call(valueArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._valueNames.get_Item(index), $.$$.System.Array.$ReadT1.call(values, index)), index);
                }
                $.$$.System.Array.$WriteT1.call(valueArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this.OriginalFormat), ((valueArray.length - 1) | 0));
                return valueArray;
            }
            //--TRIMMABLE-BOUNDARY-END(77311770712)
            
            //--TRIMMABLE-BOUNDARY-START(47246999640)
            static /*object */ FormatArgument(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246999640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let stringValue;
                return $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable($.$$.System.Object, value, $.$ref(() => stringValue, ($v) => stringValue = $v, $.$$.System.Object)) ? stringValue : value;
            }
            //--TRIMMABLE-BOUNDARY-END(47246999640)
            
            //--TRIMMABLE-BOUNDARY-START(90196672600)
            static /*bool */ TryFormatArgumentIfNullOrEnumerable(T, /*T?*/ value, /*out object?*/ stringValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196672600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$box(value, T) === null)
                {
                    stringValue.$v = "(null)"/*NullValue*/;
                    return true;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$$.System.String))) && $.$is(value, $.$$.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                {
                    /*var*/ let vsb = new $.$mexla.System.Text.ValueStringBuilder().$ctor$4($.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256, null));
                    /*bool*/ let first = true;
                    var $en3 = enumerable.System$Collections$IEnumerable$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!first)
                            {
                                vsb.Append$3(", ");
                            }
                            let f;
                            vsb.Append$3($.$is(e, $.$$.System.IFormattable, { set $v(v){ f = v; } }) ? f.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture) : !(e === null) ? $.$$.System.Object.ToString.call(e) : "(null)"/*NullValue*/);
                            first = false;
                        }
                    }
                    stringValue.$v = $.$mexla.System.Text.ValueStringBuilder.ToString.call(vsb);
                    return true;
                }
                stringValue.$v = null;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(90196672600)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8592293976)
                this._valueNames = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8592293976)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(81606738008)
                    this.NullValue = "(null)";
                    //--TRIMMABLE-BOUNDARY-END(81606738008)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2359384;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85901705304),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131901528,
        "f": 50331649
      },
      "n": "OriginalFormat",
      "d": 2359384,
      "h": 85901705304,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901705304),
//--TRIMMABLE-BOUNDARY-START(94491639896),
    {
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721836120,
        "f": 50331649
      },
      "n": "ValueNames",
      "d": 2359384,
      "h": 94491639896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94491639896)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477195864),
    {
      "r": 655361,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "brace",
          "p": 458753
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "FindBraceIndex",
      "d": 2359384,
      "h": 21477195864,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21477195864),
//--TRIMMABLE-BOUNDARY-START(30067130456),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "Format",
      "o": "@$1",
      "d": 2359384,
      "h": 30067130456,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067130456),
//--TRIMMABLE-BOUNDARY-START(51541966936),
    {
      "r": 1310721,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "FormatWithOverwrite",
      "d": 2359384,
      "h": 51541966936,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51541966936),
//--TRIMMABLE-BOUNDARY-START(25772163160),
    {
      "r": 1310721,
      "n": "Format",
      "d": 2359384,
      "h": 25772163160,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25772163160),
//--TRIMMABLE-BOUNDARY-START(42952032344),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg0",
          "p": (TArg0) => TArg0.$h
        }
      ],
      "g": [
        "TArg0"
      ],
      "n": "Format",
      "o": "@$4",
      "d": 2359384,
      "h": 42952032344,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(42952032344),
//--TRIMMABLE-BOUNDARY-START(38657065048),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg0",
          "p": (TArg0, TArg1) => TArg0.$h
        },
        {
          "n": "arg1",
          "p": (TArg0, TArg1) => TArg1.$h
        }
      ],
      "g": [
        "TArg0",
        "TArg1"
      ],
      "n": "Format",
      "o": "@$3",
      "d": 2359384,
      "h": 38657065048,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(38657065048),
//--TRIMMABLE-BOUNDARY-START(34362097752),
    {
      "r": 1310721,
      "p": [
        {
          "n": "arg0",
          "p": (TArg0, TArg1, TArg2) => TArg0.$h
        },
        {
          "n": "arg1",
          "p": (TArg0, TArg1, TArg2) => TArg1.$h
        },
        {
          "n": "arg2",
          "p": (TArg0, TArg1, TArg2) => TArg2.$h
        }
      ],
      "g": [
        "TArg0",
        "TArg1",
        "TArg2"
      ],
      "n": "Format",
      "o": "@$2",
      "d": 2359384,
      "h": 34362097752,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(34362097752),
//--TRIMMABLE-BOUNDARY-START(73016803416),
    {
      "r": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetValue",
      "d": 2359384,
      "h": 73016803416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016803416),
//--TRIMMABLE-BOUNDARY-START(77311770712),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "GetValues",
      "d": 2359384,
      "h": 77311770712,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77311770712),
//--TRIMMABLE-BOUNDARY-START(47246999640),
    {
      "r": 131073,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "FormatArgument",
      "d": 2359384,
      "h": 47246999640,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246999640),
//--TRIMMABLE-BOUNDARY-START(90196672600),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "stringValue",
          "p": 131073,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryFormatArgumentIfNullOrEnumerable",
      "d": 2359384,
      "h": 90196672600,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(90196672600)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(81606738008),
    {
      "t": 1310721,
      "n": "NullValue",
      "d": 2359384,
      "h": 81606738008,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81606738008),
//--TRIMMABLE-BOUNDARY-START(8592293976),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "_valueNames",
      "d": 2359384,
      "h": 8592293976,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592293976),
//--TRIMMABLE-BOUNDARY-START(4297326680),
    {
      "t": 164560897,
      "n": "_format",
      "d": 2359384,
      "h": 4297326680,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326680)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228568),
    {
      "p": [
        {
          "n": "format",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359384,
      "h": 17182228568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228568)
  ],
  "h": 2359384
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogValuesFormatter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359384)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638488)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LoggerFactoryExtensions", ($self) => class LoggerFactoryExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(8591573080)
            static /*ILogger<T> */ CreateLogger$1(T, /*this ILoggerFactory*/ factory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591573080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                return new ($.$mexla.Microsoft.Extensions.Logging.Logger$$(T))().$ctor$1(factory);
            }
            //--TRIMMABLE-BOUNDARY-END(8591573080)
            
            //--TRIMMABLE-BOUNDARY-START(4296605784)
            static /*ILogger */ CreateLogger(/*this ILoggerFactory*/ factory, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                return factory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger($.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(type, true, false, false, /*.*/ 46));
            }
            //--TRIMMABLE-BOUNDARY-END(4296605784)
            
            static $h = 1638488;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591573080),
    {
      "r": (T) => $.$mexla.Microsoft.Extensions.Logging.ILogger$$(T).$h,
      "p": [
        {
          "n": "factory",
          "p": 1048664
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateLogger",
      "o": "@$1",
      "d": 1638488,
      "h": 8591573080,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591573080),
//--TRIMMABLE-BOUNDARY-START(4296605784),
    {
      "r": 917592,
      "p": [
        {
          "n": "factory",
          "p": 1048664
        },
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "CreateLogger",
      "d": 1638488,
      "h": 4296605784,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296605784)
  ],
  "h": 1638488
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638488)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441880)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LoggerExtensions", ($self) => class LoggerExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296409176)
            /*Func<FormattedLogValues, Exception?, string>*/ static _messageFormatter = null;
            //--TRIMMABLE-BOUNDARY-END(4296409176)
            
            //--TRIMMABLE-BOUNDARY-START(60130984024)
            static /*void */ LogDebug$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130984024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 1/*LogLevel.Debug*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(60130984024)
            
            //--TRIMMABLE-BOUNDARY-START(64425951320)
            static /*void */ LogDebug$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 1/*LogLevel.Debug*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951320)
            
            //--TRIMMABLE-BOUNDARY-START(51541049432)
            static /*void */ LogDebug(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 1/*LogLevel.Debug*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(51541049432)
            
            //--TRIMMABLE-BOUNDARY-START(55836016728)
            static /*void */ LogDebug$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 1/*LogLevel.Debug*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(55836016728)
            
            //--TRIMMABLE-BOUNDARY-START(111670591576)
            static /*void */ LogTrace$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670591576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 0/*LogLevel.Trace*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(111670591576)
            
            //--TRIMMABLE-BOUNDARY-START(115965558872)
            static /*void */ LogTrace$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 0/*LogLevel.Trace*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(115965558872)
            
            //--TRIMMABLE-BOUNDARY-START(103080656984)
            static /*void */ LogTrace(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080656984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 0/*LogLevel.Trace*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(103080656984)
            
            //--TRIMMABLE-BOUNDARY-START(107375624280)
            static /*void */ LogTrace$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 0/*LogLevel.Trace*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(107375624280)
            
            //--TRIMMABLE-BOUNDARY-START(94490722392)
            static /*void */ LogInformation$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490722392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 2/*LogLevel.Information*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(94490722392)
            
            //--TRIMMABLE-BOUNDARY-START(98785689688)
            static /*void */ LogInformation$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 2/*LogLevel.Information*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(98785689688)
            
            //--TRIMMABLE-BOUNDARY-START(85900787800)
            static /*void */ LogInformation(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 2/*LogLevel.Information*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(85900787800)
            
            //--TRIMMABLE-BOUNDARY-START(90195755096)
            static /*void */ LogInformation$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 2/*LogLevel.Information*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(90195755096)
            
            //--TRIMMABLE-BOUNDARY-START(128850460760)
            static /*void */ LogWarning$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850460760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 3/*LogLevel.Warning*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(128850460760)
            
            //--TRIMMABLE-BOUNDARY-START(133145428056)
            static /*void */ LogWarning$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 3/*LogLevel.Warning*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(133145428056)
            
            //--TRIMMABLE-BOUNDARY-START(120260526168)
            static /*void */ LogWarning(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260526168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 3/*LogLevel.Warning*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(120260526168)
            
            //--TRIMMABLE-BOUNDARY-START(124555493464)
            static /*void */ LogWarning$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 3/*LogLevel.Warning*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(124555493464)
            
            //--TRIMMABLE-BOUNDARY-START(77310853208)
            static /*void */ LogError$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 4/*LogLevel.Error*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(77310853208)
            
            //--TRIMMABLE-BOUNDARY-START(81605820504)
            static /*void */ LogError$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 4/*LogLevel.Error*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(81605820504)
            
            //--TRIMMABLE-BOUNDARY-START(68720918616)
            static /*void */ LogError(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 4/*LogLevel.Error*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918616)
            
            //--TRIMMABLE-BOUNDARY-START(73015885912)
            static /*void */ LogError$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 4/*LogLevel.Error*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(73015885912)
            
            //--TRIMMABLE-BOUNDARY-START(42951114840)
            static /*void */ LogCritical$2(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 5/*LogLevel.Critical*/, eventId, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(42951114840)
            
            //--TRIMMABLE-BOUNDARY-START(47246082136)
            static /*void */ LogCritical$3(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 5/*LogLevel.Critical*/, eventId, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(47246082136)
            
            //--TRIMMABLE-BOUNDARY-START(34361180248)
            static /*void */ LogCritical(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 5/*LogLevel.Critical*/, exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(34361180248)
            
            //--TRIMMABLE-BOUNDARY-START(38656147544)
            static /*void */ LogCritical$1(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656147544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 5/*LogLevel.Critical*/, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(38656147544)
            
            //--TRIMMABLE-BOUNDARY-START(21476278360)
            static /*void */ Log$1(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476278360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, logLevel, $.$mexla.Microsoft.Extensions.Logging.EventId.op_Implicit(0), null, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(21476278360)
            
            //--TRIMMABLE-BOUNDARY-START(30066212952)
            static /*void */ Log$3(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066212952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, logLevel, eventId, null, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(30066212952)
            
            //--TRIMMABLE-BOUNDARY-START(17181311064)
            static /*void */ Log(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181311064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, logLevel, $.$mexla.Microsoft.Extensions.Logging.EventId.op_Implicit(0), exception, message, args);
            }
            //--TRIMMABLE-BOUNDARY-END(17181311064)
            
            //--TRIMMABLE-BOUNDARY-START(25771245656)
            static /*void */ Log$2(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(logger, "logger");
                logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.FormattedLogValues, logLevel, eventId, new $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues().$ctor$3(message, args), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions._messageFormatter);
            }
            //--TRIMMABLE-BOUNDARY-END(25771245656)
            
            //--TRIMMABLE-BOUNDARY-START(12886343768)
            static /*IDisposable? */ BeginScope(/*this ILogger*/ logger, /*string*/ messageFormat, /*params object?[]*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886343768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(logger, "logger");
                return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.FormattedLogValues, new $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues().$ctor$3(messageFormat, args));
            }
            //--TRIMMABLE-BOUNDARY-END(12886343768)
            
            //--TRIMMABLE-BOUNDARY-START(137440395352)
            static /*string */ MessageFormatter(/*FormattedLogValues*/ state, /*Exception?*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440395352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.ToString.call(state);
            }
            //--TRIMMABLE-BOUNDARY-END(137440395352)
            
            //--TRIMMABLE-BOUNDARY-START(8591376472)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4296409176)
                    this._messageFormatter = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.FormattedLogValues, $.$$.System.Exception, $.$$.System.String))().$ctor($.$mexla.Microsoft.Extensions.Logging.LoggerExtensions, $.$mexla.Microsoft.Extensions.Logging.LoggerExtensions.MessageFormatter);
                    //--TRIMMABLE-BOUNDARY-END(4296409176)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591376472)
            
            static $h = 1441880;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130984024),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogDebug",
      "o": "@$2",
      "d": 1441880,
      "h": 60130984024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130984024),
//--TRIMMABLE-BOUNDARY-START(64425951320),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogDebug",
      "o": "@$3",
      "d": 1441880,
      "h": 64425951320,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425951320),
//--TRIMMABLE-BOUNDARY-START(51541049432),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogDebug",
      "d": 1441880,
      "h": 51541049432,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541049432),
//--TRIMMABLE-BOUNDARY-START(55836016728),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogDebug",
      "o": "@$1",
      "d": 1441880,
      "h": 55836016728,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55836016728),
//--TRIMMABLE-BOUNDARY-START(111670591576),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogTrace",
      "o": "@$2",
      "d": 1441880,
      "h": 111670591576,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(111670591576),
//--TRIMMABLE-BOUNDARY-START(115965558872),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogTrace",
      "o": "@$3",
      "d": 1441880,
      "h": 115965558872,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115965558872),
//--TRIMMABLE-BOUNDARY-START(103080656984),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogTrace",
      "d": 1441880,
      "h": 103080656984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103080656984),
//--TRIMMABLE-BOUNDARY-START(107375624280),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogTrace",
      "o": "@$1",
      "d": 1441880,
      "h": 107375624280,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107375624280),
//--TRIMMABLE-BOUNDARY-START(94490722392),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "o": "@$2",
      "d": 1441880,
      "h": 94490722392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94490722392),
//--TRIMMABLE-BOUNDARY-START(98785689688),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "o": "@$3",
      "d": 1441880,
      "h": 98785689688,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785689688),
//--TRIMMABLE-BOUNDARY-START(85900787800),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "d": 1441880,
      "h": 85900787800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85900787800),
//--TRIMMABLE-BOUNDARY-START(90195755096),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogInformation",
      "o": "@$1",
      "d": 1441880,
      "h": 90195755096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90195755096),
//--TRIMMABLE-BOUNDARY-START(128850460760),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "o": "@$2",
      "d": 1441880,
      "h": 128850460760,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128850460760),
//--TRIMMABLE-BOUNDARY-START(133145428056),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "o": "@$3",
      "d": 1441880,
      "h": 133145428056,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133145428056),
//--TRIMMABLE-BOUNDARY-START(120260526168),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "d": 1441880,
      "h": 120260526168,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120260526168),
//--TRIMMABLE-BOUNDARY-START(124555493464),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogWarning",
      "o": "@$1",
      "d": 1441880,
      "h": 124555493464,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124555493464),
//--TRIMMABLE-BOUNDARY-START(77310853208),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogError",
      "o": "@$2",
      "d": 1441880,
      "h": 77310853208,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310853208),
//--TRIMMABLE-BOUNDARY-START(81605820504),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogError",
      "o": "@$3",
      "d": 1441880,
      "h": 81605820504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81605820504),
//--TRIMMABLE-BOUNDARY-START(68720918616),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogError",
      "d": 1441880,
      "h": 68720918616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68720918616),
//--TRIMMABLE-BOUNDARY-START(73015885912),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogError",
      "o": "@$1",
      "d": 1441880,
      "h": 73015885912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73015885912),
//--TRIMMABLE-BOUNDARY-START(42951114840),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogCritical",
      "o": "@$2",
      "d": 1441880,
      "h": 42951114840,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951114840),
//--TRIMMABLE-BOUNDARY-START(47246082136),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogCritical",
      "o": "@$3",
      "d": 1441880,
      "h": 47246082136,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246082136),
//--TRIMMABLE-BOUNDARY-START(34361180248),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogCritical",
      "d": 1441880,
      "h": 34361180248,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361180248),
//--TRIMMABLE-BOUNDARY-START(38656147544),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "LogCritical",
      "o": "@$1",
      "d": 1441880,
      "h": 38656147544,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656147544),
//--TRIMMABLE-BOUNDARY-START(21476278360),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Log",
      "o": "@$1",
      "d": 1441880,
      "h": 21476278360,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476278360),
//--TRIMMABLE-BOUNDARY-START(30066212952),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Log",
      "o": "@$3",
      "d": 1441880,
      "h": 30066212952,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066212952),
//--TRIMMABLE-BOUNDARY-START(17181311064),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Log",
      "d": 1441880,
      "h": 17181311064,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181311064),
//--TRIMMABLE-BOUNDARY-START(25771245656),
    {
      "r": 65537,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Log",
      "o": "@$2",
      "d": 1441880,
      "h": 25771245656,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771245656),
//--TRIMMABLE-BOUNDARY-START(12886343768),
    {
      "r": 90308609,
      "p": [
        {
          "n": "logger",
          "p": 917592
        },
        {
          "n": "messageFormat",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "BeginScope",
      "d": 1441880,
      "h": 12886343768,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886343768),
//--TRIMMABLE-BOUNDARY-START(137440395352),
    {
      "r": 1310721,
      "p": [
        {
          "n": "state",
          "p": 786520
        },
        {
          "n": "error",
          "p": 80019457
        }
      ],
      "n": "MessageFormatter",
      "d": 1441880,
      "h": 137440395352,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137440395352)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409176),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.FormattedLogValues, $.$$.System.Exception, $.$$.System.String).$h,
      "n": "_messageFormatter",
      "d": 1441880,
      "h": 4296409176,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296409176)
  ],
  "h": 1441880
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441880)
        
        
        //--TRIMMABLE-BOUNDARY-START(65624)
        $asm.$cls("$mexla.Microsoft.Extensions.Internal.TypeNameHelper", ($self) => class TypeNameHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17179934808)
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            //--TRIMMABLE-BOUNDARY-END(17179934808)
            
            //--TRIMMABLE-BOUNDARY-START(4295032920)
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            //--TRIMMABLE-BOUNDARY-END(4295032920)
            
            //--TRIMMABLE-BOUNDARY-START(21474902104)
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return item === null ? null : $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1($.$$.System.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            //--TRIMMABLE-BOUNDARY-END(21474902104)
            
            //--TRIMMABLE-BOUNDARY-START(25769869400)
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869400);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), type, $.$ref(() => new $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions().$ctor$3(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                const $t2 = builder;
                return name ?? $.$ifnn($t2, ($t) => $.$$.System.Text.StringBuilder.ToString.call($t)) ?? $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869400)
            
            //--TRIMMABLE-BOUNDARY-START(38654771288)
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let builtInName;
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                    $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$$.System.Text.StringBuilder().$ctor$1();
                    $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$mexla.Microsoft.Extensions.Internal.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$$.System.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$19(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$19(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$$.System.String.Replace.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$19(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771288)
            
            //--TRIMMABLE-BOUNDARY-START(30064836696)
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$3(/*[*/ 91);
                    builder.Append$2(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$3(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836696)
            
            //--TRIMMABLE-BOUNDARY-START(34359803992)
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$3(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$$.System.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$19(type.Namespace);
                        builder.Append$3(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$$.System.String.IndexOf$3.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$19(type.Name);
                    return;
                }
                builder.Append$18(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$3(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$$.System.Text.StringBuilder), $.$$.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$3(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$$.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$3(/* */ 32);
                        }
                    }
                    builder.Append$3(/*>*/ 62);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803992)
            
            //--TRIMMABLE-BOUNDARY-START(131160)
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                let $cls = $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr("$mexla.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions", ($self) => class DisplayNameOptions extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25769934936)
                    $ctor$3(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25769934936);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25769934936)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064902232)
                    /*bool*/ FullName = false;
                    //--TRIMMABLE-BOUNDARY-END(30064902232)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014575192)
                    /*bool*/ IncludeGenericParameters = false;
                    //--TRIMMABLE-BOUNDARY-END(73014575192)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719607896)
                    /*bool*/ IncludeGenericParameterNames = false;
                    //--TRIMMABLE-BOUNDARY-END(68719607896)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309542488)
                    /*char*/ NestedTypeDelimiter = 0;
                    //--TRIMMABLE-BOUNDARY-END(77309542488)
                    
                    //--TRIMMABLE-BOUNDARY-START(21474967640)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21474967640)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    static $h = 131160;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064902232),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836824,
        "f": 50331649
      },
      "n": "FullName",
      "d": 131160,
      "h": 30064902232,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064902232),
//--TRIMMABLE-BOUNDARY-START(73014575192),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706008,
        "f": 50331649
      },
      "n": "IncludeGenericParameters",
      "d": 131160,
      "h": 73014575192,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014575192),
//--TRIMMABLE-BOUNDARY-START(68719607896),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771416,
        "f": 50331649
      },
      "n": "IncludeGenericParameterNames",
      "d": 131160,
      "h": 68719607896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719607896),
//--TRIMMABLE-BOUNDARY-START(77309542488),
    {
      "p": 458753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424640600,
        "f": 50331649
      },
      "n": "NestedTypeDelimiter",
      "d": 131160,
      "h": 77309542488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309542488)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25769934936),
    {
      "p": [
        {
          "n": "fullName",
          "p": 262145
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145
        },
        {
          "n": "includeGenericParameters",
          "p": 262145
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131160,
      "h": 25769934936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769934936),
//--TRIMMABLE-BOUNDARY-START(21474967640),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131160,
      "h": 21474967640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474967640)
  ],
  "d": 65624,
  "h": 131160
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131160)
            
            //--TRIMMABLE-BOUNDARY-START(12884967512)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032920)
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$$.System.Void.$type, "void");
                        $i1.Add($.$$.System.Boolean.$type, "bool");
                        $i1.Add($.$$.System.Byte.$type, "byte");
                        $i1.Add($.$$.System.Char.$type, "char");
                        $i1.Add($.$$.System.Decimal.$type, "decimal");
                        $i1.Add($.$$.System.Double.$type, "double");
                        $i1.Add($.$$.System.Single.$type, "float");
                        $i1.Add($.$$.System.Int32.$type, "int");
                        $i1.Add($.$$.System.Int64.$type, "long");
                        $i1.Add($.$$.System.Object.$type, "object");
                        $i1.Add($.$$.System.SByte.$type, "sbyte");
                        $i1.Add($.$$.System.Int16.$type, "short");
                        $i1.Add($.$$.System.String.$type, "string");
                        $i1.Add($.$$.System.UInt32.$type, "uint");
                        $i1.Add($.$$.System.UInt64.$type, "ulong");
                        $i1.Add($.$$.System.UInt16.$type, "ushort");
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(4295032920)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967512)
            
            static $h = 65624;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474902104),
    {
      "r": 1310721,
      "p": [
        {
          "n": "item",
          "p": 131073
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "GetTypeDisplayName",
      "d": 65624,
      "h": 21474902104,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474902104),
//--TRIMMABLE-BOUNDARY-START(25769869400),
    {
      "r": 1310721,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "fullName",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "includeGenericParameterNames",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "includeGenericParameters",
          "p": 262145,
          "f": 65,
          "v": true
        },
        {
          "n": "nestedTypeDelimiter",
          "p": 458753,
          "f": 65,
          "v": "\u002B"
        }
      ],
      "n": "GetTypeDisplayName",
      "o": "@$1",
      "d": 65624,
      "h": 25769869400,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869400),
//--TRIMMABLE-BOUNDARY-START(38654771288),
    {
      "r": 1310721,
      "p": [
        {
          "n": "builder",
          "p": 167051265,
          "f": 4
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "options",
          "p": 131160,
          "f": 8
        }
      ],
      "n": "ProcessType",
      "d": 65624,
      "h": 38654771288,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654771288),
//--TRIMMABLE-BOUNDARY-START(30064836696),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "options",
          "p": 131160,
          "f": 8
        }
      ],
      "n": "ProcessArrayType",
      "d": 65624,
      "h": 30064836696,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064836696),
//--TRIMMABLE-BOUNDARY-START(34359803992),
    {
      "r": 65537,
      "p": [
        {
          "n": "builder",
          "p": 167051265
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "genericArguments",
          "p": $.$typeArray($.$$.System.Type).$h
        },
        {
          "n": "length",
          "p": 655361
        },
        {
          "n": "options",
          "p": 131160,
          "f": 8
        }
      ],
      "n": "ProcessGenericType",
      "d": 65624,
      "h": 34359803992,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359803992)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934808),
    {
      "t": 458753,
      "n": "DefaultNestedTypeDelimiter",
      "d": 65624,
      "h": 17179934808,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17179934808),
//--TRIMMABLE-BOUNDARY-START(4295032920),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.String).$h,
      "n": "_builtInTypeNames",
      "d": 65624,
      "h": 4295032920,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295032920)
  ],
  "j": [131160
  ],
  "h": 65624
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65624)
        
        
        //--TRIMMABLE-BOUNDARY-START(1704024)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LoggerMessage", ($self) => class LoggerMessage
        {
            //--TRIMMABLE-BOUNDARY-START(98785951832)
            static /*Func<ILogger, IDisposable?> */ DefineScope(/*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785951832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 0);
                /*var*/ let logValues = new $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues().$ctor$3(formatter);
                return new ($.$$.System.Func$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues, logValues);
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(98785951832)
            
            //--TRIMMABLE-BOUNDARY-START(124555755608)
            static /*Func<ILogger, T1, IDisposable?> */ DefineScope$6(T1, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555755608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 1);
                return new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1))().$ctor$3(formatter, arg1));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1) => T1.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(124555755608)
            
            //--TRIMMABLE-BOUNDARY-START(120260788312)
            static /*Func<ILogger, T1, T2, IDisposable?> */ DefineScope$5(T1, T2, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260788312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 2);
                return new ($.$$.System.Func$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2))().$ctor$3(formatter, arg1, arg2));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2) => T2.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(120260788312)
            
            //--TRIMMABLE-BOUNDARY-START(115965821016)
            static /*Func<ILogger, T1, T2, T3, IDisposable?> */ DefineScope$4(T1, T2, T3, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965821016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 3);
                return new ($.$$.System.Func$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3))().$ctor$3(formatter, arg1, arg2, arg3));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3) => T3.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(115965821016)
            
            //--TRIMMABLE-BOUNDARY-START(111670853720)
            static /*Func<ILogger, T1, T2, T3, T4, IDisposable?> */ DefineScope$3(T1, T2, T3, T4, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670853720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 4);
                return new ($.$$.System.Func$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4))().$ctor$3(formatter, arg1, arg2, arg3, arg4));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4) => T4.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(111670853720)
            
            //--TRIMMABLE-BOUNDARY-START(107375886424)
            static /*Func<ILogger, T1, T2, T3, T4, T5, IDisposable?> */ DefineScope$2(T1, T2, T3, T4, T5, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375886424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 5);
                return new ($.$$.System.Func$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5))().$ctor$3(formatter, arg1, arg2, arg3, arg4, arg5));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4, T5) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4, T5) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4, T5) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4, T5) => T4.$h
    },
    {
      "n": "arg5",
      "p": (T1, T2, T3, T4, T5) => T5.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(107375886424)
            
            //--TRIMMABLE-BOUNDARY-START(103080919128)
            static /*Func<ILogger, T1, T2, T3, T4, T5, T6, IDisposable?> */ DefineScope$1(T1, T2, T3, T4, T5, T6, /*string*/ formatString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080919128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 6);
                return new ($.$$.System.Func$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*arg6*/ arg6) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6), new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6))().$ctor$3(formatter, arg1, arg2, arg3, arg4, arg5, arg6));
                }, {
  "r": 90308609,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4, T5, T6) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4, T5, T6) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4, T5, T6) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4, T5, T6) => T4.$h
    },
    {
      "n": "arg5",
      "p": (T1, T2, T3, T4, T5, T6) => T5.$h
    },
    {
      "n": "arg6",
      "p": (T1, T2, T3, T4, T5, T6) => T6.$h
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(103080919128)
            
            //--TRIMMABLE-BOUNDARY-START(42951376984)
            static /*Action<ILogger, Exception?> */ Define$1(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951376984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define(logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951376984)
            
            //--TRIMMABLE-BOUNDARY-START(38656409688)
            static /*Action<ILogger, Exception?> */ Define(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656409688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 0);
                /*void*/  function Log(/*ILogger*/ logger, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues, logLevel, eventId, new $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues().$ctor$3(formatter), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues.Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception))().$ctor(this,  (/**/ logger, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(38656409688)
            
            //--TRIMMABLE-BOUNDARY-START(94490984536)
            static /*Action<ILogger, T1, Exception?> */ Define$13(T1, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490984536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$12(T1, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490984536)
            
            //--TRIMMABLE-BOUNDARY-START(90196017240)
            static /*Action<ILogger, T1, Exception?> */ Define$12(T1, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196017240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 1);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1))().$ctor$3(formatter, arg1), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1) => T1.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(90196017240)
            
            //--TRIMMABLE-BOUNDARY-START(85901049944)
            static /*Action<ILogger, T1, T2, Exception?> */ Define$11(T1, T2, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901049944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$10(T1, T2, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901049944)
            
            //--TRIMMABLE-BOUNDARY-START(81606082648)
            static /*Action<ILogger, T1, T2, Exception?> */ Define$10(T1, T2, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606082648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 2);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2))().$ctor$3(formatter, arg1, arg2), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2) => T2.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(81606082648)
            
            //--TRIMMABLE-BOUNDARY-START(77311115352)
            static /*Action<ILogger, T1, T2, T3, Exception?> */ Define$9(T1, T2, T3, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77311115352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$8(T1, T2, T3, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77311115352)
            
            //--TRIMMABLE-BOUNDARY-START(73016148056)
            static /*Action<ILogger, T1, T2, T3, Exception?> */ Define$8(T1, T2, T3, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 3);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3))().$ctor$3(formatter, arg1, arg2, arg3), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3) => T3.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(73016148056)
            
            //--TRIMMABLE-BOUNDARY-START(68721180760)
            static /*Action<ILogger, T1, T2, T3, T4, Exception?> */ Define$7(T1, T2, T3, T4, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721180760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$6(T1, T2, T3, T4, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721180760)
            
            //--TRIMMABLE-BOUNDARY-START(64426213464)
            static /*Action<ILogger, T1, T2, T3, T4, Exception?> */ Define$6(T1, T2, T3, T4, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 4);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4))().$ctor$3(formatter, arg1, arg2, arg3, arg4), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4) => T4.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(64426213464)
            
            //--TRIMMABLE-BOUNDARY-START(60131246168)
            static /*Action<ILogger, T1, T2, T3, T4, T5, Exception?> */ Define$5(T1, T2, T3, T4, T5, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131246168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$4(T1, T2, T3, T4, T5, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131246168)
            
            //--TRIMMABLE-BOUNDARY-START(55836278872)
            static /*Action<ILogger, T1, T2, T3, T4, T5, Exception?> */ Define$4(T1, T2, T3, T4, T5, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 5);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*T5*/ arg5, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5))().$ctor$3(formatter, arg1, arg2, arg3, arg4, arg5), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, arg5, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4, T5) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4, T5) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4, T5) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4, T5) => T4.$h
    },
    {
      "n": "arg5",
      "p": (T1, T2, T3, T4, T5) => T5.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(55836278872)
            
            //--TRIMMABLE-BOUNDARY-START(51541311576)
            static /*Action<ILogger, T1, T2, T3, T4, T5, T6, Exception?> */ Define$3(T1, T2, T3, T4, T5, T6, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541311576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.Define$2(T1, T2, T3, T4, T5, T6, logLevel, eventId, formatString, null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541311576)
            
            //--TRIMMABLE-BOUNDARY-START(47246344280)
            static /*Action<ILogger, T1, T2, T3, T4, T5, T6, Exception?> */ Define$2(T1, T2, T3, T4, T5, T6, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LogValuesFormatter*/ let formatter = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 6);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*T5*/ arg5, /*T6*/ arg6, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6), logLevel, eventId, new ($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6))().$ctor$3(formatter, arg1, arg2, arg3, arg4, arg5, arg6), exception, $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$$.System.Action$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.Exception))().$ctor(this, Log);
                }
                return new ($.$$.System.Action$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*arg6*/ arg6, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, arg5, arg6, exception);
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "logger",
      "p": 917592
    },
    {
      "n": "arg1",
      "p": (T1, T2, T3, T4, T5, T6) => T1.$h
    },
    {
      "n": "arg2",
      "p": (T1, T2, T3, T4, T5, T6) => T2.$h
    },
    {
      "n": "arg3",
      "p": (T1, T2, T3, T4, T5, T6) => T3.$h
    },
    {
      "n": "arg4",
      "p": (T1, T2, T3, T4, T5, T6) => T4.$h
    },
    {
      "n": "arg5",
      "p": (T1, T2, T3, T4, T5, T6) => T5.$h
    },
    {
      "n": "arg6",
      "p": (T1, T2, T3, T4, T5, T6) => T6.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1704024,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(47246344280)
            
            //--TRIMMABLE-BOUNDARY-START(34361442392)
            static /*LogValuesFormatter */ CreateLogValuesFormatter(/*string*/ formatString, /*int*/ expectedNamedParameterCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361442392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let logValuesFormatter = new $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(formatString);
                /*int*/ let actualCount = logValuesFormatter.ValueNames.Count;
                if (actualCount !== expectedNamedParameterCount)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$mexla.System.SR.Format$4($.$mexla.System.SR.UnexpectedNumberOfNamedParameters, formatString, $.$box(expectedNamedParameterCount, $.$$.System.Int32), $.$box(actualCount, $.$$.System.Int32)));
                }
                return logValuesFormatter;
            }
            //--TRIMMABLE-BOUNDARY-END(34361442392)
            
            //--TRIMMABLE-BOUNDARY-START(1769560)
            static $_LogValues;
            static get LogValues()
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return $cls.$_LogValues ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues", ($self) => class LogValues extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21476606040)
                    /*Func<LogValues, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(21476606040)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296736856)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296736856)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181638744)
                    $ctor$3(/*LogValuesFormatter*/ formatter)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181638744);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181638744)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836344408)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        if (index === 0)
                        {
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                        }
                        throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836344408)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771573336)
                    /*int */ get Count()
                    {
                        return 1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771573336)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246409816)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            yield this.get_Item$1(0);
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246409816)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131311704)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60131311704);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.Format();
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(60131311704)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541377112)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51541377112);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541377112)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886671448)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886671448)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296736856)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4296736856)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(8591704152)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(21476606040)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues, $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues.ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": 1769560
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": 1769560,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(21476606040)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591704152)
                    
                    static $h = 1769560;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836344408),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951442520,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1769560,
      "h": 55836344408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836344408),
//--TRIMMABLE-BOUNDARY-START(25771573336),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361507928,
        "f": 50331649
      },
      "n": "Count",
      "d": 1769560,
      "h": 25771573336,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771573336)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246409816),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": 1769560,
      "h": 47246409816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246409816),
//--TRIMMABLE-BOUNDARY-START(60131311704),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1769560,
      "h": 60131311704,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131311704)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476606040),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues, $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": 1769560,
      "h": 21476606040,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476606040),
//--TRIMMABLE-BOUNDARY-START(4296736856),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": 1769560,
      "h": 4296736856,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736856)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181638744),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769560,
      "h": 17181638744,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638744),
//--TRIMMABLE-BOUNDARY-START(12886671448),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769560,
      "h": 12886671448,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671448)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "d": 1704024,
  "h": 1769560
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues`; }
                }, $cls, ($v) => $cls.$_LogValues = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769560)
            
            //--TRIMMABLE-BOUNDARY-START(2162776)
            static $_LogValues$$;
            static LogValues$$(T0)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<>", (T0) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<>", [T0], ($self) => class LogValues$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(25771966552)
                    /*Func<LogValues<T0>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(25771966552)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297130072)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297130072)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592097368)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592097368)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476999256)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476999256);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476999256)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131704920)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131704920)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066933848)
                    /*int */ get Count()
                    {
                        return 2;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066933848)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541770328)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541770328)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426672216)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64426672216);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.Format$4(T0, this._value0);
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(64426672216)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836737624)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836737624);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836737624)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182031960)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182031960)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4297130072)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4297130072)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592097368)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8592097368)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(12887064664)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(25771966552)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(25771966552)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887064664)
                    
                    static $h = 2162776;
                    static $g = 1;
                    static $z = 8;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131704920),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131704920),
//--TRIMMABLE-BOUNDARY-START(30066933848),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066933848)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541770328),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541770328),
//--TRIMMABLE-BOUNDARY-START(64426672216),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426672216)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771966552),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771966552),
//--TRIMMABLE-BOUNDARY-START(4297130072),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297130072),
//--TRIMMABLE-BOUNDARY-START(8592097368),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097368)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476999256),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476999256),
//--TRIMMABLE-BOUNDARY-START(17182031960),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182031960)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328
  ],
  "r": 1,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$ = $v))(T0);
            }
            //--TRIMMABLE-BOUNDARY-END(2162776)
            
            //--TRIMMABLE-BOUNDARY-START(2097240)
            static $_LogValues$$$;
            static LogValues$$$(T0, T1)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,>", (T0, T1) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,>", [T0, T1], ($self) => class LogValues$$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(30066868312)
                    /*Func<LogValues<T0, T1>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(30066868312)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297064536)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297064536)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592031832)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592031832)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886999128)
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886999128)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771901016)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771901016);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771901016)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426606680)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426606680)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361835608)
                    /*int */ get Count()
                    {
                        return 3;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361835608)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836672088)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836672088)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721573976)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68721573976);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.Format$3(T0, T1, this._value0, this._value1);
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(68721573976)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131639384)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60131639384);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131639384)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933720)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476933720)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4297064536)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4297064536)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592031832)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8592031832)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886999128)
                        this._value1 = $.$default(T1);
                        //--TRIMMABLE-BOUNDARY-END(12886999128)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(17181966424)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(30066868312)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(30066868312)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181966424)
                    
                    static $h = 2097240;
                    static $g = 2;
                    static $z = 12;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64426606680),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426606680),
//--TRIMMABLE-BOUNDARY-START(34361835608),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361835608)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836672088),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55836672088),
//--TRIMMABLE-BOUNDARY-START(68721573976),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68721573976)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30066868312),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066868312),
//--TRIMMABLE-BOUNDARY-START(4297064536),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297064536),
//--TRIMMABLE-BOUNDARY-START(8592031832),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592031832),
//--TRIMMABLE-BOUNDARY-START(12886999128),
    {
      "t": T1?.$h??1572864,
      "n": "_value1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886999128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771901016),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        },
        {
          "n": "value1",
          "p": T1?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771901016),
//--TRIMMABLE-BOUNDARY-START(21476933720),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476933720)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328,T1?.$h??1572864
  ],
  "r": 2,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$ = $v))(T0, T1);
            }
            //--TRIMMABLE-BOUNDARY-END(2097240)
            
            //--TRIMMABLE-BOUNDARY-START(2031704)
            static $_LogValues$$$$;
            static LogValues$$$$(T0, T1, T2)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,>", (T0, T1, T2) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,>", [T0, T1, T2], ($self) => class LogValues$$$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(34361770072)
                    /*Func<LogValues<T0, T1, T2>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(34361770072)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296999000)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296999000)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591966296)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591966296)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886933592)
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886933592)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181900888)
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181900888)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656737368)
                    /*int */ get Count()
                    {
                        return 4;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656737368)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721508440)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721508440)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066802776)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066802776);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066802776)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016475736)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(73016475736);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.Format$2(T0, T1, T2, this._value0, this._value1, this._value2);
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(73016475736)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131573848)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131573848)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426541144)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426541144);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426541144)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771835480)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771835480)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296999000)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4296999000)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591966296)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8591966296)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886933592)
                        this._value1 = $.$default(T1);
                        //--TRIMMABLE-BOUNDARY-END(12886933592)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181900888)
                        this._value2 = $.$default(T2);
                        //--TRIMMABLE-BOUNDARY-END(17181900888)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(21476868184)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(34361770072)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(34361770072)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476868184)
                    
                    static $h = 2031704;
                    static $g = 3;
                    static $z = 16;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38656737368),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656737368),
//--TRIMMABLE-BOUNDARY-START(68721508440),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721508440)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016475736),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73016475736),
//--TRIMMABLE-BOUNDARY-START(60131573848),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131573848)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361770072),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361770072),
//--TRIMMABLE-BOUNDARY-START(4296999000),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296999000),
//--TRIMMABLE-BOUNDARY-START(8591966296),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966296),
//--TRIMMABLE-BOUNDARY-START(12886933592),
    {
      "t": T1?.$h??1572864,
      "n": "_value1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933592),
//--TRIMMABLE-BOUNDARY-START(17181900888),
    {
      "t": T2?.$h??1638400,
      "n": "_value2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181900888)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30066802776),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        },
        {
          "n": "value1",
          "p": T1?.$h??1572864
        },
        {
          "n": "value2",
          "p": T2?.$h??1638400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066802776),
//--TRIMMABLE-BOUNDARY-START(25771835480),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771835480)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400
  ],
  "r": 3,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$ = $v))(T0, T1, T2);
            }
            //--TRIMMABLE-BOUNDARY-END(2031704)
            
            //--TRIMMABLE-BOUNDARY-START(1966168)
            static $_LogValues$$$$$;
            static LogValues$$$$$(T0, T1, T2, T3)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,>", (T0, T1, T2, T3) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,>", [T0, T1, T2, T3], ($self) => class LogValues$$$$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(38656671832)
                    /*Func<LogValues<T0, T1, T2, T3>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(38656671832)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296933464)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296933464)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591900760)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591900760)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886868056)
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886868056)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181835352)
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181835352)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476802648)
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476802648)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951639128)
                    /*int */ get Count()
                    {
                        return 5;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951639128)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016410200)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016410200)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361704536)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361704536);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361704536)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311377496)
                    /*object?[] */ ToArray()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(77311377496);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3)], [-1], null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311377496)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606344792)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81606344792);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.FormatWithOverwrite(this.ToArray());
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(81606344792)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426475608)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426475608)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721442904)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68721442904);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721442904)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066737240)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066737240)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296933464)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4296933464)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591900760)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8591900760)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886868056)
                        this._value1 = $.$default(T1);
                        //--TRIMMABLE-BOUNDARY-END(12886868056)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181835352)
                        this._value2 = $.$default(T2);
                        //--TRIMMABLE-BOUNDARY-END(17181835352)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476802648)
                        this._value3 = $.$default(T3);
                        //--TRIMMABLE-BOUNDARY-END(21476802648)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(25771769944)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(38656671832)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(38656671832)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771769944)
                    
                    static $h = 1966168;
                    static $g = 4;
                    static $z = 20;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951639128),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951639128),
//--TRIMMABLE-BOUNDARY-START(73016410200),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016410200)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77311377496),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77311377496),
//--TRIMMABLE-BOUNDARY-START(81606344792),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606344792),
//--TRIMMABLE-BOUNDARY-START(64426475608),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426475608)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38656671832),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656671832),
//--TRIMMABLE-BOUNDARY-START(4296933464),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933464),
//--TRIMMABLE-BOUNDARY-START(8591900760),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900760),
//--TRIMMABLE-BOUNDARY-START(12886868056),
    {
      "t": T1?.$h??1572864,
      "n": "_value1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886868056),
//--TRIMMABLE-BOUNDARY-START(17181835352),
    {
      "t": T2?.$h??1638400,
      "n": "_value2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835352),
//--TRIMMABLE-BOUNDARY-START(21476802648),
    {
      "t": T3?.$h??1703936,
      "n": "_value3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802648)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361704536),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        },
        {
          "n": "value1",
          "p": T1?.$h??1572864
        },
        {
          "n": "value2",
          "p": T2?.$h??1638400
        },
        {
          "n": "value3",
          "p": T3?.$h??1703936
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361704536),
//--TRIMMABLE-BOUNDARY-START(30066737240),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066737240)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936
  ],
  "r": 4,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$ = $v))(T0, T1, T2, T3);
            }
            //--TRIMMABLE-BOUNDARY-END(1966168)
            
            //--TRIMMABLE-BOUNDARY-START(1900632)
            static $_LogValues$$$$$$;
            static LogValues$$$$$$(T0, T1, T2, T3, T4)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,>", (T0, T1, T2, T3, T4) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,>", [T0, T1, T2, T3, T4], ($self) => class LogValues$$$$$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(42951573592)
                    /*Func<LogValues<T0, T1, T2, T3, T4>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(42951573592)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296867928)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296867928)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835224)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591835224)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802520)
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886802520)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769816)
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181769816)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737112)
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476737112)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771704408)
                    /*T4*/  get _value4() { return this.$getField(20, 4); }
                    /*T4*/  set _value4(value) { this.$setField(20, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771704408)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540888)
                    /*int */ get Count()
                    {
                        return 6;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246540888)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311311960)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(4), $.$box(this._value4, T4));
                            case 5:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311311960)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656606296)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3, /*T4*/ value4)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38656606296);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                            this._value4 = value4;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656606296)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606279256)
                    /*object?[] */ ToArray()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81606279256);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3), $.$box(this._value4, T4)], [-1], null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606279256)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901246552)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(85901246552);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.FormatWithOverwrite(this.ToArray());
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(85901246552)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721377368)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721377368)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016344664)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73016344664);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016344664)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361639000)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361639000)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        copy._value4 = this._value4;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296867928)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4296867928)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591835224)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8591835224)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886802520)
                        this._value1 = $.$default(T1);
                        //--TRIMMABLE-BOUNDARY-END(12886802520)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181769816)
                        this._value2 = $.$default(T2);
                        //--TRIMMABLE-BOUNDARY-END(17181769816)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476737112)
                        this._value3 = $.$default(T3);
                        //--TRIMMABLE-BOUNDARY-END(21476737112)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771704408)
                        this._value4 = $.$default(T4);
                        //--TRIMMABLE-BOUNDARY-END(25771704408)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(30066671704)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(42951573592)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(42951573592)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066671704)
                    
                    static $h = 1900632;
                    static $g = 5;
                    static $z = 24;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246540888),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246540888),
//--TRIMMABLE-BOUNDARY-START(77311311960),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311311960)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81606279256),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81606279256),
//--TRIMMABLE-BOUNDARY-START(85901246552),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901246552),
//--TRIMMABLE-BOUNDARY-START(68721377368),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721377368)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951573592),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951573592),
//--TRIMMABLE-BOUNDARY-START(4296867928),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867928),
//--TRIMMABLE-BOUNDARY-START(8591835224),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835224),
//--TRIMMABLE-BOUNDARY-START(12886802520),
    {
      "t": T1?.$h??1572864,
      "n": "_value1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886802520),
//--TRIMMABLE-BOUNDARY-START(17181769816),
    {
      "t": T2?.$h??1638400,
      "n": "_value2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181769816),
//--TRIMMABLE-BOUNDARY-START(21476737112),
    {
      "t": T3?.$h??1703936,
      "n": "_value3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476737112),
//--TRIMMABLE-BOUNDARY-START(25771704408),
    {
      "t": T4?.$h??1769472,
      "n": "_value4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771704408)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656606296),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        },
        {
          "n": "value1",
          "p": T1?.$h??1572864
        },
        {
          "n": "value2",
          "p": T2?.$h??1638400
        },
        {
          "n": "value3",
          "p": T3?.$h??1703936
        },
        {
          "n": "value4",
          "p": T4?.$h??1769472
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656606296),
//--TRIMMABLE-BOUNDARY-START(34361639000),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361639000)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936,T4?.$h??1769472
  ],
  "r": 5,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$$ = $v))(T0, T1, T2, T3, T4);
            }
            //--TRIMMABLE-BOUNDARY-END(1900632)
            
            //--TRIMMABLE-BOUNDARY-START(1835096)
            static $_LogValues$$$$$$$;
            static LogValues$$$$$$$(T0, T1, T2, T3, T4, T5)
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$$$ ??= $asm.$nstr("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,,>", (T0, T1, T2, T3, T4, T5) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,,>", [T0, T1, T2, T3, T4, T5], ($self) => class LogValues$$$$$$$ extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(47246475352)
                    /*Func<LogValues<T0, T1, T2, T3, T4, T5>, Exception?, string>*/ static Callback = null;
                    //--TRIMMABLE-BOUNDARY-END(47246475352)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296802392)
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296802392)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591769688)
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591769688)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886736984)
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886736984)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181704280)
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181704280)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476671576)
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476671576)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771638872)
                    /*T4*/  get _value4() { return this.$getField(20, 4); }
                    /*T4*/  set _value4(value) { this.$setField(20, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771638872)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066606168)
                    /*T5*/  get _value5() { return this.$getField(24, 4); }
                    /*T5*/  set _value5(value) { this.$setField(24, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(30066606168)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541442648)
                    /*int */ get Count()
                    {
                        return 7;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51541442648)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606213720)
                    /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(4), $.$box(this._value4, T4));
                            case 5:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3(this._formatter.ValueNames.get_Item(5), $.$box(this._value5, T5));
                            case 6:
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606213720)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951508056)
                    $ctor$3(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3, /*T4*/ value4, /*T5*/ value5)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42951508056);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                            this._value4 = value4;
                            this._value5 = value5;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951508056)
                    
                    //--TRIMMABLE-BOUNDARY-START(85901181016)
                    /*object?[] */ ToArray()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(85901181016);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3), $.$box(this._value4, T4), $.$box(this._value5, T5)], [-1], null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85901181016)
                    
                    //--TRIMMABLE-BOUNDARY-START(90196148312)
                    static/*conventional*/ /*string */ ToString()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(90196148312);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._formatter.FormatWithOverwrite(this.ToArray());
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5).ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(90196148312)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016279128)
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item$1(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016279128)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311246424)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311246424);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311246424)
                    
                    //--TRIMMABLE-BOUNDARY-START(8650096641)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8650096641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8650096641)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656540760)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656540760)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        copy._value4 = this._value4;
                        copy._value5 = this._value5;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4296802392)
                        this._formatter = null;
                        //--TRIMMABLE-BOUNDARY-END(4296802392)
                        
                        //--TRIMMABLE-BOUNDARY-START(8591769688)
                        this._value0 = $.$default(T0);
                        //--TRIMMABLE-BOUNDARY-END(8591769688)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886736984)
                        this._value1 = $.$default(T1);
                        //--TRIMMABLE-BOUNDARY-END(12886736984)
                        
                        //--TRIMMABLE-BOUNDARY-START(17181704280)
                        this._value2 = $.$default(T2);
                        //--TRIMMABLE-BOUNDARY-END(17181704280)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476671576)
                        this._value3 = $.$default(T3);
                        //--TRIMMABLE-BOUNDARY-END(21476671576)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771638872)
                        this._value4 = $.$default(T4);
                        //--TRIMMABLE-BOUNDARY-END(25771638872)
                        
                        //--TRIMMABLE-BOUNDARY-START(30066606168)
                        this._value5 = $.$default(T5);
                        //--TRIMMABLE-BOUNDARY-END(30066606168)
                        
                    }
                    //--TRIMMABLE-BOUNDARY-START(34361573464)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(47246475352)
                            this.Callback = new ($.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5), $.$$.System.Exception, $.$$.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5).ToString.call(state);
                            }, {
  "r": 1310721,
  "p": [
    {
      "n": "state",
      "p": this.$h
    },
    {
      "n": "exception",
      "p": 80019457
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
});
                            //--TRIMMABLE-BOUNDARY-END(47246475352)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361573464)
                    
                    static $h = 1835096;
                    static $g = 6;
                    static $z = 28;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541442648),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541442648),
//--TRIMMABLE-BOUNDARY-START(81606213720),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606213720)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85901181016),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901181016),
//--TRIMMABLE-BOUNDARY-START(90196148312),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196148312),
//--TRIMMABLE-BOUNDARY-START(73016279128),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016279128)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47246475352),
    {
      "t": $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5), $.$$.System.Exception, $.$$.System.String).$h,
      "n": "Callback",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246475352),
//--TRIMMABLE-BOUNDARY-START(4296802392),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802392),
//--TRIMMABLE-BOUNDARY-START(8591769688),
    {
      "t": T0?.$h??1507328,
      "n": "_value0",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591769688),
//--TRIMMABLE-BOUNDARY-START(12886736984),
    {
      "t": T1?.$h??1572864,
      "n": "_value1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886736984),
//--TRIMMABLE-BOUNDARY-START(17181704280),
    {
      "t": T2?.$h??1638400,
      "n": "_value2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181704280),
//--TRIMMABLE-BOUNDARY-START(21476671576),
    {
      "t": T3?.$h??1703936,
      "n": "_value3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476671576),
//--TRIMMABLE-BOUNDARY-START(25771638872),
    {
      "t": T4?.$h??1769472,
      "n": "_value4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771638872),
//--TRIMMABLE-BOUNDARY-START(30066606168),
    {
      "t": T5?.$h??1835008,
      "n": "_value5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066606168)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951508056),
    {
      "p": [
        {
          "n": "formatter",
          "p": 2359384
        },
        {
          "n": "value0",
          "p": T0?.$h??1507328
        },
        {
          "n": "value1",
          "p": T1?.$h??1572864
        },
        {
          "n": "value2",
          "p": T2?.$h??1638400
        },
        {
          "n": "value3",
          "p": T3?.$h??1703936
        },
        {
          "n": "value4",
          "p": T4?.$h??1769472
        },
        {
          "n": "value5",
          "p": T5?.$h??1835008
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951508056),
//--TRIMMABLE-BOUNDARY-START(38656540760),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656540760)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "g": [T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936,T4?.$h??1769472,T5?.$h??1835008
  ],
  "r": 6,
  "d": 1704024,
  "h": this.$h
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName},${T5?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$$$ = $v))(T0, T1, T2, T3, T4, T5);
            }
            //--TRIMMABLE-BOUNDARY-END(1835096)
            
            static $h = 1704024;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785951832),
    {
      "r": $.$$.System.Func$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "n": "DefineScope",
      "d": 1704024,
      "h": 98785951832,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98785951832),
//--TRIMMABLE-BOUNDARY-START(124555755608),
    {
      "r": (T1) => $.$$.System.Func$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1"
      ],
      "n": "DefineScope",
      "o": "@$6",
      "d": 1704024,
      "h": 124555755608,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124555755608),
//--TRIMMABLE-BOUNDARY-START(120260788312),
    {
      "r": (T1, T2) => $.$$.System.Func$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "DefineScope",
      "o": "@$5",
      "d": 1704024,
      "h": 120260788312,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120260788312),
//--TRIMMABLE-BOUNDARY-START(115965821016),
    {
      "r": (T1, T2, T3) => $.$$.System.Func$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "DefineScope",
      "o": "@$4",
      "d": 1704024,
      "h": 115965821016,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115965821016),
//--TRIMMABLE-BOUNDARY-START(111670853720),
    {
      "r": (T1, T2, T3, T4) => $.$$.System.Func$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4"
      ],
      "n": "DefineScope",
      "o": "@$3",
      "d": 1704024,
      "h": 111670853720,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111670853720),
//--TRIMMABLE-BOUNDARY-START(107375886424),
    {
      "r": (T1, T2, T3, T4, T5) => $.$$.System.Func$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5"
      ],
      "n": "DefineScope",
      "o": "@$2",
      "d": 1704024,
      "h": 107375886424,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107375886424),
//--TRIMMABLE-BOUNDARY-START(103080919128),
    {
      "r": (T1, T2, T3, T4, T5, T6) => $.$$.System.Func$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.IDisposable).$h,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6"
      ],
      "n": "DefineScope",
      "o": "@$1",
      "d": 1704024,
      "h": 103080919128,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103080919128),
//--TRIMMABLE-BOUNDARY-START(42951376984),
    {
      "r": $.$$.System.Action$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "n": "Define",
      "o": "@$1",
      "d": 1704024,
      "h": 42951376984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951376984),
//--TRIMMABLE-BOUNDARY-START(38656409688),
    {
      "r": $.$$.System.Action$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "n": "Define",
      "d": 1704024,
      "h": 38656409688,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656409688),
//--TRIMMABLE-BOUNDARY-START(94490984536),
    {
      "r": (T1) => $.$$.System.Action$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1"
      ],
      "n": "Define",
      "o": "@$13",
      "d": 1704024,
      "h": 94490984536,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94490984536),
//--TRIMMABLE-BOUNDARY-START(90196017240),
    {
      "r": (T1) => $.$$.System.Action$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1"
      ],
      "n": "Define",
      "o": "@$12",
      "d": 1704024,
      "h": 90196017240,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(90196017240),
//--TRIMMABLE-BOUNDARY-START(85901049944),
    {
      "r": (T1, T2) => $.$$.System.Action$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "Define",
      "o": "@$11",
      "d": 1704024,
      "h": 85901049944,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(85901049944),
//--TRIMMABLE-BOUNDARY-START(81606082648),
    {
      "r": (T1, T2) => $.$$.System.Action$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1",
        "T2"
      ],
      "n": "Define",
      "o": "@$10",
      "d": 1704024,
      "h": 81606082648,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(81606082648),
//--TRIMMABLE-BOUNDARY-START(77311115352),
    {
      "r": (T1, T2, T3) => $.$$.System.Action$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "Define",
      "o": "@$9",
      "d": 1704024,
      "h": 77311115352,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(77311115352),
//--TRIMMABLE-BOUNDARY-START(73016148056),
    {
      "r": (T1, T2, T3) => $.$$.System.Action$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3"
      ],
      "n": "Define",
      "o": "@$8",
      "d": 1704024,
      "h": 73016148056,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(73016148056),
//--TRIMMABLE-BOUNDARY-START(68721180760),
    {
      "r": (T1, T2, T3, T4) => $.$$.System.Action$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4"
      ],
      "n": "Define",
      "o": "@$7",
      "d": 1704024,
      "h": 68721180760,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(68721180760),
//--TRIMMABLE-BOUNDARY-START(64426213464),
    {
      "r": (T1, T2, T3, T4) => $.$$.System.Action$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4"
      ],
      "n": "Define",
      "o": "@$6",
      "d": 1704024,
      "h": 64426213464,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64426213464),
//--TRIMMABLE-BOUNDARY-START(60131246168),
    {
      "r": (T1, T2, T3, T4, T5) => $.$$.System.Action$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5"
      ],
      "n": "Define",
      "o": "@$5",
      "d": 1704024,
      "h": 60131246168,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60131246168),
//--TRIMMABLE-BOUNDARY-START(55836278872),
    {
      "r": (T1, T2, T3, T4, T5) => $.$$.System.Action$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5"
      ],
      "n": "Define",
      "o": "@$4",
      "d": 1704024,
      "h": 55836278872,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(55836278872),
//--TRIMMABLE-BOUNDARY-START(51541311576),
    {
      "r": (T1, T2, T3, T4, T5, T6) => $.$$.System.Action$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6"
      ],
      "n": "Define",
      "o": "@$3",
      "d": 1704024,
      "h": 51541311576,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(51541311576),
//--TRIMMABLE-BOUNDARY-START(47246344280),
    {
      "r": (T1, T2, T3, T4, T5, T6) => $.$$.System.Action$$$$$$$$$($.$mexla.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$$.System.Exception).$h,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 1310808
        }
      ],
      "g": [
        "T1",
        "T2",
        "T3",
        "T4",
        "T5",
        "T6"
      ],
      "n": "Define",
      "o": "@$2",
      "d": 1704024,
      "h": 47246344280,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47246344280),
//--TRIMMABLE-BOUNDARY-START(34361442392),
    {
      "r": 2359384,
      "p": [
        {
          "n": "formatString",
          "p": 1310721
        },
        {
          "n": "expectedNamedParameterCount",
          "p": 655361
        }
      ],
      "n": "CreateLogValuesFormatter",
      "d": 1704024,
      "h": 34361442392,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361442392)
  ],
  "j": [1769560,2162776,2097240,2031704,1966168,1900632,1835096
  ],
  "h": 1704024
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704024)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490456)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.NullScope", ($self) => class NullScope extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30067261528)
            /*NullScope*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30067261528)
            
            //--TRIMMABLE-BOUNDARY-START(12887392344)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887392344);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887392344)
            
            //--TRIMMABLE-BOUNDARY-START(17182359640)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182359640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17182359640)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(8592425048)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mexla.Microsoft.Extensions.Logging.NullScope().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592425048)
            
            static $h = 2490456;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30067261528),
    {
      "p": 2490456,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25772294232,
        "f": 50331681
      },
      "n": "Instance",
      "d": 2490456,
      "h": 30067261528,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30067261528)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182359640),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2490456,
      "h": 17182359640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182359640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887392344),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2490456,
      "h": 12887392344,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887392344)
  ],
  "i": [90308609
  ],
  "h": 2490456
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490456)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424920)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.NullExternalScopeProvider", ($self) => class NullExternalScopeProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12887326808)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887326808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887326808)
            
            //--TRIMMABLE-BOUNDARY-START(25772228696)
            /*IExternalScopeProvider*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25772228696)
            
            //--TRIMMABLE-BOUNDARY-START(30067195992)
            /*void */ Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067195992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30067195992)
            
            //--TRIMMABLE-BOUNDARY-START(34362163288)
            /*IDisposable */ Microsoft$Extensions$Logging$IExternalScopeProvider$Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362163288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(34362163288)
            
            //--TRIMMABLE-BOUNDARY-START(8592359512)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mexla.Microsoft.Extensions.Logging.NullExternalScopeProvider().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8592359512)
            
            static $h = 2424920;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772228696),
    {
      "p": 852056,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477261400,
        "f": 50331681
      },
      "n": "Instance",
      "d": 2424920,
      "h": 25772228696,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25772228696)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887326808),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424920,
      "h": 12887326808,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12887326808)
  ],
  "i": [852056
  ],
  "h": 2424920
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullExternalScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424920)
        
        
        //--TRIMMABLE-BOUNDARY-START(393304)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger", ($self) => class NullLogger extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(30065164376)
            /*NullLogger*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(30065164376)
            
            //--TRIMMABLE-BOUNDARY-START(12885295192)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295192);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295192)
            
            //--TRIMMABLE-BOUNDARY-START(17180262488)
            /*IDisposable */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262488)
            
            //--TRIMMABLE-BOUNDARY-START(34360131672)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(34360131672)
            
            //--TRIMMABLE-BOUNDARY-START(38655098968)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655098968)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            //--TRIMMABLE-BOUNDARY-START(8590327896)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327896)
            
            static $h = 393304;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065164376),
    {
      "p": 393304,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197080,
        "f": 50331681
      },
      "n": "Instance",
      "d": 393304,
      "h": 30065164376,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065164376)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180262488),
    {
      "r": 90308609,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": 393304,
      "h": 17180262488,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17180262488),
//--TRIMMABLE-BOUNDARY-START(34360131672),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": 393304,
      "h": 34360131672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360131672),
//--TRIMMABLE-BOUNDARY-START(38655098968),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": 393304,
      "h": 38655098968,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(38655098968)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885295192),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393304,
      "h": 12885295192,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885295192)
  ],
  "i": [917592
  ],
  "h": 393304
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLogger`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393304)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507416)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider", ($self) => class LoggerExternalScopeProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474712)
            /*AsyncLocal<Scope?>*/ _currentScope = null;
            //--TRIMMABLE-BOUNDARY-END(4296474712)
            
            //--TRIMMABLE-BOUNDARY-START(12886409304)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409304)
            
            //--TRIMMABLE-BOUNDARY-START(17181376600)
            /*void */ ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*void*/  function Report(/*Scope?*/ current)
                {
                    if (current === null)
                    {
                        return;
                    }
                    Report.call(this, current.Parent);
                    callback.Invoke(current.State, state);
                }
                Report.call(this, this._currentScope.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(17181376600)
            
            //--TRIMMABLE-BOUNDARY-START(21476343896)
            /*IDisposable */ Push(/*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Scope?*/ let parent = this._currentScope.Value;
                /*var*/ let newScope = new $.$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope().$ctor$1(this, state, parent);
                this._currentScope.Value = newScope;
                return newScope;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343896)
            
            //--TRIMMABLE-BOUNDARY-START(1572952)
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider;
                return $cls.$_Scope ??= $asm.$ncls("$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope", ($self) => class Scope extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591507544)
                    /*LoggerExternalScopeProvider*/ _provider = null;
                    //--TRIMMABLE-BOUNDARY-END(8591507544)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296540248)
                    /*bool*/ _isDisposed = false;
                    //--TRIMMABLE-BOUNDARY-END(4296540248)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476409432)
                    $ctor$1(/*LoggerExternalScopeProvider*/ provider, /*object?*/ state, /*Scope?*/ parent)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476409432);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._provider = provider;
                            this.State = state;
                            this.Parent = parent;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476409432)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246213208)
                    /*Scope?*/ Parent = null;
                    //--TRIMMABLE-BOUNDARY-END(47246213208)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541180504)
                    /*object?*/ State = null;
                    //--TRIMMABLE-BOUNDARY-END(51541180504)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836147800)
                    static/*conventional*/ /*string? */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836147800);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        const $t1 = this.State;
                        return $.$ifnn($t1, ($t) => $.$$.System.Object.ToString.call($t));
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(55836147800)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771376728)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771376728);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this._isDisposed)
                        {
                            this._provider._currentScope.Value = this.Parent;
                            this._isDisposed = true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771376728)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    static $h = 1572952;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246213208),
    {
      "p": 1572952,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361311320,
        "f": 50331649
      },
      "n": "Parent",
      "d": 1572952,
      "h": 47246213208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246213208),
//--TRIMMABLE-BOUNDARY-START(51541180504),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951245912,
        "f": 50331649
      },
      "n": "State",
      "d": 1572952,
      "h": 51541180504,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541180504)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836147800),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1572952,
      "h": 55836147800,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55836147800),
//--TRIMMABLE-BOUNDARY-START(25771376728),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1572952,
      "h": 25771376728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376728)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507544),
    {
      "t": 1507416,
      "n": "_provider",
      "d": 1572952,
      "h": 8591507544,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507544),
//--TRIMMABLE-BOUNDARY-START(4296540248),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": 1572952,
      "h": 4296540248,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476409432),
    {
      "p": [
        {
          "n": "provider",
          "p": 1507416
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "parent",
          "p": 1572952
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572952,
      "h": 21476409432,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476409432)
  ],
  "i": [90308609
  ],
  "d": 1507416,
  "h": 1572952
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1572952)
            
            //--TRIMMABLE-BOUNDARY-START(4295819352)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.ForEachScope<TState>(System.Action<object?, TState>, TState)
            Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ForEachScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295819352)
            
            //--TRIMMABLE-BOUNDARY-START(8590786648)
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.Push(object?)
            Microsoft$Extensions$Logging$IExternalScopeProvider$Push()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Push(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590786648)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296474712)
                this._currentScope = new ($.$$.System.Threading.AsyncLocal$$($.$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296474712)
                
            }
            static $h = 1507416;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181376600),
    {
      "r": 65537,
      "p": [
        {
          "n": "callback",
          "p": (TState) => $.$$.System.Action$$$($.$$.System.Object, TState).$h
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "ForEachScope",
      "d": 1507416,
      "h": 17181376600,
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(17181376600),
//--TRIMMABLE-BOUNDARY-START(21476343896),
    {
      "r": 90308609,
      "p": [
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 1507416,
      "h": 21476343896,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343896)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474712),
    {
      "t": $.$$.System.Threading.AsyncLocal$$($.$mexla.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope).$h,
      "n": "_currentScope",
      "d": 1507416,
      "h": 4296474712,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474712)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886409304),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507416,
      "h": 12886409304,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409304)
  ],
  "i": [852056
  ],
  "j": [1572952
  ],
  "h": 1507416
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExternalScopeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507416)
        
        
        //--TRIMMABLE-BOUNDARY-START(524376)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory", ($self) => class NullLoggerFactory extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590458968)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458968);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458968)
            
            //--TRIMMABLE-BOUNDARY-START(25770328152)
            /*NullLoggerFactory*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(25770328152)
            
            //--TRIMMABLE-BOUNDARY-START(17180393560)
            /*ILogger */ CreateLogger(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180393560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393560)
            
            //--TRIMMABLE-BOUNDARY-START(12885426264)
            /*void */ AddProvider(/*ILoggerProvider*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885426264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885426264)
            
            //--TRIMMABLE-BOUNDARY-START(21475360856)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475360856)
            
            //--TRIMMABLE-BOUNDARY-START(8590983256)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983256)
            
            //--TRIMMABLE-BOUNDARY-START(4296015960)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
            Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.AddProvider(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296015960)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(4295491672)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328152)
                    this.Instance = new $.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(25770328152)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491672)
            
            static $h = 524376;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393560),
    {
      "r": 917592,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 524376,
      "h": 17180393560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393560),
//--TRIMMABLE-BOUNDARY-START(12885426264),
    {
      "r": 65537,
      "p": [
        {
          "n": "provider",
          "p": 1114200
        }
      ],
      "n": "AddProvider",
      "d": 524376,
      "h": 12885426264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426264),
//--TRIMMABLE-BOUNDARY-START(21475360856),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 524376,
      "h": 21475360856,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360856)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328152),
    {
      "t": 524376,
      "n": "Instance",
      "d": 524376,
      "h": 25770328152,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328152)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458968),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524376,
      "h": 8590458968,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458968)
  ],
  "i": [1048664,90308609
  ],
  "h": 524376
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILoggerFactory, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524376)
        
        
        //--TRIMMABLE-BOUNDARY-START(458840)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger<>", (T) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger<>", [T], ($self) => class NullLogger$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180328024)
            /*NullLogger<T>*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(17180328024)
            
            //--TRIMMABLE-BOUNDARY-START(12885360728)
            /*IDisposable */ BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360728)
            
            //--TRIMMABLE-BOUNDARY-START(25770262616)
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770262616)
            
            //--TRIMMABLE-BOUNDARY-START(21475295320)
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295320)
            
            //--TRIMMABLE-BOUNDARY-START(12885819480)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Log(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819480)
            
            //--TRIMMABLE-BOUNDARY-START(8590852184)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsEnabled(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852184)
            
            //--TRIMMABLE-BOUNDARY-START(4295884888)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BeginScope(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884888)
            
            //--TRIMMABLE-BOUNDARY-START(8590393432)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393432)
            
            //--TRIMMABLE-BOUNDARY-START(4295426136)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180328024)
                    this.Instance = new ($.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger$$(T))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17180328024)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295426136)
            
            static $h = 458840;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360728),
    {
      "r": 90308609,
      "p": [
        {
          "n": "state",
          "p": (TState) => TState.$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "BeginScope",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(12885360728),
//--TRIMMABLE-BOUNDARY-START(25770262616),
    {
      "r": 65537,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": (TState) => TState.$h
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "formatter",
          "p": (TState) => $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "g": [
        "TState"
      ],
      "n": "Log",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(25770262616),
//--TRIMMABLE-BOUNDARY-START(21475295320),
    {
      "r": 262145,
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        }
      ],
      "n": "IsEnabled",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295320)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180328024),
    {
      "t": this.$h,
      "n": "Instance",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180328024)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393432),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393432)
  ],
  "i": [$.$mexla.Microsoft.Extensions.Logging.ILogger$$(T).$h,917592
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILogger$$(T), $.$mexla.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLogger<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458840)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376344)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Logger<>", (T) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.Logger<>", [T], ($self) => class Logger$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343640)
            /*ILogger*/ _logger = null;
            //--TRIMMABLE-BOUNDARY-END(4296343640)
            
            //--TRIMMABLE-BOUNDARY-START(8591310936)
            $ctor$1(/*ILoggerFactory*/ factory)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591310936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(factory, "factory");
                    this._logger = factory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger($.$mexla.Microsoft.Extensions.Logging.Logger$$(T).GetCategoryName());
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310936)
            
            //--TRIMMABLE-BOUNDARY-START(21476212824)
            /*IDisposable? */ Microsoft$Extensions$Logging$ILogger$BeginScope(TState, /*TState*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._logger.Microsoft$Extensions$Logging$ILogger$BeginScope(TState, state);
            }
            //--TRIMMABLE-BOUNDARY-END(21476212824)
            
            //--TRIMMABLE-BOUNDARY-START(25771180120)
            /*bool */ Microsoft$Extensions$Logging$ILogger$IsEnabled(/*LogLevel*/ logLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel);
            }
            //--TRIMMABLE-BOUNDARY-END(25771180120)
            
            //--TRIMMABLE-BOUNDARY-START(30066147416)
            /*void */ Microsoft$Extensions$Logging$ILogger$Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._logger.Microsoft$Extensions$Logging$ILogger$Log(TState, logLevel, eventId, state, exception, formatter);
            }
            //--TRIMMABLE-BOUNDARY-END(30066147416)
            
            //--TRIMMABLE-BOUNDARY-START(17181245528)
            static /*string */ GetCategoryName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181245528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$mexla.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(T.$type, true, false, false, /*.*/ 46);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181245528)
            
            //--TRIMMABLE-BOUNDARY-START(12886278232)
            /*string */ DebuggerToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.DebuggerToString($.$mexla.Microsoft.Extensions.Logging.Logger$$(T).GetCategoryName(), this);
            }
            //--TRIMMABLE-BOUNDARY-END(12886278232)
            
            static $h = 1376344;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245528),
    {
      "r": 1310721,
      "n": "GetCategoryName",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181245528),
//--TRIMMABLE-BOUNDARY-START(12886278232),
    {
      "r": 1310721,
      "n": "DebuggerToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886278232)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343640),
    {
      "t": 917592,
      "n": "_logger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306,
      "a": [
        {
          "t": 70189057,
          "c": 8660123649,
          "a": [
            {
              "v": 3,
              "t": 70254593
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296343640)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310936),
    {
      "p": [
        {
          "n": "factory",
          "p": 1048664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310936)
  ],
  "i": [$.$mexla.Microsoft.Extensions.Logging.ILogger$$(T).$h,917592
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{DebuggerToString(),nq}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILogger$$(T), $.$mexla.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Logger<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1376344)
        
        
        //--TRIMMABLE-BOUNDARY-START(589912)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider", ($self) => class NullLoggerProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360328280)
            /*NullLoggerProvider*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(34360328280)
            
            //--TRIMMABLE-BOUNDARY-START(12885491800)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491800)
            
            //--TRIMMABLE-BOUNDARY-START(17180459096)
            /*ILogger */ CreateLogger(/*string*/ categoryName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459096)
            
            //--TRIMMABLE-BOUNDARY-START(21475426392)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475426392)
            
            //--TRIMMABLE-BOUNDARY-START(4296081496)
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerProvider.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CreateLogger(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081496)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(8590524504)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mexla.Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590524504)
            
            static $h = 589912;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360328280),
    {
      "p": 589912,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065360984,
        "f": 50331681
      },
      "n": "Instance",
      "d": 589912,
      "h": 34360328280,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360328280)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459096),
    {
      "r": 917592,
      "p": [
        {
          "n": "categoryName",
          "p": 1310721
        }
      ],
      "n": "CreateLogger",
      "d": 589912,
      "h": 17180459096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459096),
//--TRIMMABLE-BOUNDARY-START(21475426392),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 589912,
      "h": 21475426392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426392)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491800),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589912,
      "h": 12885491800,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12885491800)
  ],
  "i": [1114200,90308609
  ],
  "h": 589912
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mexla.Microsoft.Extensions.Logging.ILoggerProvider, $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589912)
        
        
        //--TRIMMABLE-BOUNDARY-START(327768)
        $asm.$str("$mexla.Microsoft.Extensions.Logging.Abstractions.LogEntry<>", (TState) => $asm.$gt("$mexla.Microsoft.Extensions.Logging.Abstractions.LogEntry<>", [TState], ($self) => class LogEntry$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360066136)
            $ctor$3(/*LogLevel*/ logLevel, /*string*/ category, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.LogLevel = logLevel;
                    this.Category = category;
                    this.EventId = eventId;
                    this.State = state;
                    this.Exception = exception;
                    this.Formatter = formatter;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360066136)
            
            //--TRIMMABLE-BOUNDARY-START(107374510168)
            /*LogLevel*/ LogLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(107374510168)
            
            //--TRIMMABLE-BOUNDARY-START(38655033432)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(38655033432)
            
            //--TRIMMABLE-BOUNDARY-START(42950000728)
            /*EventId*/ EventId;
            //--TRIMMABLE-BOUNDARY-END(42950000728)
            
            //--TRIMMABLE-BOUNDARY-START(111669477464)
            /*TState*/ State = $.$default(TState);
            //--TRIMMABLE-BOUNDARY-END(111669477464)
            
            //--TRIMMABLE-BOUNDARY-START(47244968024)
            /*Exception?*/ Exception = null;
            //--TRIMMABLE-BOUNDARY-END(47244968024)
            
            //--TRIMMABLE-BOUNDARY-START(51539935320)
            /*Func<TState, Exception?, string>*/ Formatter = null;
            //--TRIMMABLE-BOUNDARY-END(51539935320)
            
            //--TRIMMABLE-BOUNDARY-START(30065098840)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098840)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.LogLevel = this.LogLevel;
                copy.Category = this.Category;
                copy.EventId = this.EventId.Clone();
                copy.State = this.State;
                copy.Exception = this.Exception;
                copy.Formatter = this.Formatter;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.EventId = $.$default($.$mexla.Microsoft.Extensions.Logging.EventId);
            }
            static $h = 327768;
            static $g = 1;
            static $z = 28;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374510168),
    {
      "p": 2293848,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "LogLevel",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374510168),
//--TRIMMABLE-BOUNDARY-START(38655033432),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331649
      },
      "n": "Category",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655033432),
//--TRIMMABLE-BOUNDARY-START(42950000728),
    {
      "p": 720984,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331649
      },
      "n": "EventId",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950000728),
//--TRIMMABLE-BOUNDARY-START(111669477464),
    {
      "p": TState?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "State",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669477464),
//--TRIMMABLE-BOUNDARY-START(47244968024),
    {
      "p": 80019457,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1200000000n),
        "f": 50331649
      },
      "n": "Exception",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244968024),
//--TRIMMABLE-BOUNDARY-START(51539935320),
    {
      "p": $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "Formatter",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539935320)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360066136),
    {
      "p": [
        {
          "n": "logLevel",
          "p": 2293848
        },
        {
          "n": "category",
          "p": 1310721
        },
        {
          "n": "eventId",
          "p": 720984
        },
        {
          "n": "state",
          "p": TState?.$h??1507328
        },
        {
          "n": "exception",
          "p": 80019457
        },
        {
          "n": "formatter",
          "p": $.$$.System.Func$$$$(TState, $.$$.System.Exception, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360066136),
//--TRIMMABLE-BOUNDARY-START(30065098840),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065098840)
  ],
  "g": [TState?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.LogEntry<${TState?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327768)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228312)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.LoggerMessageAttribute", ($self) => class LoggerMessageAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(25772032088)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772032088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772032088)
            
            //--TRIMMABLE-BOUNDARY-START(30066999384)
            $ctor$3(/*int*/ eventId, /*LogLevel*/ level, /*string*/ message)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066999384);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.EventId = eventId;
                    this.Level = level;
                    this.Message = message;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066999384)
            
            //--TRIMMABLE-BOUNDARY-START(38656933976)
            $ctor$5(/*LogLevel*/ level, /*string*/ message)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656933976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Level = level;
                    this.Message = message;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656933976)
            
            //--TRIMMABLE-BOUNDARY-START(42951901272)
            $ctor$6(/*LogLevel*/ level)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951901272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Level = level;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951901272)
            
            //--TRIMMABLE-BOUNDARY-START(34361966680)
            $ctor$4(/*string*/ message)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361966680);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Message = message;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361966680)
            
            //--TRIMMABLE-BOUNDARY-START(47246868568)
            /*int*/ EventId = 0;
            //--TRIMMABLE-BOUNDARY-END(47246868568)
            
            //--TRIMMABLE-BOUNDARY-START(51541835864)
            /*string?*/ EventName = null;
            //--TRIMMABLE-BOUNDARY-END(51541835864)
            
            //--TRIMMABLE-BOUNDARY-START(98786476120)
            /*LogLevel*/ Level = 0;
            //--TRIMMABLE-BOUNDARY-END(98786476120)
            
            //--TRIMMABLE-BOUNDARY-START(103081443416)
            /*string*/ Message = null;
            //--TRIMMABLE-BOUNDARY-END(103081443416)
            
            //--TRIMMABLE-BOUNDARY-START(150326083672)
            /*bool*/ SkipEnabledCheck = false;
            //--TRIMMABLE-BOUNDARY-END(150326083672)
            
            //default member initializer
            constructor()
            {
                super();
                this.EventId = -1;
                this.Level = 6;
                this.Message = "";
            }
            static $h = 2228312;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246868568),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131770456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111671378008,
        "f": 83886081
      },
      "n": "EventId",
      "d": 2228312,
      "h": 47246868568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246868568),
//--TRIMMABLE-BOUNDARY-START(51541835864),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721705048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120261312600,
        "f": 83886081
      },
      "n": "EventName",
      "d": 2228312,
      "h": 51541835864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541835864),
//--TRIMMABLE-BOUNDARY-START(98786476120),
    {
      "p": 2293848,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311639640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128851247192,
        "f": 83886081
      },
      "n": "Level",
      "d": 2228312,
      "h": 98786476120,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98786476120),
//--TRIMMABLE-BOUNDARY-START(103081443416),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901574232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137441181784,
        "f": 83886081
      },
      "n": "Message",
      "d": 2228312,
      "h": 103081443416,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103081443416),
//--TRIMMABLE-BOUNDARY-START(150326083672),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491508824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146031116376,
        "f": 83886081
      },
      "n": "SkipEnabledCheck",
      "d": 2228312,
      "h": 150326083672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150326083672)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772032088),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2228312,
      "h": 25772032088,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772032088),
//--TRIMMABLE-BOUNDARY-START(30066999384),
    {
      "p": [
        {
          "n": "eventId",
          "p": 655361
        },
        {
          "n": "level",
          "p": 2293848
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2228312,
      "h": 30066999384,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066999384),
//--TRIMMABLE-BOUNDARY-START(38656933976),
    {
      "p": [
        {
          "n": "level",
          "p": 2293848
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 2228312,
      "h": 38656933976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656933976),
//--TRIMMABLE-BOUNDARY-START(42951901272),
    {
      "p": [
        {
          "n": "level",
          "p": 2293848
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2228312,
      "h": 42951901272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951901272),
//--TRIMMABLE-BOUNDARY-START(34361966680),
    {
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2228312,
      "h": 34361966680,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361966680)
  ],
  "h": 2228312,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 64,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessageAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228312)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555992)
        $asm.$cls("$mexla.Microsoft.Extensions.Logging.ProviderAliasAttribute", ($self) => class ProviderAliasAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592490584)
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592490584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Alias = alias;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592490584)
            
            //--TRIMMABLE-BOUNDARY-START(12887457880)
            /*string*/ Alias = null;
            //--TRIMMABLE-BOUNDARY-END(12887457880)
            
            static $h = 2555992;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887457880),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477392472,
        "f": 50331649
      },
      "n": "Alias",
      "d": 2555992,
      "h": 12887457880,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887457880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592490584),
    {
      "p": [
        {
          "n": "alias",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2555992,
      "h": 8592490584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592490584)
  ],
  "h": 2555992,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ProviderAliasAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555992)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687064)
        $asm.$str("$mexla.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4297654360)
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4297654360)
            
            //--TRIMMABLE-BOUNDARY-START(8592621656)
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            //--TRIMMABLE-BOUNDARY-END(8592621656)
            
            //--TRIMMABLE-BOUNDARY-START(12887588952)
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12887588952)
            
            //--TRIMMABLE-BOUNDARY-START(25772490840)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772490840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772490840)
            
            //--TRIMMABLE-BOUNDARY-START(21477523544)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477523544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477523544)
            
            //--TRIMMABLE-BOUNDARY-START(146031575128)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376869464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916477016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146031575128)
            
            //--TRIMMABLE-BOUNDARY-START(73017131096)
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(73017131096)
            
            //--TRIMMABLE-BOUNDARY-START(81607065688)
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81607065688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81607065688)
            
            //--TRIMMABLE-BOUNDARY-START(120261771352)
            /*ref char */ GetPinnableReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261771352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(120261771352)
            
            //--TRIMMABLE-BOUNDARY-START(124556738648)
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556738648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(124556738648)
            
            //--TRIMMABLE-BOUNDARY-START(163211444312)
            /*ref char*/ get_Item$1(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(163211444312)
            
            //--TRIMMABLE-BOUNDARY-START(167506411608)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506411608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mexla.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(167506411608)
            
            //--TRIMMABLE-BOUNDARY-START(150326542424)
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            //--TRIMMABLE-BOUNDARY-END(150326542424)
            
            //--TRIMMABLE-BOUNDARY-START(60132229208)
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132229208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(60132229208)
            
            //--TRIMMABLE-BOUNDARY-START(55837261912)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55837261912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55837261912)
            
            //--TRIMMABLE-BOUNDARY-START(68722163800)
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68722163800);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68722163800)
            
            //--TRIMMABLE-BOUNDARY-START(64427196504)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64427196504);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64427196504)
            
            //--TRIMMABLE-BOUNDARY-START(171801378904)
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801378904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171801378904)
            
            //--TRIMMABLE-BOUNDARY-START(137441640536)
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441640536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(137441640536)
            
            //--TRIMMABLE-BOUNDARY-START(141736607832)
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736607832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(141736607832)
            
            //--TRIMMABLE-BOUNDARY-START(34362425432)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362425432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34362425432)
            
            //--TRIMMABLE-BOUNDARY-START(42952360024)
            /*void */ Append$3(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952360024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952360024)
            
            //--TRIMMABLE-BOUNDARY-START(47247327320)
            /*void */ AppendSlow(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247327320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            //--TRIMMABLE-BOUNDARY-END(47247327320)
            
            //--TRIMMABLE-BOUNDARY-START(30067458136)
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067458136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(30067458136)
            
            //--TRIMMABLE-BOUNDARY-START(38657392728)
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657392728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38657392728)
            
            //--TRIMMABLE-BOUNDARY-START(51542294616)
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542294616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(51542294616)
            
            //--TRIMMABLE-BOUNDARY-START(133146673240)
            /*void */ GrowAndAppend(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146673240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Grow(1);
                this.Append$1(c);
            }
            //--TRIMMABLE-BOUNDARY-END(133146673240)
            
            //--TRIMMABLE-BOUNDARY-START(128851705944)
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851705944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128851705944)
            
            //--TRIMMABLE-BOUNDARY-START(77312098392)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312098392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$mexla.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77312098392)
            
            //--TRIMMABLE-BOUNDARY-START(17182556248)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182556248)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4297654360)
                this._arrayToReturnToPool = null;
                //--TRIMMABLE-BOUNDARY-END(4297654360)
                
                //--TRIMMABLE-BOUNDARY-START(8592621656)
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(8592621656)
                
                //--TRIMMABLE-BOUNDARY-START(12887588952)
                this._pos = 0;
                //--TRIMMABLE-BOUNDARY-END(12887588952)
                
            }
            static $h = 2687064;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(146031575128),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376869464,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158916477016,
        "f": 83886081
      },
      "n": "Length",
      "d": 2687064,
      "h": 146031575128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146031575128),
//--TRIMMABLE-BOUNDARY-START(73017131096),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90197000280,
        "f": 50331649
      },
      "n": "Capacity",
      "d": 2687064,
      "h": 73017131096,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017131096),
//--TRIMMABLE-BOUNDARY-START(163211444312),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786934872,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 2687064,
      "h": 163211444312,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163211444312),
//--TRIMMABLE-BOUNDARY-START(150326542424),
    {
      "p": $.$$.System.Span$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966804056,
        "f": 50331649
      },
      "n": "RawChars",
      "d": 2687064,
      "h": 150326542424,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150326542424)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(81607065688),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 2687064,
      "h": 81607065688,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81607065688),
//--TRIMMABLE-BOUNDARY-START(120261771352),
    {
      "r": 458753,
      "n": "GetPinnableReference",
      "d": 2687064,
      "h": 120261771352,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(120261771352),
//--TRIMMABLE-BOUNDARY-START(124556738648),
    {
      "r": 458753,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "GetPinnableReference",
      "o": "@$1",
      "d": 2687064,
      "h": 124556738648,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124556738648),
//--TRIMMABLE-BOUNDARY-START(167506411608),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 2687064,
      "h": 167506411608,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167506411608),
//--TRIMMABLE-BOUNDARY-START(60132229208),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 2687064,
      "h": 60132229208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60132229208),
//--TRIMMABLE-BOUNDARY-START(55837261912),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "n": "AsSpan",
      "d": 2687064,
      "h": 55837261912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55837261912),
//--TRIMMABLE-BOUNDARY-START(68722163800),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$3",
      "d": 2687064,
      "h": 68722163800,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68722163800),
//--TRIMMABLE-BOUNDARY-START(64427196504),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 2687064,
      "h": 64427196504,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64427196504),
//--TRIMMABLE-BOUNDARY-START(171801378904),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": 2687064,
      "h": 171801378904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171801378904),
//--TRIMMABLE-BOUNDARY-START(137441640536),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Insert",
      "d": 2687064,
      "h": 137441640536,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137441640536),
//--TRIMMABLE-BOUNDARY-START(141736607832),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "o": "@$1",
      "d": 2687064,
      "h": 141736607832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141736607832),
//--TRIMMABLE-BOUNDARY-START(34362425432),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 2687064,
      "h": 34362425432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34362425432),
//--TRIMMABLE-BOUNDARY-START(42952360024),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 2687064,
      "h": 42952360024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952360024),
//--TRIMMABLE-BOUNDARY-START(47247327320),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AppendSlow",
      "d": 2687064,
      "h": 47247327320,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47247327320),
//--TRIMMABLE-BOUNDARY-START(30067458136),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "d": 2687064,
      "h": 30067458136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30067458136),
//--TRIMMABLE-BOUNDARY-START(38657392728),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 2687064,
      "h": 38657392728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657392728),
//--TRIMMABLE-BOUNDARY-START(51542294616),
    {
      "r": $.$$.System.Span$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": 2687064,
      "h": 51542294616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51542294616),
//--TRIMMABLE-BOUNDARY-START(133146673240),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "GrowAndAppend",
      "d": 2687064,
      "h": 133146673240,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146673240),
//--TRIMMABLE-BOUNDARY-START(128851705944),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityBeyondPos",
          "p": 655361
        }
      ],
      "n": "Grow",
      "d": 2687064,
      "h": 128851705944,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128851705944),
//--TRIMMABLE-BOUNDARY-START(77312098392),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2687064,
      "h": 77312098392,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77312098392)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297654360),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_arrayToReturnToPool",
      "d": 2687064,
      "h": 4297654360,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297654360),
//--TRIMMABLE-BOUNDARY-START(8592621656),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_chars",
      "d": 2687064,
      "h": 8592621656,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592621656),
//--TRIMMABLE-BOUNDARY-START(12887588952),
    {
      "t": 655361,
      "n": "_pos",
      "d": 2687064,
      "h": 12887588952,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12887588952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25772490840),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2687064,
      "h": 25772490840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772490840),
//--TRIMMABLE-BOUNDARY-START(21477523544),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2687064,
      "h": 21477523544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477523544),
//--TRIMMABLE-BOUNDARY-START(17182556248),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687064,
      "h": 17182556248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182556248)
  ],
  "h": 2687064
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687064)
        
        
        //--TRIMMABLE-BOUNDARY-START(720984)
        $asm.$str("$mexla.Microsoft.Extensions.Logging.EventId", ($self) => class EventId extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885622872)
            static /*EventId */ op_Implicit(/*int*/ i)
            {
                return new $.$mexla.Microsoft.Extensions.Logging.EventId().$ctor$3(i, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12885622872)
            
            //--TRIMMABLE-BOUNDARY-START(64425230424)
            static /*bool */ op_Equality(/*EventId*/ left, /*EventId*/ right)
            {
                return left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(64425230424)
            
            //--TRIMMABLE-BOUNDARY-START(68720197720)
            static /*bool */ op_Inequality(/*EventId*/ left, /*EventId*/ right)
            {
                return !left.Equals$2(right);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197720)
            
            //--TRIMMABLE-BOUNDARY-START(21475557464)
            $ctor$3(/*int*/ id, /*string?*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Id = id;
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557464)
            
            //--TRIMMABLE-BOUNDARY-START(55835295832)
            /*int*/ Id = 0;
            //--TRIMMABLE-BOUNDARY-END(55835295832)
            
            //--TRIMMABLE-BOUNDARY-START(60130263128)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(60130263128)
            
            //--TRIMMABLE-BOUNDARY-START(73015165016)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Name ?? $.$$.System.Int32.ToString.call(this.Id);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.EventId.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(73015165016)
            
            //--TRIMMABLE-BOUNDARY-START(30065492056)
            /*bool */ Equals$2(/*EventId*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id === other.Id;
            }
            //--TRIMMABLE-BOUNDARY-END(30065492056)
            
            //--TRIMMABLE-BOUNDARY-START(25770524760)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return false;
                }
                let eventId;
                return $.$is(obj, $.$mexla.Microsoft.Extensions.Logging.EventId, { set $v(v){ eventId = v; } }) && this.Equals$2(eventId);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$mexla.Microsoft.Extensions.Logging.EventId.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25770524760)
            
            //--TRIMMABLE-BOUNDARY-START(51540328536)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Id;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mexla.Microsoft.Extensions.Logging.EventId.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(51540328536)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Logging.EventId>.Equals(Microsoft.Extensions.Logging.EventId)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(17180590168)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590168)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Id = this.Id;
                copy.Name = this.Name;
                return copy;
            }
            static $h = 720984;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835295832),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426648,
        "f": 50331649
      },
      "n": "Id",
      "d": 720984,
      "h": 55835295832,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835295832),
//--TRIMMABLE-BOUNDARY-START(60130263128),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361240,
        "f": 50331649
      },
      "n": "Name",
      "d": 720984,
      "h": 60130263128,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130263128)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015165016),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 720984,
      "h": 73015165016,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015165016),
//--TRIMMABLE-BOUNDARY-START(30065492056),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 720984
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 720984,
      "h": 30065492056,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065492056),
//--TRIMMABLE-BOUNDARY-START(25770524760),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 720984,
      "h": 25770524760,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770524760),
//--TRIMMABLE-BOUNDARY-START(51540328536),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 720984,
      "h": 51540328536,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540328536)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557464),
    {
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720984,
      "h": 21475557464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557464),
//--TRIMMABLE-BOUNDARY-START(17180590168),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720984,
      "h": 17180590168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590168)
  ],
  "i": [$.$$.System.IEquatable$$($.$mexla.Microsoft.Extensions.Logging.EventId).$h
  ],
  "h": 720984
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$mexla.Microsoft.Extensions.Logging.EventId) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.EventId`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720984)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293848)
        $asm.$str("$mexla.Microsoft.Extensions.Logging.LogLevel", ($self) => class LogLevel extends $.$$.System.Enum
        {
            static Trace = 0;
            static Debug = 1;
            static Information = 2;
            static Warning = 3;
            static Error = 4;
            static Critical = 5;
            static None = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Trace": 0n,
                    "Debug": 1n,
                    "Information": 2n,
                    "Warning": 3n,
                    "Error": 4n,
                    "Critical": 5n,
                    "None": 6n
                };
            }
            static $h = 2293848;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067064920),
    {
      "t": 2293848,
      "n": "Trace",
      "d": 2293848,
      "h": 30067064920,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067064920),
//--TRIMMABLE-BOUNDARY-START(12887195736),
    {
      "t": 2293848,
      "n": "Debug",
      "d": 2293848,
      "h": 12887195736,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887195736),
//--TRIMMABLE-BOUNDARY-START(21477130328),
    {
      "t": 2293848,
      "n": "Information",
      "d": 2293848,
      "h": 21477130328,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21477130328),
//--TRIMMABLE-BOUNDARY-START(34362032216),
    {
      "t": 2293848,
      "n": "Warning",
      "d": 2293848,
      "h": 34362032216,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362032216),
//--TRIMMABLE-BOUNDARY-START(17182163032),
    {
      "t": 2293848,
      "n": "Error",
      "d": 2293848,
      "h": 17182163032,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182163032),
//--TRIMMABLE-BOUNDARY-START(8592228440),
    {
      "t": 2293848,
      "n": "Critical",
      "d": 2293848,
      "h": 8592228440,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592228440),
//--TRIMMABLE-BOUNDARY-START(25772097624),
    {
      "t": 2293848,
      "n": "None",
      "d": 2293848,
      "h": 25772097624,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25772097624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261144),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2293848,
      "h": 4297261144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297261144)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2293848
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293848)
        
        
        //--TRIMMABLE-BOUNDARY-START(786520)
        $asm.$str("$mexla.Microsoft.Extensions.Logging.FormattedLogValues", ($self) => class FormattedLogValues extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(73015230552)
            /*int*/ static MaxCachedFormatters = 1024;
            //--TRIMMABLE-BOUNDARY-END(73015230552)
            
            //--TRIMMABLE-BOUNDARY-START(77310197848)
            /*string*/ static NullFormat = null;
            //--TRIMMABLE-BOUNDARY-END(77310197848)
            
            //--TRIMMABLE-BOUNDARY-START(81605165144)
            /*int*/ static s_count = 0;
            //--TRIMMABLE-BOUNDARY-END(81605165144)
            
            //--TRIMMABLE-BOUNDARY-START(85900132440)
            /*ConcurrentDictionary<string, LogValuesFormatter>*/ static s_formatters = null;
            //--TRIMMABLE-BOUNDARY-END(85900132440)
            
            //--TRIMMABLE-BOUNDARY-START(8590721112)
            /*LogValuesFormatter?*/  get _formatter() { return this.$getField(0, 4); }
            /*LogValuesFormatter?*/  set _formatter(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590721112)
            
            //--TRIMMABLE-BOUNDARY-START(17180655704)
            /*object?[]?*/  get _values() { return this.$getField(4, 4); }
            /*object?[]?*/  set _values(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17180655704)
            
            //--TRIMMABLE-BOUNDARY-START(12885688408)
            /*string*/  get _originalMessage() { return this.$getField(8, 4); }
            /*string*/  set _originalMessage(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885688408)
            
            //--TRIMMABLE-BOUNDARY-START(4295753816)
            /*string?*/  get _cachedToString() { return this.$getField(12, 4); }
            /*string?*/  set _cachedToString(value) { this.$setField(12, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295753816)
            
            //--TRIMMABLE-BOUNDARY-START(38655492184)
            /*LogValuesFormatter? */ get Formatter()
            {
                return this._formatter;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492184)
            
            //--TRIMMABLE-BOUNDARY-START(30065557592)
            $ctor$3(/*string?*/ format, /*params object?[]?*/ values)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (values !== null && values.length !== 0 && $.$$.System.String.op_Inequality(format, null))
                    {
                        if ($.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.s_count >= 1024/*MaxCachedFormatters*/)
                        {
                            if (!$.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.s_formatters.TryGetValue(format, $.$ref(() => this._formatter, ($v) => this._formatter = $v, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter)))
                            {
                                this._formatter = new $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(format);
                            }
                        }
                        else 
                        {
                            this._formatter = $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.s_formatters.GetOrAdd(format, new ($.$$.System.Func$$$($.$$.System.String, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter))().$ctor(this,  (/*f*/ f) =>
                            {
                                $.$$.System.Threading.Interlocked.Increment($.$ref(() => $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.s_count, ($v) => $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.s_count = $v, $.$$.System.Int32));
                                return new $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(f);
                            }, {
  "r": 2359384,
  "p": [
    {
      "n": "f",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 786520,
  "h": 0,
  "f": 17825794
}));
                        }
                    }
                    else 
                    {
                        this._formatter = null;
                    }
                    this._originalMessage = format ?? "[null]"/*NullFormat*/;
                    this._values = values;
                    this._cachedToString = null;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065557592)
            
            //--TRIMMABLE-BOUNDARY-START(94490067032)
            /*KeyValuePair<string, object?>*/ get_Item$1(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.IndexOutOfRangeException().$ctor$12("index");
                }
                if (index === ((this.Count - 1) | 0))
                {
                    return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object))().$ctor$3("{OriginalFormat}", this._originalMessage);
                }
                return this._formatter.GetValue(this._values, index);
            }
            //--TRIMMABLE-BOUNDARY-END(94490067032)
            
            //--TRIMMABLE-BOUNDARY-START(34360524888)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245426776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._formatter === null)
                {
                    return 1;
                }
                return ((this._formatter.ValueNames.Count + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34360524888)
            
            //--TRIMMABLE-BOUNDARY-START(68720263256)
            /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this.Count; ++i)
                    {
                        yield this.get_Item$1(i);
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(68720263256)
            
            //--TRIMMABLE-BOUNDARY-START(98785034328)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785034328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._formatter === null)
                {
                    return this._originalMessage;
                }
                return this._cachedToString ??= this._formatter.Format$1(this._values);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mexla.Microsoft.Extensions.Logging.FormattedLogValues.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(98785034328)
            
            //--TRIMMABLE-BOUNDARY-START(90195099736)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195099736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(90195099736)
            
            //--TRIMMABLE-BOUNDARY-START(8650096641)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
            System$Collections$Generic$IReadOnlyList$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650096641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650096641)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            //--TRIMMABLE-BOUNDARY-START(25770590296)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590296)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._formatter = this._formatter;
                copy._values = this._values;
                copy._originalMessage = this._originalMessage;
                copy._cachedToString = this._cachedToString;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590721112)
                this._formatter = null;
                //--TRIMMABLE-BOUNDARY-END(8590721112)
                
                //--TRIMMABLE-BOUNDARY-START(17180655704)
                this._values = null;
                //--TRIMMABLE-BOUNDARY-END(17180655704)
                
                //--TRIMMABLE-BOUNDARY-START(12885688408)
                this._originalMessage = null;
                //--TRIMMABLE-BOUNDARY-END(12885688408)
                
                //--TRIMMABLE-BOUNDARY-START(4295753816)
                this._cachedToString = null;
                //--TRIMMABLE-BOUNDARY-END(4295753816)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21475623000)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77310197848)
                    this.NullFormat = "[null]";
                    //--TRIMMABLE-BOUNDARY-END(77310197848)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900132440)
                    this.s_formatters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(85900132440)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475623000)
            
            static $h = 786520;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655492184),
    {
      "p": 2359384,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361368,
        "f": 50331656
      },
      "n": "Formatter",
      "d": 786520,
      "h": 38655492184,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(38655492184),
//--TRIMMABLE-BOUNDARY-START(94490067032),
    {
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425295960,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 786520,
      "h": 94490067032,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490067032),
//--TRIMMABLE-BOUNDARY-START(34360524888),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426776,
        "f": 50331649
      },
      "n": "Count",
      "d": 786520,
      "h": 34360524888,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360524888)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68720263256),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,
      "n": "GetEnumerator",
      "d": 786520,
      "h": 68720263256,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720263256),
//--TRIMMABLE-BOUNDARY-START(98785034328),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 786520,
      "h": 98785034328,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785034328)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(73015230552),
    {
      "t": 655361,
      "n": "MaxCachedFormatters",
      "d": 786520,
      "h": 73015230552,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015230552),
//--TRIMMABLE-BOUNDARY-START(77310197848),
    {
      "t": 1310721,
      "n": "NullFormat",
      "d": 786520,
      "h": 77310197848,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77310197848),
//--TRIMMABLE-BOUNDARY-START(81605165144),
    {
      "t": 655361,
      "n": "s_count",
      "d": 786520,
      "h": 81605165144,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(81605165144),
//--TRIMMABLE-BOUNDARY-START(85900132440),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.String, $.$mexla.Microsoft.Extensions.Logging.LogValuesFormatter).$h,
      "n": "s_formatters",
      "d": 786520,
      "h": 85900132440,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(85900132440),
//--TRIMMABLE-BOUNDARY-START(8590721112),
    {
      "t": 2359384,
      "n": "_formatter",
      "d": 786520,
      "h": 8590721112,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721112),
//--TRIMMABLE-BOUNDARY-START(17180655704),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_values",
      "d": 786520,
      "h": 17180655704,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180655704),
//--TRIMMABLE-BOUNDARY-START(12885688408),
    {
      "t": 1310721,
      "n": "_originalMessage",
      "d": 786520,
      "h": 12885688408,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885688408),
//--TRIMMABLE-BOUNDARY-START(4295753816),
    {
      "t": 1310721,
      "n": "_cachedToString",
      "d": 786520,
      "h": 4295753816,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753816)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065557592),
    {
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786520,
      "h": 30065557592,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557592),
//--TRIMMABLE-BOUNDARY-START(25770590296),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786520,
      "h": 25770590296,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770590296)
  ],
  "i": [$.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417
  ],
  "h": 786520
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.FormattedLogValues`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786520)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.ComponentModel", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.ObjectModel", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource"))
//--TRIMMABLE-BOUNDARY-END(88)
