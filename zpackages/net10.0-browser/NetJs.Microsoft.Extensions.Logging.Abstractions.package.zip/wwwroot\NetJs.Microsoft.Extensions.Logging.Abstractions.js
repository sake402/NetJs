
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $stee, $st, $stt, $sttp, $sr, $scc, $scm, $so, $sris, $sic, $sim, $sl, $sci, $sdd, $srm, $sre, $sle, $mxdi) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.Microsoft.Extensions.Logging.Abstractions", 
    {"h":21,"f":"Microsoft.Extensions.Logging.Abstractions","v":"1.0.35.0","a":[{"t":92405761,"c":4387373057,"a":[{"v":"Microsoft.Extensions.Logging.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100f33a29044fa9d740c9b3213a93e57c84b472c84e0b8a0e1ae48e67a9f8f6de9d5f7f3d52ac23e48ac51801f1dc950abe901da34d2a9e3baadb141a17c77ef3c565dd5ee5054b91cf63bb3c6ab83f72ab3aafe93d0fc3c2348b764fafb0b1c0733de51459aeab46580384bf9d74c4e28164b7cde247f891ba07891c9d872ad2bb","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.Microsoft.Extensions.Logging.Abstractions","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.Microsoft.Extensions.Logging.Abstractions","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.IBufferedLogger", ($self) => class IBufferedLogger
        {
            static $h = 262165;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"records","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$mela.Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord).$h}],"n":"LogRecords","o":"Microsoft$Extensions$Logging$Abstractions$IBufferedLogger$LogRecords","d":262165,"h":4295229461,"f":257}],"h":262165}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.IBufferedLogger`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.IExternalScopeProvider", ($self) => class IExternalScopeProvider
        {
            static $h = 851989;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"callback","p":(TState) => $.$spc.System.Action$$$($.$spc.System.Object, TState).$h},{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"ForEachScope","o":"Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope","d":851989,"h":4295819285,"f":131329},{"r":57475073,"p":[{"n":"state","p":131073}],"n":"Push","o":"Microsoft$Extensions$Logging$IExternalScopeProvider$Push","d":851989,"h":8590786581,"f":257}],"h":851989}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.IExternalScopeProvider`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ILogger", ($self) => class ILogger
        {
            static $h = 917525;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"state","p":(TState) => TState.$h},{"n":"exception","p":47185921},{"n":"formatter","p":(TState) => $.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"g":["TState"],"n":"Log","o":"Microsoft$Extensions$Logging$ILogger$Log","d":917525,"h":4295884821,"f":131329},{"r":262145,"p":[{"n":"logLevel","p":2293781}],"n":"IsEnabled","o":"Microsoft$Extensions$Logging$ILogger$IsEnabled","d":917525,"h":8590852117,"f":257},{"r":57475073,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"BeginScope","o":"Microsoft$Extensions$Logging$ILogger$BeginScope","d":917525,"h":12885819413,"f":131329}],"h":917525}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILogger`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ILoggingBuilder", ($self) => class ILoggingBuilder
        {
            static $h = 1179669;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":786435,"g":{"r":0,"d":0,"h":8591114261,"f":257},"n":"Services","o":"Microsoft$Extensions$Logging$ILoggingBuilder$Services","d":1179669,"h":4296146965,"f":257}],"h":1179669}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggingBuilder`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ISupportExternalScope", ($self) => class ISupportExternalScope
        {
            static $h = 1245205;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"scopeProvider","p":851989}],"n":"SetScopeProvider","o":"Microsoft$Extensions$Logging$ISupportExternalScope$SetScopeProvider","d":1245205,"h":4296212501,"f":257}],"h":1245205}; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ISupportExternalScope`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ILogger<>", (/*out*/ TCategoryName) => $asm.$gt("$mela.Microsoft.Extensions.Logging.ILogger<>", [/*out*/ TCategoryName], ($self) => class ILogger$$
        {
            static $h = 983061;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"i":[917525],"g":[TCategoryName?.$h??1507328],"s":[{"n":"TCategoryName","f":32}],"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILogger<${TCategoryName?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ILoggerProvider", ($self) => class ILoggerProvider
        {
            static $h = 1114133;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":917525,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLogger","o":"Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger","d":1114133,"h":4296081429,"f":257}],"i":[57475073],"h":1114133}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggerProvider`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ILoggerFactory", ($self) => class ILoggerFactory
        {
            static $h = 1048597;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":917525,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLogger","o":"Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger","d":1048597,"h":4296015893,"f":257},{"r":65537,"p":[{"n":"provider","p":1114133}],"n":"AddProvider","o":"Microsoft$Extensions$Logging$ILoggerFactory$AddProvider","d":1048597,"h":8590983189,"f":257}],"i":[57475073],"h":1048597}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ILoggerFactory`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord", ($self) => class BufferedLogRecord extends $.$spc.System.Object
        {
            /*string? */ get Exception()
            {
                return null;
            }
            /*ActivitySpanId? */ get ActivitySpanId()
            {
                return null;
            }
            /*ActivityTraceId? */ get ActivityTraceId()
            {
                return null;
            }
            /*int? */ get ManagedThreadId()
            {
                return null;
            }
            /*string? */ get FormattedMessage()
            {
                return null;
            }
            /*string? */ get MessageTemplate()
            {
                return null;
            }
            /*IReadOnlyList<KeyValuePair<string, object?>> */ get Attributes()
            {
                return (() =>
                {
                    let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1();
                    return $t1;
                })();
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 196629;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34340865,"g":{"r":0,"d":0,"h":8590131221,"f":257},"n":"Timestamp","d":196629,"h":4295163925,"f":257},{"p":2293781,"g":{"r":0,"d":0,"h":17180065813,"f":257},"n":"LogLevel","d":196629,"h":12885098517,"f":257},{"p":720917,"g":{"r":0,"d":0,"h":25770000405,"f":257},"n":"EventId","d":196629,"h":21475033109,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":34359934997,"f":129},"n":"Exception","d":196629,"h":30064967701,"f":129},{"p":$.$typeNullable($.$sdd.System.Diagnostics.ActivitySpanId).$h,"g":{"r":0,"d":0,"h":42949869589,"f":129},"n":"ActivitySpanId","d":196629,"h":38654902293,"f":129},{"p":$.$typeNullable($.$sdd.System.Diagnostics.ActivityTraceId).$h,"g":{"r":0,"d":0,"h":51539804181,"f":129},"n":"ActivityTraceId","d":196629,"h":47244836885,"f":129},{"p":$.$typeNullable($.$spc.System.Int32).$h,"g":{"r":0,"d":0,"h":60129738773,"f":129},"n":"ManagedThreadId","d":196629,"h":55834771477,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":68719673365,"f":129},"n":"FormattedMessage","d":196629,"h":64424706069,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":77309607957,"f":129},"n":"MessageTemplate","d":196629,"h":73014640661,"f":129},{"p":$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"g":{"r":0,"d":0,"h":85899542549,"f":129},"n":"Attributes","d":196629,"h":81604575253,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":196629,"h":90194509845,"f":4}],"h":196629}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.BufferedLogRecord`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Internal.TypeNameHelper", ($self) => class TypeNameHelper
        {
            /*char*/ static DefaultNestedTypeDelimiter = /*+*/ 43;
            /*Dictionary<Type, string>*/ static _builtInTypeNames = null;
            static /*string? */ GetTypeDisplayName(/*object?*/ item, /*bool*/ fullName)
            {
                return item === null ? null : $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1($.$spc.System.Object.GetType.call(item), fullName, false, true, /*+*/ 43);
            }
            static /*string */ GetTypeDisplayName$1(/*Type*/ type, /*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
            {
                /*StringBuilder?*/ let builder = null;
                /*string?*/ let name = $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), type, $.$ref(() => new $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions().$ctor$2(fullName, includeGenericParameterNames, includeGenericParameters, nestedTypeDelimiter), ));
                const $t2 = builder;
                return name ?? $.$ifnn($t2, ($t) => $.$spc.System.Text.StringBuilder.ToString.call($t)) ?? $.$spc.System.String.Empty;
            }
            static /*string? */ ProcessType(/*ref StringBuilder?*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*string?*/ let builtInName;
                if (type.IsGenericType)
                {
                    /*Type[]*/ let genericArguments = type.GetGenericArguments();
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder.$v, type, genericArguments, genericArguments.length, options);
                }
                else if (type.IsArray)
                {
                    builder.$v ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                    $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessArrayType(builder.$v, type, options);
                }
                else if ($.$mela.Microsoft.Extensions.Internal.TypeNameHelper._builtInTypeNames.TryGetValue(type, $.$ref(() => builtInName, ($v) => builtInName = $v, $.$spc.System.String)))
                {
                    if (builder.$v === null)
                    {
                        return builtInName;
                    }
                    builder.$v.Append$2(builtInName);
                }
                else if (type.IsGenericParameter)
                {
                    if (options.$v.IncludeGenericParameterNames)
                    {
                        if (builder.$v === null)
                        {
                            return type.Name;
                        }
                        builder.$v.Append$2(type.Name);
                    }
                }
                else 
                {
                    /*string*/ let name = options.$v.FullName ? type.FullName : type.Name;
                    if (builder.$v === null)
                    {
                        if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                        {
                            return $.$spc.System.String.Replace$2.call(name, /*+*/ 43, options.$v.NestedTypeDelimiter);
                        }
                        return name;
                    }
                    builder.$v.Append$2(name);
                    if (options.$v.NestedTypeDelimiter !== /*+*/ 43)
                    {
                        builder.$v.Replace$5(/*+*/ 43, options.$v.NestedTypeDelimiter, ((builder.$v.Length - name.length) | 0), name.length);
                    }
                }
                return null;
            }
            static /*void */ ProcessArrayType(/*StringBuilder*/ builder, /*Type*/ type, /*in DisplayNameOptions*/ options)
            {
                /*Type*/ let innerType = type;
                while(innerType.IsArray)
                {
                    innerType = innerType.GetElementType();
                }
                $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), innerType, options);
                while(type.IsArray)
                {
                    builder.Append$7(/*[*/ 91);
                    builder.Append(/*,*/ 44, ((type.GetArrayRank() - 1) | 0));
                    builder.Append$7(/*]*/ 93);
                    type = type.GetElementType();
                }
            }
            static /*void */ ProcessGenericType(/*StringBuilder*/ builder, /*Type*/ type, /*Type[]*/ genericArguments, /*int*/ length, /*in DisplayNameOptions*/ options)
            {
                /*int*/ let offset = 0;
                if (type.IsNested)
                {
                    offset = type.DeclaringType.GetGenericArguments().length;
                }
                if (options.$v.FullName)
                {
                    if (type.IsNested)
                    {
                        $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessGenericType(builder, type.DeclaringType, genericArguments, offset, options);
                        builder.Append$7(options.$v.NestedTypeDelimiter);
                    }
                    else if (!$.$spc.System.String.IsNullOrEmpty(type.Namespace))
                    {
                        builder.Append$2(type.Namespace);
                        builder.Append$7(/*.*/ 46);
                    }
                }
                /*int*/ let genericPartIndex = $.$spc.System.String.IndexOf.call(type.Name, /*`*/ 96);
                if (genericPartIndex <= 0)
                {
                    builder.Append$2(type.Name);
                    return;
                }
                builder.Append$3(type.Name, 0, genericPartIndex);
                if (options.$v.IncludeGenericParameters)
                {
                    builder.Append$7(/*<*/ 60);
                    for(/*int*/ let i = offset; i < length; i++)
                    {
                        $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.ProcessType($.$ref(() => builder, ($v) => builder = $v, $.$spc.System.Text.StringBuilder), $.$spc.System.Array.$ReadT1.call(genericArguments, i), options);
                        if (((i + 1) | 0) === length)
                        {
                            continue;
                        }
                        builder.Append$7(/*,*/ 44);
                        if (options.$v.IncludeGenericParameterNames || !$.$spc.System.Array.$ReadT1.call(genericArguments, ((i + 1) | 0)).IsGenericParameter)
                        {
                            builder.Append$7(/* */ 32);
                        }
                    }
                    builder.Append$7(/*>*/ 62);
                }
            }
            static $_DisplayNameOptions;
            static get DisplayNameOptions()
            {
                let $cls = $.$mela.Microsoft.Extensions.Internal.TypeNameHelper;
                return $cls.$_DisplayNameOptions ??= $asm.$nstr("$mela.Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions", ($self) => class DisplayNameOptions extends $.$spc.System.ValueType
                {
                    $ctor$2(/*bool*/ fullName, /*bool*/ includeGenericParameterNames, /*bool*/ includeGenericParameters, /*char*/ nestedTypeDelimiter)
                    {
                        super.$ctor$1();
                        {
                            this.FullName = fullName;
                            this.IncludeGenericParameters = includeGenericParameters;
                            this.IncludeGenericParameterNames = includeGenericParameterNames;
                            this.NestedTypeDelimiter = nestedTypeDelimiter;
                        }
                        return this;
                    }
                    /*bool*/ FullName = false;
                    /*bool*/ IncludeGenericParameters = false;
                    /*bool*/ IncludeGenericParameterNames = false;
                    /*char*/ NestedTypeDelimiter = 0;
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.FullName = this.FullName;
                        copy.IncludeGenericParameters = this.IncludeGenericParameters;
                        copy.IncludeGenericParameterNames = this.IncludeGenericParameterNames;
                        copy.NestedTypeDelimiter = this.NestedTypeDelimiter;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.FullName = false;
                        this.IncludeGenericParameters = false;
                        this.IncludeGenericParameterNames = false;
                    }
                    static $h = 131093;
                    static $z = 5;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180000277,"f":1},"n":"FullName","d":131093,"h":12885032981,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30064902165,"f":1},"n":"IncludeGenericParameters","d":131093,"h":25769934869,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42949804053,"f":1},"n":"IncludeGenericParameterNames","d":131093,"h":38654836757,"f":1},{"p":458753,"g":{"r":0,"d":0,"h":55834705941,"f":1},"n":"NestedTypeDelimiter","d":131093,"h":51539738645,"f":1}],"c":[{"p":[{"n":"fullName","p":262145},{"n":"includeGenericParameterNames","p":262145},{"n":"includeGenericParameters","p":262145},{"n":"nestedTypeDelimiter","p":458753}],"n":".ctor","o":"$ctor$2","d":131093,"h":4295098389,"f":1},{"n":".ctor","o":"$ctor$3","d":131093,"h":60129673237,"f":1}],"d":65557,"h":131093}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper.DisplayNameOptions`; }
                }, $cls, ($v) => $cls.$_DisplayNameOptions = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._builtInTypeNames = (() =>
                    {
                        //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String)()
                        const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add($.$spc.System.Void.$type, "void");
                        $i1.Add($.$spc.System.Boolean.$type, "bool");
                        $i1.Add($.$spc.System.Byte.$type, "byte");
                        $i1.Add($.$spc.System.Char.$type, "char");
                        $i1.Add($.$spc.System.Decimal.$type, "decimal");
                        $i1.Add($.$spc.System.Double.$type, "double");
                        $i1.Add($.$spc.System.Single.$type, "float");
                        $i1.Add($.$spc.System.Int32.$type, "int");
                        $i1.Add($.$spc.System.Int64.$type, "long");
                        $i1.Add($.$spc.System.Object.$type, "object");
                        $i1.Add($.$spc.System.SByte.$type, "sbyte");
                        $i1.Add($.$spc.System.Int16.$type, "short");
                        $i1.Add($.$spc.System.String.$type, "string");
                        $i1.Add($.$spc.System.UInt32.$type, "uint");
                        $i1.Add($.$spc.System.UInt64.$type, "ulong");
                        $i1.Add($.$spc.System.UInt16.$type, "ushort");
                        return $i1;
                    })();
                }
            }
            static $h = 65557;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"item","p":131073},{"n":"fullName","p":262145,"f":65,"v":true}],"n":"GetTypeDisplayName","d":65557,"h":12884967445,"f":33},{"r":1310721,"p":[{"n":"type","p":142606337},{"n":"fullName","p":262145,"f":65,"v":true},{"n":"includeGenericParameterNames","p":262145,"f":65,"v":false},{"n":"includeGenericParameters","p":262145,"f":65,"v":true},{"n":"nestedTypeDelimiter","p":458753,"f":65,"v":"\u002B"}],"n":"GetTypeDisplayName","o":"@$1","d":65557,"h":17179934741,"f":33},{"r":1310721,"p":[{"n":"builder","p":122945537,"f":4},{"n":"type","p":142606337},{"n":"options","p":131093,"f":8}],"n":"ProcessType","d":65557,"h":21474902037,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"options","p":131093,"f":8}],"n":"ProcessArrayType","d":65557,"h":25769869333,"f":34},{"r":65537,"p":[{"n":"builder","p":122945537},{"n":"type","p":142606337},{"n":"genericArguments","p":0},{"n":"length","p":655361},{"n":"options","p":131093,"f":8}],"n":"ProcessGenericType","d":65557,"h":30064836629,"f":34}],"l":[{"t":458753,"n":"DefaultNestedTypeDelimiter","d":65557,"h":4295032853,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.String).$h,"n":"_builtInTypeNames","d":65557,"h":8590000149,"f":34}],"j":[131093],"h":65557}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Internal.TypeNameHelper`; }
        });
        
        $asm.$cls("$mela.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$mela.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("Microsoft.Extensions.Logging.Abstractions", $.$mela.System.SR.$type.Assembly);
                    $.$mela.System.SR.s_resourceManager = temp;
                }
                return $.$mela.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$mela.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$mela.System.SR.resourceCulture = value;
            }
            static /*string */ get UnexpectedNumberOfNamedParameters()
            {
                return "The format string '{0}' does not have the expected number of named parameters. Expected {1} parameter(s) but found {2} parameter(s).";
            }
            static /*string */ FormatUnexpectedNumberOfNamedParameters(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The format string '{0}' does not have the expected number of named parameters. Expected {1} parameter(s) but found {2} parameter(s).", arg1, arg2, arg3);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$mela.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$mela.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$mela.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mela.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$mela.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$mela.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$mela.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2621461;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2621461}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.DebuggerDisplayFormatting", ($self) => class DebuggerDisplayFormatting
        {
            static /*string */ DebuggerToString(/*string*/ name, /*ILogger*/ logger)
            {
                /*LogLevel?*/ let minimumLevel = $.$mela.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.CalculateEnabledLogLevel(logger);
                /*var*/ let debugText = `Name = \"${name}\"`;
                if (minimumLevel !== null)
                {
                    debugText += `, MinLevel = ${minimumLevel}`;
                }
                else 
                {
                    debugText += `, Enabled = false`;
                }
                return debugText;
            }
            static /*LogLevel? */ CalculateEnabledLogLevel(/*ILogger*/ logger)
            {
                /*ReadOnlySpan<LogLevel>*/ let logLevels = new ($.$spc.System.ReadOnlySpan$$($.$mela.Microsoft.Extensions.Logging.LogLevel))().$ctor$2([ 5/*LogLevel.Critical*/, 4/*LogLevel.Error*/, 3/*LogLevel.Warning*/, 2/*LogLevel.Information*/, 1/*LogLevel.Debug*/, 0/*LogLevel.Trace*/ ]);
                /*LogLevel?*/ let minimumLevel = null;
                var $en2 = logLevels.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var logLevel = $en2.Current.$v;
                    {
                        if (!logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                        {
                            break;
                        }
                        minimumLevel = logLevel;
                    }
                }
                return minimumLevel;
            }
            static $h = 655381;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"logger","p":917525}],"n":"DebuggerToString","d":655381,"h":4295622677,"f":40},{"r":$.$typeNullable($.$mela.Microsoft.Extensions.Logging.LogLevel).$h,"p":[{"n":"logger","p":917525}],"n":"CalculateEnabledLogLevel","d":655381,"h":8590589973,"f":40}],"h":655381}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.DebuggerDisplayFormatting`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LogDefineOptions", ($self) => class LogDefineOptions extends $.$spc.System.Object
        {
            /*bool*/ SkipEnabledCheck = false;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.SkipEnabledCheck = false;
            }
            static $h = 1310741;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886212629,"f":1},"s":{"r":0,"d":0,"h":17181179925,"f":1},"n":"SkipEnabledCheck","d":1310741,"h":8591245333,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1310741,"h":21476147221,"f":1}],"h":1310741}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogDefineOptions`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LoggerFactoryExtensions", ($self) => class LoggerFactoryExtensions
        {
            static /*ILogger<T> */ CreateLogger(T, /*this ILoggerFactory*/ factory)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                return new ($.$mela.Microsoft.Extensions.Logging.Logger$$(T))().$ctor$1(factory);
            }
            static /*ILogger */ CreateLogger$1(/*this ILoggerFactory*/ factory, /*Type*/ type)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                $.$spc.System.ArgumentNullException.ThrowIfNull(type, "type");
                return factory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger($.$mela.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(type, true, false, false, /*.*/ 46));
            }
            static $h = 1638421;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(T) => $.$mela.Microsoft.Extensions.Logging.ILogger$$(T).$h,"p":[{"n":"factory","p":1048597}],"g":["T"],"n":"CreateLogger","d":1638421,"h":4296605717,"f":131105},{"r":917525,"p":[{"n":"factory","p":1048597},{"n":"type","p":142606337}],"n":"CreateLogger","o":"@$1","d":1638421,"h":8591573013,"f":33}],"h":1638421}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerFactoryExtensions`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LogValuesFormatter", ($self) => class LogValuesFormatter extends $.$spc.System.Object
        {
            /*string*/ static NullValue = null;
            /*List<string>*/ _valueNames = null;
            /*CompositeFormat*/ _format = null;
            $ctor$1(/*string*/ format)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(format, "format");
                    this.OriginalFormat = format;
                    /*var*/ let vsb = new $.$mela.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null));
                    /*int*/ let scanIndex = 0;
                    /*int*/ let endIndex = format.length;
                    while(scanIndex < endIndex)
                    {
                        /*int*/ let openBraceIndex = $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.FindBraceIndex(format, /*{*/ 123, scanIndex, endIndex);
                        if (scanIndex === 0 && openBraceIndex === endIndex)
                        {
                            this._format = $.$spc.System.Text.CompositeFormat.Parse(format);
                            return this;
                        }
                        /*int*/ let closeBraceIndex = $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.FindBraceIndex(format, /*}*/ 125, openBraceIndex, endIndex);
                        if (closeBraceIndex === endIndex)
                        {
                            vsb.Append$3($.$spc.System.MemoryExtensions.AsSpan$7(format, scanIndex, ((endIndex - scanIndex) | 0)));
                            scanIndex = endIndex;
                        }
                        else 
                        {
                            /*int*/ let formatDelimiterIndex = $.$spc.System.MemoryExtensions.IndexOfAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$7(format, openBraceIndex, ((closeBraceIndex - openBraceIndex) | 0)), /*,*/ 44, /*:*/ 58);
                            formatDelimiterIndex = formatDelimiterIndex < 0 ? closeBraceIndex : ((formatDelimiterIndex + openBraceIndex) | 0);
                            vsb.Append$3($.$spc.System.MemoryExtensions.AsSpan$7(format, scanIndex, ((((openBraceIndex - scanIndex) | 0) + 1) | 0)));
                            vsb.Append$1($.$spc.System.Int32.ToString$2.call(this._valueNames.Count, $.$spc.System.Globalization.CultureInfo.InvariantCulture));
                            this._valueNames.Add($.$spc.System.String.Substring$1.call(format, ((openBraceIndex + 1) | 0), ((((formatDelimiterIndex - openBraceIndex) | 0) - 1) | 0)));
                            vsb.Append$3($.$spc.System.MemoryExtensions.AsSpan$7(format, formatDelimiterIndex, ((((closeBraceIndex - formatDelimiterIndex) | 0) + 1) | 0)));
                            scanIndex = ((closeBraceIndex + 1) | 0);
                        }
                    }
                    this._format = $.$spc.System.Text.CompositeFormat.Parse($.$mela.System.Text.ValueStringBuilder.ToString.call(vsb));
                }
                return this;
            }
            /*string*/ OriginalFormat = null;
            /*List<string> */ get ValueNames()
            {
                return this._valueNames;
            }
            static /*int */ FindBraceIndex(/*string*/ format, /*char*/ brace, /*int*/ startIndex, /*int*/ endIndex)
            {
                /*int*/ let braceIndex = endIndex;
                /*int*/ let scanIndex = startIndex;
                /*int*/ let braceOccurrenceCount = 0;
                while(scanIndex < endIndex)
                {
                    if (braceOccurrenceCount > 0 && $.$spc.System.String.get_Chars.call(format, scanIndex) !== brace)
                    {
                        if (braceOccurrenceCount % 2 === 0)
                        {
                            braceOccurrenceCount = 0;
                            braceIndex = endIndex;
                        }
                        else 
                        {
                            break;
                        }
                    }
                    else if ($.$spc.System.String.get_Chars.call(format, scanIndex) === brace)
                    {
                        if (brace === /*}*/ 125)
                        {
                            if (braceOccurrenceCount === 0)
                            {
                                braceIndex = scanIndex;
                            }
                        }
                        else 
                        {
                            braceIndex = scanIndex;
                        }
                        braceOccurrenceCount++;
                    }
                    scanIndex++;
                }
                return braceIndex;
            }
            /*string */ Format(/*object?[]?*/ values)
            {
                /*object?[]?*/ let formattedValues = values;
                if (values !== null)
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        /*object*/ let formattedValue = $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$spc.System.Array.$ReadT1.call(values, i));
                        if (!$.$spc.System.Object.ReferenceEquals(formattedValue, $.$spc.System.Array.$ReadT1.call(values, i)))
                        {
                            formattedValues = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [values.length], null);
                            $.$spc.System.Array.Copy(values, formattedValues, i);
                            $.$spc.System.Array.$WriteT1.call(formattedValues, formattedValue, i++);
                            for(; i < values.length; i++)
                            {
                                $.$spc.System.Array.$WriteT1.call(formattedValues, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$spc.System.Array.$ReadT1.call(values, i)), i);
                            }
                            break;
                        }
                    }
                }
                return $.$spc.System.String.Format$13($.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, formattedValues ?? $.$spc.System.Array.Empty($.$spc.System.Object));
            }
            /*string */ FormatWithOverwrite(/*object?[]?*/ values)
            {
                if (values !== null)
                {
                    for(/*int*/ let i = 0; i < values.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(values, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.FormatArgument($.$spc.System.Array.$ReadT1.call(values, i)), i);
                    }
                }
                return $.$spc.System.String.Format$13($.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, values ?? $.$spc.System.Array.Empty($.$spc.System.Object));
            }
            /*string */ Format$1()
            {
                return this._format.Format;
            }
            /*string */ Format$2(TArg0, /*TArg0*/ arg0)
            {
                /*object?*/ let arg0String;
                return !$.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$spc.System.Object)) ? $.$spc.System.String.Format$10(TArg0, $.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0) : $.$spc.System.String.Format$14($.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg0String ]));
            }
            /*string */ Format$3(TArg0, TArg1, /*TArg0*/ arg0, /*TArg1*/ arg1)
            {
                /*object?*/ let arg0String;
                /*object?*/ let arg1String;
                return $.$spc.System.Boolean.op_BitwiseOr($.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$spc.System.Object)), $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg1, arg1, $.$ref(() => arg1String, ($v) => arg1String = $v, $.$spc.System.Object))) ? $.$spc.System.String.Format$14($.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg0String ?? $.$box(arg0, TArg0), arg1String ?? $.$box(arg1, TArg1) ])) : $.$spc.System.String.Format$11(TArg0, TArg1, $.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0, arg1);
            }
            /*string */ Format$4(TArg0, TArg1, TArg2, /*TArg0*/ arg0, /*TArg1*/ arg1, /*TArg2*/ arg2)
            {
                /*object?*/ let arg0String;
                /*object?*/ let arg1String;
                /*object?*/ let arg2String;
                return $.$spc.System.Boolean.op_BitwiseOr($.$spc.System.Boolean.op_BitwiseOr($.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg0, arg0, $.$ref(() => arg0String, ($v) => arg0String = $v, $.$spc.System.Object)), $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg1, arg1, $.$ref(() => arg1String, ($v) => arg1String = $v, $.$spc.System.Object))), $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable(TArg2, arg2, $.$ref(() => arg2String, ($v) => arg2String = $v, $.$spc.System.Object))) ? $.$spc.System.String.Format$14($.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg0String ?? $.$box(arg0, TArg0), arg1String ?? $.$box(arg1, TArg1), arg2String ?? $.$box(arg2, TArg2) ])) : $.$spc.System.String.Format$12(TArg0, TArg1, TArg2, $.$spc.System.Globalization.CultureInfo.InvariantCulture, this._format, arg0, arg1, arg2);
            }
            /*KeyValuePair<string, object?> */ GetValue(/*object?[]*/ values, /*int*/ index)
            {
                if (index < 0 || index > this._valueNames.Count)
                {
                    throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                }
                if (this._valueNames.Count > index)
                {
                    return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._valueNames.get_Item(index), $.$spc.System.Array.$ReadT1.call(values, index));
                }
                return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this.OriginalFormat);
            }
            /*IEnumerable<KeyValuePair<string, object?>> */ GetValues(/*object[]*/ values)
            {
                /*var*/ let valueArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [((values.length + 1) | 0)], null);
                for(/*int*/ let index = 0; index !== this._valueNames.Count; ++index)
                {
                    $.$spc.System.Array.$WriteT1.call(valueArray, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._valueNames.get_Item(index), $.$spc.System.Array.$ReadT1.call(values, index)), index);
                }
                $.$spc.System.Array.$WriteT1.call(valueArray, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this.OriginalFormat), ((valueArray.length - 1) | 0));
                return valueArray;
            }
            static /*object */ FormatArgument(/*object?*/ value)
            {
                /*object?*/ let stringValue;
                return $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter.TryFormatArgumentIfNullOrEnumerable($.$spc.System.Object, value, $.$ref(() => stringValue, ($v) => stringValue = $v, $.$spc.System.Object)) ? stringValue : value;
            }
            static /*bool */ TryFormatArgumentIfNullOrEnumerable(T, /*T?*/ value, /*out object?*/ stringValue)
            {
                if ($.$box(value, T) === null)
                {
                    stringValue.$v = "(null)"/*NullValue*/;
                    return true;
                }
                let enumerable;
                if (!(value !== null && ($.$is(value, $.$spc.System.String))) && $.$is(value, $.$spc.System.Collections.IEnumerable, { set $v(v){ enumerable = v; } }))
                {
                    /*var*/ let vsb = new $.$mela.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null));
                    /*bool*/ let first = true;
                    var $en3 = enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var e = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!first)
                            {
                                vsb.Append$1(", ");
                            }
                            let f;
                            vsb.Append$1($.$is(e, $.$spc.System.IFormattable, { set $v(v){ f = v; } }) ? f.System$IFormattable$ToString(null, $.$spc.System.Globalization.CultureInfo.InvariantCulture) : !(e === null) ? $.$spc.System.Object.ToString.call(e) : "(null)"/*NullValue*/);
                            first = false;
                        }
                    }
                    stringValue.$v = $.$mela.System.Text.ValueStringBuilder.ToString.call(vsb);
                    return true;
                }
                stringValue.$v = null;
                return false;
            }
            //default member initializer
            constructor()
            {
                super();
                this._valueNames = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.NullValue = "(null)";
                }
            }
            static $h = 2359317;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30067130389,"f":1},"n":"OriginalFormat","d":2359317,"h":25772163093,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":38657064981,"f":1},"n":"ValueNames","d":2359317,"h":34362097685,"f":1}],"m":[{"r":655361,"p":[{"n":"format","p":1310721},{"n":"brace","p":458753},{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":"FindBraceIndex","d":2359317,"h":42952032277,"f":34},{"r":1310721,"p":[{"n":"values","p":0}],"n":"Format","d":2359317,"h":47246999573,"f":1},{"r":1310721,"p":[{"n":"values","p":0}],"n":"FormatWithOverwrite","d":2359317,"h":51541966869,"f":8},{"r":1310721,"n":"Format","o":"@$1","d":2359317,"h":55836934165,"f":8},{"r":1310721,"p":[{"n":"arg0","p":(TArg0) => TArg0.$h}],"g":["TArg0"],"n":"Format","o":"@$2","d":2359317,"h":60131901461,"f":131080},{"r":1310721,"p":[{"n":"arg0","p":(TArg0, TArg1) => TArg0.$h},{"n":"arg1","p":(TArg0, TArg1) => TArg1.$h}],"g":["TArg0","TArg1"],"n":"Format","o":"@$3","d":2359317,"h":64426868757,"f":131080},{"r":1310721,"p":[{"n":"arg0","p":(TArg0, TArg1, TArg2) => TArg0.$h},{"n":"arg1","p":(TArg0, TArg1, TArg2) => TArg1.$h},{"n":"arg2","p":(TArg0, TArg1, TArg2) => TArg2.$h}],"g":["TArg0","TArg1","TArg2"],"n":"Format","o":"@$4","d":2359317,"h":68721836053,"f":131080},{"r":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"p":[{"n":"values","p":0},{"n":"index","p":655361}],"n":"GetValue","d":2359317,"h":73016803349,"f":1},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"p":[{"n":"values","p":0}],"n":"GetValues","d":2359317,"h":77311770645,"f":1},{"r":131073,"p":[{"n":"value","p":131073}],"n":"FormatArgument","d":2359317,"h":81606737941,"f":34},{"r":262145,"p":[{"n":"value","p":(T) => T.$h},{"n":"stringValue","p":131073,"f":2}],"g":["T"],"n":"TryFormatArgumentIfNullOrEnumerable","d":2359317,"h":85901705237,"f":131106}],"l":[{"t":1310721,"n":"NullValue","d":2359317,"h":4297326613,"f":34},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h,"n":"_valueNames","d":2359317,"h":8592293909,"f":2},{"t":120455169,"n":"_format","d":2359317,"h":12887261205,"f":2}],"c":[{"p":[{"n":"format","p":1310721}],"n":".ctor","o":"$ctor$1","d":2359317,"h":17182228501,"f":1}],"h":2359317}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogValuesFormatter`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LoggerExtensions", ($self) => class LoggerExtensions
        {
            /*Func<FormattedLogValues, Exception?, string>*/ static _messageFormatter = null;
            static /*void */ LogDebug(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 1/*LogLevel.Debug*/, eventId, exception, message, args);
            }
            static /*void */ LogDebug$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 1/*LogLevel.Debug*/, eventId, message, args);
            }
            static /*void */ LogDebug$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 1/*LogLevel.Debug*/, exception, message, args);
            }
            static /*void */ LogDebug$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 1/*LogLevel.Debug*/, message, args);
            }
            static /*void */ LogTrace(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 0/*LogLevel.Trace*/, eventId, exception, message, args);
            }
            static /*void */ LogTrace$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 0/*LogLevel.Trace*/, eventId, message, args);
            }
            static /*void */ LogTrace$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 0/*LogLevel.Trace*/, exception, message, args);
            }
            static /*void */ LogTrace$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 0/*LogLevel.Trace*/, message, args);
            }
            static /*void */ LogInformation(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 2/*LogLevel.Information*/, eventId, exception, message, args);
            }
            static /*void */ LogInformation$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 2/*LogLevel.Information*/, eventId, message, args);
            }
            static /*void */ LogInformation$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 2/*LogLevel.Information*/, exception, message, args);
            }
            static /*void */ LogInformation$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 2/*LogLevel.Information*/, message, args);
            }
            static /*void */ LogWarning(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 3/*LogLevel.Warning*/, eventId, exception, message, args);
            }
            static /*void */ LogWarning$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 3/*LogLevel.Warning*/, eventId, message, args);
            }
            static /*void */ LogWarning$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 3/*LogLevel.Warning*/, exception, message, args);
            }
            static /*void */ LogWarning$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 3/*LogLevel.Warning*/, message, args);
            }
            static /*void */ LogError(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 4/*LogLevel.Error*/, eventId, exception, message, args);
            }
            static /*void */ LogError$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 4/*LogLevel.Error*/, eventId, message, args);
            }
            static /*void */ LogError$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 4/*LogLevel.Error*/, exception, message, args);
            }
            static /*void */ LogError$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 4/*LogLevel.Error*/, message, args);
            }
            static /*void */ LogCritical(/*this ILogger*/ logger, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, 5/*LogLevel.Critical*/, eventId, exception, message, args);
            }
            static /*void */ LogCritical$1(/*this ILogger*/ logger, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$1(logger, 5/*LogLevel.Critical*/, eventId, message, args);
            }
            static /*void */ LogCritical$2(/*this ILogger*/ logger, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$2(logger, 5/*LogLevel.Critical*/, exception, message, args);
            }
            static /*void */ LogCritical$3(/*this ILogger*/ logger, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log(logger, 5/*LogLevel.Critical*/, message, args);
            }
            static /*void */ Log(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, logLevel, $.$mela.Microsoft.Extensions.Logging.EventId.op_Implicit(0), null, message, args);
            }
            static /*void */ Log$1(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, logLevel, eventId, null, message, args);
            }
            static /*void */ Log$2(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.Log$3(logger, logLevel, $.$mela.Microsoft.Extensions.Logging.EventId.op_Implicit(0), exception, message, args);
            }
            static /*void */ Log$3(/*this ILogger*/ logger, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*Exception?*/ exception, /*string?*/ message, /*params object?[]*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(logger, "logger");
                logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.FormattedLogValues, logLevel, eventId, new $.$mela.Microsoft.Extensions.Logging.FormattedLogValues().$ctor$2(message, args), exception, $.$mela.Microsoft.Extensions.Logging.LoggerExtensions._messageFormatter);
            }
            static /*IDisposable? */ BeginScope(/*this ILogger*/ logger, /*string*/ messageFormat, /*params object?[]*/ args)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(logger, "logger");
                return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.FormattedLogValues, new $.$mela.Microsoft.Extensions.Logging.FormattedLogValues().$ctor$2(messageFormat, args));
            }
            static /*string */ MessageFormatter(/*FormattedLogValues*/ state, /*Exception?*/ error)
            {
                return $.$mela.Microsoft.Extensions.Logging.FormattedLogValues.ToString.call(state);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._messageFormatter = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.FormattedLogValues, $.$spc.System.Exception, $.$spc.System.String))().$ctor(null, $.$mela.Microsoft.Extensions.Logging.LoggerExtensions.MessageFormatter);
                }
            }
            static $h = 1441813;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogDebug","d":1441813,"h":8591376405,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogDebug","o":"@$1","d":1441813,"h":12886343701,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogDebug","o":"@$2","d":1441813,"h":17181310997,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogDebug","o":"@$3","d":1441813,"h":21476278293,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogTrace","d":1441813,"h":25771245589,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogTrace","o":"@$1","d":1441813,"h":30066212885,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogTrace","o":"@$2","d":1441813,"h":34361180181,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogTrace","o":"@$3","d":1441813,"h":38656147477,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogInformation","d":1441813,"h":42951114773,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogInformation","o":"@$1","d":1441813,"h":47246082069,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogInformation","o":"@$2","d":1441813,"h":51541049365,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogInformation","o":"@$3","d":1441813,"h":55836016661,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogWarning","d":1441813,"h":60130983957,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogWarning","o":"@$1","d":1441813,"h":64425951253,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogWarning","o":"@$2","d":1441813,"h":68720918549,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogWarning","o":"@$3","d":1441813,"h":73015885845,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogError","d":1441813,"h":77310853141,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogError","o":"@$1","d":1441813,"h":81605820437,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogError","o":"@$2","d":1441813,"h":85900787733,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogError","o":"@$3","d":1441813,"h":90195755029,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogCritical","d":1441813,"h":94490722325,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogCritical","o":"@$1","d":1441813,"h":98785689621,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogCritical","o":"@$2","d":1441813,"h":103080656917,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"LogCritical","o":"@$3","d":1441813,"h":107375624213,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"logLevel","p":2293781},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"Log","d":1441813,"h":111670591509,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"Log","o":"@$1","d":1441813,"h":115965558805,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"logLevel","p":2293781},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"Log","o":"@$2","d":1441813,"h":120260526101,"f":33},{"r":65537,"p":[{"n":"logger","p":917525},{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"exception","p":47185921},{"n":"message","p":1310721},{"n":"args","p":0,"f":16}],"n":"Log","o":"@$3","d":1441813,"h":124555493397,"f":33},{"r":57475073,"p":[{"n":"logger","p":917525},{"n":"messageFormat","p":1310721},{"n":"args","p":0,"f":16}],"n":"BeginScope","d":1441813,"h":128850460693,"f":33},{"r":1310721,"p":[{"n":"state","p":786453},{"n":"error","p":47185921}],"n":"MessageFormatter","d":1441813,"h":133145427989,"f":34}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.FormattedLogValues, $.$spc.System.Exception, $.$spc.System.String).$h,"n":"_messageFormatter","d":1441813,"h":4296409109,"f":34}],"h":1441813}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExtensions`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LoggerMessage", ($self) => class LoggerMessage
        {
            static /*Func<ILogger, IDisposable?> */ DefineScope(/*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 0);
                /*var*/ let logValues = new $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues().$ctor$2(formatter);
                return new ($.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.IDisposable))().$ctor(this,  (/*logger*/ logger) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues, logValues);
                });
            }
            static /*Func<ILogger, T1, IDisposable?> */ DefineScope$1(T1, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 1);
                return new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.IDisposable))().$ctor(this,  (/**/ logger, /*arg1*/ arg1) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1))().$ctor$2(formatter, arg1));
                });
            }
            static /*Func<ILogger, T1, T2, IDisposable?> */ DefineScope$2(T1, T2, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 2);
                return new ($.$spc.System.Func$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2))().$ctor$2(formatter, arg1, arg2));
                });
            }
            static /*Func<ILogger, T1, T2, T3, IDisposable?> */ DefineScope$3(T1, T2, T3, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 3);
                return new ($.$spc.System.Func$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3))().$ctor$2(formatter, arg1, arg2, arg3));
                });
            }
            static /*Func<ILogger, T1, T2, T3, T4, IDisposable?> */ DefineScope$4(T1, T2, T3, T4, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 4);
                return new ($.$spc.System.Func$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4))().$ctor$2(formatter, arg1, arg2, arg3, arg4));
                });
            }
            static /*Func<ILogger, T1, T2, T3, T4, T5, IDisposable?> */ DefineScope$5(T1, T2, T3, T4, T5, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 5);
                return new ($.$spc.System.Func$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.IDisposable))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5))().$ctor$2(formatter, arg1, arg2, arg3, arg4, arg5));
                });
            }
            static /*Func<ILogger, T1, T2, T3, T4, T5, T6, IDisposable?> */ DefineScope$6(T1, T2, T3, T4, T5, T6, /*string*/ formatString)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 6);
                return new ($.$spc.System.Func$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.IDisposable))().$ctor(this,  (/**/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*arg6*/ arg6) =>
                {
                    return logger.Microsoft$Extensions$Logging$ILogger$BeginScope($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6), new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6))().$ctor$2(formatter, arg1, arg2, arg3, arg4, arg5, arg6));
                });
            }
            static /*Action<ILogger, Exception?> */ Define(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$1(logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, Exception?> */ Define$1(/*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 0);
                /*void*/  function Log(/*ILogger*/ logger, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues, logLevel, eventId, new $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues().$ctor$2(formatter), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues.Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.Exception))().$ctor(this,  (/*logger*/ logger, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, Exception?> */ Define$2(T1, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$3(T1, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, Exception?> */ Define$3(T1, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 1);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1))().$ctor$2(formatter, arg1), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T1).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, T2, Exception?> */ Define$4(T1, T2, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$5(T1, T2, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, T2, Exception?> */ Define$5(T1, T2, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 2);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2))().$ctor$2(formatter, arg1, arg2), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T1, T2).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, T2, T3, Exception?> */ Define$6(T1, T2, T3, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$7(T1, T2, T3, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, T2, T3, Exception?> */ Define$7(T1, T2, T3, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 3);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3))().$ctor$2(formatter, arg1, arg2, arg3), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T1, T2, T3).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.Exception))().$ctor(this,  (/**/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, T2, T3, T4, Exception?> */ Define$8(T1, T2, T3, T4, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$9(T1, T2, T3, T4, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, T2, T3, T4, Exception?> */ Define$9(T1, T2, T3, T4, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 4);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4))().$ctor$2(formatter, arg1, arg2, arg3, arg4), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T1, T2, T3, T4).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.Exception))().$ctor(this,  (/**/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, T2, T3, T4, T5, Exception?> */ Define$10(T1, T2, T3, T4, T5, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$11(T1, T2, T3, T4, T5, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, T2, T3, T4, T5, Exception?> */ Define$11(T1, T2, T3, T4, T5, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 5);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*T5*/ arg5, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5))().$ctor$2(formatter, arg1, arg2, arg3, arg4, arg5), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T1, T2, T3, T4, T5).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, arg5, exception);
                    }
                });
            }
            static /*Action<ILogger, T1, T2, T3, T4, T5, T6, Exception?> */ Define$12(T1, T2, T3, T4, T5, T6, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString)
            {
                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.Define$13(T1, T2, T3, T4, T5, T6, logLevel, eventId, formatString, null);
            }
            static /*Action<ILogger, T1, T2, T3, T4, T5, T6, Exception?> */ Define$13(T1, T2, T3, T4, T5, T6, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*string*/ formatString, /*LogDefineOptions?*/ options)
            {
                /*LogValuesFormatter*/ let formatter = $.$mela.Microsoft.Extensions.Logging.LoggerMessage.CreateLogValuesFormatter(formatString, 6);
                /*void*/  function Log(/*ILogger*/ logger, /*T1*/ arg1, /*T2*/ arg2, /*T3*/ arg3, /*T4*/ arg4, /*T5*/ arg5, /*T6*/ arg6, /*Exception?*/ exception)
                {
                    logger.Microsoft$Extensions$Logging$ILogger$Log($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6), logLevel, eventId, new ($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6))().$ctor$2(formatter, arg1, arg2, arg3, arg4, arg5, arg6), exception, $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T1, T2, T3, T4, T5, T6).Callback);
                }
                if (options !== null && options.SkipEnabledCheck)
                {
                    return new ($.$spc.System.Action$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.Exception))().$ctor(this, Log);
                }
                return new ($.$spc.System.Action$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.Exception))().$ctor(this,  (/*logger*/ logger, /*arg1*/ arg1, /*arg2*/ arg2, /*arg3*/ arg3, /*arg4*/ arg4, /*arg5*/ arg5, /*arg6*/ arg6, /*exception*/ exception) =>
                {
                    if (logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel))
                    {
                        Log.call(this, logger, arg1, arg2, arg3, arg4, arg5, arg6, exception);
                    }
                });
            }
            static /*LogValuesFormatter */ CreateLogValuesFormatter(/*string*/ formatString, /*int*/ expectedNamedParameterCount)
            {
                /*var*/ let logValuesFormatter = new $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(formatString);
                /*int*/ let actualCount = logValuesFormatter.ValueNames.Count;
                if (actualCount !== expectedNamedParameterCount)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$mela.System.SR.Format$2($.$mela.System.SR.UnexpectedNumberOfNamedParameters, formatString, $.$box(expectedNamedParameterCount, $.$spc.System.Int32), $.$box(actualCount, $.$spc.System.Int32)));
                }
                return logValuesFormatter;
            }
            static $_LogValues;
            static get LogValues()
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return $cls.$_LogValues ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues", ($self) => class LogValues extends $.$spc.System.ValueType
                {
                    /*Func<LogValues, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    $ctor$2(/*LogValuesFormatter*/ formatter)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                        }
                        return this;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        if (index === 0)
                        {
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                        }
                        throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                    }
                    /*int */ get Count()
                    {
                        return 1;
                    }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            yield this.get_Item(0);
                        }.bind(this)).GetEnumerator();
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.Format$1();
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues.ToString.apply(this, arguments); }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues, $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues.ToString.call(state);
                            });
                        }
                    }
                    static $h = 1769493;
                    static $z = 4;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":21476605973,"f":1},"n":"Item","o":"@$2","d":1769493,"h":17181638677,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30066540565,"f":1},"n":"Count","d":1769493,"h":25771573269,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":1769493,"h":34361507861,"f":1},{"r":1310721,"n":"ToString","d":1769493,"h":38656475157,"f":32769}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues, $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":1769493,"h":4296736789,"f":33},{"t":2359317,"n":"_formatter","d":1769493,"h":8591704085,"f":2}],"c":[{"p":[{"n":"formatter","p":2359317}],"n":".ctor","o":"$ctor$2","d":1769493,"h":12886671381,"f":1},{"n":".ctor","o":"$ctor$3","d":1769493,"h":47246409749,"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"d":1703957,"h":1769493}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues`; }
                }, $cls, ($v) => $cls.$_LogValues = $v);
            }
            static $_LogValues$$;
            static LogValues$$(T0)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<>", (T0) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<>", [T0], ($self) => class LogValues$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                        }
                        return this;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    /*int */ get Count()
                    {
                        return 2;
                    }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.Format$2(T0, this._value0);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0).ToString.apply(this, arguments); }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0).ToString.call(state);
                            });
                        }
                    }
                    static $h = 2162709;
                    static $g = 1;
                    static $z = 8;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32769}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$(T0), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328],"r":1,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$ = $v))(T0);
            }
            static $_LogValues$$$;
            static LogValues$$$(T0, T1)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,>", (T0, T1) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,>", [T0, T1], ($self) => class LogValues$$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0, T1>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                        }
                        return this;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    /*int */ get Count()
                    {
                        return 3;
                    }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.Format$3(T0, T1, this._value0, this._value1);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1).ToString.apply(this, arguments); }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                        this._value1 = $.$default(T1);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1).ToString.call(state);
                            });
                        }
                    }
                    static $h = 2097173;
                    static $g = 2;
                    static $z = 12;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$(T0, T1), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":T1?.$h??1572864,"n":"_value1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328},{"n":"value1","p":T1?.$h??1572864}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328,T1?.$h??1572864],"r":2,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$ = $v))(T0, T1);
            }
            static $_LogValues$$$$;
            static LogValues$$$$(T0, T1, T2)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,>", (T0, T1, T2) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,>", [T0, T1, T2], ($self) => class LogValues$$$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0, T1, T2>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    /*int */ get Count()
                    {
                        return 4;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                        }
                        return this;
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.Format$4(T0, T1, T2, this._value0, this._value1, this._value2);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2).ToString.apply(this, arguments); }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                        this._value1 = $.$default(T1);
                        this._value2 = $.$default(T2);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2).ToString.call(state);
                            });
                        }
                    }
                    static $h = 2031637;
                    static $g = 3;
                    static $z = 16;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1}],"m":[{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":32769},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$(T0, T1, T2), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":T1?.$h??1572864,"n":"_value1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":T2?.$h??1638400,"n":"_value2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328},{"n":"value1","p":T1?.$h??1572864},{"n":"value2","p":T2?.$h??1638400}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400],"r":3,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$ = $v))(T0, T1, T2);
            }
            static $_LogValues$$$$$;
            static LogValues$$$$$(T0, T1, T2, T3)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,>", (T0, T1, T2, T3) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,>", [T0, T1, T2, T3], ($self) => class LogValues$$$$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0, T1, T2, T3>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    /*int */ get Count()
                    {
                        return 5;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                        }
                        return this;
                    }
                    /*object?[] */ ToArray()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3)], [-1], null);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.FormatWithOverwrite(this.ToArray());
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3).ToString.apply(this, arguments); }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                        this._value1 = $.$default(T1);
                        this._value2 = $.$default(T2);
                        this._value3 = $.$default(T3);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3).ToString.call(state);
                            });
                        }
                    }
                    static $h = 1966101;
                    static $g = 4;
                    static $z = 20;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1}],"m":[{"r":0,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":32769},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":1}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$(T0, T1, T2, T3), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":T1?.$h??1572864,"n":"_value1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":T2?.$h??1638400,"n":"_value2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":T3?.$h??1703936,"n":"_value3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328},{"n":"value1","p":T1?.$h??1572864},{"n":"value2","p":T2?.$h??1638400},{"n":"value3","p":T3?.$h??1703936}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936],"r":4,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$ = $v))(T0, T1, T2, T3);
            }
            static $_LogValues$$$$$$;
            static LogValues$$$$$$(T0, T1, T2, T3, T4)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,>", (T0, T1, T2, T3, T4) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,>", [T0, T1, T2, T3, T4], ($self) => class LogValues$$$$$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0, T1, T2, T3, T4>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    /*T4*/  get _value4() { return this.$getField(20, 4); }
                    /*T4*/  set _value4(value) { this.$setField(20, 4, value); }
                    /*int */ get Count()
                    {
                        return 6;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(4), $.$box(this._value4, T4));
                            case 5:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3, /*T4*/ value4)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                            this._value4 = value4;
                        }
                        return this;
                    }
                    /*object?[] */ ToArray()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3), $.$box(this._value4, T4)], [-1], null);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.FormatWithOverwrite(this.ToArray());
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4).ToString.apply(this, arguments); }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        copy._value4 = this._value4;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                        this._value1 = $.$default(T1);
                        this._value2 = $.$default(T2);
                        this._value3 = $.$default(T3);
                        this._value4 = $.$default(T4);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4).ToString.call(state);
                            });
                        }
                    }
                    static $h = 1900565;
                    static $g = 5;
                    static $z = 24;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1}],"m":[{"r":0,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":32769},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$(T0, T1, T2, T3, T4), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":T1?.$h??1572864,"n":"_value1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":T2?.$h??1638400,"n":"_value2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":T3?.$h??1703936,"n":"_value3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},{"t":T4?.$h??1769472,"n":"_value4","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328},{"n":"value1","p":T1?.$h??1572864},{"n":"value2","p":T2?.$h??1638400},{"n":"value3","p":T3?.$h??1703936},{"n":"value4","p":T4?.$h??1769472}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936,T4?.$h??1769472],"r":5,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$$ = $v))(T0, T1, T2, T3, T4);
            }
            static $_LogValues$$$$$$$;
            static LogValues$$$$$$$(T0, T1, T2, T3, T4, T5)
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerMessage;
                return ($cls.$_LogValues$$$$$$$ ??= $asm.$nstr("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,,>", (T0, T1, T2, T3, T4, T5) => $asm.$gt("$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues<,,,,,>", [T0, T1, T2, T3, T4, T5], ($self) => class LogValues$$$$$$$ extends $.$spc.System.ValueType
                {
                    /*Func<LogValues<T0, T1, T2, T3, T4, T5>, Exception?, string>*/ static Callback = null;
                    /*LogValuesFormatter*/  get _formatter() { return this.$getField(0, 4); }
                    /*LogValuesFormatter*/  set _formatter(value) { this.$setField(0, 4, value); }
                    /*T0*/  get _value0() { return this.$getField(4, 4); }
                    /*T0*/  set _value0(value) { this.$setField(4, 4, value); }
                    /*T1*/  get _value1() { return this.$getField(8, 4); }
                    /*T1*/  set _value1(value) { this.$setField(8, 4, value); }
                    /*T2*/  get _value2() { return this.$getField(12, 4); }
                    /*T2*/  set _value2(value) { this.$setField(12, 4, value); }
                    /*T3*/  get _value3() { return this.$getField(16, 4); }
                    /*T3*/  set _value3(value) { this.$setField(16, 4, value); }
                    /*T4*/  get _value4() { return this.$getField(20, 4); }
                    /*T4*/  set _value4(value) { this.$setField(20, 4, value); }
                    /*T5*/  get _value5() { return this.$getField(24, 4); }
                    /*T5*/  set _value5(value) { this.$setField(24, 4, value); }
                    /*int */ get Count()
                    {
                        return 7;
                    }
                    /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
                    {
                        switch(index)
                        {
                            case 0:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(0), $.$box(this._value0, T0));
                            case 1:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(1), $.$box(this._value1, T1));
                            case 2:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(2), $.$box(this._value2, T2));
                            case 3:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(3), $.$box(this._value3, T3));
                            case 4:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(4), $.$box(this._value4, T4));
                            case 5:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(this._formatter.ValueNames.get_Item(5), $.$box(this._value5, T5));
                            case 6:
                            return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._formatter.OriginalFormat);
                            default:
                            throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                        }
                    }
                    $ctor$2(/*LogValuesFormatter*/ formatter, /*T0*/ value0, /*T1*/ value1, /*T2*/ value2, /*T3*/ value3, /*T4*/ value4, /*T5*/ value5)
                    {
                        super.$ctor$1();
                        {
                            this._formatter = formatter;
                            this._value0 = value0;
                            this._value1 = value1;
                            this._value2 = value2;
                            this._value3 = value3;
                            this._value4 = value4;
                            this._value5 = value5;
                        }
                        return this;
                    }
                    /*object?[] */ ToArray()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [$.$box(this._value0, T0), $.$box(this._value1, T1), $.$box(this._value2, T2), $.$box(this._value3, T3), $.$box(this._value4, T4), $.$box(this._value5, T5)], [-1], null);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return this._formatter.FormatWithOverwrite(this.ToArray());
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5).ToString.apply(this, arguments); }
                    /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                        {
                            for(/*int*/ let i = 0; i < this.Count; ++i)
                            {
                                yield this.get_Item(i);
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._formatter = this._formatter;
                        copy._value0 = this._value0;
                        copy._value1 = this._value1;
                        copy._value2 = this._value2;
                        copy._value3 = this._value3;
                        copy._value4 = this._value4;
                        copy._value5 = this._value5;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._formatter = null;
                        this._value0 = $.$default(T0);
                        this._value1 = $.$default(T1);
                        this._value2 = $.$default(T2);
                        this._value3 = $.$default(T3);
                        this._value4 = $.$default(T4);
                        this._value5 = $.$default(T5);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Callback = new ($.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5), $.$spc.System.Exception, $.$spc.System.String))().$ctor(this,  (/*state*/ state, /*exception*/ exception) =>
                            {
                                return $.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5).ToString.call(state);
                            });
                        }
                    }
                    static $h = 1835029;
                    static $g = 6;
                    static $z = 28;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":1}],"m":[{"r":0,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":32769},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1}],"l":[{"t":$.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.LoggerMessage.LogValues$$$$$$$(T0, T1, T2, T3, T4, T5), $.$spc.System.Exception, $.$spc.System.String).$h,"n":"Callback","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33},{"t":2359317,"n":"_formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2},{"t":T0?.$h??1507328,"n":"_value0","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"t":T1?.$h??1572864,"n":"_value1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},{"t":T2?.$h??1638400,"n":"_value2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2},{"t":T3?.$h??1703936,"n":"_value3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2},{"t":T4?.$h??1769472,"n":"_value4","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2},{"t":T5?.$h??1835008,"n":"_value5","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2}],"c":[{"p":[{"n":"formatter","p":2359317},{"n":"value0","p":T0?.$h??1507328},{"n":"value1","p":T1?.$h??1572864},{"n":"value2","p":T2?.$h??1638400},{"n":"value3","p":T3?.$h??1703936},{"n":"value4","p":T4?.$h??1769472},{"n":"value5","p":T5?.$h??1835008}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"g":[T0?.$h??1507328,T1?.$h??1572864,T2?.$h??1638400,T3?.$h??1703936,T4?.$h??1769472,T5?.$h??1835008],"r":6,"d":1703957,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage.LogValues<${T0?.$fullName},${T1?.$fullName},${T2?.$fullName},${T3?.$fullName},${T4?.$fullName},${T5?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_LogValues$$$$$$$ = $v))(T0, T1, T2, T3, T4, T5);
            }
            static $h = 1703957;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.Func$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"n":"DefineScope","d":1703957,"h":4296671253,"f":33},{"r":(T1) => $.$spc.System.Func$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1"],"n":"DefineScope","o":"@$1","d":1703957,"h":8591638549,"f":131105},{"r":(T1, T2) => $.$spc.System.Func$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1","T2"],"n":"DefineScope","o":"@$2","d":1703957,"h":12886605845,"f":131105},{"r":(T1, T2, T3) => $.$spc.System.Func$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1","T2","T3"],"n":"DefineScope","o":"@$3","d":1703957,"h":17181573141,"f":131105},{"r":(T1, T2, T3, T4) => $.$spc.System.Func$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4"],"n":"DefineScope","o":"@$4","d":1703957,"h":21476540437,"f":131105},{"r":(T1, T2, T3, T4, T5) => $.$spc.System.Func$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4","T5"],"n":"DefineScope","o":"@$5","d":1703957,"h":25771507733,"f":131105},{"r":(T1, T2, T3, T4, T5, T6) => $.$spc.System.Func$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.IDisposable).$h,"p":[{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4","T5","T6"],"n":"DefineScope","o":"@$6","d":1703957,"h":30066475029,"f":131105},{"r":$.$spc.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"n":"Define","d":1703957,"h":34361442325,"f":33},{"r":$.$spc.System.Action$$$($.$mela.Microsoft.Extensions.Logging.ILogger, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"n":"Define","o":"@$1","d":1703957,"h":38656409621,"f":33},{"r":(T1) => $.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1"],"n":"Define","o":"@$2","d":1703957,"h":42951376917,"f":131105},{"r":(T1) => $.$spc.System.Action$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1"],"n":"Define","o":"@$3","d":1703957,"h":47246344213,"f":131105},{"r":(T1, T2) => $.$spc.System.Action$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1","T2"],"n":"Define","o":"@$4","d":1703957,"h":51541311509,"f":131105},{"r":(T1, T2) => $.$spc.System.Action$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1","T2"],"n":"Define","o":"@$5","d":1703957,"h":55836278805,"f":131105},{"r":(T1, T2, T3) => $.$spc.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1","T2","T3"],"n":"Define","o":"@$6","d":1703957,"h":60131246101,"f":131105},{"r":(T1, T2, T3) => $.$spc.System.Action$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1","T2","T3"],"n":"Define","o":"@$7","d":1703957,"h":64426213397,"f":131105},{"r":(T1, T2, T3, T4) => $.$spc.System.Action$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4"],"n":"Define","o":"@$8","d":1703957,"h":68721180693,"f":131105},{"r":(T1, T2, T3, T4) => $.$spc.System.Action$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1","T2","T3","T4"],"n":"Define","o":"@$9","d":1703957,"h":73016147989,"f":131105},{"r":(T1, T2, T3, T4, T5) => $.$spc.System.Action$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4","T5"],"n":"Define","o":"@$10","d":1703957,"h":77311115285,"f":131105},{"r":(T1, T2, T3, T4, T5) => $.$spc.System.Action$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1","T2","T3","T4","T5"],"n":"Define","o":"@$11","d":1703957,"h":81606082581,"f":131105},{"r":(T1, T2, T3, T4, T5, T6) => $.$spc.System.Action$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721}],"g":["T1","T2","T3","T4","T5","T6"],"n":"Define","o":"@$12","d":1703957,"h":85901049877,"f":131105},{"r":(T1, T2, T3, T4, T5, T6) => $.$spc.System.Action$$$$$$$$$($.$mela.Microsoft.Extensions.Logging.ILogger, T1, T2, T3, T4, T5, T6, $.$spc.System.Exception).$h,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"formatString","p":1310721},{"n":"options","p":1310741}],"g":["T1","T2","T3","T4","T5","T6"],"n":"Define","o":"@$13","d":1703957,"h":90196017173,"f":131105},{"r":2359317,"p":[{"n":"formatString","p":1310721},{"n":"expectedNamedParameterCount","p":655361}],"n":"CreateLogValuesFormatter","d":1703957,"h":94490984469,"f":34}],"j":[1769493,2162709,2097173,2031637,1966101,1900565,1835029],"h":1703957}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessage`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.NullExternalScopeProvider", ($self) => class NullExternalScopeProvider extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IExternalScopeProvider*/ static Instance = null;
            /*void */ Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
            }
            /*IDisposable */ Microsoft$Extensions$Logging$IExternalScopeProvider$Push(/*object?*/ state)
            {
                return $.$mela.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mela.Microsoft.Extensions.Logging.NullExternalScopeProvider().$ctor$1();
                }
            }
            static $h = 2424853;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":851989,"g":{"r":0,"d":0,"h":17182294037,"f":33},"n":"Instance","d":2424853,"h":12887326741,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":2424853,"h":4297392149,"f":2}],"i":[851989],"h":2424853}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullExternalScopeProvider`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.NullScope", ($self) => class NullScope extends $.$spc.System.Object
        {
            /*NullScope*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mela.Microsoft.Extensions.Logging.NullScope().$ctor$1();
                }
            }
            static $h = 2490389;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2490389,"g":{"r":0,"d":0,"h":12887392277,"f":33},"n":"Instance","d":2490389,"h":8592424981,"f":33}],"m":[{"r":65537,"n":"Dispose","d":2490389,"h":21477326869,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":2490389,"h":17182359573,"f":2}],"i":[57475073],"h":2490389}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.NullScope`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider", ($self) => class LoggerExternalScopeProvider extends $.$spc.System.Object
        {
            /*AsyncLocal<Scope?>*/ _currentScope = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ ForEachScope(TState, /*Action<object?, TState>*/ callback, /*TState*/ state)
            {
                /*void*/  function Report(/*Scope?*/ current)
                {
                    if (current === null)
                    {
                        return;
                    }
                    Report.call(this, current.Parent);
                    callback.Invoke(current.State, state);
                }
                Report.call(this, this._currentScope.Value);
            }
            /*IDisposable */ Push(/*object?*/ state)
            {
                /*Scope?*/ let parent = this._currentScope.Value;
                /*var*/ let newScope = new $.$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope().$ctor$1(this, state, parent);
                this._currentScope.Value = newScope;
                return newScope;
            }
            static $_Scope;
            static get Scope()
            {
                let $cls = $.$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider;
                return $cls.$_Scope ??= $asm.$ncls("$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope", ($self) => class Scope extends $.$spc.System.Object
                {
                    /*LoggerExternalScopeProvider*/ _provider = null;
                    /*bool*/ _isDisposed = false;
                    $ctor$1(/*LoggerExternalScopeProvider*/ provider, /*object?*/ state, /*Scope?*/ parent)
                    {
                        super.$ctor();
                        {
                            this._provider = provider;
                            this.State = state;
                            this.Parent = parent;
                        }
                        return this;
                    }
                    /*Scope?*/ Parent = null;
                    /*object?*/ State = null;
                    static/*conventional*/ /*string? */ ToString()
                    {
                        const $t1 = this.State;
                        return $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t));
                    }
                    //Static convention instance redirect
                    /*string? */ ToString() { return $.$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope.ToString.apply(this, arguments); }
                    /*void */ Dispose()
                    {
                        if (!this._isDisposed)
                        {
                            this._provider._currentScope.Value = this.Parent;
                            this._isDisposed = true;
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1572885;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1572885,"g":{"r":0,"d":0,"h":25771376661,"f":1},"n":"Parent","d":1572885,"h":21476409365,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":38656278549,"f":1},"n":"State","d":1572885,"h":34361311253,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1572885,"h":42951245845,"f":32769},{"r":65537,"n":"Dispose","d":1572885,"h":47246213141,"f":1}],"l":[{"t":1507349,"n":"_provider","d":1572885,"h":4296540181,"f":2},{"t":262145,"n":"_isDisposed","d":1572885,"h":8591507477,"f":2}],"c":[{"p":[{"n":"provider","p":1507349},{"n":"state","p":131073},{"n":"parent","p":1572885}],"n":".ctor","o":"$ctor$1","d":1572885,"h":12886474773,"f":8}],"i":[57475073],"d":1507349,"h":1572885}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope`; }
                }, $cls, ($v) => $cls.$_Scope = $v);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.ForEachScope<TState>(System.Action<object?, TState>, TState)
            Microsoft$Extensions$Logging$IExternalScopeProvider$ForEachScope()
            {
                return this.ForEachScope(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.IExternalScopeProvider.Push(object?)
            Microsoft$Extensions$Logging$IExternalScopeProvider$Push()
            {
                return this.Push(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._currentScope = new ($.$spc.System.Threading.AsyncLocal$$($.$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope))().$ctor$1();
            }
            static $h = 1507349;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"callback","p":(TState) => $.$spc.System.Action$$$($.$spc.System.Object, TState).$h},{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"ForEachScope","d":1507349,"h":12886409237,"f":131073},{"r":57475073,"p":[{"n":"state","p":131073}],"n":"Push","d":1507349,"h":17181376533,"f":1}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$mela.Microsoft.Extensions.Logging.LoggerExternalScopeProvider.Scope).$h,"n":"_currentScope","d":1507349,"h":4296474645,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1507349,"h":8591441941,"f":1}],"i":[851989],"j":[1572885],"h":1507349}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.IExternalScopeProvider ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerExternalScopeProvider`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger", ($self) => class NullLogger extends $.$spc.System.Object
        {
            /*NullLogger*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*IDisposable */ BeginScope(TState, /*TState*/ state)
            {
                return $.$mela.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                return false;
            }
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                return this.Log(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                return this.BeginScope(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger().$ctor$1();
                }
            }
            static $h = 393237;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":393237,"g":{"r":0,"d":0,"h":12885295125,"f":33},"n":"Instance","d":393237,"h":8590327829,"f":33}],"m":[{"r":57475073,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"BeginScope","d":393237,"h":21475229717,"f":131073},{"r":262145,"p":[{"n":"logLevel","p":2293781}],"n":"IsEnabled","d":393237,"h":25770197013,"f":1},{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"state","p":(TState) => TState.$h},{"n":"exception","p":47185921},{"n":"formatter","p":(TState) => $.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"g":["TState"],"n":"Log","d":393237,"h":30065164309,"f":131073}],"c":[{"n":".ctor","o":"$ctor$1","d":393237,"h":17180262421,"f":2}],"i":[917525],"h":393237}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLogger`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Logger<>", (T) => $asm.$gt("$mela.Microsoft.Extensions.Logging.Logger<>", [T], ($self) => class Logger$$ extends $.$spc.System.Object
        {
            /*ILogger*/ _logger = null;
            $ctor$1(/*ILoggerFactory*/ factory)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(factory, "factory");
                    this._logger = factory.Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger($.$mela.Microsoft.Extensions.Logging.Logger$$(T).GetCategoryName());
                }
                return this;
            }
            /*IDisposable? */ Microsoft$Extensions$Logging$ILogger$BeginScope(TState, /*TState*/ state)
            {
                return this._logger.Microsoft$Extensions$Logging$ILogger$BeginScope(TState, state);
            }
            /*bool */ Microsoft$Extensions$Logging$ILogger$IsEnabled(/*LogLevel*/ logLevel)
            {
                return this._logger.Microsoft$Extensions$Logging$ILogger$IsEnabled(logLevel);
            }
            /*void */ Microsoft$Extensions$Logging$ILogger$Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                this._logger.Microsoft$Extensions$Logging$ILogger$Log(TState, logLevel, eventId, state, exception, formatter);
            }
            static /*string */ GetCategoryName()
            {
                return $.$mela.Microsoft.Extensions.Internal.TypeNameHelper.GetTypeDisplayName$1(T.$type, true, false, false, /*.*/ 46);
            }
            /*string */ DebuggerToString()
            {
                return $.$mela.Microsoft.Extensions.Logging.DebuggerDisplayFormatting.DebuggerToString($.$mela.Microsoft.Extensions.Logging.Logger$$(T).GetCategoryName(), this);
            }
            static $h = 1376277;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"n":"GetCategoryName","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":34},{"r":1310721,"n":"DebuggerToString","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":8}],"l":[{"t":917525,"n":"_logger","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2,"a":[{"t":37355521,"c":4332322817,"a":[{"v":3,"t":37421057}]}]}],"c":[{"p":[{"n":"factory","p":1048597}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[$.$mela.Microsoft.Extensions.Logging.ILogger$$(T).$h,917525],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{DebuggerToString(),nq}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger$$(T), $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Logger<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory", ($self) => class NullLoggerFactory extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*NullLoggerFactory*/ static Instance = null;
            /*ILogger */ CreateLogger(/*string*/ name)
            {
                return $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance;
            }
            /*void */ AddProvider(/*ILoggerProvider*/ provider)
            {
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerFactory$CreateLogger()
            {
                return this.CreateLogger(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerFactory.AddProvider(Microsoft.Extensions.Logging.ILoggerProvider)
            Microsoft$Extensions$Logging$ILoggerFactory$AddProvider()
            {
                return this.AddProvider(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory().$ctor$1();
                }
            }
            static $h = 524309;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":917525,"p":[{"n":"name","p":1310721}],"n":"CreateLogger","d":524309,"h":12885426197,"f":1},{"r":65537,"p":[{"n":"provider","p":1114133}],"n":"AddProvider","d":524309,"h":17180393493,"f":1},{"r":65537,"n":"Dispose","d":524309,"h":21475360789,"f":1}],"l":[{"t":524309,"n":"Instance","d":524309,"h":8590458901,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":524309,"h":4295491605,"f":1}],"i":[1048597,57475073],"h":524309}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerFactory, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLoggerFactory`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider", ($self) => class NullLoggerProvider extends $.$spc.System.Object
        {
            /*NullLoggerProvider*/ static Instance = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*ILogger */ CreateLogger(/*string*/ categoryName)
            {
                return $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger.Instance;
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILoggerProvider.CreateLogger(string)
            Microsoft$Extensions$Logging$ILoggerProvider$CreateLogger()
            {
                return this.CreateLogger(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$mela.Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider().$ctor$1();
                }
            }
            static $h = 589845;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":589845,"g":{"r":0,"d":0,"h":12885491733,"f":33},"n":"Instance","d":589845,"h":8590524437,"f":33}],"m":[{"r":917525,"p":[{"n":"categoryName","p":1310721}],"n":"CreateLogger","d":589845,"h":21475426325,"f":1},{"r":65537,"n":"Dispose","d":589845,"h":25770393621,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":589845,"h":17180459029,"f":2}],"i":[1114133,57475073],"h":589845}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILoggerProvider, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLoggerProvider`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger<>", (T) => $asm.$gt("$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger<>", [T], ($self) => class NullLogger$$ extends $.$spc.System.Object
        {
            /*NullLogger<T>*/ static Instance = null;
            /*IDisposable */ BeginScope(TState, /*TState*/ state)
            {
                return $.$mela.Microsoft.Extensions.Logging.NullScope.Instance;
            }
            /*void */ Log(TState, /*LogLevel*/ logLevel, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
            }
            /*bool */ IsEnabled(/*LogLevel*/ logLevel)
            {
                return false;
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.Log<TState>(Microsoft.Extensions.Logging.LogLevel, Microsoft.Extensions.Logging.EventId, TState, System.Exception?, System.Func<TState, System.Exception?, string>)
            Microsoft$Extensions$Logging$ILogger$Log()
            {
                return this.Log(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.IsEnabled(Microsoft.Extensions.Logging.LogLevel)
            Microsoft$Extensions$Logging$ILogger$IsEnabled()
            {
                return this.IsEnabled(...arguments);
            }
            //Generated interface implemetation for Microsoft.Extensions.Logging.ILogger.BeginScope<TState>(TState)
            Microsoft$Extensions$Logging$ILogger$BeginScope()
            {
                return this.BeginScope(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new ($.$mela.Microsoft.Extensions.Logging.Abstractions.NullLogger$$(T))().$ctor$1();
                }
            }
            static $h = 458773;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57475073,"p":[{"n":"state","p":(TState) => TState.$h}],"g":["TState"],"n":"BeginScope","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":131073},{"r":65537,"p":[{"n":"logLevel","p":2293781},{"n":"eventId","p":720917},{"n":"state","p":(TState) => TState.$h},{"n":"exception","p":47185921},{"n":"formatter","p":(TState) => $.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"g":["TState"],"n":"Log","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":131073},{"r":262145,"p":[{"n":"logLevel","p":2293781}],"n":"IsEnabled","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1}],"l":[{"t":this.$h,"n":"Instance","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1}],"i":[$.$mela.Microsoft.Extensions.Logging.ILogger$$(T).$h,917525],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mela.Microsoft.Extensions.Logging.ILogger$$(T), $.$mela.Microsoft.Extensions.Logging.ILogger ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.NullLogger<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$mela.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$mela.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 2686997;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30067458069,"f":1},"s":{"r":0,"d":0,"h":34362425365,"f":1},"n":"Length","d":2686997,"h":25772490773,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42952359957,"f":1},"n":"Capacity","d":2686997,"h":38657392661,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":64427196437,"f":1},"n":"Item","o":"@$2","d":2686997,"h":60132229141,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":77312098325,"f":1},"n":"RawChars","d":2686997,"h":73017131029,"f":1}],"m":[{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":2686997,"h":47247327253,"f":1},{"r":458753,"n":"GetPinnableReference","d":2686997,"h":51542294549,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":2686997,"h":55837261845,"f":1},{"r":1310721,"n":"ToString","d":2686997,"h":68722163733,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":2686997,"h":81607065621,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":2686997,"h":85902032917,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":2686997,"h":90197000213,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":2686997,"h":94491967509,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":2686997,"h":98786934805,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":2686997,"h":103081902101,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":2686997,"h":107376869397,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","d":2686997,"h":111671836693,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$1","d":2686997,"h":115966803989,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":2686997,"h":120261771285,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":2686997,"h":124556738581,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$3","d":2686997,"h":128851705877,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":2686997,"h":133146673173,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":2686997,"h":137441640469,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":2686997,"h":141736607765,"f":2},{"r":65537,"n":"Dispose","d":2686997,"h":146031575061,"f":1}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":2686997,"h":4297654293,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":2686997,"h":8592621589,"f":2},{"t":655361,"n":"_pos","d":2686997,"h":12887588885,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":2686997,"h":17182556181,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":2686997,"h":21477523477,"f":1},{"n":".ctor","o":"$ctor$4","d":2686997,"h":150326542357,"f":1}],"h":2686997}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$str("$mela.Microsoft.Extensions.Logging.Abstractions.LogEntry<>", (TState) => $asm.$gt("$mela.Microsoft.Extensions.Logging.Abstractions.LogEntry<>", [TState], ($self) => class LogEntry$$ extends $.$spc.System.ValueType
        {
            $ctor$2(/*LogLevel*/ logLevel, /*string*/ category, /*EventId*/ eventId, /*TState*/ state, /*Exception?*/ exception, /*Func<TState, Exception?, string>*/ formatter)
            {
                super.$ctor$1();
                {
                    this.LogLevel = logLevel;
                    this.Category = category;
                    this.EventId = eventId;
                    this.State = state;
                    this.Exception = exception;
                    this.Formatter = formatter;
                }
                return this;
            }
            /*LogLevel*/ LogLevel = 0;
            /*string*/ Category = null;
            /*EventId*/ EventId;
            /*TState*/ State = $.$default(TState);
            /*Exception?*/ Exception = null;
            /*Func<TState, Exception?, string>*/ Formatter = null;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.LogLevel = this.LogLevel;
                copy.Category = this.Category;
                copy.EventId = this.EventId.Clone();
                copy.State = this.State;
                copy.Exception = this.Exception;
                copy.Formatter = this.Formatter;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.LogLevel = 0;
                this.EventId = $.$default($.$mela.Microsoft.Extensions.Logging.EventId);
            }
            static $h = 327701;
            static $g = 1;
            static $z = 28;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2293781,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":1},"n":"LogLevel","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":1},"n":"Category","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1},{"p":720917,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":1},"n":"EventId","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1},{"p":TState?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":1},"n":"State","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":1},{"p":47185921,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":1},"n":"Exception","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":1},{"p":$.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":1},"n":"Formatter","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":1}],"c":[{"p":[{"n":"logLevel","p":2293781},{"n":"category","p":1310721},{"n":"eventId","p":720917},{"n":"state","p":TState?.$h??1507328},{"n":"exception","p":47185921},{"n":"formatter","p":$.$spc.System.Func$$$$(TState, $.$spc.System.Exception, $.$spc.System.String).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":1}],"g":[TState?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Microsoft.Extensions.Logging.Abstractions.LogEntry<${TState?.$fullName}>`; }
        }));
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.LoggerMessageAttribute", ($self) => class LoggerMessageAttribute extends $.$spc.System.Attribute
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ eventId, /*LogLevel*/ level, /*string*/ message)
            {
                super.$ctor$1();
                {
                    this.EventId = eventId;
                    this.Level = level;
                    this.Message = message;
                }
                return this;
            }
            $ctor$4(/*LogLevel*/ level, /*string*/ message)
            {
                super.$ctor$1();
                {
                    this.Level = level;
                    this.Message = message;
                }
                return this;
            }
            $ctor$5(/*LogLevel*/ level)
            {
                super.$ctor$1();
                {
                    this.Level = level;
                }
                return this;
            }
            $ctor$6(/*string*/ message)
            {
                super.$ctor$1();
                {
                    this.Message = message;
                }
                return this;
            }
            /*int*/ EventId = 0;
            /*string?*/ EventName = null;
            /*LogLevel*/ Level = 0;
            /*string*/ Message = null;
            /*bool*/ SkipEnabledCheck = false;
            //default member initializer
            constructor()
            {
                super();
                this.EventId = -1;
                this.Level = 6;
                this.Message = "";
                this.SkipEnabledCheck = false;
            }
            static $h = 2228245;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":655361,"g":{"r":0,"d":0,"h":34361966613,"f":1},"s":{"r":0,"d":0,"h":38656933909,"f":1},"n":"EventId","d":2228245,"h":30066999317,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51541835797,"f":1},"s":{"r":0,"d":0,"h":55836803093,"f":1},"n":"EventName","d":2228245,"h":47246868501,"f":1},{"p":2293781,"g":{"r":0,"d":0,"h":68721704981,"f":1},"s":{"r":0,"d":0,"h":73016672277,"f":1},"n":"Level","d":2228245,"h":64426737685,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85901574165,"f":1},"s":{"r":0,"d":0,"h":90196541461,"f":1},"n":"Message","d":2228245,"h":81606606869,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":103081443349,"f":1},"s":{"r":0,"d":0,"h":107376410645,"f":1},"n":"SkipEnabledCheck","d":2228245,"h":98786476053,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":2228245,"h":4297195541,"f":1},{"p":[{"n":"eventId","p":655361},{"n":"level","p":2293781},{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$3","d":2228245,"h":8592162837,"f":1},{"p":[{"n":"level","p":2293781},{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$4","d":2228245,"h":12887130133,"f":1},{"p":[{"n":"level","p":2293781}],"n":".ctor","o":"$ctor$5","d":2228245,"h":17182097429,"f":1},{"p":[{"n":"message","p":1310721}],"n":".ctor","o":"$ctor$6","d":2228245,"h":21477064725,"f":1}],"h":2228245,"a":[{"t":14614529,"c":21489451009,"a":[{"v":64,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LoggerMessageAttribute`; }
        });
        
        $asm.$cls("$mela.Microsoft.Extensions.Logging.ProviderAliasAttribute", ($self) => class ProviderAliasAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ alias)
            {
                super.$ctor$1();
                {
                    this.Alias = alias;
                }
                return this;
            }
            /*string*/ Alias = null;
            static $h = 2555925;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182425109,"f":1},"n":"Alias","d":2555925,"h":12887457813,"f":1}],"c":[{"p":[{"n":"alias","p":1310721}],"n":".ctor","o":"$ctor$2","d":2555925,"h":4297523221,"f":1}],"h":2555925,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `Microsoft.Extensions.Logging.ProviderAliasAttribute`; }
        });
        
        $asm.$str("$mela.Microsoft.Extensions.Logging.EventId", ($self) => class EventId extends $.$spc.System.ValueType
        {
            static /*EventId */ op_Implicit(/*int*/ i)
            {
                return new $.$mela.Microsoft.Extensions.Logging.EventId().$ctor$2(i, null);
            }
            static /*bool */ op_Equality(/*EventId*/ left, /*EventId*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*EventId*/ left, /*EventId*/ right)
            {
                return !left.Equals$2(right);
            }
            $ctor$2(/*int*/ id, /*string?*/ name)
            {
                super.$ctor$1();
                {
                    this.Id = id;
                    this.Name = name;
                }
                return this;
            }
            /*int*/ Id = 0;
            /*string?*/ Name = null;
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name ?? $.$spc.System.Int32.ToString.call(this.Id);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.EventId.ToString.apply(this, arguments); }
            /*bool */ Equals$2(/*EventId*/ other)
            {
                return this.Id === other.Id;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if (obj === null)
                {
                    return false;
                }
                let eventId;
                return $.$is(obj, $.$mela.Microsoft.Extensions.Logging.EventId, { set $v(v){ eventId = v; } }) && this.Equals$2(eventId);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$mela.Microsoft.Extensions.Logging.EventId.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this.Id;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$mela.Microsoft.Extensions.Logging.EventId.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<Microsoft.Extensions.Logging.EventId>.Equals(Microsoft.Extensions.Logging.EventId)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Id = this.Id;
                copy.Name = this.Name;
                return copy;
            }
            static $h = 720917;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30065491989,"f":1},"n":"Id","d":720917,"h":25770524693,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950393877,"f":1},"n":"Name","d":720917,"h":38655426581,"f":1}],"m":[{"r":1310721,"n":"ToString","d":720917,"h":47245361173,"f":32769},{"r":262145,"p":[{"n":"other","p":720917}],"n":"Equals","o":"@$2","d":720917,"h":51540328469,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":720917,"h":55835295765,"f":32769},{"r":655361,"n":"GetHashCode","d":720917,"h":60130263061,"f":32769}],"c":[{"p":[{"n":"id","p":655361},{"n":"name","p":1310721,"f":65}],"n":".ctor","o":"$ctor$2","d":720917,"h":17180590101,"f":1},{"n":".ctor","o":"$ctor$3","d":720917,"h":64425230357,"f":1}],"i":[$.$spc.System.IEquatable$$($.$mela.Microsoft.Extensions.Logging.EventId).$h],"h":720917}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$mela.Microsoft.Extensions.Logging.EventId) ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.EventId`; }
        });
        
        $asm.$str("$mela.Microsoft.Extensions.Logging.LogLevel", ($self) => class LogLevel extends $.$spc.System.Enum
        {
            static Trace = 0;
            static Debug = 1;
            static Information = 2;
            static Warning = 3;
            static Error = 4;
            static Critical = 5;
            static None = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Trace": 0n,
                    "Debug": 1n,
                    "Information": 2n,
                    "Warning": 3n,
                    "Error": 4n,
                    "Critical": 5n,
                    "None": 6n
                };
            }
            static $h = 2293781;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2293781,"n":"Trace","d":2293781,"h":4297261077,"f":33},{"t":2293781,"n":"Debug","d":2293781,"h":8592228373,"f":33},{"t":2293781,"n":"Information","d":2293781,"h":12887195669,"f":33},{"t":2293781,"n":"Warning","d":2293781,"h":17182162965,"f":33},{"t":2293781,"n":"Error","d":2293781,"h":21477130261,"f":33},{"t":2293781,"n":"Critical","d":2293781,"h":25772097557,"f":33},{"t":2293781,"n":"None","d":2293781,"h":30067064853,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2293781,"h":34362032149,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2293781}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.LogLevel`; }
        });
        
        $asm.$str("$mela.Microsoft.Extensions.Logging.FormattedLogValues", ($self) => class FormattedLogValues extends $.$spc.System.ValueType
        {
            /*int*/ static MaxCachedFormatters = 1024;
            /*string*/ static NullFormat = null;
            /*int*/ static s_count = 0;
            /*ConcurrentDictionary<string, LogValuesFormatter>*/ static s_formatters = null;
            /*LogValuesFormatter?*/  get _formatter() { return this.$getField(0, 4); }
            /*LogValuesFormatter?*/  set _formatter(value) { this.$setField(0, 4, value); }
            /*object?[]?*/  get _values() { return this.$getField(4, 4); }
            /*object?[]?*/  set _values(value) { this.$setField(4, 4, value); }
            /*string*/  get _originalMessage() { return this.$getField(8, 4); }
            /*string*/  set _originalMessage(value) { this.$setField(8, 4, value); }
            /*string?*/  get _cachedToString() { return this.$getField(12, 4); }
            /*string?*/  set _cachedToString(value) { this.$setField(12, 4, value); }
            /*LogValuesFormatter? */ get Formatter()
            {
                return this._formatter;
            }
            $ctor$2(/*string?*/ format, /*params object?[]?*/ values)
            {
                super.$ctor$1();
                {
                    if (values !== null && values.length !== 0 && $.$spc.System.String.op_Inequality(format, null))
                    {
                        if ($.$mela.Microsoft.Extensions.Logging.FormattedLogValues.s_count >= 1024/*MaxCachedFormatters*/)
                        {
                            if (!$.$mela.Microsoft.Extensions.Logging.FormattedLogValues.s_formatters.TryGetValue(format, $.$ref(() => this._formatter, ($v) => this._formatter = $v, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter)))
                            {
                                this._formatter = new $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(format);
                            }
                        }
                        else 
                        {
                            this._formatter = $.$mela.Microsoft.Extensions.Logging.FormattedLogValues.s_formatters.GetOrAdd(format, new ($.$spc.System.Func$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter))().$ctor(this,  (/*f*/ f) =>
                            {
                                $.$spc.System.Threading.Interlocked.Increment($.$ref(() => $.$mela.Microsoft.Extensions.Logging.FormattedLogValues.s_count, ($v) => $.$mela.Microsoft.Extensions.Logging.FormattedLogValues.s_count = $v, $.$spc.System.Int32));
                                return new $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter().$ctor$1(f);
                            }));
                        }
                    }
                    else 
                    {
                        this._formatter = null;
                    }
                    this._originalMessage = format ?? "[null]"/*NullFormat*/;
                    this._values = values;
                    this._cachedToString = null;
                }
                return this;
            }
            /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.IndexOutOfRangeException().$ctor$10("index");
                }
                if (index === ((this.Count - 1) | 0))
                {
                    return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("{OriginalFormat}", this._originalMessage);
                }
                return this._formatter.GetValue(this._values, index);
            }
            /*int */ get Count()
            {
                if (this._formatter === null)
                {
                    return 1;
                }
                return ((this._formatter.ValueNames.Count + 1) | 0);
            }
            /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(function*()
                {
                    for(/*int*/ let i = 0; i < this.Count; ++i)
                    {
                        yield this.get_Item(i);
                    }
                }.bind(this)).GetEnumerator();
            }
            static/*conventional*/ /*string */ ToString()
            {
                if (this._formatter === null)
                {
                    return this._originalMessage;
                }
                return this._cachedToString ??= this._formatter.Format(this._values);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$mela.Microsoft.Extensions.Logging.FormattedLogValues.ToString.apply(this, arguments); }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
            System$Collections$Generic$IReadOnlyList$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._formatter = this._formatter;
                copy._values = this._values;
                copy._originalMessage = this._originalMessage;
                copy._cachedToString = this._cachedToString;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._formatter = null;
                this._values = null;
                this._originalMessage = null;
                this._cachedToString = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.NullFormat = "[null]";
                }
                {
                    this.s_formatters = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter))().$ctor$1();
                }
            }
            static $h = 786453;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":2359317,"g":{"r":0,"d":0,"h":42950459413,"f":8},"n":"Formatter","d":786453,"h":38655492117,"f":8},{"p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":55835361301,"f":1},"n":"Item","o":"@$2","d":786453,"h":51540394005,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":64425295893,"f":1},"n":"Count","d":786453,"h":60130328597,"f":1}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,"n":"GetEnumerator","d":786453,"h":68720263189,"f":1},{"r":1310721,"n":"ToString","d":786453,"h":73015230485,"f":32769}],"l":[{"t":655361,"n":"MaxCachedFormatters","d":786453,"h":4295753749,"f":40},{"t":1310721,"n":"NullFormat","d":786453,"h":8590721045,"f":34},{"t":655361,"n":"s_count","d":786453,"h":12885688341,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.String, $.$mela.Microsoft.Extensions.Logging.LogValuesFormatter).$h,"n":"s_formatters","d":786453,"h":17180655637,"f":34},{"t":2359317,"n":"_formatter","d":786453,"h":21475622933,"f":2},{"t":0,"n":"_values","d":786453,"h":25770590229,"f":2},{"t":1310721,"n":"_originalMessage","d":786453,"h":30065557525,"f":2},{"t":1310721,"n":"_cachedToString","d":786453,"h":34360524821,"f":2}],"c":[{"p":[{"n":"format","p":1310721},{"n":"values","p":0,"f":16}],"n":".ctor","o":"$ctor$2","d":786453,"h":47245426709,"f":1},{"n":".ctor","o":"$ctor$3","d":786453,"h":81605165077,"f":1}],"i":[$.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h,31588353],"h":786453}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `Microsoft.Extensions.Logging.FormattedLogValues`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions"))